# 剑雅 4 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 155

TEST2 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 C
2 C
3 B
4 B
5 A
6 Cathedral
7 Markets
8 Gardens
9 Art Gallery
10 climb the tower / see the view
Section2, Questions11–20
11 C
12 B
13 A
14 C
15 B
16 C
17 A
18 B
19 B
20 A
Section3, Questions21–30
21 collecting data / gathering data / data collection
22 1,500
23 5
24 3,000–4,000
25–26 IN EITHER ORDER: B; C
27 Mehta
28 Survey Research
29 London University / London University Press
30 1988
Section4, Questions31–40
31 C
32 A
33 mass media / media
34 academic circles / academics / researchers
35 specialist knowledge / specialised knowledge
36 unaware
37 individual customers / individual consumers / individuals
38 illegal profit / illegal profits
39–40 IN EITHER ORDER: D; E
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. C

2. C

3. B

4. B

5. A

6. Cathedral

7. Markets

8. Gardens

9. Art Gallery

10. climb the tower / see the view

### Part 2 · source page 155

TEST2 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 C
2 C
3 B
4 B
5 A
6 Cathedral
7 Markets
8 Gardens
9 Art Gallery
10 climb the tower / see the view
Section2, Questions11–20
11 C
12 B
13 A
14 C
15 B
16 C
17 A
18 B
19 B
20 A
Section3, Questions21–30
21 collecting data / gathering data / data collection
22 1,500
23 5
24 3,000–4,000
25–26 IN EITHER ORDER: B; C
27 Mehta
28 Survey Research
29 London University / London University Press
30 1988
Section4, Questions31–40
31 C
32 A
33 mass media / media
34 academic circles / academics / researchers
35 specialist knowledge / specialised knowledge
36 unaware
37 individual customers / individual consumers / individuals
38 illegal profit / illegal profits
39–40 IN EITHER ORDER: D; E
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. C

12. B

13. A

14. C

15. B

16. C

17. A

18. B

19. B

20. A

### Part 3 · source page 155

TEST2 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 C
2 C
3 B
4 B
5 A
6 Cathedral
7 Markets
8 Gardens
9 Art Gallery
10 climb the tower / see the view
Section2, Questions11–20
11 C
12 B
13 A
14 C
15 B
16 C
17 A
18 B
19 B
20 A
Section3, Questions21–30
21 collecting data / gathering data / data collection
22 1,500
23 5
24 3,000–4,000
25–26 IN EITHER ORDER: B; C
27 Mehta
28 Survey Research
29 London University / London University Press
30 1988
Section4, Questions31–40
31 C
32 A
33 mass media / media
34 academic circles / academics / researchers
35 specialist knowledge / specialised knowledge
36 unaware
37 individual customers / individual consumers / individuals
38 illegal profit / illegal profits
39–40 IN EITHER ORDER: D; E
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. collecting data / gathering data / data collection

22. 1,500 / 1500

23. 5

24. 3,000-4,000 / 3000-4000

25. B / C

26. B / C

27. Mehta

28. Survey Research

29. London University / London University Press

30. 1988

### Part 4 · source page 155

TEST2 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 C
2 C
3 B
4 B
5 A
6 Cathedral
7 Markets
8 Gardens
9 Art Gallery
10 climb the tower / see the view
Section2, Questions11–20
11 C
12 B
13 A
14 C
15 B
16 C
17 A
18 B
19 B
20 A
Section3, Questions21–30
21 collecting data / gathering data / data collection
22 1,500
23 5
24 3,000–4,000
25–26 IN EITHER ORDER: B; C
27 Mehta
28 Survey Research
29 London University / London University Press
30 1988
Section4, Questions31–40
31 C
32 A
33 mass media / media
34 academic circles / academics / researchers
35 specialist knowledge / specialised knowledge
36 unaware
37 individual customers / individual consumers / individuals
38 illegal profit / illegal profits
39–40 IN EITHER ORDER: D; E
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. C

32. A

33. mass media / media

34. academic circles / academics / researchers

35. specialist knowledge / specialised knowledge

36. unaware

37. individual customers / individual consumers / individuals

38. illegal profit / illegal profits

39. D / E

40. D / E

## A 类阅读

### Academic Reading · source page 156

ACADEMIC READING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Reading Passage1, Questions1–13
1 isolation
2 economic globalisation / globalization / socio-economic pressures
3 cultural identity
4 traditional skill
5 E
6 B
7 D
8 C
9 B
10 NO
11 YES
12 NOT GIVEN
13 YES
Reading Passage2, Questions14–26
14 C
15 B
16 YES
17 NO
18 YES
19 YES
20 YES
21 NOT GIVEN
22 NO
23 YES
24 emotional / emotional problems
25 headache / headaches
26 general ill health
Reading Passage3, Questions27–40
27 H
28 F
29 A
30 H
31 I
32 B
33–35 IN ANY ORDER: A; C; F
36 B
37 G
38 E
39 D
40 A
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. isolation

2. economic globalisation / economic globalization / globalization / socio-economic pressures

3. cultural identity

4. traditional skill

5. E

6. B

7. D

8. C

9. B

10. NO

11. YES

12. NOT GIVEN

13. YES

14. C

15. B

16. YES

17. NO

18. YES

19. YES

20. YES

21. NOT GIVEN

22. NO

23. YES

24. emotional / emotional problems

25. headache / headaches

26. general ill health

27. H

28. F

29. A

30. H

31. I

32. B

33. A / C / F

34. A / C / F

35. A / C / F

36. B

37. G

38. E

39. D

40. A

## A 类写作

### Writing material: c4-t2-w-1

Original daily-demand graph and usage pie inspected. Horizontal time is 0–24 hours in a typical day; vertical demand is labelled units of electricity, not explicitly kWh. Winter demand is substantially higher throughout: approximately 35,000 units at midnight, an early peak just under 40,000 around 3:00, a low around 30,000 at about 9:00, roughly 40,000 during much of the afternoon, and the highest peak around 45,000 near 22:00 before dropping to about 35,000 by 24:00. Summer starts around 17,000, falls to roughly 13,000 near 9:00, rises to about 20,000 early in the afternoon, falls to around 16,000, and has a smaller late-evening peak near 19,000 before declining. These curve readings are approximate. Pie percentages are explicitly labelled: heating rooms and heating water 52.5%; ovens, kettles and washing machines 17.5%; lighting, TV and radio 15%; vacuum cleaners, food mixers and electric tools 15%. Shares total 100%. Heating uses more than all other categories combined. The pie refers to an average English home; do not invent separate seasonal pie shares.



### Writing material: c4-t2-w-2

Two explicit questions: difficulty defining happiness, and factors important to achieving it. Address both; no one definition or personal position is required.



## 口语
