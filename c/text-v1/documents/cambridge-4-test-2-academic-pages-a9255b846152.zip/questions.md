# 剑雅 4 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/7bcb4e1aa31def592e53459bea525c51d0ca9969d968004810873cf5a7b7ae82.jpg; PDF page 35; full -->

```text
Test 2 
LISTENING 
SECTION 1 Questions 1-10 
Questions 1-5 
Choose the correct letter, A, B or C 
Example 
How long has Sally been waiting? 
A five minutes 
B twenty minutes 
C thirty minutes [Example answer C] 
1 What does Peter want to drink? 
A tea 
B coffee 
C a cold drink 
2 What caused Peter problems at the bank? 
A The exchange rate was down . 
B He was late. 
C The computers weren't working. 
3 Who did Peter talk to at the bank? 
A an old friend 
B an American man 
C a German man 
4 Henry gave Peter a map of 
A the city. 
B the bus routes. 
C the train system. 
5 What do Peter and Sally decide to order? 
A food and drinks 
B just food 
C just drinks 
34
```

[Original question page](assets/7bcb4e1aa31def592e53459bea525c51d0ca9969d968004810873cf5a7b7ae82.jpg)

<!-- Source: /api/assets/75fb1b37b3fa245f4c4713bcbfad52946b6bfe54897cd4ae787062a8a9c779ab.jpg; PDF page 36; full -->

```text
Questions 6-8 
Complete the notes below using words from the box: 
Art Gallery 
Cathedral 
Castle 
Gardens 
Markets 
Tourist attractions open all day: 6 .... .. .... ..... ..... ... .. ... .. and Gardens 
Tourist attractions NOT open on Mondays: 7 ............ .................. and Castle 
Tourist attractions which have free entry: 8 .......................... .... and Markets 
Questions 9 and 10 
Complete the sentences below. 
Write NO MORE THAN THREE WORDS for each answer. 
9 The first place Peter and Sally will visit is the ................................ . 
10 At the Cathedral, Peter really wants to ....... ................................ . 
35
```

[Original question page](assets/75fb1b37b3fa245f4c4713bcbfad52946b6bfe54897cd4ae787062a8a9c779ab.jpg)

### Part 2

<!-- Source: /api/assets/90dd7aa5b65ae66f848845684d7170c2566cab7f84519931dac580061e739f10.jpg; PDF page 37; full -->

```text
SECTION 2 Questions 11-20 
Questions 11-20 
Choose the correct letter, A, B or C 
11 The Counselling Service may contact tutors if 
A they are too slow in marking assignments. 
B they give students a lot of work. 
C they don 't inform students about their progress. 
12 Stress may be caused by 
A new teachers. 
B time pressure. 
C unfamiliar subject matter. 
13 International students may find stress difficult to handle because 
A they lack support from family and friends. 
B they don't have time to make new friends. 
C they find it difficult to socialise. 
14 A personal crisis may be caused by 
A studying for too long overseas. 
B business problems in the student's own country. 
C disruptions to personal relationships. 
15 Students may lose self-esteem if 
A they have to change courses. 
B they don't complete a course. 
C their family puts too much pressure on them . 
16 Students should consult Glenda Roberts if 
A their general health is poor. 
B their diet is too strict. 
C they can't eat the local food. 
17 Students in financial difficulties can receive 
A assistance to buy books. 
B a loan to pay their course fees. 
C a no-interest loan to cover study expenses. 
36
```

[Original question page](assets/90dd7aa5b65ae66f848845684d7170c2566cab7f84519931dac580061e739f10.jpg)

<!-- Source: /api/assets/b4fcfa7cbe7e00f5f2a803724d49bf68bc1db2339c029a86e45640c65791d450.jpg; PDF page 38; full -->

```text
18 Loans are also available to students who 
A can't pay their rent. 
B need to buy furniture . 
C can't cover their living expenses. 
19 The number of students counselled by the service last year was 
A 214. 
B 240. 
C 2,600. 
20 The speaker thinks the Counselling Service 
A has been effective in spite of staff shortages. 
B is under-used by students. 
C has suffered badly because of staff cuts. 
37
```

[Original question page](assets/b4fcfa7cbe7e00f5f2a803724d49bf68bc1db2339c029a86e45640c65791d450.jpg)

### Part 3

<!-- Source: /api/assets/17d271e300f7e70b7bceee6586942c1a108a555213b99543b05ac136f1002069.jpg; PDF page 39; full -->

```text
SECTION3 Questions21–30
Questions21–24: Complete the notes below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
DETAILS OF ASSIGNMENT
Part1 Essay
Title: ‘Assess the two main methods of (21) __________ in social science research’
Number of words: (22) __________
Part2 Small-scale study
Choose one method. Gather data from at least (23) __________ subjects.
Part3 Report on study
Number of words: (24) __________
Questions25 and26: Choose TWO letters A–E.
What TWO disadvantages of the questionnaire form of data collection do the students discuss?
A The data is sometimes invalid.
B Too few people may respond.
C It is less likely to reveal the unexpected.
D It can only be used with literate populations.
E There is a delay between the distribution and return of questionnaires.
```

[Original question page](assets/17d271e300f7e70b7bceee6586942c1a108a555213b99543b05ac136f1002069.jpg)

<!-- Source: /api/assets/5e94e9323b61bf82b6dd76b9ae377fa3f287332e908eb3f9cb3f04b6170c0902.jpg; PDF page 40; full -->

```text
Questions27–30
Complete the table below. Write NO MORE THAN THREE WORDS OR A NUMBER for each answer.
AUTHOR | TITLE | PUBLISHER | YEAR OF PUBLICATION
(27) __________ |‘Sample Surveys in Social Science Research’|[empty non-answer cell]|[empty non-answer cell]
Bell |(28) __________ |(29) __________ |[empty non-answer cell]
Wilson |‘Interviews That Work’|Oxford University Press|(30) __________
```

[Original question page](assets/5e94e9323b61bf82b6dd76b9ae377fa3f287332e908eb3f9cb3f04b6170c0902.jpg)

### Part 4

<!-- Source: /api/assets/0e6b2f79f0e19d63ff976a894a6bf111a44a7344ceb87579a19095c7dfcd4e79.jpg; PDF page 41; full -->

```text
SECTION 4 Questions 31-40 
Questions 31 and 32 
Choose the correct letter, A, B or C 
31 Corporate crime is generally committed 
A against individuals. 
B by groups. 
C for companies. 
32 Corporate crime does NOT include 
A employees stealing from their company. 
B unintentional crime by employees. 
C fraud resulting from company policy. 
Questions 33-38 
Complete the notes below. 
Write NO MORE THAN THREE WORDS for each answer. 
Corporate crime has been ignored by: 
a) the 33 ....................................... e.g. films 
b) 34 ...................................... . 
Reasons: 
a) often more complex, and needing 35 ...................................... . 
b) less human interest than conventional crime 
c) victims often 36 ...................................... . 
Effects: 
a) Economic costs 
• may appear unimportant to 37 ...................................... . 
• can make large 38 ....................................... for company 
• cause more losses to individuals than conventional crimes 
b) Social costs 
• make people lose trust in business world 
• affect poorer people most 
---------------------------------------------
40
```

[Original question page](assets/0e6b2f79f0e19d63ff976a894a6bf111a44a7344ceb87579a19095c7dfcd4e79.jpg)

<!-- Source: /api/assets/a9a9f15ffd00d6eacb5eb16a541ea315ee8355b448a58335d5c412f0a0731cc6.jpg; PDF page 42; full -->

```text
Questions 39 and 40 
Choose TWO letters A-F. 
The oil tanker explosion was an example of a crime which 
A was no-one's fault. 
B was not a corporate crime. 
C was intentional. 
D was caused by indifference. 
E had tragic results. 
F made a large profit for the company . 
41
```

[Original question page](assets/a9a9f15ffd00d6eacb5eb16a541ea315ee8355b448a58335d5c412f0a0731cc6.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/83b16e8182f5361f45e95751d1a732c5c1e79e340ead0fe5244d2e2f88d48989.jpg; PDF page 43; full -->

```text
READING PASSAGE 1 
You should spend about 20 minutes on Questions 1-13 which are based on Reading Passage 1 
below. 
Lost for Words

Many minority languages are on the danger list 
In the Native American Navajo nation, 
which sprawls across four states in 
the American south-west, the native 
language is dying. Most of its speakers 
are middle-aged or elderly. Although 
many students take classes in Navajo, 
the schools are run in English. Street 
signs, supermarket goods and even 
their own newspaper are all in 
English. Not surprisingly. linguists 
doubt that any native speakers of 
Navajo will remain in a hundred years' 
time . 
Navajo is far from alone. Half the 
world's 6,800 languages are likely to 
vanish within two generations- that's 
one language lost every ten days. Never 
before has the planet's linguistic diver­
sity shrunk at such a pace. ‘At the 
moment, we are heading for about 
three or four languages dominating the 
world,' says Mark Pagel, an evolution­
ary biologist at the University of 
Reading. 'It's a mass extinction, and 
whether we will ever rebound from the 
loss is difficult to know.' 
Isolation breeds linguistic diversity: 
as a result, the world is peppered with 
languages spoken by only a few people. 
Only 250 languages have more than a 
42 
million speakers, and at least 3,000 
have fewer than 2,500. It is not neces­
sarily these small languages that are 
about to disappear. Navajo is consid­
ered endangered despite having 150,000 
speakers. What makes a language 
endangered is not just the number of 
speakers, but how old they are. If it is 
spoken by children it is relatively safe . 
The critically endangered languages 
are those that are only spoken by the 
elderly. according to Michael Krauss, 
director of the Alassk Native 
Language Center, in Fairbanks. 
Why do people reject the language of 
their parents? It begins with a crisis of 
confidence, when a small community 
finds itself alongside a larger, wealth­
ier society. says Nicholas Ostler, of 
Britain's Foundation for Endangered 
Languages, in Bath. 'People lose faith 
in their culture,' he says. 'When the 
next generation reaches their teens, 
they might not want to be induced into 
the old traditions.' 
The change is not always voluntary. 
Quite often, governments try to kill off 
a minority language by banning its use 
in public or discouraging its use in 
schools, all to promote national unity.
```

[Original question page](assets/83b16e8182f5361f45e95751d1a732c5c1e79e340ead0fe5244d2e2f88d48989.jpg)

<!-- Source: /api/assets/2b9a4461496778366c0df063e711063bfa455da36f2845dd908630dd6739c0a5.jpg; PDF page 44; full -->

```text
The former US policy of running 
Indian reservation schools in English, 
for example, effectively put languages 
such as Navajo on the danger list. But 
Salikoko Mufwene, who chairs the 
Linguistics Department at the 
University of Chicago , argues that the 
deadliest weapon is not government 
policy but economic globalisation. 
'Native Americans have not lost pride 
in their language, but they have had to 
adapt to socio-economic pressures,' he 
says. They cannot refuse to speak 
English if most commercial activity is 
in English.' But are languages worth 
saving? At the very least, there is a loss 
of data for the study of languages and 
their evolution, which relies on com­
parisons between languages, both 
living and dead . When an unwritten 
and unrecorded language disappears, 
it is lost to science. 
Language is also intimately bound 
up with culture, so it may be difficult to 
preserve one without the other. 'If a 
person shifts from Navajo to English, 
they lose something, ' Mufwene says. 
'Moreover, the loss of diversity may 
also deprive us of different ways of 
looking at the world,' says Pagel. There 
is mounting evidence that learning a 
language produces physiological 
changes in the brain. 'Your brain and 
mine are different from the brain of 
someone who speaks French, for 
instance, ' Pagel says , and this could 
affect our thoughts and perceptions. 
'The patterns and connections we 
make among various concepts may be 
structured by the linguistic habits of 
our community.' 
So despite linguists' best efforts, 
many languages will disappear over 
the next century. But a growing inter-
est in cultural identity may prevent the 
direst predictions from coming true. 
'The key to fostering diversity is for 
people to learn their ancestral tongue, 
as well as the dominant language,' says 
Doug Whalen , founder and president of 
the Endangered Language Fund in 
New Haven, Connecticut. 'Most of 
these languages will not survive 
without a large degree of bilingual­
ism,' he says. In New Zealand, classes 
for children have slowed the erosion 
of Maori and rekindled interest in 
the language. A similar approach in 
Hawaii has produced about 8,000 
new speakers of Polynesian lan­
guages in the past few years. In 
California, 'apprentice ' programmes 
have provided life support to several 
indigenous languages. Volunteer 
'apprentices' pair up with one of the 
last living speakers of a Native 
American tongue to learn a traditional 
skill such as basket weaving, with 
instruction exclusively in the endan ­
gered language. After about 300 hours 
of training they are generally suffi­
ciently fluent to transmit the language 
to the next generation. But Mufwene 
says that preventing a language dying 
out is not the same as giving it new life 
by using it every day. 'Preserving a lan­
guage is more like preserving fruits in 
a jar,' he says. 
However, preservation can bring a 
language back from the dead. There 
are examples of languages that have 
survived in written form and then been 
revived by later generations. But a 
written form is essential for this, so the 
mere possibility of revival has led 
many speakers of endangered lan­
guages to develop systems of writing 
where none existed before. 
43
```

[Original question page](assets/2b9a4461496778366c0df063e711063bfa455da36f2845dd908630dd6739c0a5.jpg)

<!-- Source: /api/assets/44f10f472dfae699e29f962c2adc43780ead6a321372612b10e13c4b9b3c9e62.jpg; PDF page 45; full -->

```text
Questions 1-4 
Complete the summary below. 
Choose NO MORE THAN TWO WORDS from the passage for each answer. 
Write your answers in boxes 1-4 on your answer sheet. 
There are currently approximately 6,800 languages in the world. This great variety of 
languages came about largely as a result of geographical (1) __________ But in today's world, 
factors such as government initiatives and 2 ...... are contributing to a huge decrease in the 
number of languages. One factor which may help to ensure that some endangered languages 
do not die out completely is people's increasing appreciation of their 3 ....... This has been 
encouraged through programmes of language classes for children and through 'apprentice' 
schemes. in which the endangered language is used as the medium of instruction to teach 
people a 4 .. ..... Some speakers of endangered languages have even produced writing 
systems in order to help secure the survival of their mother tongue. 
Questions 5-9 
Look at the following statements (Questions 5-9) and the list of people in the box below. 
Match each statement with the correct person A-E. 
Write the appropriate letter A-E in boxes 5-9 on your answer sheet. 
NB You may use any letter more than once. 
5 Endangered languages cannot be saved unless people learn to speak more than one 
language. 
6 Saving languages from extinction is not in itself a satisfactory goal. 
7 The way we think may be determined by our language. 
8 Young people often reject the established way of life in their community. 
9 A change of language may mean a loss of traditional culture. 
44 
A Michael Krauss 
B Salikoko Mufwene 
C Nicholas Ostler 
D Mark Pagel 
E Doug Whalen
```

[Original question page](assets/44f10f472dfae699e29f962c2adc43780ead6a321372612b10e13c4b9b3c9e62.jpg)

<!-- Source: /api/assets/2f5413edeac3d4bd96849ce5ae923ffbe2d88f333ea946e9c2255082e763601b.jpg; PDF page 46; full -->

```text
Questions 10-13 
Do the following statements agree with the views of the writer in Reading Passage 1? 
In boxes 10-13 on your answer sheet write 
YES if the statement agrees with the views of the writer 
NO if the statement contradicts the views of the writer 
NOT GIVEN if it is impossible to say what the writer thinks about this 
10 The Navajo language will die out because it currently has too few speakers. 
11 A large number of native speakers fail to guarantee the survival of a language. 
12 National governments could do more to protect endangered languages. 
13 The loss of linguistic diversity is inevitable. 
45
```

[Original question page](assets/2f5413edeac3d4bd96849ce5ae923ffbe2d88f333ea946e9c2255082e763601b.jpg)

<!-- Source: /api/assets/b1705def99509ff6c1dbec1d1bcb0b93215dbc39eed6a872fdf93f0c960ba754.jpg; PDF page 47; full -->

```text
READING PASSAGE 2



You should spend about 20 minutes on Questions 14-26 which are based on Reading Passage 2

below.



ALTERNATIVE MEDICINE IN AUSTRALIA



The first students to study alternative medicine at university level in Australia

began their four-year, full-time course at the University of Technology, Sydney,

in early 1994. Their course covered, among other therapies, acupuncture. The

theory they learnt is based on the traditional Chinese explanation of this ancient

healing art: that it can regulate the flow of ‘Qi’ or energy through pathways in

the body. This course reflects how far some alternative therapies have come in

their struggle for acceptance by the medical establishment.



Australia has been unusual in the Western world in having a very conservative

attitude to natural or alternative therapies, according to Dr Paul Laver, a lecturer

in Public Health at the University of Sydney. ‘We've had a tradition of doctors

being fairly powerful and I guess they are pretty loath to allow any pretenders to

their position to come into it.’ In many other industrialised countries, orthodox

and alternative medicine have worked ‘hand in glove’ for years. In Europe, only

orthodox doctors can prescribe herbal medicine. In Germany, plant remedies

account for 10% of the national turnover of pharmaceuticals. Americans made

more visits to alternative therapists than to orthodox doctors in 1990, and each

year they spend about $US12 billion on therapies that have not been scientifically

tested.



Disenchantment with orthodox medicine has seen the popularity of alternative

therapies in Australia climb steadily during the past 20 years. In a 1983 national

health survey, 1.9% of people said they had contacted a chiropractor, naturopath,

osteopath, acupuncturist or herbalist in the two weeks prior to the survey. By 1990,

this figure had risen to 2.6% of the population. The 550,000 consultations with

alternative therapists reported in the 1990 survey represented about an eighth of

the total number of consultations with medically qualified personnel covered by

the survey, according to Dr Laver and colleagues writing in the Australian Journal

of Public Health in 1993. ‘A better educated and less accepting public has become



46
```

[Original question page](assets/b1705def99509ff6c1dbec1d1bcb0b93215dbc39eed6a872fdf93f0c960ba754.jpg)

<!-- Source: /api/assets/644910b93ee18b24a015c32bfa6db1eed05336e24e15f6be99cbf4f72bf0a450.jpg; PDF page 48; full -->

```text
disillusioned with the experts in general, and increasingly sceptical about science

and empirically based knowledge,’ they said. ‘The high standing of professionals,

including doctors, has been eroded as a consequence.’



Rather than resisting or criticising this trend, increasing numbers of Australian

doctors, particularly younger ones, are forming group practices with alternative

therapists or taking courses themselves, particularly in acupuncture and herbalism. Part of the incentive was financial, Dr Laver said. ‘The bottom line is that most

general practitioners are business people. If they see potential clientele going elsewhere, they might want to be able to offer a similar service.’



In 1993, Dr Laver and his colleagues published a survey of 289 Sydney people who

attended eight alternative therapists’ practices in Sydney. These practices offered a

wide range of alternative therapies from 25 therapists. Those surveyed had experienced chronic illnesses, for which orthodox medicine had been able to provide little

relief. They commented that they liked the holistic approach of their alternative

therapists and the friendly, concerned and detailed attention they had received. The

cold, impersonal manner of orthodox doctors featured in the survey. An increasing

exodus from their clinics, coupled with this and a number of other relevant surveys

carried out in Australia, all pointing to orthodox doctors’ inadequacies, have led

mainstream doctors themselves to begin to admit they could learn from the personal style of alternative therapists. Dr Patrick Store, President of the Royal College

of General Practitioners, concurs that orthodox doctors could learn a lot about

bedside manner and advising patients on preventative health from alternative therapists.



According to the Australian Journal of Public Health, 18% of patients visiting alternative therapists do so because they suffer from musculo-skeletal complaints; 12%

suffer from digestive problems, which is only 1% more than those suffering from

emotional problems. Those suffering from respiratory complaints represent 7% of

their patients, and candida sufferers represent an equal percentage. Headache sufferers and those complaining of general ill health represent 6% and 5% of patients

respectively, and a further 4% see therapists for general health maintenance.



The survey suggested that complementary medicine is probably a better term than

alternative medicine. Alternative medicine appears to be an adjunct, sought in

times of disenchantment when conventional medicine seems not to offer the

answer.



47
```

[Original question page](assets/644910b93ee18b24a015c32bfa6db1eed05336e24e15f6be99cbf4f72bf0a450.jpg)

<!-- Source: /api/assets/f5fc1deef2b628750ae617321f8035b4f356f023c6998a04ba432f6fd028edcd.jpg; PDF page 49; full -->

```text
Questions 14 and 15 
Choose the correct letter, A, B, C or D. 
Write your answers in boxes 14 and 15 on your answer sheet. 
14 Traditionally, how have Australian doctors differed from doctors in many Western 
countries? 
A They have worked closely with pharmaceutical companies. 
B They have often worked alongside other therapists. 
C They have been reluctant to accept alternative therapists. 
D They have regularly prescribed alternative remedies. 
15 In 1990, Americans 
A were prescribed more herbal medicines than in previous years. 
B consulted alternative therapists more often than doctors. 
C spent more on natural therapies than orthodox medicines. 
D made more complaints about doctors than in previous years. 
Questions 16-23 
Do the following statements agree with the views of the writer in Reading Passage 2? 
In boxes 16-23 on your answer sheet write 
YES if the statement agrees with the views of the writer 
NO if the statement contradicts the views of the writer 
NOT GIVEN if it is impossible to say what the writer thinks about this 
16 Australians have been turning to alternative therapies in increasing numbers over the 
past 20 years. 
17 Between 1983 and 1990 the numbers of patients visiting alternative therapists rose to 
include a further 8% of the population. 
18 The 1990 survey related to 550,000 consultations with alternative therapists. 
19 In the past, Australians had a higher opinion of doctors than they do today. 
20 Some Australian doctors are retraining in alternative therapies. 
21 Alternative therapists earn higher salaries than doctors. 
22 The 1993 Sydney survey involved 289 patients who visited alternative therapists for 
acupuncture treatment. 
23 All the patients in the 1993 Sydney survey had long-term medical complaints. 
48
```

[Original question page](assets/f5fc1deef2b628750ae617321f8035b4f356f023c6998a04ba432f6fd028edcd.jpg)

<!-- Source: /api/assets/19964e81b16fcc4bbc32609d7bd616638dec72759ac56831cb47c68b11f82e1f.jpg; PDF page 50; full -->

```text
Questions24–26
Complete the vertical axis on the table below. Choose NO MORE THAN THREE WORDS from Reading Passage2 for each answer. Write your answers in boxes24–26 on your answer sheet.
Medical complaints of patients visiting therapists
Use original horizontal bar chart with0–30% scale in5% increments.
Top to bottom labels: Other; Musculo-skeletal; Digestive; (24) __________; Respiratory; Candida; (25) __________; (26) __________; General health maintenance.
```

[Original question page](assets/19964e81b16fcc4bbc32609d7bd616638dec72759ac56831cb47c68b11f82e1f.jpg)

![Original figure](assets/19964e81b16fcc4bbc32609d7bd616638dec72759ac56831cb47c68b11f82e1f.jpg)

<!-- Source: /api/assets/571d44d88c2577ac9bcc9b2aa009a493179a3083484b699d309fb0252f0c9e5d.jpg; PDF page 51; full -->

```text
READING PASSAGE 3



You should spend about 20 minutes on Questions 27-40 which are based on Reading Passage 3

below.



PLAY IS A SERIOUS

BUSINESS



Does play help develop bigger, better brains?

Bryant Furlow investigates



A Playing is a serious business. Children engrossed in a make-believe world, fox cubs play-fighting or kittens teasing a ball of string aren’t just having fun. Play may look like a carefree and

exuberant way to pass the time before the hard work of adulthood comes along, but there’s

much more to it than that. For a start, play can even cost animals their lives. Eighty per cent

of deaths among juvenile fur seals occur because playing pups fail to spot predators approaching. It is also extremely expensive in terms of energy. Playful young animals use around two

or three per cent of their energy cavorting, and in children that figure can be closer to fifteen

per cent. ‘Even two or three per cent is huge,’ says John Byers of Idaho University. “You just

don’t find animals wasting energy like that,’ he adds. There must be a reason.



B But if play is not simply a developmental hiccup, as biologists once thought, why did it evolve?

The latest idea suggests that play has evolved to build big brains. In other words, playing

makes you intelligent. Playfulness, it seems, is common only among mammals, although a

few of the larger-brained birds also indulge. Animals at play often use unique signs — tailwagging in dogs, for example — to indicate that activity superficially resembling adult behaviour is not really in earnest. A popular explanation of play has been that it helps juveniles

develop the skills they will need to hunt, mate and socialise as adults. Another has been that

it allows young animals to get in shape for adult life by improving their respiratory endurance.

Both these ideas have been questioned in recent years.



C Take the exercise theory. If play evolved to build muscle or as a kind of endurance training,

then you would expect to see permanent benefits. But Byers points out that the benefits of

increased exercise disappear rapidly after training stops, so any improvement in endurance

resulting from juvenile play would be lost by adulthood. ‘If the function of play was to get

into shape,’ says Byers, ‘the optimum time for playing would depend on when it was most

advantageous for the young of a particular species to do so. But it doesn’t work like that.’

Across species, play tends to peak about halfway through the suckling stage and then decline.



D Then there’s the skills-training hypothesis. At first glance, playing animals do appear to be

practising the complex manoeuvres they will need in adulthood. But a closer inspection

reveals this interpretation as too simplistic. In one study, behavioural ecologist Tim Caro,

from the University of California, looked at the predatory play of kittens and their predatory



50
```

[Original question page](assets/571d44d88c2577ac9bcc9b2aa009a493179a3083484b699d309fb0252f0c9e5d.jpg)

<!-- Source: /api/assets/62b4d95649e6018be6115b4412342328e37fdd4c0cad3b9f06b931bfa427a22c.jpg; PDF page 52; full -->

```text
behaviour when they reached adulthood. He found that the way the cats played had no significant effect on their hunting prowess in later life.



E Earlier this year, Sergio Pellis of Lethbridge University, Canada, reported that there is a

strong positive link between brain size and playfulness among mammals in general.

Comparing measurements for fifteen orders of mammal, he and his team found larger brains

(for a given body size) are linked to greater playfulness. The converse was also found to be

true. Robert Barton of Durham University believes that, because large brains are more sensitive to developmental stimuli than smaller brains, they require more play to help mould

them for adulthood. ‘I concluded it’s to do with learning, and with the importance of environmental data to the brain during development,’ he says.



F According to Byers, the timing of the playful stage in young animals provides an important

clue to what’s going on. If you plot the amount of time a juvenile devotes to play each day

over the course of its development, you discover a pattern typically associated with a ‘sensitive period’ — a brief development window during which the brain can actually be modified

in ways that are not possible earlier or later in life. Think of the relative ease with which young

children — but not infants or adults — absorb language. Other researchers have found that play

in cats, rats and mice is at its most intense just as this ‘window of opportunity’ reaches its

peak.



G ‘People have not paid enough attention to the amount of the brain activated by play,’ says

Marc Bekoff from Colorado University. Bekoff studied coyote pups at play and found that

the kind of behaviour involved was markedly more variable and unpredictable than that of

adults. Such behaviour activates many different parts of the brain, he reasons. Bekoff likens

it to a behavioural kaleidoscope, with animals at play jumping rapidly between activities.

‘They use behaviour from a lot of different contexts — predation, aggression, reproduction,’

he says. ‘Their developing brain is getting all sorts of stimulation.’



H Not only is more of the brain involved in play than was suspected, but it also seems to activate higher cognitive processes. “There’s enormous cognitive involvement in play,’ says

Bekoff. He points out that play often involves complex assessments of playmates, ideas of reciprocity and the use of specialised signals and rules. He believes that play creates a brain that

has greater behavioural flexibility and improved potential for learning later in life. The idea

is backed up by the work of Stephen Siviy of Gettysburg College. Siviy studied how bouts of

play affected the brain’s levels of a particular chemical associated with the stimulation and

growth of nerve cells. He was surprised by the extent of the activation. ‘Play just lights everything up,’ he says. By allowing link-ups between brain areas that might not normally communicate with each other, play may enhance creativity.



I What might further experimentation suggest about the way children are raised in many societies today? We already know that rat pups denied the chance to play grow smaller brain components and fail to develop the ability to apply social rules when they interact with their peers.

With schooling beginning earlier and becoming increasingly exam-orientated, play is likely

to get even less of a look-in. Who knows what the result of that will be?



51
```

[Original question page](assets/62b4d95649e6018be6115b4412342328e37fdd4c0cad3b9f06b931bfa427a22c.jpg)

<!-- Source: /api/assets/9054cbfe7edbfc90c491606e854fcc441e5467f3a36023b4e95f248c112ca858.jpg; PDF page 53; full -->

```text
Questions 27-32 
Reading Passage 3 has nine paragraphs labelled A–I. 
Which paragraph contains the following information? 
Write the correct letter A–I in boxes 27-32 on your answer sheet. 
NB You may use any letter more than once. 
27 the way play causes unusual connections in the brain which are beneficial 
28 insights from recording how much time young animals spend playing 
29 a description of the physical hazards that can accompany play 
30 a description of the mental activities which are exercised and developed during play 
31 the possible effects that a reduction in play opportunities will have on humans 
32 the classes of animals for which play is important 
Questions 33-35 
Choose THREE letters A-F. 
Write your answers in boxes 33-35 on your answer sheet. 
The list below gives some ways of regarding play. 
Which THREE ways are mentioned by the writer of the text? 
A a rehearsal for later adult activities 
B a method animals use to prove themselves to their peer group 
C an activity intended to build up strength for adulthood 
D a means of communicating feelings 
E a defensive strategy 
F an activity assisting organ growth 
52
```

[Original question page](assets/9054cbfe7edbfc90c491606e854fcc441e5467f3a36023b4e95f248c112ca858.jpg)

<!-- Source: /api/assets/91a6f76f21c68dfa3a1cb0e4e885582feb970fef0b88b7bf7785176ac821b7c2.jpg; PDF page 54; full -->

```text
Questions 36-40 
Look at the following researchers (Questions 36-40) and the list of findings below. 
Match each researcher with the correct finding. 
Write the correct letter A-H in boxes 36-40 on your answer sheet. 
36 Robert Barton 
37 Marc Bekoff 
38 John Byers 
39 Sergio Pellis 
40 Stephen Siviy 
List of Findings 
A There is a link between a specific substance in the brain and playing. 
B Play provides input concerning physical surroundings . 
C Varieties of play can be matched to different stages of evolutionary 
history. 
D There is a tendency for mammals with smaller brains to play less. 
E Play is not a form of fitness training for the future . 
F Some species of larger-brained birds engage in play. 
G A wide range of activities are combined during play. 
H Play is a method of teaching survival techniques. 
53
```

[Original question page](assets/91a6f76f21c68dfa3a1cb0e4e885582feb970fef0b88b7bf7785176ac821b7c2.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/fe6ed3d7d13ca6d1b3877432bb64664c602c4196fe95b89c5da0b59e747711b5.jpg; PDF page 55; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below shows the demand for electricity in England during typical days in winter and summer. The pie chart shows how electricity is used in an average English home.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original table or chart is retained below.]
```

[Original question page](assets/fe6ed3d7d13ca6d1b3877432bb64664c602c4196fe95b89c5da0b59e747711b5.jpg)

![Original figure](assets/fe6ed3d7d13ca6d1b3877432bb64664c602c4196fe95b89c5da0b59e747711b5.jpg)

### Task 2

<!-- Source: /api/assets/d014d4f40ad5dc6fefdd498b84883f6137b649c1e7529838455a4d7921e2d198.jpg; PDF page 56; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Happiness is considered very important in life.

Why is it difficult to define?

What factors are important in achieving happiness?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/d014d4f40ad5dc6fefdd498b84883f6137b649c1e7529838455a4d7921e2d198.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/02001e0de28553b7dd15c2d42b303ed9d6d474f92a1721e17be9131a49c45757.jpg; PDF page 57; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Food and cooking 
• What kinds of food do you like to eat? 
• What kind of new food would you like to try? [Why?] 
• Do you like cooking? [Why/Why not?] 
• What was the last meal you cooked? 
• Do you prefer home-cooked food or food from restaurants? [Why?] 
PART 2 
Describe an interest or hobby that you enjoy. 
You should say: 
how you became interested in it 
how long you have been doing it 
why you enjoy it 
and explain what benefits you get from this interest or hobby. 
You will have to talk about 
the topic for one to two 
minutes. 
You have one minute to 
think about what you're 
going to say. 
You can make some notes 
to help you if you wish. 

PART 3 
Discussion topics: 
The social benefits of hobbies 
Example questions: 
Do you think having a hobby is good for people's social life? In what way? 
Are there any negative effects of a person spending too much time on their hobby? What are 
they? 
Why do you think people need to have an interest or hobby? 
Leisure time 
Example questions: 
In your country , how much time do people spend on work and how much time on leisure? Is 
this a good balance, do you think? 
Would you say the amount of free time has changed much in the last fifty years? 
Do you think people will have more or less free time in the future? Why? 
56
```

[Original question page](assets/02001e0de28553b7dd15c2d42b303ed9d6d474f92a1721e17be9131a49c45757.jpg)

### Part 2

<!-- Source: /api/assets/02001e0de28553b7dd15c2d42b303ed9d6d474f92a1721e17be9131a49c45757.jpg; PDF page 57; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Food and cooking 
• What kinds of food do you like to eat? 
• What kind of new food would you like to try? [Why?] 
• Do you like cooking? [Why/Why not?] 
• What was the last meal you cooked? 
• Do you prefer home-cooked food or food from restaurants? [Why?] 
PART 2 
Describe an interest or hobby that you enjoy. 
You should say: 
how you became interested in it 
how long you have been doing it 
why you enjoy it 
and explain what benefits you get from this interest or hobby. 
You will have to talk about 
the topic for one to two 
minutes. 
You have one minute to 
think about what you're 
going to say. 
You can make some notes 
to help you if you wish. 

PART 3 
Discussion topics: 
The social benefits of hobbies 
Example questions: 
Do you think having a hobby is good for people's social life? In what way? 
Are there any negative effects of a person spending too much time on their hobby? What are 
they? 
Why do you think people need to have an interest or hobby? 
Leisure time 
Example questions: 
In your country , how much time do people spend on work and how much time on leisure? Is 
this a good balance, do you think? 
Would you say the amount of free time has changed much in the last fifty years? 
Do you think people will have more or less free time in the future? Why? 
56
```

[Original question page](assets/02001e0de28553b7dd15c2d42b303ed9d6d474f92a1721e17be9131a49c45757.jpg)

### Part 3

<!-- Source: /api/assets/02001e0de28553b7dd15c2d42b303ed9d6d474f92a1721e17be9131a49c45757.jpg; PDF page 57; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Food and cooking 
• What kinds of food do you like to eat? 
• What kind of new food would you like to try? [Why?] 
• Do you like cooking? [Why/Why not?] 
• What was the last meal you cooked? 
• Do you prefer home-cooked food or food from restaurants? [Why?] 
PART 2 
Describe an interest or hobby that you enjoy. 
You should say: 
how you became interested in it 
how long you have been doing it 
why you enjoy it 
and explain what benefits you get from this interest or hobby. 
You will have to talk about 
the topic for one to two 
minutes. 
You have one minute to 
think about what you're 
going to say. 
You can make some notes 
to help you if you wish. 

PART 3 
Discussion topics: 
The social benefits of hobbies 
Example questions: 
Do you think having a hobby is good for people's social life? In what way? 
Are there any negative effects of a person spending too much time on their hobby? What are 
they? 
Why do you think people need to have an interest or hobby? 
Leisure time 
Example questions: 
In your country , how much time do people spend on work and how much time on leisure? Is 
this a good balance, do you think? 
Would you say the amount of free time has changed much in the last fifty years? 
Do you think people will have more or less free time in the future? Why? 
56
```

[Original question page](assets/02001e0de28553b7dd15c2d42b303ed9d6d474f92a1721e17be9131a49c45757.jpg)
