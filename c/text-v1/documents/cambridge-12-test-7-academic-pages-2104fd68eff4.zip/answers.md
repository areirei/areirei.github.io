# 剑雅 12 · Test 7 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 121

TEST 7 LISTENING
1 travel/travel(l)ing
2 history
3 study
4 teenagers
5 kitchen
6 crime
7 appointment/booking
8 sugar
9 stamps
10 parking
11 D
12 E
13 A
14 C
15 C
16 B
17 A
18 stress
19 weight
20 families
21 C
22 E
23 H
24 B
25 A
26 F
27 A
28 C
29 B
30 B
31 insects
32 behaviour/behavior
33 father
34 complex/complicated
35 reproduction/breeding
36 control
37 duck(s)
38 language
39 food
40 cost(s)/price(s)/bill(s)
11&12 IN EITHER ORDER: D,E
13&14 IN EITHER ORDER: A,C
If you score: 0–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. travel / traveling / travelling

2. history

3. study

4. teenagers

5. kitchen

6. crime

7. appointment / booking

8. sugar

9. stamps

10. parking

### Part 2 · source page 121

TEST 7 LISTENING
1 travel/travel(l)ing
2 history
3 study
4 teenagers
5 kitchen
6 crime
7 appointment/booking
8 sugar
9 stamps
10 parking
11 D
12 E
13 A
14 C
15 C
16 B
17 A
18 stress
19 weight
20 families
21 C
22 E
23 H
24 B
25 A
26 F
27 A
28 C
29 B
30 B
31 insects
32 behaviour/behavior
33 father
34 complex/complicated
35 reproduction/breeding
36 control
37 duck(s)
38 language
39 food
40 cost(s)/price(s)/bill(s)
11&12 IN EITHER ORDER: D,E
13&14 IN EITHER ORDER: A,C
If you score: 0–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. D / E

12. D / E

13. A / C

14. A / C

15. C

16. B

17. A

18. stress

19. weight

20. families

### Part 3 · source page 121

TEST 7 LISTENING
1 travel/travel(l)ing
2 history
3 study
4 teenagers
5 kitchen
6 crime
7 appointment/booking
8 sugar
9 stamps
10 parking
11 D
12 E
13 A
14 C
15 C
16 B
17 A
18 stress
19 weight
20 families
21 C
22 E
23 H
24 B
25 A
26 F
27 A
28 C
29 B
30 B
31 insects
32 behaviour/behavior
33 father
34 complex/complicated
35 reproduction/breeding
36 control
37 duck(s)
38 language
39 food
40 cost(s)/price(s)/bill(s)
11&12 IN EITHER ORDER: D,E
13&14 IN EITHER ORDER: A,C
If you score: 0–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. C

22. E

23. H

24. B

25. A

26. F

27. A

28. C

29. B

30. B

### Part 4 · source page 121

TEST 7 LISTENING
1 travel/travel(l)ing
2 history
3 study
4 teenagers
5 kitchen
6 crime
7 appointment/booking
8 sugar
9 stamps
10 parking
11 D
12 E
13 A
14 C
15 C
16 B
17 A
18 stress
19 weight
20 families
21 C
22 E
23 H
24 B
25 A
26 F
27 A
28 C
29 B
30 B
31 insects
32 behaviour/behavior
33 father
34 complex/complicated
35 reproduction/breeding
36 control
37 duck(s)
38 language
39 food
40 cost(s)/price(s)/bill(s)
11&12 IN EITHER ORDER: D,E
13&14 IN EITHER ORDER: A,C
If you score: 0–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. insects

32. behaviour / behavior

33. father

34. complex / complicated

35. reproduction / breeding

36. control

37. duck / ducks

38. language

39. food

40. cost / costs / price / prices / bill / bills

## A 类阅读

### Academic Reading · source page 122

TEST 7 READING
1 v
2 iii
3 viii
4 i
5 iv
6 vi
7 ii
8 pirates
9 food
10 oil
11 settlers
12 species
13 eggs
14 D
15 C
16 F
17 G
18 D
19 B
20 vaccinations
21 antibiotics
22 mosquito(e)s
23 factories
24 forests
25 Polio
26 mountain
27 dopamine
28 pleasure
29 caudate
30 anticipatory phase
31 food
32 B
33 C
34 A
35 B
36 D
37 F
38 B
39 E
40 C
If you score: 0–14 unlikely;15–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. v

2. iii

3. viii

4. i

5. iv

6. vi

7. ii

8. pirates

9. food

10. oil

11. settlers

12. species

13. eggs

14. D

15. C

16. F

17. G

18. D

19. B

20. vaccinations

21. antibiotics

22. mosquitos / mosquitoes

23. factories

24. forests

25. Polio

26. mountain

27. dopamine

28. pleasure

29. caudate

30. anticipatory phase

31. food

32. B

33. C

34. A

35. B

36. D

37. F

38. B

39. E

40. C

## A 类写作

### Writing material: c12-t7-w-1

Three separate years2003/2006/2013; percentages by frequency, approximate unlabelled bar readings: every day4/3/3; several times a week17/20/16; once a week31/33/28; once or twice a month30/25/33; a few times a year13/15/15; never5/4/4. Weekly most common2003/2006, monthly most common2013. Every day and never smallest groups throughout. Several-times-weekly peaks2006. Category once OR twice a month is not twice weekly. No number of meals, sales, obesity data or other intermediate years supplied.



### Writing material: c12-t7-w-2

Discuss investment in new intercity high-speed rail versus improving existing public transport and give own opinion. Preserve new/existing and between-cities distinctions.



## 口语
