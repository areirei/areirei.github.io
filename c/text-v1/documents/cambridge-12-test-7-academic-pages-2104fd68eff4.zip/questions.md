# 剑雅 12 · Test 7

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/f652dd26fb1e10fc7e638666ebc04d58d2f1b63e739ea0eaeadc5874559ec40e.jpg; PDF page 54; full -->

```text
Test 7
LISTENING
SECTION 1 Questions 1-10
Complete the notes below.
Write ONE WORD ONLY for each answer.
PUBLIC LIBRARY
Example
The library re-opened last month [example]
The library now has
• a seating area with magazines
• an expanded section for books on 1 ................................... ..
• a new section on local 2 .................................... .
• a community room for meetings (also possible to 3 ..................................... there)
• a new section of books for 4 .................................... .
For younger children
• the next Science Club meeting: experiments using things from your
5 .................................... .
- . Reading Challenge: read six books during the holidays
For adults
• this Friday: a local author talks about a novel based on a real 6 ................................... ..
• IT support is available on Tuesdays - no 7 ..................................... is necessary
• free check of blood 8 ..................................... and cholesterol levels (over 60s only)
Other information
• the library shop sells wall-charts, cards and 9 .................................... .
• evenings and weekends: free 10 ..................................... is available
53
```

[Original question page](assets/f652dd26fb1e10fc7e638666ebc04d58d2f1b63e739ea0eaeadc5874559ec40e.jpg)

### Part 2

<!-- Source: /api/assets/14c836bd81b662d493cfa5d8cc4fb4c1a35883d8548e23cfab1a41cf2e1f4eb6.jpg; PDF page 55; full -->

```text
Test 7
SECTION 2 Questions 11-20
Questions 11 and 12
Choose TWO letters, A-E.
Which TWO age groups are taking increasing numbers of holidays with BC Travel?
A 16-30 years
B 31-42 years
C 43-54 years
D 55-64 years
E over 65 years
Questions 13 and 14
Choose TWO letters, A-E.
Which TWO are the main reasons given for the popularity of activity holidays?
A Clients make new friends.
B Clients learn a useful skill.
C Clients learn about a different culture.
D Clients are excited by the risk involved.
E Clients find them good value for money.
Questions 15-17
Choose the correct letter, A, B or C.
15 How does BC Travel plan to expand the painting holidays?
A by adding to the number of locations
B by increasing the range of levels
C by employing more teachers
16 Why are BC Travel's cooking holidays unusual?
A They only use organic foods.
B They have an international focus.
C They mainly involve vegetarian dishes.
17 What does the speaker say about the photography holidays?
54
A Clients receive individual tuition.
B The tutors are also trained guides.
C Advice is given on selling photographs.
```

[Original question page](assets/14c836bd81b662d493cfa5d8cc4fb4c1a35883d8548e23cfab1a41cf2e1f4eb6.jpg)

<!-- Source: /api/assets/47fa0c39db415a81876aa0db4c89a5d99cbe9a0288a54adb30b7a7379da9c791.jpg; PDF page 56; full -->

```text
Questions 18–20
Complete the table below. Write ONE WORD ONLY for each answer.
Fitness Holidays
| Location | Main focus | Other comments |
| --- | --- | --- |
| Ireland and Italy | general fitness | personally designed programme; also reduces (18) __________ |
| Greece | (19) __________ control | includes exercise on the beach |
| Morocco | mountain biking | wide variety of levels; one holiday that is specially designed for (20) __________ |
```

[Original question page](assets/47fa0c39db415a81876aa0db4c89a5d99cbe9a0288a54adb30b7a7379da9c791.jpg)

### Part 3

<!-- Source: /api/assets/6e93a3599bd6733130343d4f575f68dc95eadac96eece625d1e9612ad7223d43.jpg; PDF page 57; full -->

```text
Test 7
SECTION 3
Questions 21-26
Questions 21-30
Complete the flow-chart below.
Choose SIX answers from the box and write the correct letter, A-H, next to
Questions 21-26.
A patterns B names C sources D questions
E employees F solutions G headings H officials
STAGES IN DOING A TOURISM CASE STUDY
RESEARCH
Locate and read relevant articles, noting key information and also 21 ..................... ......... ...... . .
Identify a problem or need
Select interviewees - these may be site 22 ............ .......... ...... .......... , visitors or
city 23 ...................... ...... .... ..... .
Prepare and carry out interviews. If possible, collect statistics.
Check whether 24 ..................... ................. of interviewees can be used
↓
ANALYSIS
Select relevant information and try to identify 25 ................ ............ ........ . .
Decide on the best form of visuals
↓
WRITING THE CASE STUDY
Give some background before writing the main sections
Do NOT end with 26 ........ ............................ ..
56
```

[Original question page](assets/6e93a3599bd6733130343d4f575f68dc95eadac96eece625d1e9612ad7223d43.jpg)

<!-- Source: /api/assets/5df3f8adb47f8caabc5080b49f75b6edd70988d1387be782fef6af7191bbe871.jpg; PDF page 58; full -->

```text
Listening
Questions 27-30
Choose the correct letter, A, B or C.
The Horton Castle site
27 Natalie and Dave agree one reason why so few people visit Horton Castle is that
A the publicity is poor.
B it is difficult to get to.
C there is little there of interest.
28 Natalie and Dave agree that the greatest problem with a visitor centre could be
A covering the investment costs.
B finding a big enough space for it.
C dealing with planning restrictions.
29 What does Dave say about conditions in the town of Horton?
A There is a lot of unemployment.
B There are few people of working age.
C There are opportunities for skilled workers.
30 According to Natalie, one way to prevent damage to the castle site would be to
A insist visitors have a guide.
B make visitors keep to the paths.
C limit visitor numbers.
57
```

[Original question page](assets/5df3f8adb47f8caabc5080b49f75b6edd70988d1387be782fef6af7191bbe871.jpg)

### Part 4

<!-- Source: /api/assets/88678d1ee0410dcb2cc1263cdfc1999b1e1ccf38aaeb9c545f2bf5a89dbd9d98.jpg; PDF page 59; full -->

```text
Test 7
SECTION 4 Questions 31-40
Complete the notes below.
Write ONE WORD ONLY for each answer.
58
The effects of environmental change on birds
Mercury (Hg)
• Highly toxic
• Released into the atmosphere from coal
• In water it may be consumed by fish
• It has also recently been found to affect birds which feed on 31 .......................... ..
Research on effects of mercury on birds
• Claire Varian-Ramos is investigating:
the effects on birds' 32 ............................ or mental processes, e.g. memory
the effects on bird song (usually learned from a bird's 33 ............................ )
• Findings:
songs learned by birds exposed to mercury are less 34 .......................... ..
this may have a negative effect on birds' 35 ........................... .
• Lab-based studies:
allow more 36 ............................ for the experimenter
Implications for humans
• Migrating birds such as 37 ............................ containing mercury may be eaten by
humans
• Mercury also causes problems in learning 38 .......................... ..
• Mercury in a mother's body from 39 ............................ may affect the unborn child
• New regulations for mercury emissions will affect everyone's energy
40 .......................... ..
```

[Original question page](assets/88678d1ee0410dcb2cc1263cdfc1999b1e1ccf38aaeb9c545f2bf5a89dbd9d98.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/1c8abc59b014b54d055454864953bb7dfe07a770a1b10ba4b34079da258455fe.jpg; PDF page 60; full -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1–13, which are based on Reading Passage 1.
Questions 1–7
Reading Passage 1 has seven paragraphs, A–G.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i–viii, in boxes 1–7 on your answer sheet.
List of Headings
i The importance of getting the timing right
ii Young meets old
iii Developments to the disadvantage of tortoise populations
iv Planning a bigger idea
v Tortoises populate the islands
vi Carrying out a carefully prepared operation
vii Looking for a home for the islands’ tortoises
viii The start of the conservation project
1 Paragraph A
2 Paragraph B
3 Paragraph C
4 Paragraph D
5 Paragraph E
6 Paragraph F
7 Paragraph G
```

[Original question page](assets/1c8abc59b014b54d055454864953bb7dfe07a770a1b10ba4b34079da258455fe.jpg)

<!-- Source: /api/assets/0fb8ccb70e57cd1b7a80aa1b8a5b3df45cdc7284e5809db6bfc965ee7f1eebdf.jpg; PDF page 61; full -->

```text
Test 7
Flying tortoises
An airborne reintroduction programme has helped conservationists take
significant steps to protect the endangered Galapagos tortoise.
A Forests of spiny cacti cover much of the uneven lava plains that separate the
interior of the Galapagos island of Isabela from the Pacific Ocean. With its
five distinct volcanoes, the island resembles a lunar landscape. Only the thick
vegetation at the skirt of the often cloud-covered peak of Sierra Negra offers respite
from the barren terrain below. This inhospitable environment is home to the giant
Galapagos tortoise. Some time after the Galapagos's birth, around five million
years ago, the islands were colonised by one or more tortoises from mainland
South America. As these ancestral tortoises settled on the individual islands, the
different populations adapted to their unique environments, giving rise to at least
14 different subspecies. Island life agreed with them. In the absence of significant
predators, they grew to become the largest and longest-living tortoises on the
planet, weighing more than 400 kilograms, occasionally exceeding 1.8 metres in
length and living for more than a century.
B Before human arrival, the archipelago's tortoises numbered in the hundreds
of thousands. From the 17th century onwards, pirates took a few on board for
food, but the arrival of whaling ships in the 1790s saw this exploitation grow
exponentially. Relatively immobile and capable of surviving for months without food
or water, the tortoises were taken on board these ships to act as food supplies
during long ocean passages. Sometimes, their bodies were processed into high­
grade oil. In total, an estimated 200,000 animals were taken from the archipelago
before the 20th century. This historical exploitation was then exacerbated when
settlers came to the islands. They hunted the tortoises and destroyed their habitat
to clear land for agriculture. They also introduced alien species - ranging from
cattle, pigs, goats, rats and dogs to plants and ants - that either prey on the eggs
and young tortoises or damage or destroy their habitat.
C Today, only 11 of the original subspecies survive and of these, several are highly
endangered. In 1989, work began on a tortoise-breeding centre just outside the
town of Puerto Villamil on Isabela, dedicated to protecting the island's tortoise
populations. The centre's captive-breeding programme proved to be extremely
successful, and it eventually had to deal with an overpopulation problem.
D The problem was also a pressing one. Captive-bred tortoises can't be reintroduced
into the wild until they're at least five years old and weigh at least 4.5 kilograms,
at which point their size and weight - and their hardened shells - are sufficient
to protect them from predators. But if people wait too long after that point, the
tortoises eventually become too large to transport.
```

[Original question page](assets/0fb8ccb70e57cd1b7a80aa1b8a5b3df45cdc7284e5809db6bfc965ee7f1eebdf.jpg)

<!-- Source: /api/assets/e4d1c4c847c7634b2a4407b90d76a2ad9ff25931c0cf6a1b72bd422f828fd71a.jpg; PDF page 62; full -->

```text
Reading
E For years, repatriation efforts were carried out in small numbers, with the tortoises
carried on the backs of men over weeks of long, treacherous hikes along narrow
trails. But in November 2010, the environmentalist and Galapagos National Park
liaison officer Godfrey Merlin, a visiting private motor yacht captain and a helicopter
pilot gathered around a table in a small cafe in Puerto Ayora on the island of Santa
Cruz to work out more ambitious reintroduction. The aim was to use a helicopter
to move 300 of the breeding centre's tortoises to various locations close to Sierra
Negra.
F This unprecedented effort was made possible by the owners of the 67-metre
yacht White Cloud, who provided the Galapagos National Park with free use of
their helicopter and its experienced pilot, as well as the logistical support of the
yacht, its captain and crew. Originally an air ambulance, the yacht's helicopter
has a rear double door and a large internal space that's well suited for cargo,
so a custom crate was designed to hold up to 33 tortoises with a total weight of
about 150 kilograms. This weight, together with that of the fuel, pilot and four crew,
approached the helicopter's maximum payload, and there were times when it was
clearly right on the edge of the helicopter's capabilities. During a period of three
days, a group of volunteers from the breeding centre worked around the clock to
prepare the young tortoises for transport. Meanwhile, park wardens, dropped off
ahead of time in remote locations, cleared landing sites within the thick brush, cacti
and lava rocks.
G Upon their release, the juvenile tortoises quickly spread out over their ancestral
territory, investigating their new surroundings and feeding on the vegetation.
Eventually, one tiny tortoise came across a fully grown giant who had been
lumbering around the island for around a hundred years. The two stood side by
side, a powerful symbol of the regeneration of an ancient species.
61
```

[Original question page](assets/e4d1c4c847c7634b2a4407b90d76a2ad9ff25931c0cf6a1b72bd422f828fd71a.jpg)

<!-- Source: /api/assets/ff427ee4ff638a37547a7b5ad414eb198ba7caf59bf5dec7e238e90a4ddbb151.jpg; PDF page 63; full -->

```text
Test 7
Questions 8-13
Complete the notes below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 8-13 on your answer sheet.
The decline of the Galapagos tortoise
• Originally from mainland South America
• Numbers on Galapagos islands increased, due to lack of predators
• 17th century: small numbers taken onto ships used by 8 .......................................... .
• 1790s: very large numbers taken onto whaling ships, kept for 9 ........................................... ,
and also used to produce 10 .......................................... .
• Hunted by 11 ........................... ..... ............ on the islands.
• Habitat destruction: for the establishment of agriculture and by various
12 ........................................... not native to the islands, which also fed on baby tortoises and
tortoises' 13 .......................................... .
62
```

[Original question page](assets/ff427ee4ff638a37547a7b5ad414eb198ba7caf59bf5dec7e238e90a4ddbb151.jpg)

<!-- Source: /api/assets/bb1bb7f49831e981b3c93787f92edea88b0588d9a497f2726268c00f1610bfff.jpg; PDF page 64; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2.
The Intersection of Health Sciences and Geography
A While many diseases that affect humans have been eradicated due to
improvements in vaccinations and the availability of healthcare, there are still areas
around the world where certain health issues are more prevalent. In a world that is
far more globalised than ever before, people come into contact with one another
through travel and living closer and closer to each other. As a result, super-viruses
and other infections resistant to antibiotics are becoming more and more common.
B Geography can often play a very large role in the health concerns of certain
populations. For instance, depending on where you live, you will not have the same
health concerns as someone who lives in a different geographical region. Perhaps
one of the most obvious examples of this idea is malaria-prone areas, which are
usually tropical regions that foster a warm and damp environment in which the
mosquitos that can give people this disease can grow. Malaria is much less of a
problem in high-altitude deserts, for instance.
C In some countries, geographical factors influence the health and well-being of
the population in very obvious ways. In many large cities, the wind is not strong
enough to clear the air of the massive amounts of smog and pollution that cause
asthma, lung problems, eyesight issues and more in the people who live there. Part
of the problem is, of course, the massive number of cars being driven, in addition
to factories that run on coal power. The rapid industrialisation of some countries in
recent years has also led to the cutting down of forests to allow for the expansion of
big cities, which makes it even harder to fight the pollution with the fresh air that is
produced by plants.
D It is in situations like these that the field of health geography comes into its own. It
is an increasingly important area of study in a world where diseases like polio are
re-emerging, respiratory diseases continue to spread, and malaria-prone areas
are still fighting to find a better cure. Health geography is the combination of, on
the one hand, knowledge regarding geography and methods used to analyse and
interpret geographical information, and on the other, the study of health, diseases
and healthcare practices around the world. The aim of this hybrid science is to
create solutions for common geography-based health problems. While people will
always be prone to illness, the study of how geography affects our health could
lead to the eradication of certain illnesses, and the prevention of others in the
future. By understanding why and how we get sick, we can change the way we
treat illness and disease specific to certain geographical locations.
63
```

[Original question page](assets/bb1bb7f49831e981b3c93787f92edea88b0588d9a497f2726268c00f1610bfff.jpg)

<!-- Source: /api/assets/bdb70a309ce2aa84f46241ed36ecf39056d6517f47f0adb6a4346e34479bcb60.jpg; PDF page 65; full -->

```text
Test 7
E The geography of disease and ill health analyses the frequency with which certain
diseases appear in different parts of the world, and overlays the data with the
geography of the region, to see if there could be a correlation between the two.
Health geographers also study factors that could make certain individuals or a
population more likely to be taken ill with a specific health concern or disease, as
compared with the population of another area. Health geographers in this field
are usually trained as healthcare workers, and have an understanding of basic
epidemiology as it relates to the spread of diseases among the population.
F Researchers study the interactions between humans and their environment that
could lead to illness (such as asthma in places with high levels of pollution) and
work to create a clear way of categorising illnesses, diseases and epidemics into
local and global scales. Health geographers can map the spread of illnesses and
attempt to identify the reasons behind an increase or decrease in illnesses, as
they work to find a way to halt the further spread or re-emergence of diseases in
vulnerable populations.
G The second subcategory of health geography is the geography of healthcare
provision. This group studies the availability (or lack thereof) of healthcare
resources to individuals and populations around the world. In both developed and
developing nations there is often a very large discrepancy between the options
available to people in different social classes, income brackets, and levels of
education. Individuals working in the area of the geography of healthcare provision
attempt to assess the levels of healthcare in the area (for instance, it may be very
difficult for people to get medical attention because there is a mountain between
their village and the nearest hospital). These researchers are on the frontline of
making recommendations regarding policy to international organisations, local
government bodies and others.
H The field of health geography is often overlooked, but it constitutes a huge area
of need in the fields of geography and healthcare. If we can understand how
geography affects our health no matter where in the world we are located, we can
better treat disease, prevent illness, and keep people safe and well.
64
```

[Original question page](assets/bdb70a309ce2aa84f46241ed36ecf39056d6517f47f0adb6a4346e34479bcb60.jpg)

<!-- Source: /api/assets/7797853a43d666ea3b84a64fe9b211fcd1a601a76805f1ae1c4464d3500f080c.jpg; PDF page 66; full -->

```text
Reading
Questions 14-19
Reading Passage 2 has eight sections, A-H.
Which paragraph contains the following information?
Write the correct letter, A-H, in boxes 14-19 on your answer sheet.
NB You may use any letter more than once.
14 an acceptance that not all diseases can be totally eliminated
15 examples of physical conditions caused by human behaviour
16 a reference to classifying diseases on the basis of how far they extend
geographically
17 reasons why the level of access to healthcare can vary within a country
18 a description of health geography as a mixture of different academic fields
19 a description of the type of area where a particular illness is rare
Questions 20–26
Complete the sentences below.
Choose ONE WORD ONLY from the passage for each answer.
20 Certain diseases have disappeared, thanks to better ........................................... and
healthcare.
21 Because there is more contact between people, ........................................... are losing their
usefulness.
22 Disease-causing ........................................... are most likely to be found in hot, damp regions.
23 One cause of pollution is ........................................... that burn a particular fuel.
24 The growth of cities often has an impact on nearby ........................................... .
25 ........................................... is one disease that is growing after having been eradicated.
26 A physical barrier such as a ........................................... can prevent people from reaching
a hospital.
65
```

[Original question page](assets/7797853a43d666ea3b84a64fe9b211fcd1a601a76805f1ae1c4464d3500f080c.jpg)

<!-- Source: /api/assets/17dd9c9cb6327626c9ba4944c95c15d6e3f3b885669d32fbaaf62b4ec4185abd.jpg; PDF page 67; full -->

```text
Test 7
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3.
Music and the emotions
Neuroscientist Jonah Lehrer considers the emotional power of music
Why does music make us feel? On the one hand, music is a purely abstract art form,
devoid of language or explicit ideas. And yet, even though music says little, it still
manages to touch us deeply. When listening to our favourite songs, our body betrays all
the symptoms of emotional arousal. The pupils in our eyes dilate, our pulse and blood
pressure rise, the electrical conductance of our skin is lowered, and the cerebellum, a
brain region associated with bodily movement, becomes strangely active. Blood is even
re-directed to the muscles in our legs. In other words, sound stirs us at our biological
roots.
A recent paper in Nature Neuroscience by a research team in Montreal, Canada, marks
an important step in revealing the precise underpinnings of 'the potent pleasurable
stimulus' that is music. Although the study involves plenty of fancy technology, including
functional magnetic resonance imaging (fMRI) and ligand-based positron emission
tomography (PET) scanning, the experiment itself was rather straightforward. After
screening 217 individuals who responded to advertisements requesting people who
experience 'chills' to instrumental music, the scientists narrowed down the subject pool
to ten. They then asked the subjects to bring in their playlist of favourite songs - virtually
every genre was represented, from techno to tango - and played them the music while
their brain activity was monitored. Because the scientists were combining methodologies
(PET and fMRI), they were able to obtain an impressively exact and detailed portrait of
music in the brain. The first thing they discovered is that music triggers the production
of dopamine - a chemical with a key role in setting people's moods - by the neurons
(nerve cells) in both the dorsal and ventral regions of the brain. As these two regions
have long been linked with the experience of pleasure, this finding isn't particularly
surprising.
What is rather more significant is the finding that the dopamine neurons in the
caudate - a region of the brain involved in learning stimulus-response associations,
and in anticipating food and other 'reward' stimuli - were at their most active around
15 seconds before the participants' favourite moments in the music. The researchers
call this the 'anticipatory phase' and argue that the purpose of this activity is to help
us predict the arrival of our favourite part. The question, of course, is what all these
dopamine neurons are up to. Why are they so active in the period preceding the
acoustic climax? After all, we typically associate surges of dopamine with pleasure, with
the processing of actual rewards. And yet, this cluster of cells is most active when the
'chills' have yet to arrive, when the melodic pattern is still unresolved.
66
```

[Original question page](assets/17dd9c9cb6327626c9ba4944c95c15d6e3f3b885669d32fbaaf62b4ec4185abd.jpg)

<!-- Source: /api/assets/a8edfaa36c288a9c9b472dade0710e8aa231c57146b66d13da8ac795346452f1.jpg; PDF page 68; full -->

```text
Reading
One way to answer the question is to look at the music and not the neurons. While
music can often seem (at least to the outsider) like a labyrinth of intricate patterns, it
turns out that the most important part of every song or symphony is when the patterns
break down, when the sound becomes unpredictable. If the music is too obvious, it is
annoyingly boring, like an alarm clock. Numerous studies, after all, have demonstrated
that dopamine neurons quickly adapt to predictable rewards. If we know what's going
to happen next, then we don't get excited. This is why composers often introduce a
key note in the beginning of a song, spend most of the rest of the piece in the studious
avoidance of the pattern, and then finally repeat it only at the end. The longer we are
denied the pattern we expect, the greater the emotional release when the pattern
returns, safe and sound.
To demonstrate this psychological principle, the musicologist Leonard Meyer, in his
classic book Emotion and Meaning in Music (1956), analysed the 5th movement of
Beethoven's String Quartet in C-sharp minor, Op. 131. Meyer wanted to show how
music is defined by its flirtation with - but not submission to - our expectations of order.
Meyer dissected 50 measures (bars) of the masterpiece, showing how Beethoven
begins with the clear statement of a rhythmic and harmonic pattern and then, in an
ingenious tonal dance, carefully holds off repeating it. What Beethoven does instead is
suggest variations of the pattern. He wants to preserve an element of uncertainty in his
music, making our brains beg for the one chord he refuses to give us. Beethoven saves
that chord for the end.
According to Meyer, it is the suspenseful tension of music, arising out of our unfulfilled
expectations, that is the source of the music's feeling. While earlier theories of music
focused on the way a sound can refer to the real world of images and experiences - its
'connotative' meaning - Meyer argued that the emotions we find in music come from the
unfolding events of the music itself. This 'embodied meaning' arises from the patterns
the symphony invokes and then ignores. It is this uncertainty that triggers the surge
of dopamine in the caudate, as we struggle to figure out what will happen next. We
can predict some of the notes, but we can't predict them all, and that is what keeps us
listening, waiting expectantly for our reward, for the pattern to be completed.
67
```

[Original question page](assets/a8edfaa36c288a9c9b472dade0710e8aa231c57146b66d13da8ac795346452f1.jpg)

<!-- Source: /api/assets/de1a7622e19477fccde949ea33f59c1d829e55703197dee8540c6a34fe677707.jpg; PDF page 69; full -->

```text
Test 7
Questions 27-31
Complete the summary below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 27-31 on your answer sheet.
The Montreal Study
Participants, who were recruited for the study through advertisements, had their brain
activity monitored while listening to their favourite music. It was noted that the music
stimulated the brain's neurons to release a substance called 27 ...................................... in two
of the parts of the brain which are associated with feeling 28 ...................................... .
Researchers also observed that the neurons in the area of the brain called the
29 ...................................... were particularly active just before the participants' favourite
moments in the music — the period known as the 30 ....................................... Activity in
this part of the brain is associated with the expectation of 'reward' stimuli such as
31 ...................................... .
68
```

[Original question page](assets/de1a7622e19477fccde949ea33f59c1d829e55703197dee8540c6a34fe677707.jpg)

<!-- Source: /api/assets/2764df7450218f02dfabbcc10b676b563b21a9f09ad617eea0b51f71318462ca.jpg; PDF page 70; full -->

```text
Reading
Questions 32-36
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 32-36 on your answer sheet.
32 What point does the writer emphasise in the first paragraph?
A how dramatically our reactions to music can vary
B how intense our physical responses to music can be
C how little we know about the way that music affects us
D how much music can tell us about how our brains operate
33 What view of the Montreal study does the writer express in the second paragraph?
A Its aims were innovative.
B The approach was too simplistic.
C It produced some remarkably precise data.
D The technology used was unnecessarily complex.
34 What does the writer find interesting about the results of the Montreal study?
A the timing of participants' neural responses to the music
B the impact of the music on participants' emotional state
C the section of participants' brains which was activated by the music
D the type of music which had the strongest effect on participants' brains
35 Why does the writer refer to Meyer's work on music and emotion?
A to propose an original theory about the subject
B to offer support for the findings of the Montreal study
C to recommend the need for further research into the subject
D to present a view which opposes that of the Montreal researchers
36 According to Leonard Meyer, what causes the listener's emotional response to
music?
A the way that the music evokes poignant memories in the listener
B the association of certain musical chords with certain feelings
C the listener's sympathy with the composer's intentions
D the internal structure of the musical composition
69
```

[Original question page](assets/2764df7450218f02dfabbcc10b676b563b21a9f09ad617eea0b51f71318462ca.jpg)

<!-- Source: /api/assets/82ce806638db67fe1a4c1e1dc387459a223c12858608854d67c5a99850952b04.jpg; PDF page 71; full -->

```text
Test 7
Questions 37-40
Complete each sentence with the correct ending, A-F, below.
Write the correct letter, A-F, in boxes 37-40 on your answer sheet.
37 The Montreal researchers discovered that
38 Many studies have demonstrated that
39 Meyer's analysis of Beethoven's music shows that
40 Earlier theories of music suggested that
70
A our response to music depends on our initial emotional state.
B neuron activity decreases if outcomes become predictable.
C emotive music can bring to mind actual pictures and events.
D experiences in our past can influence our emotional reaction to music.
E emotive music delays giving listeners what they expect to hear.
F neuron activity increases prior to key points in a musical piece.
```

[Original question page](assets/82ce806638db67fe1a4c1e1dc387459a223c12858608854d67c5a99850952b04.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/504f9055ad9c844a57d57a8f8722aaaa2c3de39dcf9fb5705e1c6e5a904496eb.jpg; PDF page 72; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows how frequently people in the USA ate in fast food restaurants between 2003 and 2013.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/504f9055ad9c844a57d57a8f8722aaaa2c3de39dcf9fb5705e1c6e5a904496eb.jpg)

![Original figure](assets/504f9055ad9c844a57d57a8f8722aaaa2c3de39dcf9fb5705e1c6e5a904496eb.jpg)

### Task 2

<!-- Source: /api/assets/26504a3c4aa596c4486e0d9a005257f3abac016e983bd78d56bccaf3e8112f5c.jpg; PDF page 73; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In a number of countries, some people think it is necessary to spend large sums of money on constructing new railway lines for very fast trains between cities. Others believe the money should be spent on improving existing public transport.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/26504a3c4aa596c4486e0d9a005257f3abac016e983bd78d56bccaf3e8112f5c.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/21cf5cad7f2d7325cedb23c257352addb2fe90127da549d30405840203a27ed9.jpg; PDF page 74; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Clothes
• Where do you buy most of your clothes? [Why?]
• How often do you buy new clothes for yourself? [Why?]
• How do you decide which clothes to buy? [Why?]
• Have the kinds of clothes you like changed in recent years? [Why?/Why not?]
PART 2
Describe an interesting discussion you
had about how you spend your money.
You should say:
who you had the discussion with
why you discussed this topic
what the result of the discussion was
and explain why this discussion was
interesting for you.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Money and young people
Example questions:
Why do some parents give their children money to spend each week?
Do you agree that schools should teach children how to manage money?
Do you think it is a good idea for students to earn money while studying?
Money and society
Example questions:
Do you think it is true that in today's society money cannot buy happiness?
What disadvantages are there in a society where the gap between rich and poor
is very large?
Do you think richer countries have a responsibility to help poorer countries?
73
```

[Original question page](assets/21cf5cad7f2d7325cedb23c257352addb2fe90127da549d30405840203a27ed9.jpg)

### Part 2

<!-- Source: /api/assets/21cf5cad7f2d7325cedb23c257352addb2fe90127da549d30405840203a27ed9.jpg; PDF page 74; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Clothes
• Where do you buy most of your clothes? [Why?]
• How often do you buy new clothes for yourself? [Why?]
• How do you decide which clothes to buy? [Why?]
• Have the kinds of clothes you like changed in recent years? [Why?/Why not?]
PART 2
Describe an interesting discussion you
had about how you spend your money.
You should say:
who you had the discussion with
why you discussed this topic
what the result of the discussion was
and explain why this discussion was
interesting for you.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Money and young people
Example questions:
Why do some parents give their children money to spend each week?
Do you agree that schools should teach children how to manage money?
Do you think it is a good idea for students to earn money while studying?
Money and society
Example questions:
Do you think it is true that in today's society money cannot buy happiness?
What disadvantages are there in a society where the gap between rich and poor
is very large?
Do you think richer countries have a responsibility to help poorer countries?
73
```

[Original question page](assets/21cf5cad7f2d7325cedb23c257352addb2fe90127da549d30405840203a27ed9.jpg)

### Part 3

<!-- Source: /api/assets/21cf5cad7f2d7325cedb23c257352addb2fe90127da549d30405840203a27ed9.jpg; PDF page 74; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Clothes
• Where do you buy most of your clothes? [Why?]
• How often do you buy new clothes for yourself? [Why?]
• How do you decide which clothes to buy? [Why?]
• Have the kinds of clothes you like changed in recent years? [Why?/Why not?]
PART 2
Describe an interesting discussion you
had about how you spend your money.
You should say:
who you had the discussion with
why you discussed this topic
what the result of the discussion was
and explain why this discussion was
interesting for you.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Money and young people
Example questions:
Why do some parents give their children money to spend each week?
Do you agree that schools should teach children how to manage money?
Do you think it is a good idea for students to earn money while studying?
Money and society
Example questions:
Do you think it is true that in today's society money cannot buy happiness?
What disadvantages are there in a society where the gap between rich and poor
is very large?
Do you think richer countries have a responsibility to help poorer countries?
73
```

[Original question page](assets/21cf5cad7f2d7325cedb23c257352addb2fe90127da549d30405840203a27ed9.jpg)
