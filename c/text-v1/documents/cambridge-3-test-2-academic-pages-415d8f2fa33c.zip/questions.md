# 剑雅 3 · Test 2

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/c1b44164bf9a4255658163b29105c5a7eedc07b7714d99a39fd7ac2f87187ab6.jpg; PDF page 34; full -->

```text
SECTION1 Questions1–10
Questions1–5: Complete the table below. Write NO MORE THAN THREE WORDS OR A NUMBER for each answer.
Programme of Activities for First Day
Time | Place | Event
Example10.00 | (1) __________ [shared place for first three events] | Meet the Principal and staff
10.15 | same place(1) | Talk by (2) __________
10.45 | same place(1) | Talk by (3) __________
(4) __________ | Classroom5 | (5) __________ test
```

[Original question page](assets/c1b44164bf9a4255658163b29105c5a7eedc07b7714d99a39fd7ac2f87187ab6.jpg)

<!-- Source: /api/assets/a1b2f896c3b95d881681f42679c14e855b84a6a89ca6189716cc9d9cfcdbd83b.jpg; PDF page 35; full -->

```text
Listening 
 31
Questions 6-10 
 
Label the rooms on the map below. 
 
Choose your answers from the box below and write them next to questions 6-10. 
 
CL Computer Laboratory 
DO Director’s Office 
L Library 
MH Main Hall 
S Storeroom 
SAR Self Access Room 
SCR Student Common Room 
SR Staff Room
```

[Original question page](assets/a1b2f896c3b95d881681f42679c14e855b84a6a89ca6189716cc9d9cfcdbd83b.jpg)

![Original figure](assets/a1b2f896c3b95d881681f42679c14e855b84a6a89ca6189716cc9d9cfcdbd83b.jpg)

### Part 2

<!-- Source: /api/assets/abbe6b1290054d4790cfad4c6208e0122e4179aeb85caae91843d1a48f24c139.jpg; PDF page 36; full -->

```text
SECTION2 Questions11–20
Questions11–15: Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
TYPE OF HELP | EXAMPLES
FINANCIAL | grants; (11) __________
(12) __________ | childcare; nurseries
ACADEMIC | (13) __________; using the library
(14) __________ | individual interests; (15) __________
```

[Original question page](assets/abbe6b1290054d4790cfad4c6208e0122e4179aeb85caae91843d1a48f24c139.jpg)

<!-- Source: /api/assets/4f7fee07fa527b7de367e977f0fab3e50f7ae9c34b046b1ba9b44a284882765c.jpg; PDF page 37; full -->

```text
Questions16–20
Complete the notes below. Write NUMBERS OR NO MORE THAN THREE WORDS for each answer.
HELPLINE DETAILS
Officer: Jackie (16) __________
Address: Student Welfare Office,13Marshall Road
Telephone number: (17) __________
Opening hours:9.30am–6pm(weekdays); (18) __________ (Saturdays)
Ring or visit office for (19) __________
N.B. At peak times there may be a (20) __________.
```

[Original question page](assets/4f7fee07fa527b7de367e977f0fab3e50f7ae9c34b046b1ba9b44a284882765c.jpg)

### Part 3

<!-- Source: /api/assets/1a97ad5408b5d9f6111fd31c51145974dbe3fa4657b8a8ef331b6b7b79a8d98b.jpg; PDF page 38; full -->

```text
Test 2 
 34
SECTION 3       Questions 21-30  
 
Questions 21-24 
 
Choose the correct letters A-C. 
21     At the start of the tutorial, the tutor emphasises the importance of 
A     interviews. 
B      staff selection. 
C     question techniques. 
 
22    An example of a person who doesn’t ‘fit in’ is someone who 
A     is over-qualified for the job. 
B     lacks experience of the tasks set. 
C     disagrees with the rest of the group. 
 
23     An important part of teamwork is having trust in your 
A     colleagues’ ability.  
B     employer’s directions.  
C     company training. 
 
24    The tutor says that finding out personal information is 
A     a skill that needs practice.  
B     avoided by many interviewers.  
C     already a part of job interviews.
```

[Original question page](assets/1a97ad5408b5d9f6111fd31c51145974dbe3fa4657b8a8ef331b6b7b79a8d98b.jpg)

<!-- Source: /api/assets/4a3d3bbfcbc7e1cebf92c21a8a85e61bf9705cf76ff52056864824130b3e3167.jpg; PDF page 39; full -->

```text
Questions25–29
Complete the notes below. Write NO MORE THAN THREE WORDS for each answer.
Personality Questionnaires
• completed during (25) __________
• used in the past by the (26) __________ and the (27) __________
• nowadays used by (28) __________ of large employers
• questions about things like: working under pressure or keeping deadlines
• written by (29) __________ who say candidates tend to be truthful
Question 30 
 
Choose the correct letter A—C. 
What is the tutor trying to do in the tutorial? 
A     describe one selection technique 
B     criticise traditional approaches to interviews 
C     illustrate how she uses personality questionnaires
```

[Original question page](assets/4a3d3bbfcbc7e1cebf92c21a8a85e61bf9705cf76ff52056864824130b3e3167.jpg)

### Part 4

<!-- Source: /api/assets/0c636ab5eab3e25d812daa8c88717181618b557c93d71d15f9bbbaf55adc6acb.jpg; PDF page 40; full -->

```text
Test 2 
 36
SECTION4        Questions 31-40 
 
Questions 31 and 32 
Complete the notes below. 
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer. 
 
 
HAT-MAKING PROJECT — Project Profile
Example: Name of student — Vivien
Type of school: (31) __________
Age of pupils: (32) __________
Questions33and34: Label the diagrams. Write NO MORE THAN THREE WORDS for each answer.
Introduction to Hat-Making — original cut/fold diagrams retained.
First Hat: circle A → conical hat B; cut into centre and (33) __________ the cut.
Second Hat: circle A + strip B → pillbox C; stick flaps to (34) __________ of circle.
```

[Original question page](assets/0c636ab5eab3e25d812daa8c88717181618b557c93d71d15f9bbbaf55adc6acb.jpg)

![Original figure](assets/0c636ab5eab3e25d812daa8c88717181618b557c93d71d15f9bbbaf55adc6acb.jpg)

<!-- Source: /api/assets/ff8745ed60becfce4f6c3cab2af5c966d25942676167645fe1006cc9b875917d.jpg; PDF page 41; full -->

```text
Questions35–37: Complete the notes below. Write NO MORE THAN THREE WORDS for each answer.
DESIGN PHASE
StageA: Refer to research and design a hat (35) __________.
StageB: Make a small-scale (36) __________ hat.
Constraints:
• material: paper
• colours: (37) __________
• glue: must not show
Questions38–40
Indicate who made the hats below. Write the appropriate letter A–E next to each name.
38 Theresa __________
39 Muriel __________
40 Fabrice __________
Original hat options a–e retained; answer letters A–E follow the printed instruction.
```

[Original question page](assets/ff8745ed60becfce4f6c3cab2af5c966d25942676167645fe1006cc9b875917d.jpg)

![Original figure](assets/ff8745ed60becfce4f6c3cab2af5c966d25942676167645fe1006cc9b875917d.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/480a95de76f5dfde2c66830eb960979e272a408d452e1e36f95c7c05d880b1e6.jpg; PDF page 42; full -->

```text
Test 2 
 38
READING 
 
READING PASSAGE 1 
 
You should spend about 20 minutes on Questions 1-13 which are based on Reading Passage 1 below. 
 
A Remarkable Beetle 
Some of the most remarkable beetles are the dung beetles, 
which spend almost their whole lives eating and breeding 
in dung’. 
More than 4,000 species of these remarkable creatures 
have evolved and adapted to the world’s different climates 
and the dung of its many animals. Australia’s native dung 
beetles are scrub and woodland dwellers, specialising in 
coarse marsupial droppings and avoiding the soft cattle 
dung in which bush flies and buffalo flies breed. 
In the early 1960s George Bornemissza, then a scientist at 
the Australian Government’s premier research 
organisation, the Commonwealth Scientific and Industrial 
Research Organisation (CSIRO), suggested that dung beetles 
should be introduced to Australia to control dung-breeding 
flies. Between 1968 and 1982, the CSIRO imported insects 
from about 50 different species of dung beetle, from Asia, Europe and Africa, aiming 
to match them to different climatic zones in Australia. Of the 26 species that are 
known to have become successfully integrated into the local environment, only one, 
an African species released in northern Australia, has reached its natural boundary. 
Introducing dung beetles into a pasture is a simple process: approximately 1,500 
beetles are released, a handful at a time, into fresh cow pats2 in the cow pasture. 
The beetles immediately disappear beneath the pats digging and tunnelling and, if 
they successfully adapt to their new environment, soon become a permanent, self-
sustaining part of the local ecology. In time they multiply and within three or four 
years the benefits to the pasture are obvious. 
Dung beetles work from the inside of the pat so they are sheltered from predators 
such as birds and foxes. Most species burrow into the soil and bury dung in tunnels 
directly underneath the pats, which are hollowed out from within. Some large species 
originating from France excavate tunnels to a depth of approximately 30 cm below 
the dung pat. These beetles make sausage-shaped brood chambers along the tunnels. 
The shallowest tunnels belong to a much smaller Spanish species that buries dung in 
chambers that hang like fruit from the branches of a pear tree. South African beetles
```

[Original question page](assets/480a95de76f5dfde2c66830eb960979e272a408d452e1e36f95c7c05d880b1e6.jpg)

<!-- Source: /api/assets/fa8750b226f523d11f0034f82ae4c9f622271e67779472e5a653537b0040310d.jpg; PDF page 43; full -->

```text
Reading 
 39
dig narrow tunnels of approximately 20 cm below the surface of the pat. Some 
surface-dwelling beetles, including a South African species, cut perfectly-shaped balls 
from the pat, which are rolled away and attached to the bases of plants. 
For maximum dung burial in spring, summer and autumn, farmers require a variety of 
species with overlapping periods of activity. In the cooler environments of the state 
of Victoria, the large French species (2.5 cms long) is matched with smaller (half this 
size), temperate-climate Spanish species. The former are slow to recover from the 
winter cold and produce only one or two generations of offspring from late spring 
until autumn. The latter, which multiply rapidly in early spring, produce two to five 
generations annually. The South African ball-rolling species, being a subtropical 
beetle, prefers the climate of northern and coastal New South Wales where it 
commonly works with the South African tunnelling species. In warmer climates, many 
species are active for longer periods of the year. 
Dung beetles were initially introduced in the late 1960s with a view to controlling 
buffalo flies by removing the dung within a day or two and so preventing flies from 
breeding. However, other benefits have become evident. Once the beetle larvae have 
finished pupation, the residue is a first-rate source of fertiliser. The tunnels 
abandoned by the beetles provide excellent aeration and water channels for root 
systems. In addition, when the new generation of beetles has left the nest the 
abandoned burrows are an attractive habitat for soil-enriching earthworms. The 
digested dung in these burrows is an excellent food supply for the earthworms, which 
decompose it further to provide essential soil nutrients. If it were not for the dung 
beetle, chemical fertiliser and dung would be washed by rain into streams and rivers 
before it could be absorbed into the hard earth, polluting water courses and causing 
blooms of blue-green algae. Without the beetles to dispose of the dung, cow pats 
would litter pastures making grass inedible to cattle and depriving the soil of sunlight. 
Australia’s 30 million cattle each produce 10-12 cow pats a day. This amounts to 1.7 
billion tonnes a year, enough to smother about 110,000 sq km of pasture, half the 
area of Victoria. 
Dung beetles have become an integral part of the successful management of dairy 
farms in Australia over the past few decades. A number of species are available from 
the CSIRO or through a small number of private breeders, most of whom were 
entomologists with the CSIRO’s dung beetle unit who have taken their specialised 
knowledge of the insect and opened small businesses in direct competition with their 
former employer. 
 
Glossary 
1. dung:         the droppings or excreta of animals 
2. cow pats:   droppings of cows
```

[Original question page](assets/fa8750b226f523d11f0034f82ae4c9f622271e67779472e5a653537b0040310d.jpg)

<!-- Source: /api/assets/80318bf6e3d3b508976f609f880eb721d2693598ad3695645f5dd533a9e4525a.jpg; PDF page 44; full -->

```text
Test 2 
 40
Questions 1-5 
 
Do the following statements reflect the claims of the writer in Reading Passage 1?  
 
In boxes 1-5 on your answer sheet write 
 
YES               if the statement reflects the claims of the writer 
NO                 if the statement contradicts the claims of the writer 
NOT GIVEN   if it is impossible to say what the writer thinks about this 
 
1      Bush flies are easier to control than buffalo flies. 
2      Four thousand species of dung beetle were initially brought to Australia by the CSIRO. 
3      Dung beetles were brought to Australia by the CSIRO over a fourteen-year period. 
4      At least twenty-six of the introduced species have become established in Australia. 
5      The dung beetles cause an immediate improvement to the quality of a cow pasture.  
 
Questions 6-8 
Label the tunnels on the diagram below. Choose your labels from the box below the diagram.  
 
Write your answers in boxes 6-8 on your answer sheet. 
 
 
 
Dung Beetle Types 
French                   Spanish  
Mediterranean       South African  
Australian native   South African ball roller
Original tunnel diagram retained:6left tunnel group,7deep central group,8shallow right group; approximate depth axis0/10/20/30cm. Labels selected from the supplied beetle-type box.
```

[Original question page](assets/80318bf6e3d3b508976f609f880eb721d2693598ad3695645f5dd533a9e4525a.jpg)

![Original figure](assets/80318bf6e3d3b508976f609f880eb721d2693598ad3695645f5dd533a9e4525a.jpg)

<!-- Source: /api/assets/9f72e882e1b958b388f3f27ab86005da3a45e2c31b6b6a2b5b84e3b71876ddb7.jpg; PDF page 45; full -->

```text
Reading 
 41
Question 9-13 
 
Complete the table below. 
 
Choose NO MORE THAN THREE WORDS OR A NUMBER from Reading Passage 1 for each 
answer. 
 
Write your answers in boxes 9—13 on your answer sheet. 
 
Species | Size | Preferred climate | Complementary species | Start of active period | Number of generations per year
French |2.5cm|cool|Spanish|late spring|1–2
Spanish |1.25cm|(9) __________|[grey cell]|(10) __________|(11) __________
South African ball roller |[grey cell]|(12) __________|(13) __________|[grey cell]|[grey cell]
Grey cells are not answer spaces.
```

[Original question page](assets/9f72e882e1b958b388f3f27ab86005da3a45e2c31b6b6a2b5b84e3b71876ddb7.jpg)

<!-- Source: /api/assets/547259659bb28bd3337f2dccfd556f2a63d336f5f050e514efa19bb460f86047.jpg; PDF page 46; full -->

```text
Test 2 
 42
READING PASSAGE 2 
 
You should spend about 20 minutes on Questions 14-28 which are based on Reading Passage 2 on 
the following pages. 
 
Questions 14-18 
 
Reading Passage 2 has six sections A-F. 
 
Choose the most suitable headings for sections A-D and F from the list of headings below. 
 
Write the appropriate numbers i-ix in boxes 14-18 on your answer sheet. 
 
 List of Headings 
i The probable effects of the new 
international trade agreement 
ii The environmental impact of modern 
farming 
iii Farming and soil erosion 
iv The effects of government policy in rich 
countries 
v Governments and management of the 
environment 
vi The effects of government policy in poor 
countries 
vii Farming and food output 
viii The effects of government policy on food 
output 
ix The new prospects for world trade 
14     Section A 
15     Section B 
16     Section C 
17     Section D 
Example 
Paragraph E 
Answer 
vi  
18    Section F
```

[Original question page](assets/547259659bb28bd3337f2dccfd556f2a63d336f5f050e514efa19bb460f86047.jpg)

<!-- Source: /api/assets/00e0635815f80669d2ef9aed4763be1afc3ea51d943d62e6a7582199fab060f4.jpg; PDF page 47; full -->

```text
Reading 
 43
Section A 
The role of governments in environmental management is difficult but inescapable. 
Sometimes, the state tries to manage the resources it owns, and does so badly. Often, 
however, governments act in an even more harmful way. They actually subsidise the 
exploitation and consumption of natural resources. A whole range of policies, from farm-
price support to protection for coal-mining, do environmental damage and (often) make no 
economic sense. Scrapping them offers a two-fold bonus: a cleaner environment and a 
more efficient economy. Growth and environmentalism can actually go hand in hand, if 
politicians have the courage to confront the vested interest that subsi-dies create. 
 
SectionB 
No activity affects more of the earth’s surface than farming. It shapes a third of the planet’s 
land area, not counting Antarctica, and the proportion Is rising. World food output per head 
has risen by 4 per cent between the 1970s and 1980s mainly as a result of increases in 
yields from land already in cultivation, but also because more land has been brought under 
the plough. Higher yields have been achieved by increased irrigation, better crop breeding, 
and a doubling in the use of pesticides and chemical fertilisers in the 1970s and 1980s. 
 
Section C 
All these activities may have damaging environmental impacts. For example, land clearing 
for agriculture is the largest single cause of deforestation; chemical fertilisers and 
pesticides may contaminate water supplies; more intensive farming and the abandonment 
of fallow periods tend to exacerbate soil erosion; and the spread of mono-Culture and use 
of high-yielding varieties of crops have been accompanied by the disappearance of old 
varieties of food plants which might have provided some insurance against pests or 
diseases in future. Soil erosion threatens the productivity of land In both rich and poor 
countries. The United States, where the most careful measurements have been done, 
discovered in 1982 that about one-fifth of its farmtand as losing topsoil at a rate likely to 
diminish the soil’s productivity. The country subse-uently embarked upon a program to 
convert 11 per cent of its cropped land to meadow or forest. Topsoil in India and China is 
vanishing much faster than in America. 
 
Section D 
Government policies have frequently compounded the environmental damage that 
farming can cause. In the rich countries, subsidies for growing crops and price supports 
for farm output drive up the price of land.The annual value of these subsidies is immense: 
about $250 billion, or more than all World Bank lending in the 1980s.To increase the output 
of crops per acre, a farmer’s easiest option is to use more of the most readily available 
inputs: fertilisers and pesticides. Fertiliser use doubled in Denmark in the period 1960-1985 
and increased in The Netherlands by 150 per cent. The quantity of pesticides applied has 
risen too; by 69 per cent In 1975-1984 in Denmark, for example, with a rise of 115 per cent 
in the frequency of application in the three years from 1981. 
 
In the late 1980s and early 1990s some efforts were made to reduce farm subsidies. The 
most dramatic example was that of New Zealand, which scrapped most farm support in 
1984. A study of the environmental effects, conducted in 1993, found that the end of fer-
```

[Original question page](assets/00e0635815f80669d2ef9aed4763be1afc3ea51d943d62e6a7582199fab060f4.jpg)

<!-- Source: /api/assets/9df935557cd3588769ee5f6fbbb66120674db69e7a27cdab06412f3f17190e9d.jpg; PDF page 48; full -->

```text
Test 2 
 44
tiliser subsidies had been followed by a fall in fertiliser use (a fall compounded by the 
decline in world commodity prices, which cut farm incomes). The removal of subsidies also 
stopped land-clearing and over-stocking, which in the past had been the principal causes of 
erosion. Farms began to diversify. The one kind of subsidy whose removal appeared to 
have been bad for the environment was the subsidy to manage soil eroslon, 
 
In less enlightened countries, and in the European Union, the trend has been to reduce 
rather than eliminate subsidies, and to introduce new payments to encourage farmers to 
treat their land In environmentally friendlier ways, or to leave it follow. It may sound strange 
but such payments need to be higher than the existing incentives for farmers to grow food 
crops. Farmers, however, dislike being paid to do nothing. In several countries they have 
become interested in the possibility of using fuel produced from crop residues either as a 
replacement for petrol (as ethanol) or as fuel for power stations (as biomass). Such fuels 
produce far less carbon dioxide than coal or oil, and absorb carbon dioxide as they 
grow.They are therefore less likely to contribute to the greenhouse effect. But they die 
rarely competitive with fossil fuels unless subsidised - and growing them does no less 
environmental harm than other crops. 
 
Section E 
In poor countries, governments aggravate other sorts of damage. Subsidies for pesticides 
and artificial fertilisers encourage farmers to use greater quantities than are needed to get 
the highest economic crop yield. A study by the International Rice Research Institute Of 
pesticide use by farmers in South East Asia found that, with pest-resistant varieties of rice, 
even moderate applications of pesticide frequently cost farmers more than they saved.Such 
waste puts farmers on a chemical treadmill: bugs and weeds become resis-tant to poisons, 
so next year’s poisons must be more lethal. One cost is to human health, Every year some 
10,000 people die from pesticide poisoning, almost all of them in the developing countries, 
and another 400,000 become seriously ill. As for artificial fertilisers, their use world-wide 
increased by 40 per cent per unit of farmed land between the mid 1970s and late 1980s, 
mostly in the developing countries. Overuse of fertilisers may cause farmers to stop rotating 
crops or leaving their land fallow. That, In turn, may make soil erosion worse. 
 
Section F 
A 
result of the Uruguay Round of world trade negotiations Is likely to be a reduction of 36 
per cent In the average levels of farm subsidies paid by the rich countries in 1986-1990. 
Some of the world’s food production will move from Western Europe to regions where 
subsidies are lower or non-existent, such as the former communist countries and parts of 
the developing world. Some environmentalists worry about this outcome. It wiB 
undoubtedly mean more pressure to convert natural habitat into farmland. But it will also 
have many desirable environmental effects. The intensity of farming in the rich world should 
decline, and the use of chemical inputs will diminish. Crops are more likely to be grown p 
the environments to which they are naturally suited. And more farmers in poor coun-tries 
wilt have the money and the incentive to manage their land in ways that are sustainable in 
the long run. That is important. To feed an increasingly hungry world, farmers need every 
incentive to use their soil and water effectively and efficiently.
```

[Original question page](assets/9df935557cd3588769ee5f6fbbb66120674db69e7a27cdab06412f3f17190e9d.jpg)

<!-- Source: /api/assets/9a87e9c19b52bc35f098568824079f2f7b09663f7b8396ae38e06c6aaef241f4.jpg; PDF page 49; full -->

```text
Reading 
 45
Questions 19-22 
 
Complete the table below using the information in sections B and C of Reading Passage 2. 
 
Choose your answers A-G from the box below the table and write them in boxes 19-22 on your 
answer sheet. 
 
Agricultural practice | Environmental damage that may result
(19) __________ | Deforestation
(20) __________ | Degraded water supply
More intensive farming | (21) __________
Expansion of monoculture | (22) __________
A Abandonment of fallow period 
B Disappearance of old plant varieties 
C Increased use of chemical inputs 
D Increased irrigation 
E Insurance against pests and diseases 
F Soil erosion 
G Clearing land for cultivation
```

[Original question page](assets/9a87e9c19b52bc35f098568824079f2f7b09663f7b8396ae38e06c6aaef241f4.jpg)

<!-- Source: /api/assets/6d87c110bcc2c76a4f5af837a0c5943c73fc15fddd045f337e9421e5f20084dc.jpg; PDF page 50; full -->

```text
Test 2 
 46
Questions 23-27 
 
Choose the appropriate letters A-D and write them in boxes 23-27 on your answer sheet. 
 
23     Research completed in 1982 found that in the United States soil erosion  
A     reduced the productivity of farmland by 20 per cent. 
B     was almost as severe as in India and China. 
C     was causing significant damage to 20 per cent of farmland. 
D     could be reduced by converting cultivated land to meadow or forest. 
 
24     By the mid-1980s, farmers in Denmark 
A     used 50 per cent less fertiliser than Dutch farmers. 
B     used twice as much fertiliser as they had in 1960. 
C     applied fertiliser much more frequently than in 1960. 
D     more than doubled the amount of pesticide they used in just 3 years. 
 
25    Which one of the following increased in New Zealand after 1984?  
A     farm incomes 
B     use of fertiliser 
C     over-stocking 
D     farm diversification 
 
26    The writer refers to some rich countries as being ‘less enlightened’ than New Zealand because 
A     they disapprove of paying farmers for not cultivating the land.  
B     their new fuel crops are as harmful as the ones they have replaced.  
C     their policies do not recognise the long-term benefit of ending subsidies.  
D     they have not encouraged their farmers to follow environmentally friendly practices. 
 
27    The writer believes that the Uruguay Round agreements on trade will  
A     encourage more sustainable farming practices in the long term.  
B     do more harm than good to the international environment. 
C     increase pressure to cultivate land in the rich countries.  
D     be more beneficial to rich than to poor countries. 
 
Question 28 
 
From the list below choose the most suitable title for Reading Passage 2. 
 
Write the appropriate letter A-E in box 28 on your answer sheet. 
 
A     Environmental management 
B     Increasing the world’s food supply 
C      Soil erosion 
D     Fertilisers and pesticides - the way forward 
E     Farm subsidies
```

[Original question page](assets/6d87c110bcc2c76a4f5af837a0c5943c73fc15fddd045f337e9421e5f20084dc.jpg)

<!-- Source: /api/assets/9ac9ad720e0a609533da6a8836eb4416e154976a92e454dab306f8c0b155e850.jpg; PDF page 51; full -->

```text
Reading 
 47
READING PASSAGE 3 
 
You should spend about 20 minutes on Questions 29—40 which are based on Reading Passage 3 below. 
 
 
 
THE CONCEPT OF ROLE THEORY

Role set 
Any individual in any situation occupies a role in relation to 
other people. The particular individual with whom one is 
concerned in the analysis of any situation is usually given the 
name of focal person. He has the focal role and can be regarded 
as sitting in the middle of a group of people, with whom he 
interacts in some way in that situation. This group of people is 
called his role set. For instance, in the family situation, an 
individual’s role set might be shown as in Figure 6. 
 
 
 
Figure 6 
 
The role set should include all those with whom the individual has more than trivial interactions. 
 
Role definition 
The definition of any individual’s role in any situation will be a combination of the role expectations 
that the members of the role set have of the focal role. These expectations are often occupationally 
denned, sometimes even legally so. The role definitions of lawyers and doctors are fairly clearly 
defined both in legal and in cultural terms. The role definitions of, say, a film star or bank manager, 
are also fairly clearly defined in cultural terms, too clearly perhaps. 
Individuals often find it hard to escape from the role that cultural traditions have defined for them. 
Not only with doctors or lawyers is the required role behaviour so constrained that if you are in that 
role for long it eventually becomes part of you, part of your personality. Hence, there is some 
likelihood that all accountants will be alike or that all blondes are similar - they are forced that way 
by the expectations of their role.
```

[Original question page](assets/9ac9ad720e0a609533da6a8836eb4416e154976a92e454dab306f8c0b155e850.jpg)

![Original figure](assets/9ac9ad720e0a609533da6a8836eb4416e154976a92e454dab306f8c0b155e850.jpg)

<!-- Source: /api/assets/4c95875da3fc33a931c6c6d739870097ed8462a446a6b89bf7f81b342c6a8dba.jpg; PDF page 52; full -->

```text
Test 2 
 48
It is often important that you make it clear what your particular role is at a given time. The means of 
doing this are called, rather obviously, role signs. The simplest of role signs is a uniform. The 
number of stripes on your arm or pips on your shoulder is a very precise role definition which allows 
you to do certain very prescribed things in certain situations. Imagine yourself questioning a stranger 
on a dark street at midnight without wearing the role signs of a policeman! 
In social circumstances, dress has often been used as a role sign to indicate the nature and degree of 
formality of any gathering and occasionally the social status of people present. The current trend 
towards blurring these role signs in dress is probably democratic, but it also makes some people very 
insecure. Without role signs, who is to know who has what role? 
Place is another role sign. Managers often behave very differently outside the office and in it, even 
to the same person. They use a change of location to indicate a change in role from, say, boss to 
friend. Indeed, if you wish to change your roles you must find some outward sign that you are doing 
so or you won’t be permitted to change - the subordinate will continue to hear you as his boss no 
matter how hard you try to be his friend. In very significant cases of role change, e.g. from a soldier 
in the ranks to officer, from bachelor to married man, the change of role has to have a very obvious 
sign, hence rituals. It is interesting to observe, for instance, some decline in the emphasis given to 
marriage rituals. This could be taken as an indication that there is no longer such a big change in role 
from single to married person, and therefore no need for a public change in sign. 
In organisations, office signs and furniture are often used as role signs. These and other perquisites 
of status are often frowned upon, but they may serve a purpose as a kind of uniform in a democratic 
society; roles without signs often lead to confused or differing expectations of the role of the focal 
person. 
Role ambiguity 
Role ambiguity results when there is some uncertainty in the minds, either of the focal person or of 
the members of his role set, as to precisely what his role is at any given time. One of the crucial 
expectations that shape the role definition is that of the individual, the focal person himself. If his 
occupation of the role is unclear, or if it differs from that of the others in the role set, there will be a 
degree of role ambiguity. Is this bad? Not necessarily, for the ability to shape one’s own role is one 
of the freedoms that many people desire, but the ambiguity may lead to role stress which will be 
discussed later on. The virtue of job descriptions is that they lessen this role ambiguity. 
Unfortunately, job descriptions are seldom complete role definitions, except at the lower end of the 
scale. At middle and higher management levels, they are often a list of formal jobs and duties that 
say little about the more subtle and informal expectations of the role. The result is therefore to give 
the individual an uncomfortable feeling that there are things left unsaid, i.e. to heighten the sense of 
role ambiguity. 
Looking at role ambiguity from the other side, from the point of view of the members of the role set, 
lack of clarity in the role of the focal person can cause insecurity, lack of confidence, irritation and 
even anger among members of his role set. One list of the roles of a manager identified the 
following: executive, planner, policy maker, expert, controller of rewards and punishments, 
counsellor, friend, teacher. If it is not clear, through role signs of one sort or another, which role is 
currently the operational one, the other party may not react in the appropriate way — we may, in 
fact, hear quite another message if the focal person speaks to us, for example, as a teacher and we 
hear her as an executive.
```

[Original question page](assets/4c95875da3fc33a931c6c6d739870097ed8462a446a6b89bf7f81b342c6a8dba.jpg)

<!-- Source: /api/assets/df533f5f37d7a5f6ce537272dfcfd51cf3e69a0dc8fbda323034e84ab4627f76.jpg; PDF page 53; full -->

```text
Reading 
 49
Questions 29-35 
 
Do the following statements reflect the views of the writer in Reading Passage 3? 
 
 In boxes 29-35 on your answer sheet write 
 
YES                  if the statement reflects the views of the writer 
NO                    if the statement contradicts the views of the writer 
NOT GIVEN      if it is impossible to know what the writer thinks about this 
 
29     It would be a good idea to specify the role definitions of soldiers more clearly. 
30     Accountants may be similar to one another because they have the same type of job. 
31     It is probably a good idea to keep dress as a role sign even nowadays. 
32     The decline in emphasis on marriage rituals should be reversed. 
33     Today furniture operates as a role sign in the same way as dress has always done. 
34     It is a good idea to remove role ambiguity. 
35     Job descriptions eliminate role ambiguity for managers.
```

[Original question page](assets/df533f5f37d7a5f6ce537272dfcfd51cf3e69a0dc8fbda323034e84ab4627f76.jpg)

<!-- Source: /api/assets/20ac04c9b83f8abc4f244e8c1afc2b69032409502fa6797464824c57f79a72e2.jpg; PDF page 54; full -->

```text
Test 2 
 50
Questions 36-39 
 
Choose ONE OR TWO WORDS from Reading Passage 3 for each answer.  
 
Write your answers in boxes 36-39 on your answer sheet. 
 
36    A new headmaster of a school who enlarges his office and puts in expensive carpeting is using 
the office as a ... 
37     The graduation ceremony in many universities is an important... 
38    The wig which judges wear in UK courts is a ... 
39    The parents of students in a school are part of the headmaster’s ...  
 
Question 40 
 
Choose the appropriate letter A-D and write it in box 40 on your answer sheet.  
 
This text is taken from 
 
A     a guide for new managers in a company. 
B     a textbook analysis of behaviour in organisations. 
C     a critical study of the importance of role signs in modern society. 
D     a newspaper article about role changes.
```

[Original question page](assets/20ac04c9b83f8abc4f244e8c1afc2b69032409502fa6797464824c57f79a72e2.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/d98fa8190284063a0d99e2c358930eb4776874ed66f28ab98b6e09d09e69cd5c.jpg; PDF page 55; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows the amount spent on six consumer goods in four European countries.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

[Text edition note: the complete original figure is retained for all plotted series and labels.]
```

[Original question page](assets/d98fa8190284063a0d99e2c358930eb4776874ed66f28ab98b6e09d09e69cd5c.jpg)

![Original figure](assets/d98fa8190284063a0d99e2c358930eb4776874ed66f28ab98b6e09d09e69cd5c.jpg)

### Task 2

<!-- Source: /api/assets/95d98c2ff78385604fc42234018f4b57e44861550eb5a8ab76fcc8cd5de096ed.jpg; PDF page 56; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic.

When a country develops its technology, the traditional skills and ways of life die out. It is pointless to try and keep them alive.

To what extent do you agree or disagree with this opinion?

You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.

You should write at least 250 words.
```

[Original question page](assets/95d98c2ff78385604fc42234018f4b57e44861550eb5a8ab76fcc8cd5de096ed.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/202302d0fcdd6400fb607b17f86042090241266c37ce89b9fec4703ba092b300.jpg; PDF page 57; full -->

```text
Writing 
 53
SPEAKING 
 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics. 
EXAMPLE  
Festivals 
•  Tell me about the most important festival in your country. 
•   What special food and activities are connected with this festival?
• What do you most enjoy about it? 
•  Do you think festivals are important for a country? [Why?] 
 
PART 2 
 
Describe a film or a TV programme which has made a strong 
impression on you.  
You should say:  
what kind of film or TV programme it was, e.g. comedy  
when you saw the film or TV programme  
what the film or TV programme was about  
and explain why this film or TV programme made such an 
impression on you. 
You will have to talk about the topic for 
1 to 2 minutes. You have one minute to 
think about what you’re going to say. 
You can make some notes to help you if 
you wish. 
 
PART 3 
 
Discussion topics: 
 
People’s cinema-going habits nowadays 
 
Example questions: 
Do you think the cinema has increased or decreased in popularity in recent years? 
In your opinion, will this trend continue into the future? 
 
Making a film or TV drama of real/fictional events 
 
Example questions: 
What are the advantages and disadvantages of making films of real-life events? 
How important do you think it is for a film-maker to remain true to the original story? 
 
Censorship and the freedom of the film-maker/TV producer 
 
Example questions: 
Should films and television be censored or should we be free to choose what we see? 
How do you think censorship laws will change in the next 20 years?
```

[Original question page](assets/202302d0fcdd6400fb607b17f86042090241266c37ce89b9fec4703ba092b300.jpg)

### Part 2

<!-- Source: /api/assets/202302d0fcdd6400fb607b17f86042090241266c37ce89b9fec4703ba092b300.jpg; PDF page 57; full -->

```text
Writing 
 53
SPEAKING 
 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics. 
EXAMPLE  
Festivals 
•  Tell me about the most important festival in your country. 
•   What special food and activities are connected with this festival?
• What do you most enjoy about it? 
•  Do you think festivals are important for a country? [Why?] 
 
PART 2 
 
Describe a film or a TV programme which has made a strong 
impression on you.  
You should say:  
what kind of film or TV programme it was, e.g. comedy  
when you saw the film or TV programme  
what the film or TV programme was about  
and explain why this film or TV programme made such an 
impression on you. 
You will have to talk about the topic for 
1 to 2 minutes. You have one minute to 
think about what you’re going to say. 
You can make some notes to help you if 
you wish. 
 
PART 3 
 
Discussion topics: 
 
People’s cinema-going habits nowadays 
 
Example questions: 
Do you think the cinema has increased or decreased in popularity in recent years? 
In your opinion, will this trend continue into the future? 
 
Making a film or TV drama of real/fictional events 
 
Example questions: 
What are the advantages and disadvantages of making films of real-life events? 
How important do you think it is for a film-maker to remain true to the original story? 
 
Censorship and the freedom of the film-maker/TV producer 
 
Example questions: 
Should films and television be censored or should we be free to choose what we see? 
How do you think censorship laws will change in the next 20 years?
```

[Original question page](assets/202302d0fcdd6400fb607b17f86042090241266c37ce89b9fec4703ba092b300.jpg)

### Part 3

<!-- Source: /api/assets/202302d0fcdd6400fb607b17f86042090241266c37ce89b9fec4703ba092b300.jpg; PDF page 57; full -->

```text
Writing 
 53
SPEAKING 
 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics. 
EXAMPLE  
Festivals 
•  Tell me about the most important festival in your country. 
•   What special food and activities are connected with this festival?
• What do you most enjoy about it? 
•  Do you think festivals are important for a country? [Why?] 
 
PART 2 
 
Describe a film or a TV programme which has made a strong 
impression on you.  
You should say:  
what kind of film or TV programme it was, e.g. comedy  
when you saw the film or TV programme  
what the film or TV programme was about  
and explain why this film or TV programme made such an 
impression on you. 
You will have to talk about the topic for 
1 to 2 minutes. You have one minute to 
think about what you’re going to say. 
You can make some notes to help you if 
you wish. 
 
PART 3 
 
Discussion topics: 
 
People’s cinema-going habits nowadays 
 
Example questions: 
Do you think the cinema has increased or decreased in popularity in recent years? 
In your opinion, will this trend continue into the future? 
 
Making a film or TV drama of real/fictional events 
 
Example questions: 
What are the advantages and disadvantages of making films of real-life events? 
How important do you think it is for a film-maker to remain true to the original story? 
 
Censorship and the freedom of the film-maker/TV producer 
 
Example questions: 
Should films and television be censored or should we be free to choose what we see? 
How do you think censorship laws will change in the next 20 years?
```

[Original question page](assets/202302d0fcdd6400fb607b17f86042090241266c37ce89b9fec4703ba092b300.jpg)
