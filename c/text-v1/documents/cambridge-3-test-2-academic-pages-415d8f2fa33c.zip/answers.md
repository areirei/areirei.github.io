# 剑雅 3 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 155

Answer key 
 151
TEST 2 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS. ( Where alternative spellings are accepted, these are stated in the key.) 
 
Section 1, Questions 1-10 
1      (the) Main Hall NOT Hall 
2      (the) Director (of) (Studies) // DOS 
3     (the) Student(s) Advisor/Adviser 
4     eleven/11 o’clock //11.00 (am) 
5     placement/English (test) 
6      L // Library 
7      MH // Main Hall 
8     CL // Computer Laboratory 
9     SR // Staff Room 
10     SCR // Student Common Room 
Section 2, Questions 11-20 
11      (overseas)(student(s’)) (tuition) fees 
12      (the) domestic (area) 
13     (essay(s’)) deadlines NOT ressay(s) 
14     social (life) 
15      outings // trips 
16      KOUACHI 
17      3269940 
18      ten/10(am)-/to4/four(pm) 
19      (an) appointment(s) 
20     waiting list 
 
Section 3, Questions 21-30 
21      B // staff selection 
22      C // disagrees with the rest of the group 
23     A // colleagues’ ability 
24     C // already a part of job interviews 
25     selection (procedure)  
26-27      EITHER ORDER (the) (ancient) Chinese 
(the) military // army 
28     (almost) two thirds // 2/3 
29     experts NOT expert 
30     A // describe one selection technique 
Section 4, Questions 31-40 
31      secondary 
32      14 // fourteen (year olds/years old) 
33     overlap // overlapping ACCEPT over(-)lap // 
over(-)lapping 
34     underside // underneath // bottom NOT side 
35      on paper // in two dimensions 
36     3/three(-)dimensional // 3(-)D 
37     MUST STATE ALL THREE white, grey/gray, 
brown 
38     C 
39     D 
40     A 
 
 

If you score… (original source guidance, not a new scoring rule)
0–17: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
18–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


1. Main Hall / the Main Hall

2. Director / Director Studies / Director of / Director of Studies / the Director / the Director Studies / the Director of / the Director of Studies / DOS

3. Student Advisor / Students Advisor / the Student Advisor / the Students Advisor / Student Adviser / Students Adviser / the Student Adviser / the Students Adviser

4. eleven / 11 o'clock / 11.00 / 11:00 / 11.00 am / 11.00am / 11:00 am / 11:00am

5. placement / English / English test

6. L / Library

7. MH / Main Hall

8. CL / Computer Laboratory

9. SR / Staff Room

10. SCR / Student Common Room

### Part 2 · source page 155

Answer key 
 151
TEST 2 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS. ( Where alternative spellings are accepted, these are stated in the key.) 
 
Section 1, Questions 1-10 
1      (the) Main Hall NOT Hall 
2      (the) Director (of) (Studies) // DOS 
3     (the) Student(s) Advisor/Adviser 
4     eleven/11 o’clock //11.00 (am) 
5     placement/English (test) 
6      L // Library 
7      MH // Main Hall 
8     CL // Computer Laboratory 
9     SR // Staff Room 
10     SCR // Student Common Room 
Section 2, Questions 11-20 
11      (overseas)(student(s’)) (tuition) fees 
12      (the) domestic (area) 
13     (essay(s’)) deadlines NOT ressay(s) 
14     social (life) 
15      outings // trips 
16      KOUACHI 
17      3269940 
18      ten/10(am)-/to4/four(pm) 
19      (an) appointment(s) 
20     waiting list 
 
Section 3, Questions 21-30 
21      B // staff selection 
22      C // disagrees with the rest of the group 
23     A // colleagues’ ability 
24     C // already a part of job interviews 
25     selection (procedure)  
26-27      EITHER ORDER (the) (ancient) Chinese 
(the) military // army 
28     (almost) two thirds // 2/3 
29     experts NOT expert 
30     A // describe one selection technique 
Section 4, Questions 31-40 
31      secondary 
32      14 // fourteen (year olds/years old) 
33     overlap // overlapping ACCEPT over(-)lap // 
over(-)lapping 
34     underside // underneath // bottom NOT side 
35      on paper // in two dimensions 
36     3/three(-)dimensional // 3(-)D 
37     MUST STATE ALL THREE white, grey/gray, 
brown 
38     C 
39     D 
40     A 
 
 

If you score… (original source guidance, not a new scoring rule)
0–17: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
18–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


11. fees / tuition fees / student fees / student tuition fees / students' fees / students' tuition fees / overseas fees / overseas tuition fees / overseas student fees / overseas student tuition fees / overseas students' fees / overseas students' tuition fees

12. domestic / domestic area / the domestic / the domestic area

13. deadlines / essay deadlines / essays' deadlines

14. social / social life

15. outings / trips

16. KOUACHI

17. 3269940

18. ten to four / ten to four pm / ten am to four / ten am to four pm / 10 to 4 / 10 to 4 pm / 10 to 4pm / 10 am to 4 / 10am to 4 / 10 am to 4 pm / 10am to 4pm / 10-4

19. appointment / appointments / an appointment / an appointments

20. waiting list

### Part 3 · source page 155

Answer key 
 151
TEST 2 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS. ( Where alternative spellings are accepted, these are stated in the key.) 
 
Section 1, Questions 1-10 
1      (the) Main Hall NOT Hall 
2      (the) Director (of) (Studies) // DOS 
3     (the) Student(s) Advisor/Adviser 
4     eleven/11 o’clock //11.00 (am) 
5     placement/English (test) 
6      L // Library 
7      MH // Main Hall 
8     CL // Computer Laboratory 
9     SR // Staff Room 
10     SCR // Student Common Room 
Section 2, Questions 11-20 
11      (overseas)(student(s’)) (tuition) fees 
12      (the) domestic (area) 
13     (essay(s’)) deadlines NOT ressay(s) 
14     social (life) 
15      outings // trips 
16      KOUACHI 
17      3269940 
18      ten/10(am)-/to4/four(pm) 
19      (an) appointment(s) 
20     waiting list 
 
Section 3, Questions 21-30 
21      B // staff selection 
22      C // disagrees with the rest of the group 
23     A // colleagues’ ability 
24     C // already a part of job interviews 
25     selection (procedure)  
26-27      EITHER ORDER (the) (ancient) Chinese 
(the) military // army 
28     (almost) two thirds // 2/3 
29     experts NOT expert 
30     A // describe one selection technique 
Section 4, Questions 31-40 
31      secondary 
32      14 // fourteen (year olds/years old) 
33     overlap // overlapping ACCEPT over(-)lap // 
over(-)lapping 
34     underside // underneath // bottom NOT side 
35      on paper // in two dimensions 
36     3/three(-)dimensional // 3(-)D 
37     MUST STATE ALL THREE white, grey/gray, 
brown 
38     C 
39     D 
40     A 
 
 

If you score… (original source guidance, not a new scoring rule)
0–17: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
18–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


21. B

22. C

23. A

24. C

25. selection / selection procedure

26. Chinese / ancient Chinese / the Chinese / the ancient Chinese / military / the military / army

27. Chinese / ancient Chinese / the Chinese / the ancient Chinese / military / the military / army

28. two thirds / almost two thirds / f

29. experts

30. A

### Part 4 · source page 155

Answer key 
 151
TEST 2 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS. ( Where alternative spellings are accepted, these are stated in the key.) 
 
Section 1, Questions 1-10 
1      (the) Main Hall NOT Hall 
2      (the) Director (of) (Studies) // DOS 
3     (the) Student(s) Advisor/Adviser 
4     eleven/11 o’clock //11.00 (am) 
5     placement/English (test) 
6      L // Library 
7      MH // Main Hall 
8     CL // Computer Laboratory 
9     SR // Staff Room 
10     SCR // Student Common Room 
Section 2, Questions 11-20 
11      (overseas)(student(s’)) (tuition) fees 
12      (the) domestic (area) 
13     (essay(s’)) deadlines NOT ressay(s) 
14     social (life) 
15      outings // trips 
16      KOUACHI 
17      3269940 
18      ten/10(am)-/to4/four(pm) 
19      (an) appointment(s) 
20     waiting list 
 
Section 3, Questions 21-30 
21      B // staff selection 
22      C // disagrees with the rest of the group 
23     A // colleagues’ ability 
24     C // already a part of job interviews 
25     selection (procedure)  
26-27      EITHER ORDER (the) (ancient) Chinese 
(the) military // army 
28     (almost) two thirds // 2/3 
29     experts NOT expert 
30     A // describe one selection technique 
Section 4, Questions 31-40 
31      secondary 
32      14 // fourteen (year olds/years old) 
33     overlap // overlapping ACCEPT over(-)lap // 
over(-)lapping 
34     underside // underneath // bottom NOT side 
35      on paper // in two dimensions 
36     3/three(-)dimensional // 3(-)D 
37     MUST STATE ALL THREE white, grey/gray, 
brown 
38     C 
39     D 
40     A 
 
 

If you score… (original source guidance, not a new scoring rule)
0–17: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
18–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


31. secondary

32. 14 / 14 year olds / 14 years old / fourteen / fourteen year olds / fourteen years old

33. overlap / overlapping / over-lap / over-lapping

34. underside / underneath / bottom

35. on paper / in two dimensions

36. 3-dimensional / three-dimensional / 3-D

37. white grey brown / white, grey, brown / white and grey and brown / white & grey & brown / white; grey; brown / white/grey/brown / white,grey,brown / white, grey and brown / white brown grey / white, brown, grey / white and brown and grey / white & brown & grey / white; brown; grey / white/brown/grey / white,brown,grey / white, brown and grey / grey white brown / grey, white, brown / grey and white and brown / grey & white & brown / grey; white; brown / grey/white/brown / grey,white,brown / grey, white and brown / grey brown white / grey, brown, white / grey and brown and white / grey & brown & white / grey; brown; white / grey/brown/white / grey,brown,white / grey, brown and white / brown white grey / brown, white, grey / brown and white and grey / brown & white & grey / brown; white; grey / brown/white/grey / brown,white,grey / brown, white and grey / brown grey white / brown, grey, white / brown and grey and white / brown & grey & white / brown; grey; white / brown/grey/white / brown,grey,white / brown, grey and white / white gray brown / white, gray, brown / white and gray and brown / white & gray & brown / white; gray; brown / white/gray/brown / white,gray,brown / white, gray and brown / white brown gray / white, brown, gray / white and brown and gray / white & brown & gray / white; brown; gray / white/brown/gray / white,brown,gray / white, brown and gray / gray white brown / gray, white, brown / gray and white and brown / gray & white & brown / gray; white; brown / gray/white/brown / gray,white,brown / gray, white and brown / gray brown white / gray, brown, white / gray and brown and white / gray & brown & white / gray; brown; white / gray/brown/white / gray,brown,white / gray, brown and white / brown white gray / brown, white, gray / brown and white and gray / brown & white & gray / brown; white; gray / brown/white/gray / brown,white,gray / brown, white and gray / brown gray white / brown, gray, white / brown and gray and white / brown & gray & white / brown; gray; white / brown/gray/white / brown,gray,white / brown, gray and white

38. C

39. D

40. A

## A 类阅读

### Academic Reading · source page 156

Answer key 
 
 152
ACADEMIC READING 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN ALL 
ANSWERS. 
 
Reading Passage 1, Questions 1-13 
1      NOT GIVEN // NG 
2      NO // N 
3      YES // Y 
4     YES // Y 
5      NO // N 
6     South African 
7      French 
8      Spanish 
9     temperate 
10     early spring NOT spring 
11      2-5 // two to five 
12     sub-tropical 
13      South African tunneling/tunnelling/ 
tunneler/tunneller (species) 
Reading Passage 2, Questions 14-28 
14      v // Governments and management of the 
environment 
15      vii // Farming and food output 
16      ii // The environmental impact of modern farming 
17     iv // The effects of government policy in rich 
countries 
18     i // The probable effects of the new international 
trade agreement 
19     G // Clearing land for cultivation 
20     C // Increased use of chemical inputs 
21      F // Soil erosion 
22      B // Disappearance of old plant varieties 
23      C // was causing significant damage to 20 per 
cent of farmland 
24     B // used twice as much fertiliser as they had in 
1960 
25      D // farm diversification 
26      C // their policies do not recognise the long term 
benefit of ending subsidies 
27      A // encourage more sustainable farming 
practices in the long term 
28     A // Environmental management 
Reading Passage 3, Questions 29-40 
29      NOT GIVEN // NG 
30      YES // Y 
31      YES // Y 
32     NOT GIVEN // NG 
33     YES // Y 
34      NO // N 
35      NO // N 
36     role sign 
37      ritual 
38     role sign 
39      role set 
40      C // a critical study of the importance of role 
signs in modern society 
 
 

If you score… (original source guidance, not a new scoring rule)
0–15: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
16–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


1. NOT GIVEN

2. NO

3. YES

4. YES

5. NO

6. South African

7. French

8. Spanish

9. temperate

10. early spring

11. 2-5 / two to five

12. sub-tropical

13. South African tunneling / South African tunneling species / South African tunnelling / South African tunnelling species / South African tunneler / South African tunneler species / South African tunneller / South African tunneller species

14. v

15. vii

16. ii

17. iv

18. i

19. G

20. C

21. F

22. B

23. C

24. B

25. D

26. C

27. A

28. A

29. NOT GIVEN

30. YES

31. YES

32. NOT GIVEN

33. YES

34. NO

35. NO

36. role sign

37. ritual

38. role sign

39. role set

40. C

## A 类写作

### Writing material: c3-t2-w-1

Original grouped horizontal bar chart and legend inspected at full resolution. Countries: Germany (white), Italy (light grey), France (dark grey), Britain (black). Horizontal units: thousand pounds sterling; the displayed axis begins at 100 and runs to 180, so bar starts are truncated rather than zero. Categories: personal stereos, tennis racquets, perfumes, CDs, toys, photographic film. Approximate readings in Germany/Italy/France/Britain order: personal stereos 148/150/148/154; tennis racquets 150/152/145/154; perfumes 148/152/146/160; CDs 146/152/158/162; toys 148/158/158/168; photographic film 146/156/166/172 thousand pounds. Accept sensible rounded estimates. Britain spends most on all six goods; its largest expenditure is photographic film, followed by toys. France also spends most on photographic film. German spending is relatively low and varies little, although France is lower on tennis racquets and perfumes. No year, per-capita denominator or causal explanation is given.



### Writing material: c3-t2-w-2

The stated position is an opinion for evaluation. A supported agreement, disagreement or qualified position is valid; do not require a predetermined stance.



## 口语
