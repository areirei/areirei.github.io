# 剑雅 7 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/9a0d857dedf792493377462c2dc15081f3ce610bf33d5f5457c130b95d50d49e.jpg; PDF page 86; full -->

```text
Test 4
SECTION 1 Questions 1-10
Questions 1-6
Complete the form below.
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
HOMESTAY APPLICATION
Example Answer
Surname: Yuichini ....................
First name: 1 ........................
Sex: female Nationality: Japanese
Passport number: 2 ........................ Age: 28 years
Present address: Room 21C, Willow College
Length of homestay: approx 3 .... ....................
Course enrolled in: 4 ........................
Family preferences: no 5 .......... ..............
no objection to 6 ........................
81
```

[Original question page](assets/9a0d857dedf792493377462c2dc15081f3ce610bf33d5f5457c130b95d50d49e.jpg)

<!-- Source: /api/assets/d1fd24a1a34b91b0ee9794e01423944dcd9656b78f6e17f52ccbb6aa4a6042b3.jpg; PDF page 87; full -->

```text
Test 4
Questions 7-10
Answer the questions below.
Write NO MORE THAN TWO WORDS for each answer.
7 What does the student particularly like to eat?
8 What sport does the student play?
9 What mode of transport does the student prefer?
10 When will the student find out her homestay address?
82
```

[Original question page](assets/d1fd24a1a34b91b0ee9794e01423944dcd9656b78f6e17f52ccbb6aa4a6042b3.jpg)

### Part 2

<!-- Source: /api/assets/495abd70a10c28959aa1c0e9c5d304ba843902b9c6808d9a5dd033795ecc7839.jpg; PDF page 88; full -->

```text
Listening
SECTION 2 Questions 11-20
Questions 11-14
Choose the correct letter, A, B or C
11 What kind of tour is Sally leading?
A a bus tour
B a train tour
C a walking tour
12 The original buildings on the site were
A houses.
B industrial buildings.
C shops.
13 The local residents wanted to use the site for
A leisure.
B apartment blocks.
C a sports centre.
14 The Tower is at the centre of the
A nature reserve.
B formal gardens.
C Bicentennial Park .
83
```

[Original question page](assets/495abd70a10c28959aa1c0e9c5d304ba843902b9c6808d9a5dd033795ecc7839.jpg)

<!-- Source: /api/assets/0453f3679370c7d39befd772bfba23daba867c361f272812913a277c3c5908be.jpg; PDF page 89; full -->

```text
Questions 15–17
Label the plan below. Write NO MORE THAN TWO WORDS for each answer.
[Original plan retained, compass north up. Tower/You are here at centre-left; lake and island to its north; Pond to its south. Olympic Site/ Stadium/Swimming Pool/Indoor Arena and railway/Station on east. Blank15 points to the building southeast of Station;16 points to the curved area with benches west of Tower;17 points to the small rectangle at the lake’s southwest edge.]
15 __________; 16 __________; 17 __________
Questions 18–20
Complete the table below. Write NO MORE THAN TWO WORDS for each answer.
Nature Reserve
| Area | Facility | Activity |
| --- | --- | --- |
| The Mangroves | boardwalk | (18) __________ |
| Frog Pond | outdoor classroom | (19) __________ |
| The Waterbird Refuge | (20) __________ | bird watching |
```

[Original question page](assets/0453f3679370c7d39befd772bfba23daba867c361f272812913a277c3c5908be.jpg)

![Original figure](assets/0453f3679370c7d39befd772bfba23daba867c361f272812913a277c3c5908be.jpg)

### Part 3

<!-- Source: /api/assets/e71b24d7c14903333eba8c3210151830f282dfb3a3511536f505dbe64c821627.jpg; PDF page 90; full -->

```text
SECTION 3 Questions 21-30
Questions 21 and 22
Complete the sentences below.
Write NO MORE THAN ONE WORD AND/OR A NUMBER for each answer.
The presentation will last 15 minutes .
There will be 21 ............ ............ minutes for questions.
The presentation will not be 22 ........................ .
Questions 23-26
What do the students decide about each topic for the geography presentation?
A They will definitely include this topic.
B They might include this topic.
C They will not include this topic.
Write the correct letter, A, B or C, next to questions 23-26 .
23 Geographical Location __________
24 Economy __________
25 Overview of Education System __________
26 Role of English Language __________
```

[Original question page](assets/e71b24d7c14903333eba8c3210151830f282dfb3a3511536f505dbe64c821627.jpg)

<!-- Source: /api/assets/2541469ef00b0505217e7bd259aceca28a8049495029e81e365c7be88febdea0.jpg; PDF page 91; full -->

```text
Questions 27–30
Complete the table below. Write NO MORE THAN TWO WORDS for each answer.
| Information/visual aid | Where from? |
| --- | --- |
| Overhead projector | the (27) __________ |
| Map of West Africa | the (28) __________ |
| Map of the islands | a tourist brochure |
| Literacy figures | the (29) __________ |
| (30) __________ on school places | as above |
```

[Original question page](assets/2541469ef00b0505217e7bd259aceca28a8049495029e81e365c7be88febdea0.jpg)

### Part 4

<!-- Source: /api/assets/1f928d62349751e7bfb17789e148b7bab78a457bc407ba1feb86f9bb5d940654.jpg; PDF page 92; full -->

```text
SECTION 4 Questions 31-40
Questions 31-33
Choose the correct letter, A, B or C
Monosodium Glutamate (MSG)
31 The speaker says the main topic of the lecture is
A the history of monosodium glutamate.
B the way monosodium glutamate works.
C where monosodium glutamate is used.
32 In 1908 , scientists in Japan
A made monosodium glutamate.
B began using kombu.
C identified glutamate.
33 What change occurred in the manufacture of glutamate in 1956?
A It began to be manufactured on a large scale.
B The Japanese began extracting it from natural sources.
C It became much more expensive to produce.
Listening
87
```

[Original question page](assets/1f928d62349751e7bfb17789e148b7bab78a457bc407ba1feb86f9bb5d940654.jpg)

<!-- Source: /api/assets/4e9b5364263b20f80a9411e5d6613e04750f541eed7e3353b6dcb49b994e719d.jpg; PDF page 93; full -->

```text
Test 4
Questions 34-40
Complete the notes below.
Write NO MORE THAN TWO WORDS for each answer.
Monosodium Glutamate (MSG)
• MSG contains
-glutamate (78.2%)
-sodium (12.2%)
-34 ........................ (9.6%)
Glutamate is found in foods that contain protein such as 35 ........................ and
36 ..................... ... .
MSG is used in foods in many different parts of the world.
• In 1908 Kikunae Ikeda discovered a 37 ............ ............ .
Our ability to detect glutamate makes sense because it is so 38 ....................... .
naturally.
John Prescott suggests that:
-sweetness tells us that a food contains carbohydrates .
- 39 .............. .......... tells us that a food contains toxins.
-sourness tells us that a food is spoiled.
-saltiness tells us that a food contains 40 ........................ .
88
```

[Original question page](assets/4e9b5364263b20f80a9411e5d6613e04750f541eed7e3353b6dcb49b994e719d.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/09b31f1c0c892188b3634b35bbb6038ee3aef0a9b8dbc4bb9a55bad067f62a4f.jpg; PDF page 94; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13 , which are based on Reading Passage 1
below.
Pulling strings to build pyramids
No one knows exactly how the pyramids were built.
Marcus Chown reckons the answer could be 'hanging
in the air'.
The pyramids of Egypt were built more than three
thousand years ago, and no one knows how. The
conventional picture is that tens of thousands of slaves
dragged stones on sledges. But there is no evidence to
back this up. Now a Californian software consultant
called Maureen Clemmons has suggested that kites
might have been involved. While perusing a book on
the monuments of Egypt, she noticed a hieroglyph that showed a row of men standing in
odd postures. They were holding what looked like ropes that led, via some kind of
mechanical system, to a giant bird in the sky. She wondered if perhaps the bird was
actually a giant kite, and the men were using it to lift a heavy object.
Intrigued, Clemmons contacted Morteza Gharib , aeronautics professor at the California
Institute of Technology. He was fascinated by the idea. 'Coming from Iran, I have a keen
interest in Middle Eastern science,' he says. He too was puzzled by the picture that had
sparked Clemmons's interest. The object in the sky apparently had wings far too short and
wide for a bird. 'The possibility certainly existed that it was a kite,' he says. And since he
needed a summer project for his student Emilio Graff, investigating the possibility of using
kites as heavy lifters seemed like a good idea.
Gharib and Graff set themselves the task of raising a 4.5-metre stone column from
horizontal to vertical, using no source of energy except the wind . Their initial calculations
and scale-model wind-tunnel experiments convinced them they wouldn't need a strong
wind to lift the 33.5-tonne column. Even a modest force, if sustained over a long time,
would do. The key was to use a pulley system that would magnify the applied force. So
they rigged up a tent-shaped scaffold directly above the tip of the horizontal column, with
pulleys suspended from the scaffold's apex. The idea was that as one end of the column
rose, the base would roll across the ground on a trolley.
89
```

[Original question page](assets/09b31f1c0c892188b3634b35bbb6038ee3aef0a9b8dbc4bb9a55bad067f62a4f.jpg)

<!-- Source: /api/assets/8ac2626882bde2ee25b154c17a30d7e1b4bb13459db4091ee4c3dc10399984b5.jpg; PDF page 95; full -->

```text
Test4
Earlier this year, the team put Clemmons's unlikely theory to the test, using a 40-square­
metre rectangular nylon sail. The kite lifted the column clean off the ground. We were
absolutely stunned,' Gharib says. 'The instant the sail opened into the wind, a huge force
was generated and the column was raised to the vertical in a mere 40 seconds.'
The wind was blowing at a gentle 16 to 20 kilometres an hour, little more than half what
they thought would be needed. What they had failed to reckon with was what happened
when the kite was opened. 'There was a huge initial force- five times larger than the steady
state force,' Gharib says. This jerk meant that kites could lift huge weights, Gharib realised.
Even a 300-tonne column could have been lifted to the vertical with 40 or so men and four
or five sails. So Clemmons was right: the pyramid builders could have used kites to lift
massive stones into place. Whether they actually did is another matter,' Gharib says. There
are no pictures showing the construction of the pyramids, so there is no way to tell what
really happened. 'The evidence for using kites to move large stones is no better or worse
than the evidence for the brute force method,' Gharib says.
90
Indeed, the experiments have left many specialists unconvinced. 'The evidence for kite­
lifting is non-existent,' says Willeke Wendrich, an associate professor of Egyptology at the
University of California, Los Angeles.
Others feel there is more of a case for the theory. Harnessing the wind would not have
been a problem for accomplished sailors like the Egyptians. And they are known to have
used wooden pulleys, which could have been made strong enough to bear the weight of
massive blocks of stone. In addition, there is some physical evidence that the ancient
Egyptians were interested in flight. A wooden artefact found on the step pyramid at
Saqqara looks uncannily like a modern glider. Although it dates from several hundred
years after the building of the pyramids, its sophistication suggests that the Egyptians might
have been developing ideas of flight for a long time. And other ancient civilisations
certainly knew about kites; as early as 1250 BC, the Chinese were using them to deliver
messages and dump flaming debris on their foes.
The experiments might even have practical uses nowadays. There are plenty of places
around the globe where people have no access to heavy machinery, but do know how to
deal with wind, sailing and basic mechanical principles. Gharib has already been
contacted by a civil engineer in Nicaragua, who wants to put up buildings with adobe
roofs supported by concrete arches on a site that heavy equipment can't reach. His idea
is to build the arches horizontally, then lift them into place using kites. We've given him
some design hints,' says Gharib. We're just waiting for him to report back.' So whether
they were actually used to build the pyramids or not, it seems that kites may make sensible
construction tools in the 21st century AD.
```

[Original question page](assets/8ac2626882bde2ee25b154c17a30d7e1b4bb13459db4091ee4c3dc10399984b5.jpg)

<!-- Source: /api/assets/4b6425648c79f54f8c9b0df9343fb240284cb3db743eaca6db514f84456648d5.jpg; PDF page 96; full -->

```text
Reading
Questions 1-7
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-7 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
1 It is generally believed that large numbers of people were needed to build the pyramids.
2 Clemmons found a strange hieroglyph on the wall of an Egyptian monument.
3 Gharib had previously done experiments on bird flight.
4 Gharib and Graff tested their theory before applying it.
5 The success of the actual experiment was due to the high speed of the wind.
6 They found that , as the kite flew higher, the wind force got stronger.
7 The team decided that it was possible to use kites to raise very heavy stones.
Questions 8-13
Complete the summary below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 8-13 on your answer sheet.
Additional evidence for theory of kite-lifting
The Egyptians had 8 ........................ , which could lift large pieces of 9 ........................ ,
and they knew how to use the energy of the wind from their skill as 10 ........................ .
The discovery on one pyramid of an object which resembled a 11 ....................... .
suggests they may have experimented with 12 ........................ . In addition, over two
thousand years ago kites were used in China as weapons, as well as for sending
13 ..................... ... 0
91
```

[Original question page](assets/4b6425648c79f54f8c9b0df9343fb240284cb3db743eaca6db514f84456648d5.jpg)

<!-- Source: /api/assets/7a1b67efd19c57904f1a8d486dc9169bb8b34f28ec4170b547c82f520eb8ede9.jpg; PDF page 97; full -->

```text
Test4
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26 , which are based on Reading Passage 2
below.
92
Endless Harvest
More than two hundred years ago, Russian explorers and fur
hunters landed on the Aleutian Islands, a volcanic archipelago
in the North Pacific, and learned of a land mass that lay
farther to the north . The islands' native inhabitants called this
land mass Aleyska, the 'Great Land'; today, we know it as
Alaska.
The forty-ninth state to join the United States of America (in
1959), Alaska is fully one-fifth the size of the mainland 48
states combined. It shares, with Canada, the second longest
river system in North America and has over half the coastline
of the United States. The rivers feed into the Bering Sea and Gulf of Alaska- cold, nutrient-rich
waters which support tens of millions of seabirds, and over 400 species of fish, shellfish,
crustaceans, and molluscs. Taking advantage of this rich bounty, Alaska's commercial fisheries
have developed into some of the largest in the world.
According to the Alaska Department of Fish and Game (ADF&G), Alaska's commercial fisheries
landed hundreds of thousands of tonnes of shellfish and herring, and well over a million tonnes
of groundfish (cod, sole, perch and pollock) in 2000. The true cultural heart and soul of Alaska's
fisheries, however, is salmon. 'Salmon,' notes writer Susan Ewing in The Great Alaska Nature
Factbook, 'pump through Alaska like blood through a heart, bringing rhythmic, circulating
nourishment to land, animals and people.' The 'predictable abundance of salmon allowed some
native cultures to flourish,' and 'dying spawners* feed bears, eagles, other animals, and ultimately
the soil itself.' All five species of Pacific salmon- chinook, or king; chum, or dog; coho, or silver;
sockeye, or red; and pink, or humpback- spawn** in Alaskan waters, and 90% of all Pacific
salmon commercially caught in North America are produced there. Indeed, if Alaska was an
independent nation, it would be the largest producer of wild salmon in the world. During 2000,
commercial catches of Pacific salmon in Alaska exceeded 320,000 tonnes, with an ex-vessel value
of over $US260 million.
Catches have not always been so healthy. Between 1940 and 1959, overfishing led to crashes in
salmon populations so severe that in 1953 Alaska was declared a federal disaster area. With the
onset of statehood, however, the State of Alaska took over management of its own fisheries,
guided by a state constitution which mandates that Alaska's natural resources be managed on a
sustainable basis. At that time, statewide harvests totalled around 25 million salmon. Over the next
few decades average catches steadily increased as a result of this policy of sustainable
• spawners: fish that have released eggs
•• spawn: release eggs
```

[Original question page](assets/7a1b67efd19c57904f1a8d486dc9169bb8b34f28ec4170b547c82f520eb8ede9.jpg)

<!-- Source: /api/assets/ed88876e178b124ddd43863ebf47c46e5f6e6366d1e5d39fd8dd67223c229a42.jpg; PDF page 98; full -->

```text
Reading
management, until, during the 1990s, annual harvests were well in excess of 100 million, and on
several occasions over 200 million fish.
The primary reason for such increases is what is known as 'In-Season Abundance-Based
Management '. There are biologists throughout the state constantly monitoring adult fish as they
show up to spawn. The biologists sit in streamside counting towers, study sonar, watch from
aeroplanes, and talk to fishermen . The salmon season in Alaska is not pre-set . The fishermen
know the approximate time of year when they will be allowed to fish, but on any given day, one or
more field biologists in a particular area can put a halt to fishing. Even sport fishing can be
brought to a halt. It is this management mechanism that has allowed Alaska salmon stocks - and,
accordingly, Alaska salmon fisheries - to prosper, even as salmon populations in the rest of the
United States are increasingly considered threatened or even endangered.
In 1999, the Marine Stewardship Council (MSC)*** commissioned a review of the Alaska salmon
fishery . The Council , which was founded in 1996, certifies fisheries that meet high environmental
standards, enabling them to use a label that recognises their environmental responsibility. The
MSC has established a set of criteria by which commercial fisheries can be judged. Recognising the
potential benefits of being identified as environmentally responsible, fisheries approach the
Council requesting to undergo the certification process. The MSC then appoints a certification
committee, composed of a panel of fisheries experts, which gathers information and opinions
from fishermen, biologists, government officials, industry representatives, non-governmental
organisations and others.
Some observers thought the Alaska salmon fisheries would not have any chance of certification
when, in the months leading up to MSC's final decision, salmon runs throughout western Alaska
completely collapsed. In the Yukon and Kuskokwim rivers, chinook and chum runs were probably
the poorest since statehood ; subsistence communities throughout the region, who normally have
priority over commercial fishing, were devastated.
The crisis was completely unexpected, but researchers believe it had nothing to do with impacts of
fisheries. Rather, they contend, it was almost certainly the result of climatic shifts, prompted in
part by cumulative effects of the el niño/la niña phenomenon on Pacific Ocean temperatures,
culminating in a harsh winter in which huge numbers of salmon eggs were frozen. It could have
meant the end as far as the certification process was concerned. However, the state reacted quickly,
closing down all fisheries, even those necessary for subsistence purposes.
In September 2000, MSC announced that the Alaska salmon fisheries qualified for certification.
Seven companies producing Alaska salmon were immediately granted permission to display the
MSC logo on their products. Certification is for an initial period of five years, with an annual
review to ensure that the fishery is continuing to meet the required standards.
*** MSC: a joint venture between WWF (World Wildlife Fund) and Unilever, a Dutch -based multi-national
93
```

[Original question page](assets/ed88876e178b124ddd43863ebf47c46e5f6e6366d1e5d39fd8dd67223c229a42.jpg)

<!-- Source: /api/assets/1ff5d16a1cc9ee845913a4d145615cc55eeb9b50483cd0c060ac0b4c800e0273.jpg; PDF page 99; full -->

```text
Test4
Questions 14-20
Do the following statements agree with the information given in Reading Passage 2?
In boxes 14-20 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
14 The inhabitants of the Aleutian islands renamed their islands 'Aleyska'.
15 Alaska's fisheries are owned by some of the world's largest companies.
16 Life in Alaska is dependent on salmon.
17 Ninety per cent of all Pacific salmon caught are sockeye or pink salmon.
18 More than 320,000 tonnes of salmon were caught in Alaska in 2000.
19 Between 1940 and 1959, there was a sharp decrease in Alaska's salmon population.
20 During the 1990s, the average number of salmon caught each year was 100 million.
94
```

[Original question page](assets/1ff5d16a1cc9ee845913a4d145615cc55eeb9b50483cd0c060ac0b4c800e0273.jpg)

<!-- Source: /api/assets/492503d3767c31a080b23b8318b472a797ae0d24e795a36ed3270933cc5ce8ac.jpg; PDF page 100; full -->

```text
Reading
Questions 21-26
Complete each sentence with the correct ending, A-K, below.
Write the correct letter, A-K, in boxes 21-26 on your answer sheet.
21 In Alaska, biologists keep a check on adult fish
22 Biologists have the authority
23 In-Season Abundance-Based Management has allowed the Alaska salmon fisheries
24 The Marine Stewardship Council (MSC) was established
25 As a result of the collapse of the salmon runs in 1999, the state decided
26 In September 2000, the MSC allowed seven Alaska salmon companies
A to recognise fisheries that care for the environment.
B to be successful.
C to stop fish from spawning.
D to set up environmental protection laws.
E to stop people fishing for sport.
F to label their products using the MSC logo.
G to ensure that fish numbers are sufficient to permit
fishing.
H to assist the subsistence communities in the region.
I to freeze a huge number of salmon eggs.
J to deny certification to the Alaska fisheries.
K to close down all fisheries.
95
```

[Original question page](assets/492503d3767c31a080b23b8318b472a797ae0d24e795a36ed3270933cc5ce8ac.jpg)

<!-- Source: /api/assets/e38341778967c9c37af22e3687d6883d5ab94ba58696c43b131c312a8479275a.jpg; PDF page 101; full -->

```text
Test4
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading Passage 3
below.
96
EFFECTS OF NOISE
In general, it is plausible to suppose that we should prefer peace and quiet to noise. And
yet most of us have had the experience of having to adjust to sleeping in the mountains or
the countryside because it was initially 'too quiet' , an experience that suggests that
humans are capable of adapting to a wide range of noise levels. Research supports this
view. For example, Glass and Singer (1972) exposed people to short bursts of very loud
noise and then measured their ability to work out problems and their physiological
reactions to the noise. The noise was quite disruptive at first, but after about four minutes
the subjects were doing just as well on their tasks as control subjects who were not exposed
to noise. Their physiological arousal also declined quickly to the same levels as those of
the control subjects.
But there are limits to adaptation and loud noise becomes more troublesome if the person
is required to concentrate on more than one task. For example, high noise levels interfered
with the performance of subjects who were required to monitor three dials at a time, a
task not unlike that of an aeroplane pilot or an air-traffic controller (Broadbent , 1957).
Similarly, noise did not affect a subject's ability to track a moving line with a steering
wheel, but it did interfere with the subject's ability to repeat numbers while tracking
(Finkelman and Glass, 1970).
Probably the most significant finding from research on noise is that its predictability is
more important than how loud it is. We are much more able to 'tune out ' chronic
background noise, even if it is quite loud , than to work under circumstances with
unexpected intrusions of noise. In the Glass and Singer study, in which subjects were
exposed to bursts of noise as they worked on a task, some subjects heard loud bursts and
others heard soft bursts. For some subjects, the bursts were spaced exactly one minute
apart (predictable noise); others heard the same amount of noise overall, but the bursts
| | Unpredictable Noise | Predictable Noise | Average |
| --- | --- | --- | --- |
| Loud noise | 40.1 | 31.8 | 35.9 |
| Soft noise | 36.7 | 27.4 | 32.1 |
| Average | 38.4 | 29.6 | |
Table 1: Proofreading Errors and Noise
```

[Original question page](assets/e38341778967c9c37af22e3687d6883d5ab94ba58696c43b131c312a8479275a.jpg)

<!-- Source: /api/assets/204bf1086a62fa1eefd87fc810ccc744918703fc5502a514e893a9fcc92829a3.jpg; PDF page 102; full -->

```text
Reading
occurred at random intervals (unpredictable noise). Subjects reported finding the
predictable and unpredictable noise equally annoying , and all subjects performed at about
the same level during the noise portion of the experiment. But the different noise
conditions had quite different after-effects when the subjects were required to proofread
written material under conditions of no noise. As shown in Table I the unpredictable
noise produced more errors in the later proofreading task than predictable noise; and soft,
unpredictable noise actually produced slightly more errors on this task than the loud ,
predictable noise.
Apparently , unpredictable noise produces more fatigue than predictable noise, but it takes
a while for this fatigue to take its toll on performance.
Predictability is not the only variable that reduces or eliminates the negative effects of
noise. Another is control. If the individual knows that he or she can control the noise, this
seems to eliminate both its negative effects at the time and its after-effects. This is true even
if the individual never actually exercises his or her option to turn the noise off (Glass and
Singer, 1972). Just the knowledge that one has control is sufficient.
The studies discussed so far exposed people to noise for only short periods and only
transient effects were studied. But the major worry about noisy environments is that living
day after day with chronic noise may produce serious, lasting effects. One study, suggesting
that this worry is a realistic one, compared elementary school pupils who attended schools
near Los Angeles's busiest airport with students who attended schools in quiet
neighbourhoods (Cohen et al., 1980). It was found that children from the noisy schools
had higher blood pressure and were more easily distracted than those who attended the
quiet schools. Moreover, there was no evidence of adaptability to the noise. In fact, the
longer the children had attended the noisy schools, the more distractible they became. The
effects also seem to be long lasting . A follow-up study showed that children who were
moved to less noisy classrooms still showed greater distractibility one year later than
students who had always been in the quiet schools (Cohen et al, 1981 ). It should be noted
that the two groups of children had been carefully matched by the investigators so that
they were comparable in age, ethnicity, race, and social class.
97
```

[Original question page](assets/204bf1086a62fa1eefd87fc810ccc744918703fc5502a514e893a9fcc92829a3.jpg)

<!-- Source: /api/assets/d30aae5a0a538e2b7e60379641065a3361b4dcefbbdc6687c262ecc86b319d91.jpg; PDF page 103; full -->

```text
Test 4
Questions 27-29
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-29 on your answer sheet.
27 The writer suggests that people may have difficulty sleeping in the mountains because
A humans do not prefer peace and quiet to noise.
B they may be exposed to short bursts of very strange sounds.
C humans prefer to hear a certain amount of noise while they sleep.
D they may have adapted to a higher noise level in the city.
28 In noise experiments, Glass and Singer found that
A problem-solving is much easier under quiet conditions .
B physiological arousal prevents the ability to work .
C bursts of noise do not seriously disrupt problem-solving in the long term.
D the physiological arousal of control subjects declined quickly.
29 Researchers discovered that high noise levels are not likely to interfere with the
A successful performance of a single task .
B tasks of pilots or air traffic controllers.
C ability to repeat numbers while tracking moving lines.
D ability to monitor three dials at once.
98
```

[Original question page](assets/d30aae5a0a538e2b7e60379641065a3361b4dcefbbdc6687c262ecc86b319d91.jpg)

<!-- Source: /api/assets/0a9e51e429c71a1026458197f8ff646a4558364cd782d29cdb530855df5fb4fd.jpg; PDF page 104; full -->

```text
Reading
Questions 30-34
Complete the summary using the list of words and phrases, A-J, below.
Write the correct letter, A-J, in boxes 30-34 on your answer sheet.
NB You may use any letter more than once.
Glass and Singer (1972) showed that situations in which there is intense noise have
less effect on performance than circumstances in which 30 .......... .. ............ noise
occurs. Subjects were divided into groups to perform a task. Some heard loud bursts
of noise, others soft. For some subjects, the noise was predictable, while for others its
occurrence was random. All groups were exposed to 31 ........................ noise. The
predictable noise group 32 ............ ............ the unpredictable noise group on this task.
In the second part of the experiment, the four groups were given a proofreading task
to complete under conditions of no noise. They were required to check written material
for errors. The group which had been exposed to unpredictable noise 33 .......... ........ .... ..
the group which had been exposed to predictable noise. The group which had been
exposed to loud predictable noise performed better than those who had heard soft,
unpredictable bursts. The results suggest that 34 ........................ noise produces
fatigue but that this manifests itself later.
A no control over
B unexpected
C intense
D the same amount of
E performed better than
F performed at about the same level as
G no
H showed more irritation than
I made more mistakes than
J different types of
99
```

[Original question page](assets/0a9e51e429c71a1026458197f8ff646a4558364cd782d29cdb530855df5fb4fd.jpg)

<!-- Source: /api/assets/6edb1e0b922ddf0ae9bf2a620d519fa55561e57358a80dcb7ea020047479bdc3.jpg; PDF page 105; full -->

```text
Test4
Questions 35-40
Look at the following statements (Questions 35-40) and the list of researchers below.
Match each statement with the correct researcher(s), A-E.
Write the correct letter, A-E, in boxes 35-40 on your answer sheet.
NB You may use any letter more than once.
35 Subjects exposed to noise find it difficult at first to concentrate on problem-solving
tasks.
36 Long-term exposure to noise can produce changes in behaviour which can still be
observed a year later.
37 The problems associated with exposure to noise do not arise if the subject knows they
can make it stop.
38 Exposure to high-pitched noise results in more errors than exposure to low-pitched
noise.
39 Subjects find it difficult to perform three tasks at the same time when exposed to noise.
40 Noise affects a subject's capacity to repeat numbers while carrying out another task.
List of Researchers
A Glass and Singer
B Broadbent
C Finkelman and Glass
D Cohen et al.
E None of the above
100
```

[Original question page](assets/6edb1e0b922ddf0ae9bf2a620d519fa55561e57358a80dcb7ea020047479bdc3.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/25413c208cefbe0ec73ebec5363eb85b1aece3a665a185524a650e91e6f0998e.jpg; PDF page 106; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The pie charts below show units of electricity production by fuel source in Australia and France in 1980 and 2000.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the original figure is retained for the complete plotted data or diagram.]
```

[Original question page](assets/25413c208cefbe0ec73ebec5363eb85b1aece3a665a185524a650e91e6f0998e.jpg)

![Original figure](assets/25413c208cefbe0ec73ebec5363eb85b1aece3a665a185524a650e91e6f0998e.jpg)

### Task 2

<!-- Source: /api/assets/9c7128d3e2824b72ab91eb8e8eeacd9484922e99f13112080c0603c6a57c74ae.jpg; PDF page 107; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people think that universities should provide graduates with the knowledge and skills needed in the workplace. Others think that the true function of a university should be to give access to knowledge for its own sake, regardless of whether the course is useful to an employer.

What, in your opinion, should be the main function of a university?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/9c7128d3e2824b72ab91eb8e8eeacd9484922e99f13112080c0603c6a57c74ae.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/9667c36a095a9ab99e4e16fd7ac91fbe1a2aee36ac1cad1e1206c4a2b637e75c.jpg; PDF page 108; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics .
EXAMPLE
Travelling to work or college
• How do you usually travel to work or college? [Why?]
• Have you always travelled to work/college in the same way? [Why/Why not?]
• What do you like about travelling to work/college this way?
• What changes would improve the way you travel to work/college? [Why?]
PART 2
Describe a piece of electronic equipment that you find useful.
You should say: what it is; how you learned to use it; how long you have had it; and explain why you find this piece of electronic equipment useful.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Technology and housework
Example questions:
What kinds of machine are used for housework in modern homes in your country?
How have these machines benefited people? Are there any negative effects of using them?
Do you think all new homes will be equipped with household machines in the future? Why?
Technology in the workplace
Example questions:
What kinds of equipment do most workers need to use in offices today?
How have developments in technology affected employment in your country?
Some people think that technology has brought more stress than benefits to employed
people nowadays. Would you agree or disagree? Why?
103
```

[Original question page](assets/9667c36a095a9ab99e4e16fd7ac91fbe1a2aee36ac1cad1e1206c4a2b637e75c.jpg)

### Part 2

<!-- Source: /api/assets/9667c36a095a9ab99e4e16fd7ac91fbe1a2aee36ac1cad1e1206c4a2b637e75c.jpg; PDF page 108; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics .
EXAMPLE
Travelling to work or college
• How do you usually travel to work or college? [Why?]
• Have you always travelled to work/college in the same way? [Why/Why not?]
• What do you like about travelling to work/college this way?
• What changes would improve the way you travel to work/college? [Why?]
PART 2
Describe a piece of electronic equipment that you find useful.
You should say: what it is; how you learned to use it; how long you have had it; and explain why you find this piece of electronic equipment useful.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Technology and housework
Example questions:
What kinds of machine are used for housework in modern homes in your country?
How have these machines benefited people? Are there any negative effects of using them?
Do you think all new homes will be equipped with household machines in the future? Why?
Technology in the workplace
Example questions:
What kinds of equipment do most workers need to use in offices today?
How have developments in technology affected employment in your country?
Some people think that technology has brought more stress than benefits to employed
people nowadays. Would you agree or disagree? Why?
103
```

[Original question page](assets/9667c36a095a9ab99e4e16fd7ac91fbe1a2aee36ac1cad1e1206c4a2b637e75c.jpg)

### Part 3

<!-- Source: /api/assets/9667c36a095a9ab99e4e16fd7ac91fbe1a2aee36ac1cad1e1206c4a2b637e75c.jpg; PDF page 108; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics .
EXAMPLE
Travelling to work or college
• How do you usually travel to work or college? [Why?]
• Have you always travelled to work/college in the same way? [Why/Why not?]
• What do you like about travelling to work/college this way?
• What changes would improve the way you travel to work/college? [Why?]
PART 2
Describe a piece of electronic equipment that you find useful.
You should say: what it is; how you learned to use it; how long you have had it; and explain why you find this piece of electronic equipment useful.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Technology and housework
Example questions:
What kinds of machine are used for housework in modern homes in your country?
How have these machines benefited people? Are there any negative effects of using them?
Do you think all new homes will be equipped with household machines in the future? Why?
Technology in the workplace
Example questions:
What kinds of equipment do most workers need to use in offices today?
How have developments in technology affected employment in your country?
Some people think that technology has brought more stress than benefits to employed
people nowadays. Would you agree or disagree? Why?
103
```

[Original question page](assets/9667c36a095a9ab99e4e16fd7ac91fbe1a2aee36ac1cad1e1206c4a2b637e75c.jpg)
