# 剑雅 7 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 163

TEST 4 LISTENING
Section 1, Questions 1–10
1 Keiko
2 JO6337
3 4 months
4 (Advanced) English (Studies)
5 (young) children
6 pets
7 seafood
8 tennis
9 trains / (the) train
10 this / that afternoon
Section 2, Questions 11–20
11 C
12 B
13 A
14 B
15 car park
16 rose garden
17 café
18 cycling
19 biology lesson
20 viewing shelter
Section 3, Questions 21–30
21 5
22 assessed
23 A
24 B
25 A
26 C
27 media room
28 resources room
29 embassy
30 statistics / stats
Section 4, Questions 31–40
31 B
32 C
33 A
34 water
35–36 IN EITHER ORDER: meat; cheese
37 5th / new taste
38 common
39 bitterness
40 minerals
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. Keiko

2. JO6337

3. 4 months

4. English / English Studies / Advanced English / Advanced English Studies

5. children / young children

6. pets

7. seafood

8. tennis

9. trains / train / the train

10. this afternoon / that afternoon

### Part 2 · source page 163

TEST 4 LISTENING
Section 1, Questions 1–10
1 Keiko
2 JO6337
3 4 months
4 (Advanced) English (Studies)
5 (young) children
6 pets
7 seafood
8 tennis
9 trains / (the) train
10 this / that afternoon
Section 2, Questions 11–20
11 C
12 B
13 A
14 B
15 car park
16 rose garden
17 café
18 cycling
19 biology lesson
20 viewing shelter
Section 3, Questions 21–30
21 5
22 assessed
23 A
24 B
25 A
26 C
27 media room
28 resources room
29 embassy
30 statistics / stats
Section 4, Questions 31–40
31 B
32 C
33 A
34 water
35–36 IN EITHER ORDER: meat; cheese
37 5th / new taste
38 common
39 bitterness
40 minerals
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. C

12. B

13. A

14. B

15. car park

16. rose garden

17. café

18. cycling

19. biology lesson

20. viewing shelter

### Part 3 · source page 163

TEST 4 LISTENING
Section 1, Questions 1–10
1 Keiko
2 JO6337
3 4 months
4 (Advanced) English (Studies)
5 (young) children
6 pets
7 seafood
8 tennis
9 trains / (the) train
10 this / that afternoon
Section 2, Questions 11–20
11 C
12 B
13 A
14 B
15 car park
16 rose garden
17 café
18 cycling
19 biology lesson
20 viewing shelter
Section 3, Questions 21–30
21 5
22 assessed
23 A
24 B
25 A
26 C
27 media room
28 resources room
29 embassy
30 statistics / stats
Section 4, Questions 31–40
31 B
32 C
33 A
34 water
35–36 IN EITHER ORDER: meat; cheese
37 5th / new taste
38 common
39 bitterness
40 minerals
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. 5

22. assessed

23. A

24. B

25. A

26. C

27. media room

28. resources room

29. embassy

30. statistics / stats

### Part 4 · source page 163

TEST 4 LISTENING
Section 1, Questions 1–10
1 Keiko
2 JO6337
3 4 months
4 (Advanced) English (Studies)
5 (young) children
6 pets
7 seafood
8 tennis
9 trains / (the) train
10 this / that afternoon
Section 2, Questions 11–20
11 C
12 B
13 A
14 B
15 car park
16 rose garden
17 café
18 cycling
19 biology lesson
20 viewing shelter
Section 3, Questions 21–30
21 5
22 assessed
23 A
24 B
25 A
26 C
27 media room
28 resources room
29 embassy
30 statistics / stats
Section 4, Questions 31–40
31 B
32 C
33 A
34 water
35–36 IN EITHER ORDER: meat; cheese
37 5th / new taste
38 common
39 bitterness
40 minerals
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. B

32. C

33. A

34. water

35. meat / cheese

36. meat / cheese

37. 5th taste / new taste

38. common

39. bitterness

40. minerals

## A 类阅读

### Academic Reading · source page 164

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 TRUE
2 FALSE
3 NOT GIVEN
4 TRUE
5 FALSE
6 NOT GIVEN
7 TRUE
8 (wooden) pulleys
9 stone
10 (accomplished) sailors
11 (modern) glider
12 flight
13 messages
Reading Passage 2, Questions 14–26
14 FALSE
15 NOT GIVEN
16 TRUE
17 NOT GIVEN
18 TRUE
19 TRUE
20 FALSE
21 G
22 E
23 B
24 A
25 K
26 F
Reading Passage 3, Questions 27–40
27 D
28 C
29 A
30 B
31 D
32 F
33 I
34 B
35 A
36 D
37 A
38 E
39 B
40 C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. TRUE

2. FALSE

3. NOT GIVEN

4. TRUE

5. FALSE

6. NOT GIVEN

7. TRUE

8. pulleys / wooden pulleys

9. stone

10. sailors / accomplished sailors

11. glider / modern glider

12. flight

13. messages

14. FALSE

15. NOT GIVEN

16. TRUE

17. NOT GIVEN

18. TRUE

19. TRUE

20. FALSE

21. G

22. E

23. B

24. A

25. K

26. F

27. D

28. C

29. A

30. B

31. D

32. F

33. I

34. B

35. A

36. D

37. A

38. E

39. B

40. C

## A 类写作

### Writing material: c7-t4-w-1

Full original pies and legend inspected. These are labelled UNITS, not percentages. Australia 1980 total 100: coal50, oil10, natural gas20, hydro20, nuclear0 represented; Australia 2000 total170: coal130, oil2, gas2, hydro36, nuclear0 represented. France 1980 total90: coal25, oil20, gas25, hydro5, nuclear15; France 2000 total180: coal25, oil25, gas2, hydro2, nuclear126. Totals are the sum of each pie's units. Australia increasingly relies on coal, while France shifts strongly toward nuclear power. French total doubles; Australian total rises by 70 units rather than doubling. Australia's hydro output rises, while France's falls; gas falls sharply in both. Valid derived shares may be reported, but do not relabel the original unit counts as percentages.



### Writing material: c7-t4-w-2

The prompt gives contrasting purposes but asks which main function the writer supports. It does not literally use Discuss both views; do not impose a fixed balanced-essay structure or a predetermined answer.



## 口语
