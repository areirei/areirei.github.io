# 剑雅 16 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 125

TEST 3 LISTENING
1 park
2 blue
3 reference
4 story
5 rain
6 snack
7 medication
8 helmet
9 tent
10 199
11 A
12 C
13 B
14 C
15 D
16 F
17 A
18 H
19 C
20 G
21 C
22 D
23 C
24 E
25 C
26 A
27 B
28 A
29 A
30 C
31 grandmother
32 decade
33 equipment
34 economic
35 basic
36 round
37 bone
38 rough
39 style
40 sheep
11&12 IN EITHER ORDER: A,C
13&14 IN EITHER ORDER: B,C
21&22 IN EITHER ORDER: C,D
23&24 IN EITHER ORDER: C,E
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. park

2. blue

3. reference

4. story

5. rain

6. snack

7. medication

8. helmet

9. tent

10. 199

### Part 2 · source page 125

TEST 3 LISTENING
1 park
2 blue
3 reference
4 story
5 rain
6 snack
7 medication
8 helmet
9 tent
10 199
11 A
12 C
13 B
14 C
15 D
16 F
17 A
18 H
19 C
20 G
21 C
22 D
23 C
24 E
25 C
26 A
27 B
28 A
29 A
30 C
31 grandmother
32 decade
33 equipment
34 economic
35 basic
36 round
37 bone
38 rough
39 style
40 sheep
11&12 IN EITHER ORDER: A,C
13&14 IN EITHER ORDER: B,C
21&22 IN EITHER ORDER: C,D
23&24 IN EITHER ORDER: C,E
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A / C

12. A / C

13. B / C

14. B / C

15. D

16. F

17. A

18. H

19. C

20. G

### Part 3 · source page 125

TEST 3 LISTENING
1 park
2 blue
3 reference
4 story
5 rain
6 snack
7 medication
8 helmet
9 tent
10 199
11 A
12 C
13 B
14 C
15 D
16 F
17 A
18 H
19 C
20 G
21 C
22 D
23 C
24 E
25 C
26 A
27 B
28 A
29 A
30 C
31 grandmother
32 decade
33 equipment
34 economic
35 basic
36 round
37 bone
38 rough
39 style
40 sheep
11&12 IN EITHER ORDER: A,C
13&14 IN EITHER ORDER: B,C
21&22 IN EITHER ORDER: C,D
23&24 IN EITHER ORDER: C,E
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. C / D

22. C / D

23. C / E

24. C / E

25. C

26. A

27. B

28. A

29. A

30. C

### Part 4 · source page 125

TEST 3 LISTENING
1 park
2 blue
3 reference
4 story
5 rain
6 snack
7 medication
8 helmet
9 tent
10 199
11 A
12 C
13 B
14 C
15 D
16 F
17 A
18 H
19 C
20 G
21 C
22 D
23 C
24 E
25 C
26 A
27 B
28 A
29 A
30 C
31 grandmother
32 decade
33 equipment
34 economic
35 basic
36 round
37 bone
38 rough
39 style
40 sheep
11&12 IN EITHER ORDER: A,C
13&14 IN EITHER ORDER: B,C
21&22 IN EITHER ORDER: C,D
23&24 IN EITHER ORDER: C,E
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. grandmother

32. decade

33. equipment

34. economic

35. basic

36. round

37. bone

38. rough

39. style

40. sheep

## A 类阅读

### Academic Reading · source page 126

TEST 3 READING
1 FALSE
2 NOT GIVEN
3 FALSE
4 TRUE
5 TRUE
6 lightweight
7 bronze
8 levels
9 hull
10 triangular
11 music
12 grain
13 towboats
14 D
15 C
16 F
17 H
18 G
19 B
20 microorganisms / micro-organisms
21 reindeer
22 insects
23 B
24 C
25 A
26 C
27 NOT GIVEN
28 TRUE
29 TRUE
30 NOT GIVEN
31 FALSE
32 FALSE
33 H
34 D
35 G
36 C
37 A
38 warm (winter)
39 summer
40 mustard plant(s) / mustard
23&24 IN EITHER ORDER: B,C
25&26 IN EITHER ORDER: A,C
If you score: 1–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. FALSE

2. NOT GIVEN

3. FALSE

4. TRUE

5. TRUE

6. lightweight

7. bronze

8. levels

9. hull

10. triangular

11. music

12. grain

13. towboats

14. D

15. C

16. F

17. H

18. G

19. B

20. microorganisms / micro-organisms

21. reindeer

22. insects

23. B / C

24. B / C

25. A / C

26. A / C

27. NOT GIVEN

28. TRUE

29. TRUE

30. NOT GIVEN

31. FALSE

32. FALSE

33. H

34. D

35. G

36. C

37. A

38. warm / warm winter

39. summer

40. mustard plant / mustard plants / mustard

## A 类写作

### Writing material: c16-t3-w-1

Directly inspected both original Southwest Airport plans. Compare now with redevelopment next year; no compass orientation is supplied, so left/right and top/bottom refer to the printed plans. Gates increase from 8 in a short rectangular concourse to 18 in a longer Y-shaped concourse. A sky train replaces the walkway linking the terminal and gates. Departures remain on the left and arrivals on the right. Security and passport control on the departures side and passport control/customs on the arrivals side remain in the same terminal area. Shops are added beyond departure security toward the gates. On the departures side, check-in moves from the left to the right of the public hall; bag drop is added on the left, and the cafe moves from the upper-right of that hall to the lower-left near the entrances. The previously empty arrivals public hall gains a cafe and ATM on the right; car hire is in a new extension projecting to the right near the front. Additional entrance/exit openings are shown along the bottom. No runway or aircraft movement changes are depicted.



### Writing material: c16-t3-w-2

Evaluate making sugary manufactured foods/drinks more expensive to reduce sugar consumption. Preserve proposed price measure; general health advice alone does not answer it. No required stance.



## 口语
