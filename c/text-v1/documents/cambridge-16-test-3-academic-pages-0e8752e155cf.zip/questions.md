# 剑雅 16 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/fca43c05d9f4c09e1f3628b1b413ebefa0cb8804e84a4821dc7d80a248d9102c.jpg; PDF page 55; full -->

```text
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
JUNIOR CYCLE CAMP
The course focuses on skills and safety.
• Charlie would be placed in Level 5.
• First of all, children at this level are taken to practise in a (1) __________.
Instructors
• Instructors wear (2) __________ shirts.
• A (3) __________ is required and training is given.
Classes
• The size of the classes is limited.
• There are quiet times during the morning for a (4) __________ or a game.
• Classes are held even if there is (5) __________.
What to bring
• a change of clothing
• a (6) __________
• shoes (not sandals)
• Charlie’s (7) __________
Day 1
• Charlie should arrive at 9.20 am on the first day.
• Before the class, his (8) __________ will be checked.
• He should then go to the (9) __________ to meet his class instructor.
Cost
• The course costs (10) $ __________ per week.
```

[Original question page](assets/fca43c05d9f4c09e1f3628b1b413ebefa0cb8804e84a4821dc7d80a248d9102c.jpg)

### Part 2

<!-- Source: /api/assets/8c83d2f982b09adf036d05a53dd97198fd05ba533306acd4c0474c9a9a0627d4.jpg; PDF page 56; full -->

```text
PART 2 Questions 11–20
Questions 11 and 12
Choose TWO letters, A–E.
According to Megan, what are the TWO main advantages of working in the agriculture and horticulture sectors?
A the active lifestyle
B the above-average salaries
C the flexible working opportunities
D the opportunities for overseas travel
E the chance to be in a natural environment
Questions 13 and 14
Choose TWO letters, A–E.
Which TWO of the following are likely to be disadvantages for people working outdoors?
A the increasing risk of accidents
B being in a very quiet location
C difficult weather conditions at times
D the cost of housing
E the level of physical fitness required
```

[Original question page](assets/8c83d2f982b09adf036d05a53dd97198fd05ba533306acd4c0474c9a9a0627d4.jpg)

<!-- Source: /api/assets/bfd56db1b3a933c3df6ec1b3114b40f146535fc23dbfdf7daea007b1172f1977.jpg; PDF page 57; full -->

```text
Questions 15–20
What information does Megan give about each of the following job opportunities?
Choose SIX answers from the box and write the correct letter, A–H, next to Questions 15–20.
Information
A not a permanent job
B involves leading a team
C experience not essential
D intensive work but also fun
E chance to earn more through overtime
F chance for rapid promotion
G accommodation available
H local travel involved
Job opportunities
15 Fresh food commercial manager __________
16 Agronomist __________
17 Fresh produce buyer __________
18 Garden centre sales manager __________
19 Tree technician __________
20 Farm worker __________
```

[Original question page](assets/bfd56db1b3a933c3df6ec1b3114b40f146535fc23dbfdf7daea007b1172f1977.jpg)

### Part 3

<!-- Source: /api/assets/5638de0ce78f1e745b3c9e99445e7e6542702bdbc65519f4e41c5afcbf8e6617.jpg; PDF page 58; full -->

```text
PART 3 Questions 21–30
Questions 21 and 22
Choose TWO letters, A–E.
Which TWO points does Adam make about his experiment on artificial sweeteners?
A The results were what he had predicted.
B The experiment was simple to set up.
C A large sample of people was tested.
D The subjects were unaware of what they were drinking.
E The test was repeated several times for each person.
Questions 23 and 24
Choose TWO letters, A–E.
Which TWO problems did Rosie have when measuring the fat content of nuts?
A She used the wrong sort of nuts.
B She used an unsuitable chemical.
C She did not grind the nuts finely enough.
D The information on the nut package was incorrect.
E The weighing scales may have been unsuitable.
```

[Original question page](assets/5638de0ce78f1e745b3c9e99445e7e6542702bdbc65519f4e41c5afcbf8e6617.jpg)

<!-- Source: /api/assets/cad568fe07d6f7c94715379e2876a40782e5d7fd91dc3c906534bad96c4590f8.jpg; PDF page 59; full -->

```text
Listening
Questions 25-30
Choose the correct letter, A, B or C.
25 Adam suggests that restaurants could reduce obesity if their menus
A offered fewer options.
B had more low-calorie foods.
C were organised in a particular way.
26 The students agree that food manufacturers deliberately
A make calorie counts hard to understand.
B fail to provide accurate calorie counts.
C use ineffective methods to reduce calories.
27 What does Rosie say about levels of exercise in England?
A The amount recommended is much too low.
B Most people overestimate how much they do.
C Women now exercise more than they used to.
28 Adam refers to the location and width of stairs in a train station to illustrate
A practical changes that can influence people’s behaviour.
B methods of helping people who have mobility problems.
C ways of preventing accidents by controlling crowd movement.
29 What do the students agree about including reference to exercise in their
presentation?
A They should probably leave it out.
B They need to do more research on it.
C They should discuss this with their tutor.
30 What are the students going to do next for their presentation?
A prepare some slides for it
B find out how long they have for it
C decide on its content and organisation
>|@ p. 125||@ p.112| 59
```

[Original question page](assets/cad568fe07d6f7c94715379e2876a40782e5d7fd91dc3c906534bad96c4590f8.jpg)

### Part 4

<!-- Source: /api/assets/53b28371c115e353ed1e8df31f2d2575a7295bc0d20c72be0fdd6c507f47010b.jpg; PDF page 60; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Hand knitting
Interest in knitting
• Knitting has a long history around the world.
• We imagine someone like a (31) __________ knitting.
• A (32) __________ ago, knitting was expected to disappear.
• The number of knitting classes is now increasing.
• People are buying more (33) __________ for knitting nowadays.
Benefits of knitting
• gives support in times of (34) __________ difficulty
• requires only (35) __________ skills and little money to start
• reduces stress in a busy life
Early knitting
• The origins are not known.
• Findings show early knitted items to be (36) __________ in shape.
• The first needles were made of natural materials such as wood and (37) __________.
• Early yarns felt (38) __________ to touch.
• Wool became the most popular yarn for spinning.
• Geographical areas had their own (39) __________ of knitting.
• Everyday tasks like looking after (40) __________ were done while knitting.
```

[Original question page](assets/53b28371c115e353ed1e8df31f2d2575a7295bc0d20c72be0fdd6c507f47010b.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/55b94d848984bf0b739561631e514a3b24e633d6f3bd30074d7a3b4e033c12e2.jpg; PDF page 61; full -->

```text
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Roman shipbuilding and navigation
Shipbuilding today is based on science and ships are built using computers and sophisticated
tools. Shipbuilding in ancient Rome, however, was more of an art relying on estimation, inherited
techniques and personal experience. The Romans were not traditionally sailors but mostly land-
based people, who learned to build ships from the people that they conquered, namely the Greeks
and the Egyptians.
There are a few surviving written documents that give descriptions and representations of ancient
Roman ships, including the sails and rigging. Excavated vessels also provide some clues about
ancient shipbuilding techniques. Studies of these have taught us that ancient Roman shipbuilders
built the outer hull first, then proceeded with the frame and the rest of the ship. Planks used to
build the outer hull were initially sewn together. Starting from the 6th century BCE, they were
fixed using a method called mortise and tenon, whereby one plank locked into another without
the need for stitching. Then in the first centuries of the current era, Mediterranean shipbuilders
shifted to another shipbuilding method, still in use today, which consisted of building the frame
first and then proceeding with the hull and the other components of the ship. This method was
more systematic and dramatically shortened ship construction times. The ancient Romans built
large merchant ships and warships whose size and technology were unequalled until the 16th
century CE.
Warships were built to be lightweight and very speedy. They had to be able to sail near the coast,
which is why they had no ballast or excess load and were built with a long, narrow hull. They did
not sink when damaged and often would lie crippled on the sea’s surface following naval battles.
They had a bronze battering ram, which was used to pierce the timber hulls or break the oars of
enemy vessels. Warships used both wind (sails) and human power (oarsmen) and were therefore
very fast. Eventually, Rome’s navy became the largest and most powerful in the Mediterranean,
and the Romans had control over what they therefore called Mare Nostrum meaning ‘our sea’.
There were many kinds of warship. The ‘trireme’ was the dominant warship from the 7th to 4th
century BCE. It had rowers in the top, middle and lower levels, and approximately 50 rowers in
each bank. The rowers at the bottom had the most uncomfortable position as they were under the
other rowers and were exposed to the water entering through the oar-holes. It is worth noting that
contrary to popular perception, rowers were not slaves but mostly Roman citizens enrolled in the
military. The trireme was superseded by larger ships with even more rowers.
61
```

[Original question page](assets/55b94d848984bf0b739561631e514a3b24e633d6f3bd30074d7a3b4e033c12e2.jpg)

<!-- Source: /api/assets/04a2ac96d7eab55b4b013f6b211e2bff36a519106aac893d55edd622d6a85e6b.jpg; PDF page 62; full -->

```text
Test 3
Merchant ships were built to transport lots of cargo over long distances and at a reasonable cost.
They had a wider hull, double planking and a solid interior for added stability. Unlike warships,
their V-shaped hull was deep underwater, meaning that they could not sail too close to the coast.
They usually had two huge side rudders located off the stern and controlled by a small tiller bar
connected to a system of cables. They had from one to three masts with large square sails and a
small triangular sail at the bow. Just like warships, merchant ships used oarsmen, but coordinating
the hundreds of rowers in both types of ship was not an easy task. In order to assist them, music
would be played on an instrument, and oars would then keep time with this.
The cargo on merchant ships included raw materials (e.g. iron bars, copper, marble and granite),
and agricultural products (e.g. grain from Egypt’s Nile valley). During the Empire, Rome was a
huge city by ancient standards of about one million inhabitants. Goods from all over the world
would come to the city through the port of Pozzuoli situated west of the bay of Naples in Italy and
through the gigantic port of Ostia situated at the mouth of the Tiber River. Large merchant ships
would approach the destination port and, just like today, be intercepted by a number of towboats
that would drag them to the quay.
The time of travel along the many sailing routes could vary widely. Navigation in ancient
Rome did not rely on sophisticated instruments such as compasses but on experience, local
knowledge and observation of natural phenomena. In conditions of good visibility, seamen in the
Mediterranean often had the mainland or islands in sight, which greatly facilitated navigation. They
sailed by noting their position relative to a succession of recognisable landmarks. When weather
conditions were not good or where land was no longer visible, Roman mariners estimated directions
from the pole star or, with less accuracy, from the Sun at noon. They also estimated directions
relative to the wind and swell. Overall, shipping in ancient Roman times resembled shipping
today with large vessels regularly crossing the seas and bringing supplies from their Empire.
62
```

[Original question page](assets/04a2ac96d7eab55b4b013f6b211e2bff36a519106aac893d55edd622d6a85e6b.jpg)

<!-- Source: /api/assets/c47ed0635f58a3d2c0633e76b7d0c4b9f4b38a2780b2dee893058e226f109aac.jpg; PDF page 63; full -->

```text
Reading
Questions 1-5
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-5 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 The Romans’ shipbuilding skills were passed on to the Greeks and the Egyptians.
2 Skilled craftsmen were needed for the mortise and tenon method of fixing planks.
3. The later practice used by Mediterranean shipbuilders involved building the hull
before the frame.
4 The Romans called the Mediterranean Sea Mare Nostrum because they dominated
its use.
5 Most rowers on ships were people from the Roman army.
63
```

[Original question page](assets/c47ed0635f58a3d2c0633e76b7d0c4b9f4b38a2780b2dee893058e226f109aac.jpg)

<!-- Source: /api/assets/6c4f67916fb1c82aafaa29229e82b7dc3b268538e862a4dcd6952de8154580b7.jpg; PDF page 64; full -->

```text
Test 3
Questions 6-13
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 6-13 on your answer sheet.
Warships and merchant ships
Warships were designed so that they were (6) __________ and moved quickly. They often remained afloat after battles and were able to sail close to land as they lacked any additional weight. A battering ram made of (7) __________ was included in the design for attacking and damaging the timber and oars of enemy ships. Warships, such as the ‘trireme’, had rowers on three different (8) __________.
Unlike warships, merchant ships had a broad (9) __________ that lay far below the surface of the sea. Merchant ships were steered through the water with the help of large rudders and a tiller bar. They had both square and (10) __________ sails. On merchant ships and warships, (11) __________ was used to ensure rowers moved their oars in and out of the water at the same time.
Quantities of agricultural goods such as (12) __________ were transported by merchant ships to two main ports in Italy. The ships were pulled to the shore by (13) __________. When the weather was clear and they could see islands or land, sailors used landmarks that they knew to help them navigate their route.
```

[Original question page](assets/6c4f67916fb1c82aafaa29229e82b7dc3b268538e862a4dcd6952de8154580b7.jpg)

<!-- Source: /api/assets/35d1224a66d0df500b29796313a2e14fa5d41a31ce67a824a68372769787e860.jpg; PDF page 65; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Climate change reveals ancient artefacts in Norway’s glaciers
A Well above the treeline in Norway’s highest mountains, ancient fields of ice are shrinking
as Earth’s climate warms. As the ice has vanished, it has been giving up the treasures it has
preserved in cold storage for the last 6,000 years — items such as ancient arrows and skis
from Viking Age* traders. And those artefacts have provided archaeologists with some
surprising insights into how ancient Norwegians made their livings.
B Organic materials like textiles and hides are relatively rare finds at archaeological sites.
This is because unless they’re protected from the microorganisms that cause decay, they
tend not to last long. Extreme cold is one reliable way to keep artefacts relatively fresh
for a few thousand years, but once thawed out, these materials experience degradation
relatively swiftly.
With climate change shrinking ice cover around the world, glacial archaeologists need to
race the clock to find newly revealed artefacts, preserve them, and study them. If something
fragile dries and is windblown it might very soon be lost to science, or an arrow might
be exposed and then covered again by the next snow and remain well-preserved. The
unpredictability means that glacial archaeologists have to be systematic in their approach
to fieldwork.
C Over a nine-year period, a team of archaeologists, which included Lars Pilø of Oppland
County Council, Norway, and James Barrett of the McDonald Institute for Archaeological
Research, surveyed patches of ice in Oppland, an area of south-central Norway that is home
to some of the country’s highest mountains. Reindeer once congregated on these icy patches
in the later summer months to escape biting insects, and from the late Stone Age**, hunters
followed. In addition, trade routes threaded through the mountain passes of Oppland, linking
settlements in Norway to the rest of Europe.
The slow but steady movement of glaciers tends to destroy anything at their bases, so the
team focused on stationary patches of ice, mostly above 1,400 metres. That ice is found
amid fields of frost-weathered boulders, fallen rocks, and exposed bedrock that for nine
months of the year is buried beneath snow.
“Fieldwork is hard work — hiking with all our equipment, often camping on permafrost —
but very rewarding. You’re rescuing the archaeology, bringing the melting ice to wider
attention, discovering a unique environmental history and really connecting with the natural
environment,’ says Barrett.
*Viking Age: a period of European history from around 700 CE to around 1050 CE when Scandinavian Vikings migrated throughout
Europe by means of trade and warfare
** The Stone Age: a period in early history that began about 3.4 million years ago
65
```

[Original question page](assets/35d1224a66d0df500b29796313a2e14fa5d41a31ce67a824a68372769787e860.jpg)

<!-- Source: /api/assets/da815835e02bfd42466377b2d952d7ce188f378fbf40b335be9128656feee888.jpg; PDF page 66; full -->

```text
Test 3

66
D At the edges of the contracting ice patches, archaeologists found more than 2,000
artefacts, which formed a material record that ran from 4,000 BCE to the beginnings of the
Renaissance in the 14th century. Many of the artefacts are associated with hunting. Hunters
would have easily misplaced arrows and they often discarded broken bows rather than take
them all the way home. Other items could have been used by hunters traversing the high
mountain passes of Oppland: all-purpose items like tools, skis, and horse tack.
E Barrett’s team radiocarbon-dated 153 of the artefacts and compared those dates to the timing
of major environmental changes in the region — such as periods of cooling or warming — and
major social and economic shifts — such as the growth of farming settlements and the spread
of international trade networks leading up to the Viking Age. They found that some periods
had produced lots of artefacts, which indicates that people had been pretty active in the
mountains during those times. But there were few or no signs of activity during other periods.
F What was surprising, according to Barrett, was the timing of these periods. Oppland’s
mountains present daunting terrain and in periods of extreme cold, glaciers could block the
higher mountain passes and make travel in the upper reaches of the mountains extremely
difficult. Archaeologists assumed people would stick to lower elevations during a time
like the Late Antique Little Ice Age, a short period of deeper-than-usual cold from about
536-600 CE. But it turned out that hunters kept regularly venturing into the mountains
even when the climate turned cold, based on the amount of stuff they had apparently
dropped there.
‘Remarkably, though, the finds from the ice may have continued through this period,
perhaps suggesting that the importance of mountain hunting increased to supplement
failing agricultural harvests in times of low temperatures,’ says Barrett. A colder turn in the
Scandinavian climate would likely have meant widespread crop failures, so more people
would have depended on hunting to make up for those losses.
G Many of the artefacts Barrett’s team recovered date from the beginning of the Viking Age,
the 700s through to the 900s CE. Trade networks connecting Scandinavia with Europe and
the Middle East were expanding around this time. Although we usually think of ships when
we think of Scandinavian expansion, these recent discoveries show that plenty of goods
travelled on overland routes, like the mountain passes of Oppland. And growing Norwegian
towns, along with export markets, would have created a booming demand for hides to fight
off the cold, as well as antlers to make useful things like combs. Business must have been
good for hunters.
H Norway’s mountains are probably still hiding a lot of history — and prehistory — in remote
ice patches. When Barrett’s team looked at the dates for their sample of 153 artefacts,
they noticed a gap with almost no artefacts from about 3,800 to 2,200 BCE. In fact,
archaeological finds from that period are rare all over Norway. The researchers say that
could be because many of those artefacts have already disintegrated or are still frozen in the
ice. That means archaeologists could be extracting some of those artefacts from retreating
ice in years to come.
```

[Original question page](assets/da815835e02bfd42466377b2d952d7ce188f378fbf40b335be9128656feee888.jpg)

<!-- Source: /api/assets/9776ffc1bbaac6b6a9a36a9a6a00b3875c8080614f19510f6a831b1c23ae5407.jpg; PDF page 67; full -->

```text
Reading
Questions 14-19
Reading Passage 2 has eight sections, A-H.
Which section contains the following information?
Write the correct letter, A-H, in boxes 14—19 on your answer sheet.
14 an explanation for weapons being left behind in the mountains
15 a reference to the physical difficulties involved in an archaeological expedition
16 an explanation of why less food may have been available
17 a reference to the possibility of future archaeological discoveries
18 examples of items that would have been traded
19 a reference to the pressure archaeologists are under to work quickly
Questions 20-22
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 20-22 on your answer sheet.
Interesting finds at an archaeological site
Organic materials such as animal skins and textiles are not discovered very often at
archaeological sites. They have little protection against (20) __________,
which means that they decay relatively quickly. But this is not always the case.
If temperatures are low enough, fragile artefacts can be preserved for thousands
of years.
A team of archaeologists have been working in the mountains in Oppland in Norway
to recover artefacts revealed by shrinking ice cover. In the past, there were trade
routes through these mountains and (21) __________ gathered there in
the summer months to avoid being attacked by (22) __________ on lower
ground. The people who used these mountains left things behind and it is those
objects that are of interest to archaeologists.
```

[Original question page](assets/9776ffc1bbaac6b6a9a36a9a6a00b3875c8080614f19510f6a831b1c23ae5407.jpg)

<!-- Source: /api/assets/4216fde52533dd7ff4651d268d48f68090212630624af96e9a981e2592fd534e.jpg; PDF page 68; full -->

```text
Test 3
Questions 23 and 24
Choose TWO letters, A-E.
Write the correct letters in boxes 23 and 24 on your answer sheet.
Which TWO of the following statements does the writer make about the discoveries of
Barrett's team?
A Artefacts found in the higher mountain passes were limited to
skiing equipment.
B Hunters went into the mountains even during periods of extreme cold.
C The number of artefacts from certain time periods was relatively low.
D Radiocarbon dating of artefacts produced some unreliable results.
E More artefacts were found in Oppland than at any other mountain site.
Questions 25 and 26
Choose TWO letters, A-E.
Write the correct letters in boxes 25 and 26 on your answer sheet.
Which TWO of the following statements does the writer make about the Viking Age?
A Hunters at this time benefited from an increased demand for goods.
B The beginning of the period saw the greatest growth in the wealth of Vikings.
C Vikings did not rely on ships alone to transport goods.
D Norwegian towns at this time attracted traders from around the world.
E Vikings were primarily interested in their trading links with the Middle East.
```

[Original question page](assets/4216fde52533dd7ff4651d268d48f68090212630624af96e9a981e2592fd534e.jpg)

<!-- Source: /api/assets/7568a4d98cf9f56930cbee0b4b80435e1a2c00ed9fb815e0a898955c5b07b5a9.jpg; PDF page 69; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Plant ‘thermometer’ triggers springtime growth by
measuring night-time heat
A photoreceptor molecule in plant cells has been found to have a second job
as a thermometer after dark — allowing plants to read seasonal temperature
changes. Scientists say the discovery could help breed crops that are more
resilient to the temperatures expected to result from climate change
A An international team of scientists led by the University of Cambridge has
discovered that the ‘thermometer’ molecule in plants enables them to develop
according to seasonal temperature changes. Researchers have revealed that
molecules called phytochromes — used by plants to detect light during the day —
actually change their function in darkness to become cellular temperature gauges
that measure the heat of the night.
The new findings, published in the journal Science, show that phytochromes control
genetic switches in response to temperature as well as light to dictate plant development.
B At night, these molecules change states, and the pace at which they change is
‘directly proportional to temperature’, say scientists, who compare phytochromes
to mercury in a thermometer. The warmer it is, the faster the molecular change —
stimulating plant growth.
C Farmers and gardeners have known for hundreds of years how responsive plants are
to temperature: warm winters cause many trees and flowers to bud early, something
humans have long used to predict weather and harvest times for the coming year. The
latest research pinpoints for the first time a molecular mechanism in plants that reacts
to temperature — often triggering the buds of spring we long to see at the end of winter.
D With weather and temperatures set to become ever more unpredictable due to
climate change, researchers say the discovery that this light-sensing molecule also
functions as the internal thermometer in plant cells could help us breed tougher
crops. ‘It is estimated that agricultural yields will need to double by 2050, but
climate change is a major threat to achieving this. Key crops such as wheat and rice
are sensitive to high temperatures. Thermal stress reduces crop yields by around
10% for every one degree increase in temperature,’ says lead researcher Dr Philip
Wigge from Cambridge’s Sainsbury Laboratory. ‘Discovering the molecules that
allow plants to sense temperature has the potential to accelerate the breeding of
crops resilient to thermal stress and climate change.”
69
```

[Original question page](assets/7568a4d98cf9f56930cbee0b4b80435e1a2c00ed9fb815e0a898955c5b07b5a9.jpg)

<!-- Source: /api/assets/8425b2395e3348a36dd5717c717ddff87196514f8c4ec1096df4658c6b59c64a.jpg; PDF page 70; full -->

```text
Test 3

70
E In their active state, phytochrome molecules bind themselves to DNA to restrict
plant growth. During the day, sunlight activates the molecules, slowing down
growth. If a plant finds itself in shade, phytochromes are quickly inactivated —
enabling it to grow faster to find sunlight again. This is how plants compete to
escape each other’s shade. ‘Light-driven changes to phytochrome activity occur very
fast, in less than a second,’ says Wigge.
At night, however, it’s a different story. Instead of a rapid deactivation following
sundown, the molecules gradually change from their active to inactive state. This is
called ‘dark reversion’. ‘Just as mercury rises in a thermometer, the rate at which
phytochromes revert to their inactive state during the night is a direct measure of
temperature,’ says Wigge.
F ‘The lower the temperature, the slower the rate at which phytochromes revert to
inactivity, so the molecules spend more time in their active, growth-suppressing
state. This is why plants are slower to grow in winter. Warm temperatures accelerate
dark reversion, so that phytochromes rapidly reach an inactive state and detach
themselves from the plant’s DNA — allowing genes to be expressed and plant growth
to resume.’ Wigge believes phytochrome thermo-sensing evolved at a later stage,
and co-opted the biological network already used for light-based growth during the
downtime of night.
G Some plants mainly use day length as an indicator of the season. Other species, such
as daffodils, have considerable temperature sensitivity, and can flower months in
advance during a warm winter. In fact, the discovery of the dual role of phytochromes
provides the science behind a well-known rhyme long used to predict the coming
season: oak before ash we’ll have a splash, ash before oak we’re in for a soak.
Wigge explains: ‘Oak trees rely much more on temperature, likely using
phytochromes as thermometers to dictate development, whereas ash trees rely on
measuring day length to determine their seasonal timing. A warmer spring, and
consequently a higher likeliness of a hot summer, will result in oak leafing before
ash. A cold spring will see the opposite. As the British know only too well, a colder
summer is likely to be a rain-soaked one.’
H The new findings are the culmination of twelve years of research involving scientists
from Germany, Argentina and the US, as well as the Cambridge team. The work was
done in a model system, using a mustard plant called Arabidopsis, but Wigge says
the phytochrome genes necessary for temperature sensing are found in crop plants as
well. ‘Recent advances in plant genetics now mean that scientists are able to rapidly
identify the genes controlling these processes in crop plants, and even alter their
activity using precise molecular “scalpels”,’ adds Wigge. ‘Cambridge is uniquely
well-positioned to do this kind of research as we have outstanding collaborators
nearby who work on more applied aspects of plant biology, and can help us transfer
this new knowledge into the field.’
```

[Original question page](assets/8425b2395e3348a36dd5717c717ddff87196514f8c4ec1096df4658c6b59c64a.jpg)

<!-- Source: /api/assets/b6d6872d6af2571534bb27aaac58d162413c674b87f40f65a3a0d0f0375ba9ef.jpg; PDF page 71; full -->

```text
Reading
Questions 27-32
Do the following statements agree with the information given in Reading Passage 3?
In boxes 27-32 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
27 The Cambridge scientists’ discovery of the ‘thermometer molecule’ caused surprise
among other scientists.
28 The target for agricultural production by 2050 could be missed.
29 Wheat and rice suffer from a rise in temperatures.
30 It may be possible to develop crops that require less water.
31 Plants grow faster in sunlight than in shade.
32 Phytochromes change their state at the same speed day and night.
Questions 33-37
Reading Passage 3 has eight sections, A-H.
Which section contains the following information?
Write the correct letter, A-H, in boxes 33-37 on your answer sheet.
33 mention of specialists who can make use of the research findings
34 a reference to a potential benefit of the research findings
35 scientific support for a traditional saying
36 a reference to people traditionally making plans based on plant behaviour
37 a reference to where the research has been reported
71
```

[Original question page](assets/b6d6872d6af2571534bb27aaac58d162413c674b87f40f65a3a0d0f0375ba9ef.jpg)

<!-- Source: /api/assets/e6d407cb1115619dc9d331ea9923c6b6fe7cab212aa0e00a79b3517ef26f2e80.jpg; PDF page 72; full -->

```text
Questions 38–40
Complete the sentences below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 38–40 on your answer sheet.
38 Daffodils are likely to flower early in response to __________ weather.
39 If ash trees come into leaf before oak trees, the weather in __________ will probably be wet.
40 The research was carried out using a particular species of __________.
```

[Original question page](assets/e6d407cb1115619dc9d331ea9923c6b6fe7cab212aa0e00a79b3517ef26f2e80.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/217d3a642da3e07f8cdaebe2010e652122c815fff18ab893e5a6a11f269adcd6.jpg; PDF page 73; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The plans below show the site of an airport now and how it will look after redevelopment next year.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

Figure: SOUTHWEST AIRPORT — NOW / AFTER DEVELOPMENT.
See the retained original diagram for its labelled stages or spatial layout.
```

[Original question page](assets/217d3a642da3e07f8cdaebe2010e652122c815fff18ab893e5a6a11f269adcd6.jpg)

![Original figure](assets/217d3a642da3e07f8cdaebe2010e652122c815fff18ab893e5a6a11f269adcd6.jpg)

### Task 2

<!-- Source: /api/assets/33ddacb2f459228c000957af71c69b2b106372c57e617521efb44d79be314dfe.jpg; PDF page 74; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Many manufactured food and drink products contain high levels of sugar, which causes many health problems. Sugary products should be made more expensive to encourage people to consume less sugar.

Do you agree or disagree?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/33ddacb2f459228c000957af71c69b2b106372c57e617521efb44d79be314dfe.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/c9d1080220771a8f3c08ac7ae2a990db0e8d45dafeaf677d4b4215130c1b95f3.jpg; PDF page 75; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Summer
* Is summer your favourite time of year? [Why/Why not?]
+ What do you do in summer when the weather’s very hot? [Why?]
* Do you go on holiday every summer? [Why/Why not?]
* Did you enjoy the summer holidays when you were at school? [Why/Why not?]
PART 2
Describe a luxury item you would like to own in the future.
You should say:
what item you would like to own
what this item looks like
why you would like to own this item
and explain whether you think you will ever own this item.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Expensive items
Example questions:
Which expensive items would many young people (in your country) like to buy?
How do the expensive items that younger people want to buy differ from those that older
people want to buy?
Do you think that people are more likely to buy expensive items for their friends or for
themselves?
Rich people
Example questions:
How difficult is it to become very rich in today’s world?
Do you agree that money does not necessarily bring happiness?
In what ways might rich people use their money to help society?
75
```

[Original question page](assets/c9d1080220771a8f3c08ac7ae2a990db0e8d45dafeaf677d4b4215130c1b95f3.jpg)

### Part 2

<!-- Source: /api/assets/c9d1080220771a8f3c08ac7ae2a990db0e8d45dafeaf677d4b4215130c1b95f3.jpg; PDF page 75; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Summer
* Is summer your favourite time of year? [Why/Why not?]
+ What do you do in summer when the weather’s very hot? [Why?]
* Do you go on holiday every summer? [Why/Why not?]
* Did you enjoy the summer holidays when you were at school? [Why/Why not?]
PART 2
Describe a luxury item you would like to own in the future.
You should say:
what item you would like to own
what this item looks like
why you would like to own this item
and explain whether you think you will ever own this item.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Expensive items
Example questions:
Which expensive items would many young people (in your country) like to buy?
How do the expensive items that younger people want to buy differ from those that older
people want to buy?
Do you think that people are more likely to buy expensive items for their friends or for
themselves?
Rich people
Example questions:
How difficult is it to become very rich in today’s world?
Do you agree that money does not necessarily bring happiness?
In what ways might rich people use their money to help society?
75
```

[Original question page](assets/c9d1080220771a8f3c08ac7ae2a990db0e8d45dafeaf677d4b4215130c1b95f3.jpg)

### Part 3

<!-- Source: /api/assets/c9d1080220771a8f3c08ac7ae2a990db0e8d45dafeaf677d4b4215130c1b95f3.jpg; PDF page 75; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Summer
* Is summer your favourite time of year? [Why/Why not?]
+ What do you do in summer when the weather’s very hot? [Why?]
* Do you go on holiday every summer? [Why/Why not?]
* Did you enjoy the summer holidays when you were at school? [Why/Why not?]
PART 2
Describe a luxury item you would like to own in the future.
You should say:
what item you would like to own
what this item looks like
why you would like to own this item
and explain whether you think you will ever own this item.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Expensive items
Example questions:
Which expensive items would many young people (in your country) like to buy?
How do the expensive items that younger people want to buy differ from those that older
people want to buy?
Do you think that people are more likely to buy expensive items for their friends or for
themselves?
Rich people
Example questions:
How difficult is it to become very rich in today’s world?
Do you agree that money does not necessarily bring happiness?
In what ways might rich people use their money to help society?
75
```

[Original question page](assets/c9d1080220771a8f3c08ac7ae2a990db0e8d45dafeaf677d4b4215130c1b95f3.jpg)
