# 剑雅 17 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 124

TEST 4 LISTENING
1 floor(s)
2 fridge
3 shirts
4 windows
5 balcony
6 electrician
7 dust
8 police
9 training
10 review
11 A
12 A
13 A
14 C
15 A
16 C
17 B
18 C
19 B
20 A
21 C
22 E
23 A
24 D
25 B
26 F
27 A
28 D
29 C
30 G
31 golden
32 healthy
33 climate
34 rock(s)
35 diameter
36 tube
37 fire
38 steam
39 cloudy
40 litre / liter
21&22 IN EITHER ORDER: C,E
23&24 IN EITHER ORDER: A,D
If you score: 1–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. floor / floors

2. fridge

3. shirts

4. windows

5. balcony

6. electrician

7. dust

8. police

9. training

10. review

### Part 2 · source page 124

TEST 4 LISTENING
1 floor(s)
2 fridge
3 shirts
4 windows
5 balcony
6 electrician
7 dust
8 police
9 training
10 review
11 A
12 A
13 A
14 C
15 A
16 C
17 B
18 C
19 B
20 A
21 C
22 E
23 A
24 D
25 B
26 F
27 A
28 D
29 C
30 G
31 golden
32 healthy
33 climate
34 rock(s)
35 diameter
36 tube
37 fire
38 steam
39 cloudy
40 litre / liter
21&22 IN EITHER ORDER: C,E
23&24 IN EITHER ORDER: A,D
If you score: 1–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A

12. A

13. A

14. C

15. A

16. C

17. B

18. C

19. B

20. A

### Part 3 · source page 124

TEST 4 LISTENING
1 floor(s)
2 fridge
3 shirts
4 windows
5 balcony
6 electrician
7 dust
8 police
9 training
10 review
11 A
12 A
13 A
14 C
15 A
16 C
17 B
18 C
19 B
20 A
21 C
22 E
23 A
24 D
25 B
26 F
27 A
28 D
29 C
30 G
31 golden
32 healthy
33 climate
34 rock(s)
35 diameter
36 tube
37 fire
38 steam
39 cloudy
40 litre / liter
21&22 IN EITHER ORDER: C,E
23&24 IN EITHER ORDER: A,D
If you score: 1–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. C / E

22. C / E

23. A / D

24. A / D

25. B

26. F

27. A

28. D

29. C

30. G

### Part 4 · source page 124

TEST 4 LISTENING
1 floor(s)
2 fridge
3 shirts
4 windows
5 balcony
6 electrician
7 dust
8 police
9 training
10 review
11 A
12 A
13 A
14 C
15 A
16 C
17 B
18 C
19 B
20 A
21 C
22 E
23 A
24 D
25 B
26 F
27 A
28 D
29 C
30 G
31 golden
32 healthy
33 climate
34 rock(s)
35 diameter
36 tube
37 fire
38 steam
39 cloudy
40 litre / liter
21&22 IN EITHER ORDER: C,E
23&24 IN EITHER ORDER: A,D
If you score: 1–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. golden

32. healthy

33. climate

34. rock / rocks

35. diameter

36. tube

37. fire

38. steam

39. cloudy

40. litre / liter

## A 类阅读

### Academic Reading · source page 125

TEST 4 READING
1 FALSE
2 FALSE
3 NOT GIVEN
4 TRUE
5 NOT GIVEN
6 TRUE
7 droppings
8 coffee
9 mosquitoes
10 protein
11 unclean
12 culture
13 houses
14 E
15 A
16 D
17 F
18 C
19 descendants
20 sermon
21 fine
22 innovation
23 B
24 E
25 B
26 D
27 D
28 E
29 F
30 B
31 H
32 E
33 FALSE
34 NOT GIVEN
35 NOT GIVEN
36 TRUE
37 memory
38 numbers
39 communication
40 visual
23&24 IN EITHER ORDER: B,E
25&26 IN EITHER ORDER: B,D
If you score: 1–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. FALSE

2. FALSE

3. NOT GIVEN

4. TRUE

5. NOT GIVEN

6. TRUE

7. droppings

8. coffee

9. mosquitoes

10. protein

11. unclean

12. culture

13. houses

14. E

15. A

16. D

17. F

18. C

19. descendants

20. sermon

21. fine

22. innovation

23. B / E

24. B / E

25. B / D

26. B / D

27. D

28. E

29. F

30. B

31. H

32. E

33. FALSE

34. NOT GIVEN

35. NOT GIVEN

36. TRUE

37. memory

38. numbers

39. communication

40. visual

## A 类写作

### Writing material: c17-t4-w-1

Number of shops,2011–2018; solid closures,dashed openings. Approximate closures6500,5900,7200,6500,600,5100,5000,5200; openings8500,4000,5000,6100,4000,4000,4200,3000. Closures crash below1000in2015then recover; openings fall overall with2012drop and2014rebound. Openings exceed closures only2011and2015; others reverse. No equality or closure count zero in2015. Measures are annual openings/closures, not total shops operating or direct unemployment counts. Country unnamed; all unlabelled readings approximate.



### Writing material: c17-t4-w-2

Evaluate trying alternative treatments INSTEAD OF usual doctor visits, not merely complementary treatment alongside medical care. Give reasoned judgement without inventing clinical evidence.



## 口语
