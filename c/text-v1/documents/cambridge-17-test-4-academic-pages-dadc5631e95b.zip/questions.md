# 剑雅 17 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/fcd505caaf44e7c25525b40cc202e4222c1e4c56a3556c69f116d334c5360e95.jpg; PDF page 74; full -->

```text
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD for each answer.
Easy Life Cleaning Services
Basic cleaning package offered
• Cleaning all surfaces
• Cleaning the (1) __________ throughout the apartment
• Cleaning shower, sinks, toilet etc.
Additional services agreed
• Every week
– Cleaning the (2) __________
– Ironing clothes – (3) __________ only
• Every month
– Cleaning all the (4) __________ from the inside
– Washing down the (5) __________
Other possibilities
• They can organise a plumber or an (6) __________ if necessary.
• A special cleaning service is available for customers who are allergic to (7) __________.
Information on the cleaners
• Before being hired, all cleaners have a background check carried out by the (8) __________.
• References are required.
• All cleaners are given (9) __________ for two weeks.
• Customers send a (10) __________ after each visit.
• Usually, each customer has one regular cleaner.
```

[Original question page](assets/fcd505caaf44e7c25525b40cc202e4222c1e4c56a3556c69f116d334c5360e95.jpg)

### Part 2

<!-- Source: /api/assets/5c2ac600358a5c5525aec0061b86a05fed688b65b91648f5c4af903b65dcb3c1.jpg; PDF page 75; full -->

```text
Test 4
PART 2 Questions 11-20
Questions 11-14
Listening test audio
Choose the correct letter, A, B or C.
11. Many hotel managers are unaware that their staff often leave because of
A a lack of training.
B long hours.
C low pay.
12 What is the impact of high staff turnover on managers?
A an increased workload
B low morale
C an inability to meet targets
13 What mistake should managers always avoid?
A failing to treat staff equally
B reorganising shifts without warning
C neglecting to have enough staff during busy periods
14 What unexpected benefit did Dunwich Hotel notice after improving staff
retention rates?
A a fall in customer complaints
B an increase in loyalty club membership
C a rise in spending per customer
76
```

[Original question page](assets/5c2ac600358a5c5525aec0061b86a05fed688b65b91648f5c4af903b65dcb3c1.jpg)

<!-- Source: /api/assets/b319ab6416743797e2aa4eec0e64e07ea5fe8ac77c41571a8f56a086866e8172.jpg; PDF page 76; full -->

```text
Questions 15–20
Which way of reducing staff turnover was used in each of the following hotels?
Write the correct letter, A, B or C, next to Questions 15–20.
Ways of reducing staff turnover
A improving relationships and teamwork
B offering incentives and financial benefits
C providing career opportunities
Hotels
15 The Sun Club __________
16 The Portland __________
17 Bluewater Hotels __________
18 Pentlow Hotels __________
19 Green Planet __________
20 The Amesbury __________
```

[Original question page](assets/b319ab6416743797e2aa4eec0e64e07ea5fe8ac77c41571a8f56a086866e8172.jpg)

### Part 3

<!-- Source: /api/assets/090edc61102e93d85c6db15c623258f85e3c6ee18c44d4266d6c54415530f4ff.jpg; PDF page 77; full -->

```text
PART 3 Questions 21–30
Questions 21–22
Choose TWO letters, A–E.
Which TWO points do Thomas and Jeanne make about Thomas’s sporting activities at school?
A He should have felt more positive about them.
B The training was too challenging for him.
C He could have worked harder at them.
D His parents were disappointed in him.
E His fellow students admired him.
Questions 23 and 24
Choose TWO letters, A–E.
Which TWO feelings did Thomas experience when he was in Kenya?
A disbelief
B relief
C stress
D gratitude
E homesickness
```

[Original question page](assets/090edc61102e93d85c6db15c623258f85e3c6ee18c44d4266d6c54415530f4ff.jpg)

<!-- Source: /api/assets/88d82dee3768d8c4b675b05c4e658a4b9e287ee18bdcb8b4a68a21ac94a30ea0.jpg; PDF page 78; full -->

```text
Questions 25–30
What comment do the students make about the development of each of the following items of sporting equipment?
Choose SIX answers from the box and write the correct letter, A–H, next to Questions 25–30.
Comments about the development of the equipment
A It could cause excessive sweating.
B The material was being mass produced for another purpose.
C People often needed to make their own.
D It often had to be replaced.
E The material was expensive.
F It was unpopular among spectators.
G It caused injuries.
H No one using it liked it at first.
Items of sporting equipment
25 the table tennis bat __________
26 the cricket helmet __________
27 the cycle helmet __________
28 the golf club __________
29 the hockey stick __________
30 the football __________
```

[Original question page](assets/88d82dee3768d8c4b675b05c4e658a4b9e287ee18bdcb8b4a68a21ac94a30ea0.jpg)

### Part 4

<!-- Source: /api/assets/6daec4bbd46fb076b22676535b103a6f4d06fe0d3b10cc137cd6db14f206c3e4.jpg; PDF page 79; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Maple syrup
What is maple syrup?
• made from the sap of the maple tree
• added to food or used in cooking
• colour described as (31) __________
• very (32) __________ compared to refined sugar
The maple tree
• has many species
• needs sunny days and cool nights
• maple leaf has been on the Canadian flag since 1964
• needs moist soil but does not need fertiliser as well
• best growing conditions and (33) __________ are in Canada and North America
Early maple sugar producers
• made holes in the tree trunks
• used hot (34) __________ to heat the sap
• used tree bark to make containers for collection
• sweetened food and drink with sugar
Today’s maple syrup
The trees
• Tree trunks may not have the correct (35) __________ until they have been growing for 40 years.
• The changing temperature and movement of water within the tree produces the sap.
The production
• A tap is drilled into the trunk and a (36) __________ carries the sap into a bucket.
• Large pans of sap called evaporators are heated by means of a (37) __________.
• A lot of (38) __________ is produced during the evaporation process.
• ‘Sugar sand’ is removed because it makes the syrup look (39) __________ and affects the taste.
• The syrup is ready for use.
• A huge quantity of sap is needed to make a (40) __________ of maple syrup.
```

[Original question page](assets/6daec4bbd46fb076b22676535b103a6f4d06fe0d3b10cc137cd6db14f206c3e4.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/f5b3ef6dc7e204a5411ef66a0f205b4cf4678e104900b477b38ce48e4185cec3.jpg; PDF page 80; full -->

```text
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Bats to the rescue
How Madagascar’s bats are helping to save the rainforest
There are few places in the world where relations between agriculture and conservation are more
strained. Madagascar’s forests are being converted to agricultural land at a rate of one percent
every year. Much of this destruction is fuelled by the cultivation of the country’s main staple
crop: rice. And a key reason for this destruction is that insect pests are destroying vast quantities
of what is grown by local subsistence farmers, leading them to clear forest to create new paddy
fields. The result is devastating habitat and biodiversity loss on the island, but not all species
are suffering. In fact, some of the island’s insectivorous bats are currently thriving and this has
important implications for farmers and conservationists alike.
Enter University of Cambridge zoologist Ricardo Rocha. He’s passionate about conservation,
and bats. More specifically, he’s interested in how bats are responding to human activity and
deforestation in particular. Rocha’s new study shows that several species of bats are giving
Madagascar’s rice farmers a vital pest control service by feasting on plagues of insects. And this,
he believes, can ease the financial pressure on farmers to turn forest into fields.
Bats comprise roughly one-fifth of all mammal species in Madagascar and thirty-six recorded bat
species are native to the island, making it one of the most important regions for conservation of
this animal group anywhere in the world.
Co-leading an international team of scientists, Rocha found that several species of indigenous
bats are taking advantage of habitat modification to hunt insects swarming above the country’s
rice fields. They include the Malagasy mouse-eared bat, Major’s long-fingered bat, the Malagasy
white-bellied free-tailed bat and Peters’ wrinkle-lipped bat.
‘These winner species are providing a valuable free service to Madagascar as biological pest
suppressors,’ says Rocha. ‘We found that six species of bat are preying on rice pests, including the
paddy swarming caterpillar and grass webworm. The damage which these insects cause puts the
island’s farmers under huge financial pressure and that encourages deforestation.”
The study, now published in the journal Agriculture, Ecosystems and Environment, set out to
investigate the feeding activity of insectivorous bats in the farmland bordering the Ranomafana
National Park in the southeast of the country.
81
```

[Original question page](assets/f5b3ef6dc7e204a5411ef66a0f205b4cf4678e104900b477b38ce48e4185cec3.jpg)

<!-- Source: /api/assets/c81896a3c08ae55581702ae74921ec887e0df6db6554925f6d7bbf11a5236271.jpg; PDF page 81; full -->

```text
Test 4
Rocha and his team used state-of-the-art ultrasonic recorders to record over a thousand bat
‘feeding buzzes’ (echolocation sequences used by bats to target their prey) at 54 sites, in order
to identify the favourite feeding spots of the bats. They next used DNA barcoding techniques to
analyse droppings collected from bats at the different sites.
The recordings revealed that bat activity over rice fields was much higher than it was in
continuous forest — seven times higher over rice fields which were on flat ground, and sixteen
times higher over fields on the sides of hills — leaving no doubt that the animals are preferentially
foraging in these man-made ecosystems. The researchers suggest that the bats favour these fields
because lack of water and nutrient run-off make these crops more susceptible to insect pest
infestations. DNA analysis showed that all six species of bat had fed on economically important
insect pests. While the findings indicated that rice farming benefits most from the bats, the
scientists also found indications that the bats were consuming pests of other crops, including the
black twig borer (which infests coffee plants), the sugarcane cicada, the macadamia nut-borer, and
the sober tabby (a pest of citrus fruits).
‘The effectiveness of bats as pest controllers has already been proven in the USA and Catalonia,’
said co-author James Kemp, from the University of Lisbon. ‘But our study is the first to show this
happening in Madagascar, where the stakes for both farmers and conservationists are so high.’
Local people may have a further reason to be grateful to their bats. While the animal is often
associated with spreading disease, Rocha and his team found evidence that Malagasy bats feed
not just on crop pests but also on mosquitoes — carriers of malaria, Rift Valley fever virus and
elephantiasis — as well as blackflies, which spread river blindness.
Rocha points out that the relationship is complicated. When food is scarce, bats become a crucial
source of protein for local people. Even the children will hunt them. And as well as roosting in
trees, the bats sometimes roost in buildings, but are not welcomed there because they make them
unclean. At the same time, however, they are associated with sacred caves and the ancestors, so
they can be viewed as beings between worlds, which makes them very significant in the culture of
the people. And one potential problem is that while these bats are benefiting from farming, at the
same time deforestation is reducing the places where they can roost, which could have long-term
effects on their numbers. Rocha says, ‘With the right help, we hope that farmers can promote this
mutually beneficial relationship by installing bat houses.’
Rocha and his colleagues believe that maximising bat populations can help to boost crop yields
and promote sustainable livelihoods. The team is now calling for further research to quantify this
contribution. ‘I’m very optimistic,’ says Rocha. ‘If we give nature a hand, we can speed up the
process of regeneration.’
82
```

[Original question page](assets/c81896a3c08ae55581702ae74921ec887e0df6db6554925f6d7bbf11a5236271.jpg)

<!-- Source: /api/assets/faf04b330793f4b26fbf12e1bbf1b4da2d156fb553f9339e7f247c3f628f0b6c.jpg; PDF page 82; full -->

```text
Reading
Questions 1-6
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-6 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 Many Madagascan forests are being destroyed by attacks from insects.
2 Loss of habitat has badly affected insectivorous bats in Madagascar.
3 Ricardo Rocha has carried out studies of bats in different parts of the world.

4 Habitat modification has resulted in indigenous bats in Madagascar becoming
useful to farmers.
5 The Malagasy mouse-eared bat is more common than other indigenous bat species
in Madagascar.
6 Bats may feed on paddy swarming caterpillars and grass webworms.
83
```

[Original question page](assets/faf04b330793f4b26fbf12e1bbf1b4da2d156fb553f9339e7f247c3f628f0b6c.jpg)

<!-- Source: /api/assets/6b99e712c358fc012ac9837ffb46f6285a75d594ceed59009ac617c47c31e13a.jpg; PDF page 83; full -->

```text
Questions 7–13
Complete the table below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 7–13 on your answer sheet.
The study carried out by Rocha’s team
| Category | Details |
| --- | --- |
| Aim | to investigate the feeding habits of bats in farmland near the Ranomafana National Park |
| Method | ultrasonic recording to identify favourite feeding spots; DNA analysis of bat (7) __________ |
| Findings | the bats: were most active in rice fields located on hills; ate pests of rice, (8) __________, sugarcane, nuts and fruit; prevent the spread of disease by eating (9) __________ and blackflies |
| Findings | local attitudes to bats are mixed: they provide food rich in (10) __________; the buildings where they roost become (11) __________; they play an important role in local (12) __________ |
| Recommendation | farmers should provide special (13) __________ to support the bat population |
```

[Original question page](assets/6b99e712c358fc012ac9837ffb46f6285a75d594ceed59009ac617c47c31e13a.jpg)

<!-- Source: /api/assets/5043cb00f7e7b7c8d02b4e51813236da310fa311828a074bddc83a43f08c4d4c.jpg; PDF page 84; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Does education fuel economic growth?
A Over the last decade, a huge database about the lives of southwest German villagers
between 1600 and 1900 has been compiled by a team led by Professor Sheilagh Ogilvie
at Cambridge University’s Faculty of Economics. It includes court records, guild ledgers,
parish registers, village censuses, tax lists and — the most recent addition — 9,000 handwritten
inventories listing over a million personal possessions belonging to ordinary women and
men across three centuries. Ogilvie, who discovered the inventories in the archives of two
German communities 30 years ago, believes they may hold the answer to a conundrum that
has long puzzled economists: the lack of evidence for a causal link between education and a
country’s economic growth.
B As Ogilvie explains, ‘Education helps us to work more productively, invent better
technology, and earn more ... surely it must be critical for economic growth? But, if you
look back through history, there’s no evidence that having a high literacy rate made a
country industrialise earlier.’ Between 1600 and 1900, England had only mediocre literacy
rates by European standards, yet its economy grew fast and it was the first country to
industrialise. During this period, Germany and Scandinavia had excellent literacy rates, but
their economies grew slowly and they industrialised late. ‘Modern cross-country analyses
have also struggled to find evidence that education causes economic growth, even though
there is plenty of evidence that growth increases education,’ she adds.
C In the handwritten inventories that Ogilvie is analysing are the belongings of women and
men at marriage, remarriage and death. From badger skins to Bibles, sewing machines to
scarlet bodices — the villagers’ entire worldly goods are included. Inventories of agricultural
equipment and craft tools reveal economic activities; ownership of books and education-
related objects like pens and slates suggests how people learned. In addition, the tax lists
included in the database record the value of farms, workshops, assets and debts; signatures
and people’s estimates of their age indicate literacy and numeracy levels; and court records
reveal obstacles (such as the activities of the guilds*) that stifled industry.
Previous studies usually had just one way of linking education with economic growth — the
presence of schools and printing presses, perhaps, or school enrolment, or the ability to
sign names. According to Ogilvie, the database provides multiple indicators for the same
individuals, making it possible to analyse links between literacy, numeracy, wealth, and
industriousness, for individual women and men over the long term.
* guild: an association of artisans or merchants which oversees the practice of their craft or trade in a particular area
85
```

[Original question page](assets/5043cb00f7e7b7c8d02b4e51813236da310fa311828a074bddc83a43f08c4d4c.jpg)

<!-- Source: /api/assets/d6bfb546152220e9373919edcc27012f2fb0ceb66568630177fe31546f30144c.jpg; PDF page 85; full -->

```text
Test 4
D
86
Ogilvie and her team have been building the vast database of material possessions on top
of their full demographic reconstruction of the people who lived in these two German
communities. “We can follow the same people — and their descendants — across 300 years
of educational and economic change,’ she says. Individual lives have unfolded before their
eyes. Stories like that of the 24-year-olds Ana Regina and Magdalena Riethmüllerin, who
were chastised in 1707 for reading books in church instead of listening to the sermon. ‘This
tells us they were continuing to develop their reading skills at least a decade after leaving
school,’ explains Ogilvie. The database also reveals the case of Juliana Schweickherdt, a
50-year-old spinster living in the small Black Forest community of Wildberg, who was
reprimanded in 1752 by the local weavers’ guild for ‘weaving cloth and combing wool,
counter to the guild ordinance’. When Juliana continued taking jobs reserved for male guild
members, she was summoned before the guild court and told to pay a fine equivalent to one
third of a servant’s annual wage. It was a small act of defiance by today’s standards, but it
reflects a time when laws in Germany and elsewhere regulated people’s access to labour
markets. The dominance of guilds not only prevented people from using their skills, but also
held back even the simplest industrial innovation.
E The data-gathering phase of the project has been completed and now, according to Ogilvie,
it is time ‘to ask the big questions’. One way to look at whether education causes economic
growth is to ‘hold wealth constant’. This involves following the lives of different people with
the same level of wealth over a period of time. If wealth is constant, it is possible to discover
whether education was, for example, linked to the cultivation of new crops, or to the
adoption of industrial innovations like sewing machines. The team will also ask what aspect
of education helped people engage more with productive and innovative activities. Was it,
for instance, literacy, numeracy, book ownership, years of schooling? Was there a threshold
level — a tipping point — that needed to be reached to affect economic performance?
F Ogilvie hopes to start finding answers to these questions over the next few years. One
thing is already clear, she says: the relationship between education and economic growth
is far from straightforward. ‘German-speaking central Europe is an excellent laboratory
for testing theories of economic growth,’ she explains. Between 1600 and 1900, literacy
rates and book ownership were high and yet the region remained poor. It was also the case
that local guilds and merchant associations were extremely powerful and legislated against
anything that undermined their monopolies. In villages throughout the region, guilds
blocked labour migration and resisted changes that might reduce their influence.
‘Early findings suggest that the potential benefits of education for the economy can be held
back by other barriers, and this has implications for today, says Ogilvie. ‘Huge amounts
are spent improving education in developing countries, but this spending can fail to deliver
economic growth if restrictions block people — especially women and the poor — from using
their education in economically productive ways. If economic institutions are poorly set up,
for instance, education can’t lead to growth.’
```

[Original question page](assets/d6bfb546152220e9373919edcc27012f2fb0ceb66568630177fe31546f30144c.jpg)

<!-- Source: /api/assets/800750ea470d94b370b0b020f2af2ed982be957e15061209fe4e0257186b85be.jpg; PDF page 86; full -->

```text
Reading
Questions 14-18
Reading Passage 2 has six sections, A-F.
Which section contains the following information?
Write the correct letter, A-F, in boxes 14—18 on your answer sheet.
14 an explanation of the need for research to focus on individuals with a fairly
consistent income
15 examples of the sources the database has been compiled from
16 an account of one individual's refusal to obey an order
17 a reference to a region being particularly suited to research into the link between
education and economic growth
18 examples of the items included in a list of personal possessions
Questions 19-22
Complete the summary below.
Choose ONE WORD from the passage for each answer.
Write your answers in boxes 19-22 on your answer sheet.
Demographic reconstruction of two German communities
The database that Ogilvie and her team has compiled sheds light on the lives of a range of individuals, as well as those of their (19) __________, over a 300-year period. For example, Ana Regina and Magdalena Riethmüllerin were reprimanded for reading while they should have been paying attention to a (20) __________.
There was also Juliana Schweickherdt, who came to the notice of the weavers’ guild in the year 1752 for breaking guild rules. As a punishment, she was later given a (21) __________. Cases like this illustrate how the guilds could prevent (22) __________ and stop skilled people from working.
```

[Original question page](assets/800750ea470d94b370b0b020f2af2ed982be957e15061209fe4e0257186b85be.jpg)

<!-- Source: /api/assets/6cca9c70abe2b92a36cdc677eaa38d9a0aedfe01d7ad795db0de7b0d53c0b9e3.jpg; PDF page 87; full -->

```text
Test 4
Questions 23 and 24
Choose TWO letters, A-E.
Write the correct letters in boxes 23 and 24 on your answer sheet.
Which TWO of the following statements does the writer make about literacy rates in
Section B?
A Very little research has been done into the link between high literacy rates and
improved earnings.
B Literacy rates in Germany between 1600 and 1900 were very good.
C There is strong evidence that high literacy rates in the modern world result in
economic growth.
D England is a good example of how high literacy rates helped a country
industrialise.
E Economic growth can help to improve literacy rates.
Questions 25 and 26
Choose TWO letters, A-E.
Write the correct letters in boxes 25 and 26 on your answer sheet.
Which TWO of the following statements does the writer make in Section F about guilds
in German-speaking Central Europe between 1600 and 1900?
A They helped young people to learn a skill.
B They were opposed to people moving to an area for work.
C They kept better records than guilds in other parts of the world.
D They opposed practices that threatened their control over a trade.
E They predominantly consisted of wealthy merchants.
```

[Original question page](assets/6cca9c70abe2b92a36cdc677eaa38d9a0aedfe01d7ad795db0de7b0d53c0b9e3.jpg)

<!-- Source: /api/assets/38ca874014b09549e78775329a1208acb6a2ac3af09c7234525858ee61704edb.jpg; PDF page 88; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Timur Gareyev — blindfold chess champion
A Next month, a chess player named Timur Gareyev will take on nearly 50 opponents
at once. But that is not the hard part. While his challengers will play the games as
normal, Gareyev himself will be blindfolded. Even by world record standards, it
sets a high bar for human performance. The 28-year-old already stands out in the
rarefied world of blindfold chess. He has a fondness for bright clothes and unusual
hairstyles, and he gets his kicks from the adventure sport of BASE jumping. He has
already proved himself a strong chess player, too. In a 10-hour chess marathon in
2013, Gareyev played 33 games in his head simultaneously. He won 29 and lost
none. The skill has become his brand: he calls himself the Blindfold King.
B But Gareyev’s prowess has drawn interest from beyond the chess-playing
community. In the hope of understanding how he and others like him can perform
such mental feats, researchers at the University of California in Los Angeles
(UCLA) called him in for tests. They now have their first results. ‘The ability to play
a game of chess with your eyes closed is not a far reach for most accomplished
players,’ said Jesse Rissman, who runs a memory lab at UCLA. ‘But the thing that’s
so remarkable about Timur and a few other individuals is the number of games they
can keep active at once. To me it is simply astonishing.’
C Gareyev learned to play chess in his native Uzbekistan when he was six years old.
Tutored by his grandfather, he entered his first tournament aged eight and soon
became obsessed with competitions. At 16, he was crowned Asia’s youngest ever
chess grandmaster. He moved to the US soon after, and as a student helped his
university win its first national chess championship. In 2013, Gareyev was ranked
the third best chess player in the US.
D To the uninitiated, blindfold chess seems to call for superhuman skill. But displays
of the feat go back centuries. The first recorded game in Europe was played in
13th-century Florence. In 1947, the Argentinian grandmaster Miguel Najdorf played
45 simultaneous games in his mind, winning 39 in the 24-hour session.
E Accomplished players can develop the skill of playing blind even without realising
it. The nature of the game is to run through possible moves in the mind to see
how they play out. From this, regular players develop a memory for the patterns
the pieces make, the defences and attacks. ‘You recreate it in your mind,’ said
Gareyev. ‘A lot of players are capable of doing what I’m doing.’ The real mental
challenge comes from playing multiple games at once in the head. Not only must
the positions of each piece on every board be memorised, they must be recalled
89
```

[Original question page](assets/38ca874014b09549e78775329a1208acb6a2ac3af09c7234525858ee61704edb.jpg)

<!-- Source: /api/assets/200f49d842ece347350eb3b27f776f98594e42436b49f8bde0f5a0c4771f3bcb.jpg; PDF page 89; full -->

```text
Test 4
90
faithfully when needed, updated with each player’s moves, and then reliably stored
again, so the brain can move on to the next board. First moves can be tough to
remember because they are fairly uninteresting. But the ends of games are taxing
too, as exhaustion sets in. When Gareyev is tired, his recall can get patchy. He
sometimes makes moves based on only a fragmented memory of the pieces’
positions.
F The scientists first had Gareyev perform some standard memory tests. These
assessed his ability to hold numbers, pictures and words in mind. One classic test
measures how many numbers a person can repeat, both forwards and backwards,
soon after hearing them. Most people manage about seven. ‘He was not
exceptional on any of these standard tests,’ said Rissman. ‘We didn’t find anything
other than playing chess that he seems to be supremely gifted at.’ But next came
the brain scans. With Gareyev lying down in the machine, Rissman looked at how
well connected the various regions of the chess player’s brain were. Though the
results are tentative and as yet unpublished, the scans found much greater than
average communication between parts of Gareyev’s brain that make up what is
called the frontoparietal control network. Of 63 people scanned alongside the chess
player, only one or two scored more highly on the measure. ‘You use this network in
almost any complex task. It helps you to allocate attention, keep rules in mind, and
work out whether you should be responding or not,’ said Rissman.
G It was not the only hint of something special in Gareyev’s brain. The scans also
suggest that Gareyev’s visual network is more highly connected to other brain parts
than usual. Initial results suggest that the areas of his brain that process visual
images — such as chess boards — may have stronger links to other brain regions,
and so be more powerful than normal. While the analyses are not finalised yet, they
may hold the first clues to Gareyev’s extraordinary ability.
H For the world record attempt, Gareyev hopes to play 47 blindfold games at once in
about 16 hours. He will need to win 80% to claim the title. ‘I don’t worry too much
about the winning percentage, that’s never been an issue for me,’ he said. ‘The
most important part of blindfold chess for me is that I have found the one thing that
I can fully dedicate myself to. I miss having an obsession.’
```

[Original question page](assets/200f49d842ece347350eb3b27f776f98594e42436b49f8bde0f5a0c4771f3bcb.jpg)

<!-- Source: /api/assets/5409fb5a8fa0f3db035a846b94d537e5241858b78011f41a287b1f13f901ca78.jpg; PDF page 90; full -->

```text
Reading
Questions 27-32
Reading Passage 3 has eight paragraphs, A-H.
Which paragraph contains the following information?
Write the correct letter, A-H, in boxes 27-32 on your answer sheet.
NB You may use any letter more than once.
27 a reference to earlier examples of blindfold chess
28 an outline of what blindfold chess involves
29 a claim that Gareyev’s skill is limited to chess
30 why Gareyev's skill is of interest to scientists
31 an outline of Gareyev’s priorities
32 a reason why the last part of a game may be difficult
Questions 33-36
Do the following statements agree with the information given in Reading Passage 3?
In boxes 33-36 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information about this
33 In the forthcoming games, all the participants will be blindfolded.
34 Gareyev has won competitions in BASE jumping.
35 UCLA is the first university to carry out research into blindfold chess players.
36 Good chess players are likely to be able to play blindfold chess.
91
```

[Original question page](assets/5409fb5a8fa0f3db035a846b94d537e5241858b78011f41a287b1f13f901ca78.jpg)

<!-- Source: /api/assets/a48e873540df1d50b52a735c87d02c147b50ea2e8817dcabe6bea7ae8f05b2a6.jpg; PDF page 91; full -->

```text
Questions 37–40
Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 37–40 on your answer sheet.
How the research was carried out
The researchers started by testing Gareyev’s (37) __________; for example, he was required to recall a string of (38) __________ in order and also in reverse order. Although his performance was normal, scans showed an unusual amount of (39) __________ within the areas of Gareyev’s brain that are concerned with directing attention. In addition, the scans raised the possibility of unusual strength in the parts of his brain that deal with (40) __________ input.
```

[Original question page](assets/a48e873540df1d50b52a735c87d02c147b50ea2e8817dcabe6bea7ae8f05b2a6.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/805e7a76369a4c2ea78f016b4d34a224cffe46c1fc664c55b1f290af7481a7fb.jpg; PDF page 92; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below shows the number of shops that closed and the number of new shops that opened in one country between 2011 and 2018.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/805e7a76369a4c2ea78f016b4d34a224cffe46c1fc664c55b1f290af7481a7fb.jpg)

![Original figure](assets/805e7a76369a4c2ea78f016b4d34a224cffe46c1fc664c55b1f290af7481a7fb.jpg)

### Task 2

<!-- Source: /api/assets/4861d99355145655ae6b04d3ca7bafaca1cdacefac0cf4f8302976a0acabca52.jpg; PDF page 93; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Nowadays, a growing number of people with health problems are trying alternative medicines and treatments instead of visiting their usual doctor.

Do you think this is a positive or a negative development?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/4861d99355145655ae6b04d3ca7bafaca1cdacefac0cf4f8302976a0acabca52.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/5e7c71520c3ec3a88951493d59121f77215bd03aea102d18c1cd229e89e21e97.jpg; PDF page 94; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Maps
e Do you think it’s better to use a paper map or a map on your phone? [Why?]
e When was the last time you needed to use a map? [Why/Why not?]
e If you visit a new city, do you always use a map to find your way around?
[Why/Why not?]
e In general, do you find it easy to read maps? [Why/Why not?]
PART 2
Describe an occasion when you had to do something in a hurry.
You should say:
what you had to do
why you had to do this in a hurry
how well you did this
and explain how you felt about having to do this in a hurry.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Arriving late
Example questions:
Do you think it’s OK to arrive late when meeting a friend?
What should happen to people who arrive late for work?
Can you suggest how people can make sure they don’t arrive late?
Managing study time
Example questions:
Is it better to study for long periods or in shorter blocks of time?
What are the likely effects of students not managing their study time well?
How important is it for students to have enough leisure time?
95
```

[Original question page](assets/5e7c71520c3ec3a88951493d59121f77215bd03aea102d18c1cd229e89e21e97.jpg)

### Part 2

<!-- Source: /api/assets/5e7c71520c3ec3a88951493d59121f77215bd03aea102d18c1cd229e89e21e97.jpg; PDF page 94; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Maps
e Do you think it’s better to use a paper map or a map on your phone? [Why?]
e When was the last time you needed to use a map? [Why/Why not?]
e If you visit a new city, do you always use a map to find your way around?
[Why/Why not?]
e In general, do you find it easy to read maps? [Why/Why not?]
PART 2
Describe an occasion when you had to do something in a hurry.
You should say:
what you had to do
why you had to do this in a hurry
how well you did this
and explain how you felt about having to do this in a hurry.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Arriving late
Example questions:
Do you think it’s OK to arrive late when meeting a friend?
What should happen to people who arrive late for work?
Can you suggest how people can make sure they don’t arrive late?
Managing study time
Example questions:
Is it better to study for long periods or in shorter blocks of time?
What are the likely effects of students not managing their study time well?
How important is it for students to have enough leisure time?
95
```

[Original question page](assets/5e7c71520c3ec3a88951493d59121f77215bd03aea102d18c1cd229e89e21e97.jpg)

### Part 3

<!-- Source: /api/assets/5e7c71520c3ec3a88951493d59121f77215bd03aea102d18c1cd229e89e21e97.jpg; PDF page 94; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Maps
e Do you think it’s better to use a paper map or a map on your phone? [Why?]
e When was the last time you needed to use a map? [Why/Why not?]
e If you visit a new city, do you always use a map to find your way around?
[Why/Why not?]
e In general, do you find it easy to read maps? [Why/Why not?]
PART 2
Describe an occasion when you had to do something in a hurry.
You should say:
what you had to do
why you had to do this in a hurry
how well you did this
and explain how you felt about having to do this in a hurry.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Arriving late
Example questions:
Do you think it’s OK to arrive late when meeting a friend?
What should happen to people who arrive late for work?
Can you suggest how people can make sure they don’t arrive late?
Managing study time
Example questions:
Is it better to study for long periods or in shorter blocks of time?
What are the likely effects of students not managing their study time well?
How important is it for students to have enough leisure time?
95
```

[Original question page](assets/5e7c71520c3ec3a88951493d59121f77215bd03aea102d18c1cd229e89e21e97.jpg)
