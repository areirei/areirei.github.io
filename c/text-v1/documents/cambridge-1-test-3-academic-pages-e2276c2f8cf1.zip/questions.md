# 剑雅 1 · Test 3

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/870465c4fd243903c49f4cc92244422941d327f2e466500c0965713458900669.jpg; PDF page 60; full -->

```text
54
Practice Test 3
LISTENING
SECTION 1     Questions 1-12
Questions 1-4
Circle the appropriate letter
Example
How does the woman travel every day?
A by car
B by bus
C on foot [circled example]
D by train
1 What are the parking regulations on campus?
A undergraduate parking allowed
B postgraduate parking allowed
C staff parking only allowed
D no student parking allowed
2 The administration office is in
A Block B.
B Block D.
C Block E.
D Block G.
3   If you do not have a parking sticker, the following action will be taken:
A wheel clamp your car.
B fine only.
C tow away your car and fine.
D tow away your car only.
```

[Original question page](assets/870465c4fd243903c49f4cc92244422941d327f2e466500c0965713458900669.jpg)

<!-- Source: /api/assets/ad5a1834d18aa5b5545484870376c26639a2dea1d04123987ccd2e39b1a14209.jpg; PDF page 61; full -->

```text
Listening
4 Which picture shows the correct location of the Administration office?
A / B / C / D: original map options retained below.
Questions 5–10
Complete the application form using NO MORE THAN THREE WORDS.
Application for parking sticker
Name (5) __________
Address (6) Flat 13 __________
Suburb (7) __________
Faculty (8) __________
Registration number (9) __________
Make of car (10) __________
Questions 11–12
11 Cashier’s office opens at: A 12.15 / B 2.00 / C 2.15 / D 4.30
12 Where must the sticker be displayed? __________
```

[Original question page](assets/ad5a1834d18aa5b5545484870376c26639a2dea1d04123987ccd2e39b1a14209.jpg)

![Original figure](assets/ad5a1834d18aa5b5545484870376c26639a2dea1d04123987ccd2e39b1a14209.jpg)

### Part 2

<!-- Source: /api/assets/f5d403ecba5105a2fb3f04a67b1e42190c72b77f5f75d94b06f95ab51e7c1049.jpg; PDF page 62; full -->

```text
56
Practice Test 3
SECTION 2     Questions 13-23
Complete the notes below using NO MORE THAN THREE WORDS for each answer.
Date the museum was opened (13)
The museum consists of a building and (14)
Handicapped toilet door shows Example:  a wheelchair
The Education Centre is signposted by (15)
If you lose your friends, meet at the (16)
Warning about The Vampire (17)
How often are the tours of The Vampire? (18)
Person featured in today’s video (19)
The Leisure Gallery shows how Australian culture is
influenced by (20)
The Picture Gallery contains pictures by (21)
Cost of family membership of the museum (22)
“Passengers and the Sea” includes a collection of (23)
```

[Original question page](assets/f5d403ecba5105a2fb3f04a67b1e42190c72b77f5f75d94b06f95ab51e7c1049.jpg)

### Part 3

<!-- Source: /api/assets/cef62562c3ad82b7f75404ad7c4623fe30df0c8002c55882850622c7412d2be0.jpg; PDF page 63; full -->

```text
57
Listening
SECTION 3    Questions 24-32
Questions 24-27
Click the correct answer
24 Mark is going to talk briefly about
A marketing new products.
B pricing strategies.
C managing large companies.
D setting sales targets.
25 According to Susan, air fares are lowest when they
A include weekend travel.
B are booked well in advance.
C are non-refundable.
D are for business travel only.
26 Mark thinks revenue management is
A interesting.
B complicated.
C time-consuming.
D reasonable.
27 The airline companies want to
A increase profits.
B benefit the passenger.
C sell cheap seats.
D improve the service.
Questions 28-32
Complete the notes using NO MORE THAN THREE WORDS for each answer
Two reasons for the new approach to pricing are:
(28) .......................................................................... and
(29) .......................................................................... .
In future people will be able to book airline tickets (30) ................................................... .
Also being marketed in this way are (31) ............................................................ and
(32) ................................................................. .
```

[Original question page](assets/cef62562c3ad82b7f75404ad7c4623fe30df0c8002c55882850622c7412d2be0.jpg)

### Part 4

<!-- Source: /api/assets/e134c770cf9124a16148a47e12ac977841b1a42a3b4fc05b20a70c72f2422ffc.jpg; PDF page 64; full -->

```text
Practice Test 3
SECTION 4 Questions 33–42
Questions 33–37
Complete the table. Write NO MORE THAN THREE WORDS for each answer.
SPACE MANAGEMENT
RESEARCH METHOD | INFORMATION PROVIDED
Questionnaires | what customers think about (33) __________
(34) __________ | how customers move around supermarket aisles
Eye movement (35) __________ | the most eye-catching areas of the shop
Computer programs, e.g. (36) __________ | the best (37) __________ for an article in the shop
```

[Original question page](assets/e134c770cf9124a16148a47e12ac977841b1a42a3b4fc05b20a70c72f2422ffc.jpg)

<!-- Source: /api/assets/5405a72ed13861f89769a22c3d7f355fb6b5ad1c9d248501492ec83b8f778003.jpg; PDF page 65; full -->

```text
Listening
Questions 38–42
Label the diagram. Write NO MORE THAN THREE WORDS for each answer.
A SUPERMARKET AISLE — original layout retained below
Entrance: first shelves — customers usually (38) __________ these.
Aisle: products placed here sell well particularly if they are placed (39) __________.
These areas are known as (40) __________.
Left gondola end — prime position: used to launch launch new products [repeated word as printed].
Right gondola end — often find (41) __________ displayed here.
Exit: checkout — often used to sell (42) __________.
```

[Original question page](assets/5405a72ed13861f89769a22c3d7f355fb6b5ad1c9d248501492ec83b8f778003.jpg)

![Original figure](assets/5405a72ed13861f89769a22c3d7f355fb6b5ad1c9d248501492ec83b8f778003.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/da107d9c6c5779b9605eccea3de989107d38043db1a5e19e0bf10670e02ffe1a.jpg; PDF page 66; full -->

```text
60
Practice Test 3
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-12 which are based on Reading
Passage 1 below.
[Source note: the printed introduction says “Passage 2”; the heading and Questions 1–12 identify this as Passage 1.]
SPOKEN CORPUS COMES TO LIFE
A   The compiling of dictionaries has been historically the provenance
of studious professorial types - usually bespectacled - who love
to pore over weighty tomes and make pronouncements on the
finer nuances of meaning. They were probably good at crosswords
and definitely knew a lot of words, but the image was always
rather dry and dusty. The latest technology, and simple technology
at that, is revolutionising the content of dictionaries and the way
they are put together.
B   For the first time, dictionary publishers are incorporating real,
spoken English into their data. It gives lexicographers (people
who write dictionaries) access to a more vibrant, up-to-date
vernacular language which has never really been studied before.
 In one project, 150 volunteers each agreed to discreetly tie a
Walkman recorder to their waist and leave it running for anything
up to two weeks. Every conversation they had was recorded. When
the data was collected, the length of tapes was 35 times the depth
of the Atlantic Ocean. Teams of audio typists transcribed the tapes
to produce a computerised database of ten million words.
C   This has been the basis - along with an existing written corpus -
for the Language Activator dictionary, described by lexicographer
Professor Randolph Quirk as “the book the world has been waiting
for”. It shows advanced foreign learners of English how the
language is really used. In the dictionary, key words such as “eat”
are followed by related phrases such as “wolf down” or “be a
picky eater”, allowing the student to choose the appropriate phrase.
D    “This kind of research would be impossible without computers,”
said Delia Summers, a director of dictionaries. “It has transformed
the way lexicographers work. If you look at the
 word “like”, you
may intuitively think that the first and most frequent meaning is
the verb, as in “I like swimming”. It is not. It is the preposition, as
in: “she walked like a duck”. Just because a word or phrase is
```

[Original question page](assets/da107d9c6c5779b9605eccea3de989107d38043db1a5e19e0bf10670e02ffe1a.jpg)

<!-- Source: /api/assets/56a5e90ae494fd868edbfbd7a6fff434878bf1eb95c289eab920da313bd5346f.jpg; PDF page 67; full -->

```text
61
Reading
used doesn’t mean it ends up in a dictionary. The sifting out process
is as vital as ever. But the database does allow lexicographers to
search for a word and find out how frequently it is used - something
that could only be guessed at intuitively before.
E  Researchers have found that written English works in a very
different way to spoken English. The phrase “say what you like”
literally means “feel free to say anything you want”, but in reality
it is used, evidence shows, by someone to prevent the other person
voicing disagreement. The phrase “it”s a question of crops up on
the database over and over again. It has nothing to do with enquiry,
but it’s one of the most frequent English phrases which has never
been in a language learner’s dictionary before: it is now.
F The Spoken Corpus computer shows how inventive and humorous
people are when they are using language by twisting familiar
phrases for effect. It also reveals the power of the pauses and
noises we use to play for time, convey emotion, doubt and irony.
G For the moment, those benefiting most from the Spoken Corpus
are foreign learners. “Computers allow lexicographers to search
quickly through more examples of real English,” said Professor
Geoffrey Leech of Lancaster University. “They allow dictionaries
to be more accurate and give a feel for how language is being
used.” The Spoken Corpus is part of the larger British National
Corpus, an initiative carried out by several groups involved in the
production of language learning materials: publishers, universities
and the British Library.
```

[Original question page](assets/56a5e90ae494fd868edbfbd7a6fff434878bf1eb95c289eab920da313bd5346f.jpg)

<!-- Source: /api/assets/dae1a3c4a8d54c2416b74121914f24b08ddbcede2977853fb5ff5a371a613e91.jpg; PDF page 68; full -->

```text
62
List of Headings
i Grammar is corrected
ii New method of research
iii Technology learns from dictionaries
iv Non-verbal content
v The first study of spoken language
vi Traditional lexicographical methods
vii Written English tells the truth
viii New phrases enter dictionary
ix A cooperative research project
x Accurate word frequency counts
xi Alternative expressions provided
Practice Test 3
Questions 1-6
Reading Passage 1 has seven paragraphs (A-G). Choose the most suitable heading for each
paragraph from the list of headings below. Write the appropriate numbers (i-xi) in boxes 1-6
on your answer sheet. Paragraph C has been done for you as an example.
NB There are more headings than paragraphs so you will not use all of them. You may use
any heading more than once.
1 Paragraph A
2 Paragraph B
Example Answer
      Paragraph C xi
3 Paragraph D
4 Paragraph E
5 Paragraph F
6 Paragraph G
```

[Original question page](assets/dae1a3c4a8d54c2416b74121914f24b08ddbcede2977853fb5ff5a371a613e91.jpg)

<!-- Source: /api/assets/caff301c3c2c3e596b2647f028766b29c2677e34e6b3f96bbf7579cb99231c26.jpg; PDF page 69; full -->

```text
Reading
Questions 7–11
The diagram below illustrates the information provided in paragraphs B–F of Reading Passage 1. Complete the labels on the diagram with an appropriate word or words. Use NO MORE THAN THREE WORDS for each space. Write your answers in boxes 7–11 on your answer sheet.
Diagram (complete original retained below):
Current, real-life data collected during Research [Example] → Spoken Corpus computer
The portrayal of feelings through (11) __________ → Spoken Corpus computer
Spoken Corpus computer → LANGUAGE ACTIVATOR
Data from (7) __________ written corpus → LANGUAGE ACTIVATOR
LANGUAGE ACTIVATOR → Key words and (8) __________
LANGUAGE ACTIVATOR → Most frequently used (9) __________ of words
LANGUAGE ACTIVATOR → Differences between written and (10) __________ use
Choose the appropriate letter A–D and write it in box 12 on your answer sheet.
12 Why was this article written?
A To give an example of a current dictionary.
B To announce a new approach to dictionary writing.
C To show how dictionaries have progressed over the years.
D To compare the content of different dictionaries.
```

[Original question page](assets/caff301c3c2c3e596b2647f028766b29c2677e34e6b3f96bbf7579cb99231c26.jpg)

![Original figure](assets/caff301c3c2c3e596b2647f028766b29c2677e34e6b3f96bbf7579cb99231c26.jpg)

<!-- Source: /api/assets/d6ff71fbbe110bc3b83ffae84895b1b77c992fbf7a9e19e138cccf56f0f7aab2.jpg; PDF page 70; full -->

```text
64
Practice Test 3
READING PASSAGE 2
You should spend about 20 minutes on Questions 13-26 which are based on Reading
Passage 2 below.
Moles happy as homes go underground
A  The first anybody knew about Dutchman
Frank Siegmund and his family was
when workmen tramping through a field
found a narrow steel chimney protruding
through the grass. Closer inspection
revealed a chink of sky-light window
among the thistles, and when amazed
investigators moved down the side of the
hill they came across a pine door
complete with leaded diamond glass and
a brass knocker set into an underground
building. The Siegmunds had managed
to live undetected for six years outside
the border town of Breda, in Holland.
They are the latest in a clutch of
individualistic homemakers who have
burrowed underground in search of
tranquillity.
B  Most, falling foul of strict building
regulations, have been forced to
dismantle their individualistic homes and
return to more conventional lifestyles.
But subterranean suburbia, Dutch-style,
is about to become respectable and
chic. Seven luxury homes cosseted
away inside a high earth-covered noise
embankment next to the main Tilburg
city road recently went on the market for
$296,500 each. The foundations had yet
to be dug, but customers queued up to
buy the unusual part-submerged
houses, whose back wall consists of a
grassy mound and whose front is a long
glass gallery.
C  The Dutch are not the only would-be
moles. Growing numbers of Europeans
are burrowing below ground to create
houses, offices, discos and shopping
malls. It is already proving a way of life in
extreme climates; in winter months in
Montreal, Canada, for instance, citizens
can escape the cold in an underground
complex complete with shops and even
health clinics. In Tokyo builders are
planning a massive underground city to
be begun in the next decade, and
underground shopping malls are already
common in Japan, where 90 percent of
the population is squeezed into 20
percent of the landspace.
D   Building big commercial buildings
underground can be a way to avoid
disfiguring or threatening a beautiful or
environmentally sensitive landscape.
Indeed many of the buildings which
consume most land -such as cinemas,
supermarkets, theatres, warehouses or
libraries -have no need to be on the
surface since they do not need windows.
E   There are big advantages, too, when it
comes to private homes. A development
of 194 houses which would take up 14
hectares of land above ground would
occupy 2.7 hectares below it, while the
number of roads would be halved. Under
several metres of earth, noise is minimal
and insulation is excellent. We get 40 to
50 enquiries a week, says Peter
Carpenter, secretary of the British Earth
Sheltering Association, which builds
```

[Original question page](assets/d6ff71fbbe110bc3b83ffae84895b1b77c992fbf7a9e19e138cccf56f0f7aab2.jpg)

<!-- Source: /api/assets/3e10f46f9b5d4daf2ab4c97550fe8d2e73074bfecde018719cb91d494ae2f323.jpg; PDF page 71; full -->

```text
65
Reading
similar homes in Britain. "People see this
as a way of building for the future." An
underground dweller himself, Carpenter
has never paid a heating bill, thanks to
solar panels and natural insulation.
F   In Europe the obstacle has been
conservative local authorities and
developers who prefer to ensure quick
sales with conventional mass produced
housing. But the Dutch development was
greeted with undisguised relief by South
Limburg planners because of Holland’s
chronic shortage of land. It was the
Tilburg architect Jo Hurkmans who hit on
the idea of making use of noise
embankments on main roads. His two-
floored, four-bedroomed, two-
bathroomed detached homes are now
taking shape. "They are not so much
below the earth as in it," he says. "All the
light will come through the glass front,
which runs from the second floor ceiling
to the ground. Areas which do not need
much natural lighting are at the back. The
living accommodation is to the front so
nobody notices that the back is dark."
G  In the US, where energy-efficient homes
became popular after the oil crisis of
1973, 10,000 underground houses have
been built. A terrace of five homes,
Britain’s first subterranean development,
is under way in Nottinghamshire. Italy’s
outstanding example of subterranean
architecture is the Olivetti residential
centre in Ivrea. Commissioned by
Roberto Olivetti in 1969, it comprises
82 one-bedroomed apartments and
12 maisonettes and forms a house/
hotel for Olivetti employees. It is built
into a hill and little can be seen from
outside except a glass facade. Patrizia
Vallecchi, a resident since 1992, says
it is little different from living in a
conventional apartment.
H  Not everyone adapts so well, and in
Japan scientists at the Shimizu
Corporation have developed "space
creation" systems which mix light,
sounds, breezes and scents to
stimulate people who spend long
periods below ground. Underground
offices in Japan are being equipped
with "virtual" windows and mirrors,
while underground departments in the
University of Minnesota have
periscopes to reflect views and light.
I   But Frank Siegmund and his family love
their hobbit lifestyle. Their home
evolved when he dug a cool room for
his bakery business in a hill he had
created. During a heatwave they took
to sleeping there. "We felt at peace
and so close to nature," he says.
"Gradually I began adding to the
rooms. It sounds strange but we are
so close to the earth we draw strength
from its vibrations. Our children love it;
not every child can boast of being
watched through their playroom
windows by rabbits.
```

[Original question page](assets/3e10f46f9b5d4daf2ab4c97550fe8d2e73074bfecde018719cb91d494ae2f323.jpg)

<!-- Source: /api/assets/db16af04fb509af5c030fe8fc31c6f77137bb995354afaf8074052b6320d6487.jpg; PDF page 72; full -->

```text
66
Practice Test 3
Example Answer
Paragraph A xii
List of Headings
i A designer describes his houses
ii Most people prefer conventional housing
iii Simulating a natural environment
iv How an underground family home developed
v Demands on space and energy are reduced
vi The plans for future homes
vii Worldwide examples of underground living accommodation
viii Some buildings do not require natural light
ix Developing underground services around the world
x Underground living improves health
xi Homes sold before completion
xii An underground home is discovered
Questions 13-20
Reading Passage 2 has nine paragraphs (A-I). Choose the most suitable heading for each
paragraph from the list of headings below. Write the appropriate numbers (i-xii) in boxes 13–20 on your answer sheet. Paragraph A has been done for you as an example.
NB There are more headings than paragraphs so you will not use all of them.
13 Paragraph B
14 Paragraph C
15 Paragraph D
16 Paragraph E
17 Paragraph F
18 Paragraph G
19 Paragraph H
20 Paragraph I
```

[Original question page](assets/db16af04fb509af5c030fe8fc31c6f77137bb995354afaf8074052b6320d6487.jpg)

<!-- Source: /api/assets/c55d62bfb88bbef18681877f224752bc6d73991a5ab561b2333f71c2cd8443c8.jpg; PDF page 73; full -->

```text
67
Reading
Questions 21-26
Complete the sentences below with words taken from the reading passage. Use NO MORE
THAN THREE WORDS for each answer. Write your answers in boxes 21-26 on your
answer sheet.
21 Many developers prefer mass-produced houses because they ...
22 The Dutch development was welcomed by ...
23 Hurkmans’ houses are built into ...
24 The Ivrea centre was developed for ...
25 Japanese scientists are helping people ... underground life.
26 Frank Siegmund’s first underground room was used for ...
```

[Original question page](assets/c55d62bfb88bbef18681877f224752bc6d73991a5ab561b2333f71c2cd8443c8.jpg)

<!-- Source: /api/assets/6b62d6fa276372fb3f9af1ca05caf30bc1a2b0ec256b6d6f097efb04976f1884.jpg; PDF page 74; full -->

```text
68
Practice Test 3
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-38 which are based on Reading Passage
3 below.
A Workaholic Economy
FOR THE first century or so of the
industrial    revolution,    increased
productivity led to decreases in working
hours. Employees who had been putting
in 12-hour days, six days a week, found
their time on the job shrinking to 10 hours
daily, then, finally, to eight hours, five
days a week. Only a generation ago social
planners worried about what people
would do with all this new-found free
time. In the US, at least, it seems they
need not have bothered.
Although the output per hour of work has
more than doubled since 1945, leisure
seems reserved largely for the
unemployed and underemployed. Those
who work full-time spend as much time
on the job as they did at the end of World
War II. In fact, working hours have
increased noticeably since 1970 —
perhaps because real wages have
stagnated since that year. Bookstores now
abound with manuals describing how to
manage time and cope with stress.
There are several reasons for lost leisure.
Since 1979, companies have responded
to improvements in the business climate
by having employees work overtime
rather than by hiring extra personnel, says
economist Juliet B. Schor of Harvard
University. Indeed, the current economic
recovery has gained a certain amount of
notoriety for its “jobless” nature:
increased production has been almost
entirely decoupled from employment.
Some firms are even downsizing as their
profits climb. “All things being equal,
we’d be better off spreading around the
work,’ observes labour economist
Ronald G. Ehrenberg of Cornell
University.
Yet a host of factors pushes employers
to hire fewer workers for more hours
and, at the same time, compels workers
to spend more time on the job. Most of
those incentives involve what Ehrenberg
calls the structure of compensation:
quirks in the way salaries and benefits
are organised that make it more
profitable to ask 40 employees to labour
an extra hour each than to hire one more
worker to do the same 40-hour job.
Professional and managerial employees
supply the most obvious lesson along
these lines. Once people are on salary,
their cost to a firm is the same whether
they spend 35 hours a week in the office
or 70. Diminishing returns may
eventually set in as overworked
employees lose efficiency or leave for
more arable pastures. But in the short
run, the employer’s incentive is clear.
Even hourly employees receive benefits -
such as pension contributions and medical
insurance - that are not tied to the number
of hours they work. Therefore, it is more

Reprinted with permission. Copyright © 1994 by Scientific American, Inc. All rights reserved.
```

[Original question page](assets/6b62d6fa276372fb3f9af1ca05caf30bc1a2b0ec256b6d6f097efb04976f1884.jpg)

<!-- Source: /api/assets/de9f5c46603e4ee80235f45a27b72070e55d1b6c352106f886d3075a5cb1f79e.jpg; PDF page 75; full -->

```text
69
Writing
profitable for employers to work their
existing employees harder.
For all that employees complain about
long hours, they, too, have reasons not
to trade money for leisure. “People who
work reduced hours pay a huge penalty
in career terms,” Schor maintains. “It’s
taken as a negative signal’ about their
commitment to the firm.’  [Lotte] Bailyn
[of Massachusetts Institute of
Technology] adds that many corporate
managers find it difficult to measure the
contribution of their underlings to a
firm’s well-being, so they use the number
of hours worked as a proxy for output.
“Employees know this,” she says, and
they adjust their behavior accordingly.
“Although the image of the good worker
is the one whose life belongs to the
company,” Bailyn says, “it 
doesn’t fit the
facts.’ She cites both quantitative and
qualitative studies that show increased
productivity for part-time workers: they
make better use of the time they have, and
they are less likely to succumb to fatigue in
stressful jobs. Companies that employ more
workers for less time also gain from the
resulting redundancy, she asserts. “The extra
people can cover the contingencies 
that you
know are going to happen, such as when
crises take people away from the
workplace.’ Positive experiences with
reduced hours have begun to change the
more-is-better culture at some
companies, Schor reports.
Larger firms, in particular, appear to be
more willing to experiment with flexible
working arrangements...
It may take even more than changes in
the financial and cultural structures of
employment for workers successfully to
trade increased productivity and money
for leisure time, Schor contends. She
says the U.S. market for goods has
become skewed by the assumption of
full-time, two-career  households.
Automobile makers no longer
manufacture cheap models, and
developers do not build the tiny
bungalows that served the first postwar
generation of home buyers. Not even the
humblest household object is made
without a microprocessor. As Schor
notes, the situation is a curious inversion
of the “appropriate technology” vision
that designers have had for developing
countries: U.S. goods are appropriate
only for high incomes and long hours.
Paul Walluh
```

[Original question page](assets/de9f5c46603e4ee80235f45a27b72070e55d1b6c352106f886d3075a5cb1f79e.jpg)

<!-- Source: /api/assets/257807f8ddc64a19cdb14a0cb778ac0715bbbc000ebc6a5d202ffa852126cdf6.jpg; PDF page 76; full -->

```text
70
Practice Test 3
Questions 27-32
Do the following statements agree with the views of the writer in Reading Passage 3? In
boxes 27-32 write
YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
Example Answer
During the industrial revolution people worked harder.      NOT GIVEN
27 Today, employees are facing a reduction in working hours.
28 Social planners have been consulted about US employment figures.
29 Salaries have not risen significantly since the 1970s.
30 The economic recovery created more jobs.
31 Bailyn’s research shows that part-time employees work more efficiently.
32 Increased leisure time would benefit two-career households.
Questions 33-34
Choose the appropriate letters A-D and write them in boxes 33 and 34 on your answer sheet.
33  Bailyn argues that it is better for a company to employ more workers because
A it is easy to make excess staff redundant.
B crises occur if you are under-staffed.
C people are available to substitute for absent staff.
D they can project a positive image at work.
34 Schor thinks it will be difficult for workers in the US to reduce their working hours
because
A they would not be able to afford cars or homes.
B employers are offering high incomes for long hours.
C the future is dependent on technological advances.
D they do not wish to return to the humble post-war era.
```

[Original question page](assets/257807f8ddc64a19cdb14a0cb778ac0715bbbc000ebc6a5d202ffa852126cdf6.jpg)

<!-- Source: /api/assets/153aa4feb2ae7d1909837b4977a6f744770f0f8ca24f8542caff71b05eb766ad.jpg; PDF page 77; full -->

```text
71
Questions 35-38
The writer mentions a number of factors that have resulted, in employees working longer
hours. Which FOUR of the following factors are mentioned? Write your answers (A-H) in
boxes 35-38 on your answer sheet.
Reading
List of Factors
A Books are available to help employees cope with stress.
B Extra work is offered to existing employees.
C Increased production has led to joblessness.
D Benefits and hours spent on the job are not linked.
E Overworked employees require longer to do their work.
F Longer hours indicate greater commitment to the firm.
G Managers estimate staff productivity in terms of hours worked.
H Employees value a career more than a family.
```

[Original question page](assets/153aa4feb2ae7d1909837b4977a6f744770f0f8ca24f8542caff71b05eb766ad.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/d2351fd8364038ded4222670ce01996798e9fdf88101586828d3429891a8d057.jpg; PDF page 78; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows the amount of money per week spent on fast foods in Britain. The graph shows the trends in consumption of fast foods.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

The original figure is retained for the plotted values, labels, arrows and spatial layout.
```

[Original question page](assets/d2351fd8364038ded4222670ce01996798e9fdf88101586828d3429891a8d057.jpg)

![Original figure](assets/d2351fd8364038ded4222670ce01996798e9fdf88101586828d3429891a8d057.jpg)

### Task 2

<!-- Source: /api/assets/3592d56fdf2363d402124b70db5777ffdb863264963854363ad71fd23c058760.jpg; PDF page 79; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic:

News editors decide what to broadcast on television and what to print in newspapers. What factors do you think influence these decisions? Do we become used to bad news? Would it be better if more good news was reported?

You should write at least 250 words.

Use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.
```

[Original question page](assets/3592d56fdf2363d402124b70db5777ffdb863264963854363ad71fd23c058760.jpg)

## 口语

### 原书口语任务

<!-- Source: /api/assets/b1dcfea3c0a4db336ef4342e62645e7b1336a47ff7cd99cc0e5a570fd282e0b6.png; PDF page 80; full -->

```text
74
Practice Test 3
SPEAKING
CANDIDATE`S CUE CARD
      Task 3
THE PUBLIC HOLIDAY
There will soon be a public holiday in the country your examiner comes
from. You want to find out about the holiday.
Ask the examiner about: the name of the public holiday
the significance of the holiday
availability of services on the day
  (banks/shops/cinemas)
things for visitors to do
how she/he plans to spend the day
```

[Original question page](assets/b1dcfea3c0a4db336ef4342e62645e7b1336a47ff7cd99cc0e5a570fd282e0b6.png)
