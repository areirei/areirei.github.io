# 剑雅 1 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 144

138
Practice Test 3
LISTENING
Section 1
1 B
2 D
3 C
4 A
5 Richard Lee (must have correct spelling of
“Lee “ and capitals)
6 30 Enmore Road (must have correct
spelling and capitals)
7 Newport (must have correct spelling and
capital “N”)
8 Architecture
9 LJX 058K
10 Ford
11 C
12 (on the) (front) window/windscreen
Section 2
13 November 1991
14 (historic) ships
15 green arrows
16 information desk
17 stairs to climb//lots of stairs
18 every hour
19 Captain Cook
20 the sea
21 Australian artists/painters
22 $70
23 souvenirs
PRACTICE TEST 3
Section 3
24 B
25 C
26 D
27 A
28 law has changed//law changes//changes in
law
29 (powerful) computer programs
30 from home (computer)
31 hotels/hotel beds/rooms
32 hire cars
Section 4
33 displays//products//displays and products
34 (hidden) TV cameras
35 recorder//recording
36 “Spaceman”
37 position//shelf//spot//place
38 walk (straight/right) past // ignore//pass
39 at eye level//near customers’ eyes
40 hotspots
41 special offers
42 chocolates

1. B

2. D

3. C

4. A

5. Richard Lee / RICHARD LEE

6. 30 Enmore Road / 30 ENMORE ROAD / 30ENMOREROAD

7. Newport / NEWPORT

8. Architecture

9. LJX 058K / LJX058K

10. Ford

11. C

12. window / front window / on the window / on the front window / windscreen / front windscreen / on the windscreen / on the front windscreen

### Part 2 · source page 144

138
Practice Test 3
LISTENING
Section 1
1 B
2 D
3 C
4 A
5 Richard Lee (must have correct spelling of
“Lee “ and capitals)
6 30 Enmore Road (must have correct
spelling and capitals)
7 Newport (must have correct spelling and
capital “N”)
8 Architecture
9 LJX 058K
10 Ford
11 C
12 (on the) (front) window/windscreen
Section 2
13 November 1991
14 (historic) ships
15 green arrows
16 information desk
17 stairs to climb//lots of stairs
18 every hour
19 Captain Cook
20 the sea
21 Australian artists/painters
22 $70
23 souvenirs
PRACTICE TEST 3
Section 3
24 B
25 C
26 D
27 A
28 law has changed//law changes//changes in
law
29 (powerful) computer programs
30 from home (computer)
31 hotels/hotel beds/rooms
32 hire cars
Section 4
33 displays//products//displays and products
34 (hidden) TV cameras
35 recorder//recording
36 “Spaceman”
37 position//shelf//spot//place
38 walk (straight/right) past // ignore//pass
39 at eye level//near customers’ eyes
40 hotspots
41 special offers
42 chocolates

13. November 1991

14. ships / historic ships

15. green arrows

16. information desk

17. stairs to climb / lots of stairs

18. every hour

19. Captain Cook

20. the sea

21. Australian artists / Australian painters

22. $ 70 / $70

23. souvenirs

### Part 3 · source page 144

138
Practice Test 3
LISTENING
Section 1
1 B
2 D
3 C
4 A
5 Richard Lee (must have correct spelling of
“Lee “ and capitals)
6 30 Enmore Road (must have correct
spelling and capitals)
7 Newport (must have correct spelling and
capital “N”)
8 Architecture
9 LJX 058K
10 Ford
11 C
12 (on the) (front) window/windscreen
Section 2
13 November 1991
14 (historic) ships
15 green arrows
16 information desk
17 stairs to climb//lots of stairs
18 every hour
19 Captain Cook
20 the sea
21 Australian artists/painters
22 $70
23 souvenirs
PRACTICE TEST 3
Section 3
24 B
25 C
26 D
27 A
28 law has changed//law changes//changes in
law
29 (powerful) computer programs
30 from home (computer)
31 hotels/hotel beds/rooms
32 hire cars
Section 4
33 displays//products//displays and products
34 (hidden) TV cameras
35 recorder//recording
36 “Spaceman”
37 position//shelf//spot//place
38 walk (straight/right) past // ignore//pass
39 at eye level//near customers’ eyes
40 hotspots
41 special offers
42 chocolates

24. B

25. C

26. D

27. A

28. law has changed / law changes / changes in law

29. computer programs / powerful computer programs

30. from home / from home computer

31. hotels / hotel beds / rooms

32. hire cars

### Part 4 · source page 144

138
Practice Test 3
LISTENING
Section 1
1 B
2 D
3 C
4 A
5 Richard Lee (must have correct spelling of
“Lee “ and capitals)
6 30 Enmore Road (must have correct
spelling and capitals)
7 Newport (must have correct spelling and
capital “N”)
8 Architecture
9 LJX 058K
10 Ford
11 C
12 (on the) (front) window/windscreen
Section 2
13 November 1991
14 (historic) ships
15 green arrows
16 information desk
17 stairs to climb//lots of stairs
18 every hour
19 Captain Cook
20 the sea
21 Australian artists/painters
22 $70
23 souvenirs
PRACTICE TEST 3
Section 3
24 B
25 C
26 D
27 A
28 law has changed//law changes//changes in
law
29 (powerful) computer programs
30 from home (computer)
31 hotels/hotel beds/rooms
32 hire cars
Section 4
33 displays//products//displays and products
34 (hidden) TV cameras
35 recorder//recording
36 “Spaceman”
37 position//shelf//spot//place
38 walk (straight/right) past // ignore//pass
39 at eye level//near customers’ eyes
40 hotspots
41 special offers
42 chocolates

33. displays / products / displays and products

34. TV cameras / hidden TV cameras

35. recorder / recording

36. Spaceman

37. position / shelf / spot / place

38. walk past / walk straight past / walk right past / ignore / pass

39. at eye level / near customers' eyes

40. hotspots

41. special offers

42. chocolates

## A 类阅读

### Academic Reading · source page 145

139
Answer keys
READING
READING PASSAGE 1 Spoken corpus comes to life
Questions 1-6
Questions 7-11
Suggested approach
• Read the task rubric carefully.
• Note that you must use a maximum of three
words but that these do not have to be taken
from the passage. Note also that you need to
focus on particular paragraphs.
• Scan the diagram carefully and make sure you
understand it. You have already read the
passage once so you should realise that the
diagram summarises most of the information in
the passage.
• Look at item 7. This box describes an input into
the Language Activator that is not part of the
Spoken Corpus. Skim through the passage to
find out what other kind of information is going
into the Language Activator.
• The answer occurs at the beginning of
paragraph C although it is helpful to read
  paragraph B too. An existing written corpus has
been used.
• Repeat this procedure with the rest of the
questions.


Question | Answer | Location (where supplied)
1 | vi
2 | ii
3 | x
4 | viii
5 | iv
6 | ix
7 | existing | “This has been the basis — along with the company’s existing written corpus …” [as quoted by the source answer page]
8 | (related) phrases | “… key words … are followed by related phrases …”
9 | meanings // forms | gist of paragraph D
10 | spoken // real // oral | “… written English works in a very different way to spoken English.”
11 | noise // pauses // noises and pauses | “It also reveals the power of the pauses and noises we use to play for time, convey emotion doubt and irony.”
12 | B

Questions Task Skills tested

1-6 Paragraph headings • detailed reading
• identifying main ideas/themes/topics
• understanding gist
7-11 Labelling a diagram • locating specific information
• understanding a process
• understanding paraphrase
• distinguishing examples from main ideas
12 Global multiple choice • identifying the overall intention of the writer

### Academic Reading · source page 146

140
Practice Test 3
READING PASSAGE 2 Moles happy as homes go underground
Question 13-20
Questions 21-26
Suggested approach
• Read the task rubric carefully. Note that you
must use a maximum of three words for each
answer, but that these do not have to be taken
from the passage.
• You can take a straightforward approach to this
set of questions as the items are not dependent
upon each other.
• Read question 21 and note that you need to
complete the sentence with the reason why
developers prefer mass-produced housing.
• Skim through the text for a reference to
developers and/or mass produced housing.
• This information is located in paragraph F.
Here you will read the sentence: “In Europe the
obstacle has been conservative local authorities
and developers who prefer to ensure quick sales
with conventional mass produced housing.”
• From this sentence you can understand that the
reason why they prefer such housing is because
it sells quickly.
• Read question 21 again remembering that you
have to complete the sentence using a
grammatically correct form of the answer. In
this case, “sell quickly” is the best answer.
• Repeat this procedure with items 22-26.

Question | Answer
13 | xi
14 | ix
15 | viii
16 | v
17 | i
18 | vii
19 | iii
20 | iv
Question | Answer | Location of answer in text
21 | sell (more) quickly | “In Europe the obstacle has been … developers who prefer to ensure quick sales with conventional mass-produced housing.”
22 | (South Limberg) planners | “… the Dutch development was greeted with undisguised relief by South Limburg planners …”
23 | (road/noise) embankments | “It was … Hurkmans who hit on the idea of making use of noise embankments …”
24 | Olivetti employees | “… the Olivetti centre in Ivrea … forms a house/hotel for Olivetti employees.”
25 | adapt to | gist of paragraph H, cued by “Not everyone adapts so well …”
26 | his bakery business // a cool room | “Their home evolved when he dug a cool room for his bakery business in a hill he had created.”
[Source note: the answer table prints “Limberg”, while the passage spells it “Limburg”. Original accepted-answer rules are not changed by text conversion.]

Questions Task Skills tested

13-20 Paragraph headings • detailed reading
• identifying main ideas/themes/topics
• understanding gist
21-26 Sentence completion • skimming for factual information
• understanding description
• understanding paraphrase

[Source correction: the suggested approach says answers need not be taken from the passage. The actual Questions21–26 explicitly require words taken from the reading passage; follow the question instruction.]

### Academic Reading · source page 147

Answer keys
READING PASSAGE 3 A workaholic economy
Questions 27-32
Suggested approach
• Read the task rubric carefully. Note that you
have to make a judgement about the writer’s
views.
• Note, also, the difference between NO (which
contradicts the writer’s views) and NOT
GIVEN (which means that the writer doesn’t
mention this at all).
• Read question 27. You have to decide whether
the writer states that employees have fewer
working hours today (compared with the past).
• Skim through the passage to see if you can
come across this information or any
contradictory information.
• The first paragraph states that working hours
were reduced after the industrial revolution.
However in the second paragraph, the writer
states that “… working hours have increased
noticeably since 1970 …” and if you read on
this fact is reiterated.  So the statement (Q27)
actually says the opposite of what the writer
says. The answer to question 27 is therefore
NO.
• Go on to item 28 and repeat this procedure.


Question | Answer | Location (where supplied)
27 | NO | “… working hours have increased noticeably since1970 …”
28 | NOT GIVEN
29 | YES | “… real wages have stagnated since that year(1970).”
30 | NO | “… the current economic recovery has gained a certain amount of notoriety for its «jobless» nature.”
31 | YES | “She cites … studies that show increased productivity for part time workers …”
32 | NOT GIVEN
33 | C
34 | A
35–38 | B,D,F,G in any order

Questions Task Skills tested

27-32 Yes, No, Not Given • skimming for detailed information
• understanding gist and paraphrase
• identifying attitude and opinion
33-34 Multiple choice • skimming for information
• identifying opinion
• understanding paraphrase
• distinguishing between main and supporting points
35-38 Selecting factors • skimming for specific information
• making inferences
• understanding paraphrase

1. vi

2. ii

3. x

4. viii

5. iv

6. ix

7. existing

8. phrases / related phrases

9. meanings / forms

10. spoken / real / oral

11. noise / pauses / noises and pauses

12. B

13. xi

14. ix

15. viii

16. v

17. i

18. vii

19. iii

20. iv

21. sell quickly / sell more quickly

22. planners / South Limberg planners / South Limburg planners

23. embankments / road embankments / noise embankments

24. Olivetti employees

25. adapt to

26. his bakery business / a cool room

27. NO

28. NOT GIVEN

29. YES

30. NO

31. YES

32. NOT GIVEN

33. C

34. A

35. B / D / F / G

36. B / D / F / G

37. B / D / F / G

38. B / D / F / G

## A 类写作

### Writing material: c1-t3-w-1

Original bar chart and line graph inspected. Bar title: Expenditure on fast foods by income groups; units pence per person per week; categories high income, average income, low income; series hamburgers, fish and chips, pizza. Heights are visual estimates, not exact labelled data: high income about 43 pence hamburgers, 18 fish and chips, 20 pizza; average income about 33, 25, 12 respectively; low income about 14, 18, 8 respectively. Accept sensible rounded estimates. Hamburger and pizza spending is greater in higher income groups. Average-income consumers spend most on fish and chips in absolute terms, while fish and chips is the largest category within the low-income group. Line title: Consumption of fast foods 1970–1990; vertical axis grams. Hamburgers rise from roughly 80 to over 500 grams, becoming the largest series; pizza rises from roughly 40 to around 280 grams. Fish and chips start around 300 grams, fall toward 200 in the mid-1980s, then recover to roughly 240 by 1990. Hamburger consumption overtakes fish and chips in the early-to-mid 1980s; pizza finishes slightly above fish and chips. Do not invent a survey sample size or claim exact values from unlabelled curves.



### Writing material: c1-t3-w-2

This early multi-question task contains THREE explicit questions, despite the broad system type label two-part: factors influencing editorial choices; whether people become used to bad news; whether more good news would be better. All three require a response. Do not silently reduce it to two questions.



## 口语

### 原书口语任务 · reference on source page 80

INTERVIEWER’S NOTES
THE PUBLIC HOLIDAY
Choose a lesser known public holiday from your country. Be prepared to
provide some accurate information on the history and significance of the
day. If in-country, tell the candidate how you will spend the day.
If you are in a non-English speaking country, tell the candidate how people
normally spend this day back home.
Provide information about the availability of shops, services and banks on
the day.

[Complete original page](assets/d36b82e832476e859063afc68c10f8ae6f05950c49bb79274519f12c02f965af.jpg)
