# 剑雅 9 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/4de968f915d1335bccf14672772432701926cbdd450d8662fd95e0dfe535bf45.jpg; PDF page 71; full -->

```text
SECTION 1 Questions 1–10
Questions 1–4
Complete the table below. Write ONE WORD ONLY for each answer.
Health Centres
| Name of centre | Doctor’s name | Advantage |
| --- | --- | --- |
| The Harvey Clinic | Example — Dr Green | especially good with (1) __________ |
| The (2) __________ Health Practice | Dr Fuller | offers (3) __________ appointments |
| The Shore Lane Health Centre | Dr (4) __________ | |
Questions 5–6
Choose TWO letters, A–E.
Which TWO of the following are offered free of charge at Shore Lane Health Centre?
A acupuncture
B employment medicals
C sports injury therapy
D travel advice
E vaccinations
```

[Original question page](assets/4de968f915d1335bccf14672772432701926cbdd450d8662fd95e0dfe535bf45.jpg)

<!-- Source: /api/assets/93ff2270ea4c9a9c2835e4b3f96623f9c6a6e21064915ada7b7cfc0ba71bff58.jpg; PDF page 72; full -->

```text
Questions 7–10
Complete the table below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
Talks for patients at Shore Lane Health Centre
| Subject of talk | Date/Time | Location | Notes |
| --- | --- | --- | --- |
| Giving up smoking | 25th February at 7pm | room 4 | useful for people with asthma or (7) __________ problems |
| Healthy eating | 1st March at 5pm | the (8) __________ (Shore Lane) | anyone welcome |
| Avoiding injuries during exercise | 9th March at (9) __________ | room 6 | for all (10) __________ |
```

[Original question page](assets/93ff2270ea4c9a9c2835e4b3f96623f9c6a6e21064915ada7b7cfc0ba71bff58.jpg)

### Part 2

<!-- Source: /api/assets/033575a5ca0ab23dc0bf25a7a132ae32e8270d66726c892843cdf1e26c5b6703.jpg; PDF page 73; full -->

```text
SECTION 2 Questions 11–20
Questions 11–13
Label the diagram below. Choose THREE answers from the box and write the correct letter, A–E, next to questions 11–13.
A electricity indicator
B on/off switch
C reset button
D time control
E warning indicator
Water Heater
[Original perspective diagram retained. Printed central heating radiators arrow points to middle large round dial on lower control panel; hot water arrow points to right large round dial. (11) __________ points to left round control; (12) __________ points to small lower middle control beneath the central dial; (13) __________ points to small feature beneath/right of the right dial. Large time dial at far right is retained. No answers supplied.]
```

[Original question page](assets/033575a5ca0ab23dc0bf25a7a132ae32e8270d66726c892843cdf1e26c5b6703.jpg)

![Original figure](assets/033575a5ca0ab23dc0bf25a7a132ae32e8270d66726c892843cdf1e26c5b6703.jpg)

<!-- Source: /api/assets/3ade22b60263969e10105a83f0fbbccb30a9cd338f4132eef53fd41e3d11f953.jpg; PDF page 74; full -->

```text
Questions 14–18
Where can each of the following items be found?
Choose FIVE answers from the box and write the correct letter, A–G, next to questions 14–18.
Locations
A in box on washing machine
B in cupboard on landing
C in chest of drawers
D next to window in living room
E on shelf by back door
F on top of television
G under kitchen sink
14 pillows __________
15 washing powder __________
16 key __________
17 light bulbs __________
18 map __________
Questions 19 and 20
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
The best place to park in town – next to the station
Phone number for takeaway pizzas – (19) __________
Railway museum closed on (20) __________
```

[Original question page](assets/3ade22b60263969e10105a83f0fbbccb30a9cd338f4132eef53fd41e3d11f953.jpg)

### Part 3

<!-- Source: /api/assets/00766b500465f4110a92a4001adf5219e0b1de65146974cc2acf17c6363e83e5.jpg; PDF page 75; full -->

```text
SECTION 3 Questions 21–30
Questions 21 and 22
Choose the correct letter, A, B or C.
21 In her home country, Kira had
A completed a course.
B done two years of a course.
C found her course difficult.
22 To succeed with assignments, Kira had to
A read faster.
B write faster.
C change her way of thinking.
Questions 23–25
Complete the sentences below. Write ONE WORD ONLY for each answer.
23 Kira says that lecturers are easier to (23) __________ than those in her home country.
24 Paul suggests that Kira may be more (24) __________ than when she was studying before.
25 Kira says that students want to discuss things that worry them or that (25) __________ them very much.
```

[Original question page](assets/00766b500465f4110a92a4001adf5219e0b1de65146974cc2acf17c6363e83e5.jpg)

<!-- Source: /api/assets/40a868609f0dfb553960d06ea98c67cf861d94a95ecf27b5a45842e6458102d5.jpg; PDF page 76; full -->

```text
Test 4

Questions 26-30
Answer the questions below.

Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.

26 How did the students do their practical sessions?

27 In the second semester how often did Kira work in a hospital?

28 How much full-time work did Kira do during the year?

29 Having completed the year, how does Kira feel?

30 In addition to the language, what do overseas students need to become familiar
with?

84
```

[Original question page](assets/40a868609f0dfb553960d06ea98c67cf861d94a95ecf27b5a45842e6458102d5.jpg)

### Part 4

<!-- Source: /api/assets/e33754c580be68486f708f892f3a57c38cc65dc9c0d4150a7620aa150f2c7631.jpg; PDF page 77; full -->

```text
SECTION 4 Questions 31–40
Questions 31–36
Choose the correct letter, A, B or C.
Wildlife in city gardens
31 What led the group to choose their topic?
A They were concerned about the decline of one species.
B They were interested in the effects of city growth.
C They wanted to investigate a recent phenomenon.
32 The exact proportion of land devoted to private gardens was confirmed by
A consulting some official documents.
B taking large-scale photos.
C discussions with town surveyors.
33 The group asked garden owners to
A take part in formal interviews.
B keep a record of animals they saw.
C get in contact when they saw a rare species.
34 The group made their observations in gardens
A which had a large number of animal species.
B which they considered to be representative.
C which had stable populations of rare animals.
35 The group did extensive reading on
A wildlife problems in rural areas.
B urban animal populations.
C current gardening practices.
36 The speaker focuses on three animal species because
A a lot of data has been obtained about them.
B the group were most interested in them.
C they best indicated general trends.
```

[Original question page](assets/e33754c580be68486f708f892f3a57c38cc65dc9c0d4150a7620aa150f2c7631.jpg)

<!-- Source: /api/assets/76a71d4ce10e7fa349aecb39786d28718577c1363bb5f3b9985f22a92677315f.jpg; PDF page 78; full -->

```text
Questions 37–40
Complete the table below. Write ONE WORD ONLY for each answer.
| Animals | Reason for population increase in gardens | Comments |
| --- | --- | --- |
| (37) __________ | suitable stretches of water | massive increase in urban population |
| Hedgehogs | safer from (38) __________ when in cities | easy to (39) __________ them accurately |
| Song thrushes | a variety of (40) __________ to eat; more nesting places available | large survey starting soon |
```

[Original question page](assets/76a71d4ce10e7fa349aecb39786d28718577c1363bb5f3b9985f22a92677315f.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/2a5c124c8a891bac76686f9a413fe1488d03db6ca831c2d2c89e95cde9835ede.jpg; PDF page 79; full -->

```text
Reading

READING

READING PASSAGE 1

You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.

The life and work of Marie Curie

Marie Curie is probably the most famous woman
scientist who has ever lived. Born Maria Sklodowska
in Poland in 1867, she is famous for her work on
radioactivity, and was twice a winner of the Nobel
Prize. With her husband, Pierre Curie, and Henri
Becquerel, she was awarded the 1903 Nobel Prize for
Physics, and was then sole winner of the 1911 Nobel
Prize for Chemistry. She was the first woman to win a
Nobel Prize.

From childhood, Marie was remarkable for her
prodigious memory, and at the age of 16 won a gold
medal on completion of her secondary education. Because her father lost his savings through
bad investment, she then had to take work as a teacher. From her earnings she was able to
finance her sister Bronia's medical studies in Paris, on the understanding that Bronia would, in
turn, later help her to get an education.

In 1891 this promise was fulfilled and Marie went to Paris and began to study at the
Sorbonne (the University of Paris). She often worked far into the night and lived on little more
than bread and butter and tea. She came first in the examination in the physical sciences in
1893, and in 1894 was placed second in the examination in mathematical sciences. It was not
until the spring of that year that she was introduced to Pierre Curie.

Their marriage in 1895 marked the start of a partnership that was soon to achieve results of
world significance. Following Henri Becquerel’s discovery in 1896 of a new phenomenon, which
Marie later called ‘radioactivity’, Marie Curie decided to find out if the radioactivity discovered
in uranium was to be found in other elements. She discovered that this was true for thorium.

Turning her attention to minerals, she found her interest drawn to pitchblende, a mineral
whose radioactivity, superior to that of pure uranium, could be explained only by the presence
in the ore of small quantities of an unknown substance of very high activity. Pierre Curie joined
her in the work that she had undertaken to resolve this problem, and that led to the discovery
of the new elements, polonium and radium. While Pierre Curie devoted himself chiefly to
the physical study of the new radiations, Marie Curie struggled to obtain pure radium in the
metallic state. This was achieved with the help of the chemist André-Louis Debierne, one of

87
```

[Original question page](assets/2a5c124c8a891bac76686f9a413fe1488d03db6ca831c2d2c89e95cde9835ede.jpg)

<!-- Source: /api/assets/2c502f0970d40a825c8db650d89b6c1b6121ccef6b5413d6894cb7c729c50010.jpg; PDF page 80; full -->

```text
Test 4

Pierre Curie’s pupils. Based on the results of this research, Marie Curie received her Doctorate
of Science, and in 1903 Marie and Pierre shared with Becquerel the Nobel Prize for Physics for
the discovery of radioactivity.

The births of Marie's two daughters, Irène and Eve, in 1897 and 1904 failed to interrupt
her scientific work. She was appointed lecturer in physics at the École Normale Supérieure for
girls in Sèvres, France (1900), and introduced a method of teaching based on experimental
demonstrations. In December 1904 she was appointed chief assistant in the laboratory directed
by Pierre Curie.

The sudden death of her husband in 1906 was a bitter blow to Marie Curie, but was also a
turning point in her career: henceforth she was to devote all her energy to completing alone
the scientific work that they had undertaken. On May 13, 1906, she was appointed to the
professorship that had been left vacant on her husband's death, becoming the first woman to
teach at the Sorbonne. In 1911 she was awarded the Nobel Prize for Chemistry for the isolation
of a pure form of radium.

During World War I, Marie Curie, with the help of her daughter Irène, devoted herself to the
development of the use of X-radiography, including the mobile units which came to be known
as ‘Little Curies', used for the treatment of wounded soldiers. In 1918 the Radium Institute,
whose staff Irène had joined, began to operate in earnest, and became a centre for nuclear
physics and chemistry. Marie Curie, now at the highest point of her fame and, from 1922, a
member of the Academy of Medicine, researched the chemistry of radioactive substances and
their medical applications.

In 1921, accompanied by her two daughters, Marie Curie made a triumphant journey to the
United States to raise funds for research on radium. Women there presented her with a gram of
radium for her campaign. Marie also gave lectures in Belgium, Brazil, Spain and Czechoslovakia
and, in addition, had the satisfaction of seeing the development of the Curie Foundation in
Paris, and the inauguration in 1932 in Warsaw of the Radium Institute, where her sister Bronia
became director.

One of Marie Curie’s outstanding achievements was to have understood the need to accumulate intense radioactive sources, not only to treat illness but also to maintain an abundant supply for research. The existence in Paris at the Radium Institute of a stock of 1.5 grams of radium made a decisive contribution to the success of the experiments undertaken in the years around 1930. This work prepared the way for the discovery of the neutron by Sir James Chadwick and, above all, for the discovery in 1934 by Irène and Frédéric Joliot-Curie of artificial radioactivity. A few months after this discovery, Marie Curie died as a result
of leukaemia caused by exposure to radiation. She had often carried test tubes containing
radioactive isotopes in her pocket, remarking on the pretty blue-green light they gave off.

Her contribution to physics had been immense, not only in her own work, the importance
of which had been demonstrated by her two Nobel Prizes, but because of her influence on
subsequent generations of nuclear physicists and chemists.

88
```

[Original question page](assets/2c502f0970d40a825c8db650d89b6c1b6121ccef6b5413d6894cb7c729c50010.jpg)

<!-- Source: /api/assets/dbf132cf978e788ccb051794c1cc8c5dffdf8c5a0eca7e3c1cc1a27aeb7ff5ab.jpg; PDF page 81; full -->

```text
Questions 1–6
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1–6 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 Marie Curie’s husband was a joint winner of both Marie’s Nobel Prizes.
2 Marie became interested in science when she was a child.
3 Marie was able to attend the Sorbonne because of her sister’s financial contribution.
4 Marie stopped doing research for several years when her children were born.
5 Marie took over the teaching position her husband had held.
6 Marie’s sister Bronia studied the medical uses of radioactivity.
```

[Original question page](assets/dbf132cf978e788ccb051794c1cc8c5dffdf8c5a0eca7e3c1cc1a27aeb7ff5ab.jpg)

<!-- Source: /api/assets/1a36264113b811773cfd9143d9bd5cb79728af4919c8adbeae18d46eaad14e3c.jpg; PDF page 82; full -->

```text
Questions 7–13
Complete the notes below. Choose ONE WORD from the passage for each answer.
Write your answers in boxes 7–13 on your answer sheet.
Marie Curie’s research on radioactivity
– When uranium was discovered to be radioactive, Marie Curie found that the element called (7) __________ had the same property.
– Marie and Pierre Curie’s research into the radioactivity of the mineral known as (8) __________ led to the discovery of two new elements.
– In 1911, Marie Curie received recognition for her work on the element (9) __________.
– Marie and Irène Curie developed X-radiography which was used as a medical technique for (10) __________.
– Marie Curie saw the importance of collecting radioactive material both for research and for cases of (11) __________.
– The radioactive material stocked in Paris contributed to the discoveries in the 1930s of the (12) __________ and of what was known as artificial radioactivity.
– During her research, Marie Curie was exposed to radiation and as a result she suffered from (13) __________.
```

[Original question page](assets/1a36264113b811773cfd9143d9bd5cb79728af4919c8adbeae18d46eaad14e3c.jpg)

<!-- Source: /api/assets/6802611f7a9ac614f11ea51a68556b388f6c71cefcc3c49fda3d2318a0e9fde3.jpg; PDF page 83; full -->

```text
Reading

READING PASSAGE 2

You should spend about 20 minutes on Questions 14-26 which are based on Reading
Passage 2 below.

Young children’s sense of identity

A A sense of self develops in young children by degrees. The process can usefully be
thought of in terms of the gradual emergence of two somewhat separate features:
the self as a subject, and the self as an object. William James introduced the distinction
in 1892, and contemporaries of his, such as Charles Cooley, added to the developing
debate. Ever since then psychologists have continued building on the theory.

B According to James, a child’s first step on the road to self-understanding can
be seen as the recognition that he or she exists. This is an aspect of the self that
he labelled ‘self-as-subject’, and he gave it various elements. These included an
awareness of one’s own agency (i.e. one’s power to act), and an awareness of one’s
distinctiveness from other people. These features gradually emerge as infants
explore their world and interact with caregivers. Cooley (1902) suggested that a
sense of the self-as-subject was primarily concerned with being able to exercise
power. He proposed that the earliest examples of this are an infant’s attempts to
control physical objects, such as toys or his or her own limbs. This is followed by
attempts to affect the behaviour of other people. For example, infants learn that
when they cry or smile someone responds to them.

C Another powerful source of information for infants about the effects they can
have on the world around them is provided when others mimic them. Many
parents spend a lot of time, particularly in the early months, copying their infant’s
vocalizations and expressions. In addition, young children enjoy looking in mirrors,
where the movements they can see are dependent upon their own movements.
This is not to say that infants recognize the reflection as their own image (a later
development). However, Lewis and Brooks-Gunn (1979) suggest that infants’
developing understanding that the movements they see in the mirror are contingent
on their own, leads to a growing awareness that they are distinct from other people.
This is because they, and only they, can change the reflection in the mirror.

D This understanding that children gain of themselves as active agents continues
to develop in their attempts to co-operate with others in play. Dunn (1988) points
out that it is in such day-to-day relationships and interactions that the child’s
understanding of his- or herself emerges. Empirical investigations of the self-as-
subject in young children are, however, rather scarce because of difficulties of
communication: even if young infants can reflect on their experience, they certainly
cannot express this aspect of the self directly.

91
```

[Original question page](assets/6802611f7a9ac614f11ea51a68556b388f6c71cefcc3c49fda3d2318a0e9fde3.jpg)

<!-- Source: /api/assets/0fcbc18411103028b5be158774c21a4647acdec27eea580e4f5b252111fe3189.jpg; PDF page 84; full -->

```text
Test 4

92

E Once children have acquired a certain level of self-awareness, they begin to

place themselves in a whole series of categories, which together play such an
important part in defining them uniquely as ‘themselves’. This second step in the
development of a full sense of self is what James called the ‘self-as-object’. This has
been seen by many to be the aspect of the self which is most influenced by social
elements, since it is made up of social roles (such as student, brother, colleague) and
characteristics which derive their meaning from comparison or interaction with
other people (such as trustworthiness, shyness, sporting ability).

F Cooley and other researchers suggested a close connection between a person’s own
understanding of their identity and other people’s understanding of it. Cooley
believed that people build up their sense of identity from the reactions of others

to them, and from the view they believe others have of them. He called the self-
as-object the ‘looking-glass self’, since people come to see themselves as they are
reflected in others. Mead (1934) went even further, and saw the self and the social
world as inextricably bound together: ‘The self is essentially a social structure, and
it arises in social experience ... it is impossible to conceive of a self arising outside
of social experience.’

G Lewis and Brooks-Gunn argued that an important developmental milestone is
reached when children become able to recognize themselves visually without the
support of seeing contingent movement. This recognition occurs around their
second birthday. In one experiment, Lewis and Brooks-Gunn (1979) dabbed some
red powder on the noses of children who were playing in front of a mirror, and then
observed how often they touched their noses. The psychologists reasoned that if

the children knew what they usually looked like, they would be surprised by the
unusual red mark and would start touching it. On the other hand, they found that
children of 15 to 18 months are generally not able to recognize themselves unless
other cues such as movement are present.

H Finally, perhaps the most graphic expressions of self-awareness in general can

be seen in the displays of rage which are most common from 18 months to 3

years of age. In a longitudinal study of groups of three or four children, Bronson
(1975) found that the intensity of the frustration and anger in their disagreements
increased sharply between the ages of 1 and 2 years. Often, the children’s
disagreements involved a struggle over a toy that none of them had played with
before or after the tug-of-war: the children seemed to be disputing ownership rather
than wanting to play with it. Although it may be less marked in other societies, the
link between the sense of ‘self’ and of ‘ownership’ is a notable feature of childhood
in Western societies.
```

[Original question page](assets/0fcbc18411103028b5be158774c21a4647acdec27eea580e4f5b252111fe3189.jpg)

<!-- Source: /api/assets/411f0c4ab17090c5756131643365026d137f04679d8c268978eacb50b5be0562.jpg; PDF page 85; full -->

```text
Questions 14–19
Reading Passage 2 has eight paragraphs, A–H.
Which paragraph contains the following information?
Write the correct letter, A–H, in boxes 14–19 on your answer sheet.
NB You may use any letter more than once.
14 an account of the method used by researchers in a particular study
15 the role of imitation in developing a sense of identity
16 the age at which children can usually identify a static image of themselves
17 a reason for the limitations of scientific research into ‘self-as-subject’
18 reference to a possible link between culture and a particular form of behaviour
19 examples of the wide range of features that contribute to the sense of ‘self-as-object’
```

[Original question page](assets/411f0c4ab17090c5756131643365026d137f04679d8c268978eacb50b5be0562.jpg)

<!-- Source: /api/assets/99eb76e828d9a6136f53b8aad019ef19b953146c21959c08ea96c10d76283054.jpg; PDF page 86; full -->

```text
Questions 20–23
Look at the following findings (Questions 20–23) and the list of researchers below.
Match each finding with the correct researcher or researchers, A–E.
Write the correct letter, A–E, in boxes 20–23 on your answer sheet.
20 A sense of identity can never be formed without relationships with other people.
21 A child’s awareness of self is related to a sense of mastery over things and people.
22 At a certain age, children’s sense of identity leads to aggressive behaviour.
23 Observing their own reflection contributes to children’s self awareness.
List of Researchers
A James
B Cooley
C Lewis and Brooks-Gunn
D Mead
E Bronson
```

[Original question page](assets/99eb76e828d9a6136f53b8aad019ef19b953146c21959c08ea96c10d76283054.jpg)

<!-- Source: /api/assets/f8e1a055842b48044706304989ab3567c8278635799e55a22843bdd4d3f059f6.jpg; PDF page 87; full -->

```text
Questions 24–26
Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 24–26 on your answer sheet.
How children acquire a sense of identity
First, children come to realise that they can have an effect on the world around them, for example by handling objects, or causing the image to move when they face a (24) __________. This aspect of self-awareness is difficult to research directly, because of (25) __________ problems.
Secondly, children start to become aware of how they are viewed by others. One important stage in this process is the visual recognition of themselves which usually occurs when they reach the age of two. In Western societies at least, the development of self awareness is often linked to a sense of (26) __________, and can lead to disputes.
```

[Original question page](assets/f8e1a055842b48044706304989ab3567c8278635799e55a22843bdd4d3f059f6.jpg)

<!-- Source: /api/assets/427bafe93f8b3c08a6137136fc55aa7bbd342875286079bba979ddaa042a9517.jpg; PDF page 88; full -->

```text
Test 4

READING PASSAGE 3

You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 on the following pages.

Questions 27-30
Reading Passage 3 has six paragraphs, A-F.
Choose the correct heading for paragraphs B-E from the list of headings below.

Write the correct number, i-vii, in boxes 27-30 on your answer sheet.

List of Headings
i Commercial pressures on people in charge
ii Mixed views on current changes to museums
iii Interpreting the facts to meet visitor expectations
iv The international dimension
v Collections of factual evidence
vi Fewer differences between public attractions

vii Current reviews and suggestions

Example Answer
Paragraph A v

27 Paragraph B
28 Paragraph C
29 Paragraph D
30 Paragraph E

96
```

[Original question page](assets/427bafe93f8b3c08a6137136fc55aa7bbd342875286079bba979ddaa042a9517.jpg)

<!-- Source: /api/assets/1415dccc8a5e58451fe4ca0a38084b19c645daa9baf617d2ccb6fac83bcc565f.jpg; PDF page 89; full -->

```text
Reading

The Development of
Museums

A The conviction that historical relics provide infallible testimony about the past is
rooted in the nineteenth and early twentieth centuries, when science was regarded
as objective and value free. As one writer observes: ‘Although it is now evident that
artefacts are as easily altered as chronicles, public faith in their veracity endures: a
tangible relic seems ipso facto real.’ Such conviction was, until recently, reflected in
museum displays. Museums used to look - and some still do - much like storage
rooms of objects packed together in showcases: good for scholars who wanted to
study the subtle differences in design, but not for the ordinary visitor, to whom it all
looked alike. Similarly, the information accompanying the objects often made little
sense to the lay visitor. The content and format of explanations dated back to a time
when the museum was the exclusive domain of the scientific researcher.

B Recently, however, attitudes towards history and the way it should be presented
have altered. The key word in heritage display is now ‘experience’, the more exciting
the better and, if possible, involving all the senses. Good examples of this approach
in the UK are the Jorvik Centre in York; the National Museum of Photography, Film
and Television in Bradford; and the Imperial War Museum in London. In the US
the trend emerged much earlier: Williamsburg has been a prototype for many
heritage developments in other parts of the world. No one can predict where the
process will end. On so-called heritage sites the re-enactment of historical events
is increasingly popular, and computers will soon provide virtual reality experiences,
which will present visitors with a vivid image of the period of their choice, in which
they themselves can act as if part of the historical environment. Such developments
have been criticised as an intolerable vulgarisation, but the success of many historical
theme parks and similar locations suggests that the majority of the public does not
share this opinion.

C In a related development, the sharp distinction between museum and heritage sites
on the one hand, and theme parks on the other, is gradually evaporating. They already
borrow ideas and concepts from one another. For example, museums have adopted
story lines for exhibitions, sites have accepted ‘theming’ as a relevant tool, and theme
parks are moving towards more authenticity and research-based presentations. In
zoos, animals are no longer kept in cages, but in great spaces, either in the open air or
in enormous greenhouses, such as the jungle and desert environments in Burgers’ Zoo
in Holland. This particular trend is regarded as one of the major developments in the
presentation of natural history in the twentieth century.

97
```

[Original question page](assets/1415dccc8a5e58451fe4ca0a38084b19c645daa9baf617d2ccb6fac83bcc565f.jpg)

<!-- Source: /api/assets/00c0b2227f655e3d9227bf267bf5e73b3181f53be4371aeca21f06f22d7fe76c.jpg; PDF page 90; full -->

```text
Test 4

D


Theme parks are undergoing other changes, too, as they try to present more serious
social and cultural issues, and move away from fantasy. This development is a
response to market forces and, although museums and heritage sites have a special,
rather distinct, role to fulfil, they are also operating in a very competitive environment,
where visitors make choices on how and where to spend their free time. Heritage and
museum experts do not have to invent stories and recreate historical environments

to attract their visitors: their assets are already in place. However, exhibits must be
both based on artefacts and facts as we know them, and attractively presented. Those
who are professionally engaged in the art of interpreting history are thus in a difficult
position, as they must steer a narrow course between the demands of ‘evidence’

and ‘attractiveness’, especially given the increasing need in the heritage industry for
income-generating activities.

E It could be claimed that in order to make everything in heritage more ‘real’, historical
accuracy must be increasingly altered. For example, Pithecanthropus erectus

is depicted in an Indonesian museum with Malay facial features, because this
corresponds to public perceptions. Similarly, in the Museum of Natural History in
Washington, Neanderthal man is shown making a dominant gesture to his wife. Such
presentations tell us more about contemporary perceptions of the world than about
our ancestors. There is one compensation, however, for the professionals who make
these interpretations: if they did not provide the interpretation, visitors would do it
for themselves, based on their own ideas, misconceptions and prejudices. And no
matter how exciting the result, it would contain a lot more bias than the presentations
provided by experts.

F Human bias is inevitable, but another source of bias in the representation of history
has to do with the transitory nature of the materials themselves. The simple fact is
that not everything from history survives the historical process. Castles, palaces and
cathedrals have a longer lifespan than the dwellings of ordinary people. The same
applies to the furnishings and other contents of the premises. In a town like Leyden in
Holland, which in the seventeenth century was occupied by approximately the same
number of inhabitants as today, people lived within the walled town, an area more
than five times smaller than modern Leyden. In most of the houses several families
lived together in circumstances beyond our imagination. Yet in museums, fine period
rooms give only an image of the lifestyle of the upper class of that era. No wonder
that people who stroll around exhibitions are filled with nostalgia; the evidence in
museums indicates that life was so much better in the past. This notion is induced by
the bias in its representation in museums and heritage centres.
```

[Original question page](assets/00c0b2227f655e3d9227bf267bf5e73b3181f53be4371aeca21f06f22d7fe76c.jpg)

<!-- Source: /api/assets/3e0579dc0812bb9be01b20d194e6447a3aaa63b54ad095f88496d2f5fa4def87.jpg; PDF page 91; full -->

```text
Questions 31–36
Choose the correct letter, A, B, C or D. Write the correct letter in boxes 31–36 on your answer sheet.
31 Compared with today’s museums, those of the past
A did not present history in a detailed way.
B were not primarily intended for the public.
C were more clearly organised.
D preserved items with greater care.
32 According to the writer, current trends in the heritage industry
A emphasise personal involvement.
B have their origins in York and London.
C rely on computer images.
D reflect minority tastes.
33 The writer says that museums, heritage sites and theme parks
A often work in close partnership.
B try to preserve separate identities.
C have similar exhibits.
D are less easy to distinguish than before.
34 The writer says that in preparing exhibits for museums, experts
A should pursue a single objective.
B have to do a certain amount of language translation.
C should be free from commercial constraints.
D have to balance conflicting priorities.
35 In paragraph E, the writer suggests that some museum exhibits
A fail to match visitor expectations.
B are based on the false assumptions of professionals.
C reveal more about present beliefs than about the past.
D allow visitors to make more use of their imagination.
36 The passage ends by noting that our view of history is biased because
A we fail to use our imagination.
B only very durable objects remain from the past.
C we tend to ignore things that displease us.
D museum exhibits focus too much on the local area.
```

[Original question page](assets/3e0579dc0812bb9be01b20d194e6447a3aaa63b54ad095f88496d2f5fa4def87.jpg)

<!-- Source: /api/assets/754287e963b2d4594b597dc791339d3e39952d1c362a29c23ddb1e049dc34d03.jpg; PDF page 92; full -->

```text
Test 4

Questions 37-40
Do the following statements agree with the information given in Reading Passage 3?
In boxes 37-40 on your answer sheet, write

TRUE if the statement agrees with the information

FALSE if the statement contradicts the information

NOT GIVEN if there is no information on this

37 Consumers prefer theme parks which avoid serious issues.
38 More people visit museums than theme parks.
39 The boundaries of Leyden have changed little since the seventeenth century.

40 Museums can give a false impression of how life used to be.

100
```

[Original question page](assets/754287e963b2d4594b597dc791339d3e39952d1c362a29c23ddb1e049dc34d03.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/748fa1cf26dbf4e9647e4f0c4c25025e825e702ab77a7a2be9fa68d286265ca1.jpg; PDF page 93; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below gives information from a 2008 report about consumption of energy in the USA since 1980 with projections until 2030.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/748fa1cf26dbf4e9647e4f0c4c25025e825e702ab77a7a2be9fa68d286265ca1.jpg)

![Original figure](assets/748fa1cf26dbf4e9647e4f0c4c25025e825e702ab77a7a2be9fa68d286265ca1.jpg)

### Task 2

<!-- Source: /api/assets/6bb2e0a5afc6ce180a48416d65fda2a6f1f6d0d50b80c46d9c622ca8a4a3073d.jpg; PDF page 94; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Every year several languages die out. Some people think that this is not important because life will be easier if there are fewer languages in the world.

To what extent do you agree or disagree with this opinion?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/6bb2e0a5afc6ce180a48416d65fda2a6f1f6d0d50b80c46d9c622ca8a4a3073d.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/eb848110faa1c4e95b6f44a5d2241560b4c103c78c567f8a38ab56215dd5e4d2.jpg; PDF page 95; full -->

```text
Speaking

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Bicycles

* How popular are bicycles in your home town? [Why?]

* How often do you ride a bicycle? [Why/Why not?]

* Do you think that bicycles are suitable for all ages? [Why/Why not?]
* What are the advantages of a bicycle compared to a car? [Why?]

PART 2
Describe a person who has done a lot of work to help people.
You should say:
who this person is/was
where this person lives/lived
what he/she has done to help people
and explain how you know about this person.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Helping other people in the community

Example questions:

What are some of the ways people can help others in the community? Which is most
important?

Why do you think some people like to help other people?

Some people say that people help others in the community more now than they did in
the past. Do you agree or disagree? Why?

Community Services

Example questions:

What types of services, such as libraries or health centres, are available to the people
who live in your area? Do you think there are enough of them?

Which groups of people generally need most support in a community? Why?

Who do you think should pay for the services that are available to the people in a
community? Should it be the government or individual people?

103
```

[Original question page](assets/eb848110faa1c4e95b6f44a5d2241560b4c103c78c567f8a38ab56215dd5e4d2.jpg)

### Part 2

<!-- Source: /api/assets/eb848110faa1c4e95b6f44a5d2241560b4c103c78c567f8a38ab56215dd5e4d2.jpg; PDF page 95; full -->

```text
Speaking

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Bicycles

* How popular are bicycles in your home town? [Why?]

* How often do you ride a bicycle? [Why/Why not?]

* Do you think that bicycles are suitable for all ages? [Why/Why not?]
* What are the advantages of a bicycle compared to a car? [Why?]

PART 2
Describe a person who has done a lot of work to help people.
You should say:
who this person is/was
where this person lives/lived
what he/she has done to help people
and explain how you know about this person.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Helping other people in the community

Example questions:

What are some of the ways people can help others in the community? Which is most
important?

Why do you think some people like to help other people?

Some people say that people help others in the community more now than they did in
the past. Do you agree or disagree? Why?

Community Services

Example questions:

What types of services, such as libraries or health centres, are available to the people
who live in your area? Do you think there are enough of them?

Which groups of people generally need most support in a community? Why?

Who do you think should pay for the services that are available to the people in a
community? Should it be the government or individual people?

103
```

[Original question page](assets/eb848110faa1c4e95b6f44a5d2241560b4c103c78c567f8a38ab56215dd5e4d2.jpg)

### Part 3

<!-- Source: /api/assets/eb848110faa1c4e95b6f44a5d2241560b4c103c78c567f8a38ab56215dd5e4d2.jpg; PDF page 95; full -->

```text
Speaking

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Bicycles

* How popular are bicycles in your home town? [Why?]

* How often do you ride a bicycle? [Why/Why not?]

* Do you think that bicycles are suitable for all ages? [Why/Why not?]
* What are the advantages of a bicycle compared to a car? [Why?]

PART 2
Describe a person who has done a lot of work to help people.
You should say:
who this person is/was
where this person lives/lived
what he/she has done to help people
and explain how you know about this person.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Helping other people in the community

Example questions:

What are some of the ways people can help others in the community? Which is most
important?

Why do you think some people like to help other people?

Some people say that people help others in the community more now than they did in
the past. Do you agree or disagree? Why?

Community Services

Example questions:

What types of services, such as libraries or health centres, are available to the people
who live in your area? Do you think there are enough of them?

Which groups of people generally need most support in a community? Why?

Who do you think should pay for the services that are available to the people in a
community? Should it be the government or individual people?

103
```

[Original question page](assets/eb848110faa1c4e95b6f44a5d2241560b4c103c78c567f8a38ab56215dd5e4d2.jpg)
