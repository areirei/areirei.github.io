# 剑雅 9 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 150

TEST 4 LISTENING
1 babies
2 Eshcol
3 evening
4 Gormley
5 B
6 E
7 heart
8 primary school
9 4.30
10 ages
11 B
12 C
13 E
14 B
15 E
16 D
17 A
18 C
19 732281
20 Thursday / Thursdays
21 A
22 C
23 approach
24 mature
25 interest
26 groups
27 every 2 days
28 2 weeks
29 confident
30 education system
31 C
32 A
33 B
34 B
35 A
36 C
37 frog / frogs
38 predators
39 count
40 seed / seeds
5–6 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. babies

2. Eshcol

3. evening

4. Gormley

5. B / E

6. B / E

7. heart

8. primary school

9. 4.30 / 4:30

10. ages

### Part 2 · source page 150

TEST 4 LISTENING
1 babies
2 Eshcol
3 evening
4 Gormley
5 B
6 E
7 heart
8 primary school
9 4.30
10 ages
11 B
12 C
13 E
14 B
15 E
16 D
17 A
18 C
19 732281
20 Thursday / Thursdays
21 A
22 C
23 approach
24 mature
25 interest
26 groups
27 every 2 days
28 2 weeks
29 confident
30 education system
31 C
32 A
33 B
34 B
35 A
36 C
37 frog / frogs
38 predators
39 count
40 seed / seeds
5–6 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. B

12. C

13. E

14. B

15. E

16. D

17. A

18. C

19. 732281

20. Thursday / Thursdays

### Part 3 · source page 150

TEST 4 LISTENING
1 babies
2 Eshcol
3 evening
4 Gormley
5 B
6 E
7 heart
8 primary school
9 4.30
10 ages
11 B
12 C
13 E
14 B
15 E
16 D
17 A
18 C
19 732281
20 Thursday / Thursdays
21 A
22 C
23 approach
24 mature
25 interest
26 groups
27 every 2 days
28 2 weeks
29 confident
30 education system
31 C
32 A
33 B
34 B
35 A
36 C
37 frog / frogs
38 predators
39 count
40 seed / seeds
5–6 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. A

22. C

23. approach

24. mature

25. interest

26. groups

27. every 2 days

28. 2 weeks

29. confident

30. education system

### Part 4 · source page 150

TEST 4 LISTENING
1 babies
2 Eshcol
3 evening
4 Gormley
5 B
6 E
7 heart
8 primary school
9 4.30
10 ages
11 B
12 C
13 E
14 B
15 E
16 D
17 A
18 C
19 732281
20 Thursday / Thursdays
21 A
22 C
23 approach
24 mature
25 interest
26 groups
27 every 2 days
28 2 weeks
29 confident
30 education system
31 C
32 A
33 B
34 B
35 A
36 C
37 frog / frogs
38 predators
39 count
40 seed / seeds
5–6 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. C

32. A

33. B

34. B

35. A

36. C

37. frog / frogs

38. predators

39. count

40. seed / seeds

## A 类阅读

### Academic Reading · source page 151

ACADEMIC READING
1 FALSE
2 NOT GIVEN
3 TRUE
4 FALSE
5 TRUE
6 NOT GIVEN
7 thorium
8 pitchblende
9 radium
10 soldiers
11 illness
12 neutron
13 leukaemia / leukemia
14 G
15 C
16 G
17 D
18 H
19 E
20 D
21 B
22 E
23 C
24 mirror
25 communication
26 ownership
27 ii
28 vi
29 i
30 iii
31 B
32 A
33 D
34 D
35 C
36 B
37 FALSE
38 NOT GIVEN
39 FALSE
40 TRUE
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. FALSE

2. NOT GIVEN

3. TRUE

4. FALSE

5. TRUE

6. NOT GIVEN

7. thorium

8. pitchblende

9. radium

10. soldiers

11. illness

12. neutron

13. leukaemia / leukemia

14. G

15. C

16. G

17. D

18. H

19. E

20. D

21. B

22. E

23. C

24. mirror

25. communication

26. ownership

27. ii

28. vi

29. i

30. iii

31. B

32. A

33. D

34. D

35. C

36. B

37. FALSE

38. NOT GIVEN

39. FALSE

40. TRUE

## A 类写作

### Writing material: c9-t4-w-1

U.S. energy consumption by fuel1980–2030; unit QUADRILLION UNITS. History/projections distinguished on axis; source is a2008report. Approximate endpoints1980→2030: petrol/oil35→49; coal16→30–32; natural gas20→25; nuclear4→8; solar/wind3→6; hydropower4→3. Petrol/oil dominates throughout, initially falls then rises with fluctuations. Coal rises and overtakes natural gas around2015, then continues higher. Natural gas fluctuates early, projected to plateau near25 after2015. Nuclear and solar/wind increase modestly; hydropower fluctuates then stays low. All unlabelled curve readings approximate; do not present2030as historical data or attach financial units.



### Writing material: c9-t4-w-2

Evaluate the opinion that language loss is unimportant because fewer languages would ease life. Address the value or consequences of losing languages and the stated convenience argument; no required stance.



## 口语
