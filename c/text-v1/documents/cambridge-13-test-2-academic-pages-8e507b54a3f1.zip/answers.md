# 剑雅 13 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 121

TEST 2 LISTENING
1 races
2 insurance
3 Jerriz
4 25 / twenty-five
5 stadium
6 park
7 coffee
8 leader
9 route
10 lights
11 C
12 B
13 C
14 B
15 B
16 A
17 C
18 E
19 B
20 D
21 B
22 A
23 C
24 C
25 A
26 A
27 C
28 D
29 G
30 B
31 location
32 world
33 personal
34 attention
35 name
36 network
37 frequency
38 colour / color
39 brain
40 self
17&18 IN EITHER ORDER: C,E
19&20 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. races

2. insurance

3. Jerriz

4. 25 / twenty-five

5. stadium

6. park

7. coffee

8. leader

9. route

10. lights

### Part 2 · source page 121

TEST 2 LISTENING
1 races
2 insurance
3 Jerriz
4 25 / twenty-five
5 stadium
6 park
7 coffee
8 leader
9 route
10 lights
11 C
12 B
13 C
14 B
15 B
16 A
17 C
18 E
19 B
20 D
21 B
22 A
23 C
24 C
25 A
26 A
27 C
28 D
29 G
30 B
31 location
32 world
33 personal
34 attention
35 name
36 network
37 frequency
38 colour / color
39 brain
40 self
17&18 IN EITHER ORDER: C,E
19&20 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. C

12. B

13. C

14. B

15. B

16. A

17. C / E

18. C / E

19. B / D

20. B / D

### Part 3 · source page 121

TEST 2 LISTENING
1 races
2 insurance
3 Jerriz
4 25 / twenty-five
5 stadium
6 park
7 coffee
8 leader
9 route
10 lights
11 C
12 B
13 C
14 B
15 B
16 A
17 C
18 E
19 B
20 D
21 B
22 A
23 C
24 C
25 A
26 A
27 C
28 D
29 G
30 B
31 location
32 world
33 personal
34 attention
35 name
36 network
37 frequency
38 colour / color
39 brain
40 self
17&18 IN EITHER ORDER: C,E
19&20 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B

22. A

23. C

24. C

25. A

26. A

27. C

28. D

29. G

30. B

### Part 4 · source page 121

TEST 2 LISTENING
1 races
2 insurance
3 Jerriz
4 25 / twenty-five
5 stadium
6 park
7 coffee
8 leader
9 route
10 lights
11 C
12 B
13 C
14 B
15 B
16 A
17 C
18 E
19 B
20 D
21 B
22 A
23 C
24 C
25 A
26 A
27 C
28 D
29 G
30 B
31 location
32 world
33 personal
34 attention
35 name
36 network
37 frequency
38 colour / color
39 brain
40 self
17&18 IN EITHER ORDER: C,E
19&20 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. location

32. world

33. personal

34. attention

35. name

36. network

37. frequency

38. colour / color

39. brain

40. self

## A 类阅读

### Academic Reading · source page 122

TEST 2 READING
1 oils
2 friendship
3 funerals
4 wealth
5 indigestion
6 India
7 camels
8 Alexandria
9 Venice
10 TRUE
11 FALSE
12 NOT GIVEN
13 FALSE
14 B
15 F
16 B
17 E
18 A
19 B
20 C
21 animals
22 childbirth
23 placebo
24 game
25 strangers
26 names
27 D
28 C
29 A
30 D
31 D
32 D
33 C
34 B
35 A
36 C
37 A
38 B
39 C
40 D
If you score: 0–15 unlikely;16–23 may;24–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. oils

2. friendship

3. funerals

4. wealth

5. indigestion

6. India

7. camels

8. Alexandria

9. Venice

10. TRUE

11. FALSE

12. NOT GIVEN

13. FALSE

14. B

15. F

16. B

17. E

18. A

19. B

20. C

21. animals

22. childbirth

23. placebo

24. game

25. strangers

26. names

27. D

28. C

29. A

30. D

31. D

32. D

33. C

34. B

35. A

36. C

37. A

38. B

39. C

40. D

## A 类写作

### Writing material: c13-t2-w-1

England and Wales; owned/rented household shares, approximate unlabelled bars:1918 22/78%;1939 31/69%;1953 32/68%;1961 42/58%;1971 50/50%;1981 60/40%;1991 68/32%;2001 69/31%;2011 64/36%. Ownership generally rises until2001 then declines, renting reverses; equality1971. Two shares total100 each year. These are households, not individuals, house prices or mortgages. Dates irregularly spaced; no values for missing years supplied.



### Writing material: c13-t2-w-2

Evaluate whether contemporary choice is excessive, not merely whether choice exists. Examples may span relevant domains; no particular one required and balanced judgement acceptable.



## 口语
