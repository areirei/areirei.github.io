# 剑雅 13 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/f2169265a32331cbb48b61fea77a54ad1fb5bd901a402e30e11ddb3e645e5dd3.jpg; PDF page 33; full -->

```text
LISTENING
SECTION 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
South City Cycling Club
Example: Name of club secretary: Jim Hunter
Membership
• Full membership costs $260; this covers cycling and (1) __________ all over Australia
• Recreational membership costs $108
• Cost of membership includes the club fee and (2) __________
• The club kit is made by a company called (3) __________
Training rides
• Chance to improve cycling skills and fitness
• Level B: speed about (4) __________ kph
• Weekly sessions
– Tuesdays at 5.30 am, meet at the (5) __________
– Thursdays at 5.30 am, meet at the entrance to the (6) __________
Further information
• Rides are about an hour and a half
• Members often have (7) __________ together afterwards
• There is not always a (8) __________ with the group on these rides
• Check and print the (9) __________ on the website beforehand
• Bikes must have (10) __________
```

[Original question page](assets/f2169265a32331cbb48b61fea77a54ad1fb5bd901a402e30e11ddb3e645e5dd3.jpg)

### Part 2

<!-- Source: /api/assets/8a2b2ab472ce4e0b601744285173898305e29fd38a5db5c265431cef8b63cecd.jpg; PDF page 34; full -->

```text
SECTION 2 Questions 11–20
Listening
Questions 11-16
Choose the correct letter, A, B or C.
Information on company volunteering projects
11 How much time for volunteering does the company allow per employee?
A two hours per week
B one day per month
C 8 hours per year
12 In feedback almost all employees said that volunteering improved their
A chances of promotion.
B job satisfaction.
C relationships with colleagues.
13 Last year some staff helped unemployed people with their
A literacy skills.
B job applications.
C communication skills.
14 This year the company will start a new volunteering project with a local
A school.
B park.
C charity.
15 Where will the Digital Inclusion Day be held?
A at the company's training facility
B at a college
C in a community centre
16 What should staff do if they want to take part in the Digital Inclusion Day?

A fill in a form
B attend a training workshop
C get permission from their manager
```

[Original question page](assets/8a2b2ab472ce4e0b601744285173898305e29fd38a5db5c265431cef8b63cecd.jpg)

<!-- Source: /api/assets/c53c5f73c9fd55dd8c2969aee983a4094fa6a0dcd14ea096455ac2c8dbba2b1b.jpg; PDF page 35; full -->

```text
Questions 17 and 18
Choose TWO letters, A–E.
What TWO things are mentioned about the participants on the last Digital Inclusion Day?
A They were all over 70.
B They never used their computer.
C Their phones were mostly old-fashioned.
D They only used their phones for making calls.
E They initially showed little interest.
Questions 19 and 20
Choose TWO letters, A–E.
What TWO activities on the last Digital Inclusion Day did participants describe as useful?
A learning to use tablets
B communicating with family
C shopping online
D playing online games
E sending emails
```

[Original question page](assets/c53c5f73c9fd55dd8c2969aee983a4094fa6a0dcd14ea096455ac2c8dbba2b1b.jpg)

### Part 3

<!-- Source: /api/assets/c5c13857ddb60072e5106095cb6a8e2017234f119eb6d68f3926fb368b604314.jpg; PDF page 36; full -->

```text
SECTION 3 Questions 21–30
Listening
Questions 21 - 25
Choose the correct letter, A, B or C.
Planning a presentation on nanotechnology
21 Russ says that his difficulty in planning the presentation is due to
A his lack of knowledge about the topic.
B his uncertainty about what he should try to achieve.
C the short time that he has for preparation.
22 Russ and his tutor agree that his approach in the presentation will be
A to concentrate on how nanotechnology is used in one field.
B to follow the chronological development of nanotechnology.
C to show the range of applications of nanotechnology.
23 In connection with slides, the tutor advises Russ to
A talk about things that he can find slides to illustrate.
B look for slides to illustrate the points he makes.
C consider omitting slides altogether.
24 They both agree that the best way for Russ to start his presentation is
A to encourage the audience to talk.
B to explain what Russ intends to do.
C to provide an example.
25 What does the tutor advise Russ to do next while preparing his presentation?
A summarise the main point he wants to make
B read the notes he has already made
C list the topics he wants to cover

35
```

[Original question page](assets/c5c13857ddb60072e5106095cb6a8e2017234f119eb6d68f3926fb368b604314.jpg)

<!-- Source: /api/assets/29e3abe0f37bb120788552c6ff6b86128e52a0e4807a992f8fcadcc1d698d2c1.jpg; PDF page 37; full -->

```text
Questions 26–30
Test 2
What comments do the speakers make about each of the following aspects of Russ's
previous presentation?
Choose FIVE answers from the box and write the correct letter, A-G, next to
.
Comments
A lacked a conclusion
B useful in the future
C not enough
D sometimes distracting
E showed originality
F covered a wide range
G not too technical
Questions 26-30
Aspects of Russ's previous presentation
26 structure ..........
27 eye contact ..........
28 body language ..........
29 choice of words ..........
30 handouts ..........
36
```

[Original question page](assets/29e3abe0f37bb120788552c6ff6b86128e52a0e4807a992f8fcadcc1d698d2c1.jpg)

### Part 4

<!-- Source: /api/assets/10e59b1f97ded5a1414c3eaa26effebf65077c46e131022e29bec692929103c9.jpg; PDF page 38; full -->

```text
SECTION 4 Questions 31–40
Listening
Complete the notes below.
Write ONE WORD ONLY for each answer.

Episodic memory
• the ability to recall details, e.g. the time and 31....................of past
events
• different to semantic memory - the ability to remember general information
about the 32...................., which does not involve recalling
33....................information
Forming episodic memories involves three steps:
Encoding
• involves receiving and processing information
• the more 34....................given to an event, the more successfully it
can be encoded
• to remember a 35...................., it is useful to have a strategy for
encoding such information
Consolidation
• how memories are strengthened and stored
• most effective when memories can be added to a 36....................
of related information
• the 37....................of retrieval affects the strength of memories
Retrieval
• memory retrieval often depends on using a prompt, e.g. the
38....................of an object near to the place where you left your car
Episodic memory impairments
• these affect people with a wide range of medical conditions
• games which stimulate the 39....................have been found to help
people with schizophrenia
• children with autism may have difficulty forming episodic memories -
possibly because their concept of the 40....................may be absent
• memory training may help autistic children develop social skills
37
```

[Original question page](assets/10e59b1f97ded5a1414c3eaa26effebf65077c46e131022e29bec692929103c9.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/b1b0e05c030a4b5e8e0f93142ca8d3ca2a19752f4db472c933ea364fc9077ce7.jpg; PDF page 39; full -->

```text
Test 2
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Bringing cinnamon to Europe
Cinnamon is a sweet, fragrant spice produced from the inner bark of trees of the genus
Cinnamomum, which is native to the Indian sub-continent. It was known in biblical times,
and is mentioned in several books of the Bible, both as an ingredient that was mixed
with oils for anointing people's bodies, and also as a token indicating friendship among
lovers and friends. In ancient Rome, mourners attending funerals burnt cinnamon to
create a pleasant scent. Most often, however, the spice found its primary use as an
additive to food and drink. In the Middle Ages, Europeans who could afford the spice
used it to flavour food, particularly meat, and to impress those around them with their
ability to purchase an expensive condiment from the ‘exotic’ East. At a banquet, a host
would offer guests a plate with various spices piled upon it as a sign of the wealth at his
or her disposal. Cinnamon was also reported to have health benefits, and was thought
to cure various ailments, such as indigestion.
Toward the end of the Middle Ages, the European middle classes began to desire
the lifestyle of the elite, including their consumption of spices. This led to a growth in
demand for cinnamon and other spices. At that time, cinnamon was transported by Arab
merchants, who closely guarded the secret of the source of the spice from potential
rivals. They took it from India, where it was grown, on camels via an overland route
to the Mediterranean. Their journey ended when they reached Alexandria. European
traders sailed there to purchase their supply of cinnamon, then brought it back to Venice.
The spice then travelled from that great trading city to markets all around Europe.
Because the overland trade route allowed for only small quantities of the spice to reach
Europe, and because Venice had a virtual monopoly of the trade, the Venetians could
set the price of cinnamon exorbitantly high. These prices, coupled with the increasing
demand, spurred the search for new routes to Asia by Europeans eager to take part in
the spice trade.
Seeking the high profits promised by the cinnamon market, Portuguese traders arrived
on the island of Ceylon in the Indian Ocean toward the end of the 15th century. Before
Europeans arrived on the island, the state had organized the cultivation of cinnamon.
People belonging to the ethnic group called the Salagama would peel the bark off
young shoots of the cinnamon plant in the rainy season, when the wet bark was
more pliable. During the peeling process, they curled the bark into the ‘stick’ shape
still associated with the spice today. The Salagama then gave the finished product to
the king as a form of tribute. When the Portuguese arrived, they needed to increase
38
```

[Original question page](assets/b1b0e05c030a4b5e8e0f93142ca8d3ca2a19752f4db472c933ea364fc9077ce7.jpg)

<!-- Source: /api/assets/b1f80119164d273ab941aa60594b05dd21fa0d30fb4a9329fe968103ae31bfd0.jpg; PDF page 40; full -->

```text
Reading
production significantly, and so enslaved many other members of the Ceylonese native
population, forcing them to work in cinnamon harvesting. In 1518, the Portuguese built
a fort on Ceylon, which enabled them to protect the island, so helping them to develop a
monopoly in the cinnamon trade and generate very high profits. In the late 16th century,
for example, they enjoyed a tenfold profit when shipping cinnamon over a journey of
eight days from Ceylon to India.
When the Dutch arrived off the coast of southern Asia at the very beginning of the
17th century, they set their sights on displacing the Portuguese as kings of cinnamon.
The Dutch allied themselves with Kandy, an inland kingdom on Ceylon. In return
for payments of elephants and cinnamon, they protected the native king from the
Portuguese. By 1640, the Dutch broke the 150-year Portuguese monopoly when they
overran and occupied their factories. By 1658, they had permanently expelled the
Portuguese from the island, thereby gaining control of the lucrative cinnamon trade.
In order to protect their hold on the market, the Dutch, like the Portuguese before them,
treated the native inhabitants harshly. Because of the need to boost production and
satisfy Europe's ever-increasing appetite for cinnamon, the Dutch began to alter the
harvesting practices of the Ceylonese. Over time, the supply of cinnamon trees on the
island became nearly exhausted, due to systematic stripping of the bark. Eventually, the
Dutch began cultivating their own cinnamon trees to supplement the diminishing number
of wild trees available for use.
Then, in 1796, the English arrived on Ceylon, thereby displacing the Dutch from their
control of the cinnamon monopoly. By the middle of the 19th century, production of
cinnamon reached 1,000 tons a year, after a lower grade quality of the spice became
acceptable to European tastes. By that time, cinnamon was being grown in other parts
of the Indian Ocean region and in the West Indies, Brazil, and Guyana. Not only was a
monopoly of cinnamon becoming impossible, but the spice trade overall was diminishing
in economic potential, and was eventually superseded by the rise of trade in coffee, tea,
chocolate, and sugar.
39
```

[Original question page](assets/b1f80119164d273ab941aa60594b05dd21fa0d30fb4a9329fe968103ae31bfd0.jpg)

<!-- Source: /api/assets/20908034c96a3b7a6fc98ed08bd9bcbff2639b9d014ffca712f90b132a74ba08.jpg; PDF page 41; full -->

```text
Test 2
Questions 1-9
Complete the notes below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1-9 on your answer sheet.
The Early History of Cinnamon
Biblical times:
added to 1....................
used to show 2....................between people
Ancient Rome:
used for its sweet smell at 3....................
Middle Ages:
added to food, especially meat
was an indication of a person's 4....................
known as a treatment for 5....................and other
health problems
grown in 6....................
merchants used 7....................to bring it to
the Mediterranean
arrived in the Mediterranean at 8....................
traders took it to 9....................and sold it to
destinations around Europe
40
```

[Original question page](assets/20908034c96a3b7a6fc98ed08bd9bcbff2639b9d014ffca712f90b132a74ba08.jpg)

<!-- Source: /api/assets/31c4e0f83b9f69fb9f857a1ca0a8a9f9338f8883a16678b7553edea19d2b1271.jpg; PDF page 42; full -->

```text
Questions 10–13
Reading
Do the following statements agree with the information given in Reading Passage 1?
In boxes 10-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
10 The Portuguese had control over the cinnamon trade in Ceylon throughout the 16th
century.
11 The Dutch took over the cinnamon trade from the Portuguese as soon as they
arrived in Ceylon.
12 The trees planted by the Dutch produced larger quantities of cinnamon than the
wild trees.
13 The spice trade maintained its economic importance during the 19th century.

41
```

[Original question page](assets/31c4e0f83b9f69fb9f857a1ca0a8a9f9338f8883a16678b7553edea19d2b1271.jpg)

<!-- Source: /api/assets/c2a7d9918a5cc5845e537af3ed0e209dbcde5bd200ba127d4e00498f5af0ebcf.jpg; PDF page 43; full -->

```text
Test 2
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Oxytocin
The positive and negative effects of the chemical known as the ‘love hormone’
A Oxytocin is a chemical, a hormone produced in the pituitary gland in the brain. It
was through various studies focusing on animals that scientists first became aware
of the influence of oxytocin. They discovered that it helps reinforce the bonds
between prairie voles, which mate for life, and triggers the motherly behaviour
that sheep show towards their newborn lambs. It is also released by women in
childbirth, strengthening the attachment between mother and baby. Few chemicals
have as positive a reputation as oxytocin, which is sometimes referred to as the
‘love hormone’. One sniff of it can, it is claimed, make a person more trusting,
empathetic, generous and cooperative. It is time, however, to revise this wholly
optimistic view. A new wave of studies has shown that its effects vary greatly
depending on the person and the circumstances, and it can impact on our social
interactions for worse as well as for better.
B Oxytocin’s role in human behaviour first emerged in 2005. In a groundbreaking
experiment, Markus Heinrichs and his colleagues at the University of Freiburg,
Germany, asked volunteers to do an activity in which they could invest money with
an anonymous person who was not guaranteed to be honest. The team found
that participants who had sniffed oxytocin via a nasal spray beforehand invested
more money than those who received a placebo instead. The study was the start
of research into the effects of oxytocin on human interactions. ‘For eight years, it
was quite a lonesome field,’ Heinrichs recalls. 'Now, everyone is interested.’ These
follow-up studies have shown that after a sniff of the hormone, people become
more charitable, better at reading emotions on others’ faces and at communicating
constructively in arguments. Together, the results fuelled the view that oxytocin
universally enhanced the positive aspects of our social nature.
C Then, after a few years, contrasting findings began to emerge. Simone Shamay-
Tsoory at the University of Haifa, Israel, found that when volunteers played a
competitive game, those who inhaled the hormone showed more pleasure when
they beat other players, and felt more envy when others won. What’s more,
administering oxytocin also has sharply contrasting outcomes depending on a
person’s disposition. Jennifer Bartz from Mount Sinai School of Medicine, New
York, found that it improves people’s ability to read emotions, but only if they are
not very socially adept to begin with. Her research also shows that oxytocin in fact
reduces cooperation in subjects who are particularly anxious or sensitive
to rejection.
42
```

[Original question page](assets/c2a7d9918a5cc5845e537af3ed0e209dbcde5bd200ba127d4e00498f5af0ebcf.jpg)

<!-- Source: /api/assets/306f89cd28d616e951aed462a6e737f4e0ade1031586cb281e3b1669ff6a1c82.jpg; PDF page 44; full -->

```text
Reading
D Another discovery is that oxytocin's effects vary depending on who we are
interacting with. Studies conducted by Carolyn DeClerck of the University of
Antwerp, Belgium, revealed that people who had received a dose of oxytocin
actually became less cooperative when dealing with complete strangers.
Meanwhile, Carsten De Dreu at the University of Amsterdam in the Netherlands
discovered that volunteers given oxytocin showed favouritism: Dutch men became
quicker to associate positive words with Dutch names than with foreign ones,
for example. According to De Dreu, oxytocin drives people to care for those in
their social circles and defend them from outside dangers. So, it appears that
oxytocin strengthens biases, rather than promoting general goodwill, as was
previously thought.
E There were signs of these subtleties from the start. Bartz has recently shown that
in almost half of the existing research results, oxytocin influenced only certain
individuals or in certain circumstances. Where once researchers took no notice
of such findings, now a more nuanced understanding of oxytocin's effects is
propelling investigations down new lines. To Bartz, the key to understanding what
the hormone does lies in pinpointing its core function rather than in cataloguing its
seemingly endless effects. There are several hypotheses which are not mutually
exclusive. Oxytocin could help to reduce anxiety and fear. Or it could simply
motivate people to seek out social connections. She believes that oxytocin acts as
a chemical spotlight that shines on social clues - a shift in posture, a flicker of the
eyes, a dip in the voice - making people more attuned to their social environment.
This would explain why it makes us more likely to look others in the eye and
improves our ability to identify emotions. But it could also make things worse for
people who are overly sensitive or prone to interpreting social cues in the
worst light.
F Perhaps we should not be surprised that the oxytocin story has become more
perplexing. The hormone is found in everything from octopuses to sheep, and its
evolutionary roots stretch back half a billion years. 'It's a very simple and ancient
molecule that has been co-opted for many different functions,, says Sue Carter at
the University of Illinois, Chicago, USA. ‘It affects primitive parts of the brain like
the amygdala, so it's going to have many effects on just about everything.' Bartz
agrees. ‘Oxytocin probably does some very basic things, but once you add our
higher-order thinking and social situations, these basic processes could manifest
in different ways depending on individual differences and context.’
43
```

[Original question page](assets/306f89cd28d616e951aed462a6e737f4e0ade1031586cb281e3b1669ff6a1c82.jpg)

<!-- Source: /api/assets/c7e276915e74a5ae6ed8f80824ab043439d3a0415b5e39e724a54484ed9f3990.jpg; PDF page 45; full -->

```text
Questions 14–17
Test 2
Reading Passage 2 has six paragraphs, A-F.
Which paragraph contains the following information?
Write the correct letter, A-F, in boxes 14-17 on your answer sheet.
NB You may use any letter more than once.
14 reference to research showing the beneficial effects of oxytocin on people
15 reasons why the effects of oxytocin are complex
16 mention of a period in which oxytocin attracted little scientific attention
17 reference to people ignoring certain aspects of their research data
Questions 18-20
Look at the following research findings (Questions 18-20) and the list of
researchers below.
Match each research finding with the correct researcher, A-F.
Write the correct letter, A-F, in boxes 18-20 on your answer sheet.
18 People are more trusting when affected by oxytocin.
19 Oxytocin increases people’s feelings of jealousy.
20 The effect of oxytocin varies from one type of person to another.

List of Researchers
A Markus Heinrichs
B Simone Shamay-Tsoory
C Jennifer Bartz
D Carolyn DeClerck
E Carsten De Dreu
F Sue Carter
44
```

[Original question page](assets/c7e276915e74a5ae6ed8f80824ab043439d3a0415b5e39e724a54484ed9f3990.jpg)

<!-- Source: /api/assets/26de3b458d99f1a6d8dcfcf59ee92ca348f101329442d456c52190fcd43a51e6.jpg; PDF page 46; full -->

```text
Reading
Questions 21-26
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 21-26 on your answer sheet.
Oxytocin research
The earliest findings about oxytocin and bonding came from research involving
(21) __________. It was also discovered that humans produce oxytocin during
(22) __________. An experiment in 2005, in which participants were given either
oxytocin or a 23...................., reinforced the belief that the hormone had a
positive effect.
However, later research suggests that this is not always the case. A study at the
University of Haifa where participants took part in a 24....................revealed
the negative emotions which oxytocin can trigger. A study at the University of Antwerp
showed people's lack of willingness to help 25....................while under the
influence of oxytocin. Meanwhile, research at the University of Amsterdam revealed that
people who have been given oxytocin consider 26....................that are familiar
to them in their own country to have more positive associations than those from other
cultures.
45
```

[Original question page](assets/26de3b458d99f1a6d8dcfcf59ee92ca348f101329442d456c52190fcd43a51e6.jpg)

<!-- Source: /api/assets/5436d378ddff97bc242c9d188973e39df00e03dff96a22417ffb0681f3a46bc6.jpg; PDF page 47; full -->

```text
Test 2
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
MAKING THE MOST OF TRENDS
Experts from Harvard Business School give advice to managers
Most managers can identify the major trends of the day. But in the course of conducting research
in a number of industries and working directly with companies, we have discovered that
managers often fail to recognize the less obvious but profound ways these trends are influencing
consumers’ aspirations, attitudes, and behaviors. This is especially true of trends that managers
view as peripheral to their core markets.
Many ignore trends in their innovation strategies or adopt a wait-and-see approach and let
competitors take the lead. At a minimum, such responses mean missed profit opportunities. At
the extreme, they can jeopardize a company by ceding to rivals the opportunity to transform the
industry. The purpose of this article is twofold: to spur managers to think more expansively about
how trends could engender new value propositions in their core markets, and to provide some
high-level advice on how to make market research and product development personnel more
adept at analyzing and exploiting trends.
One strategy, known as 'infuse and augment’, is to design a product or service that retains most
of the attributes and functions of existing products in the category but adds others that address
the needs and desires unleashed by a major trend. A case in point is the Poppy range of handbags,
which the firm Coach created in response to the economic downturn of 2008. The Coach brand
had been a symbol of opulence and luxury for nearly 70 years, and the most obvious reaction
to the downturn would have been to lower prices. However, that would have risked cheapening
the brand’s image. Instead, they initiated a consumer-research project which revealed that
customers were eager to lift themselves and the country out of tough times. Using these insights,
Coach launched the lower-priced Poppy handbags, which were in vibrant colors, and looked
more youthful and playful than conventional Coach products. Creating the sub-brand allowed
Coach to avert an across-the-board price cut. In contrast to the many companies that responded
to the recession by cutting prices, Coach saw the new consumer mindset as an opportunity for
innovation and renewal.
A further example of this strategy was supermarket Tesco’s response to consumers’ growing
concerns about the environment. With that in mind, Tesco, one of the world’s top five retailers,
introduced its Greener Living program, which demonstrates the company’s commitment to
protecting the environment by involving consumers in ways that produce tangible results. For
example, Tesco customers can accumulate points for such activities as reusing bags, recycling
cans and printer cartridges, and buying home-insulation materials. Like points earned on regular
purchases, these green points can be redeemed for cash. Tesco has not abandoned its traditional
retail offerings but augmented its business with these innovations, thereby infusing its value
proposition with a green streak.
46
```

[Original question page](assets/5436d378ddff97bc242c9d188973e39df00e03dff96a22417ffb0681f3a46bc6.jpg)

<!-- Source: /api/assets/54dd6ae1ce5ad551d0c9e454bfcca18af517574efc4b22b016627ed313f1012c.jpg; PDF page 48; full -->

```text
Reading
A more radical strategy is ‘combine and transcend’. This entails combining aspects of the
product’s existing value proposition with attributes addressing changes arising from a trend, to
create a novel experience - one that may land the company in an entirely new market space.
At first glance, spending resources to incorporate elements of a seemingly irrelevant trend into
one’s core offerings sounds like it’s hardly worthwhile. But consider Nike’s move to integrate the
digital revolution into its reputation for high-performance athletic footwear. In 2006, they teamed
up with technology company Apple to launch Nike+, a digital sports kit comprising a sensor
that attaches to the running shoe and a wireless receiver that connects to the user’s iPod. By
combining Nike’s original value proposition for amateur athletes with one for digital consumers,
the Nike+ sports kit and web interface moved the company from a focus on athletic apparel to a
new plane of engagement with its customers.
A third approach, known as 'counteract and reaffirm’, involves developing products or services
that stress the values traditionally associated with the category in ways that allow consumers to
oppose - or at least temporarily escape from - the aspects of trends they view as undesirable.
A product that accomplished this is the ME2, a video game created by Canada’s iToys. By
reaffirming the toy category’s association with physical play, the ME2 counteracted some of
the widely perceived negative impacts of digital gaming devices. Like other handheld games,
the device featured a host of exciting interactive games, a full-color LCD screen, and advanced
3D graphics. What set it apart was that it incorporated the traditional physical component
of children’s play: it contained a pedometer, which tracked and awarded points for physical
activity (walking, running, biking, skateboarding, climbing stairs). The child could use the
points to enhance various virtual skills needed for the video game. The ME2, introduced in mid-
2008, catered to kids’ huge desire to play video games while countering the negatives, such as
associations with lack of exercise and obesity.
Once you have gained perspective on how trend-related changes in consumer opinions and
behaviors impact on your category, you can determine which of our three innovation strategies to
pursue. When your category’s basic value proposition continues to be meaningful for consumers
influenced by the trend, the infuse-and-augment strategy will allow you to reinvigorate the
category. If analysis reveals an increasing disparity between your category and consumers’ new
focus, your innovations need to transcend the category to integrate the two worlds. Finally,
if aspects of the category clash with undesired outcomes of a trend, such as associations with
unhealthy lifestyles, there is an opportunity to counteract those changes by reaffirming the core
values of your category.
Trends —  technological, economic, environmental, social, or political - that affect how people
perceive the world around them and shape what they expect from products and services present
firms with unique opportunities for growth.
47
```

[Original question page](assets/54dd6ae1ce5ad551d0c9e454bfcca18af517574efc4b22b016627ed313f1012c.jpg)

<!-- Source: /api/assets/fae909a6de66251ea80dc7f0cdbaeca141ea69c305da245a41d8ba755db3738b.jpg; PDF page 49; full -->

```text
Questions 27–31
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27–31 on your answer sheet.
27 In the first paragraph, the writer says that most managers
A fail to spot the key consumer trends of the moment.
B make the mistake of focusing only on the principal consumer trends.
C misinterpret market research data relating to current consumer trends.
D are unaware of the significant impact that trends have on consumers’ lives.
28 According to the third paragraph, Coach was anxious to
A follow what some of its competitors were doing.
B maintain its prices throughout its range.
C safeguard its reputation as a manufacturer of luxury goods.
D modify the entire look of its brand to suit the economic climate.
29 What point is made about Tesco’s Greener Living programme?
A It did not require Tesco to modify its core business activities.
B It succeeded in attracting a more eco-conscious clientele.
C Its main aim was to raise consumers’ awareness of environmental issues.
D It was not the first time that Tesco had implemented such an initiative.
30 What does the writer suggest about Nike’s strategy?
A It was an extremely risky strategy at the time.
B It was a strategy that only a major company could afford to follow.
C It was the type of strategy that would not have been possible in the past.
D It was the kind of strategy which might appear to have few obvious benefits.
31 What was original about the ME2?
A It contained technology that had been developed for the sports industry.
B It appealed to young people who were keen to improve their physical fitness.
C It took advantage of a current trend for video games with colourful 3D graphics.
D It was a handheld game that addressed people’s concerns about unhealthy lifestyles.
```

[Original question page](assets/fae909a6de66251ea80dc7f0cdbaeca141ea69c305da245a41d8ba755db3738b.jpg)

<!-- Source: /api/assets/dc0184e3d0af5b34e323b27a5114d79bf9b2da817f29af94b6e842fefe1ef4d3.jpg; PDF page 50; full -->

```text
Questions 32-37
Look at the following statements (Questions 32-37) and the list of companies below.
Reading
Match each statement with the correct company, A, B, C or D.
Write the correct letter, A, B, C or D, in boxes 32-37 on your answer sheet.
NB You may use any letter more than once.
32 It turned the notion that its products could have harmful effects to its own
advantage.
33 It extended its offering by collaborating with another manufacturer.
34 It implemented an incentive scheme to demonstrate its corporate social
responsibility.
35 It discovered that customers had a positive attitude towards dealing with difficult
circumstances.
36 It responded to a growing lifestyle trend in an unrelated product sector.
37 It successfully avoided having to charge its customers less for its core products.
List of companies
A Coach
B Tesco
C Nike
D iToys
49
```

[Original question page](assets/dc0184e3d0af5b34e323b27a5114d79bf9b2da817f29af94b6e842fefe1ef4d3.jpg)

<!-- Source: /api/assets/b9fe036cabc2f1d2882101aa8f9eb5d21d2fe799830d6453befcf17560ebef6d.jpg; PDF page 51; full -->

```text
Questions 38–40
Test 2
Complete each sentence with the correct ending, A, B, C or D below.
Write the correct letter, A, B, C or D, in boxes 38-40 on your answer sheet.
38 If there are any trend-related changes impacting on your category, you should
39 If a current trend highlights a negative aspect of your category, you should
40 If the consumers’ new focus has an increasing lack of connection with your offering,
you should
A employ a combination of strategies to maintain your consumer base.
B identify the most appropriate innovation strategy to use.
C emphasise your brand's traditional values with the counteract-and-
affirm strategy.
D use the combine-and-transcend strategy to integrate the two worlds.

50
```

[Original question page](assets/b9fe036cabc2f1d2882101aa8f9eb5d21d2fe799830d6453befcf17560ebef6d.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/4bb31fc9ef5ac12269806fc55b69de800b4cc802286a59d65d9bde86313f275b.jpg; PDF page 52; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows the percentage of households in owned and rented accommodation in England and Wales between 1918 and 2011.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/4bb31fc9ef5ac12269806fc55b69de800b4cc802286a59d65d9bde86313f275b.jpg)

![Original figure](assets/4bb31fc9ef5ac12269806fc55b69de800b4cc802286a59d65d9bde86313f275b.jpg)

### Task 2

<!-- Source: /api/assets/5401062ea47fd19dec577a52b4bca973197fb49bb511b6a05893a083392127d9.jpg; PDF page 53; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that nowadays we have too many choices.

To what extent do you agree or disagree with this statement?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/5401062ea47fd19dec577a52b4bca973197fb49bb511b6a05893a083392127d9.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/1d70b019ca901986069e4fe5009379c65ffcb95848b04ee62fb3fb0a6f67fa1e.jpg; PDF page 54; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Age
• Are you happy to be the age you are now? [Why/Why not?]
• When you were a child, did you think a lot about your future? [Why/Why not?]
• Do you think you have changed as you have got older? [Why/Why not?]
• What will be different about your life in the future? [Why]
PART 2
Describe a time when you started using a new
technological device (e.g. a new computer or phone).
You should say:
what device you started using
why you started using this device
how easy or difficult it was to use
and explain how helpful this device was to you.
You will have to talk
about the topic for one
to two minutes. You
have one minute to
think about what you
are going to say. You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Technology and education
Example questions:
What is the best age for children to start computer lessons?
Do you think that schools should use more technology to help children learn?
Do you agree or disagree that computers will replace teachers one day?
Technology and society
Example questions:
How much has technology improved how we communicate with each other?
Do you agree that there are still many more major technological innovations to
be made?
Could you suggest some reasons why some people are deciding to reduce their use
of technology?

53
```

[Original question page](assets/1d70b019ca901986069e4fe5009379c65ffcb95848b04ee62fb3fb0a6f67fa1e.jpg)

### Part 2

<!-- Source: /api/assets/1d70b019ca901986069e4fe5009379c65ffcb95848b04ee62fb3fb0a6f67fa1e.jpg; PDF page 54; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Age
• Are you happy to be the age you are now? [Why/Why not?]
• When you were a child, did you think a lot about your future? [Why/Why not?]
• Do you think you have changed as you have got older? [Why/Why not?]
• What will be different about your life in the future? [Why]
PART 2
Describe a time when you started using a new
technological device (e.g. a new computer or phone).
You should say:
what device you started using
why you started using this device
how easy or difficult it was to use
and explain how helpful this device was to you.
You will have to talk
about the topic for one
to two minutes. You
have one minute to
think about what you
are going to say. You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Technology and education
Example questions:
What is the best age for children to start computer lessons?
Do you think that schools should use more technology to help children learn?
Do you agree or disagree that computers will replace teachers one day?
Technology and society
Example questions:
How much has technology improved how we communicate with each other?
Do you agree that there are still many more major technological innovations to
be made?
Could you suggest some reasons why some people are deciding to reduce their use
of technology?

53
```

[Original question page](assets/1d70b019ca901986069e4fe5009379c65ffcb95848b04ee62fb3fb0a6f67fa1e.jpg)

### Part 3

<!-- Source: /api/assets/1d70b019ca901986069e4fe5009379c65ffcb95848b04ee62fb3fb0a6f67fa1e.jpg; PDF page 54; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Age
• Are you happy to be the age you are now? [Why/Why not?]
• When you were a child, did you think a lot about your future? [Why/Why not?]
• Do you think you have changed as you have got older? [Why/Why not?]
• What will be different about your life in the future? [Why]
PART 2
Describe a time when you started using a new
technological device (e.g. a new computer or phone).
You should say:
what device you started using
why you started using this device
how easy or difficult it was to use
and explain how helpful this device was to you.
You will have to talk
about the topic for one
to two minutes. You
have one minute to
think about what you
are going to say. You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Technology and education
Example questions:
What is the best age for children to start computer lessons?
Do you think that schools should use more technology to help children learn?
Do you agree or disagree that computers will replace teachers one day?
Technology and society
Example questions:
How much has technology improved how we communicate with each other?
Do you agree that there are still many more major technological innovations to
be made?
Could you suggest some reasons why some people are deciding to reduce their use
of technology?

53
```

[Original question page](assets/1d70b019ca901986069e4fe5009379c65ffcb95848b04ee62fb3fb0a6f67fa1e.jpg)
