# 剑雅 8 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 155

TEST 3 LISTENING
1 central
2 600
3 2 year(s)
4 garage
5 garden
6 study
7 noisy
8 595
9 B
10 E
11 classical music / (classical / music) concerts
12 bookshop / bookstore
13 planned
14 1983 / (the) 1980s
15 City Council
16 363
17 (the) Garden Hall
18 Three Lives
19 4.50
20 Faces of China
21 C
22 C
23 A
24 B
25 C
26 A
27 C
28 A
29 B
30 C
31 B
32 B
33 B
34 A
35 combination / system
36 safety
37 attitude(s)
38 control(s)
39 factory / factories
40 skills
9–10 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. central

2. 600

3. 2 year / 2 years

4. garage

5. garden

6. study

7. noisy

8. 595

9. B / E

10. B / E

### Part 2 · source page 155

TEST 3 LISTENING
1 central
2 600
3 2 year(s)
4 garage
5 garden
6 study
7 noisy
8 595
9 B
10 E
11 classical music / (classical / music) concerts
12 bookshop / bookstore
13 planned
14 1983 / (the) 1980s
15 City Council
16 363
17 (the) Garden Hall
18 Three Lives
19 4.50
20 Faces of China
21 C
22 C
23 A
24 B
25 C
26 A
27 C
28 A
29 B
30 C
31 B
32 B
33 B
34 A
35 combination / system
36 safety
37 attitude(s)
38 control(s)
39 factory / factories
40 skills
9–10 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. classical music / concerts / classical concerts / music concerts

12. bookshop / bookstore

13. planned

14. 1983 / 1980s / the 1980s

15. City Council

16. 363

17. Garden Hall / the Garden Hall

18. Three Lives

19. 4.50 / 4:50

20. Faces of China

### Part 3 · source page 155

TEST 3 LISTENING
1 central
2 600
3 2 year(s)
4 garage
5 garden
6 study
7 noisy
8 595
9 B
10 E
11 classical music / (classical / music) concerts
12 bookshop / bookstore
13 planned
14 1983 / (the) 1980s
15 City Council
16 363
17 (the) Garden Hall
18 Three Lives
19 4.50
20 Faces of China
21 C
22 C
23 A
24 B
25 C
26 A
27 C
28 A
29 B
30 C
31 B
32 B
33 B
34 A
35 combination / system
36 safety
37 attitude(s)
38 control(s)
39 factory / factories
40 skills
9–10 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. C

22. C

23. A

24. B

25. C

26. A

27. C

28. A

29. B

30. C

### Part 4 · source page 155

TEST 3 LISTENING
1 central
2 600
3 2 year(s)
4 garage
5 garden
6 study
7 noisy
8 595
9 B
10 E
11 classical music / (classical / music) concerts
12 bookshop / bookstore
13 planned
14 1983 / (the) 1980s
15 City Council
16 363
17 (the) Garden Hall
18 Three Lives
19 4.50
20 Faces of China
21 C
22 C
23 A
24 B
25 C
26 A
27 C
28 A
29 B
30 C
31 B
32 B
33 B
34 A
35 combination / system
36 safety
37 attitude(s)
38 control(s)
39 factory / factories
40 skills
9–10 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. B

32. B

33. B

34. A

35. combination / system

36. safety

37. attitude / attitudes

38. control / controls

39. factory / factories

40. skills

## A 类阅读

### Academic Reading · source page 156

ACADEMIC READING
1 D
2 A
3 A
4 power companies
5 safely
6 size
7 B
8 C
9 G
10 D
11 NO
12 YES
13 NOT GIVEN
14 B
15 C
16 F
17 H
18 J
19 TRUE
20 TRUE
21 FALSE
22 TRUE
23 TRUE
24 NOT GIVEN
25 TRUE
26 NOT GIVEN
27 ix
28 ii
29 vii
30 i
31 viii
32 iv
33 physical chemistry (and)
34 thermodynamics
35 adapt
36 immortality
37 NO
38 YES
39 NOT GIVEN
40 YES
14–18 IN ANY ORDER: B; C; F; H; J
33–34 IN EITHER ORDER: physical chemistry (and); thermodynamics
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. D

2. A

3. A

4. power companies

5. safely

6. size

7. B

8. C

9. G

10. D

11. NO

12. YES

13. NOT GIVEN

14. B / C / F / H / J

15. B / C / F / H / J

16. B / C / F / H / J

17. B / C / F / H / J

18. B / C / F / H / J

19. TRUE

20. TRUE

21. FALSE

22. TRUE

23. TRUE

24. NOT GIVEN

25. TRUE

26. NOT GIVEN

27. ix

28. ii

29. vii

30. i

31. viii

32. iv

33. physical chemistry / physical chemistry and / thermodynamics

34. physical chemistry / physical chemistry and / thermodynamics

35. adapt

36. immortality

37. NO

38. YES

39. NOT GIVEN

40. YES

## A 类写作

### Writing material: c8-t3-w-1

Full original diagrams inspected. Cement: limestone and clay enter a crusher and become powder; powder passes through a mixer into a rotating heater, with heat applied at one end; output passes through a grinder, yielding cement, which is packed in bags. Concrete: cement15%, water10%, sand25%, gravel50% enter a rotating concrete mixer. Gravel is explicitly defined as small stones. Cement is one ingredient of concrete, not the same material. Cement manufacturing has multiple processing stages and heating; concrete production combines four ingredients in one mixing operation. The concrete percentages total100%. Do not invent processing times, temperatures or heating in the concrete mixer.



### Writing material: c8-t3-w-2

Address both the claim that higher petrol prices are the BEST solution and other effective measures. An opinion without alternatives misses the second explicit question; no one stance is required.



## 口语
