# 剑雅 8 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/9668e464092c6a32b27a2d4a46a2dec10878986b6dad225ba73362cb3b8fa014.jpg; PDF page 55; full -->

```text
Test 3
LISTENING
SECTION 1
Questions 1-3
Questions 1-10
Complete the form below.
Write ONE WORD AND/OR A NUMBER for each answer.
Rented Properties
Customer's Requirements
Name: Steven Godfrey
Example Answer
No. of bedrooms: four .......
Preferred location: in the 1 ....................... area of town
Maximum monthly rent: 2 £ .......................
Length of let required: 3 .......................
Starting: September 1st
56
```

[Original question page](assets/9668e464092c6a32b27a2d4a46a2dec10878986b6dad225ba73362cb3b8fa014.jpg)

<!-- Source: /api/assets/d3d548044608175d7597d7b46ad4a7624a42dbd0595b26aad35bb985607ca891.jpg; PDF page 56; full -->

```text
Questions 4–8
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
| Address | Rooms | Monthly rent | Problem |
| --- | --- | --- | --- |
| Oakington Avenue | living/dining room, separate kitchen | £550 | no (4) __________ |
| Mead Street | large living room and kitchen, bathroom and a cloakroom | £580 | the (5) __________ is too large |
| Hamilton Road | living room, kitchen-diner, and a (6) __________ | £550 | too (7) __________ |
| Devon Close | living room, dining room, small kitchen | (8) £__________ | none |
```

[Original question page](assets/d3d548044608175d7597d7b46ad4a7624a42dbd0595b26aad35bb985607ca891.jpg)

<!-- Source: /api/assets/b56f8f7bf119e8dc1e0a3ca0f405dcb9f9b3baca692b6b4f0ea40fd5909ddfbd.jpg; PDF page 57; full -->

```text
Test3
Questions 9 and 10
Choose TWO letters, A-E.
Which TWO facilities in the district of Devon Close are open to the public at the moment?
A museum
B concert hall
C cinema
D sports centre
E swimming pool
58
```

[Original question page](assets/b56f8f7bf119e8dc1e0a3ca0f405dcb9f9b3baca692b6b4f0ea40fd5909ddfbd.jpg)

### Part 2

<!-- Source: /api/assets/9c7edaef76d2a14c0facae1651d4fde0a8e489e392a234e7870b92a831f74dbd.jpg; PDF page 58; full -->

```text
SECTION 2
Questions 11-16
Questions 11-20
Complete the notes below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
THE NATIONAL ARTS CENTRE
Well known for:
Complex consists of:
Historical background:
11 ...................... .
concert rooms
theatres
cinemas
art galleries
public library
restaurants
a 12 ...................... .
1940 – area destroyed by bombs
Listening
1960s-1970s - Centre was 13 ....................... and
built
in 14 ....................... opened to public
Managed by: the 15 ...................... .
Open: 16 ....................... days per year
59
```

[Original question page](assets/9c7edaef76d2a14c0facae1651d4fde0a8e489e392a234e7870b92a831f74dbd.jpg)

<!-- Source: /api/assets/7eae700c283b6f7c893e0dd91219901ba66593a0ab293a28237ba0e9c7a46605.jpg; PDF page 59; full -->

```text
Questions 17–20
Complete the table below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
| Day | Time | Event | Venue | Ticket price |
| --- | --- | --- | --- | --- |
| Monday and Tuesday | 7.30 p.m. | ‘The Magic Flute’ (opera by Mozart) | (17) __________ | from £8.00 |
| Wednesday | 8.00 p.m. | (18) ‘__________’ (Canadian film) | Cinema 2 | (19) £__________ |
| Saturday and Sunday | 11 a.m. to 10 p.m. | (20) ‘__________’ (art exhibition) | Gallery 1 | free |
```

[Original question page](assets/7eae700c283b6f7c893e0dd91219901ba66593a0ab293a28237ba0e9c7a46605.jpg)

### Part 3

<!-- Source: /api/assets/4374b215c9b3b21eb04076a8e3146b004e4e132a98bafd43e5d3fd99e47c3ac9.jpg; PDF page 60; full -->

```text
SECTION 3
Questions 21-26
Questions 21-30
Choose the correct letter, A, B or C.
Latin American studies
21 Paul decided to get work experience in South America because he wanted
A to teach English there.
B to improve his Spanish.
C to learn about Latin American life.
22 What project work did Paul originally intend to get involved in?
A construction
B agriculture
C tourism
23 Why did Paul change from one project to another?
A His first job was not well organised.
B He found doing the routine work very boring.
C The work was too physically demanding.
24 In the village community, he learnt how important it was to
A respect family life.
B develop trust.
C use money wisely.
25 What does Paul say about his project manager?
A He let Paul do most of the work.
B His plans were too ambitious.
C He was very supportive of Paul.
26 Paul was surprised to be given
A a computer to use.
B so little money to live on.
C an extension to his contract.
Listening
61
```

[Original question page](assets/4374b215c9b3b21eb04076a8e3146b004e4e132a98bafd43e5d3fd99e47c3ac9.jpg)

<!-- Source: /api/assets/e927ef9f41da1eaccab93389dd7b513fa09b724084f7ed75df60d4bd94262e45.jpg; PDF page 61; full -->

```text
Test3
Questions 27-30
What does Paul decide about each of the following modules?
Write the correct letter, A, B or C, next to questions 27-30.
Module
A He will do this.
B He might do this.
C He won't do this.
27 Gender Studies in Latin America
28 Second Language Acquisition
29 Indigenous Women's Lives
30 Portuguese Language Studies
62
```

[Original question page](assets/e927ef9f41da1eaccab93389dd7b513fa09b724084f7ed75df60d4bd94262e45.jpg)

### Part 4

<!-- Source: /api/assets/74a0da3d199ee205b93601dd6f6c8a7809d496068a0034c9899e53db908d2fbd.jpg; PDF page 62; full -->

```text
Listening
SECTION 4
Questions 31-34
Questions 31-40
Choose the correct letter, A, B or C.
Trying to repeat success
31 Compared to introducing new business processes, attempts to copy existing
processes are
A more attractive.
B more frequent.
C more straightforward.
32 Most research into the repetition of success in business has
A been done outside the United States.
B produced consistent findings.
C related to only a few contexts.
33 What does the speaker say about consulting experts?
A Too few managers ever do it.
B It can be useful in certain circumstances.
C Experts are sometimes unwilling to give advice.
34 An expert's knowledge about a business system may be incomplete because
A some details are difficult for workers to explain.
B workers choose not to mention certain details.
C details are sometimes altered by workers.
63
```

[Original question page](assets/74a0da3d199ee205b93601dd6f6c8a7809d496068a0034c9899e53db908d2fbd.jpg)

<!-- Source: /api/assets/b844917eed1e708ec22f91ff5515cc7668584662addc443975ecaf4c6cd49030.jpg; PDF page 63; full -->

```text
Test3
Questions 35-40
Complete the notes below.
Write ONE WORD ONLY for each answer.
Setting up systems based on an existing process
Two mistakes
Manager tries to:
• improve on the original process
• create an ideal 35 ....................... from the best parts of several processes
Cause of problems
• information was inaccurate
• comparison between the business settings was invalid
• disadvantages were overlooked, e.g. effect of changes on 36 ...................... .
Solution
• change 37 ...................... .
• impose rigorous 38 ..................... ..
• copy original very closely:
- physical features of the 39 ...................... .
- the 40 ....................... of original employees
64
```

[Original question page](assets/b844917eed1e708ec22f91ff5515cc7668584662addc443975ecaf4c6cd49030.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/ad86f1c94262245efc40ba7528ebc50832e015a4662d8683237bf775c5d63878.jpg; PDF page 64; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13 which are based on Reading
Passage 1 below.
Striking Back at Lightning
With Lasers
Seldom is the weather more dramatic than when thunderstorms strike. Their electrical fury
inflicts death or serious injury on around 500 people each year in the United States alone. As the
clouds roll in, a leisurely round of golf can become a terrifying dice with death - out in the open,
a lone golfer may be a lightning bolt's most inviting target. And there is damage to property
too. Lightning damage costs American power companies more than $100 million a year.
But researchers in the United States and Japan are planning to hit back. Already in laboratory
trials they have tested strategies for neutralising the power of thunderstorms, and this winter
they will brave real storms, equipped with an armoury of lasers that they will be pointing
towards the heavens to discharge thunderclouds before lightning can strike.
The idea of forcing storm clouds to discharge their lightning on command is not new. In the
early 1960s, researchers tried firing rockets trailing wires into thunderclouds to set up an
easy discharge path for the huge electric charges that these clouds generate. The technique
survives to this day at a test site in Florida run by the University of Florida, with support
from the Electrical Power Research Institute (EPRI), based in California. EPRI, which is
funded by power companies, is looking at ways to protect the United States' power grid from
lightning strikes. 'We can cause the lightning to strike where we want it to using rockets,' says
Ralph Bernstein, manager of lightning projects at EPRI. The rocket site is providing precise
measurements of lightning voltages and allowing engineers to check how electrical equipment
bears up.
Bad behaviour
But while rockets are fine for research, they cannot provide the protection from lightning
strikes that everyone is looking for. The rockets cost around $1,200 each, can only be fired
at a limited frequency and their failure rate is about 40 per cent. And even when they do
trigger lightning, things still do not always go according to plan. 'Lightning is not perfectly
well behaved,' says Bernstein. 'Occasionally, it will take a branch and go someplace it wasn't
supposed to go.'
And anyway, who would want to fire streams of rockets in a populated area? 'What goes up
must come down,' points out Jean-Claude Diels of the University of New Mexico. Diels is
leading a project, which is backed by EPRI, to try to use lasers to discharge lightning safely
65
```

[Original question page](assets/ad86f1c94262245efc40ba7528ebc50832e015a4662d8683237bf775c5d63878.jpg)

<!-- Source: /api/assets/882ad70842f47dcf4f56126c364c851fa9774fb44a75e430ea36131a3976d99d.jpg; PDF page 65; full -->

```text
Test3
- and safety is a basic requirement since no one wants to put themselves or their expensive
equipment at risk. With around $500,000 invested so far, a promising system is just emerging
from the laboratory.
The idea began some 20 years ago, when high-powered lasers were revealing their ability to
extract electrons out of atoms and create ions. If a laser could generate a line of ionisation
in the air all the way up to a storm cloud, this conducting path could be used to guide
lightning to Earth, before the electric field becomes strong enough to break down the air in an
uncontrollable surge. To stop the laser itself being struck, it would not be pointed straight at
the clouds. Instead it would be directed at a mirror, and from there into the sky. The mirror
would be protected by placing lightning conductors close by. Ideally, the cloud-zapper (gun)
would be cheap enough to be installed around all key power installations, and portable enough
to be taken to international sporting events to beam up at brewing storm clouds.
A stumbling block
However, there is still a big stumbling block. The laser is no nifty portable: it's a monster
that takes up a whole room. Diels is trying to cut down the size and says that a laser around
the size of a small table is in the offing. He plans to test this more manageable system on live
thunderclouds next summer.
Bernstein says that Diels's system is attracting lots of interest from the power companies.
But they have not yet come up with the $5 million that EPRI says will be needed to develop a
commercial system, by making the lasers yet smaller and cheaper. 'I cannot say I have money
yet, but I'm working on it,' says Bernstein. He reckons that the forthcoming field tests will be
the turning point - and he's hoping for good news. Bernstein predicts 'an avalanche of interest
and support' if all goes well. He expects to see cloud-zappers eventually costing $50,000 to
$100,000 each.
Other scientists could also benefit. With a lightning 'switch' at their fingertips, materials
scientists could find out what happens when mighty currents meet matter. Diels also hopes to
see the birth of 'interactive meteorology' - not just forecasting the weather but controlling it.
'If we could discharge clouds, we might affect the weather,' he says.
And perhaps, says Diels, we'll be able to confront some other meteorological menaces. 'We
think we could prevent hail by inducing lightning,' he says. Thunder, the shock wave that
comes from a lightning flash, is thought to be the trigger for the torrential rain that is typical
of storms. A laser thunder factory could shake the moisture out of clouds, perhaps preventing
the formation of the giant hailstones that threaten crops. With luck, as the storm clouds
gather this winter, laser-toting researchers could, for the first time, strike back.
66
```

[Original question page](assets/882ad70842f47dcf4f56126c364c851fa9774fb44a75e430ea36131a3976d99d.jpg)

<!-- Source: /api/assets/9a6ac30b42d3cf996d59a6232fdad918f0090f1996fc4cba10343c9d7ea68a38.jpg; PDF page 66; full -->

```text
Reading
Questions 1-3
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 1-3 on your answer sheet.
1 The main topic discussed in the text is
A the damage caused to US golf courses and golf players by lightning strikes.
B the effect of lightning on power supplies in the US and in Japan.
C a variety of methods used in trying to control lightning strikes.
D a laser technique used in trying to control lightning strikes.
2 According to the text, every year lightning
A does considerable damage to buildings during thunderstorms.
B kills or injures mainly golfers in the United States.
C kills or injures around 500 people throughout the world.
D damages more than 100 American power companies.
3 Researchers at the University of Florida and at the University of New Mexico
A receive funds from the same source.
B are using the same techniques.
C are employed by commercial companies.
D are in opposition to each other.
Questions 4-6
Complete the sentences below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 4-6 on your answer sheet.
4 EPRI receives financial support from ........................ .
5 The advantage of the technique being developed by Diels is that it can be
used ........................ .
6 The main difficulty associated with using the laser equipment is related to
its ........................ .
67
```

[Original question page](assets/9a6ac30b42d3cf996d59a6232fdad918f0090f1996fc4cba10343c9d7ea68a38.jpg)

<!-- Source: /api/assets/f1435a2ae3cdaf59ae262619402fb2ef68191abc3c75497803a2d77de520f2bc.jpg; PDF page 67; full -->

```text
Test3
Questions 7–10
Complete the summary using the list of words, A-I, below.
Write the correct letter, A-I, in boxes 7-10 on your answer sheet.
In this method, a laser is used to create a line of ionisation by removing electrons
from 7 ......................... This laser is then directed at 8 ........................ in order to
control electrical charges, a method which is less dangerous than using
9 ......................... As a protection for the lasers, the beams are aimed firstly at
10 ........................ .
68
A cloud-zappers
D mirrors
G rockets
B atoms
E technique
H conductors
C storm clouds
F ions
I thunder
```

[Original question page](assets/f1435a2ae3cdaf59ae262619402fb2ef68191abc3c75497803a2d77de520f2bc.jpg)

<!-- Source: /api/assets/f73bb8cd06764f01c257f8eb189b1a3ed3388e2446789483d5cac97d6119c8a4.jpg; PDF page 68; full -->

```text
Reading
Questions 11-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 11-13 on your answer sheet write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
11 Power companies have given Diels enough money to develop his laser.
12 Obtaining money to improve the lasers will depend on tests in real storms.
13 Weather forecasters are intensely interested in Diels's system.
69
```

[Original question page](assets/f73bb8cd06764f01c257f8eb189b1a3ed3388e2446789483d5cac97d6119c8a4.jpg)

<!-- Source: /api/assets/e2db0bdc17457709f2375e6307924b68b4700a3935fd7ffa9eb21b3483c70883.jpg; PDF page 69; full -->

```text
Test3
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
The Nature of Genius
There has always been an interest in geniuses and prodigies. The word 'genius', from
the Latin gens (= family) and the term 'genius', meaning 'begetter', comes from the
early Roman cult of a divinity as the head of the family. In its earliest form, genius was
concerned with the ability of the head of the family, the paterfamilias, to perpetuate
himself. Gradually, genius came to represent a person's characteristics and thence an
individual's highest attributes derived from his 'genius' or guiding spirit. Today, people
still look to stars or genes, astrology or genetics, in the hope of finding the source of
exceptional abilities or personal characteristics.
The concept of genius and of gifts has become part of our folk culture, and
attitudes are ambivalent towards them. We envy the gifted and mistrust them. In the
mythology of giftedness, it is popularly believed that if people are talented in one area,
they must be defective in another, that intellectuals are impractical, that prodigies
burn too brightly too soon and burn out, that gifted people are eccentric, that they
are physical weaklings, that there's a thin line between genius and madness, that
genius runs in families, that the gifted are so clever they don't need special help, that
giftedness is the same as having a high IQ, that some races are more intelligent or
musical or mathematical than others, that genius goes unrecognised and unrewarded,
that adversity makes men wise or that people with gifts have a responsibility to
use them. Language has been enriched with such terms as 'highbrow', 'egghead',
'blue-stocking', 'wiseacre', 'know-all', 'boffin' and, for many, 'intellectual' is a term of
denigration.
The nineteenth century saw considerable interest in the nature of genius, and
produced not a few studies of famous prodigies. Perhaps for us today, two of the
most significant aspects of most of these studies of genius are the frequency with
which early encouragement and teaching by parents and tutors had beneficial effects
on the intellectual, artistic or musical development of the children but caused great
difficulties of adjustment later in their lives, and the frequency with which abilities
went unrecognised by teachers and schools. However, the difficulty with the evidence
produced by these studies, fascinating as they are in collecting together anecdotes
and apparent similarities and exceptions, is that they are not what we would today
call norm-referenced. In other words, when, for instance, information is collated
about early illnesses, methods of upbringing, schooling, etc., we must also take into
account information from other historical sources about how common or exceptional
these were at the time. For instance, infant mortality was high and life expectancy
much shorter than today, home tutoring was common in the families of the nobility
and wealthy, bullying and corporal punishment were common at the best independent
70
```

[Original question page](assets/e2db0bdc17457709f2375e6307924b68b4700a3935fd7ffa9eb21b3483c70883.jpg)

<!-- Source: /api/assets/0a3194d7d8ff23d25498cf72355507d049a0c6843026864977455320e600264f.jpg; PDF page 70; full -->

```text
Reading
schools and, for the most part, the cases studied were members of the privileged
classes. It was only with the growth of paediatrics and psychology in the twentieth
century that studies could be carried out on a more objective, if still not always very
scientific, basis.
Geniuses, however they are defined, are but the peaks which stand out through
the mist of history and are visible to the particular observer from his or her particular
vantage point. Change the observers and the vantage points, clear away some of the
mist, and a different lot of peaks appear. Genius is a term we apply to those whom
we recognise for their outstanding achievements and who stand near the end of the
continuum of human abilities which reaches back through the mundane and mediocre
to the incapable. There is still much truth in Dr Samuel Johnson's observation, 'The
true genius is a mind of large general powers, accidentally determined to some
particular direction'. We may disagree with the 'general', for we doubt if all musicians
of genius could have become scientists of genius or vice versa, but there is no
doubting the accidental determination which nurtured or triggered their gifts into
those channels into which they have poured their powers so successfully. Along the
continuum of abilities are hundreds of thousands of gifted men and women, boys and
girls.
What we appreciate, enjoy or marvel at in the works of genius or the achievements
of prodigies are the manifestations of skills or abilities which are similar to, but so
much superior to, our own. But that their minds are not different from our own is
demonstrated by the fact that the hard-won discoveries of scientists like Kepler
or Einstein become the commonplace knowledge of schoolchildren and the once
outrageous shapes and colours of an artist like Paul Klee so soon appear on the
fabrics we wear. This does not minimise the supremacy of their achievements, which
outstrip our own as the sub-four-minute milers outstrip our jogging.
To think of geniuses and the gifted as having uniquely different brains is only
reasonable if we accept that each human brain is uniquely different. The purpose of
instruction is to make us even more different from one another, and in the process
of being educated we can learn from the achievements of those more gifted than
ourselves. But before we try to emulate geniuses or encourage our children to do so
we should note that some of the things we learn from them may prove unpalatable.
We may envy their achievements and fame, but we should also recognise the
price they may have paid in terms of perseverance, single-mindedness, dedication,
restrictions on their personal lives, the demands upon their energies and time, and
how often they had to display great courage to preserve their integrity or to make their
way to the top.
Genius and giftedness are relative descriptive terms of no real substance. We may,
at best, give them some precision by defining them and placing them in a context but,
whatever we do, we should never delude ourselves into believing that gifted children
or geniuses are different from the rest of humanity, save in the degree to which they
have developed the performance of their abilities.
71
```

[Original question page](assets/0a3194d7d8ff23d25498cf72355507d049a0c6843026864977455320e600264f.jpg)

<!-- Source: /api/assets/716b127a2f115f77b256407e0f075de1c5dfee9db25359ecbca26cbf3557dacd.jpg; PDF page 71; full -->

```text
Test3
Questions 14-18
Choose FIVE letters, A-K.
Write the correct letters in boxes 14-18 on your answer sheet.
NB Your answers may be given in any order.
Below are listed some popular beliefs about genius and giftedness.
Which FIVE of these beliefs are reported by the writer of the text?
A Truly gifted people are talented in all areas.
B The talents of geniuses are soon exhausted.
C Gifted people should use their gifts.
D A genius appears once in every generation.
E Genius can be easily destroyed by discouragement.
F Genius is inherited.
G Gifted people are very hard to live with.
H People never appreciate true genius.
I Geniuses are natural leaders.
J Gifted people develop their greatness through difficulties.
K Genius will always reveal itself.
72
```

[Original question page](assets/716b127a2f115f77b256407e0f075de1c5dfee9db25359ecbca26cbf3557dacd.jpg)

<!-- Source: /api/assets/dc5f11146ffdbe378642a94ba76ac9d34c6ac418505ad1564051f0fd611264f4.jpg; PDF page 72; full -->

```text
Reading
Questions 19-26
Do the following statements agree with the information given in Reading Passage 2?
In boxes 19-26 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this .
19 Nineteenth-century studies of the nature of genius failed to take into account the
uniqueness of the person's upbringing.
20 Nineteenth-century studies of genius lacked both objectivity and a proper scientific
approach.
21 A true genius has general powers capable of excellence in any area.
22 The skills of ordinary individuals are in essence the same as the skills of prodigies.
23 The ease with which truly great ideas are accepted and taken for granted fails to
lessen their significance.
24 Giftedness and genius deserve proper scientific research into their true nature so
that all talent may be retained for the human race.
25 Geniuses often pay a high price to achieve greatness.
26 To be a genius is worth the high personal cost.
73
```

[Original question page](assets/dc5f11146ffdbe378642a94ba76ac9d34c6ac418505ad1564051f0fd611264f4.jpg)

<!-- Source: /api/assets/1fdc6b1cf8938ca2ab2b8d64f9ee6aebf48fda39bf1360d81ce31eb4123acc4a.jpg; PDF page 73; full -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27–40, which are based on Reading Passage 3 on the following pages.
Questions 27–32
Reading Passage 3 has seven paragraphs, A–G.
Choose the correct heading for paragraphs B–G from the list of headings below.
Write the correct number, i–x, in boxes 27–32 on your answer sheet.
List of Headings
i The biological clock
ii Why dying is beneficial
iii The ageing process of men and women
iv Prolonging your life
v Limitations of life span
vi Modes of development of different species
vii A stable life span despite improvements
viii Energy consumption
ix Fundamental differences in ageing of objects and organisms
x Repair of genetic material
Example — Paragraph A: v
27 Paragraph B
28 Paragraph C
29 Paragraph D
30 Paragraph E
31 Paragraph F
32 Paragraph G
```

[Original question page](assets/1fdc6b1cf8938ca2ab2b8d64f9ee6aebf48fda39bf1360d81ce31eb4123acc4a.jpg)

<!-- Source: /api/assets/87a82e69f7055abfcdf96a5e14737d6f9fb3faa815653e8ebc9be001ae236caa.jpg; PDF page 74; full -->

```text
Reading
HOW DOES THE BIOLOGICAL CLOCK TICK?
A Our life span is restricted. Everyone accepts this as 'biologically' obvious.
'Nothing lives for ever!' However, in this statement we think of artificially
produced, technical objects, products which are subjected to natural wear and
tear during use. This leads to the result that at some time or other the object
stops working and is unusable ('death' in the biological sense). But are the
wear and tear and loss of function of technical objects and the death of living
organisms really similar or comparable?
B Our 'dead' products are 'static', closed systems. It is always the basic material
which constitutes the object and which, in the natural course of things, is worn
down and becomes 'older'. Ageing in this case must occur according to the laws
of physical chemistry and of thermodynamics. Although the same law holds
for a living organism, the result of this law is not inexorable in the same way.
At least as long as a biological system has the ability to renew itself it could
actually become older without ageing; an organism is an open, dynamic system
through which new material continuously flows. Destruction of old material
and formation of new material are thus in permanent dynamic equilibrium.
The material of which the organism is formed changes continuously. Thus
our bodies continuously exchange old substance for new, just like a spring
which more or less maintains its form and movement, but in which the water
molecules are always different.
C Thus ageing and death should not be seen as inevitable, particularly as
the organism possesses many mechanisms for repair. It is not, in principle,
necessary for a biological system to age and die. Nevertheless, a restricted life
span, ageing, and then death are basic characteristics of life. The reason for
this is easy to recognise: in nature, the existent organisms either adapt or are
regularly replaced by new types. Because of changes in the genetic material
(mutations) these have new characteristics and in the course of their individual
lives they are tested for optimal or better adaptation to the environmental
conditions. Immortality would disturb this system - it needs room for new and
better life. This is the basic problem of evolution.
D Every organism has a life span which is highly characteristic. There are striking
differences in life span between different species, but within one species the
parameter is relatively constant. For example, the average duration of human
life has hardly changed in thousands of years. Although more and more people
attain an advanced age as a result of developments in medical care and better
nutrition, the characteristic upper limit for most remains 80 years. A further
argument against the simple wear and tear theory is the observation that the
time within which organisms age lies between a few days (even a few hours for
unicellular organisms) and several thousand years, as with mammoth trees.
75
```

[Original question page](assets/87a82e69f7055abfcdf96a5e14737d6f9fb3faa815653e8ebc9be001ae236caa.jpg)

<!-- Source: /api/assets/c36a86957460839ec91607454f3874546681a311627c932142574f45222b219c.jpg; PDF page 75; full -->

```text
Test3
E If a life span is a genetically determined biological characteristic, it is logically
necessary to propose the existence of an internal clock, which in some way
measures and controls the ageing process and which finally determines death
as the last step in a fixed programme. Like the life span, the metabolic rate has
for different organisms a fixed mathematical relationship to the body mass. In
comparison to the life span this relationship is 'inverted': the larger the organism
the lower its metabolic rate. Again this relationship is valid not only for birds,
but also, similarly on average within the systematic unit, for all other organisms
(plants, animals, unicellular organisms).
F Animals which behave 'frugally' with energy become particularly old, for
example, crocodiles and tortoises. Parrots and birds of prey are often held
chained up. Thus they are not able to 'experience life' and so they attain a high
life span in captivity. Animals which save energy by hibernation or lethargy
(e.g. bats or hedgehogs) live much longer than those which are always active.
The metabolic rate of mice can be reduced by a very low consumption of food
(hunger diet). They then may live twice as long as their well fed comrades.
Women become distinctly (about 10 per cent) older than men. If you examine
the metabolic rates of the two sexes you establish that the higher male
metabolic rate roughly accounts for the lower male life span. That means that
they live life 'energetically' - more intensively, but not for as long.
G It follows from the above that sparing use of energy reserves should
tend to extend life. Extreme high performance sports may lead to optimal
cardiovascular performance, but they quite certainly do not prolong life.
Relaxation lowers metabolic rate, as does adequate sleep and in general an
equable and balanced personality. Each of us can develop his or her own
'energy saving programme' with a little self-observation, critical self-control and,
above all, logical consistency. Experience will show that to live in this way not
only increases the life span but is also very healthy. This final aspect should not
be forgotten.
```

[Original question page](assets/c36a86957460839ec91607454f3874546681a311627c932142574f45222b219c.jpg)

<!-- Source: /api/assets/50ade8aef018163f7cff6b8c0c3620512b619f842c8d85ef958ae1c64d706073.jpg; PDF page 76; full -->

```text
Reading
Questions 33-36
Complete the notes below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 33-36 on your answer sheet.
• Objects age in accordance with principles of 33 ........................ and of 34 ....................... .
• Through mutations, organisms can 35 ........................ better to the environment
• 36 ........................ would pose a serious problem for the theory of evolution
Questions 37-40
Do the following statements agree with the views of the writer in Reading Passage 3?
In boxes 37-40 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the views of the writer
if the statement contradicts the views of the writer
if it is impossible to say what the writer thinks about this
37 The wear and tear theory applies to both artificial objects and biological systems.
38 In principle, it is possible for a biological system to become older without ageing.
39 Within seven years, about 90 per cent of a human body is replaced as new.
40 Conserving energy may help to extend a human's life.
77
```

[Original question page](assets/50ade8aef018163f7cff6b8c0c3620512b619f842c8d85ef958ae1c64d706073.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/6826aebb07191609450e56a6d472f855b5b536e11c5cae2fb53cc55ee6299bd6.jpg; PDF page 77; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagrams below show the stages and equipment used in the cement-making process, and how cement is used to produce concrete for building purposes.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/6826aebb07191609450e56a6d472f855b5b536e11c5cae2fb53cc55ee6299bd6.jpg)

![Original figure](assets/6826aebb07191609450e56a6d472f855b5b536e11c5cae2fb53cc55ee6299bd6.jpg)

### Task 2

<!-- Source: /api/assets/34d937c187615817ff2b7bd2bad6721d5803f5d5da192d293a31332776581be1.jpg; PDF page 78; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Increasing the price of petrol is the best way to solve growing traffic and pollution problems.

To what extent do you agree or disagree?

What other measures do you think might be effective?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/34d937c187615817ff2b7bd2bad6721d5803f5d5da192d293a31332776581be1.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/d79f66e0406296cf3fee55d5af4e7bc430a149e0a8c01fca8156c67e7d49851c.jpg; PDF page 79; full -->

```text
Test3
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Flowers
• Do you like to have flowers in your home? [Why/Why not?]
• Where would you go to buy flowers? [Why?]
• On what occasions would you give someone flowers?
• Are flowers important in your culture? [Why/Why not?]
PART 2
Describe a meeting you remember going to at
work, college or school.
You should say:
when and where the meeting was held
who was at the meeting
what the people at the meeting talked
about and explain why you remember going
to this meeting.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to
say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Going to meetings
Example questions:
What are the different types of meeting that people often go to?
Some people say that no-one likes to go to meetings - what do you think?
Why can it sometimes be important to go to meetings?
International meetings
Example questions:
Why do you think world leaders often have meetings together?
What possible difficulties might be involved in organising meetings between world leaders?
Do you think that meetings between international leaders will become more frequent in
the future? Or will there be less need for world leaders to meet?
80
```

[Original question page](assets/d79f66e0406296cf3fee55d5af4e7bc430a149e0a8c01fca8156c67e7d49851c.jpg)

### Part 2

<!-- Source: /api/assets/d79f66e0406296cf3fee55d5af4e7bc430a149e0a8c01fca8156c67e7d49851c.jpg; PDF page 79; full -->

```text
Test3
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Flowers
• Do you like to have flowers in your home? [Why/Why not?]
• Where would you go to buy flowers? [Why?]
• On what occasions would you give someone flowers?
• Are flowers important in your culture? [Why/Why not?]
PART 2
Describe a meeting you remember going to at
work, college or school.
You should say:
when and where the meeting was held
who was at the meeting
what the people at the meeting talked
about and explain why you remember going
to this meeting.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to
say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Going to meetings
Example questions:
What are the different types of meeting that people often go to?
Some people say that no-one likes to go to meetings - what do you think?
Why can it sometimes be important to go to meetings?
International meetings
Example questions:
Why do you think world leaders often have meetings together?
What possible difficulties might be involved in organising meetings between world leaders?
Do you think that meetings between international leaders will become more frequent in
the future? Or will there be less need for world leaders to meet?
80
```

[Original question page](assets/d79f66e0406296cf3fee55d5af4e7bc430a149e0a8c01fca8156c67e7d49851c.jpg)

### Part 3

<!-- Source: /api/assets/d79f66e0406296cf3fee55d5af4e7bc430a149e0a8c01fca8156c67e7d49851c.jpg; PDF page 79; full -->

```text
Test3
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Flowers
• Do you like to have flowers in your home? [Why/Why not?]
• Where would you go to buy flowers? [Why?]
• On what occasions would you give someone flowers?
• Are flowers important in your culture? [Why/Why not?]
PART 2
Describe a meeting you remember going to at
work, college or school.
You should say:
when and where the meeting was held
who was at the meeting
what the people at the meeting talked
about and explain why you remember going
to this meeting.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to
say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Going to meetings
Example questions:
What are the different types of meeting that people often go to?
Some people say that no-one likes to go to meetings - what do you think?
Why can it sometimes be important to go to meetings?
International meetings
Example questions:
Why do you think world leaders often have meetings together?
What possible difficulties might be involved in organising meetings between world leaders?
Do you think that meetings between international leaders will become more frequent in
the future? Or will there be less need for world leaders to meet?
80
```

[Original question page](assets/d79f66e0406296cf3fee55d5af4e7bc430a149e0a8c01fca8156c67e7d49851c.jpg)
