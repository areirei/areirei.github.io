# 剑雅 10 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 144

TEST 1 LISTENING
1 Ardleigh
2 newspaper
3 theme
4 tent
5 castle
6 beach / beaches
7 2020
8 flight
9 429
10 dinner
11 A
12 C
13 health problems
14 safety rules
15 plan
16 joining
17 free entry
18 peak
19 guests
20 photo card / photo cards
21 C
22 A
23 B
24 A
25 C
26 presentation
27 model
28 material / materials
29 grant
30 technical
31 gene
32 power / powers
33 strangers
34 erosion
35 islands
36 roads
37 fishing
38 reproduction
39 method / methods
40 expansion
11–12 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. Ardleigh

2. newspaper

3. theme

4. tent

5. castle

6. beach / beaches

7. 2020

8. flight

9. 429

10. dinner

### Part 2 · source page 144

TEST 1 LISTENING
1 Ardleigh
2 newspaper
3 theme
4 tent
5 castle
6 beach / beaches
7 2020
8 flight
9 429
10 dinner
11 A
12 C
13 health problems
14 safety rules
15 plan
16 joining
17 free entry
18 peak
19 guests
20 photo card / photo cards
21 C
22 A
23 B
24 A
25 C
26 presentation
27 model
28 material / materials
29 grant
30 technical
31 gene
32 power / powers
33 strangers
34 erosion
35 islands
36 roads
37 fishing
38 reproduction
39 method / methods
40 expansion
11–12 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. A / C

12. A / C

13. health problems

14. safety rules

15. plan

16. joining

17. free entry

18. peak

19. guests

20. photo card / photo cards

### Part 3 · source page 144

TEST 1 LISTENING
1 Ardleigh
2 newspaper
3 theme
4 tent
5 castle
6 beach / beaches
7 2020
8 flight
9 429
10 dinner
11 A
12 C
13 health problems
14 safety rules
15 plan
16 joining
17 free entry
18 peak
19 guests
20 photo card / photo cards
21 C
22 A
23 B
24 A
25 C
26 presentation
27 model
28 material / materials
29 grant
30 technical
31 gene
32 power / powers
33 strangers
34 erosion
35 islands
36 roads
37 fishing
38 reproduction
39 method / methods
40 expansion
11–12 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. C

22. A

23. B

24. A

25. C

26. presentation

27. model

28. material / materials

29. grant

30. technical

### Part 4 · source page 144

TEST 1 LISTENING
1 Ardleigh
2 newspaper
3 theme
4 tent
5 castle
6 beach / beaches
7 2020
8 flight
9 429
10 dinner
11 A
12 C
13 health problems
14 safety rules
15 plan
16 joining
17 free entry
18 peak
19 guests
20 photo card / photo cards
21 C
22 A
23 B
24 A
25 C
26 presentation
27 model
28 material / materials
29 grant
30 technical
31 gene
32 power / powers
33 strangers
34 erosion
35 islands
36 roads
37 fishing
38 reproduction
39 method / methods
40 expansion
11–12 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. gene

32. power / powers

33. strangers

34. erosion

35. islands

36. roads

37. fishing

38. reproduction

39. method / methods

40. expansion

## A 类阅读

### Academic Reading · source page 145

ACADEMIC READING
1 FALSE
2 TRUE
3 NOT GIVEN
4 NOT GIVEN
5 TRUE
6 pavilions
7 drought
8 tourists
9 earthquake
10 4 / four sides
11 tank
12 verandas / verandahs
13 underwater
14 viii
15 iii
16 xi
17 i
18 v
19 x
20 ii
21 iv
22 TRUE
23 FALSE
24 NOT GIVEN
25 NOT GIVEN
26 FALSE
27 C
28 A
29 D
30 B
31 G
32 E
33 A
34 F
35 B
36 NO
37 YES
38 NOT GIVEN
39 NOT GIVEN
40 NO
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. FALSE

2. TRUE

3. NOT GIVEN

4. NOT GIVEN

5. TRUE

6. pavilions

7. drought

8. tourists

9. earthquake

10. 4 sides / four sides

11. tank

12. verandas / verandahs

13. underwater

14. viii

15. iii

16. xi

17. i

18. v

19. x

20. ii

21. iv

22. TRUE

23. FALSE

24. NOT GIVEN

25. NOT GIVEN

26. FALSE

27. C

28. A

29. D

30. B

31. G

32. E

33. A

34. F

35. B

36. NO

37. YES

38. NOT GIVEN

39. NOT GIVEN

40. NO

## A 类写作

### Writing material: c10-t1-w-1

Average Australian household, shares of energy use versus shares of greenhouse gas emissions respectively: heating42/15%, water heating30/32%, refrigeration7/14%, other appliances15/28%, lighting4/8%, cooling2/3%. Each chart totals100%. Heating dominates energy use; water heating leads emissions. Refrigeration and lighting emissions shares are double their energy shares; other appliances nearly double. These are two different denominators, not absolute quantities or emission rates. Do not call heating plus water heating one category or infer the national totals.



### Writing material: c10-t1-w-2

Address the necessity of punishment and which punishments parents and teachers should be allowed to use. Both questions matter, including a justified alternative view if rejecting punishment. Do not presume physical punishment is required.



## 口语
