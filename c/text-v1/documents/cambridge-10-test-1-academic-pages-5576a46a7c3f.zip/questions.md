# 剑雅 10 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/950f2effa63e99682bc4fd31a82dfe027144456830cdd10872c0d7d7b1c78d4e.jpg; PDF page 3; full -->

```text
SECTION 1 Questions 1–10
Questions 1–6
Complete the notes below. Write ONE WORD for each answer.
SELF-DRIVE TOURS IN THE USA
Example — Name: Andrea Brown
Address: 24 (1) __________ Road
Postcode: BH5 2OP
Phone: (mobile) 077 8664 3091
Heard about company from: (2) __________
Possible self-drive tours
Trip One:
– Los Angeles: customer wants to visit some (3) __________ parks with her children
– Yosemite Park: customer wants to stay in a lodge, not a (4) __________
Trip Two:
– Customer wants to see the (5) __________ on the way to Cambria
– At Santa Monica: not interested in shopping
– At San Diego, wants to spend time on the (6) __________
```

[Original question page](assets/950f2effa63e99682bc4fd31a82dfe027144456830cdd10872c0d7d7b1c78d4e.jpg)

<!-- Source: /api/assets/cd9896356d8a52b329b65501f121546f51d32ebe67e274cbebb35c23d89566ec.jpg; PDF page 4; full -->

```text
Questions 7–10
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
| Trip | Number of days | Total distance | Price (per person) | Includes |
| --- | --- | --- | --- | --- |
| Trip One | 12 days | (7) __________ km | £525 | accommodation; car; one (8) __________ |
| Trip Two | 9 days | 980 km | (9) £__________ | accommodation; car; (10) __________ |
```

[Original question page](assets/cd9896356d8a52b329b65501f121546f51d32ebe67e274cbebb35c23d89566ec.jpg)

### Part 2

<!-- Source: /api/assets/989218cbe53fe76c83f077ebdb599e143a309e3269b8ffa2f36c4863727b2a3e.jpg; PDF page 5; full -->

```text
SECTION 2 Questions 11–20
Questions 11–12
Choose TWO letters A–E.
Which TWO facilities at the leisure club have recently been improved?
A the gym
B the tracks
C the indoor pool
D the outdoor pool
E the sports training for children
```

[Original question page](assets/989218cbe53fe76c83f077ebdb599e143a309e3269b8ffa2f36c4863727b2a3e.jpg)

<!-- Source: /api/assets/accfc3b230a9c48a30a0d2da26d5feab67d81eb1e3ab0f9933a5db745d8c039c.jpg; PDF page 6; full -->

```text
Questions 13–20
Complete the notes below. Write NO MORE THAN TWO WORDS for each answer.
Joining the leisure club
Personal Assessment
– New members should describe any (13) __________.
– The (14) __________ will be explained to you before you use the equipment.
– You will be given a six-week (15) __________.
Types of membership
– There is a compulsory £90 (16) __________ fee for members.
– Gold members are given (17) __________ to all the LP clubs.
– Premier members are given priority during (18) __________ hours.
– Premier members can bring some (19) __________ every month.
– Members should always take their (20) __________ with them.
```

[Original question page](assets/accfc3b230a9c48a30a0d2da26d5feab67d81eb1e3ab0f9933a5db745d8c039c.jpg)

### Part 3

<!-- Source: /api/assets/41ccfae155150ee4e81eee2ce2814ffdea0a13f2586acf7f3f32dd5c95c20959.jpg; PDF page 7; full -->

```text
Test 1
SECTION 3 Questions 21–30
Questions 21–25
Choose the correct letter,
 A, B
or
 C.
Global Design Competition
21 Students entering the design competition have to
A produce an energy-efficient design.
B adapt an existing energy-saving appliance.
C develop a new use for current technology.
22 John chose a dishwasher because he wanted to make dishwashers
A more appealing.
B more common.
C more economical.
23 The stone in John’s ‘Rockpool’ design is used
A for decoration.
B to switch it on.
C to stop water escaping.
24 In the holding chamber, the carbon dioxide
A changes back to a gas.
B dries the dishes.
C is allowed to cool.
25 At the end of the cleaning process, the carbon dioxide
A is released into the air.
B is disposed of with the waste.
C is collected ready to be re-used.

14
```

[Original question page](assets/41ccfae155150ee4e81eee2ce2814ffdea0a13f2586acf7f3f32dd5c95c20959.jpg)

<!-- Source: /api/assets/9f785e16b764a2ce46e877f25bb9e6b0c12cce23b8b8a2ebcddf53db40c90793.jpg; PDF page 8; full -->

```text
Questions 26–30
Complete the notes below. Write ONE WORD ONLY for each answer.
– John needs help preparing for his (26) __________.
– The professor advises John to make a (27) __________ of his design.
– John’s main problem is getting good quality (28) __________.
– The professor suggests John apply for a (29) __________.
– The professor will check the (30) __________ information in John’s written report.
```

[Original question page](assets/9f785e16b764a2ce46e877f25bb9e6b0c12cce23b8b8a2ebcddf53db40c90793.jpg)

### Part 4

<!-- Source: /api/assets/deca60e21d16880e32690970464dbc341bca946f9a565f30d33ade3f9a46f6b0.jpg; PDF page 9; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
THE SPIRIT BEAR
General facts
– It is a white bear belonging to the black bear family.
– Its colour comes from an uncommon (31) __________.
– Local people believe that it has unusual (32) __________.
– They protect the bear from (33) __________.
Habitat
– The bear’s relationship with the forest is complex.
– Tree roots stop (34) __________ along salmon streams.
– The bears’ feeding habits provide nutrients for forest vegetation.
– It is currently found on a small number of (35) __________.
Threats
– Habitat is being lost due to deforestation and construction of (36) __________ by logging companies.
– Unrestricted (37) __________ is affecting the salmon supply.
– The bears’ existence is also threatened by their low rate of (38) __________.
Going forward
– Interested parties are working together.
– Logging companies must improve their (39) __________ of logging.
– Maintenance and (40) __________ of the spirit bears’ territory is needed.
```

[Original question page](assets/deca60e21d16880e32690970464dbc341bca946f9a565f30d33ade3f9a46f6b0.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/6a9e96ffb5a49d07455387f1ac2c8e46aa209b545fb9cf799b02486a78e2c0ca.jpg; PDF page 10; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on
Reading Passage 1 below.
Stepwells
A millennium ago, stepwells were fundamental to life in the driest
parts of India. Richard Cox travelled to north-western India to
document these spectacular monuments from a bygone era

During the sixth and seventh centuries,
the inhabitants of the modern-day
states of Gujarat and Rajasthan in
north-western India developed a
method of gaining access to clean, fresh
groundwater during the dry season for
drinking, bathing, watering animals and
irrigation. However, the significance
of this invention — the stepwell — goes
beyond its utilitarian application.
Unique to this region, stepwells are
often architecturally complex and vary
widely in size and shape. During their
heyday, they were places of gathering,
of leisure and relaxation and of worship
for villagers of all but the lowest classes.
Most stepwells are found dotted round
the desert areas of Gujarat (where they
are called vav) and Rajasthan (where
they are called baori), while a few also
survive in Delhi. Some were located in
or near villages as public spaces for the
community; others were positioned beside
roads as resting places for travellers.
As their name suggests, stepwells
comprise a series of stone steps
descending from ground level to the
water source (normally an underground
aquifer) as it recedes following the rains.
When the water level was high, the user
needed only to descend a few steps to
reach it; when it was low, several levels
would have to be negotiated.
Some wells are vast, open craters with
hundreds of steps paving each sloping
side, often in tiers. Others are more
elaborate, with long stepped passages
leading to the water via several storeys.
Built from stone and supported by pillars,
they also included pavilions that sheltered
visitors from the relentless heat. But
perhaps the most impressive features
are the intricate decorative sculptures
that embellish many stepwells, showing
activities from fighting and dancing to
everyday acts such as women combing
their hair or churning butter.
Down the centuries, thousands of wells
were constructed throughout north-
western India, but the majority have now
fallen into disuse; many are derelict and
dry, as groundwater has been diverted
for industrial use and the wells no longer
reach the water table. Their condition
17
```

[Original question page](assets/6a9e96ffb5a49d07455387f1ac2c8e46aa209b545fb9cf799b02486a78e2c0ca.jpg)

<!-- Source: /api/assets/4eb60b2f37281a25dde0c25d5b7957de7e3348d58cf57217ad40a450424d0ee6.jpg; PDF page 11; full -->

```text
Test 1
hasn't been helped by recent dry spells:
southern Rajasthan suffered an eight-year
drought between 1996 and 2004.
However, some important sites in
Gujarat have recently undergone major
restoration, and the state government
announced in June last year that it plans
to restore the stepwells throughout the
state.
In Patan, the state’s ancient capital, the
stepwell of Rani Ki Vav (Queen’s Stepwell)
is perhaps the finest current example.
It was built by Queen Udayamati during
the late 11th century, but became silted
up following a flood during the 13th
century. But the Archaeological Survey
of India began restoring it in the 1960s,
and today it is in pristine condition. At
65 metres long, 20 metres wide and 27
metres deep, Rani Ki Vav features 500
sculptures carved into niches throughout
the monument. Incredibly, in January
2001, this ancient structure survived an
earthquake that measured 7.6 on the
Richter scale.
Another example is the Surya Kund in
Modhera, northern Gujarat, next to the
Sun Temple, built by King Bhima I in 1026
to honour the sun god Surya. It actually
resembles a tank (kund means reservoir
or pond) rather than a well, but displays
the hallmarks of stepwell architecture,
including four sides of steps that descend
to the bottom in a stunning geometrical
formation. The terraces house 108 small,
intricately carved shrines between the
sets of steps.
Rajasthan also has a wealth of wells.
The ancient city of Bundi, 200 kilometres
south of Jaipur, is renowned for its
architecture, including its stepwells.
One of the larger examples is Raniji Ki
Baori, which was built by the queen of the
region, Nathavatji, in 1699. At 46 metres
deep, 20 metres wide and 40 metres long,
the intricately carved monument is one of
21 baoris commissioned in the Bundi area
by Nathavatji.
In the old ruined town of Abhaneri, about
95 kilometres east of Jaipur, is Chand
Baori, one of India’s oldest and deepest
wells; aesthetically it’s perhaps one of the
most dramatic. Built in around 850 AD
next to the temple of Harshat Mata, the
baori comprises hundreds of zigzagging
steps that run along three of its sides,
steeply descending 11 storeys, resulting
in a striking pattern when seen from afar.
On the fourth side, verandas which are
supported by ornate pillars overlook the
steps.
Still in public use is Neemrana Ki Baori,
located just off the Jaipur—Delhi highway.
Constructed in around 1700, it is nine
storeys deep, with the last two being
underwater. At ground level, there are
86 colonnaded openings from where the
visitor descends 170 steps to the deepest
water source.
Today, following years of neglect, many of
these monuments to medieval engineering
have been saved by the Archaeological
Survey of India, which has recognised the
importance of preserving them as part of
the country’s rich history. Tourists flock
to wells in far-flung corners of north-
western India to gaze in wonder at these
architectural marvels from hundreds of
years ago, which serve as a reminder of
both the ingenuity and artistry of ancient
civilisations and of the value of water to
human existence.
```

[Original question page](assets/4eb60b2f37281a25dde0c25d5b7957de7e3348d58cf57217ad40a450424d0ee6.jpg)

<!-- Source: /api/assets/1978130b2b332ca119a4b0e55cbff8774b2573417b9f56cee8d419773ce7d2fa.jpg; PDF page 12; full -->

```text
Questions 1–5
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1–5 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 Examples of ancient stepwells can be found all over the world.
2 Stepwells had a range of functions, in addition to those related to water collection.
3 The few existing stepwells in Delhi are more attractive than those found elsewhere.
4 It took workers many years to build the stone steps characteristic of stepwells.
5 The number of steps above the water level in a stepwell altered during the course of a year.
Questions 6–8
Answer the questions below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 6–8 on your answer sheet.
6 Which part of some stepwells provided shade for people?
7 What type of serious climatic event, which took place in southern Rajasthan, is mentioned in the article?
8 Who are frequent visitors to stepwells nowadays?
```

[Original question page](assets/1978130b2b332ca119a4b0e55cbff8774b2573417b9f56cee8d419773ce7d2fa.jpg)

<!-- Source: /api/assets/4ed587c1bc4f9289764f101877c89ed5c543f60c4c88dd62f0def5ff2e835096.jpg; PDF page 13; full -->

```text
Questions 9–13
Complete the table below. Choose ONE WORD AND/OR A NUMBER from the passage for each answer.
Write your answers in boxes 9–13 on your answer sheet.
| Stepwell | Date | Features | Other notes |
| --- | --- | --- | --- |
| Rani Ki Vav | Late 11th century | As many as 500 sculptures decorate the monument | Restored in the 1960s; Excellent condition, despite the (9) __________ of 2001 |
| Surya Kund | 1026 | Steps on the (10) __________ produce a geometrical pattern; Carved shrines | Looks more like a (11) __________ than a well |
| Raniji Ki Baori | 1699 | Intricately carved monument | One of 21 baoris in the area commissioned by Queen Nathavatji |
| Chand Baori | 850 AD | Steps take you down 11 storeys to the bottom | Old, deep and very dramatic; Has (12) __________ which provide a view of the steps |
| Neemrana Ki Baori | 1700 | Has two (13) __________ levels | Used by public today |
```

[Original question page](assets/4ed587c1bc4f9289764f101877c89ed5c543f60c4c88dd62f0def5ff2e835096.jpg)

<!-- Source: /api/assets/c2f4ecf72adbb4e1bc116abf9281f77f53c88cc88cf97cc767063c145b5f0a69.jpg; PDF page 14; full -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14–26, which are based on Reading Passage 2 on the following pages.
Questions 14–21
Reading Passage 2 has nine paragraphs, A–I.
Choose the correct heading for paragraphs A–E and G–I from the list of headings below.
Write the correct number, i–xi, in boxes 14–21 on your answer sheet.
List of Headings
i A fresh and important long-term goal
ii Charging for roads and improving other transport methods
iii Changes affecting the distances goods may be transported
iv Taking all the steps necessary to change transport patterns
v The environmental costs of road transport
vi The escalating cost of rail transport
vii The need to achieve transport rebalance
viii The rapid growth of private transport
ix Plans to develop major road networks
x Restricting road use through charging policies alone
xi Transport trends in countries awaiting EU admission
14 Paragraph A
15 Paragraph B
16 Paragraph C
17 Paragraph D
18 Paragraph E
19 Paragraph G
20 Paragraph H
21 Paragraph I
Example — Paragraph F: vii
```

[Original question page](assets/c2f4ecf72adbb4e1bc116abf9281f77f53c88cc88cf97cc767063c145b5f0a69.jpg)

<!-- Source: /api/assets/f7b7e376fa96d8d5455f454c96ce435f662139c01142e34f05a1813fdf2601ad.jpg; PDF page 15; full -->

```text
Test 1
EUROPEAN TRANSPORT SYSTEMS 1990–2010
What have been the trends and what are the prospects for
European transport systems?
A It is difficult to conceive of vigorous economic growth without an efficient transport
system. Although modern information technologies can reduce the demand for physical
transport by facilitating teleworking and teleservices, the requirement for transport
continues to increase. There are two key factors behind this trend. For passenger
transport, the determining factor is the spectacular growth in car use. The number
of cars on European Union (EU) roads saw an increase of three million cars each year
from 1990 to 2010, and in the next decade the EU will see a further substantial
increase in its fleet.
B As far as goods transport is concerned, growth is due to a large extent to changes in
the European economy and its system of production. In the last 20 years, as internal
frontiers have been abolished, the EU has moved from a ‘stock’ economy to a ‘flow’
economy. This phenomenon has been emphasised by the relocation of some industries,
particularly those which are labour intensive, to reduce production costs, even though
the production site is hundreds or even thousands of kilometres away from the final
assembly plant or away from users.
C The strong economic growth expected in countries which are candidates for entry to
the EU will also increase transport flows, in particular road haulage traffic. In 1998,
some of these countries already exported more than twice their 1990 volumes and
imported more than five times their 1990 volumes. And although many candidate
countries inherited a transport system which encourages rail, the distribution between
modes has tipped sharply in favour of road transport since the 1990s. Between
1990 and 1998, road haulage increased by 19.4%, while during the same period rail
haulage decreased by 43.5%, although -  and this could benefit the enlarged EU –  it is
still on average at a much higher level than in existing member states.
D However, a new imperative -  sustainable development -  offers an opportunity for
adapting the EU’s common transport policy. This objective, agreed by the Gothenburg
European Council, has to be achieved by integrating environmental considerations
into Community policies, and shifting the balance between modes of transport lies at
the heart of its strategy. The ambitious objective can only be fully achieved by 2020,
but proposed measures are nonetheless a first essential step towards a sustainable
transport system which will ideally be in place in 30 years’ time, that is by 2040.
22
```

[Original question page](assets/f7b7e376fa96d8d5455f454c96ce435f662139c01142e34f05a1813fdf2601ad.jpg)

<!-- Source: /api/assets/e18359f0633799a07540d14d2c0da6b347798ea96156a1ee279e301652be166f.jpg; PDF page 16; full -->

```text
Reading
E In 1998,
energy consumption in the transport sector was to blame for 28% of
emissions of CO₂, the leading greenhouse gas. According to the latest estimates, if
nothing is done to reverse the traffic growth trend, CO₂  emissions from transport can
be expected to increase by around 50% to 1,113 billion tonnes by 2020, compared
with the 739 billion tonnes recorded in 1990. Once again, road transport is the main
culprit since it alone accounts for 84% of the CO₂  emissions attributable to transport.
Using alternative fuels and improving energy efficiency is thus both an ecological
necessity and a technological challenge.
F At the same time greater efforts must be made to achieve a modal shift. Such a
change cannot be achieved overnight, all the less so after over half a century of
constant deterioration in favour of road. This has reached such a pitch that today rail
freight services are facing marginalisation, with just 8% of market share, and with
international goods trains struggling along at an average speed of 18km/h. Three
possible options have emerged.
G The first approach would consist of focusing on road transport solely through pricing.
This option would not be accompanied by complementary measures in the other modes
of transport. In the short term it might curb the growth in road transport through
the better loading ratio of goods vehicles and occupancy rates of passenger vehicles
expected as a result of the increase in the price of transport. However, the lack of
measures available to revitalise other modes of transport would make it impossible for
more sustainable modes of transport to take up the baton.
H The second approach also concentrates on road transport pricing but is accompanied
by measures to increase the efficiency of the other modes (better quality of services,
logistics, technology). However, this approach does not include investment in new
infrastructure, nor does it guarantee better regional cohesion. It could help to achieve
greater uncoupling than the first approach, but road transport would keep the lion’s
share of the market and continue to concentrate on saturated arteries, despite being
the most polluting of the modes. It is therefore not enough to guarantee the necessary
shift of the balance.
I The third approach, which is not new, comprises a series of measures ranging from
pricing to revitalising alternative modes of transport and targeting investment in the
trans-European network. This integrated approach would allow the market shares of
the other modes to return to their 1998 levels and thus make a shift of balance. It is
far more ambitious than it looks, bearing in mind the historical imbalance in favour of
roads for the last fifty years, but would achieve a marked break in the link between road
transport growth and economic growth, without placing restrictions on the mobility of
people and goods.
23
```

[Original question page](assets/e18359f0633799a07540d14d2c0da6b347798ea96156a1ee279e301652be166f.jpg)

<!-- Source: /api/assets/0b52fcb5ca3117d2359840cd89fdc64c44962e9d2e9ad2ade7d92176c1782bda.jpg; PDF page 17; full -->

```text
Questions 22–26
Do the following statements agree with the information given in Reading Passage 2?
In boxes 22–26 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
22 The need for transport is growing, despite technological developments.
23 To reduce production costs, some industries have been moved closer to their relevant consumers.
24 Cars are prohibitively expensive in some EU candidate countries.
25 The Gothenburg European Council was set up 30 years ago.
26 By the end of this decade, CO₂ emissions from transport are predicted to reach 739 billion tonnes.
```

[Original question page](assets/0b52fcb5ca3117d2359840cd89fdc64c44962e9d2e9ad2ade7d92176c1782bda.jpg)

<!-- Source: /api/assets/c72b8f338874166e9110e31585cd6d4d455c059de1046d114c7b5a377a08a58e.jpg; PDF page 18; full -->

```text
READING PASSAGE 3
Reading
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
The psychology of innovation
Why are so few companies truly innovative?
Innovation is key to business survival, and
companies put substantial resources into
inspiring employees to develop new ideas.
There are, nevertheless, people working in
luxurious, state-of-the-art centres designed
to stimulate innovation who find that their
environment doesn’t make them feel at all
creative. And there are those who don’t
have a budget, or much space, but who
innovate successfully.
For Robert B. Cialdini, Professor of
Psychology at Arizona State University,
one reason that companies don’t succeed
as often as they should is that innovation
starts with recruitment. Research shows
that the fit between an employee’s values
and a company’s values makes a difference
to what contribution they make and
whether, two years after they join, they’re
still at the company. Studies at Harvard
Business School show that, although some
individuals may be more creative than
others, almost every individual can be
creative in the right circumstances.
One of the most famous photographs in the
story of rock’n’roll emphasises Cialdini’s
views. The 1956 picture of singers Elvis
Presley, Carl Perkins, Johnny Cash and
Jerry Lee Lewis jamming at a piano in Sun
Studios in Memphis tells a hidden story.
Sun’s ‘million-dollar quartet’ could have
been a quintet. Missing from the picture
is Roy Orbison, a greater natural singer
than Lewis, Perkins or Cash. Sam Phillips,
who owned Sun, wanted to revolutionise
popular music with songs that fused
black and white music, and country and
blues. Presley, Cash, Perkins and Lewis
instinctively understood Phillips’s ambition
and believed in it. Orbison wasn’t inspired
by the goal, and only ever achieved one hit
with the Sun label.
The value fit matters, says Cialdini,
because innovation is, in part, a process
of change, and under that pressure we,
as a species, behave differently, ‘When
things change, we are hard-wired to
play it safe.’ Managers should therefore
adopt an approach that appears counter-
intuitive — they should explain what stands
to be lost if the company fails to seize a
particular opportunity. Studies show that
we invariably take more gambles when
threatened with a loss than when offered a
reward.
Managing innovation is a delicate art.
It’s easy for a company to be pulled in
conflicting directions as the marketing,
product development, and finance
departments each get different feedback
from different sets of people. And without
a system which ensures collaborative
exchanges within the company, it’s also
easy for small ‘pockets of innovation’ to
disappear. Innovation is a contact sport.
You can’t brief people just by saying, ‘We’re
going in this direction and I’m going to take
you with me.’
25
```

[Original question page](assets/c72b8f338874166e9110e31585cd6d4d455c059de1046d114c7b5a377a08a58e.jpg)

<!-- Source: /api/assets/1df207578740c8729236a0c8ddfce7de8176b1e206e14614ad6e6b69451b4e52.jpg; PDF page 19; full -->

```text
Test 1
Cialdini believes that this ‘follow-the-
leader syndrome’ is dangerous, not least
because it encourages bosses to go it
alone. ‘It's been scientifically proven that
three people will be better than one at
solving problems, even if that one person
is the smartest person in the field.’ To
prove his point, Cialdini cites an interview
with molecular biologist James Watson.
Watson, together with Francis Crick,
discovered the structure of DNA, the
genetic information carrier of all living
organisms. ‘When asked how they had
cracked the code ahead of an array of
highly accomplished rival investigators, he
said something that stunned me. He said
he and Crick had succeeded because they
were aware that they weren't the most
intelligent of the scientists pursuing the
answer. The smartest scientist was called
Rosalind Franklin who, Watson said, “was
so intelligent she rarely sought advice”.’
Teamwork taps into one of the basic
drivers of human behaviour. ‘The principle
of social proof is so pervasive that we don't
even recognise it,’ says Cialdini. ‘If your
project is being resisted, for example, by a
group of veteran employees, ask another
old-timer to speak up for it.’ Cialdini is not
alone in advocating this strategy. Research
shows that peer power, used horizontally
not vertically, is much more powerful than
any boss's speech.
Writing, visualising and prototyping can
stimulate the flow of new ideas. Cialdini
cites scores of research papers and
historical events that prove that even
something as simple as writing deepens
every individual’s engagement in the
project. It is, he says, the reason why all
those competitions on breakfast cereal
packets encouraged us to write in saying,
in no more than 10 words: ‘I like Kellogg's
Corn Flakes because... .’ The very act of
writing makes us more likely to believe it.
Authority doesn’t have to inhibit innovation
but it often does. The wrong kind of
leadership will lead to what Cialdini calls
‘captainitis, the regrettable tendency
of team members to opt out of team
responsibilities that are properly theirs’. He
calls it captainitis because, he says, ‘crew
members of multipilot aircraft exhibit a
sometimes deadly passivity when the flight
captain makes a clearly wrong-headed
decision’. This behaviour is not, he says,
unique to air travel, but can happen in any
workplace where the leader is overbearing.
At the other end of the scale is the 1980s
Memphis design collective, a group of
young designers for whom ‘the only
rule was that there were no rules’. This
environment encouraged a free interchange
of ideas, which led to more creativity with
form, function, colour and materials that
revolutionised attitudes to furniture design.
Many theorists believe the ideal boss
should lead from behind, taking pride in
collective accomplishment and giving
credit where it is due. Cialdini says:
‘Leaders should encourage everyone to
contribute and simultaneously assure all
concerned that every recommendation is
important to making the right decision and
will be given full attention.’ The frustrating
thing about innovation is that there are
many approaches, but no magic formula.
However, a manager who wants to create
a truly innovative culture can make their
job a lot easier by recognising these
psychological realities.
```

[Original question page](assets/1df207578740c8729236a0c8ddfce7de8176b1e206e14614ad6e6b69451b4e52.jpg)

<!-- Source: /api/assets/d3dbc90ac2683fcb34d4dfbd1d71c82816168f8d47094b89a81021baa6c0be14.jpg; PDF page 20; full -->

```text
Questions 27–30
Choose the correct letter, A, B, C or D. Write the correct letter in boxes 27–30 on your answer sheet.
27 The example of the ‘million-dollar quartet’ underlines the writer’s point about
A recognising talent.
B working as a team.
C having a shared objective.
D being an effective leader.
28 James Watson suggests that he and Francis Crick won the race to discover the DNA code because they
A were conscious of their own limitations.
B brought complementary skills to their partnership.
C were determined to outperform their brighter rivals.
D encouraged each other to realise their joint ambition.
29 The writer mentions competitions on breakfast cereal packets as an example of how to
A inspire creative thinking.
B generate concise writing.
C promote loyalty to a group.
D strengthen commitment to an idea.
30 In the last paragraph, the writer suggests that it is important for employees to
A be aware of their company’s goals.
B feel that their contributions are valued.
C have respect for their co-workers’ achievements.
D understand why certain management decisions are made.
```

[Original question page](assets/d3dbc90ac2683fcb34d4dfbd1d71c82816168f8d47094b89a81021baa6c0be14.jpg)

<!-- Source: /api/assets/24da308cfbdbaa0904808b8b1a477cdf4cf0f759fa7d2d66857abaf55e330029.jpg; PDF page 21; full -->

```text
Questions 31–35
Complete each sentence with the correct ending, A–G, below.
Write the correct letter, A–G, in boxes 31–35 on your answer sheet.
31 Employees whose values match those of their employers are more likely to
32 At times of change, people tend to
33 If people are aware of what they might lose, they will often
34 People working under a dominant boss are liable to
35 Employees working in organisations with few rules are more likely to
A take chances.
B share their ideas.
C become competitive.
D get promotion.
E avoid risk.
F ignore their duties.
G remain in their jobs.
```

[Original question page](assets/24da308cfbdbaa0904808b8b1a477cdf4cf0f759fa7d2d66857abaf55e330029.jpg)

<!-- Source: /api/assets/f38eca4c36cf148deab387bca8c3a1b53b3c0d747840b2dde2f2d22f459a5eb3.jpg; PDF page 22; full -->

```text
Questions 36-40
Do the following statements agree with the claims of the writer in Reading Passage 3?
Reading
In boxes 36-40 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
36 The physical surroundings in which a person works play a key role in determining
their creativity.
37 Most people have the potential to be creative.
38 Teams work best when their members are of equally matched intelligence.
39 It is easier for smaller companies to be innovative.
40 A manager’s approval of an idea is more persuasive than that of a colleague.
```

[Original question page](assets/f38eca4c36cf148deab387bca8c3a1b53b3c0d747840b2dde2f2d22f459a5eb3.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/0bb75dfd8cbcd5e1790fb85ef48ffa558f234fc55e71ec8a503d3918402ce2bb.jpg; PDF page 23; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The first chart below shows how energy is used in an average Australian household. The second chart shows the greenhouse gas emissions which result from this energy.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/0bb75dfd8cbcd5e1790fb85ef48ffa558f234fc55e71ec8a503d3918402ce2bb.jpg)

![Original figure](assets/0bb75dfd8cbcd5e1790fb85ef48ffa558f234fc55e71ec8a503d3918402ce2bb.jpg)

### Task 2

<!-- Source: /api/assets/ff6b5e152847406516db3f9cf72157085871201d4f92912cf6cd3474b4707201.jpg; PDF page 24; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic.

It is important for children to learn the difference between right and wrong at an early age. Punishment is necessary to help them learn this distinction.

To what extent do you agree or disagree with this opinion?

What sort of punishment should parents and teachers be allowed to use to teach good behaviour to children?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/ff6b5e152847406516db3f9cf72157085871201d4f92912cf6cd3474b4707201.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/0308fa57ae325a25d9282a0331c8603f5d362642029a9ce811177d039015d098.jpg; PDF page 25; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Weekends
• How do you usually spend your weekends? [Why?]
• Which is your favourite part of the weekend? [Why?]
• Do you think your weekends are long enough? [Why/Why not?]
• How important do you think it is to have free time at the weekends? [Why?]
PART 2
Describe someone you know who does something well.
You should say:
who this person is
how you know this person
what they do well
and explain why you think this person is so good at doing this.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Skills and abilities
Example questions:
What skills and abilities do people most want to have today? Why?
Which skills should children learn at school? Are there any skills which they should learn
at home? What are they?
Which skills do you think will be important in the future? Why?
Salaries for skilled people
Example questions:
Which kinds of jobs have the highest salaries in your country? Why is this?
Are there any other jobs that you think should have high salaries? Why do you think that?
Some people say it would be better for society if everyone got the same salary. What do
you think about that? Why?
32
```

[Original question page](assets/0308fa57ae325a25d9282a0331c8603f5d362642029a9ce811177d039015d098.jpg)

### Part 2

<!-- Source: /api/assets/0308fa57ae325a25d9282a0331c8603f5d362642029a9ce811177d039015d098.jpg; PDF page 25; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Weekends
• How do you usually spend your weekends? [Why?]
• Which is your favourite part of the weekend? [Why?]
• Do you think your weekends are long enough? [Why/Why not?]
• How important do you think it is to have free time at the weekends? [Why?]
PART 2
Describe someone you know who does something well.
You should say:
who this person is
how you know this person
what they do well
and explain why you think this person is so good at doing this.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Skills and abilities
Example questions:
What skills and abilities do people most want to have today? Why?
Which skills should children learn at school? Are there any skills which they should learn
at home? What are they?
Which skills do you think will be important in the future? Why?
Salaries for skilled people
Example questions:
Which kinds of jobs have the highest salaries in your country? Why is this?
Are there any other jobs that you think should have high salaries? Why do you think that?
Some people say it would be better for society if everyone got the same salary. What do
you think about that? Why?
32
```

[Original question page](assets/0308fa57ae325a25d9282a0331c8603f5d362642029a9ce811177d039015d098.jpg)

### Part 3

<!-- Source: /api/assets/0308fa57ae325a25d9282a0331c8603f5d362642029a9ce811177d039015d098.jpg; PDF page 25; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Weekends
• How do you usually spend your weekends? [Why?]
• Which is your favourite part of the weekend? [Why?]
• Do you think your weekends are long enough? [Why/Why not?]
• How important do you think it is to have free time at the weekends? [Why?]
PART 2
Describe someone you know who does something well.
You should say:
who this person is
how you know this person
what they do well
and explain why you think this person is so good at doing this.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Skills and abilities
Example questions:
What skills and abilities do people most want to have today? Why?
Which skills should children learn at school? Are there any skills which they should learn
at home? What are they?
Which skills do you think will be important in the future? Why?
Salaries for skilled people
Example questions:
Which kinds of jobs have the highest salaries in your country? Why is this?
Are there any other jobs that you think should have high salaries? Why do you think that?
Some people say it would be better for society if everyone got the same salary. What do
you think about that? Why?
32
```

[Original question page](assets/0308fa57ae325a25d9282a0331c8603f5d362642029a9ce811177d039015d098.jpg)
