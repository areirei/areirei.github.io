# 剑雅 5 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 157

TEST3 LISTENING
Section1, Questions1–10
1 1.4litres /1.4liters
2 automatic
3 light / sky
4 credit
5 Harries
6 Dr / Doctor
7 Alton
8 messages
9 Lion
10 reasonable
Section2, Questions11–20
11–12 IN EITHER ORDER: C;E
13 references
14 country
15 weather
16 C
17 C
18 A
19 B
20 C
Section3, Questions21–30
21 5th May
22 16th July / Friday16th July
23 clear / was clear
24 (an/the)outline / (a/the)course outline
25 (the)2nd half
26 (standard of)teaching / (standard of)teachers
27 discussion / group discussion
28 handouts
29 written work
30 student support / support for students
Section4, Questions31–40
31 12.5%
32 incineration plants
33 drop-off
34 cooking
35 500,000
36 roads
37 soil conditioner
38 containers
39 pencils
40 business cards
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. 1.4 litres / 1.4 liters

2. automatic

3. light / sky

4. credit

5. Harries

6. Dr / Doctor

7. Alton

8. messages

9. Lion

10. reasonable

### Part 2 · source page 157

TEST3 LISTENING
Section1, Questions1–10
1 1.4litres /1.4liters
2 automatic
3 light / sky
4 credit
5 Harries
6 Dr / Doctor
7 Alton
8 messages
9 Lion
10 reasonable
Section2, Questions11–20
11–12 IN EITHER ORDER: C;E
13 references
14 country
15 weather
16 C
17 C
18 A
19 B
20 C
Section3, Questions21–30
21 5th May
22 16th July / Friday16th July
23 clear / was clear
24 (an/the)outline / (a/the)course outline
25 (the)2nd half
26 (standard of)teaching / (standard of)teachers
27 discussion / group discussion
28 handouts
29 written work
30 student support / support for students
Section4, Questions31–40
31 12.5%
32 incineration plants
33 drop-off
34 cooking
35 500,000
36 roads
37 soil conditioner
38 containers
39 pencils
40 business cards
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. C / E

12. C / E

13. references

14. country

15. weather

16. C

17. C

18. A

19. B

20. C

### Part 3 · source page 157

TEST3 LISTENING
Section1, Questions1–10
1 1.4litres /1.4liters
2 automatic
3 light / sky
4 credit
5 Harries
6 Dr / Doctor
7 Alton
8 messages
9 Lion
10 reasonable
Section2, Questions11–20
11–12 IN EITHER ORDER: C;E
13 references
14 country
15 weather
16 C
17 C
18 A
19 B
20 C
Section3, Questions21–30
21 5th May
22 16th July / Friday16th July
23 clear / was clear
24 (an/the)outline / (a/the)course outline
25 (the)2nd half
26 (standard of)teaching / (standard of)teachers
27 discussion / group discussion
28 handouts
29 written work
30 student support / support for students
Section4, Questions31–40
31 12.5%
32 incineration plants
33 drop-off
34 cooking
35 500,000
36 roads
37 soil conditioner
38 containers
39 pencils
40 business cards
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. 5 May / 5th May

22. 16 July / 16th July / Friday 16 July / Friday 16th July

23. clear / was clear

24. outline / an outline / the outline / course outline / a course outline / the course outline

25. 2nd half / the 2nd half

26. teaching / standard of teaching / teachers / standard of teachers

27. discussion / group discussion

28. handouts

29. written work

30. student support / support for students

### Part 4 · source page 157

TEST3 LISTENING
Section1, Questions1–10
1 1.4litres /1.4liters
2 automatic
3 light / sky
4 credit
5 Harries
6 Dr / Doctor
7 Alton
8 messages
9 Lion
10 reasonable
Section2, Questions11–20
11–12 IN EITHER ORDER: C;E
13 references
14 country
15 weather
16 C
17 C
18 A
19 B
20 C
Section3, Questions21–30
21 5th May
22 16th July / Friday16th July
23 clear / was clear
24 (an/the)outline / (a/the)course outline
25 (the)2nd half
26 (standard of)teaching / (standard of)teachers
27 discussion / group discussion
28 handouts
29 written work
30 student support / support for students
Section4, Questions31–40
31 12.5%
32 incineration plants
33 drop-off
34 cooking
35 500,000
36 roads
37 soil conditioner
38 containers
39 pencils
40 business cards
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. 12.5 per cent / 12.5 percent / 12.5%

32. incineration plants

33. drop-off

34. cooking

35. 500,000 / 500000

36. roads

37. soil conditioner

38. containers

39. pencils

40. business cards

## A 类阅读

### Academic Reading · source page 158

ACADEMIC READING
Reading Passage1, Questions1–13
1 D
2 B
3 C
4 E
5 B
6 D
7 A
8 B
9 D
10 C
11 TRUE
12 FALSE
13 NOT GIVEN
Reading Passage2, Questions14–26
14 iv
15 i
16 v
17 viii
18 YES
19 NOT GIVEN
20 NO
21 YES
22 NOT GIVEN
23 YES
24 F
25 A
26 B
Reading Passage3, Questions27–40
27 E
28 B
29 A
30 F
31 B
32 NOT GIVEN
33 FALSE
34 NOT GIVEN
35 TRUE
36 FALSE
37 TRUE
38 B
39 A
40 D
If you score… (original source guidance, not a new scoring rule)
0–11: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. D

2. B

3. C

4. E

5. B

6. D

7. A

8. B

9. D

10. C

11. TRUE

12. FALSE

13. NOT GIVEN

14. iv

15. i

16. v

17. viii

18. YES

19. NOT GIVEN

20. NO

21. YES

22. NOT GIVEN

23. YES

24. F

25. A

26. B

27. E

28. B

29. A

30. F

31. B

32. NOT GIVEN

33. FALSE

34. NOT GIVEN

35. TRUE

36. FALSE

37. TRUE

38. B

39. A

40. D

## A 类写作

### Writing material: c5-t3-w-1

Original map inspected at full resolution. North arrow points up. Garlsdon population 65,000. S1 is in countryside to the northwest of the built-up housing area, near the main road toward Hindon and near the railway. S2 is inside the centrally located town centre, explicitly a no-traffic zone. Housing surrounds the centre; industrial areas are to its north and south. The railway runs from the northwest through the town centre toward the southeast and passes near both proposed sites. Main-road destinations and labels: Hindon to the northwest, 12 km away, population 10,000; Bransdon to the southwest, 16 km away, population 15,000; Cransdon to the southeast, 25 km away, population 29,000. S1 is closer to the Hindon route and outside the traffic-free centre; S2 is more central to Garlsdon's housing and surrounding approaches, but cars cannot enter the no-traffic zone. These are alternative locations, not before-and-after maps: do not invent building dates, a completed supermarket or a railway station. The task requires comparison, not necessarily choosing a winning site.



### Writing material: c5-t3-w-2

The instruction explicitly requires BOTH views and the writer's own opinion. Discuss encouraging competition and teaching cooperation, while allowing a supported balanced or qualified position.



## 口语
