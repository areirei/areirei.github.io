# 剑雅 5 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/6ce9c43f3d47adac25ce1a646742a19b5c7c30802fc774ba3cb4730b47b0a2c3.jpg; PDF page 56; full -->

```text
LISTENING SECTION1 Questions1–10
Complete the form below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
MINTONS CAR MART—Customer Enquiry
Example: Make—Lida
Engine size:(1) __________;Model:Max;Type of gears:(2) __________;Preferred colour:(3) __________ blue
FINANCE: Customer wishes to arrange(4) __________;Part exchange?yes
PERSONAL DETAILS
Name:Wendy(5) __________;Title:(6) __________
Address:20,Green Banks,(7) __________,Hampshire
Postcode:GU8 9EW
Contact number:(8)(for __________ only)0798 257643
```

[Original question page](assets/6ce9c43f3d47adac25ce1a646742a19b5c7c30802fc774ba3cb4730b47b0a2c3.jpg)

<!-- Source: /api/assets/f52f76062030894c0ee6a3d86c30d1fa6c9deabf82760becb908ec95b268a8c2.jpg; PDF page 57; full -->

```text
CURRENT CAR
Make:Conti
Model:Name:(9) __________;Year:1994
Mileage:maximum70,000
Colour:metallic grey
Condition:(10) __________
```

[Original question page](assets/f52f76062030894c0ee6a3d86c30d1fa6c9deabf82760becb908ec95b268a8c2.jpg)

### Part 2

<!-- Source: /api/assets/7c692942ca3096525cfc673f8478d27741eac1172af40ea290094bbe103ede58.jpg; PDF page 58; full -->

```text
Listening 
SECTION 2 Questions 11-20 
Questions 11 and 12 
Choose TWO letters A-E. 
What TWO advantages does the speaker say Rexford University has for the students he is 
speaking to? 
A higher than average results in examinations 
B good transport links with central London 
C near London Airport 
D special government funding 
E good links with local industry 
Questions 13-15 
Complete the notes below. 
Write NO MORE THAN ONE WORD for each answer. 
• When application is received, confirmation will be sent 
• Application processing may be slowed down by 
postal problems 
delays in sending 13 ...................... .. 
• University tries to put international applicants in touch with a student from the 
same 14 .............. ......... . who can give information and advice on 
academic atmosphere 
leisure facilities 
English 15 ........................ and food 
what to pack 
57
```

[Original question page](assets/7c692942ca3096525cfc673f8478d27741eac1172af40ea290094bbe103ede58.jpg)

<!-- Source: /api/assets/67423a9c5264f9df6fc2468ca1860a3c16a9ea9e762088adda039d4efab8108c.jpg; PDF page 59; full -->

```text
Test 3 
Questions 16-20 
Choose the correct letter, A, B or C 
16 The speaker says international students at UK universities will be 
A offered accommodation with local families. 
B given special help by their lecturers. 
C expected to work independently . 
17 What does the speaker say about university accommodation on campus? 
A Most places are given to undergraduates. 
B No places are available for postgraduates with families. 
C A limited number of places are available for new postgraduates. 
18 Students wishing to live off-campus should apply 
A several months in advance. 
B two or three weeks in advance . 
C at the beginning of term . 
19 The university accommodation officer will 
A send a list of agents for students to contact. 
B contact accommodation agencies for students. 
C ensure that students have suitable accommodation. 
20 With regard to their English, the speaker advises the students to 
A tell their lecturers if they have problems understanding. 
B have private English lessons when they arrive. 
C practise their spoken English before they arrive . 
58
```

[Original question page](assets/67423a9c5264f9df6fc2468ca1860a3c16a9ea9e762088adda039d4efab8108c.jpg)

### Part 3

<!-- Source: /api/assets/3a4b27d8519b5f0df530cd0371daf7c5cf53fd6920a794026b0a3eebd607ca5f.jpg; PDF page 60; full -->

```text
SECTION3 Questions21–30
Complete the form below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Feedback Form
Course:Communication in Business;Course code:CB162
Dates:From(21) __________ to(22) __________
Please give your comments on the following aspects of the course:
Aspect | Good Points | Suggestions for Improvement
Course organisation |(23) __________;useful to have(24) __________ at beginning of course|too much work in(25) __________ of the course—could be more evenly balanced
Course delivery |good(26) __________|some(27) __________ sessions went on too long
Materials and equipment |good(28) __________|not enough copies of key texts available;need more computers
Testing and evaluation |quick feedback from oral presentations;marking criteria for oral presentations known in advance|too much(29) __________;can we know criteria for marking final exams?
Other comments |excellent(30) __________|[empty non-answer cell]
```

[Original question page](assets/3a4b27d8519b5f0df530cd0371daf7c5cf53fd6920a794026b0a3eebd607ca5f.jpg)

### Part 4

<!-- Source: /api/assets/09b796cd9cf55c2de8e57bca1d8cf5795ed5de8956d7a4f86750e192bdba2b97.jpg; PDF page 61; full -->

```text
Test 3 
SECTION 4 Questions 31-40 
Questions 31-35 
Complete the sentences below. 
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer. 
HOUSEHOLD WASTE RECYCLING 
31 By 2008, carbon dioxide emissions need to be ........................ lower than in 1990. 
32 Recycling saves energy and reduces emissions from landfill sites and ........................ . 
33 People say that one problem is a lack of ' ........................ ' sites for household waste. 
At the 'bring banks', household waste is sorted and unsuitable items removed. 
34 Glass designed to be utilised for ........................ cannot be recycled with other types of 
glass. 
35 In the UK, ...................... .. tons of glass is recycled each year. 
60
```

[Original question page](assets/09b796cd9cf55c2de8e57bca1d8cf5795ed5de8956d7a4f86750e192bdba2b97.jpg)

<!-- Source: /api/assets/f8a608107c5761c6ea9dcdd871c170af7d13bb444c2bc5e2270ebbd09c8eb3ce.jpg; PDF page 62; full -->

```text
Questions36–40: Complete the table below. Write NO MORE THAN TWO WORDS for each answer.
Companies working with recycled materials
Material | Company | Product that the company manufactures
glass |CLF Aggregates|material used for making(36) __________
paper |Martin’s|office stationery
paper |Papersave|(37) __________ for use on farms
plastic |Pacrite|(38) __________ for collecting waste
plastic |Waterford|(39) __________
plastic |Johnson & Jones|(40) __________
```

[Original question page](assets/f8a608107c5761c6ea9dcdd871c170af7d13bb444c2bc5e2270ebbd09c8eb3ce.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/9a24e0db23c3feb368ee775cac4f7981fe9dde534d20482dc4042d21d055546b.jpg; PDF page 63; full -->

```text
Test 3



READING



READING PASSAGE 1



You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage 1



below.



Early Childhood Education







New Zealand's National Party spokesman on education, Dr Lockwood Smith,

recently visited the US and Britain. Here he reports on the findings of his trip

and what they could mean for New Zealand's education policy



A



‘Education To Be More’ was published last

August. It was the report of the New Zealand

Government's Early Childhood Care and

Education Working Group. The report argued for

enhanced equity of access and better funding



for childcare and early childhood education

institutions. Unquestionably, that’s a real need;

but since parents don’t normally send children to

pre-schools until the age of three, are we missing

out on the most important years of all?



B



A 13-year study of early childhood development

at Harvard University has shown that, by the age

of three, most children have the potential to

understand about 1000 words — most of the

language they will use in ordinary conversation

for the rest of their lives.



Furthermore, research has shown that while

every child is born with a natural curiosity, it can

be suppressed dramatically during the second

and third years of life. Researchers claim that the

human personality is formed during the first two

years of life, and during the first three years

children learn the basic skills they will use in all

their later learning both at home and at school.

Once over the age of three, children continue to

expand on existing knowledge of the world.



C

It is generally acknowledged that young people

from poorer socio-economic backgrounds tend to



62



do less well in our education system. That’s

observed not just in New Zealand, but also in

Australia, Britain and America. In an attempt to

overcome that educational under-achievement, a

nationwide programme called ‘Headstart’ was

launched in the United States in 1965. A lot of

money was poured into it. It took children into

pre-school institutions at the age of three and

was supposed to help the children of poorer

families succeed in school.



Despite substantial funding, results have been

disappointing. It is thought that there are two

explanations for this. First, the programme began

too late. Many children who entered it at the

age of three were already behind their peers in

language and measurable intelligence. Second,

the parents were not involved. At the end of each

day, ‘Headstart’ children returned to the same

disadvantaged home environment.



D



As a result of the growing research evidence



of the importance of the first three years of a

child’s life and the disappointing results from

‘Headstart’, a pilot programme was launched in

Missouri in the US that focused on parents as the

child’s first teachers. The ‘Missouri’ programme

was predicated on research showing that

working with the family, rather than bypassing

the parents, is the most effective way of helping

children get off to the best possible start in life.

The four-year pilot study included 380 families

who were about to have their first child and who
```

[Original question page](assets/9a24e0db23c3feb368ee775cac4f7981fe9dde534d20482dc4042d21d055546b.jpg)

<!-- Source: /api/assets/ef32c9e01045af4bfae7d2f72937571f4001a2700fb4da6f5ff7ec034c77243f.jpg; PDF page 64; full -->

```text
represented a cross-section of socio-economic 
status, age and family configurations. They 
included single-parent and two-parent families, 
families in which both parents worked, and 
families with either the mother or father at home. 
The programme involved trained parent­
educators visiting the parents' home and working 
with the parent, or parents, and the child . 
Information on child development, and guidance 
on things to look for and expect as the child 
grows were provided, plus guidance in fostering 
the child's intellectual, language, social and 
motor-skill development. Periodic check-ups of 
the child's educational and sensory development 
(hearing and vision) were made to detect 
possible handicaps that interfere with growth and 
development. Medical problems were referred to 
professionals. 
Parent-educators made personal visits to 
homes and monthly group meetings were held 
with other new parents to share experience and 
discuss topics of interest. Parent resource centres, 
located in school buildings, offered learning 
materials for families and facilitators for child 
care. 
E 
At the age of three, the children who had been 
involved in the 'Missouri' programme were 
evaluated alongside a cross-section of children 
selected from the same range of socio-economic 
backgrounds and family situations, and also a 
random sample of children that age. The results 
were phenomenal. By the age of three, the 
children in the programme were significantly 
more advanced in language development than 
their peers, had made greater strides in problem 
solving and other intellectual skills, and were 
Reading 
further along in social development. In fact, the 
average child on the programme was performing 
at the level of the top 15 to 20 per cent of their 
peers in such things as auditory comprehension, 
verbal ability and language ability . 
Most important of all, the traditional measures 
of 'risk', such as parents' age and education, or 
whether they were a single parent, bore little or 
no relationship to the measures of achievement 
and language development. Children in the 
programme performed equally well regardless of 
socio-economic disadvantages. Child abuse was 
virtually eliminated . The one factor that was 
found to affect the child's development was 
family stress leading to a poor quality of 
parent-child interaction. That interaction was not 
necessarily bad in poorer families. 
F 
These research findings are exciting . There is 
growing evidence in New Zealand that children 
from poorer socio-economic backgrounds are 
arriving at school less well developed and that 
our school system tends to perpetuate that 
disadvantage . The initiative outlined above could 
break that cycle of disadvantage . The concept of 
working with parents in their homes, or at their 
place of work, contrasts quite markedly with 
the report of the Early Childhood Care and 
Education Working Group . Their focus is on 
getting children and mothers access to childcare 
and institutionalised early childhood education. 
Education from the age of three to five is 
undoubtedly vital, but without a similar focus on 
parent education and on the vital importance of 
the first three years, some evidence indicates that 
it will not be enough to overcome educational 
inequity. 
63
```

[Original question page](assets/ef32c9e01045af4bfae7d2f72937571f4001a2700fb4da6f5ff7ec034c77243f.jpg)

<!-- Source: /api/assets/011ec08f67e6bcc223e299a5e4bca5a2a20d54d0881a8df05df9b15db35439fe.jpg; PDF page 65; full -->

```text
Test 3 
Questions 1-4 
Reading Passage 1 has six sections, A-F. 
Which paragraph contains the following information? 
Write the correct letter A–F in boxes 1-4 on your answer sheet. 
1 details of the range of family types involved in an education programme 
2 reasons why a child's early years are so important 
3 reasons why an education programme failed 
4 a description of the positive outcomes of an education programme 
Questions 5-10 
Classify the following features as characterising 
A the 'Headstart' programme 
B the 'Missouri' programme 
C both the 'Headstart' and the 'Missouri' programmes 
D neither the 'Headstart' nor the 'Missouri' programme 
Write the correct letter A, B, C or D in boxes 5-10 on your answer sheet. 
5 was administered to a variety of poor and wealthy families 
6 continued with follow-up assistance in elementary schools 
7 did not succeed in its aim 
8 supplied many forms of support and training to parents 
9 received insufficient funding 
10 was designed to improve pre-schoolers' educational development 
64
```

[Original question page](assets/011ec08f67e6bcc223e299a5e4bca5a2a20d54d0881a8df05df9b15db35439fe.jpg)

<!-- Source: /api/assets/2ae8d1751c33e89a09597126b2c03408559a6b11d6393d4eeed7f4ee573bbca9.jpg; PDF page 66; full -->

```text
Reading 
Questions 11-13 
Do the following statements agree with the information given in Reading Passage1? 
In boxes 11–13 on your answer sheet, write 
TRUE 
FALSE 
NOT GIVEN 
if the statement agrees with the information 
if the statement contradicts the information 
if there is no information on this 
11 Most 'Missouri' programme three-year-olds scored highly in areas such as listening, 
speaking, reasoning and interacting with others. 
12 'Missouri' programme children of young, uneducated, single parents scored less highly 
on the tests. 
13 The richer families in the 'Missouri' programme had higher stress levels. 
65
```

[Original question page](assets/2ae8d1751c33e89a09597126b2c03408559a6b11d6393d4eeed7f4ee573bbca9.jpg)

<!-- Source: /api/assets/320f2f2c5ba6a05faf13d395e70592c14b1463221667be7ca311d844a9c2d1e5.jpg; PDF page 67; full -->

```text
Test 3 
READING PASSAGE 2 
You should spend about 20 minutes on Questions 14-26 , which are based on Reading Passage 2 
on the following pages. 
Questions 14- 17 
Reading Passage 2 has six paragraphs, A-F . 
Choose the correct heading for paragraphs B and D-F from the list of headings below. 
Write the correct number i- viii in boxes 14- 17 on your answer sheet. 
List of Headings 
i Effects of irrigation on sedimentation 
ii The danger of flooding the Cairo area 
iii Causing pollution in the Mediterranean 
iv Interrupting a natural process 
v The threat to food production 
vi Less valuable sediment than before 
vii Egypt's disappearing coastline 
viii Looking at the long-term impact 
Example Paragraph A Answer vii 
14 Paragraph B 
Example Paragraph C Answer vi 
15 Paragraph D 
16 Paragraph E 
17 Paragraph F 
66
```

[Original question page](assets/320f2f2c5ba6a05faf13d395e70592c14b1463221667be7ca311d844a9c2d1e5.jpg)

<!-- Source: /api/assets/c71ec68140dddbebf27aeaaa0beeb0990b525840b0a1d1e25e8331eaaa87ca96.jpg; PDF page 68; full -->

```text
Readin g 
Disappearing Delta 
A The fertile land of the Nile delta is being 
eroded along Egypt's Mediterranean coast at 
an astounding rate, in some parts estimated at 
100 metres per year. In the past, land scoured 
away from the coastline by the currents of the 
Mediterranean Sea used to be replaced by 
sediment brought down to the delta by the River 
Nile, but this is no longer happening . 
B Up to now, people have blamed this loss of 
delta land on the two large dams at Aswan in the 
south of Egypt, which hold back virtually all of 
the sediment that used to flow down the river. 
Before the dams were built, the Nile flowed 
freely, carrying huge quantities of sediment north 
from Africa 's interior to be deposited on the Nile 
delta. This continued for 7,000 years, eventually 
covering a region of over 22,000 square 
kilometres with layers of fertile silt. Annual 
flooding brought in new, nutrient-rich soil to the 
delta region, replacing what had been washed 
away by the sea, and dispensing with the need 
for fertilizers in Egypt's richest food-growing 
area . But when the Aswan dams were 
constructed in the 20th century to provide 
electricity and irrigation, and to protect the huge 
population centre of Cairo and its surrounding 
areas from annual flooding and drought, most 
of the sediment with its natural fertilizer 
accumulated up above the dam in the southern, 
upstream half of Lake Nasser, instead of passing 
down to the delta. 
C Now, however, there turns out to be more to 
the story. it appears that the sediment-free water 
emerging from the Aswan dams picks up silt and 
sand as it erodes the river bed and banks on the 
800-kilometre trip to Cairo . Daniel Jean Stanley 
of the Smithsonian Institute noticed that water 
samples taken in Cairo , just before the river 
enters the delta, indicated that the river 
sometimes carries more than 850 grams of 
sediment per cubic metre of water- almost half 
of what it carried before the dams were built. 
'I'm ashamed to say that the significance of this 
didn 't strike me until after I had read 50 or 
60 studies,' says Stanley in Marine Geology. 
'There is still a lot of sediment coming into the 
delta, but virtually no sediment comes out into 
the Mediterranean to replenish the coastline. 
So this sediment must be trapped on the delta 
itself.' 
D Once north of Cairo , most of the Nile water 
is diverted into more than 10,000 kilometres of 
irrigation canals and only a small proportion 
reaches the sea directly through the rivers in the 
delta. The water in the irrigation canals is still 
or very slow-moving and thus cannot carry 
sediment, Stanley explains. The sediment sinks to 
the bottom of the canals and then is added to 
fields by farmers or pumped with the water 
into the four large freshwater lagoons that are 
located near the outer edges of the delta. So very 
little of it actually reaches the coastline to replace 
what is being washed away by the 
Mediterranean currents. 
E The farms on the delta plains and fishing and 
aquaculture in the lagoons account for much of 
Egypt's food supply. But by the time the sediment 
has come to rest in the fields and lagoons it is 
laden with municipal, industrial and agricultural 
waste from the Cairo region, which is home to 
more than 40 million people. 'Pollutants are 
building up faster and faster,' says Stanley. 
67
```

[Original question page](assets/c71ec68140dddbebf27aeaaa0beeb0990b525840b0a1d1e25e8331eaaa87ca96.jpg)

<!-- Source: /api/assets/12105635295427287d573397ceddc6a128995ab87fa750dc8ea9175d66e1248c.jpg; PDF page 69; full -->

```text
Test 3 
N 
Based on his investigations of sediment from 
the delta lagoons, Frederic Siegel of George 
Washington University concurs. 'In Manzalah 
Lagoon, for example, the increase in mercury, 
lead, copper and zinc coincided with 
the building of the High Dam at Aswan, the 
availability of cheap electricity, and the 
development of major power-based industries,' 
he says. Since that time the concentration of 
mercury has increased significantly. Lead from 
engines that use leaded fuels and from other 
industrial sources has also increased 
dramatically . These poisons can easily enter the 
food chain , affecting the productivity of fishing 
and farming . Another problem is that agricultural 
wastes include fertilizers which stimulate 
increases in plant growth in the lagoons and 
upset the ecology of the area, with serious effects 
on the fishing industry. 
68 
Aswa n L ow D am 
Aswan H igh D am 
F According to Siegel, international 
environmental organisations are beginning to 
pay closer attention to the region, partly because 
of the problems of erosion and pollution of the 
Nile delta, but principally because they fear the 
impact this situation could have on the whole 
Mediterranean coastal ecosystem. But there 
are no easy solutions. In the immediate future, 
Stanley believes that one solution would be to 
make artificial floods to flush out the delta 
waterways, in the same way that natural floods 
did before the construction of the dams. He says, 
however, that in the long term an alternative 
process such as desalination may have to be 
used to increase the amount of water available. 
'In my view, Egypt must devise a way to have 
more water running through the river and the 
delta,' says Stanley. Easier said than done in a 
desert region with a rapidly growing population .
[Original map retained: north arrow upwards; Mediterranean Sea and Nile Delta at top,Cairo immediately south,River Nile south to Aswan Low Dam/Aswan High Dam and Aswan,then Lake Nasser.]
```

[Original question page](assets/12105635295427287d573397ceddc6a128995ab87fa750dc8ea9175d66e1248c.jpg)

![Original figure](assets/12105635295427287d573397ceddc6a128995ab87fa750dc8ea9175d66e1248c.jpg)

<!-- Source: /api/assets/f2fa92106bdb5096fb987720dce9c35725d27f0efc0741e4f14bcb952e1b0030.jpg; PDF page 70; full -->

```text
Questions 18-23 
Do the following statements reflect the claims of the writer in Reading Passage 2? 
In boxes 18-23 on your answer sheet, write 
YES 
NO 
NOT GIVEN 
if the statement reflects the claims of the writer 
if the statement contradicts the claims of the writer 
if it is impossible to say what the writer thinks about this 
Reading 
18 Coastal erosion occurred along Egypt's Mediterranean coast before the building of the 
Aswan dams. 
19 Some people predicted that the Aswan dams would cause land loss before they were 
built. 
20 The Aswan dams were built to increase the fertility of the Nile delta . 
21 Stanley found that the levels of sediment in the river water in Cairo were relatively high. 
22 Sediment in the irrigation canals on the Nile delta causes flooding. 
23 Water is pumped from the irrigation canals into the lagoons. 
69
```

[Original question page](assets/f2fa92106bdb5096fb987720dce9c35725d27f0efc0741e4f14bcb952e1b0030.jpg)

<!-- Source: /api/assets/e9b26e2462e1792e7ea1a7a585b3b6fe2814cdd583088827a65ea0510ecefa63.jpg; PDF page 71; full -->

```text
Test 3 
Questions 24-26 
Complete the summary of paragraphs E and F with the list of words A-H below. 
Write the correct letter A-H in boxes 24-26 on your answer sheet. 
70 
In addition to the problem of coastal erosion , there has been a marked increase in the level 
of 24 ..... ........... ..... ... contained in the silt deposited in the Nile delta. To deal with this, 
Stanley suggests the use of 25 .................... .... in the short term, and increasing the 
amount of water available through 26 ........................ in the longer term. 
A artificial floods 
E nutrients 
B desalination 
F pollutants 
C delta waterways 
G population control 
D natural floods 
H sediment
```

[Original question page](assets/e9b26e2462e1792e7ea1a7a585b3b6fe2814cdd583088827a65ea0510ecefa63.jpg)

<!-- Source: /api/assets/5499ed3df24f9d7d2695fc238d82d27a1ea2ff84e293b9c871143c18aee4b8e4.jpg; PDF page 72; full -->

```text
Reading



READING PASSAGE 3



You should spend about 20 minutes on Questions 27-40, which are based on Reading Passage 3

below.



The Return of Artificial Intelligence

It is becoming acceptable again to talk of computers performing

human tasks such as problem-solving and pattern-recognition



A After years in the wilderness, the term ‘artificial intelligence’ (AI)

seems poised to make a comeback. AI was big in the 1980s but

vanished in the 1990s. It re-entered public consciousness with the

release of AI, a movie about a robot boy. This has ignited public

debate about AI, but the term is also being used once more within

the computer industry. Researchers, executives and marketing

people are now using the expression without irony or inverted

commas. And it is not always hype. The term is being applied, with

some justification, to products that depend on technology that was

originally developed by AI researchers. Admittedly, the

rehabilitation of the term has a long way to go, and some firms still

prefer to avoid using it. But the fact that others are starting to use

it again suggests that AI has moved on from being seen as an over-

ambitious and under-achieving field of research.



B The field was launched, and the term ‘artificial intelligence’ coined, at a conference in 1956 by

a group of researchers that included Marvin Minsky, John McCarthy, Herbert Simon and Alan

Newell, all of whom went on to become leading figures in the field. The expression provided an

attractive but informative name for a research programme that encompassed such previously

disparate fields as operations research, cybernetics, logic and computer science. The goal they

shared was an attempt to capture or mimic human abilities using machines. That said, different

groups of researchers attacked different problems, from speech recognition to chess playing, in

different ways; AI unified the field in name only. But it was a term that captured the public

imagination.



C Most researchers agree that AI peaked around 1985. A public reared on science-fiction

movies and excited by the growing power of computers had high expectations. For years,



AI researchers had implied that a breakthrough was just around the corner. Marvin Minsky said

in 1967 that within a generation the problem of creating ‘artificial intelligence’ would be

substantially solved. Prototypes of medical-diagnosis programs and speech recognition software

appeared to be making progress. It proved to be a false dawn. Thinking computers and



71
```

[Original question page](assets/5499ed3df24f9d7d2695fc238d82d27a1ea2ff84e293b9c871143c18aee4b8e4.jpg)

<!-- Source: /api/assets/0aa06fe2ba28a6a9da0158887464a194879fc99492c1996f0b9dd052bb731a2d.jpg; PDF page 73; full -->

```text
Test 3



household robots failed to materialise, and a backlash ensued. ‘There was undue optimism in the

early 1980s, says David Leake, a researcher at Indiana University. ‘Then when people realised

these were hard problems, there was retrenchment. By the late 1980s, the term AI was being

avoided by many researchers, who opted instead to align themselves with specific sub-disciplines

such as neural networks, agent technology, case-based reasoning, and so on:



D Ironically, in some ways AI was a victim of its own success. Whenever an apparently mundane

problem was solved, such as building a system that could land an aircraft unattended, the

problem was deemed not to have been AI in the first place. ‘If it works, it can’t be AI, as



Dr Leake characterises it. The effect of repeatedly moving the goal-posts in this way was that



AI came to refer to ‘blue-sky’ research that was still years away from commercialisation.

Researchers joked that AI stood for ‘almost implemented’. Meanwhile, the technologies that

made it onto the market, such as speech recognition, language translation and decision-support

software, were no longer regarded as AI. Yet all three once fell well within the umbrella of



AI research.



E But the tide may now be turning, according to Dr Leake. HNC Software of San Diego, backed

by a government agency, reckon that their new approach to artificial intelligence is the most

powerful and promising approach ever discovered. HNC claim that their system, based on a

cluster of 30 processors, could be used to spot camouflaged vehicles on a battlefield or extract

a voice signal from a noisy background — tasks humans can do well, but computers cannot.

‘Whether or not their technology lives up to the claims made for it, the fact that HNC are

emphasising the use of AI is itself an interesting development, says Dr Leake.



.

F Another factor that may boost the prospects for AI in the near future is that investors are

now looking for firms using clever technology, rather than just a clever business model, to

differentiate themselves. In particular, the problem of information overload, exacerbated by the

growth of e-mail and the explosion in the number of web pages, means there are plenty of

opportunities for new technologies to help filter and categorise information — classic AI

problems. That may mean that more artificial intelligence companies will start to emerge to

meet this challenge.



G The 1969 film, 2001:A Space Odyssey, featured an intelligent computer called HAL 9000. As

well as understanding and speaking English, HAL could play chess and even learned to lipread.

HAL thus encapsulated the optimism of the 1960s that intelligent computers would be

widespread by 2001. But 2001 has been and gone, and there is still no sign of a HAL-like

computer. Individual systems can play chess or transcribe speech, but a general theory of

machine intelligence still remains elusive. It may be, however, that the comparison with HAL no

longer seems quite so important, and AI can now be judged by what it can do, rather than by

how well it matches up to a 30-year-old science-fiction film. ‘People are beginning to realise that

there are impressive things that these systems can do, says Dr Leake hopefully.



72
```

[Original question page](assets/0aa06fe2ba28a6a9da0158887464a194879fc99492c1996f0b9dd052bb731a2d.jpg)

<!-- Source: /api/assets/5e62d4cf1257ffff119eb44205f285411e9fead672e518dd0f72cfc01888c689.jpg; PDF page 74; full -->

```text
Reading 
Questions 27-31 
Reading Passage 3 has seven paragraphs. A-G 
Which paragraph contains the following information? 
Write the correct letter A–G in boxes 27-31 on your answer sheet. 
NB You may use any letter more than once. 
27 how AI might have a military impact 
28 the fact that AI brings together a range of separate research areas 
29 the reason why AI has become a common topic of conversation again 
30 how AI could help deal with difficulties related to the amount of information available 
electronically 
. 
31 where the expression AI was first used 
Questions 32-37 
Do the following statements agree with the information given in Reading Passage 3? 
In boxes 32-37 on your answer sheet, write 
TRUE 
FALSE 
NOT GIVEN 
if the statement agrees with the information 
if the statement contradicts the information 
if there is no information about this 
32 The researchers who launched the field of AI had worked together on other projects in 
the past. 
33 In 1985, AI was at its lowest point. 
34 Research into agent technology was more costly than research into neural networks. 
35 Applications of AI have already had a degree of success. 
36 The problems waiting to be solved by AI have not changed since 1967. 
37 The film 2001: A Space Odyssey reflected contemporary ideas about the potential of AI 
computers. 
73
```

[Original question page](assets/5e62d4cf1257ffff119eb44205f285411e9fead672e518dd0f72cfc01888c689.jpg)

<!-- Source: /api/assets/1e1cc8d800e1aaa20c6d485ea63f227c91e5b27b7b0ad251c689ae0f7bddedbb.jpg; PDF page 75; full -->

```text
Test3 
Questions 38-40 
Choose the correct letter A. B. C or D. 
Write your answers in boxes 38-40 on your answer sheet. 
38 According to researchers, in the late 1980s there was a feeling that 
A a general theory of AI would never be developed. 
B original expectations of AI may not have been justified. 
C a wide range of applications was close to fruition. 
D more powerful computers were the key to further progress. 
39 In Dr Leake's opinion, the reputation of AI suffered as a result of 
A changing perceptions. 
B premature implementation. 
C poorly planned projects. 
D commercial pressures. 
40 The prospects for AI may benefit from 
A existing AI applications. 
74 
B new business models. 
C orders from internet-only companies. 
D new investment priorities.
```

[Original question page](assets/1e1cc8d800e1aaa20c6d485ea63f227c91e5b27b7b0ad251c689ae0f7bddedbb.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/47b1dad09a671687339efe66816a65e4c1d735f83b7e4565cb6d4bd4cb496304.jpg; PDF page 76; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The map below is of the town of Garlsdon. A new supermarket (S) is planned for the town. The map shows two possible sites for the supermarket.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/47b1dad09a671687339efe66816a65e4c1d735f83b7e4565cb6d4bd4cb496304.jpg)

![Original figure](assets/47b1dad09a671687339efe66816a65e4c1d735f83b7e4565cb6d4bd4cb496304.jpg)

### Task 2

<!-- Source: /api/assets/26b0325f6cdeb2d8aac9b61548adb969823080a5dc89aa9c9fcb650c0c065e6e.jpg; PDF page 77; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people think that a sense of competition in children should be encouraged. Others believe that children who are taught to co-operate rather than compete become more useful adults.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/26b0325f6cdeb2d8aac9b61548adb969823080a5dc89aa9c9fcb650c0c065e6e.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/88440a168e7445063e0fda056ebbd3ea98b68419a3482a2e364d21c756d036ba.jpg; PDF page 78; full -->

```text
Speaking 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Entertainment 
• Do you prefer relaxing at home or going out in the evening? [Why?] 
• When you go out for an evening, what do you like to do? 
• How popular is this with other people in your country ? 
• Is there any kind of entertainment you do not like? [Why/Why not ?] 
PART2
Describe one of your friends.You should say:how you met;how long you have known each other;how you spend time together;and explain why you like this person.
You will have to talk about the topic for one to two minutes.You have one minute to think about what you’re going to say.You can make some notes to help you if you wish.

PART 3 
Discussion topics: 
Qualities of friends 
Example questions: 
What do you think are the most important qualities for friends to have? 
Which are more important to people, their family or their friends? Why? 
What do you think causes friendships to break up? 
Other relationships 
Example questions: 
What other types of relationship, apart from friends or family, are important in people's lives 
today? 
Have relationships with neighbours where you live changed in recent years? How? 
How important do you think it is for a person to spend some time alone? Why/Why not? 
77
```

[Original question page](assets/88440a168e7445063e0fda056ebbd3ea98b68419a3482a2e364d21c756d036ba.jpg)

### Part 2

<!-- Source: /api/assets/88440a168e7445063e0fda056ebbd3ea98b68419a3482a2e364d21c756d036ba.jpg; PDF page 78; full -->

```text
Speaking 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Entertainment 
• Do you prefer relaxing at home or going out in the evening? [Why?] 
• When you go out for an evening, what do you like to do? 
• How popular is this with other people in your country ? 
• Is there any kind of entertainment you do not like? [Why/Why not ?] 
PART2
Describe one of your friends.You should say:how you met;how long you have known each other;how you spend time together;and explain why you like this person.
You will have to talk about the topic for one to two minutes.You have one minute to think about what you’re going to say.You can make some notes to help you if you wish.

PART 3 
Discussion topics: 
Qualities of friends 
Example questions: 
What do you think are the most important qualities for friends to have? 
Which are more important to people, their family or their friends? Why? 
What do you think causes friendships to break up? 
Other relationships 
Example questions: 
What other types of relationship, apart from friends or family, are important in people's lives 
today? 
Have relationships with neighbours where you live changed in recent years? How? 
How important do you think it is for a person to spend some time alone? Why/Why not? 
77
```

[Original question page](assets/88440a168e7445063e0fda056ebbd3ea98b68419a3482a2e364d21c756d036ba.jpg)

### Part 3

<!-- Source: /api/assets/88440a168e7445063e0fda056ebbd3ea98b68419a3482a2e364d21c756d036ba.jpg; PDF page 78; full -->

```text
Speaking 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Entertainment 
• Do you prefer relaxing at home or going out in the evening? [Why?] 
• When you go out for an evening, what do you like to do? 
• How popular is this with other people in your country ? 
• Is there any kind of entertainment you do not like? [Why/Why not ?] 
PART2
Describe one of your friends.You should say:how you met;how long you have known each other;how you spend time together;and explain why you like this person.
You will have to talk about the topic for one to two minutes.You have one minute to think about what you’re going to say.You can make some notes to help you if you wish.

PART 3 
Discussion topics: 
Qualities of friends 
Example questions: 
What do you think are the most important qualities for friends to have? 
Which are more important to people, their family or their friends? Why? 
What do you think causes friendships to break up? 
Other relationships 
Example questions: 
What other types of relationship, apart from friends or family, are important in people's lives 
today? 
Have relationships with neighbours where you live changed in recent years? How? 
How important do you think it is for a person to spend some time alone? Why/Why not? 
77
```

[Original question page](assets/88440a168e7445063e0fda056ebbd3ea98b68419a3482a2e364d21c756d036ba.jpg)
