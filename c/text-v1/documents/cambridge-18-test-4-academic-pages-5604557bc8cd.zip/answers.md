# 剑雅 18 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 127

TEST 4 LISTENING
1 receptionist
2 Medical
3 Chastons
4 appointments
5 database
6 experience
7 confident
8 temporary
9 1.15
10 parking
11 B
12 A
13 A
14 C
15 F
16 G
17 E
18 A
19 C
20 B
21 B
22 D
23 D
24 A
25 C
26 G
27 F
28 A
29 B
30 C
31 plot
32 poverty
33 Europe
34 poetry
35 drawings
36 furniture
37 lamps
38 harbour / harbor
39 children
40 relatives
21&22 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. receptionist

2. Medical

3. Chastons

4. appointments

5. database

6. experience

7. confident

8. temporary

9. 1.15 / 1:15

10. parking

### Part 2 · source page 127

TEST 4 LISTENING
1 receptionist
2 Medical
3 Chastons
4 appointments
5 database
6 experience
7 confident
8 temporary
9 1.15
10 parking
11 B
12 A
13 A
14 C
15 F
16 G
17 E
18 A
19 C
20 B
21 B
22 D
23 D
24 A
25 C
26 G
27 F
28 A
29 B
30 C
31 plot
32 poverty
33 Europe
34 poetry
35 drawings
36 furniture
37 lamps
38 harbour / harbor
39 children
40 relatives
21&22 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B

12. A

13. A

14. C

15. F

16. G

17. E

18. A

19. C

20. B

### Part 3 · source page 127

TEST 4 LISTENING
1 receptionist
2 Medical
3 Chastons
4 appointments
5 database
6 experience
7 confident
8 temporary
9 1.15
10 parking
11 B
12 A
13 A
14 C
15 F
16 G
17 E
18 A
19 C
20 B
21 B
22 D
23 D
24 A
25 C
26 G
27 F
28 A
29 B
30 C
31 plot
32 poverty
33 Europe
34 poetry
35 drawings
36 furniture
37 lamps
38 harbour / harbor
39 children
40 relatives
21&22 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B / D

22. B / D

23. D

24. A

25. C

26. G

27. F

28. A

29. B

30. C

### Part 4 · source page 127

TEST 4 LISTENING
1 receptionist
2 Medical
3 Chastons
4 appointments
5 database
6 experience
7 confident
8 temporary
9 1.15
10 parking
11 B
12 A
13 A
14 C
15 F
16 G
17 E
18 A
19 C
20 B
21 B
22 D
23 D
24 A
25 C
26 G
27 F
28 A
29 B
30 C
31 plot
32 poverty
33 Europe
34 poetry
35 drawings
36 furniture
37 lamps
38 harbour / harbor
39 children
40 relatives
21&22 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. plot

32. poverty

33. Europe

34. poetry

35. drawings

36. furniture

37. lamps

38. harbour / harbor

39. children

40. relatives

## A 类阅读

### Academic Reading · source page 128

TEST 4 READING
1 D
2 C
3 E
4 B
5 D
6 energy
7 food
8 gardening
9 obesity
10 C
11 D
12 A
13 D
14 B
15 C
16 D
17 C
18 B
19 A
20 E
21 B
22 D
23 YES
24 NO
25 NOT GIVEN
26 YES
27 YES
28 NOT GIVEN
29 NO
30 NO
31 I
32 F
33 A
34 C
35 H
36 E
37 B
38 A
39 D
40 C
10&11 IN EITHER ORDER: C,D
12&13 IN EITHER ORDER: A,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. D

2. C

3. E

4. B

5. D

6. energy

7. food

8. gardening

9. obesity

10. C / D

11. C / D

12. A / D

13. A / D

14. B

15. C

16. D

17. C

18. B

19. A

20. E

21. B

22. D

23. YES

24. NO

25. NOT GIVEN

26. YES

27. YES

28. NOT GIVEN

29. NO

30. NO

31. I

32. F

33. A

34. C

35. H

36. E

37. B

38. A

39. D

40. C

## A 类写作

### Writing material: c18-t4-w-1

Copper,nickel,zinc;2014January–December. Vertical axis%CHANGE IN PRICE COMPARED WITH PREVIOUS MONTH, not price level. Approximate monthly changes: copper2,1,0.5,0.5,-0.5,-0.5,1,1,1,0.5,0.5,1.5; nickel6,4,1,1,0.5,-3,-1,-1,-1,-2,1,1; zinc1,3,2,1.5,1,-1,-0.5,-0.5,-0.5,-1,1.5,2. Copper least volatile overall; nickel greatest swings,peak6%Jan,trough-3%June; zinc peaks3%Feb. All positive byyearend. Zero means no month-on-month change; negative means a fall, not negative metal prices. All unlabelled readings approximate. Copper monthly points additionally checked against full-size original.



### Writing material: c18-t4-w-2

Weigh benefits and disadvantages of an ageing population and state the extent to which benefits outweigh costs. Both government and societal consequences relevant; do not turn into only causes of longer lifespans.



## 口语
