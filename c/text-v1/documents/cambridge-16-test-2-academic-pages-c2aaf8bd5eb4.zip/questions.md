# 剑雅 16 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/091affb478f120742020954287d4374b8818473e44a41247ec00301f5029f56f.jpg; PDF page 32; full -->

```text
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Copying photos to digital format
Name of company: Picturerep
Requirements
• Maximum size of photos is 30 cm, minimum size 4 cm.
• Photos must not be in a (1) __________ or an album.
Cost
• The cost for 360 photos is (2) £ __________ (including one disk).
• Before the completed order is sent, (3) __________ is required.
Services included in the price
• Photos can be placed in a folder, e.g. with the name (4) __________.
• The (5) __________ and contrast can be improved if necessary.
• Photos which are very fragile will be scanned by (6) __________.
Special restore service (costs extra)
• It may be possible to remove an object from a photo, or change the (7) __________.
• A photo which is not correctly in (8) __________ cannot be fixed.
Other information
• Orders are completed within (9) __________.
• Send the photos in a box (not (10) __________).
```

[Original question page](assets/091affb478f120742020954287d4374b8818473e44a41247ec00301f5029f56f.jpg)

### Part 2

<!-- Source: /api/assets/1de852cffa09202fba1a9389eccff6ad4384d578512626c19976d8b3baebedef.jpg; PDF page 33; full -->

```text
Listening
PART 2 Questions 11-20
Questions 11-15
Choose the correct letter, A, B or C.





11 Dartfield House school used to be
A a tourist information centre.
B a private home.
C a local council building.
12 What is planned with regard to the lower school?
A All buildings on the main site will be improved.
B The lower school site will be used for new homes.
C Additional school buildings will be constructed on the lower school site.
13 The catering has been changed because of
A long queuing times.
B changes to the school timetable.
C dissatisfaction with the menus.
14 Parents are asked to
A help their children to decide in advance which serving point to use.
B make sure their children have enough money for food.
C advise their children on healthy food to eat.
15 What does the speaker say about the existing canteen?
A Food will still be served there.
B Only staff will have access to it.
C Pupils can take their food into it.
33
```

[Original question page](assets/1de852cffa09202fba1a9389eccff6ad4384d578512626c19976d8b3baebedef.jpg)

<!-- Source: /api/assets/21015868ec1b63629a4f8a4c0eba9ab34c02ba62899ca7dcd213ea40caa762df.jpg; PDF page 34; full -->

```text
Questions 16–18
What comment does the speaker make about each of the following serving points in the Food Hall?
Choose THREE answers from the box and write the correct letter, A–D, next to Questions 16–18.
Comments
A pupils help to plan menus
B only vegetarian food
C different food every week
D daily change in menu
Food available at serving points in Food Hall
16 World Adventures __________
17 Street Life __________
18 Speedy Italian __________
Questions 19 and 20
Choose TWO letters, A–E.
Which TWO optional after-school lessons are new?
A swimming
B piano
C acting
D cycling
E theatre sound and lighting
```

[Original question page](assets/21015868ec1b63629a4f8a4c0eba9ab34c02ba62899ca7dcd213ea40caa762df.jpg)

### Part 3

<!-- Source: /api/assets/88fe584b13015838708db5bd1c662dde716d50147e2b98e444385df71e1bb081.jpg; PDF page 35; full -->

```text
Listening
PART 3 Questions 21-30
Questions 21-24
Choose the correct letter, A, B or C.




Assignment on sleep and dreams
21 Luke read that one reason why we often forget dreams is that
A our memories cannot cope with too much information.
B we might otherwise be confused about what is real.
C we do not think they are important.
22 What do Luke and Susie agree about dreams predicting the future?
A It may just be due to chance.
B It only happens with certain types of event.
C It happens more often than some people think.
23 Susie says that a study on pre-school children having a short nap in the day
A had controversial results.
B used faulty research methodology.
C failed to reach any clear conclusions.
24 In their last assignment, both students had problems with
A statistical analysis.
B making an action plan.
C self-assessment.
35
```

[Original question page](assets/88fe584b13015838708db5bd1c662dde716d50147e2b98e444385df71e1bb081.jpg)

<!-- Source: /api/assets/245338c53aaaf0546f11d5927980cae475b794970e98ed85c9d287b7a575ed25.jpg; PDF page 36; full -->

```text
Questions 25–30
Complete the flow chart below. Write ONE WORD ONLY for each answer.
Assignment plan
Decide on research question: Is there a relationship between hours of sleep and number of dreams?
↓
Decide on sample: Twelve students from the (25) __________ department
↓
Decide on methodology: Self-reporting
↓
Decide on procedure: Answers on (26) __________
↓
Check ethical guidelines for working with (27) __________
Ensure that risk is assessed and (28) __________ is kept to a minimum
↓
Analyse the results: Calculate the correlation and make a (29) __________
↓
(30) __________ the research
```

[Original question page](assets/245338c53aaaf0546f11d5927980cae475b794970e98ed85c9d287b7a575ed25.jpg)

### Part 4

<!-- Source: /api/assets/1ada7e4f827af2c0b09c053a665b41621a8d3321189e85ffdc867644dbd06b96.jpg; PDF page 37; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Health benefits of dance
Recent findings:
• All forms of dance produce various hormones associated with feelings of happiness.
• Dancing with others has a more positive impact than dancing alone.
• An experiment on university students suggested that dance increases (31) __________.
• For those with mental illness, dance could be used as a form of (32) __________.
Benefits of dance for older people:
• accessible for people with low levels of (33) __________
• reduces the risk of heart disease
• better (34) __________ reduces the risk of accidents
• improves (35) __________ function by making it work faster
• improves participants’ general well-being
• gives people more (36) __________ to take exercise
• can lessen the feeling of (37) __________, very common in older people
Benefits of Zumba:
• A study at The University of Wisconsin showed that doing Zumba for 40 minutes uses up as many (38) __________ as other quite intense forms of exercise.
• The American Journal of Health Behavior study showed that:
– women suffering from (39) __________ benefited from doing Zumba.
– Zumba became a (40) __________ for the participants.
```

[Original question page](assets/1ada7e4f827af2c0b09c053a665b41621a8d3321189e85ffdc867644dbd06b96.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/9fcb0e1c3f4a44df73fd0ae5aa2deaeaf3cd7c598d8ce936d5f2d7be02ef313e.jpg; PDF page 38; full -->

```text
Test 2
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The White Horse of Uffington
The cutting of huge figures or ‘geoglyphs’ into the earth of English hillsides has taken
place for more than 3,000 years. There are 56 hill figures scattered around England, with
the vast majority on the chalk downlands of the country’s southern counties. The figures
include giants, horses, crosses and regimental badges. Although the majority of these
geoglyphs date within the last 300 years or so, there are one or two that are much older.
The most famous of these figures is perhaps also the most mysterious — the Uffington
White Horse in Oxfordshire. The White Horse has recently been re-dated and shown
to be even older than its previously assigned ancient pre-Roman Iron Age* date. More
controversial is the date of the enigmatic Long Man of Wilmington in Sussex. While many
historians are convinced the figure is prehistoric, others believe that it was the work of an
artistic monk from a nearby priory and was created between the 11th and 15th centuries.
The method of cutting these huge figures was simply to remove the overlying grass
to reveal the gleaming white chalk below. However, the grass would soon grow over
the geoglyph again unless it was regularly cleaned or scoured by a fairly large team
of people. One reason that the vast majority of hill figures have disappeared is that
when the traditions associated with the figures faded, people no longer bothered or
remembered to clear away the grass to expose the chalk outline. Furthermore, over
hundreds of years the outlines would sometimes change due to people not always
cutting in exactly the same place, thus creating a different shape to the original
geoglyph. The fact that any ancient hill figures survive at all in England today is
testament to the strength and continuity of local customs and beliefs which, in one case
at least, must stretch back over millennia.
*Iron Age: a period (in Britain 800 BCE — 43 CE) that is characterised by the use of iron tools
38
```

[Original question page](assets/9fcb0e1c3f4a44df73fd0ae5aa2deaeaf3cd7c598d8ce936d5f2d7be02ef313e.jpg)

![Original figure](assets/9fcb0e1c3f4a44df73fd0ae5aa2deaeaf3cd7c598d8ce936d5f2d7be02ef313e.jpg)

<!-- Source: /api/assets/e6fad697645dca8aa176bc4c8b6b4535fee84ed79ecbdb850837122a8e8085aa.jpg; PDF page 39; full -->

```text
Reading
The Uffington White Horse is a unique, stylised representation of a horse consisting of
a long, sleek back, thin disjointed legs, a streaming tail, and a bird-like beaked head.
The elegant creature almost melts into the landscape. The horse is situated 2.5 km from
Uffington village on a steep slope close to the Late Bronze Age* (c. 7th century BCE)
hillfort of Uffington Castle and below the Ridgeway, a long-distance Neolithic** track.
The Uffington Horse is also surrounded by Bronze Age burial mounds. It is not far from
the Bronze Age cemetery of Lambourn Seven Barrows, which consists of more than 30
well-preserved burial mounds. The carving has been placed in such a way as to make it
extremely difficult to see from close quarters, and like many geoglyphs is best appreciated
from the air. Nevertheless, there are certain areas of the Vale of the White Horse, the valley
containing and named after the enigmatic creature, from which an adequate impression
may be gained. Indeed on a clear day the carving can be seen from up to 30 km away.
The earliest evidence of a horse at Uffington is from the 1070s CE when ‘White Horse
Hill’ is mentioned in documents from the nearby Abbey of Abingdon, and the first
reference to the horse itself is soon after, in 1190 CE. However, the carving is believed
to date back much further than that. Due to the similarity of the Uffington White Horse to
the stylised depictions of horses on 1st century BCE coins, it had been thought that the
creature must also date to that period.
However, in 1995 Optically Stimulated Luminescence (OSL) testing was carried out by
the Oxford Archaeological Unit on soil from two of the lower layers of the horse’s body,
and from another cut near the base. The result was a date for the horse’s construction
somewhere between 1400 and 600 BCE — in other words, it had a Late Bronze Age or
Early Iron Age origin.
The latter end of this date range would tie the carving of the horse in with occupation of the
nearby Uffington hillfort, indicating that it may represent a tribal emblem marking the land of
the inhabitants of the hillfort. Alternatively, the carving may have been carried out during a
Bronze or Iron Age ritual. Some researchers see the horse as representing the Celtic*** horse
goddess Epona, who was worshipped as a protector of horses, and for her associations with
fertility. However, the cult of Epona was not imported from Gaul (France) until around the first
century CE. This date is at least six centuries after the Uffington Horse was probably carved.
Nevertheless, the horse had great ritual and economic significance during the Bronze and
Iron Ages, as attested by its depictions on jewellery and other metal objects. It is possible that
the carving represents a goddess in native mythology, such as Rhiannon, described in later
Welsh mythology as a beautiful woman dressed in gold and riding a white horse.
The fact that geoglyphs can disappear easily, along with their associated rituals and meaning,
indicates that they were never intended to be anything more than temporary gestures. But
this does not lessen their importance. These giant carvings are a fascinating glimpse into the
minds of their creators and how they viewed the landscape in which they lived.
*Bronze Age: a period (in Britain c. 2,500 BCE — 800 BCE) that is characterised by the development of bronze tools
**Neolithic: a period (in Britain c. 4,000 BCE — c. 2,500 BCE) that is significant for the spread of agricultural practices, and the use of
stone tools
***Celtic: an ancient people who migrated from Europe to Britain before the Romans
39
```

[Original question page](assets/e6fad697645dca8aa176bc4c8b6b4535fee84ed79ecbdb850837122a8e8085aa.jpg)

<!-- Source: /api/assets/cb8941e7cff0cc27490ebc14365c45d6dae763f5618a2e56d1f427c3d91d0048.jpg; PDF page 40; full -->

```text
Questions 1–8
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1–8 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 Most geoglyphs in England are located in a particular area of the country.
2 There are more geoglyphs in the shape of a horse than any other creature.
3 A recent dating of the Uffington White Horse indicates that people were mistaken about its age.
4 Historians have come to an agreement about the origins of the Long Man of Wilmington.
5 Geoglyphs were created by people placing white chalk on the hillside.
6 Many geoglyphs in England are no longer visible.
7 The shape of some geoglyphs has been altered over time.
8 The fame of the Uffington White Horse is due to its size.
```

[Original question page](assets/cb8941e7cff0cc27490ebc14365c45d6dae763f5618a2e56d1f427c3d91d0048.jpg)

<!-- Source: /api/assets/2c715523180b8946430be1d7df1f473d8459fe50a2ab694932ffba61fae227e8.jpg; PDF page 41; full -->

```text
Questions 9–13
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 9–13 on your answer sheet.
The Uffington White Horse
The location of the Uffington White Horse:
• a distance of 2.5 km from Uffington village
• near an ancient road known as the (9) __________
• close to an ancient cemetery that has a number of burial mounds
Dating the Uffington White Horse:
• first reference to White Horse Hill appears in (10) __________ from the 1070s
• horses shown on coins from the period 100 BCE – 1 BCE are similar in appearance
• according to analysis of the surrounding (11) __________, the Horse is Late Bronze Age / Early Iron Age
Possible reasons for creation of the Uffington White Horse:
• an emblem to indicate land ownership
• formed part of an ancient ritual
• was a representation of goddess Epona – associated with protection of horses and (12) __________
• was a representation of a Welsh goddess called (13) __________
```

[Original question page](assets/2c715523180b8946430be1d7df1f473d8459fe50a2ab694932ffba61fae227e8.jpg)

<!-- Source: /api/assets/89e66f304505a405b0f07e2d443f935001da255d03fad98a95658161f0dc2871.jpg; PDF page 42; full -->

```text
Test 2
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
I contain multitudes
Wendy Moore reviews Ed Yong’s book about microbes
Microbes, most of them bacteria, have populated this planet since long before animal life
developed and they will outlive us. Invisible to the naked eye, they are ubiquitous. They inhabit
the soil, air, rocks and water and are present within every form of life, from seaweed and coral to
dogs and humans. And, as Yong explains in his utterly absorbing and hugely important book, we
mess with them at our peril.
Every species has its own colony of microbes, called a ‘microbiome’, and these microbes
vary not only between species but also between individuals and within different parts of each
individual. What is amazing is that while the number of human cells in the average person is
about 30 trillion, the number of microbial ones is higher — about 39 trillion. At best, Yong informs
us, we are only 50 per cent human. Indeed, some scientists even suggest we should think of each
species and its microbes as a single unit, dubbed a ‘holobiont’.
In each human there are microbes that live only in the stomach, the mouth or the armpit and by
and large they do so peacefully. So ‘bad’ microbes are just microbes out of context. Microbes
that sit contentedly in the human gut (where there are more microbes than there are stars in
the galaxy) can become deadly if they find their way into the bloodstream. These communities
are constantly changing too. The right hand shares just one sixth of its microbes with the left
hand. And, of course, we are surrounded by microbes. Every time we eat, we swallow a million
microbes in each gram of food; we are continually swapping microbes with other humans, pets
and the world at large.
It’s a fascinating topic and Yong, a young British science journalist, is an extraordinarily adept
guide. Writing with lightness and panache, he has a knack of explaining complex science in terms
that are both easy to understand and totally enthralling. Yong is on a mission. Leading us gently
by the hand, he takes us into the world of microbes — a bizarre, alien planet — in a bid to persuade
us to love them as much as he does. By the end, we do.
For most of human history we had no idea that microbes existed. The first man to see these
extraordinarily potent creatures was a Dutch lens-maker called Antony van Leeuwenhoek in the
1670s. Using microscopes of his own design that could magnify up to 270 times, he examined a
drop of water from a nearby lake and found it teeming with tiny creatures he called ‘animalcules’.
It wasn’t until nearly two hundred years later that the research of French biologist Louis Pasteur
indicated that some microbes caused disease. It was Pasteur’s ‘germ theory’ that gave bacteria the
poor image that endures today.
42
```

[Original question page](assets/89e66f304505a405b0f07e2d443f935001da255d03fad98a95658161f0dc2871.jpg)

<!-- Source: /api/assets/df0759d982698f02364899e6054d7bf7083c8a06279422e0abf3434dab0c11ec.jpg; PDF page 43; full -->

```text
Reading
Yong’s book is in many ways a plea for microbial tolerance, pointing out that while fewer
than one hundred species of bacteria bring disease, many thousands more play a vital role in
maintaining our health. The book also acknowledges that our attitude towards bacteria is not
a simple one. We tend to see the dangers posed by bacteria, yet at the same time we are sold
yoghurts and drinks that supposedly nurture ‘friendly’ bacteria. In reality, says Yong, bacteria
should not be viewed as either friends or foes, villains or heroes. Instead we should realise we
have a symbiotic relationship, that can be mutually beneficial or mutually destructive.
What then do these millions of organisms do? The answer is pretty much everything. New
research is now unravelling the ways in which bacteria aid digestion, regulate our immune
systems, eliminate toxins, produce vitamins, affect our behaviour and even combat obesity.
‘They actually help us become who we are,’ says Yong. But we are facing a growing problem.
Our obsession with hygiene, our overuse of antibiotics and our unhealthy, low-fibre diets are
disrupting the bacterial balance and may be responsible for soaring rates of allergies and immune
problems, such as inflammatory bowel disease (IBD).
The most recent research actually turns accepted norms upside down. For example, there are
studies indicating that the excessive use of household detergents and antibacterial products
actually destroys the microbes that normally keep the more dangerous germs at bay. Other studies
show that keeping a dog as a pet gives children early exposure to a diverse range of bacteria,
which may help protect them against allergies later.
The readers of Yong’s book must be prepared for a decidedly unglamorous world. Among the less
appealing case studies is one about a fungus that is wiping out entire populations of frogs and
that can be halted by a rare microbial bacterium. Another is about squid that carry luminescent
bacteria that protect them against predators. However, if you can overcome your distaste for some
of the investigations, the reasons for Yong’s enthusiasm become clear. The microbial world is a
place of wonder. Already, in an attempt to stop mosquitoes spreading dengue fever — a disease
that infects 400 million people a year — mosquitoes are being loaded with a bacterium to block
the disease. In the future, our ability to manipulate microbes means we could construct buildings
with useful microbes built into their walls to fight off infections. Just imagine a neonatal hospital
ward coated in a specially mixed cocktail of microbes so that babies get the best start in life.
43
```

[Original question page](assets/df0759d982698f02364899e6054d7bf7083c8a06279422e0abf3434dab0c11ec.jpg)

<!-- Source: /api/assets/3804fa33f1fc9d8d1eea426de415b203206d171bd5bfb8cc38a46899d7456fe6.jpg; PDF page 44; full -->

```text
Test 2
Questions 14-16
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 14-16 on your answer sheet.
14 What point does the writer make about microbes in the first paragraph?
A They adapt quickly to their environment.
B The risk they pose has been exaggerated.
C They are more plentiful in animal life than plant life.
D They will continue to exist for longer than the human race.
15 In the second paragraph, the writer is impressed by the fact that
A each species tends to have vastly different microbes.
B some parts of the body contain relatively few microbes.
C the average individual has more microbial cells than human ones.
D scientists have limited understanding of how microbial cells behave.
16 What is the writer doing in the fifth paragraph?
A explaining how a discovery was made
B comparing scientists’ theories about microbes
C describing confusion among scientists
D giving details of how microbes cause disease
44
```

[Original question page](assets/3804fa33f1fc9d8d1eea426de415b203206d171bd5bfb8cc38a46899d7456fe6.jpg)

<!-- Source: /api/assets/86ec7697d06002f9c8d4ccabbb47a02d55fe1150d9680bf19bd29729ea4b40bc.jpg; PDF page 45; full -->

```text
Questions 17–20
Complete the summary using the list of words, A–H, below.
Write the correct letter, A–H, in boxes 17–20 on your answer sheet.
We should be more tolerant of microbes
Yong’s book argues that we should be more tolerant of microbes. Many have a beneficial effect, and only a relatively small number lead to (17) __________. And although it is misleading to think of microbes as ‘friendly’, we should also stop thinking of them as the enemy. In fact, we should accept that our relationship with microbes is one based on (18) __________.
New research shows that microbes have numerous benefits for humans. Amongst other things, they aid digestion, remove poisons, produce vitamins and may even help reduce obesity. However, there is a growing problem. Our poor (19) __________, our overuse of antibiotics, and our excessive focus on (20) __________ are upsetting the bacterial balance and may be contributing to the huge increase in allergies and immune system problems.
A solution
B partnership
C destruction
D exaggeration
E cleanliness
F regulations
G illness
H nutrition
```

[Original question page](assets/86ec7697d06002f9c8d4ccabbb47a02d55fe1150d9680bf19bd29729ea4b40bc.jpg)

<!-- Source: /api/assets/b54df3707f8c78cde65a7471052218f6eabf6508392e6fda132951857be18e87.jpg; PDF page 46; full -->

```text
Test 2
Questions 21-26
Do the following statements agree with the claims of the writer in Reading Passage 2?
In boxes 21-26 on your answer sheet, write






46
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
21 It is possible that using antibacterial products in the home fails to have the desired
effect.
22 It is a good idea to ensure that children come into contact with as few bacteria as
possible.
23 Yong’s book contains more case studies than are necessary.
24 The case study about bacteria that prevent squid from being attacked may have
limited appeal.
25 Efforts to control dengue fever have been surprisingly successful.
26 Microbes that reduce the risk of infection have already been put inside the walls of
some hospital wards.
>/Q p. 124
```

[Original question page](assets/b54df3707f8c78cde65a7471052218f6eabf6508392e6fda132951857be18e87.jpg)

<!-- Source: /api/assets/443162258818955bfeee0eecacad5bd76ea6e70b6bd24d0e59d85cd3e0803169.jpg; PDF page 47; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
How to make wise decisions
Across cultures, wisdom has been considered one of the most revered human qualities. Although
the truly wise may seem few and far between, empirical research examining wisdom suggests
that it isn’t an exceptional trait possessed by a small handful of bearded philosophers after all — in
fact, the latest studies suggest that most of us have the ability to make wise decisions, given the
right context.
‘It appears that experiential, situational, and cultural factors are even more powerful in shaping
wisdom than previously imagined,’ says Associate Professor Igor Grossmann of the University
of Waterloo in Ontario, Canada. ‘Recent empirical findings from cognitive, developmental,
social, and personality psychology cumulatively suggest that people’s ability to reason wisely
varies dramatically across experiential and situational contexts. Understanding the role of such
contextual factors offers unique insights into understanding wisdom in daily life, as well as how it
can be enhanced and taught.’
It seems that it’s not so much that some people simply possess wisdom and others lack it, but
that our ability to reason wisely depends on a variety of external factors. ‘It is impossible to
characterize thought processes attributed to wisdom without considering the role of contextual
factors,’ explains Grossmann. ‘In other words, wisdom is not solely an “inner quality” but rather
unfolds as a function of situations people happen to be in. Some situations are more likely to
promote wisdom than others.”
Coming up with a definition of wisdom is challenging, but Grossmann and his colleagues have
identified four key characteristics as part of a framework of wise reasoning. One is intellectual
humility or recognition of the limits of our own knowledge, and another is appreciation of
perspectives wider than the issue at hand. Sensitivity to the possibility of change in social
relations is also key, along with compromise or integration of different attitudes and beliefs.
Grossmann and his colleagues have also found that one of the most reliable ways to support
wisdom in our own day-to-day decisions is to look at scenarios from a third-party perspective, as
though giving advice to a friend. Research suggests that when adopting a first-person viewpoint
we focus on ‘the focal features of the environment’ and when we adopt a third-person, ‘observer’
viewpoint we reason more broadly and focus more on interpersonal and moral ideals such as
justice and impartiality. Looking at problems from this more expansive viewpoint appears to
foster cognitive processes related to wise decisions.
47
```

[Original question page](assets/443162258818955bfeee0eecacad5bd76ea6e70b6bd24d0e59d85cd3e0803169.jpg)

<!-- Source: /api/assets/6c4ff05fda57cd5a61cef1b31b0e02263293fd75771a90d1a79eb4968d7329bc.jpg; PDF page 48; full -->

```text
Test 2
What are we to do, then, when confronted with situations like a disagreement with a spouse or
negotiating a contract at work, that require us to take a personal stake? Grossmann argues that
even when we aren’t able to change the situation, we can still evaluate these experiences from
different perspectives.
For example, in one experiment that took place during the peak of a recent economic recession,
graduating college seniors were asked to reflect on their job prospects. The students were
instructed to imagine their career either ‘as if you were a distant observer’ or ‘before your own
eyes as if you were right there’. Participants in the group assigned to the ‘distant observer’ role
displayed more wisdom-related reasoning (intellectual humility and recognition of change) than
did participants in the control group.
In another study, couples in long-term romantic relationships were instructed to visualize
an unresolved relationship conflict either through the eyes of an outsider or from their own
perspective. Participants then discussed the incident with their partner for 10 minutes, after which
they wrote down their thoughts about it. Couples in the ‘other’s eyes’ condition were significantly
more likely to rely on wise reasoning — recognizing others’ perspectives and searching for a
compromise — compared to the couples in the egocentric condition.
“Ego-decentering promotes greater focus on others and enables a bigger picture, conceptual view
of the experience, affording recognition of intellectual humility and change,’ says Grossmann.
We might associate wisdom with intelligence or particular personality traits, but research shows
only a small positive relationship between wise thinking and crystallized intelligence and the
personality traits of openness and agreeableness. ‘It is remarkable how much people can vary in
their wisdom from one situation to the next, and how much stronger such contextual effects are
for understanding the relationship between wise judgment and its social and affective outcomes as
compared to the generalized “traits”, Grossmann explains. ‘That is, knowing how wisely a person
behaves in a given situation is more informative for understanding their emotions or likelihood to
forgive [or] retaliate as compared to knowing whether the person may be wise “in general”.’
48
```

[Original question page](assets/6c4ff05fda57cd5a61cef1b31b0e02263293fd75771a90d1a79eb4968d7329bc.jpg)

<!-- Source: /api/assets/69e40ffafe540c15acadebd1d781409bb19bd1672d9ac04ac1cd063e1256132a.jpg; PDF page 49; full -->

```text
Reading
Questions 27-30
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-30 on your answer sheet.




27 What point does the writer make in the first paragraph?
A Wisdom appears to be unique to the human race.
B A basic assumption about wisdom may be wrong.
C Concepts of wisdom may depend on the society we belong to.
D There is still much to be discovered about the nature of wisdom.
28 What does Igor Grossmann suggest about the ability to make wise decisions?
A It can vary greatly from one person to another.
B Earlier research into it was based on unreliable data.
C The importance of certain influences on it was underestimated.
D Various branches of psychology define it according to their own criteria.
29 According to the third paragraph, Grossmann claims that the level of wisdom an
individual shows
A can be greater than they think it is.
B will be different in different circumstances.
C may be determined by particular aspects of their personality.
D should develop over time as a result of their life experiences.
30 What is described in the fifth paragraph?
A a difficulty encountered when attempting to reason wisely
B an example of the type of person who is likely to reason wisely
C a controversial view about the benefits of reasoning wisely
D a recommended strategy that can help people to reason wisely
```

[Original question page](assets/69e40ffafe540c15acadebd1d781409bb19bd1672d9ac04ac1cd063e1256132a.jpg)

<!-- Source: /api/assets/e7859dc9473a15068572c2aecf45a1e6a8e7de0997bc689d8862cb4fc581c8bb.jpg; PDF page 50; full -->

```text
Questions 31–35
Complete the summary using the list of words, A–J, below.
Write the correct letter, A–J, in boxes 31–35 on your answer sheet.
The characteristics of wise reasoning
Igor Grossmann and colleagues have established four characteristics which enable us to make wise decisions. It is important to have a certain degree of (31) __________ regarding the extent of our knowledge, and to take into account (32) __________ which may not be the same as our own. We should also be able to take a broad (33) __________ of any situation. Another key characteristic is being aware of the likelihood of alterations in the way that people relate to each other.
Grossmann also believes that it is better to regard scenarios with (34) __________. By avoiding the first-person perspective, we focus more on (35) __________ and on other moral ideals, which in turn leads to wiser decision-making.
A opinions
B confidence
C view
D modesty
E problems
F objectivity
G fairness
H experiences
I range
J reasons
```

[Original question page](assets/e7859dc9473a15068572c2aecf45a1e6a8e7de0997bc689d8862cb4fc581c8bb.jpg)

<!-- Source: /api/assets/065c9ce3442c2c498c9cd8f984671da8fa322a747647e40612ed1f758c89e443.jpg; PDF page 51; full -->

```text
Reading
Questions 36-40
Do the following statements agree with the information given in Reading Passage 3?
In boxes 36-40 on your answer sheet, write





TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
36 Students participating in the job prospects experiment could choose one of two
perspectives to take.
37 Participants in the couples experiment were aware that they were taking part in a
study about wise reasoning.
38 In the couples experiments, the length of the couples’ relationships had an impact
on the results.
39 In both experiments, the participants who looked at the situation from a more
detached viewpoint tended to make wiser decisions.
40 Grossmann believes that a person’s wisdom is determined by their intelligence to
only a very limited extent.
>/@ p.124) 51
```

[Original question page](assets/065c9ce3442c2c498c9cd8f984671da8fa322a747647e40612ed1f758c89e443.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/57bda374890d11d2b5616acf27e2c8dc7d944092f92135680ee45e9c9cd53a1d.jpg; PDF page 52; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagram below shows the manufacturing process for making sugar from sugar cane.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

Figure: How sugar is produced from sugar cane.
See the retained original diagram for its labelled stages or spatial layout.
```

[Original question page](assets/57bda374890d11d2b5616acf27e2c8dc7d944092f92135680ee45e9c9cd53a1d.jpg)

![Original figure](assets/57bda374890d11d2b5616acf27e2c8dc7d944092f92135680ee45e9c9cd53a1d.jpg)

### Task 2

<!-- Source: /api/assets/b1c1e7b2c93382ba7c72b0dba3a5c9c7ff825706594f6613e95a6b0803625340.jpg; PDF page 53; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In their advertising, businesses nowadays usually emphasise that their products are new in some way.

Why is this? Do you think it is a positive or negative development?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/b1c1e7b2c93382ba7c72b0dba3a5c9c7ff825706594f6613e95a6b0803625340.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/501934ec621f79c7d2eeebda7b362bb6592ba2b0dd50ead3ee157fdc87d77d88.jpg; PDF page 54; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Flowers and plants
Do you have a favourite flower or plant? [Why/Why not?]
What kinds of flowers and plants grow near where you live? [Why/Why not?]
Is it important to you to have flowers and plants in your home? [Why/Why not?]
Have you ever bought flowers for someone else? [Why/Why not?]
PART 2
Describe a review you read about a product or service.
You should say:
where you read the review
what the product or service was
what information the review gave about the product or service
and explain what you did as a result of reading this review.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Online reviews
Example questions:
What kinds of things do people write online reviews about in your country?
Why do some people write online reviews?
Do you think that online reviews are good for both shoppers and companies?
Customer service
Example questions:
What do you think it might be like to work in a customer service job?
Do you agree that customers are more likely to complain nowadays?
How important is it for companies to take all customer complaints seriously?
54
```

[Original question page](assets/501934ec621f79c7d2eeebda7b362bb6592ba2b0dd50ead3ee157fdc87d77d88.jpg)

### Part 2

<!-- Source: /api/assets/501934ec621f79c7d2eeebda7b362bb6592ba2b0dd50ead3ee157fdc87d77d88.jpg; PDF page 54; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Flowers and plants
Do you have a favourite flower or plant? [Why/Why not?]
What kinds of flowers and plants grow near where you live? [Why/Why not?]
Is it important to you to have flowers and plants in your home? [Why/Why not?]
Have you ever bought flowers for someone else? [Why/Why not?]
PART 2
Describe a review you read about a product or service.
You should say:
where you read the review
what the product or service was
what information the review gave about the product or service
and explain what you did as a result of reading this review.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Online reviews
Example questions:
What kinds of things do people write online reviews about in your country?
Why do some people write online reviews?
Do you think that online reviews are good for both shoppers and companies?
Customer service
Example questions:
What do you think it might be like to work in a customer service job?
Do you agree that customers are more likely to complain nowadays?
How important is it for companies to take all customer complaints seriously?
54
```

[Original question page](assets/501934ec621f79c7d2eeebda7b362bb6592ba2b0dd50ead3ee157fdc87d77d88.jpg)

### Part 3

<!-- Source: /api/assets/501934ec621f79c7d2eeebda7b362bb6592ba2b0dd50ead3ee157fdc87d77d88.jpg; PDF page 54; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Flowers and plants
Do you have a favourite flower or plant? [Why/Why not?]
What kinds of flowers and plants grow near where you live? [Why/Why not?]
Is it important to you to have flowers and plants in your home? [Why/Why not?]
Have you ever bought flowers for someone else? [Why/Why not?]
PART 2
Describe a review you read about a product or service.
You should say:
where you read the review
what the product or service was
what information the review gave about the product or service
and explain what you did as a result of reading this review.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Online reviews
Example questions:
What kinds of things do people write online reviews about in your country?
Why do some people write online reviews?
Do you think that online reviews are good for both shoppers and companies?
Customer service
Example questions:
What do you think it might be like to work in a customer service job?
Do you agree that customers are more likely to complain nowadays?
How important is it for companies to take all customer complaints seriously?
54
```

[Original question page](assets/501934ec621f79c7d2eeebda7b362bb6592ba2b0dd50ead3ee157fdc87d77d88.jpg)
