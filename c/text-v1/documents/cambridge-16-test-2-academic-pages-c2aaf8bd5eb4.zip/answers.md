# 剑雅 16 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 123

TEST 2 LISTENING
1 frame
2 195
3 payment
4 Grandparents
5 colour / color
6 hand
7 background
8 focus
9 ten / 10 days
10 plastic
11 C
12 B
13 A
14 A
15 C
16 D
17 A
18 B
19 B
20 C
21 B
22 A
23 C
24 C
25 history
26 paper
27 humans / people
28 stress
29 graph
30 evaluate
31 creativity
32 therapy
33 fitness
34 balance
35 brain
36 motivation
37 isolation
38 calories
39 obesity
40 habit
19&20 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. frame

2. 195

3. payment

4. Grandparents

5. colour / color

6. hand

7. background

8. focus

9. ten days / 10 days

10. plastic

### Part 2 · source page 123

TEST 2 LISTENING
1 frame
2 195
3 payment
4 Grandparents
5 colour / color
6 hand
7 background
8 focus
9 ten / 10 days
10 plastic
11 C
12 B
13 A
14 A
15 C
16 D
17 A
18 B
19 B
20 C
21 B
22 A
23 C
24 C
25 history
26 paper
27 humans / people
28 stress
29 graph
30 evaluate
31 creativity
32 therapy
33 fitness
34 balance
35 brain
36 motivation
37 isolation
38 calories
39 obesity
40 habit
19&20 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. C

12. B

13. A

14. A

15. C

16. D

17. A

18. B

19. B / C

20. B / C

### Part 3 · source page 123

TEST 2 LISTENING
1 frame
2 195
3 payment
4 Grandparents
5 colour / color
6 hand
7 background
8 focus
9 ten / 10 days
10 plastic
11 C
12 B
13 A
14 A
15 C
16 D
17 A
18 B
19 B
20 C
21 B
22 A
23 C
24 C
25 history
26 paper
27 humans / people
28 stress
29 graph
30 evaluate
31 creativity
32 therapy
33 fitness
34 balance
35 brain
36 motivation
37 isolation
38 calories
39 obesity
40 habit
19&20 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B

22. A

23. C

24. C

25. history

26. paper

27. humans / people

28. stress

29. graph

30. evaluate

### Part 4 · source page 123

TEST 2 LISTENING
1 frame
2 195
3 payment
4 Grandparents
5 colour / color
6 hand
7 background
8 focus
9 ten / 10 days
10 plastic
11 C
12 B
13 A
14 A
15 C
16 D
17 A
18 B
19 B
20 C
21 B
22 A
23 C
24 C
25 history
26 paper
27 humans / people
28 stress
29 graph
30 evaluate
31 creativity
32 therapy
33 fitness
34 balance
35 brain
36 motivation
37 isolation
38 calories
39 obesity
40 habit
19&20 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. creativity

32. therapy

33. fitness

34. balance

35. brain

36. motivation

37. isolation

38. calories

39. obesity

40. habit

## A 类阅读

### Academic Reading · source page 124

TEST 2 READING
1 TRUE
2 NOT GIVEN
3 TRUE
4 FALSE
5 FALSE
6 TRUE
7 TRUE
8 NOT GIVEN
9 Ridgeway
10 documents
11 soil
12 fertility
13 Rhiannon
14 D
15 C
16 A
17 G
18 B
19 H
20 E
21 YES
22 NO
23 NOT GIVEN
24 YES
25 NOT GIVEN
26 NO
27 B
28 C
29 B
30 D
31 D
32 A
33 C
34 F
35 G
36 FALSE
37 NOT GIVEN
38 NOT GIVEN
39 TRUE
40 TRUE
If you score: 1–17 unlikely;18–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. TRUE

2. NOT GIVEN

3. TRUE

4. FALSE

5. FALSE

6. TRUE

7. TRUE

8. NOT GIVEN

9. Ridgeway

10. documents

11. soil

12. fertility

13. Rhiannon

14. D

15. C

16. A

17. G

18. B

19. H

20. E

21. YES

22. NO

23. NOT GIVEN

24. YES

25. NOT GIVEN

26. NO

27. B

28. C

29. B

30. D

31. D

32. A

33. C

34. F

35. G

36. FALSE

37. NOT GIVEN

38. NOT GIVEN

39. TRUE

40. TRUE

## A 类写作

### Writing material: c16-t2-w-1

Directly inspected the original process diagram. Seven numbered stages: 1 growing sugar cane for 12–18 months; 2 harvesting, with two alternative methods shown, a harvesting machine or manual cutting; 3 crushing cane in a machine to extract juice; 4 purifying the juice through a limestone filter; 5 heating it in an evaporator so the juice becomes syrup; 6 a centrifuge separates sugar crystals from the syrup; 7 drying and cooling produces sugar. The two harvesting alternatives converge at crushing. Sequence starts with cultivation and ends with dry cooled sugar. No other temperatures, quantities or process durations are given.



### Writing material: c16-t2-w-2

Explain why advertisers emphasise novelty and evaluate that emphasis. Both requirements matter; not every product needs to be a wholly new invention.



## 口语
