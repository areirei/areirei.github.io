# 剑雅 14 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/da7be207a20d9b3b4894bc905cac26b401b1cd2fda8902f62b8bde9865e548d7.jpg; PDF page 75; full -->

```text
SECTION 1 Questions 1–10
Questions 1–7
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Enquiry about booking hotel room for event
Example Andrew is the Events Manager
Rooms
Adelphi Room
number of people who can sit down to eat: (1) __________
has a gallery suitable for musicians
can go out and see the (2) __________ in pots on the terrace
terrace has a view of a group of (3) __________
Carlton Room
number of people who can sit down to eat: 110
has a (4) __________
view of the lake
Options
Master of Ceremonies:
can give a (5) __________ while people are eating
will provide (6) __________ if there are any problems
Accommodation:
in hotel rooms or (7) __________
```

[Original question page](assets/da7be207a20d9b3b4894bc905cac26b401b1cd2fda8902f62b8bde9865e548d7.jpg)

<!-- Source: /api/assets/922b25cf5b1f6f57e193494ad3803366fa74fd3088bd1ecdddd67233c851b481.jpg; PDF page 76; full -->

```text
Test 4
Questions 8-10
What is said about using each of the following hotel facilities?
Choose THREE answers from the box and write the correct letter, A, B or C, next to
Questions 8-10.
Availability
A  included in cost of hiring room
B available at extra charge
C not available
Hotel facilities
8  outdoor swimming pool
9 gym
10 tennis courts
76
```

[Original question page](assets/922b25cf5b1f6f57e193494ad3803366fa74fd3088bd1ecdddd67233c851b481.jpg)

### Part 2

<!-- Source: /api/assets/6fe2a51f368a0f46f64a41731cf7b2a57d6f9ccaa8efd54f47616551cbd84fe2.jpg; PDF page 77; full -->

```text
SECTION 2 Questions 11–20
Questions 11–16
What information does the speaker give about each of the following excursions?
Choose SIX answers from the box and write the correct letter, A–H, next to Questions 11–16.
Information
A all downhill
B suitable for beginners
C only in good weather
D food included
E no charge
F swimming possible
G fully booked today
H transport not included
Excursions
11 dolphin watching __________
12 forest walk __________
13 cycle trip __________
14 local craft tour __________
15 observatory trip __________
16 horse riding __________
```

[Original question page](assets/6fe2a51f368a0f46f64a41731cf7b2a57d6f9ccaa8efd54f47616551cbd84fe2.jpg)

<!-- Source: /api/assets/7a4ca7e5b6b51f3f89ef3a38f13c6f3a8c3c8202af9cf8145bc7f3dbd123e3f0.jpg; PDF page 78; full -->

```text
Questions 17 and 18
Choose TWO letters, A–E.
Which TWO things does the speaker say about the attraction called Musical Favourites?
A You pay extra for drinks.
B You must book it in advance.
C You get a reduction if you buy two tickets.
D You can meet the performers.
E You can take part in the show.
Questions 19 and 20
Choose TWO letters, A–E.
Which TWO things does the speaker say about the Castle Feast?
A Visitors can dance after the meal.
B There is a choice of food.
C Visitors wear historical costume.
D Knives and forks are not used.
E The entertainment includes horse races.
```

[Original question page](assets/7a4ca7e5b6b51f3f89ef3a38f13c6f3a8c3c8202af9cf8145bc7f3dbd123e3f0.jpg)

### Part 3

<!-- Source: /api/assets/a68514f95bd767dbbfedc4db2b27f5b5c7f4057134660b2603ae9267364c4284.jpg; PDF page 79; full -->

```text
Listening
SECTION 3 Questions 21-30
Questions 21-25
Choose the correct letter, A, B or C.





21 What does Trevor find interesting about the purpose of children’s literature?
A  the fact that authors may not realise what values they're teaching
B the fact that literature can be entertaining and educational at the same time
C the fact that adults expect children to imitate characters in literature
22 Trevor says the module about the purpose of children’s literature made him
A analyse some of the stories that his niece reads.
B  wonder how far popularity reflects good quality.
C  decide to start writing some children’s stories.
23 Stephanie is interested in the Pictures module because
A she intends to become an illustrator.
B she can remember beautiful illustrations from her childhood.
C she believes illustrations are more important than words.
24 Trevor and Stephanie agree that comics
A are inferior to books.
B have the potential for being useful.
C discourage children from using their imagination.
25 With regard to books aimed at only boys or only girls, Trevor was surprised
A how long the distinction had gone unquestioned.
B _ how few books were aimed at both girls and boys.
C how many children enjoyed books intended for the opposite sex.
79
```

[Original question page](assets/a68514f95bd767dbbfedc4db2b27f5b5c7f4057134660b2603ae9267364c4284.jpg)

<!-- Source: /api/assets/f6b477cd18e12ad5061b8a6c9d13434da1ae2b25eb99af7eebda8eaaf9861ca8.jpg; PDF page 80; full -->

```text
Test 4
Questions 26-30
What comment is made about each of these stories?
Choose FIVE answers from the box and write the correct letter, A-G, next to
Questions 26-30.
Comments
A translated into many other languages
B hard to read
C inspired a work in a different area of art
D more popular than the author’s other works
E original title refers to another book
F started a new genre
G unlikely topic
Stories
26 Perrault’s fairy tales __________
27 The Swiss Family Robinson __________
28 The Nutcracker and The Mouse King __________
29 The Lord of the Rings __________
30 War Horse __________
```

[Original question page](assets/f6b477cd18e12ad5061b8a6c9d13434da1ae2b25eb99af7eebda8eaaf9861ca8.jpg)

### Part 4

<!-- Source: /api/assets/1da8241733ac324226ffe3800b7ee4568e6d2f8cc04ff3d52f6a201025e1ee89.jpg; PDF page 81; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
The hunt for sunken settlements and ancient shipwrecks
ATLIT-YAM
• was a village on coast of eastern Mediterranean
• thrived until about 7,000 BC
• stone homes had a courtyard
• had a semicircle of large stones round a (31) __________
• cause of destruction unknown — now under the sea
• biggest settlement from the prehistoric period found on the seabed
• research carried out into structures, (32) __________ and human remains
TRADITIONAL AUTONOMOUS UNDERWATER VEHICLES (AUVs)
• used in the oil industry, e.g. to make (33) __________
• problems: they were expensive and (34) __________
LATEST AUVs
• much easier to use, relatively cheap, sophisticated
Tests:
• Marzamemi, Sicily: found ancient Roman ships carrying architectural elements made of (35) __________
Underwater internet:
• (36) __________ is used for short distance communication, acoustic waves for long distance
• plans for communication with researchers by satellite
• AUV can send data to another AUV that has better (37) __________, for example
Planned research in Gulf of Baratti:
• to find out more about wrecks of ancient Roman ships, including
– one carrying (38) __________ supplies; tablets may have been used for cleaning the (39) __________
– others carrying containers of olive oil or (40) __________
```

[Original question page](assets/1da8241733ac324226ffe3800b7ee4568e6d2f8cc04ff3d52f6a201025e1ee89.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/100f40df57bdbcf5dd00714c4b6d305635093a897f08ce845d8bb9e93bf22a2d.jpg; PDF page 82; full -->

```text
Test 4
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The secret of staying young
Pheidole dentata, a native ant of the south-eastern U.S., isn’t immortal. But scientists have found
that it doesn’t seem to show any signs of aging. Old worker ants can do everything just as well as
the youngsters, and their brains appear just as sharp. ‘We get a picture that these ants really don’t
decline,’ says Ysabel Giraldo, who studied the ants for her doctoral thesis at Boston University.
Such age-defying feats are rare in the animal kingdom. Naked mole rats can live for almost
30 years and stay fit for nearly their entire lives. They can still reproduce even when old, and they
never get cancer. But the vast majority of animals deteriorate with age just like people do. Like
the naked mole rat, ants are social creatures that usually live in highly organised colonies. ‘It’s
this social complexity that makes P. dentata useful for studying aging in people,’ says Giraldo,
now at the California Institute of Technology. Humans are also highly social, a trait that has been
connected to healthier aging. By contrast, most animal studies of aging use mice, worms or fruit
flies, which all lead much more isolated lives.
In the lab, P. dentata worker ants typically live for around 140 days. Giraldo focused on ants
at four age ranges: 20 to 22 days, 45 to 47 days, 95 to 97 days and 120 to 122 days. Unlike all
previous studies, which only estimated how old the ants were, her work tracked the ants from the
time the pupae became adults, so she knew their exact ages. Then she put them through a range
of tests.
Giraldo watched how well the ants took care of the young of the colony, recording how often each
ant attended to, carried and fed them. She compared how well 20-day-old and 95-day-old ants
followed the telltale scent that the insects usually leave to mark a trail to food. She tested how
ants responded to light and also measured how active they were by counting how often ants in a
small dish walked across a line. And she experimented with how ants react to live prey: a tethered
fruit fly. Giraldo expected the older ants to perform poorly in all these tasks. But the elderly
insects were all good caretakers and trail-followers—the 95-day-old ants could track the scent
even longer than their younger counterparts. They all responded to light well, and the older ants
were more active. And when it came to reacting to prey, the older ants attacked the poor fruit fly
just as aggressively as the young ones did, flaring their mandibles or pulling at the fly’s legs.
Then Giraldo compared the brains of 20-day-old and 95-day-old ants, identifying any cells that
were close to death. She saw no major differences with age, nor was there any difference in the
location of the dying cells, showing that age didn’t seem to affect specific brain functions. Ants
and other insects have structures in their brains called mushroom bodies, which are important for
82
```

[Original question page](assets/100f40df57bdbcf5dd00714c4b6d305635093a897f08ce845d8bb9e93bf22a2d.jpg)

<!-- Source: /api/assets/98142d1aa603d4bf10007c5ee44a3bc09a3257386cb033547159013ae88e548e.jpg; PDF page 83; full -->

```text
processing information, learning and memory. She also wanted to see if aging affects the density of synaptic complexes within these structures—regions where neurons come together. Again, the answer was no. What was more, the old ants didn’t experience any drop in the levels of either serotonin or dopamine—brain chemicals whose decline often coincides with aging. In humans, for example, a decrease in serotonin has been linked to Alzheimer’s disease.
‘This is the first time anyone has looked at both behavioral and neural changes in these ants so thoroughly,’ says Giraldo, who recently published the findings in the Proceedings of the Royal Society B. Scientists have looked at some similar aspects in bees, but the results of recent bee studies were mixed—some studies showed age-related declines, which biologists call senescence, and others didn’t. ‘For now, the study raises more questions than it answers,’ Giraldo says, ‘including how P. dentata stays in such good shape.’
Also, if the ants don’t deteriorate with age, why do they die at all? Out in the wild, the ants probably don’t live for a full 140 days thanks to predators, disease and just being in an environment that’s much harsher than the comforts of the lab. ‘The lucky ants that do live into old age may suffer a steep decline just before dying,’ Giraldo says, but she can’t say for sure because her study wasn’t designed to follow an ant’s final moments.
‘It will be important to extend these findings to other species of social insects,’ says Gene E. Robinson, an entomologist at the University of Illinois at Urbana-Champaign. This ant might be unique, or it might represent a broader pattern among other social bugs with possible clues to the science of aging in larger animals. Either way, it seems that for these ants, age really doesn’t matter.
```

[Original question page](assets/98142d1aa603d4bf10007c5ee44a3bc09a3257386cb033547159013ae88e548e.jpg)

<!-- Source: /api/assets/ece949c07b8141b09bbeb7738286e55b2015fbb6deb7209e1fe10634b6dfbe83.jpg; PDF page 84; full -->

```text
Questions 1–8
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answer in boxes 1–8 on your answer sheet.
Ysabel Giraldo’s research
Focused on a total of (1) __________ different age groups of ants, analysing
Behaviour:
• how well ants looked after their (2) __________
• their ability to locate (3) __________ using a scent trail
• the effect that (4) __________ had on them
• how (5) __________ they attacked prey
Brains:
• comparison between age and the (6) __________ of dying cells in the brains of ants
• condition of synaptic complexes (areas in which (7) __________ meet) in the brain’s ‘mushroom bodies’
• level of two (8) __________ in the brain associated with ageing
```

[Original question page](assets/ece949c07b8141b09bbeb7738286e55b2015fbb6deb7209e1fe10634b6dfbe83.jpg)

<!-- Source: /api/assets/f5863d4329d6f0f27a1b3895fae8f1f64e96edd981bc42539a537ca8d674b2b1.jpg; PDF page 85; full -->

```text
Reading
Questions 9-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 9-13 on your answer sheet, write




TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN _ if there is no information on this
9 Pheidole dentata ants are the only known animals which remain active for almost
their whole lives.
10 Ysabel Giraldo was the first person to study Pheidole dentata ants using precise
data about the insects’ ages.
11 The ants in Giraldo’s experiments behaved as she had predicted that they would.
12 The recent studies of bees used different methods of measuring age-
related decline.
13 Pheidole dentata ants kept in laboratory conditions tend to live longer lives.
85
```

[Original question page](assets/f5863d4329d6f0f27a1b3895fae8f1f64e96edd981bc42539a537ca8d674b2b1.jpg)

<!-- Source: /api/assets/173079ab8c690294ec070e400302a8473607026e13165719fa83b480026cd3d3.jpg; PDF page 86; full -->

```text
Test 4
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Why zoos are good
Scientist David Hone makes the case for zoos
A In my view, it is perfectly possible for many species of animals living in zoos
or wildlife parks to have a quality of life as high as, or higher than, in the wild.
Animals in good zoos get a varied and high-quality diet with all the supplements
required, and any illnesses they might have will be treated. Their movement might
be somewhat restricted, but they have a safe environment in which to live, and
they are spared bullying and social ostracism by others of their kind. They do not
suffer from the threat or stress of predators, or the irritation and pain of parasites or
injuries. The average captive animal will have a greater life expectancy compared
with its wild counterpart, and will not die of drought, of starvation or in the jaws of
a predator. A lot of very nasty things happen to truly ‘wild’ animals that simply don’t
happen in good zoos, and to view a life that is ‘free’ as one that is automatically
‘good’ is, I think, an error. Furthermore, zoos serve several key purposes.
B Firstly, zoos aid conservation. Colossal numbers of species are becoming extinct
across the world, and many more are increasingly threatened and therefore risk
extinction. Moreover, some of these collapses have been sudden, dramatic and
unexpected, or were simply discovered very late in the day. A species protected
in captivity can be bred up to provide a reservoir population against a population
crash or extinction in the wild. A good number of species only exist in captivity, with
many of these living in zoos. Still more only exist in the wild because they have
been reintroduced from zoos, or have wild populations that have been boosted
by captive bred animals. Without these efforts there would be fewer species alive
today. Although reintroduction successes are few and far between, the numbers
are increasing, and the very fact that species have been saved or reintroduced as a
result of captive breeding proves the value of such initiatives.
C Zoos also provide education. Many children and adults, especially those in cities,
will never see a wild animal beyond a fox or pigeon. While it is true that television
documentaries are becoming ever more detailed and impressive, and many
natural history specimens are on display in museums, there really is nothing to
compare with seeing a living creature in the flesh, hearing it, smelling it, watching
what it does and having the time to absorb details. That alone will bring a greater
understanding and perspective to many, and hopefully give them a greater
appreciation for wildlife, conservation efforts and how they can contribute.
```

[Original question page](assets/173079ab8c690294ec070e400302a8473607026e13165719fa83b480026cd3d3.jpg)

<!-- Source: /api/assets/d2bad0a99fa06e387bddd581b887e13331f42101a0f92a057bbf973d303be640.jpg; PDF page 87; full -->

```text
Reading
D In addition to this, there is also the education that can take place in zoos through
signs, talks and presentations which directly communicate information to visitors
about the animals they are seeing and their place in the world. This was an area
where zoos used to be lacking, but they are now increasingly sophisticated in
their communication and outreach work. Many zoos also work directly to educate
conservation workers in other countries, or send their animal keepers abroad
to contribute their knowledge and skills to those working in zoos and reserves,
thereby helping to improve conditions and reintroductions all over the world.
E Zoos also play a key role in research. If we are to save wild species and restore
and repair ecosystems we need to know about how key species live, act and react.
Being able to undertake research on animals in zoos where there is less risk and
fewer variables means real changes can be effected on wild populations. Finding
out about, for example, the oestrus cycle of an animal or its breeding rate helps
us manage wild populations. Procedures such as capturing and moving at-risk or
dangerous individuals are bolstered by knowledge gained in zoos about doses for
anaesthetics, and by experience in handling and transporting animals. This can
make a real difference to conservation efforts and to the reduction of human-animal
conflicts, and can provide a knowledge base for helping with the increasing threats
of habitat destruction and other problems.
F In conclusion, considering the many ongoing global threats to the environment, it is
hard for me to see zoos as anything other than essential to the long-term survival
of numerous species. They are vital not just in terms of protecting animals, but as
a means of learning about them to aid those still in the wild, as well as educating
and informing the general population about these animals and their world so that
they can assist or at least accept the need to be more environmentally conscious.
Without them, the world would be, and would increasingly become, a much
poorer place.
87
```

[Original question page](assets/d2bad0a99fa06e387bddd581b887e13331f42101a0f92a057bbf973d303be640.jpg)

<!-- Source: /api/assets/124e5cfaf9c9a04a93dc7da74b6af4bac35bfca43fb51099571ecc15fb9a551e.jpg; PDF page 88; full -->

```text
Test 4
Questions 14-17
Reading Passage 2 has six paragraphs, A-F.
Which paragraph contains the following information?
Write the correct letter, A-F, in boxes 14-17 on your answer sheet.
14 a reference to how quickly animal species can die out
15 reasons why it is preferable to study animals in captivity rather than in the wild
16 mention of two ways of learning about animals other than visiting them in zoos
17 reasons why animals in zoos may be healthier than those in the wild
Questions 18-22
Do the following statements agree with the information given in Reading Passage 2?
In boxes 18-22 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
18 An animal is likely to live longer in a zoo than in the wild.
19 There are some species in zoos which can no longer be found in the wild.
20 Improvements in the quality of TV wildlife documentaries have resulted in increased
numbers of zoo visitors.
21 Zoos have always excelled at transmitting information about animals to the public.
22 Studying animals in zoos is less stressful for the animals than studying them in
the wild.
88
```

[Original question page](assets/124e5cfaf9c9a04a93dc7da74b6af4bac35bfca43fb51099571ecc15fb9a551e.jpg)

<!-- Source: /api/assets/0296676e516ccdd2f7dd6b137d4cf44076cd38f0e5d75e61624c6d7453612642.jpg; PDF page 89; full -->

```text
Questions 23 and 24
Choose TWO letters, A–E. Write the correct letters in boxes 23 and 24 on your answer sheet.
Which TWO of the following are stated about zoo staff in the text?
A Some take part in television documentaries about animals.
B Some travel to overseas locations to join teams in zoos.
C Some get experience with species in the wild before taking up zoo jobs.
D Some teach people who are involved with conservation projects.
E Some specialise in caring for species which are under threat.
Questions 25 and 26
Choose TWO letters, A–E. Write the correct letters in boxes 25 and 26 on your answer sheet.
Which TWO of these beliefs about zoos does the writer mention in the text?
A They can help children overcome their fears of wild animals.
B They can increase public awareness of environmental issues.
C They can provide employment for a range of professional people.
D They can generate income to support wildlife conservation projects.
E They can raise animals which can later be released into the wild.
```

[Original question page](assets/0296676e516ccdd2f7dd6b137d4cf44076cd38f0e5d75e61624c6d7453612642.jpg)

<!-- Source: /api/assets/02df268280ff0f8c6f2371b71cd08d7f1993cf8668b9e2e4cc94a7705e1ed127.jpg; PDF page 90; full -->

```text
Test 4
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Chelsea Rochman, an ecologist at the University of California, Davis, has been trying to answer
a dismal question: Is everything terrible, or are things just very, very bad?
Rochman is a member of the National Center for Ecological Analysis and Synthesis’s
marine-debris working group, a collection of scientists who study, among other things, the
growing problem of marine debris, also known as ocean trash. Plenty of studies have sounded
alarm bells about the state of marine debris; in a recent paper published in the journal Ecology,
Rochman and her colleagues set out to determine how many of those perceived risks are real.
Often, Rochman says, scientists will end a paper by speculating about the broader impacts of
what they’ve found. For example, a study could show that certain seabirds eat plastic bags, and
go on to warn that whole bird populations are at risk of dying out. ‘But the truth was that nobody
had yet tested those perceived threats,’ Rochman says. ‘There wasn’t a lot of information.’
Rochman and her colleagues examined more than a hundred papers on the impacts of marine
debris that were published through 2013. Within each paper, they asked what threats scientists
had studied — 366 perceived threats in all — and what they’d actually found.
In 83 percent of cases, the perceived dangers of ocean trash were proven true. In the remaining
cases, the working group found the studies had weaknesses in design and content which affected
the validity of their conclusions — they lacked a control group, for example, or used faulty
statistics.
Strikingly, Rochman says, only one well-designed study failed to find the effect it was looking
for, an investigation of mussels ingesting microscopic plastic bits. The plastic moved from the
mussels’ stomachs to their bloodstreams, scientists found, and stayed there for weeks — but didn’t
seem to stress out the shellfish.
While mussels may be fine eating trash, though, the analysis also gave a clearer picture of the
many ways that ocean debris is bothersome.
Within the studies they looked at, most of the proven threats came from plastic debris, rather than
other materials like metal or wood. Most of the dangers also involved large pieces of debris —
animals getting entangled in trash, for example, or eating it and severely injuring themselves.
But a lot of ocean debris is ‘microplastic’, or pieces smaller than five millimeters. These may
be ingredients used in cosmetics and toiletries, fibers shed by synthetic clothing in the wash, or
eroded remnants of larger debris. Compared to the number of studies investigating large-scale
debris, Rochman’s group found little research on the effects of these tiny bits. ‘There are a lot of
open questions still for microplastic,’ Rochman says, though she notes that more papers on the
subject have been published since 2013, the cutoff point for the group’s analysis.
90
```

[Original question page](assets/02df268280ff0f8c6f2371b71cd08d7f1993cf8668b9e2e4cc94a7705e1ed127.jpg)

<!-- Source: /api/assets/502bd785cc8f5c3b5fb49cb3765c598f565ffae610c8538dcb345c61905f1033.jpg; PDF page 91; full -->

```text
:
Reading
There are also, she adds, a lot of open questions about the ways that ocean debris can lead to
sea-creature death. Many studies have looked at how plastic affects an individual animal, or that
animal’s tissues or cells, rather than whole populations. And in the lab, scientists often use higher
concentrations of plastic than what’s really in the ocean. None of that tells us how many birds or
fish or sea turtles could die from plastic pollution — or how deaths in one species could affect that
animal’s predators, or the rest of the ecosystem.
‘We need to be asking more ecologically relevant questions,’ Rochman says. Usually, scientists
don’t know exactly how disasters such as a tanker accidentally spilling its whole cargo of oil and
polluting huge areas of the ocean will affect the environment until after they’ve happened. ‘We
don’t ask the right questions early enough,’ she says. But if ecologists can understand how the
slow-moving effect of ocean trash is damaging ecosystems, they might be able to prevent things
from getting worse.
Asking the right questions can help policy makers, and the public, figure out where to focus their
attention. The problems that look or sound most dramatic may not be the best places to start. For
example, the name of the ‘Great Pacific Garbage Patch’ — a collection of marine debris in the
northern Pacific Ocean — might conjure up a vast, floating trash island. In reality though, much
of the debris is tiny or below the surface; a person could sail through the area without seeing
any trash at all. A Dutch group called ‘The Ocean Cleanup’ is currently working on plans to put
mechanical devices in the Pacific Garbage Patch and similar areas to suck up plastic. But a recent
paper used simulations to show that strategically positioning the cleanup devices closer to shore
would more effectively reduce pollution over the long term.
‘I think clearing up some of these misperceptions is really important,’ Rochman says.
Among scientists as well as in the media, she says, ‘A lot of the images about strandings and
entanglement and all of that cause the perception that plastic debris is killing everything in
the ocean.’ Interrogating the existing scientific literature can help ecologists figure out which
problems really need addressing, and which ones they’d be better off— like the mussels —
absorbing and ignoring.
91
```

[Original question page](assets/502bd785cc8f5c3b5fb49cb3765c598f565ffae610c8538dcb345c61905f1033.jpg)

<!-- Source: /api/assets/0f2d9a9d05e4e9e69fb1dccc726c57437a773d4fcdc20f4c29b995468e8afedf.jpg; PDF page 92; full -->

```text
Test 4
Questions 27-33
Do the following statements agree with the information given in Reading Passage 3?
In boxes 27-33 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
27 Rochman and her colleagues were the first people to research the problem of
marine debris.
28 The creatures most in danger from ocean trash are certain seabirds.
29 The studies Rochman has reviewed have already proved that populations of some
birds will soon become extinct.
30 Rochman analysed papers on the different kinds of danger caused by ocean trash.
31 Most of the research analysed by Rochman and her colleagues was badly
designed.
32 One study examined by Rochman was expecting to find that mussels were harmed
by eating plastic.
33 Some mussels choose to eat plastic in preference to their natural diet.
92
```

[Original question page](assets/0f2d9a9d05e4e9e69fb1dccc726c57437a773d4fcdc20f4c29b995468e8afedf.jpg)

<!-- Source: /api/assets/a087e5e8d1ca5a0ff00ab791304378bb66b907fd24ef49fbc5168b9e9a1ac5bb.jpg; PDF page 93; full -->

```text
Questions 34–39
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 34–39 on your answer sheet.
Findings related to marine debris
Studies of marine debris found the biggest threats were
• plastic (not metal or wood)
• bits of debris that were (34) __________ (harmful to animals)
There was little research into (35) __________ e.g. from synthetic fibres.
Drawbacks of the studies examined
• most of them focused on individual animals, not entire (36) __________
• the (37) __________ of plastic used in the lab did not always reflect those in the ocean
• there was insufficient information on
– numbers of animals which could be affected
– the impact of a reduction in numbers on the (38) __________ of that species
– the impact on the ecosystem
Rochman says more information is needed on the possible impact of future (39) __________ (e.g. involving oil).
Question 40
Choose the correct letter, A, B, C or D.
Write the correct letter in box 40 on your answer sheet.
40 What would be the best title for this passage?
A Assessing the threat of marine debris
B Marine debris: who is to blame?
C A new solution to the problem of marine debris
D Marine debris: the need for international action
```

[Original question page](assets/a087e5e8d1ca5a0ff00ab791304378bb66b907fd24ef49fbc5168b9e9a1ac5bb.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/e746310c2237756e498a9c3d08495d8e521c60e7651a88fe23d2c2b79db7d6bb.jpg; PDF page 94; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The plans below show a public park when it first opened in 1920 and the same park today.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/e746310c2237756e498a9c3d08495d8e521c60e7651a88fe23d2c2b79db7d6bb.jpg)

![Original figure](assets/e746310c2237756e498a9c3d08495d8e521c60e7651a88fe23d2c2b79db7d6bb.jpg)

### Task 2

<!-- Source: /api/assets/70d052a9e7efb613daeab18200079eb2a47fd80973123a921111e467f1549c3c.jpg; PDF page 95; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Nowadays many people choose to be self-employed, rather than to work for a company or organisation.

Why might this be the case?

What could be the disadvantages of being self-employed?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/70d052a9e7efb613daeab18200079eb2a47fd80973123a921111e467f1549c3c.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/14100d6b1eb20660d6fef87f6fd9f2d05acae08da0e638fe1d920753880e6a86.jpg; PDF page 96; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Your neighbourhood
e — Do you like the neighbourhood you live in? [Why/Why not?]
e — What do you do in your neighbourhood in your free time? [Why/Why not?]
e — What new things would you like to have in your neighbourhood? [Why/Why not?]
e — Would you like to live in another neighbourhood in your town or city? [Why/Why not?]
PART 2
Describe a website you have bought something from.
You should say:
what the website is
what you bought from this website
how satisfied you were with what you bought
and explain what you liked and disliked about using this website.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping online
Example questions:
What kinds of things do people in your country often buy from online shops?
Why has online shopping become so popular in many countries?
What are some possible disadvantages of buying things from online shops?
Online retail businesses
Example questions:
Do you agree that the prices of all goods should be lower on internet shopping sites than
in shops?
Will large shopping malls continue to be popular, despite the growth of internet shopping?
Do you think that some businesses (e.g. banks and travel agents) will only operate
online in the future?
96
```

[Original question page](assets/14100d6b1eb20660d6fef87f6fd9f2d05acae08da0e638fe1d920753880e6a86.jpg)

### Part 2

<!-- Source: /api/assets/14100d6b1eb20660d6fef87f6fd9f2d05acae08da0e638fe1d920753880e6a86.jpg; PDF page 96; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Your neighbourhood
e — Do you like the neighbourhood you live in? [Why/Why not?]
e — What do you do in your neighbourhood in your free time? [Why/Why not?]
e — What new things would you like to have in your neighbourhood? [Why/Why not?]
e — Would you like to live in another neighbourhood in your town or city? [Why/Why not?]
PART 2
Describe a website you have bought something from.
You should say:
what the website is
what you bought from this website
how satisfied you were with what you bought
and explain what you liked and disliked about using this website.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping online
Example questions:
What kinds of things do people in your country often buy from online shops?
Why has online shopping become so popular in many countries?
What are some possible disadvantages of buying things from online shops?
Online retail businesses
Example questions:
Do you agree that the prices of all goods should be lower on internet shopping sites than
in shops?
Will large shopping malls continue to be popular, despite the growth of internet shopping?
Do you think that some businesses (e.g. banks and travel agents) will only operate
online in the future?
96
```

[Original question page](assets/14100d6b1eb20660d6fef87f6fd9f2d05acae08da0e638fe1d920753880e6a86.jpg)

### Part 3

<!-- Source: /api/assets/14100d6b1eb20660d6fef87f6fd9f2d05acae08da0e638fe1d920753880e6a86.jpg; PDF page 96; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Your neighbourhood
e — Do you like the neighbourhood you live in? [Why/Why not?]
e — What do you do in your neighbourhood in your free time? [Why/Why not?]
e — What new things would you like to have in your neighbourhood? [Why/Why not?]
e — Would you like to live in another neighbourhood in your town or city? [Why/Why not?]
PART 2
Describe a website you have bought something from.
You should say:
what the website is
what you bought from this website
how satisfied you were with what you bought
and explain what you liked and disliked about using this website.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping online
Example questions:
What kinds of things do people in your country often buy from online shops?
Why has online shopping become so popular in many countries?
What are some possible disadvantages of buying things from online shops?
Online retail businesses
Example questions:
Do you agree that the prices of all goods should be lower on internet shopping sites than
in shops?
Will large shopping malls continue to be popular, despite the growth of internet shopping?
Do you think that some businesses (e.g. banks and travel agents) will only operate
online in the future?
96
```

[Original question page](assets/14100d6b1eb20660d6fef87f6fd9f2d05acae08da0e638fe1d920753880e6a86.jpg)
