# 剑雅 14 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 125

TEST 4 LISTENING
1 85
2 roses
3 trees
4 stage
5 speech
6 support
7 cabins
8 C
9 A
10 B
11 G
12 D
13 A
14 E
15 F
16 B
17 B
18 D
19 A
20 D
21 A
22 C
23 A
24 B
25 B
26 F
27 E
28 C
29 B
30 G
31 spring
32 tools
33 maps
34 heavy
35 marble
36 light
37 camera(s)
38 medical
39 eyes
40 wine
17&18 IN EITHER ORDER: B,D
19&20 IN EITHER ORDER: A,D
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. 85

2. roses

3. trees

4. stage

5. speech

6. support

7. cabins

8. C

9. A

10. B

### Part 2 · source page 125

TEST 4 LISTENING
1 85
2 roses
3 trees
4 stage
5 speech
6 support
7 cabins
8 C
9 A
10 B
11 G
12 D
13 A
14 E
15 F
16 B
17 B
18 D
19 A
20 D
21 A
22 C
23 A
24 B
25 B
26 F
27 E
28 C
29 B
30 G
31 spring
32 tools
33 maps
34 heavy
35 marble
36 light
37 camera(s)
38 medical
39 eyes
40 wine
17&18 IN EITHER ORDER: B,D
19&20 IN EITHER ORDER: A,D
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. G

12. D

13. A

14. E

15. F

16. B

17. B / D

18. B / D

19. A / D

20. A / D

### Part 3 · source page 125

TEST 4 LISTENING
1 85
2 roses
3 trees
4 stage
5 speech
6 support
7 cabins
8 C
9 A
10 B
11 G
12 D
13 A
14 E
15 F
16 B
17 B
18 D
19 A
20 D
21 A
22 C
23 A
24 B
25 B
26 F
27 E
28 C
29 B
30 G
31 spring
32 tools
33 maps
34 heavy
35 marble
36 light
37 camera(s)
38 medical
39 eyes
40 wine
17&18 IN EITHER ORDER: B,D
19&20 IN EITHER ORDER: A,D
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. A

22. C

23. A

24. B

25. B

26. F

27. E

28. C

29. B

30. G

### Part 4 · source page 125

TEST 4 LISTENING
1 85
2 roses
3 trees
4 stage
5 speech
6 support
7 cabins
8 C
9 A
10 B
11 G
12 D
13 A
14 E
15 F
16 B
17 B
18 D
19 A
20 D
21 A
22 C
23 A
24 B
25 B
26 F
27 E
28 C
29 B
30 G
31 spring
32 tools
33 maps
34 heavy
35 marble
36 light
37 camera(s)
38 medical
39 eyes
40 wine
17&18 IN EITHER ORDER: B,D
19&20 IN EITHER ORDER: A,D
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. spring

32. tools

33. maps

34. heavy

35. marble

36. light

37. camera / cameras

38. medical

39. eyes

40. wine

## A 类阅读

### Academic Reading · source page 126

TEST 4 READING
1 four / 4
2 young
3 food
4 light
5 aggressively
6 location
7 neurons
8 chemicals
9 FALSE
10 TRUE
11 FALSE
12 NOT GIVEN
13 TRUE
14 B
15 E
16 C
17 A
18 TRUE
19 TRUE
20 NOT GIVEN
21 FALSE
22 NOT GIVEN
23 B
24 D
25 B
26 E
27 FALSE
28 NOT GIVEN
29 FALSE
30 TRUE
31 FALSE
32 TRUE
33 NOT GIVEN
34 large
35 microplastic
36 populations
37 concentrations
38 predators
39 disasters
40 A
23&24 IN EITHER ORDER: B,D
25&26 IN EITHER ORDER: B,E
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. four / 4

2. young

3. food

4. light

5. aggressively

6. location

7. neurons

8. chemicals

9. FALSE

10. TRUE

11. FALSE

12. NOT GIVEN

13. TRUE

14. B

15. E

16. C

17. A

18. TRUE

19. TRUE

20. NOT GIVEN

21. FALSE

22. NOT GIVEN

23. B / D

24. B / D

25. B / E

26. B / E

27. FALSE

28. NOT GIVEN

29. FALSE

30. TRUE

31. FALSE

32. TRUE

33. NOT GIVEN

34. large

35. microplastic

36. populations

37. concentrations

38. predators

39. disasters

40. A

## A 类写作

### Writing material: c14-t4-w-1

Grange Park, Arnold Avenue top/north conventionally, Eldon Street bottom.1920: entrances middle of both streets; fountain centre; musicians’ stage west; rose gardens northwest,northeast,southwest; water-plant pond northeast/east; glasshouse southeast; seats at sides. Today: both street entrances retained. Stage becomes western amphitheatre for concerts. Fountain replaced by central rose garden surrounded by seats. Northwest rose garden retained; northeastern rose garden replaced by cafe; pond area becomes children’s play area. Glasshouse replaced by southeastern water feature. New underground car-park entrance on eastern edge. No compass or exact dimensions supplied. Do not claim all roses removed or turn underground parking into a surface lot.



### Writing material: c14-t4-w-2

Answer reasons for choosing self-employment and its disadvantages. Not an outweigh question and does not explicitly require a balanced list of advantages/disadvantages or solutions.



## 口语
