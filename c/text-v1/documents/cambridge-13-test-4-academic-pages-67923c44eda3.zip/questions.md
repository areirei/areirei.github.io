# 剑雅 13 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/3912cc40755a494735c90d131f3dea5ed8172e624dd55d794a992dc44f1ece33.jpg; PDF page 77; full -->

```text
Test 4
LISTENING
SECTION 1  Questions 1-10
Complete the notes below.
Write ONE WORD AND/OR A NUMBER for each answer.
Alex’s Training
Example
Alex completed his training in 2014 [example]
About the applicant:
• At first, Alex did his training in the 1....................department.
• Alex didn't have a qualification from school in 2....................
• Alex thinks he should have done the diploma in 3....................skills.
• Age of other trainees: the youngest was 4....................
Benefits of doing training at JPNW:
• Lots of opportunities because of the size of the organisation.
• Trainees receive the same amount of 5....................as permanent staff.
• The training experience increases people's confidence a lot.
• Trainees go to 6....................one day per month.
• The company is in a convenient 7....................
Advice for interview:
• Don’t wear 8....................
• Don't be 9....................
• Make sure you 10....................
76
```

[Original question page](assets/3912cc40755a494735c90d131f3dea5ed8172e624dd55d794a992dc44f1ece33.jpg)

### Part 2

<!-- Source: /api/assets/b14486c8c0d31e0746e637682db44810e70dff025fc63e0506a63822de147556.jpg; PDF page 78; full -->

```text
SECTION 2 Questions 11–20
Questions 11–16
Choose the correct letter, A, B or C.
The Snow Centre
11 Annie recommends that when cross-country skiing, the visitors should
A get away from the regular trails.
B stop to enjoy views of the scenery.
C go at a slow speed at the beginning.
12 What does Annie tell the group about this afternoon’s dog-sled trip?
A Those who want to can take part in a race.
B Anyone has the chance to drive a team of dogs.
C One group member will be chosen to lead the trail.
13 What does Annie say about the team relay event?
A All participants receive a medal.
B The course is 4 km long.
C Each team is led by a teacher.
14 On the snow-shoe trip, the visitors will
A visit an old gold mine.
B learn about unusual flowers.
C climb to the top of a mountain.
15 The cost of accommodation in the mountain hut includes
A a supply of drinking water.
B transport of visitors’ luggage.
C cooked meals.
16 If there is a storm while the visitors are in the hut, they should
A contact the bus driver.
B wait until the weather improves.
C use the emergency locator beacon.
```

[Original question page](assets/b14486c8c0d31e0746e637682db44810e70dff025fc63e0506a63822de147556.jpg)

<!-- Source: /api/assets/2008e5319ba6c80ed74eb6fb7bda2c0a0c6fd1748dfc7a6a2ff34725fe93e8b1.jpg; PDF page 79; full -->

```text
Questions 17–20
Test 4
What information does Annie give about skiing on each of the following mountain trails?
Choose FOUR answers from the box and write the correct letter, A-F, next to
Questions 17-20.
Information
A It has a good place to stop and rest.
B It is suitable for all abilities.
C It involves crossing a river.
D It demands a lot of skill.
E It may be closed in bad weather.
F It has some very narrow sections.
Mountain trails
17 Highland Trail
18 Pine Trail
19 Stony Trail
20 Loser's Trail
78
```

[Original question page](assets/2008e5319ba6c80ed74eb6fb7bda2c0a0c6fd1748dfc7a6a2ff34725fe93e8b1.jpg)

### Part 3

<!-- Source: /api/assets/52d4b81a59b3025a5d846e9144b5b18bebf3669278db9b63936b684a9215abb6.jpg; PDF page 80; full -->

```text
SECTION 3 Questions 21–30
Listening
Questions 21-26
Choose the correct letter, A, B or C.
Labels giving nutritional information on food packaging
21 What was Jack's attitude to nutritional food labels before this project?
A He didn’t read everything on them.
B He didn't think they were important.
C He thought they were too complicated.
22 Alice says that before doing this project,
A she was unaware of what certain foods contained.
B she was too lazy to read food labels.
C she was only interested in the number of calories.
23 When discussing supermarket brands of pizza, Jack agrees with Alice that
A the list of ingredients is shocking.
B he will hesitate before buying pizza again.
C the nutritional label is misleading.
24 Jack prefers the daily value system to other labelling systems because it is
A more accessible.
B more logical.
C more comprehensive.
25 What surprised both students about one flavour of crisps?
A The percentage of artificial additives given was incorrect.
B The products did not contain any meat.
C The labels did not list all the ingredients.
26 What do the students think about research into the impact of nutritional
food labelling?
A It did not produce clear results.
B It focused on the wrong people.
C It made unrealistic recommendations.

79
```

[Original question page](assets/52d4b81a59b3025a5d846e9144b5b18bebf3669278db9b63936b684a9215abb6.jpg)

<!-- Source: /api/assets/40cf1d5158b876df43282a15b148d6e61a06e51ac40e49edf07af7aaf483e33e.jpg; PDF page 81; full -->

```text
Questions 27 and 28
Choose TWO letters, A–E.
Which TWO things surprised the students about the traffic-light system for nutritional labels?
A its widespread use
B the fact that it is voluntary for supermarkets
C how little research was done before its introduction
D its unpopularity with food manufacturers
E the way that certain colours are used
Questions 29 and 30
Choose TWO letters, A–E.
Which TWO things are true about the participants in the study on the traffic-light system?
A They had low literacy levels.
B They were regular consumers of packaged food.
C They were selected randomly.
D They were from all socio-economic groups.
E They were interviewed face-to-face.
```

[Original question page](assets/40cf1d5158b876df43282a15b148d6e61a06e51ac40e49edf07af7aaf483e33e.jpg)

### Part 4

<!-- Source: /api/assets/3f52e9e9b45ededed7df421c0b9502e9e574a9099e2634cb1dacea45f7452975.jpg; PDF page 82; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
The history of coffee
Coffee in the Arab world
• There was small-scale trade in wild coffee from Ethiopia.
• 1522: Coffee was approved in the Ottoman court as a type of medicine.
• 1623: In Constantinople, the ruler ordered the (31) __________ of every coffee house.
Coffee arrives in Europe (17th century)
• Coffee shops were compared to (32) __________.
• They played an important part in social and (33) __________ changes.
Coffee and European colonisation
• European powers established coffee plantations in their colonies.
• Types of coffee were often named according to the (34) __________ they came from.
• In Brazil and the Caribbean, most cultivation depended on (35) __________.
• In Java, coffee was used as a form of (36) __________.
• Coffee became almost as important as (37) __________.
• The move towards the consumption of (38) __________ in Britain did not also take place in the USA.
Coffee in the 19th century
• Prices dropped because of improvements in (39) __________.
• Industrial workers found coffee helped them to work at (40) __________.
```

[Original question page](assets/3f52e9e9b45ededed7df421c0b9502e9e574a9099e2634cb1dacea45f7452975.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/e42a6a397a179cd4df8a725bce163483f4ad123994b5f84f5d50bdf2d8af06f7.jpg; PDF page 83; full -->

```text
READING PASSAGE 1
Test 4
READING
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Cutty Sark: the fastest sailing ship of all time
The nineteenth century was a period of great technological development in Britain, and for
shipping the major changes were from wind to steam power, and from wood to iron and steel.
The fastest commercial sailing vessels of all time were clippers, three-masted ships built to
transport goods around the world, although some also took passengers. From the 1840s until
1869, when the Suez Canal opened and steam propulsion was replacing sail, clippers dominated
world trade. Although many were built, only one has survived more or less intact: Cutty Sark,
now on display in Greenwich, southeast London.
Cutty Sark's unusual name comes from the poem Tam O’Shanter by the Scottish poet Robert
Burns. Tam, a farmer, is chased by a witch called Nannie, who is wearing a 'cutty sark’ - an
old Scottish name for a short nightdress. The witch is depicted in Cutty Sark’s figurehead - the
carving of a woman typically at the front of old sailing ships. In legend, and in Burns’s poem,
witches cannot cross water, so this was a rather strange choice of name for a ship.
Cutty Sark was built in Dumbarton, Scotland, in 1869, for a shipping company owned by John
Willis. To carry out construction, Willis chose a new shipbuilding firm, Scott & Linton, and
ensured that the contract with them put him in a very strong position. In the end, the firm was
forced out of business, and the ship was finished by a competitor.
Willis’s company was active in the tea trade between China and Britain, where speed could
bring shipowners both profits and prestige, so Cutty Sark was designed to make the journey
more quickly than any other ship. On her maiden voyage, in 1870, she set sail from London,
carrying large amounts of goods to China. She returned laden with tea, making the journey back
to London in four months. However, Cutty Sark never lived up to the high expectations of her
owner, as a result of bad winds and various misfortunes. On one occasion, in 1872, the ship and
a rival clipper, Thermopylae, left port in China on the same day. Crossing the Indian Ocean,
Cutty Sark gained a lead of over 400 miles, but then her rudder was severely damaged in stormy
seas, making her impossible to steer. The ship’s crew had the daunting task of repairing the
rudder at sea, and only succeeded at the second attempt. Cutty Sark reached London a week after
Thermopylae.

82
```

[Original question page](assets/e42a6a397a179cd4df8a725bce163483f4ad123994b5f84f5d50bdf2d8af06f7.jpg)

<!-- Source: /api/assets/f075bff7fe58be44324324cb98215d6cfd63328d75244d410229bf200f7ab360.jpg; PDF page 84; full -->

```text
Reading
Steam ships posed a growing threat to clippers, as their speed and cargo capacity increased. In
addition, the opening of the Suez Canal in 1869, the same year that Cutty Sark was launched,
had a serious impact. While steam ships could make use of the quick, direct route between the
Mediterranean and the Red Sea, the canal was of no use to sailing ships, which needed the much
stronger winds of the oceans, and so had to sail a far greater distance. Steam ships reduced the
journey time between Britain and China by approximately two months.
By 1878, tea traders weren’t interested in Cutty Sark, and instead, she took on the much less
prestigious work of carrying any cargo between any two ports in the world. In 1880, violence
aboard the ship led ultimately to the replacement of the captain with an incompetent drunkard
who stole the crew’s wages. He was suspended from service, and a new captain appointed. This
marked a turnaround and the beginning of the most successful period in Cutty Sark's working
life, transporting wool from Australia to Britain. One such journey took just under 12 weeks,
beating every other ship sailing that year by around a month.
The ship’s next captain, Richard Woodget, was an excellent navigator, who got the best out of
both his ship and his crew. As a sailing ship, Cutty Sark depended on the strong trade winds of the
southern hemisphere, and Woodget took her further south than any previous captain, bringing her
dangerously close to icebergs off the southern tip of South America. His gamble paid off, though,
and the ship was the fastest vessel in the wool trade for ten years.
As competition from steam ships increased in the 1890s, and Cutty Sark approached the end of
her life expectancy, she became less profitable. She was sold to a Portuguese firm, which renamed
her Ferreira. For the next 25 years, she again carried miscellaneous cargoes around the world.
Badly damaged in a gale in 1922, she was put into Falmouth harbour in southwest England, for
repairs. Wilfred Dowman, a retired sea captain who owned a training vessel, recognised her and
tried to buy her, but without success. She returned to Portugal and was sold to another Portuguese
company. Dowman was determined, however, and offered a high price: this was accepted, and
the ship returned to Falmouth the following year and had her original name restored.
Dowman used Cutty Sark as a training ship, and she continued in this role after his death. When
she was no longer required, in 1954, she was transferred to dry dock at Greenwich to go on
public display. The ship suffered from fire in 2007, and again, less seriously, in 2014, but now
Cutty Sark attracts a quarter of a million visitors a year.
83
```

[Original question page](assets/f075bff7fe58be44324324cb98215d6cfd63328d75244d410229bf200f7ab360.jpg)

<!-- Source: /api/assets/76849c43d09caf94c2bd16a2b627b545a679df9498dcc19dad0f6b4dac2670cf.jpg; PDF page 85; full -->

```text
Questions 1–8
Test 4
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-8 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 Clippers were originally intended to be used as passenger ships.
2 Cutty Sark was given the name of a character in a poem.
3 The contract between John Willis and Scott & Linton favoured Willis.
4 John Willis wanted Cutty Sark to be the fastest tea clipper travelling between the
UK and China.
5 Despite storm damage, Cutty Sark beat Thermopylae back to London.
6 The opening of the Suez Canal meant that steam ships could travel between Britain
and China faster than clippers.
7 Steam ships sometimes used the ocean route to travel between London and China.
8 Captain Woodget put Cutty Sark at risk of hitting an iceberg.
Questions 9-13
Complete the sentences below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 9-13 on your answer sheet.
9 After 1880, Cutty Sark carried
....................as its main cargo during its most
successful time.
10 As a captain and...................., Woodget was very skilled.
11 Ferreira went to Falmouth to repair damage that a....................had caused.
12 Between 1923 and 1954, Cutty Sark was used for....................
13 Cutty Sark has twice been damaged by....................in the 21st century.

84
```

[Original question page](assets/76849c43d09caf94c2bd16a2b627b545a679df9498dcc19dad0f6b4dac2670cf.jpg)

<!-- Source: /api/assets/b108da7fdb886834ea683cf74bfb2ff16ac66be95ef5d48be96e21ca54de2cb7.jpg; PDF page 86; full -->

```text
READING PASSAGE 2
Reading
You should spend about 20 minutes on Questions 14–26, which are based on Reading
Passage 2 below.
SAVING THE SOIL
More than a third of the Earth's top layer is at risk. Is there hope for our planet’s
most precious resource?
A More than a third of the world’s soil is endangered, according to a recent UN report.
If we don’t slow the decline, all farmable soil could be gone in 60 years. Since soil
grows 95% of our food, and sustains human life in other more surprising ways, that
is a huge problem.
B Peter Groffman, from the Cary Institute of Ecosystem Studies in New York, points
out that soil scientists have been warning about the degradation of the world's soil
for decades. At the same time, our understanding of its importance to humans has
grown. A single gram of healthy soil might contain 100 million bacteria, as well as
other microorganisms such as viruses and fungi, living amid decomposing plants
and various minerals.
That means soils do not just grow our food, but are the source of nearly all our
existing antibiotics, and could be our best hope in the fight against antibiotic-
resistant bacteria. Soil is also an ally against climate change: as microorganisms
within soil digest dead animals and plants, they lock in their carbon content, holding
three times the amount of carbon as does the entire atmosphere. Soils also store
water, preventing flood damage: in the UK, damage to buildings, roads and bridges
from floods caused by soil degradation costs £233 million every year.
C If the soil loses its ability to perform these functions, the human race could be in
big trouble. The danger is not that the soil will disappear completely, but that the
microorganisms that give it its special properties will be lost. And once this has
happened, it may take the soil thousands of years to recover.
Agriculture is by far the biggest problem. In the wild, when plants grow they remove
nutrients from the soil, but then when the plants die and decay these nutrients are
returned directly to the soil. Humans tend not to return unused parts of harvested
crops directly to the soil to enrich it, meaning that the soil gradually becomes
less fertile. In the past we developed strategies to get around the problem, such
as regularly varying the types of crops grown, or leaving fields uncultivated for a
season.
D But these practices became inconvenient as populations grew and agriculture had
to be run on more commercial lines. A solution came in the early 20th century with
the Haber-Bosch process for manufacturing ammonium nitrate. Farmers have been
putting this synthetic fertiliser on their fields ever since.

85
```

[Original question page](assets/b108da7fdb886834ea683cf74bfb2ff16ac66be95ef5d48be96e21ca54de2cb7.jpg)

<!-- Source: /api/assets/e51d212211d244cf2e2ff786aabcea1ad90f6c520c59dd6b3885d0ac1407e262.jpg; PDF page 87; full -->

```text
Test 4
But over the past few decades, it has become clear this wasn't such a bright idea.
Chemical fertilisers can release polluting nitrous oxide into the atmosphere and
excess is often washed away with the rain, releasing nitrogen into rivers. More
recently, we have found that indiscriminate use of fertilisers hurts the soil itself,
turning it acidic and salty, and degrading the soil they are supposed to nourish.
E One of the people looking for a solution to this problem is Pius Floris, who started
out running a tree-care business in the Netherlands, and now advises some of the
world’s top soil scientists. He came to realise that the best way to ensure his trees
flourished was to take care of the soil, and has developed a cocktail of beneficial
bacteria, fungi and humus* to do this. Researchers at the University of Valladolid in
Spain recently used this cocktail on soils destroyed by years of fertiliser overuse.
When they applied Floris’s mix to the desert-like test plots, a good crop of plants
emerged that were not just healthy at the surface, but had roots strong enough to
pierce dirt as hard as rock. The few plants that grew in the control plots, fed with
traditional fertilisers, were small and weak.
F However, measures like this are not enough to solve the global soil degradation
problem. To assess our options on a global scale we first need an accurate picture
of what types of soil are out there, and the problems they face. That’s not easy. For
one thing, there is no agreed international system for classifying soil. In an attempt
to unify the different approaches, the UN has created the Global Soil Map project.
Researchers from nine countries are working together to create a map linked to a
database that can be fed measurements from field surveys, drone surveys, satellite
imagery, lab analyses and so on to provide real-time data on the state of the soil.
Within the next four years, they aim to have mapped soils worldwide to a depth of
100 metres, with the results freely accessible to all.
G But this is only a first step. We need ways of presenting the problem that bring
it home to governments and the wider public, says Pamela Chasek at the
International Institute for Sustainable Development, in Winnipeg, Canada. 'Most
scientists don't speak language that policy-makers can understand, and vice versa.,
Chasek and her colleagues have proposed a goal of ‘zero net land degradation, .
Like the idea of carbon neutrality, it is an easily understood target that can help
shape expectations and encourage action.
For soils on the brink, that may be too late. Several researchers are agitating for
the immediate creation of protected zones for endangered soils. One difficulty
here is defining what these areas should conserve: areas where the greatest soil
diversity is present? Or areas of unspoilt soils that could act as a future benchmark
of quality?
Whatever we do, if we want our soils to survive, we need to take action now.
* Humus: the part of the soil formed from dead plant material
86
```

[Original question page](assets/e51d212211d244cf2e2ff786aabcea1ad90f6c520c59dd6b3885d0ac1407e262.jpg)

<!-- Source: /api/assets/fc6a6b0e662a71396fcc08de20cfe288215403a25720c6745d801144eb70e3e3.jpg; PDF page 88; full -->

```text
Reading
Questions 14-17
Complete the summary below.
Write ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 14-17 on your answer sheet.
Why soil degradation could be a disaster for humans
Healthy soil contains a large variety of bacteria and other microorganisms, as well
as plant remains and 14..................... It provides us with food and also with
antibiotics, and its function in storing 15....................has a significant effect on the
climate. In addition, it prevents damage to property and infrastructure because it
holds 16....................
If these microorganisms are lost, soil may lose its special properties. The main factor
contributing to soil degradation is the 17....................carried out by humans.
Questions 18-21
Complete each sentence with the correct ending, A-F, below.
Write the correct letter, A-F, in boxes 18-21 on your answer sheet.
18 Nutrients contained in the unused parts of harvested crops
19 Synthetic fertilisers produced with the Haber-Bosch process
20 Addition of a mixture developed by Pius Floris to the soil
21 The idea of zero net soil degradation
A may improve the number and quality of plants growing there.
B may contain data from up to nine countries.
C may not be put back into the soil.
D may help governments to be more aware of soil-related issues.
E may cause damage to different aspects of the environment.
F may be better for use at a global level.
87
```

[Original question page](assets/fc6a6b0e662a71396fcc08de20cfe288215403a25720c6745d801144eb70e3e3.jpg)

<!-- Source: /api/assets/a3d589787be782e6bcb291f2e8e4825c811fa39f71dae21e9bc2203839cee2e3.jpg; PDF page 89; full -->

```text
Questions 22–26
Test 4
Reading Passage 2 has seven paragraphs, A-G.
Which section contains the following information?
Write the correct letter, A-G, in boxes 22-26 on your answer sheet.
NB You may use any letter more than once.
22 a reference to one person’s motivation for a soil-improvement project
23 an explanation of how soil stayed healthy before the development of farming
24 examples of different ways of collecting information on soil degradation
25 a suggestion for a way of keeping some types of soil safe in the near future
26 a reason why it is difficult to provide an overview of soil degradation

88
```

[Original question page](assets/a3d589787be782e6bcb291f2e8e4825c811fa39f71dae21e9bc2203839cee2e3.jpg)

<!-- Source: /api/assets/2a8e4cf658adefcc463302c4062ac87603041eeecfb39ac7bee3ca0dc37825b7.jpg; PDF page 90; full -->

```text
READING PASSAGE 3
Reading
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Book Review
The Happiness Industry: How the Government and Big Business
Sold Us Well-Being
By William Davies
‘Happiness is the ultimate goal because it is self-evidently good. If we are asked why
happiness matters we can give no further external reason. It just obviously does matter.’ This
pronouncement by Richard Layard, an economist and advocate of ‘positive psychology,,
summarises the beliefs of many people today. For Layard and others like him, it is obvious that
the purpose of government is to promote a state of collective well-being. The only question is
how to achieve it, and here positive psychology - a supposed science that not only identifies
what makes people happy but also allows their happiness to be measured - can show the way.
Equipped with this science, they say, governments can secure happiness in society in a way they
never could in the past.
It is an astonishingly crude and simple-minded way of thinking, and for that very reason
increasingly popular. Those who think in this way are oblivious to the vast philosophical
literature in which the meaning and value of happiness have been explored and questioned,
and write as if nothing of any importance had been thought on the subject until it came to their
attention. It was the philosopher Jeremy Bentham (1748— 1832) who was more than anyone else
responsible for the development of this way of thinking. For Bentham it was obvious that the
human good consists of pleasure and the absence of pain. The Greek philosopher Aristotle may
have identified happiness with self-realisation in the 4th century BC, and thinkers throughout the
ages may have struggled to reconcile the pursuit of happiness with other human values, but for
Bentham all this was mere metaphysics or fiction. Without knowing anything much of him or the
school of moral theory he established - since they are by education and intellectual conviction
illiterate in the history of ideas - our advocates of positive psychology follow in his tracks in
rejecting as outmoded and irrelevant pretty much the entirety of ethical reflection on human
happiness to date.
But as William Davies notes in his recent book The Happiness Industry, the view that happiness
is the only self-evident good is actually a way of limiting moral inquiry. One of the virtues of
this rich, lucid and arresting book is that it places the current cult of happiness in a well-defined
historical framework. Rightly, Davies begins his story with Bentham, noting that he was far
more than a philosopher. Davies writes, ‘Bentham’s activities were those which we might now
associate with a public sector management consultant’. In the 1790s, he wrote to the Home Office
suggesting that the departments of government be linked together through a set of 'conversation
tubes, , and to the Bank of England with a design for a printing device that could produce

89
```

[Original question page](assets/2a8e4cf658adefcc463302c4062ac87603041eeecfb39ac7bee3ca0dc37825b7.jpg)

<!-- Source: /api/assets/6c002977afeadd8f5c753fbbf85d01d809ea282595bef19e1237cdab3f164846.jpg; PDF page 91; full -->

```text
Test 4
unforgeable banknotes. He drew up plans for a ‘frigidarium’ to keep provisions such as meat,
fish, fruit and vegetables fresh. His celebrated design for a prison to be known as a ‘Panopticon,,
in which prisoners would be kept in solitary confinement while being visible at all times to the
guards, was very nearly adopted. (Surprisingly, Davies does not discuss the fact that Bentham
meant his Panopticon not just as a model prison but also as an instrument of control that could be
applied to schools and factories.)
Bentham was also a pioneer of the ‘science of happiness’. If happiness is to be regarded as
a science, it has to be measured, and Bentham suggested two ways in which this might be
done. Viewing happiness as a complex of pleasurable sensations, he suggested that it might be
quantified by measuring the human pulse rate. Alternatively, money could be used as the standard
for quantification: if two different goods have the same price, it can be claimed that they produce
the same quantity of pleasure in the consumer. Bentham was more attracted by the latter measure.
By associating money so closely to inner experience, Davies writes, Bentham ‘set the stage for
the entangling of psychological research and capitalism that would shape the business practices
of the twentieth century’.
The Happiness Industry describes how the project of a science of happiness has become
integral to capitalism. We learn much that is interesting about how economic problems are
being redefined and treated as psychological maladies. In addition, Davies shows how the
belief that inner states of pleasure and displeasure can be objectively measured has informed
management studies and advertising. The tendency of thinkers such as J B Watson, the founder
of behaviourism*, was that human beings could be shaped, or manipulated, by policymakers and
managers. Watson had no factual basis for his view of human action. When he became president
of the American Psychological Association in 1915, he 'had never even studied a single human
being’: his research had been confined to experiments on white rats. Yet Watson’s reductive
model is now widely applied, with 'behaviour change’ becoming the goal of governments: in
Britain, a ‘Behaviour Insights Team’ has been established by the government to study how people
can be encouraged, at minimum cost to the public purse, to live in what are considered to be
socially desirable ways.
Modern industrial societies appear to need the possibility of ever-increasing happiness to
motivate them in their labours. But whatever its intellectual pedigree, the idea that governments
should be responsible for promoting happiness is always a threat to human freedom.
90
* ‘behaviourism’: a branch of psychology which is concerned with observable behaviour
```

[Original question page](assets/6c002977afeadd8f5c753fbbf85d01d809ea282595bef19e1237cdab3f164846.jpg)

<!-- Source: /api/assets/02bc1ed3123f3fedc67aa2cb9009248015f67a8ce4afd2cd05f3a0c0cd9c592c.jpg; PDF page 92; full -->

```text
Questions 27–29
Reading
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-29 on your answer sheet.
27 What is the reviewer’s attitude to advocates of positive psychology?
A They are wrong to reject the ideas of Bentham.
B They are over-influenced by their study of Bentham’s theories.
C They have a fresh new approach to ideas on human happiness.
D They are ignorant about the ideas they should be considering.
28 The reviewer refers to the Greek philosopher Aristotle in order to suggest that
happiness
A may not be just pleasure and the absence of pain.
B should not be the main goal of humans.
C is not something that should be fought for.
D is not just an abstract concept.
29 According to Davies, Bentham’s suggestion for linking the price of goods to
happiness was significant because
A it was the first successful way of assessing happiness.
B it established a connection between work and psychology.
C it was the first successful example of psychological research.
D it involved consideration of the rights of consumers.

91
```

[Original question page](assets/02bc1ed3123f3fedc67aa2cb9009248015f67a8ce4afd2cd05f3a0c0cd9c592c.jpg)

<!-- Source: /api/assets/3b5987b2d2b1cca0d29464b0835cf960eff2e1097621e985a7c4e6b40a87c2ce.jpg; PDF page 93; full -->

```text
Questions 30–34
Test 4
Complete the summary using the list of words A-G below.
Write the correct letter, A-G, in boxes 30-34 on your answer sheet.
Jeremy Bentham
Jeremy Bentham was active in other areas besides philosophy. In the 1790s he
suggested a type of technology to improve 30..................for different Government
departments. He developed a new way of printing banknotes to increase
31..................and also designed a method for the 32...................of food. He
also drew up plans for a prison which allowed the 33..................of prisoners at all
times, and believed the same design could be used for other institutions as well. When
researching happiness, he investigated possibilities for its 34.................., and
suggested some methods of doing this.

A measurement
B security
C implementation
D profits
E observation
F communication
G preservation
```

[Original question page](assets/3b5987b2d2b1cca0d29464b0835cf960eff2e1097621e985a7c4e6b40a87c2ce.jpg)

<!-- Source: /api/assets/d7ba85067a362b477c6103e92fb4f07464df20d65ce354cd027a229d665ffa46.jpg; PDF page 94; full -->

```text
Questions 35–40
Reading
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 35-40 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
35 One strength of The Happiness Industry is its discussion of the relationship
between psychology and economics.
36 It is more difficult to measure some emotions than others.
37 Watson's ideas on behaviourism were supported by research on humans he carried
out before 1915.
38 Watson's ideas have been most influential on governments outside America.
39 The need for happiness is linked to industrialisation.
40 A main aim of government should be to increase the happiness of the population.

93
```

[Original question page](assets/d7ba85067a362b477c6103e92fb4f07464df20d65ce354cd027a229d665ffa46.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/7265afb8dd7295a5dd6683eb2706c2536a341e7c23f17140f8b349e58548ab86.jpg; PDF page 95; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The plans below show the layout of a university’s sports centre now, and how it will look after redevelopment.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/7265afb8dd7295a5dd6683eb2706c2536a341e7c23f17140f8b349e58548ab86.jpg)

![Original figure](assets/7265afb8dd7295a5dd6683eb2706c2536a341e7c23f17140f8b349e58548ab86.jpg)

### Task 2

<!-- Source: /api/assets/59eb09b9296e1869e5e5f56f7fd106960c307cd476c1ee0ce9734c75bf077967.jpg; PDF page 96; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In spite of the advances made in agriculture, many people around the world still go hungry.

Why is this the case?

What can be done about this problem?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/59eb09b9296e1869e5e5f56f7fd106960c307cd476c1ee0ce9734c75bf077967.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/4839360b2e7d5fcaeab39d2ffa150dbf61327708ab593facc911e6326f6269a1.jpg; PDF page 97; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Animals
• Are there many animals or birds where you live? [Why/Why not?]
• How often do you watch programmes or read articles about wild animals? [Why?]
• Have you ever been to a zoo or a wildlife park? [Why/Why not?]
• Would you like to have a job working with animals? [Why/Why not?]
PART 2
Describe a website you use that helps you a lot in
your work or studies.
You should say:
what the website is
how often you use the website
what information the website gives you
and explain how your work or studies would
change if this website didn’t exist.
96
You will have to talk
about the topic for one
to two minutes.You have
one minute to think
about what you are
going to say. You can
make some notes to
help you if you wish.
PART 3
Discussion topics:
The internet
Example questions:
Why do some people find the internet addictive?
What would the world be like without the internet?
Do you think that the way people use the internet may change in the future?
Social media websites
Example questions:
What are the ways that social media can be used for positive purposes?
Why do some individuals post highly negative comments about other people on
social media?
Do you think that companies’ main form of advertising will be via social media in the future?
```

[Original question page](assets/4839360b2e7d5fcaeab39d2ffa150dbf61327708ab593facc911e6326f6269a1.jpg)

### Part 2

<!-- Source: /api/assets/4839360b2e7d5fcaeab39d2ffa150dbf61327708ab593facc911e6326f6269a1.jpg; PDF page 97; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Animals
• Are there many animals or birds where you live? [Why/Why not?]
• How often do you watch programmes or read articles about wild animals? [Why?]
• Have you ever been to a zoo or a wildlife park? [Why/Why not?]
• Would you like to have a job working with animals? [Why/Why not?]
PART 2
Describe a website you use that helps you a lot in
your work or studies.
You should say:
what the website is
how often you use the website
what information the website gives you
and explain how your work or studies would
change if this website didn’t exist.
96
You will have to talk
about the topic for one
to two minutes.You have
one minute to think
about what you are
going to say. You can
make some notes to
help you if you wish.
PART 3
Discussion topics:
The internet
Example questions:
Why do some people find the internet addictive?
What would the world be like without the internet?
Do you think that the way people use the internet may change in the future?
Social media websites
Example questions:
What are the ways that social media can be used for positive purposes?
Why do some individuals post highly negative comments about other people on
social media?
Do you think that companies’ main form of advertising will be via social media in the future?
```

[Original question page](assets/4839360b2e7d5fcaeab39d2ffa150dbf61327708ab593facc911e6326f6269a1.jpg)

### Part 3

<!-- Source: /api/assets/4839360b2e7d5fcaeab39d2ffa150dbf61327708ab593facc911e6326f6269a1.jpg; PDF page 97; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Animals
• Are there many animals or birds where you live? [Why/Why not?]
• How often do you watch programmes or read articles about wild animals? [Why?]
• Have you ever been to a zoo or a wildlife park? [Why/Why not?]
• Would you like to have a job working with animals? [Why/Why not?]
PART 2
Describe a website you use that helps you a lot in
your work or studies.
You should say:
what the website is
how often you use the website
what information the website gives you
and explain how your work or studies would
change if this website didn’t exist.
96
You will have to talk
about the topic for one
to two minutes.You have
one minute to think
about what you are
going to say. You can
make some notes to
help you if you wish.
PART 3
Discussion topics:
The internet
Example questions:
Why do some people find the internet addictive?
What would the world be like without the internet?
Do you think that the way people use the internet may change in the future?
Social media websites
Example questions:
What are the ways that social media can be used for positive purposes?
Why do some individuals post highly negative comments about other people on
social media?
Do you think that companies’ main form of advertising will be via social media in the future?
```

[Original question page](assets/4839360b2e7d5fcaeab39d2ffa150dbf61327708ab593facc911e6326f6269a1.jpg)
