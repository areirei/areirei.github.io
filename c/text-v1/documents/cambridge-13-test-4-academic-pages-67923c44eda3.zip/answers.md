# 剑雅 13 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 125

TEST 4 LISTENING
1 Finance
2 Maths / Math / Mathematics
3 business
4 17 / seventeen
5 holiday(s) / vacation(s)
6 college
7 location
8 jeans
9 late
10 smile
11 A
12 B
13 A
14 C
15 A
16 B
17 B
18 D
19 A
20 E
21 A
22 A
23 C
24 C
25 B
26 A
27 B
28 C
29 D
30 E
31 destruction
32 universities / university
33 political
34 port(s)
35 slaves / slavery
36 taxation
37 sugar
38 tea
39 transportation
40 night
27&28 IN EITHER ORDER: B,C
29&30 IN EITHER ORDER: D,E
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. Finance

2. Maths / Math / Mathematics

3. business

4. 17 / seventeen

5. holiday / holidays / vacation / vacations

6. college

7. location

8. jeans

9. late

10. smile

### Part 2 · source page 125

TEST 4 LISTENING
1 Finance
2 Maths / Math / Mathematics
3 business
4 17 / seventeen
5 holiday(s) / vacation(s)
6 college
7 location
8 jeans
9 late
10 smile
11 A
12 B
13 A
14 C
15 A
16 B
17 B
18 D
19 A
20 E
21 A
22 A
23 C
24 C
25 B
26 A
27 B
28 C
29 D
30 E
31 destruction
32 universities / university
33 political
34 port(s)
35 slaves / slavery
36 taxation
37 sugar
38 tea
39 transportation
40 night
27&28 IN EITHER ORDER: B,C
29&30 IN EITHER ORDER: D,E
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A

12. B

13. A

14. C

15. A

16. B

17. B

18. D

19. A

20. E

### Part 3 · source page 125

TEST 4 LISTENING
1 Finance
2 Maths / Math / Mathematics
3 business
4 17 / seventeen
5 holiday(s) / vacation(s)
6 college
7 location
8 jeans
9 late
10 smile
11 A
12 B
13 A
14 C
15 A
16 B
17 B
18 D
19 A
20 E
21 A
22 A
23 C
24 C
25 B
26 A
27 B
28 C
29 D
30 E
31 destruction
32 universities / university
33 political
34 port(s)
35 slaves / slavery
36 taxation
37 sugar
38 tea
39 transportation
40 night
27&28 IN EITHER ORDER: B,C
29&30 IN EITHER ORDER: D,E
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. A

22. A

23. C

24. C

25. B

26. A

27. B / C

28. B / C

29. D / E

30. D / E

### Part 4 · source page 125

TEST 4 LISTENING
1 Finance
2 Maths / Math / Mathematics
3 business
4 17 / seventeen
5 holiday(s) / vacation(s)
6 college
7 location
8 jeans
9 late
10 smile
11 A
12 B
13 A
14 C
15 A
16 B
17 B
18 D
19 A
20 E
21 A
22 A
23 C
24 C
25 B
26 A
27 B
28 C
29 D
30 E
31 destruction
32 universities / university
33 political
34 port(s)
35 slaves / slavery
36 taxation
37 sugar
38 tea
39 transportation
40 night
27&28 IN EITHER ORDER: B,C
29&30 IN EITHER ORDER: D,E
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. destruction

32. universities / university

33. political

34. port / ports

35. slaves / slavery

36. taxation

37. sugar

38. tea

39. transportation

40. night

## A 类阅读

### Academic Reading · source page 126

TEST 4 READING
1 FALSE
2 FALSE
3 TRUE
4 TRUE
5 FALSE
6 TRUE
7 NOT GIVEN
8 TRUE
9 wool
10 navigator
11 gale
12 training
13 fire
14 minerals
15 carbon
16 water
17 agriculture
18 C
19 E
20 A
21 D
22 E
23 C
24 F
25 G
26 F
27 D
28 A
29 B
30 F
31 B
32 G
33 E
34 A
35 YES
36 NOT GIVEN
37 NO
38 NOT GIVEN
39 YES
40 NO
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. FALSE

2. FALSE

3. TRUE

4. TRUE

5. FALSE

6. TRUE

7. NOT GIVEN

8. TRUE

9. wool

10. navigator

11. gale

12. training

13. fire

14. minerals

15. carbon

16. water

17. agriculture

18. C

19. E

20. A

21. D

22. E

23. C

24. F

25. G

26. F

27. D

28. A

29. B

30. F

31. B

32. G

33. E

34. A

35. YES

36. NOT GIVEN

37. NO

38. NOT GIVEN

39. YES

40. NO

## A 类写作

### Writing material: c13-t4-w-1

North up, main entrance south. Present25m pool central, changing room west, seating east, gym north, reception south, outdoor courts both west and east. Future expanded indoor building replaces both outdoor court areas. Leisure pool west, sports hall east, two dance studios along eastern edge; gym expanded eastward. Original25m pool,seating,western changing room,reception retained. New changing rooms southwest/southeast, sports shop south-west of reception, cafe south-east. No dates/costs supplied; changes planned, not completed. No outdoor courts remain shown after redevelopment.



### Writing material: c13-t4-w-2

Explain persistent hunger despite agricultural advances and propose relevant solutions. Do not assume global production alone explains all hunger or invent numerical studies.



## 口语
