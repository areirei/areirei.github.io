# 剑雅 5 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 159

TEST 4 LISTENING
Section 1, Questions 1–10
1 14 Hill Road
2 between 9 and 9.30 / 9–9.30
3 1 year
4 intermediate
5 North-West
6 vegetarian
7 (a) (real) garden
8 (the) only guest
9 100
10 23rd March / Monday 23rd March
Section 2, Questions 11–20
11 clubhouse
12 picnic
13 prizes
14 10
15 Wednesday afternoon(s)
16 4
17 Sunday afternoon(s)
18 collect (the) fees / collect (the) money
19 send (out/the) newsletter(s)
20 supervise (the) teams
Section 3, Questions 21–30
21 sales
22 competition
23 interest rates / rates of interest
24 training
25 A
26 B
27 A
28 C
29 B
30 D
Section 4, Questions 31–40
31 B
32 A
33 A
34 C
35 A
36 B
37 B
38 A
39 B
40 C
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. 14 Hill Road

2. between 9 and 9.30 / between 9 and 9:30 / 9-9.30 / 9-9:30

3. 1 year

4. intermediate

5. North-West

6. vegetarian

7. garden / real garden / a garden / a real garden

8. only guest / the only guest

9. 100

10. 23 March / 23rd March / Monday 23 March / Monday 23rd March

### Part 2 · source page 159

TEST 4 LISTENING
Section 1, Questions 1–10
1 14 Hill Road
2 between 9 and 9.30 / 9–9.30
3 1 year
4 intermediate
5 North-West
6 vegetarian
7 (a) (real) garden
8 (the) only guest
9 100
10 23rd March / Monday 23rd March
Section 2, Questions 11–20
11 clubhouse
12 picnic
13 prizes
14 10
15 Wednesday afternoon(s)
16 4
17 Sunday afternoon(s)
18 collect (the) fees / collect (the) money
19 send (out/the) newsletter(s)
20 supervise (the) teams
Section 3, Questions 21–30
21 sales
22 competition
23 interest rates / rates of interest
24 training
25 A
26 B
27 A
28 C
29 B
30 D
Section 4, Questions 31–40
31 B
32 A
33 A
34 C
35 A
36 B
37 B
38 A
39 B
40 C
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. clubhouse

12. picnic

13. prizes

14. 10

15. Wednesday afternoon / Wednesday afternoons

16. 4

17. Sunday afternoon / Sunday afternoons

18. collect fees / collect the fees / collect money / collect the money

19. send newsletter / send newsletters / send out newsletter / send out newsletters / send the newsletter / send the newsletters

20. supervise teams / supervise the teams

### Part 3 · source page 159

TEST 4 LISTENING
Section 1, Questions 1–10
1 14 Hill Road
2 between 9 and 9.30 / 9–9.30
3 1 year
4 intermediate
5 North-West
6 vegetarian
7 (a) (real) garden
8 (the) only guest
9 100
10 23rd March / Monday 23rd March
Section 2, Questions 11–20
11 clubhouse
12 picnic
13 prizes
14 10
15 Wednesday afternoon(s)
16 4
17 Sunday afternoon(s)
18 collect (the) fees / collect (the) money
19 send (out/the) newsletter(s)
20 supervise (the) teams
Section 3, Questions 21–30
21 sales
22 competition
23 interest rates / rates of interest
24 training
25 A
26 B
27 A
28 C
29 B
30 D
Section 4, Questions 31–40
31 B
32 A
33 A
34 C
35 A
36 B
37 B
38 A
39 B
40 C
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. sales

22. competition

23. interest rates / rates of interest

24. training

25. A

26. B

27. A

28. C

29. B

30. D

### Part 4 · source page 159

TEST 4 LISTENING
Section 1, Questions 1–10
1 14 Hill Road
2 between 9 and 9.30 / 9–9.30
3 1 year
4 intermediate
5 North-West
6 vegetarian
7 (a) (real) garden
8 (the) only guest
9 100
10 23rd March / Monday 23rd March
Section 2, Questions 11–20
11 clubhouse
12 picnic
13 prizes
14 10
15 Wednesday afternoon(s)
16 4
17 Sunday afternoon(s)
18 collect (the) fees / collect (the) money
19 send (out/the) newsletter(s)
20 supervise (the) teams
Section 3, Questions 21–30
21 sales
22 competition
23 interest rates / rates of interest
24 training
25 A
26 B
27 A
28 C
29 B
30 D
Section 4, Questions 31–40
31 B
32 A
33 A
34 C
35 A
36 B
37 B
38 A
39 B
40 C
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. B

32. A

33. A

34. C

35. A

36. B

37. B

38. A

39. B

40. C

## A 类阅读

### Academic Reading · source page 160

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 iii
2 v
3 ii
4 YES
5 YES
6 NO
7 YES
8 NO
9 NOT GIVEN
10 cheese
11 tourism / tourist / tour
12 pottery
13 jewellery / jewelry
Reading Passage 2, Questions 14–26
14 G
15 A
16 H
17 C
18 F
19 I
20 C
21 K
22 E
23 L
24 TRUE
25 NOT GIVEN
26 FALSE
Reading Passage 3, Questions 27–40
27 TRUE
28 TRUE
29 NOT GIVEN
30 FALSE
31 FALSE
32 TRUE
33 FALSE
34 temperatures
35 day-neutral / day-neutral plants
36 food / food resources / adequate food / adequate food resources
37 insects / fertilization by insects
38 rainfall / suitable rainfall
39 sugarcane
40 classification
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. iii

2. v

3. ii

4. YES

5. YES

6. NO

7. YES

8. NO

9. NOT GIVEN

10. cheese

11. tourism / tourist / tour

12. pottery

13. jewellery / jewelry

14. G

15. A

16. H

17. C

18. F

19. I

20. C

21. K

22. E

23. L

24. TRUE

25. NOT GIVEN

26. FALSE

27. TRUE

28. TRUE

29. NOT GIVEN

30. FALSE

31. FALSE

32. TRUE

33. FALSE

34. temperatures

35. day-neutral / day-neutral plants

36. food / food resources / adequate food / adequate food resources

37. insects / fertilization by insects

38. rainfall / suitable rainfall

39. sugarcane

40. classification

## A 类写作

### Writing material: c5-t4-w-1

Original table inspected. Columns: city, date opened, kilometres of route, passengers per year in millions. London: 1863,394 km,775 million passengers; Paris: 1900,199 km,1191 million; Tokyo: 1927,155 km,1927 million; Washington DC: 1976,126 km,144 million; Kyoto: 1981,11 km,45 million; Los Angeles: 2001,28 km,50 million. Opening years are not annual passenger numbers even where Tokyo's passenger figure equals its opening year. London is oldest and has the longest route; Tokyo carries the most passengers; Paris ranks second on route length and passengers. Kyoto has the shortest network and fewest passengers; Los Angeles is newest and also relatively small. Washington DC has a much longer route than Kyoto or Los Angeles but far fewer passengers than the three older large systems. Do not infer changes over time, fares or passenger counts per station.



### Writing material: c5-t4-w-2

Compare inherited characteristics and life experiences as influences on personality and development, and identify the major influence in a supported position. The prompt mentions research but provides no named study or statistics; no invented citation is required.



## 口语
