# 剑雅 5 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/0058321f41de801b3ef4c8eb764b98a798136e222a7db59bbf46cf0982e15a56.jpg; PDF page 79; full -->

```text
LISTENING SECTION 1 Questions 1–10
Complete the form below. Write NO MORE THAN THREE WORDS AND/OR NUMBERS for each answer.
HOST FAMILY APPLICANT
Example: Name — Jenny Chan
Present address: Sea View Guest House, (1) __________
Daytime phone number: 2237676
[NB Best time to contact is (2) __________]
Age: 19
Intended length of stay: (3) __________
Occupation while in UK: student
General level of English: (4) __________
Preferred location: in the (5) __________
Special diet: (6) __________
Other requirements: own facilities; own television; (7) __________; to be (8) __________
Maximum price: (9) £__________ a week
Preferred starting date: (10) __________
```

[Original question page](assets/0058321f41de801b3ef4c8eb764b98a798136e222a7db59bbf46cf0982e15a56.jpg)

### Part 2

<!-- Source: /api/assets/4719214639ded9ca83e09b0454e1cd1f34e6d1dec3060be69644f81e58e2d196.jpg; PDF page 80; full -->

```text
Listening
SECTION 2 Questions 11- 20
Questions 11-13
Complete the sentences below.
Write NO MORE THAN TWO WORDS for each answer.
11 The next meeting of the soccer club will be in the ................ ........ in King's Park on 2
July.
12 The first event is a ...... ... ...... ....... .. .
13 At the final dinner, players receive ..... .......... ........ . .
Questions 14-17
Complete the table below.
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Competition Number of Teams Games Begin Training Session
(in King's Park)
Junior 14 ........................ 8.30 am 15 ........................
························
Senior 16 ........................ 2.00 pm 17 ........................
························
79
```

[Original question page](assets/4719214639ded9ca83e09b0454e1cd1f34e6d1dec3060be69644f81e58e2d196.jpg)

<!-- Source: /api/assets/1cbcb88e19ac00f8bdcfffead4c24bcefce63135a90176f89df0e96b11a026a0.jpg; PDF page 81; full -->

```text
Test 4
Questions 18-20
Complete the table below.
Write NO MORE THAN THREE WORDS for each answer.
Name of Office Bearer Responsibility
Robert Young: President to manage meetings
Gina Costello: Treasurer to 18 ........................
David West: Secretary to 19 ........................
Jason Dokic: Head Coach to 20 ....................... .
80
```

[Original question page](assets/1cbcb88e19ac00f8bdcfffead4c24bcefce63135a90176f89df0e96b11a026a0.jpg)

### Part 3

<!-- Source: /api/assets/9405ef11585c55e9d64e064d8cc9ff9b6d8802148d2dd4b9ea76fd768d3563cc.jpg; PDF page 82; full -->

```text
Listening
SECTION 3 Questions 21-30
Questions 21-24
Complete the notes below.
Write NO MORE THAN THREE WORDS for each answer.
Box Telecom
Problems: been affected by • drop in 21 ....................... .
• growing 22 ....................... .
• delays due to a strike
Causes of problems: • high 23 ....................... .
• lack of good 24 ....................... .
Questions 25-27
Choose the correct letter, A, B or C
25 What does Karin think the company will do?
A look for private investors
B accept a takeover offer
C issue some new shares
26 How does the tutor suggest the company can recover?
A by appointing a new managing director
B by changing the way it is organised
C by closing some of its retail outlets
27 The tutor wants Jason and Karin to produce a report which
A offers solutions to Box Telecom's problems.
B analyses the UK market.
C compares different companies.
81
```

[Original question page](assets/9405ef11585c55e9d64e064d8cc9ff9b6d8802148d2dd4b9ea76fd768d3563cc.jpg)

<!-- Source: /api/assets/eb371b3b1adaf7d1ca31dc687c9dae2b173de3c389f11b57360d2d8c6a116468.jpg; PDF page 83; full -->

```text
Test 4
Questions 28-30
Which opinion does each person express about Box Telecom?
Choose your answers from the box and write the letters A-F next to questions 28-30.
28 Karin __________
29 Jason __________
30 the tutor __________
```

[Original question page](assets/eb371b3b1adaf7d1ca31dc687c9dae2b173de3c389f11b57360d2d8c6a116468.jpg)

### Part 4

<!-- Source: /api/assets/a17f30c7c8000fc6075b799e32decc1c32c7e7ccd1b3c2f7ef9b41d6d79315ac.jpg; PDF page 84; full -->

```text
Listening
SECTION 4 Questions 31-40
Questions 31-36
Choose the correct letter. A, B or C.
31 During the first week of term, students are invited to
A be shown round the library by the librarian .
B listen to descriptions of library resources.
C do an intensive course in the computer centre.
32 The speaker warns the students that
A internet materials can be unreliable.
B downloaded information must be acknowledged.
C computer access may be limited at times.
33 The library is acquiring more CDs as a resource because
A they are a cheap source of information.
B they take up very little space.
C they are more up to date than the reference books.
34 Students are encouraged to use journals online because
A the articles do not need to be returned to the shelves.
B reading online is cheaper than photocopying articles.
C the stock of printed articles is to be reduced.
35 Why might some students continue to use reference books?
A they can be taken away from the library
B they provide information unavailable elsewhere
C they can be borrowed for an extended loan period
36 What is the responsibility of the Training Supervisor?
A to supervise and support library staff
B to provide orientation to the library facilities
C to identify needs and inform section managers
83
```

[Original question page](assets/a17f30c7c8000fc6075b799e32decc1c32c7e7ccd1b3c2f7ef9b41d6d79315ac.jpg)

<!-- Source: /api/assets/cfa2d30eaf5c033ea2039fc3f01ce88a69d754913270949cd12466105b53c202.jpg; PDF page 85; full -->

```text
Test4
Questions 37-40
Which section of the university will help postgraduate students with their dissertations in the
following ways?
A the postgraduate's own department or tutor
B library staff
C another section of the university
Write the correct letter. A, B or C. next to questions 37-40.
37 training in specialised computer programs
38 advising on bibliography presentation
39 checking the draft of the dissertation
40 providing language support
84
```

[Original question page](assets/cfa2d30eaf5c033ea2039fc3f01ce88a69d754913270949cd12466105b53c202.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/4530affb212deccb7995c0a6b9b9b496114eecb9f9e2332bf61703e1a7ea5350.jpg; PDF page 86; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage 1
on the following pages.
Questions 1-3
Reading Passage 1 has three sections, A-C.
Choose the correct heading for each section from the list of headings below.
Write the correct number i-vi in boxes 1- 3 on your answer sheet.
1 Section A
2 Section B
3 Section C
List of Headings
i The expansion of international tourism in recent
years
ii How local communities can balance their own
needs with the demands of wilderness tourism
iii Fragile regions and the reasons for the expansion
of tourism there
iv Traditional methods of food-supply in fragile
regions
v Some of the disruptive effects of wilderness
tourism
vi The economic benefits of mass tourism
85
```

[Original question page](assets/4530affb212deccb7995c0a6b9b9b496114eecb9f9e2332bf61703e1a7ea5350.jpg)

<!-- Source: /api/assets/2d223156f46de0d70e872a59cf8ae2b5efc67ce5eb96cfb59b3b58d653bec83a.jpg; PDF page 87; full -->

```text
The Impact of Wilderness Tourism
Test 4
A
The market for tourism in remote areas is booming as never before . Countries all
across the world are actively promoting their 'wilderness ' regions - such as
mountains , Arctic lands , deserts, small islands and wetlands - to high-spending
tourists. The attraction of these areas is obvious: by definition, wilderness tourism
requires little or no initial investment. But that does not mean that there is no cost.
As the 1992 United Nations Conference on Environment and Development
recognized, these regions are fragile (i.e. highly vulnerable to abnormal pressures)
not just in terms of their ecology, but also in terms of the culture of their inhabitants.
The three most significant types of fragile environment in these respects, and also in
terms of the proportion of the Earth’s surface they cover, are deserts, mountains and
Arctic areas. An important characteristic is their marked seasonality , with harsh
conditions prevailing for many months each year. Consequently, most human
activities, including tourism, are limited to quite clearly defined parts of the year.
Tourists are drawn to these regions by their natural landscape beauty and the
unique cultures of their indigenous people . And poor governments in these
isolated areas have welcomed the new breed of 'adventure tourist', grateful for
the hard currency they bring . For several years now, tourism has been the prime
source of foreign exchange in Nepal and Bhutan. Tourism is also a key element in
the economies of Arctic zones such as Lapland and Alaska and in desert areas
such as Ayers Rock in Australia and Arizona 's Monument Valley.
B
Once a location is established as a main tourist destination , the effects on the local
community are profound . When hill-farmers, for example , can make more money
in a few weeks working as porters for foreign trekkers than they can in a year
working in their fields, it is not surprising that many of them give up their
farm-work, which is thus left to other members of the family. In some hill-regions,
this has led to a serious decline in farm output and a change in the local diet,
because there is insufficient labour to maintain terraces and irrigation systems and
tend to crops. The result has been that many people in these regions have turned
to outside supplies of rice and other foods.
In Arctic and desert societies, year-round survival has traditionally depended on
hunting animals and fish and collecting fruit over a relatively short season.
However, as some inhabitants become involved in tourism, they no longer have
time to collect wild food ; this has led to increasing dependence on bought food
and stores. Tourism is not always the culprit behind such changes. All kinds of
wage labour , or government handouts, tend to undermine traditional survival
86
```

[Original question page](assets/2d223156f46de0d70e872a59cf8ae2b5efc67ce5eb96cfb59b3b58d653bec83a.jpg)

<!-- Source: /api/assets/85ce711214dac50ede3063819bb5b5419ad15006eaa5439739fc29d62f46babb.jpg; PDF page 88; full -->

```text
Reading
systems. Whatever the cause, the dilemma is always the same: what happens if
these new, external sources of income dry up?
The physical impact of visitors is another serious problem associated with the
growth in adventure tourism. Much attention has focused on erosion along major
trails, but perhaps more important are the deforestation and impacts on water
supplies arising from the need to provide tourists with cooked food and hot showers.
In both mountains and deserts , slow-growing trees are often the main sources of fuel
and water supplies may be limited or vulnerable to degradation through heavy use.
C
Stories about the problems of tourism have become legion in the last few years. Yet
it does not have to be a problem. Although tourism inevitably affects the region in
which it takes place , the costs to these fragile environments and their local cultures
can be minimized. Indeed, it can even be a vehicle for reinvigorating local cultures,
as has happened with the Sherpas of Nepal's Khumbu Valley and in some Alpine
villages. And a growing number of adventure tourism operators are trying to ensure
that their activities benefit the local population and environment over the long term.
In the Swiss Alps , communities have decided that their future depends on
integrating tourism more effectively with the local economy. Local concern about
the rising number of second home developments in the Swiss Pays d'Enhaut
resulted in limits being imposed on their growth . There has also been a
renaissance in communal cheese production in the area , providing the locals with
a reliable source of income that does not depend on outside visitors.
Many of the Arctic tourist destinations have been exploited by outside
companies, who employ transient workers and repatriate most of the profits to
their home base. But some Arctic communities are now operating tour businesses
themselves , thereby ensuring that the benefits accrue locally. For instance. a native
corporation in Alaska, employing local people , is running an air tour from
Anchorage to Kotzebue, where tourists eat Arctic food, walk on the tundra and
watch local musicians and dancers.
Native people in the desert regions of the American Southwest have followed
similar strategies, encouraging tourists to visit their pueblos and reservations to
purchase high -quality handicrafts and artwork. The Acoma and San Ildefonso
pueblos have established highly profitable pottery businesses, while the Navajo
and Hopi groups have been similarly successful with jewellery.
Too many people living in fragile environments have lost control over their
economies , their culture and their environment when tourism has penetrated their
homelands. Merely restricting tourism cannot be the solution to the imbalance ,
because people's desire to see new places will not just disappear. Instead,
communities in fragile environments must achieve greater control over tourism
ventures in their regions , in order to balance their needs and aspirations with the
demands of tourism. A growing number of communities are demonstrating that,
with firm communal decision-making , this is possible. The critical question now is
whether this can become the norm, rather than the exception.
87
```

[Original question page](assets/85ce711214dac50ede3063819bb5b5419ad15006eaa5439739fc29d62f46babb.jpg)

<!-- Source: /api/assets/8ce560366926441e68be7bb9113f78cb434fa32bbcf781a68ea463b6ba93952b.jpg; PDF page 89; full -->

```text
Test 4
Questions 4-9
Do the following statements reflect the opinion of the writer of Reading Passage 1?
In boxes 4- 9 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement reflects the opinion of the writer
if the statement contradicts the opinion of the writer
if it is impossible to say what the writer thinks about this
4 The low financial cost of setting up wilderness tourism makes it attractive to many
countries .
5 Deserts, mountains and Arctic regions are examples of environments that are both
ecologically and culturally fragile.
6 Wilderness tourism operates throughout the year in fragile areas.
7 The spread of tourism in certain hill-regions has resulted in a fall in the amount of
food produced locally.
8 Traditional food-gathering in desert societies was distributed evenly over the year.
9 Government handouts do more damage than tourism does to traditional patterns of
food-gathering .
Questions 10-13
Complete the table below.
Choose ONE WORD from Reading Passage 1 for each answer.
Write your answers in boxes 10- 13 on your answer sheet.
The positive ways in which some local communities have
responded to tourism
People/Location Activity
Swiss Pays d'Enhaut Revived production of 10 ............ ............
Arctic communities Operate 11 ............. ...... ..... businesses
Acoma and San Ildefonso Produce and sell 12 ··········· ·············
Navajo and Hopi Produce and sell 13 ................ ........
88
```

[Original question page](assets/8ce560366926441e68be7bb9113f78cb434fa32bbcf781a68ea463b6ba93952b.jpg)

<!-- Source: /api/assets/771afd00df229df4770cb59e676a2b7737bd52f6137dd9dc34618812c99ebc92.jpg; PDF page 90; full -->

```text
READING PASSAGE 2



Reading



You should spend about 20 minutes on Questions 14-26, which are based on Reading Passage 2



below.



Flawed Beauty: the problem with toughened glass



On 2nd August 1999, a particularly hot day

in the town of Cirencester in the UK, a large

pane of toughened glass in the roof of a

shopping centre at Bishops Walk shattered

without warning and fell from its frame.

When fragments were analysed by experts

at the giant glass manufacturer Pilkington,

which had made the pane, they found that

minute crystals of nickel sulphide trapped

inside the glass had almost certainly caused

the failure.



‘The glass industry is aware of the issue,’

says Brian Waldron, chairman of the

standards committee at the Glass and

Glazing Federation, a British trade

association, and standards development

officer at Pilkington. But he insists that

cases are few and far between. ‘It’s a very

rare phenomenon,’ he says.



Others disagree. ‘On average I see about

one or two buildings a month suffering from

nickel sulphide related failures,’ says Barrie

Josie, a consultant engineer involved in the

Bishops Walk investigation. Other experts

tell of similar experiences. Tony Wilmott of

London-based consulting engineers

Sandberg, and Simon Armstrong at CladTech

Associates in Hampshire both say they know

of hundreds of cases. ‘What you hear is only

the tip of the iceberg,’ says Trevor Ford, a

glass expert at Resolve Engineering in

Brisbane, Queensland. He believes the

reason is simple: ‘No-one wants bad press.’



Toughened glass is found everywhere, from

cars and bus shelters to the windows, walls

and roofs of thousands of buildings around

the world. It's easy to see why. This glass

has five times the strength of standard

glass, and when it does break it shatters

into tiny cubes rather than large, razor-sharp

shards. Architects love it because large

panels can be bolted together to make

transparent walls, and turning it into ceilings

and floors is almost as easy.



It is made by heating a sheet of ordinary

glass to about 620°C to soften it slightly,

allowing its structure to expand, and then

cooling it rapidly with jets of cold air. This

causes the outer layer of the pane to

contract and solidify before the interior.

When the interior finally solidifies and

shrinks, it exerts a pull on the outer layer

that leaves it in permanent compression

and produces a tensile force inside the

glass. As cracks propagate best in materials

under tension, the compressive force on the

surface must be overcome before the pane

will break, making it more resistant to

cracking.



The problem starts when glass contains

nickel sulphide impurities. Trace amounts of

nickel and sulphur are usually present in the

raw materials used to make glass, and

nickel can also be introduced by fragments

of nickel alloys falling into the molten glass.

As the glass is heated, these atoms react to



89
```

[Original question page](assets/771afd00df229df4770cb59e676a2b7737bd52f6137dd9dc34618812c99ebc92.jpg)

<!-- Source: /api/assets/bc01e748daa468d57d5c93aaaf8288b6fbedbe7fb7a577ecc6dd1d55fd6d758e.jpg; PDF page 91; full -->

```text
Test 4



form tiny crystals of nickel sulphide. Just a

tenth of a gram of nickel in the furnace can

create up to 50,000 crystals.



These crystals can exist in two forms: a

dense form called the alpha phase, which is

stable at high temperatures, and a less

dense form called the beta phase, which is

stable at room temperatures. The high

temperatures used in the toughening

process convert all the crystals to the

dense, compact alpha form. But the

subsequent cooling is so rapid that the



crystals don't have time to change back to

the beta phase. This leaves unstable alpha



crystals in the glass, primed like a coiled

spring, ready to revert to the beta phase

without warning.



When this happens, the crystals expand by

up to 4%. And if they are within the central,

tensile region of the pane, the stresses this

unleashes can shatter the whole sheet. The

time that elapses before failure occurs is

unpredictable. It could happen just months

after manufacture, or decades later,

although if the glass is heated — by

sunlight, for example — the process is

speeded up. Ironically, says Graham Dodd,

of consulting engineers Arup in London, the

oldest pane of toughened glass known to

have failed due to nickel sulphide inclusions

was in Pilkington’s glass research building

in Lathom, Lancashire. The pane was



27 years old.



Data showing the scale of the nickel

sulphide problem is almost impossible to






find. The picture is made more complicated

by the fact that these crystals occur in

batches. So even if, on average, there is

only one inclusion in 7 tonnes of glass, if

you experience one nickel sulphide failure

in your building, that probably means

you've got a problem in more than one

pane. Josie says that in the last decade



he has worked on over 15 buildings with

the number of failures into double figures.



One of the worst examples of this is

Waterfront Place, which was completed in

1990. Over the following decade the 40-

storey Brisbane block suffered a rash of

failures. Eighty panes of its toughened glass

shattered due to inclusions before experts

were finally called in. John Barry, an expert

in nickel sulphide contamination at the

University of Queensland, analysed every

glass pane in the building. Using a studio

camera, a photographer went up in a cradle

to take photos of every pane. These were

scanned under a modified microfiche reader

for signs of nickel sulphide crystals. ‘We

discovered at least another 120 panes with

potentially dangerous inclusions which were

then replaced,’ says Barry. ‘It was a very

expensive and time-consuming process that

took around six months to complete.’

Though the project cost A$1.6 million (nearly

£700,000), the alternative — re-cladding the

entire building - would have cost ten times

as much.
```

[Original question page](assets/bc01e748daa468d57d5c93aaaf8288b6fbedbe7fb7a577ecc6dd1d55fd6d758e.jpg)

<!-- Source: /api/assets/9f1c09805f1eeea9cd6988ac08b01c29a66167f2ee390b9ef15633c4a6679438.jpg; PDF page 92; full -->

```text
Questions 14-17
Look at the following people and the list of statements below.
Match each person with the correct statement.
Write the correct letter A-H in boxes 14-17 on your answer sheet.
14 Brian Waldron
15 Trevor Ford
16 Graham Dodd
17 John Barry
List of Statements
A suggests that publicity about nickel sulphide failure has been
suppressed
B regularly sees cases of nickel sulphide failure
C closely examined all the glass in one building
D was involved with the construction of Bishops Walk
E recommended the rebuilding of Waterfront Place
F thinks the benefits of toughened glass are exaggerated
G claims that nickel sulphide failure is very unusual
H refers to the most extreme case of delayed failure
Reading
91
```

[Original question page](assets/9f1c09805f1eeea9cd6988ac08b01c29a66167f2ee390b9ef15633c4a6679438.jpg)

<!-- Source: /api/assets/d619751edce3742ad3e693cdcb913bfc449d64afcb2cc84306239f7b72f7f78e.jpg; PDF page 93; full -->

```text
Test 4
Questions 18-23
Complete the summary with the list of words A-P below.
Write your answers in boxes 18–23 on your answer sheet.
92
Toughened Glass
Toughened glass is favoured by architects because it is much stronger than ordinary
glass, and the fragments are not as 18 ........................ when it breaks. However, it has
one disadvantage : it can shatter 19 ............. ............ This fault is a result of the
manufacturing process. Ordinary glass is first heated, then cooled very
20 ......................... The outer layer 21 ....................... . before the inner layer, and the
tension between the two layers which is created because of this makes the glass stronger.
However, if the glass contains nickel sulphide impurities, crystals of nickel sulphide are
formed. These are unstable, and can expand suddenly, particularly if the weather is
22 ............... ........ . . If this happens, the pane of glass may break. The frequency with
which such problems occur is 23 ........................ by glass experts. Furthermore, the
crystals cannot be detected without sophisticated equipment.
A numerous B detected C quickly
D agreed E warm F sharp
G expands H slowly I unexpectedly
J removed K contracts L disputed
M cold N moved O small
P calculated
```

[Original question page](assets/d619751edce3742ad3e693cdcb913bfc449d64afcb2cc84306239f7b72f7f78e.jpg)

<!-- Source: /api/assets/692b313aeb5a113543cf34fb8f895160e59b8e07d7ffeaf4508d35124e46c76e.jpg; PDF page 94; full -->

```text
Questions 24-26
Do the following statements agree with the information given in Reading Passage 2?
In boxes 24-26 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
24 Little doubt was expressed about the reason for the Bishops Walk accident .
25 Toughened glass has the same appearance as ordinary glass.
Reading
26 There is plenty of documented evidence available about the incidence of nickel sulphide
failure.
93
```

[Original question page](assets/692b313aeb5a113543cf34fb8f895160e59b8e07d7ffeaf4508d35124e46c76e.jpg)

<!-- Source: /api/assets/46de0e5283e79bae5ff2de8093281a33543a78b44e95c228ba26a41cc368eea4.jpg; PDF page 95; full -->

```text
Test 4



READING PASSAGE 3



You should spend about 20 minutes on Questions 27-40, which are based on Reading Passage 3

below.



The effects of light on plant and animal species



Light is important to organisms for two different reasons. Firstly it is used as a cue for the

timing of daily and seasonal rhythms in both plants and animals, and secondly it is used to

assist growth in plants.



Breeding in most organisms occurs during a part of the year only, and so a reliable cue is

needed to trigger breeding behaviour. Day length is an excellent cue, because it provides a

perfectly predictable pattern of change within the year. In the temperate zone in spring,

temperatures fluctuate greatly from day to day, but day length increases steadily by a

predictable amount. The seasonal impact of day length on physiological responses is called

photoperiodism, and the amount of experimental evidence for this phenomenon is

considerable. For example, some species of birds’ breeding can be induced even in midwinter

simply by increasing day length artificially (Wolfson 1964). Other examples of photoperiodism

occur in plants. A short-day plant flowers when the day is less than a certain critical length. A

long-day plant flowers after a certain critical day length is exceeded. In both cases the critical

day length differs from species to species. Plants which flower after a period of vegetative

growth, regardless of photoperiod, are known as day-neutral plants.



Breeding seasons in animals such as birds have evolved to occupy the part of the year in

which offspring have the greatest chances of survival. Before the breeding season begins, food

reserves must be built up to support the energy cost of reproduction, and to provide for

young birds both when they are in the nest and after fledging. Thus many temperate-zone

birds use the increasing day lengths in spring as a cue to begin the nesting cycle, because this

is a point when adequate food resources will be assured.



The adaptive significance of photoperiodism in plants is also clear. Short-day plants that

flower in spring in the temperate zone are adapted to maximising seedling growth during the

growing season. Long-day plants are adapted for situations that require fertilization by insects,

or a long period of seed ripening. Short-day plants that flower in the autumn in the

temperate zone are able to build up food reserves over the growing season and over winter

as seeds. Day-neutral plants have an evolutionary advantage when the connection between

the favourable period for reproduction and day length is much less certain. For example,

desert annuals germinate, flower and seed whenever suitable rainfall occurs, regardless of the

day length.



94
```

[Original question page](assets/46de0e5283e79bae5ff2de8093281a33543a78b44e95c228ba26a41cc368eea4.jpg)

<!-- Source: /api/assets/25feeb4c86d5eef68ad4d1c48662046ffc8c2b92bb6eec0fe7f3b025ac13f923.jpg; PDF page 96; full -->

```text
Reading



The breeding season of some plants can be delayed to extraordinary lengths. Bamboos are

perennial grasses that remain in a vegetative state for many years and then suddenly flower,

fruit and die (Evans 1976). Every bamboo of the species Chusquea abietifolia on the island



of Jamaica flowered, set seed and died during 1884. The next generation of bamboo flowered

and died between 1916 and 1918, which suggests a vegetative cycle of about 31 years. The

climatic trigger for this flowering cycle is not yet known, but the adaptive significance is clear.

The simultaneous production of masses of bamboo seeds (in some cases lying 12 to 15

centimetres deep on the ground) is more than all the seed-eating animals can cope with at

the time, so that some seeds escape being eaten and grow up to form the next generation

(Evans 1976).



The second reason light is important to organisms is that it is essential for photosynthesis. This

is the process by which plants use energy from the sun to convert carbon from soil or water

into organic material for growth. The rate of photosynthesis in a plant can be measured by



calculating the rate of its uptake of carbon. There is a wide range of photosynthetic

responses of plants to variations in light intensity. Some plants reach maximal photosynthesis

at one-quarter full sunlight, and others, like sugarcane, never reach a maximum, but continue

to increase photosynthesis rate as light intensity rises.



Plants in general can be divided into two groups: shade-tolerant species and shade-intolerant

species. This classification is commonly used in forestry and horticulture. Shade-tolerant

plants have lower photosynthetic rates and hence have lower growth rates than those of

shade-intolerant species. Plant species become adapted to living in a certain kind of habitat,

and in the process evolve a series of characteristics that prevent them from occupying other

habitats. Grime (1966) suggests that light may be one of the major components directing

these adaptations. For example, eastern hemlock seedlings are shade-tolerant. They can

survive in the forest understorey under very low light levels because they have a low

photosynthetic rate.



95
```

[Original question page](assets/25feeb4c86d5eef68ad4d1c48662046ffc8c2b92bb6eec0fe7f3b025ac13f923.jpg)

<!-- Source: /api/assets/21fcbc78b84508d8600157e155f4c0f280b73ef9c2a03d5e206c55c984cb3249.jpg; PDF page 97; full -->

```text
Test4
Questions 27-33
Do the following statements agree with the information given in Reading Passage 3?
In boxes 27-33 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
27 There is plenty of scientific evidence to support photoperiodism.
28 Some types of bird can be encouraged to breed out of season.
29 Photoperiodism is restricted to certain geographic areas.
30 Desert annuals are examples of long-day plants.
31 Bamboos flower several times during their life cycle.
32 Scientists have yet to determine the cue for Chusquea abietifolia’s seasonal rhythm.
33 Eastern hemlock is a fast-growing plant.
96
```

[Original question page](assets/21fcbc78b84508d8600157e155f4c0f280b73ef9c2a03d5e206c55c984cb3249.jpg)

<!-- Source: /api/assets/28b8e8e6e90a36671ff8acfa44b8c8c9e97fe62fb0c2eb7f5aa5f155899f5923.jpg; PDF page 98; full -->

```text
Reading
Questions 34-40
Complete the sentences.
Choose NO MORE THAN THREE WORDS from the passage for each answer.
Write your answers in boxes 34-40 on your answer sheet.
34 Day length is a useful cue for breeding in areas where ..................... ... are unpredictable .
35 Plants which do not respond to light levels are referred to as ........ ................ .
36 Birds in temperate climates associate longer days with nesting and the availability
of ....... ................. .
37 Plants that flower when days are long often depend on ........................ to help them
reproduce.
38 Desert annuals respond to ........................ as a signal for reproduction.
39 There is no limit to the photosynthetic rate in plants such as ....................... . .
40 Tolerance to shade is one criterion for the ..... ............. ...... of plants in forestry and
horticulture.
97
```

[Original question page](assets/28b8e8e6e90a36671ff8acfa44b8c8c9e97fe62fb0c2eb7f5aa5f155899f5923.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/b637213d1fa4d7fc4dd8eec50527368d4414e9352bb7ca3fc3aa27209d21d19d.jpg; PDF page 99; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The table below gives information about the underground railway systems in six cities.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/b637213d1fa4d7fc4dd8eec50527368d4414e9352bb7ca3fc3aa27209d21d19d.jpg)

![Original figure](assets/b637213d1fa4d7fc4dd8eec50527368d4414e9352bb7ca3fc3aa27209d21d19d.jpg)

### Task 2

<!-- Source: /api/assets/ce2800b4877bf0c059a7da67389a7f194450a825b012d24d47c0b13a67a56078.jpg; PDF page 100; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Research indicates that the characteristics we are born with have much more influence on our personality and development than any experiences we may have in our life.

Which do you consider to be the major influence?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/ce2800b4877bf0c059a7da67389a7f194450a825b012d24d47c0b13a67a56078.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/2714d250c034946c2dd42c466918f7010c6cfdd400a704f6e4ba76a6ec5049ee.jpg; PDF page 101; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Clothes
• How important are clothes and fashion to you? [Why/Why not?]
• What kind of clothes do you dislike? [Why?]
• How different are the clothes you wear now from those you wore 10 years ago?
• What do you think the clothes we wear say about us?
PART 2
Describe a festival that is important in your country.
You should say: when the festival occurs; what you did during it; what you like or dislike about it; and explain why this festival is important.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you’re going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Purpose of festivals and celebrations
Example questions:
Why do you think festivals are important events in the working year?
Would you agree that the original significance of festivals is often lost today? Is it good or
bad, do you think?
Do you think that new festivals will be introduced in the future? What kind?
Festivals and the media
Example questions:
What role does the media play in festivals, do you think?
Do you think it's good or bad to watch festivals on TV? Why?
How may globalisation affect different festivals around the world?
100
```

[Original question page](assets/2714d250c034946c2dd42c466918f7010c6cfdd400a704f6e4ba76a6ec5049ee.jpg)

### Part 2

<!-- Source: /api/assets/2714d250c034946c2dd42c466918f7010c6cfdd400a704f6e4ba76a6ec5049ee.jpg; PDF page 101; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Clothes
• How important are clothes and fashion to you? [Why/Why not?]
• What kind of clothes do you dislike? [Why?]
• How different are the clothes you wear now from those you wore 10 years ago?
• What do you think the clothes we wear say about us?
PART 2
Describe a festival that is important in your country.
You should say: when the festival occurs; what you did during it; what you like or dislike about it; and explain why this festival is important.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you’re going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Purpose of festivals and celebrations
Example questions:
Why do you think festivals are important events in the working year?
Would you agree that the original significance of festivals is often lost today? Is it good or
bad, do you think?
Do you think that new festivals will be introduced in the future? What kind?
Festivals and the media
Example questions:
What role does the media play in festivals, do you think?
Do you think it's good or bad to watch festivals on TV? Why?
How may globalisation affect different festivals around the world?
100
```

[Original question page](assets/2714d250c034946c2dd42c466918f7010c6cfdd400a704f6e4ba76a6ec5049ee.jpg)

### Part 3

<!-- Source: /api/assets/2714d250c034946c2dd42c466918f7010c6cfdd400a704f6e4ba76a6ec5049ee.jpg; PDF page 101; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Clothes
• How important are clothes and fashion to you? [Why/Why not?]
• What kind of clothes do you dislike? [Why?]
• How different are the clothes you wear now from those you wore 10 years ago?
• What do you think the clothes we wear say about us?
PART 2
Describe a festival that is important in your country.
You should say: when the festival occurs; what you did during it; what you like or dislike about it; and explain why this festival is important.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you’re going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Purpose of festivals and celebrations
Example questions:
Why do you think festivals are important events in the working year?
Would you agree that the original significance of festivals is often lost today? Is it good or
bad, do you think?
Do you think that new festivals will be introduced in the future? What kind?
Festivals and the media
Example questions:
What role does the media play in festivals, do you think?
Do you think it's good or bad to watch festivals on TV? Why?
How may globalisation affect different festivals around the world?
100
```

[Original question page](assets/2714d250c034946c2dd42c466918f7010c6cfdd400a704f6e4ba76a6ec5049ee.jpg)
