# 剑雅 2 · Test 3

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

> Academic Reading: PDF page 29 R: The original Strategy3 heading ends with and, and the original contains truncated Registered an / loca wording; no continuation is invented.

## 听力

### Part 1

<!-- Source: /api/assets/4402b44a510f2f6e85b96157c4978e37a0cc1f818b06324fa8aec2be670b7674.jpg; PDF page 25; L -->

```text
Test 3
Listening
SECTION 1 Questions 1-10
Questions 1-4
Circle the correct letters A-C.
Example
The respondent is
A 20-33 years old
(B) 34-54 years old
C over 54 years old
1 The respondent works in ...
A the professions.
B business.
C other.
2 The respondent has a salary of ...
A 0-£15,000 a year.
B £15,000–£35,000 a year.
C over £35,000 a year.
3 The respondent watches TV for ...
A relaxation.
B entertainment.
C information.
4 Every day the respondent watches TV for ...
A 30 minutes–1 hour.
B 1 hour–2 hours.
C more than 2 hours.
```

[Original question page](assets/4402b44a510f2f6e85b96157c4978e37a0cc1f818b06324fa8aec2be670b7674.jpg)

<!-- Source: /api/assets/c2fd6e69d1065c6b80ff24e8a78ef8fd6618922886b3b87ec8caccfceab09a6a.jpg; PDF page 25; R -->

```text
Questions 5-7
Choose TWO letters A–E for each of Questions5–7.
5 The respondent mainly watches TV ...
A in the early morning.
B around midday.
C in the afternoon.
D in the early evening.
E at night.
6 On the new channel, the respondent would like to see more ...
A children's programmes.
B documentaries.
C local service programmes.
D travel programmes.
E health programmes.
7 The respondent would advise the new channel to ...
A spend more money on drama.
B train their broadcasters to higher standards.
C improve sound quality.
D broadcast interviews with famous people.
E talk more to customers.
Questions 8-10
Circle the correct letters A-C.
8 The respondent feels that adverts should occur every ...
A 10 minutes.
B 15 minutes.
C 20 minutes.
9 The respondent would like to attend special promotions if ...
A expenses are paid.
B he is invited specially.
C they are held locally.
10 The respondent would like to receive ...
A no mail.
B requested mail.
C all mail.
```

[Original question page](assets/c2fd6e69d1065c6b80ff24e8a78ef8fd6618922886b3b87ec8caccfceab09a6a.jpg)

### Part 2

<!-- Source: /api/assets/8de7baab482661b196ac700102ae029329d9ff00f9dd9e1409e5ba8b8fc69647.jpg; PDF page 26; L -->

```text
SECTION 2 Questions 11–20
Questions 11-14
Circle FOUR letters A-G.
Which FOUR activities of the Union are mentioned by the speaker?
A raising money for good causes
B political campaigning
C running a newsagent's
D running a supermarket
E providing cheap tickets
F helping with accommodation
G providing catering services
Questions 15 and 16
Circle TWO letters A-E.
Which TWO of the following can you get advice about from the Union?
A immigration
B grants
C medical problems
D personal problems
E legal matters
```

[Original question page](assets/8de7baab482661b196ac700102ae029329d9ff00f9dd9e1409e5ba8b8fc69647.jpg)

<!-- Source: /api/assets/9d4c0d7d622dd8eef827d9622f74ecc87deabc38fdf4d71a6354678fe7fda9e6.jpg; PDF page 26; R -->

```text
Questions 17-20
Write the appropriate letters A-C against Questions 17-20.
What are the locations of the following places in Radford?
A part of the Metro Tower building
B in the main square in the centre of the town
C some distance from the centre of the town
17 the hi-tech fitness centre
18 the ice rink
19 the new cinema
20 the Theatre Royal
```

[Original question page](assets/9d4c0d7d622dd8eef827d9622f74ecc87deabc38fdf4d71a6354678fe7fda9e6.jpg)

### Part 3

<!-- Source: /api/assets/69c5e2d25e1d94aec3addfcc1efecb1917be0f2520e493734d8d396b73c245c7.jpg; PDF page 27; L -->

```text
SECTION 3 Questions 21–30
Questions 21–23
Complete the notes below. Write NO MORE THAN THREE WORDS or A NUMBER for each answer.
DISSERTATION INFORMATION
Hand-in date: (21) __________
Length: (22) __________ to __________ words
Extra programme offered on: (23) __________
Questions 24–26: Complete the table below.
DISSERTATION TIMETABLE
Date | Action
31 January | Basic bibliography
7 February | (24) __________
February–March | (25) __________
(26) __________ to __________ | Write up work
21 May | Hand in work
[Source correction: the 7February action is misprinted(26); it is(24), according to the24–26range and source key. The final date range remains(26).]
```

[Original question page](assets/69c5e2d25e1d94aec3addfcc1efecb1917be0f2520e493734d8d396b73c245c7.jpg)

<!-- Source: /api/assets/6c2cf4b8dd56c7fb17526f3381b3f85f073a15c67058cf6e6e53fb71eb745947.jpg; PDF page 27; R -->

```text
Questions 27–30
What is Dr Simon’s opinion on the following points?
Tick column A if he is in favour.
Tick column B if he has no strong opinion either way.
Tick column C if he is against.
(27) Buying a computer: A / B / C
(28) Reading previous year’s dissertations: A / B / C
(29) Using questionnaires as main research instrument: A / B / C
(30) Interviewing tutors: A / B / C
```

[Original question page](assets/6c2cf4b8dd56c7fb17526f3381b3f85f073a15c67058cf6e6e53fb71eb745947.jpg)

### Part 4

<!-- Source: /api/assets/d56222195bf7a93c0a364d1c51e056ad98a77c0f42304a4b67ae781740185c17.jpg; PDF page 28; L -->

```text
SECTION 4 Questions 31-40
Questions 31-37
Circle the correct letters A-C.
31 The driest continent is ...
A Australia.
B Africa.
C Antarctica.
32 The evaporation rate in Australia is ...
A lower than Africa.
B higher than Africa.
C about the same as Africa.
33 Rainfall in Australia hardly penetrates the soil because ...
A the soil is too hard.
B the soil is too hot.
C plants use it up.
34 In sandy soils water can ...
A evaporate quickly.
B seep down to rock.
C wash the soil away.
35 Water is mainly pumped up for ...
A people to drink.
B animals to drink.
C watering crops.
36 Natural springs are located ...
A in unexplored parts of Australia.
B quite commonly over all Australia.
C in a few areas of Australia.
```

[Original question page](assets/d56222195bf7a93c0a364d1c51e056ad98a77c0f42304a4b67ae781740185c17.jpg)

<!-- Source: /api/assets/a3d62379ed58f4fcabc767016a2fe32e57e8de116d0f8fd4fa6549c1eb97b605.jpg; PDF page 28; R -->

```text
37 Underground water supplies ...
A 18% of Australia's water.
B 48% of Australia’s water.
C 80% of Australia's water.
Questions 38-40
Circle THREE letters A-E
Which THREE of the following uses of dam water are mentioned?
A providing water for livestock
B watering farmland
C providing water for industry
D controlling flood water
E producing hydro-electric power
```

[Original question page](assets/a3d62379ed58f4fcabc767016a2fe32e57e8de116d0f8fd4fa6549c1eb97b605.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/0349e32f221b3fc4fca21f8a0bc3fc3110619a2eb76e1cdb628c2dc558b61eae.jpg; PDF page 29; L -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1–13 which are based on Reading Passage 1 below.
ABSENTEEISM IN NURSING: A LONGITUDINAL STUDY
Absence from work is a costly and
disruptive problem for any organisation.
The cost of absenteeism in Australia has
been put at 1.8 million hours per day or
$1400 million annually. The study reported
here was conducted in the Prince William
Hospital in Brisbane, Australia, where, prior
to this time, few active steps had been taken
to measure, understand or manage the
occurrence of absenteeism.
Nursing Absenteeism
A prevalent attitude amongst many nurses
in the group selected for study was that
there was no reward or recognition for not
utilising the paid sick leave entitlement
allowed them in their employment
conditions. Therefore, they believed they
may as well take the days off — sick or
otherwise. Similar attitudes have been
noted by James (1989), who noted that sick
leave is seen by many workers as a right,
like annual holiday leave.
Miller and Norton (1986), in their survey of
865 nursing personnel, found that 73 per
cent felt they should be rewarded for not
taking sick leave, because some employees
always used their sick leave. Further, 67 per
cent of nurses felt that administration was
not sympathetic to the problems shift work
causes to employees' personal and social
lives. Only 53 per cent of the respondents

felt that every effort was made to schedule
staff fairly.
In another longitudinal study of nurses
working in two Canadian hospitals, Hacket
Bycio and Guion (1989) examined the
reasons why nurses took absence from
work. The most frequent reason stated for
absence was minor illness to self. Other
causes, in decreasing order of frequency,
were illness in family, family social
function, work to do at home and
bereavement.
Method
In an attempt to reduce the level of
absenteeism amongst the 250 Registered an
Enrolled Nurses in the present study, the
Prince William management introduced
three different, yet potentially
complementary, strategies over 18 months.
Strategy 1: Non-financial (material)
incentives
Within the established wage and salary
system it was not possible to use hospital
funds to support this strategy. However, it
was possible to secure incentives from loca
businesses, including free passes to
entertainment parks, theatres, restaurants,
etc. At the end of each roster period, the
ward with the lowest absence rate would
win the prize.
```

[Original question page](assets/0349e32f221b3fc4fca21f8a0bc3fc3110619a2eb76e1cdb628c2dc558b61eae.jpg)

<!-- Source: /api/assets/454ee6e2cc24dea4d0466899f72cd14a573b99ba96e2bb12d0ddd3378b3c1cc4.jpg; PDF page 29; R -->

```text
Strategy 2 Flexible fair rostering
Where possible, staff were given the
opportunity to determine their working
schedule within the limits of clinical
needs.
Strategy 3: Individual absenteeism and
Each month, managers would analyse the
pattern of absence of staff with excessive
sick leave (greater than ten days per year for
full-time employees). Characteristic patterns
of potential 'voluntary absenteeism' such as
absence before and after days off, excessive
weekend and night duty absence and
multiple single days off were
communicated to all ward nurses and then,
as necessary, followed up by action.
Results
Absence rates for the six months prior to the
Incentive scheme ranged from 3.69 per cent
to 4.32 per cent. In the following six months
they ranged between 2.87 per cent and 3.96
per cent. This represents a 20 per cent
improvement. However, analysing the
absence rates on a year-to-year basis, the
overall absence rate was 3.60 per cent in the
first year and 3.43 per cent in the following
year. This represents a 5 per cent decrease
from the first to the second year of the
study. A significant decrease in absence
over the two-year period could not be
demonstrated.
Discussion
The non-financial incentive scheme did
appear to assist in controlling absenteeism
in the short term. As the scheme progressed
it became harder to secure prizes and this
contributed to the program's losing
momentum and finally ceasing. There were

mixed results across wards as well. For
example, in wards with staff members who
had long-term genuine illness, there was
little chance of winning, and to some extent
the staff on those wards were
disempowered. Our experience would
suggest that the long-term effects of
incentive awards on absenteeism are
questionable.
Over the time of the study, staff were given
a larger degree of control in their rosters.
This led to significant improvements in
communication between managers and
staff. A similar effect was found from the
implementation of the third strategy. Many
of the nurses had not realised the impact
their behaviour was having on the
organisation and their colleagues but there
were also staff members who felt that
talking to them about their absenteeism was
'picking' on them and this usually had a
negative effect on management—employee
relationships.
Conclusion
Although there has been some decrease in
absence rates, no single strategy or
combination of strategies has had a
significant impact on absenteeism per se.
Notwithstanding the disappointing results,
it is our contention that the strategies were
not in vain. A shared ownership of
absenteeism and a collaborative approach to
problem solving has facilitated improved
cooperation and communication between
management and staff. It is our belief that
this improvement alone, while not tangibly
measurable, has increased the ability of
management to manage the effects of
absenteeism more effectively since this
study.

This article has been adapted and condensed from the article by G. William and K. Slater (1996), 'Absenteeism in
nursing: A longitudinal study', Asia Pacific Journal of Human Resources, 34(1): 111-21. Names and other details
have been changed and report findings may have been given a different emphasis from the original. We are
grateful to the authors and Asia Pacific Journal of Human Resources for allowing us to use the material in this •"'
way.

[Source notes: the printed Strategy3heading ends with “and”; “Registered an” and “loca” are also printed truncated. No missing wording has been invented.]
```

[Original question page](assets/454ee6e2cc24dea4d0466899f72cd14a573b99ba96e2bb12d0ddd3378b3c1cc4.jpg)

<!-- Source: /api/assets/0c5f709c17f398c66e1d8dc4c1ade8a2438f49d8c26a97a277c8296a3160321f.jpg; PDF page 30; L -->

```text
Questions 1-7
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-7 on your answer sheet write
YES if the statement agrees with the information
NO if the statement contradicts the information
NOT GIVEN if there is no information on this in the passage
1 The Prince William Hospital has been trying to reduce
absenteeism amongst nurses for many years.
2 Nurses in the Prince William Hospital study believed
that there were benefits in taking as little sick leave as
possible.
3 Just over half the nurses in the 1986 study believed that
management understood the effects that shift work had
on them.
4 The Canadian study found that 'illness in the family'
was a greater cause of absenteeism than 'work to do at
home'.
5 In relation to management attitude to absenteeism the
study at the Prince William Hospital found similar
results to the two 1989 studies.
6 The study at the Prince William Hospital aimed to find
out the causes of absenteeism amongst 250 nurses.
7 The study at the Prince William Hospital involved
changes in management practices.
```

[Original question page](assets/0c5f709c17f398c66e1d8dc4c1ade8a2438f49d8c26a97a277c8296a3160321f.jpg)

<!-- Source: /api/assets/d53d74cefe7e7e9e1943f25004a1d95f326dc5221d939c66aa1caa023004a17a.jpg; PDF page 30; R -->

```text
Questions 8-13
Complete the notes below.
Choose ONE OR TWO WORDS from the passage, for each answer.
Write your answers in boxes 8-13 on your answer sheet.
In the first strategy, wards with the lowest absenteeism in different
periods would win prizes donated by ... (8) ....
In the second strategy, staff were given more control over their
...(9)... .
In the third strategy, nurses who appeared to be taking ... (10)... sick
leave or ... (11) ... were identified and counselled.
Initially, there was a ... (12)... per cent decrease in absenteeism.
The first strategy was considered ineffective and stopped. The second
and third strategies generally resulted in better ... (13) ... among staff.
```

[Original question page](assets/d53d74cefe7e7e9e1943f25004a1d95f326dc5221d939c66aa1caa023004a17a.jpg)

<!-- Source: /api/assets/67ae1c4423134459da5b28fd1977f0c841616c60a206e0628b11d7529d11774c.jpg; PDF page 31; L -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26 which are based on Reading Passage 2
below.
A There are now over 700 million motor
vehicles in the world - and the number is
rising by more than 40 million each year.
The average distance driven by car users
is growing too - from 8 km a day per
person in western Europe in 1965 to 25
km a day in 1995. This dependence on
motor vehicles has given rise to major
problems, including environmental
pollution, depletion of oil resources,
traffic congestion and safety.
B While emissions from new cars are far
less harmful than they used to be, city
streets and motorways are becoming
more crowded than ever, often with
older trucks, buses and taxis, which
emit excessive levels of smoke and
fumes. This concentration of vehicles
makes air quality in urban areas
unpleasant and sometimes dangerous
to breathe. Even Moscow has joined
the list of capitals afflicted by
congestion and traffic fumes. In
Mexico City, vehicle pollution is a
major health hazard.
C Until a hundred years ago, most
journeys were in the 20 km range, the
distance conveniently accessible by
horse. Heavy freight could only be
carried by water or rail. The invention
of the motor vehicle brought personal
mobility to the masses and made rapid
freight delivery possible over a much
wider area. Today about 90 per cent of
inland freight in the United Kingdom
is carried by road. Clearly the world
cannot revert to the horse-drawn
wagon. Can it avoid being locked into
congested and polluting ways of
transporting people and goods?
D In Europe most cities are still designed
for the old modes of transport.
Adaptation to the motor car has
involved adding ring roads, one-way
systems and parking lots. In the United
States, more land is assigned to car use
than to housing. Urban sprawl means
that life without a car is next to
impossible. Mass use of motor vehicles
has also killed or injured millions of
people. Other social effects have been
blamed on the car such as alienation
and aggressive human behaviour.
E A 1993 study by the European
Federation for Transport and
Environment found that car transport
is seven times as costly as rail travel in
terms of the external social costs it
entails such as congestion, accidents,
pollution, loss of cropland and natural
habitats, depletion of oil resources, and
so on. Yet cars easily surpass trains or
buses as a flexible and convenient mode
of personal transport. It is unrealistic
to expect people to give up private cars
in favour of mass transit.
```

[Original question page](assets/67ae1c4423134459da5b28fd1977f0c841616c60a206e0628b11d7529d11774c.jpg)

<!-- Source: /api/assets/dab581bf4af7de61a18558a47bdaaea8ee29262339adc64ae751c14beb4d4ecc.jpg; PDF page 31; R -->

```text
F Technical solutions can reduce the
pollution problem and increase the fuel
efficiency of engines. But fuel
consumption and exhaust emissions
depend on which cars are preferred by
customers and how they are driven.
Many people buy larger cars than they
need for daily purposes or waste fuel by
driving aggressively. Besides, global car
use is increasing at a faster rate than the
improvement in emissions and fuel
efficiency which technology is now
making possible.
G One solution that has been put forward
is the long-term solution of designing
cities and neighbourhoods so that car
journeys are not necessary - all
essential services being located within
walking distance or easily accessible by
public transport. Not only would this
save energy and cut carbon dioxide
emissions, it would also enhance the
quality of community life, putting the
emphasis on people instead of cars.
Good local government is already
bringing this about in some places. But
few democratic communities are
blessed with the vision - and the capital
- to make such profound changes in
modern lifestyles.
H A more likely scenario seems to be a
combination of mass transit systems
for travel into and around cities, with
small 'low emission' cars for urban use
and larger hybrid or lean burn cars for
use elsewhere. Electronically tolled
highways might be used to ensure that
drivers pay charges geared to actual
road use. Better integration of
transport systems is also highly
desirable - and made more feasible by
modern computers. But these are
solutions for countries which can
afford them. In most developing
countries, old cars and old technologies
continue to predominate.
Questions 14-19
Reading Passage 2 has eight paragraphs (A-H). Which paragraphs concentrate on the
following information? Write the appropriate letters (A-H) in boxes 14-19 on your answer
sheet.
NB You need only write ONE letter for each answer.
14 a comparison of past and present transportation methods
15 how driving habits contribute to road problems
16 the relative merits of cars and public transport
17 the writer's own prediction of future solutions
18 the increasing use of motor vehicles
19 the impact of the car on city development

```

[Original question page](assets/dab581bf4af7de61a18558a47bdaaea8ee29262339adc64ae751c14beb4d4ecc.jpg)

<!-- Source: /api/assets/8711e37172da994fd1878f4013ea378eff2e5cb19a86ce37ef413258de8f67a4.jpg; PDF page 32; L -->

```text
Questions 20-26
Do the following statements agree with the information given in Reading Passage 2?
In boxes 20-26 on your answer sheet write
YES if the statement agrees with the information
NO if the statement contradicts the information
NOT GIVEN if there is no information on this in the passage
20 Vehicle pollution is worse in European cities than anywhere else.
21 Transport by horse would be a useful alternative to motor vehicles.
22 Nowadays freight is not carried by water in the United Kingdom.
23 Most European cities were not designed for motor vehicles.
24 Technology alone cannot solve the problem of vehicle pollution.
25 People's choice of car and attitude to driving is a factor in the pollution problem.
26 Redesigning cities would be a short-term solution.
```

[Original question page](assets/8711e37172da994fd1878f4013ea378eff2e5cb19a86ce37ef413258de8f67a4.jpg)

<!-- Source: /api/assets/1971e6703f97af1f606ad59ea130ac72ad1d6040ca2c59587c5c1ef375606598.jpg; PDF page 32; R -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40 which are based on Reading Passage 3
on the following pages.
Questions 27-33
Reading Passage 3 has eight paragraphs (A-H).
Choose the most suitable headings for paragraphs B-H from the list of headings below.
Write the appropriate numbers (i-x) in boxes 27-33 on your answer sheet.
NB There are more headings than paragraphs, so you will not use all of them.
List of Headings
i Common objections
ii Who's planning what
iii This type sells best in the shops
iv The figures say it all
v Early trials
vi- They can't get in without these
vii How does it work?
viii Fighting fraud
ix Systems to avoid
x Accepting the inevitable
27 Paragraph B
28 Paragraph C
29 Paragraph D
30 Paragraph E
31 Paragraph F
32 Paragraph G
33 Paragraph H
```

[Original question page](assets/1971e6703f97af1f606ad59ea130ac72ad1d6040ca2c59587c5c1ef375606598.jpg)

<!-- Source: /api/assets/546dc2302e05aee4413d1611f96509769841ec1e505799e2077f25c68cf30760.jpg; PDF page 33; L -->

```text
A Students who want to enter the University of Montreal's Athletic
Complex need more than just a conventional ID card - their identities
must be authenticated by an electronic hand scanner. In some California
housing estates, a key alone is insufficient to get someone in the door;
his or her voiceprint must also be verified. And soon, customers at some
Japanese banks will have to present their faces for scanning before they
can enter the building and withdraw their money.
B All of these are applications of biometrics, a little-known but fast-growing
technology that involves the use of physical or biological characteristics
to identify individuals. In use for more than a decade at some high-security government institutions in the United States and Canada,
biometrics are now rapidly popping up in the everyday world. Already,
more than 10,000 facilities, from prisons to day-care centres, monitor
people's fingerprints or other physical parts to ensure that they are who
they claim to be. Some 60 biometric companies around the world pulled
in at least $22 million last year and that grand total is expected to
mushroom to at least $50 million by 1999.
C Biometric security systems operate by storing a digitised record of some
unique human feature. When an authorised user wishes to enter or use
the facility, the system scans the person's corresponding characteristics
and attempts to match them against those on record. Systems using
fingerprints, hands, voices, irises, retinas and faces are already on the
market. Others using typing patterns and even body odours are in
various stages of development.
D Fingerprint scanners are currently the most widely deployed type of
biometric application, thanks to their growing use over the last 20 years
by law-enforcement agencies. Sixteen American states now use
biometric fingerprint verification systems to check that people claiming
welfare payments are genuine. In June, politicians in Toronto voted to do
the same, with a pilot project beginning next year.
E To date, the most widely used commercial biometric system is the
handkey, a type of hand scanner which reads the unique shape, size and
irregularities of people's hands. Originally developed for nuclear power
```

[Original question page](assets/546dc2302e05aee4413d1611f96509769841ec1e505799e2077f25c68cf30760.jpg)

<!-- Source: /api/assets/2e9e7efe3292da2737a51672a825fcc021ec9fbf7221d82d63cd5bd5e55413d4.jpg; PDF page 33; R -->

```text
plants, the handkey received its big break when it was used to control
access to the Olympic Village in Atlanta by more than 65,000 athletes,
trainers and support staff. Now there are scores of other applications.
F Around the world, the market is growing rapidly. Malaysia, for
example, is preparing to equip all of its airports with biometric face
scanners to match passengers with luggage. And Japan's largest maker
of cash dispensers is developing new machines that incorporate iris
scanners. The first commercial biometric, a hand reader used by an
American firm to monitor employee attendance, was introduced in
1974. But only in the past few years has the technology improved
enough for the prices to drop sufficiently to make them commercially
viable. 'When we started four years ago, I had to explain to everyone
what a biometric is,' says one marketing expert. 'Now, there's much
more awareness out there.'
G [printed C in source; corrected to follow the A–H sequence and Questions27–33] Not surprisingly, biometrics raise thorny questions about privacy and the
potential for abuse. Some worry that governments and industry will be
tempted to use the technology to monitor individual behaviour. 'If
someone used your fingerprints to match your health-insurance records
with a credit-card record showing you regularly bought lots of cigarettes
and fatty foods,' says one policy analyst, 'you would see your insurance
payments go through the roof.' In Toronto, critics of the welfare
fingerprint plan complained that it would stigmatise recipients by forcing
them to submit to a procedure widely identified with criminals.
H Nonetheless, support for biometrics is growing in Toronto as it is in many
other communities. In an increasingly crowded and complicated world,
biometrics may well be a technology whose time has come.
```

[Original question page](assets/2e9e7efe3292da2737a51672a825fcc021ec9fbf7221d82d63cd5bd5e55413d4.jpg)

<!-- Source: /api/assets/cd1dfd88162cffa4f3d4857459673269d81e8be04ffd58537e5a0334e48e7abb.jpg; PDF page 34; L -->

```text
Questions 34-40
Look at the following groups of people (Questions 34-40) and the list of biometric systems
(A-F) below.
Match the groups of people to the biometric system associated with them in Reading Passage 3.
Write the appropriate letters A-F in boxes 34-40 on your answer sheet.
NB You may use any biometric system more than once.
34 sports students
35 Olympic athletes
36 airline passengers
37 welfare claimants
38 business employees
39 home owners
40 bank customers
List of Biometric Systems
A fingerprint scanner
B hand scanner
C body odour
D voiceprint
E face scanner
F typing pattern
```

[Original question page](assets/cd1dfd88162cffa4f3d4857459673269d81e8be04ffd58537e5a0334e48e7abb.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/787a6b795e63c0761e0353a338be17595c378c12f3eadc4da75504e1da2e2ee2.jpg; PDF page 34; R -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The first chart below shows the results of a survey which sampled a cross-section of 100,000 people asking if they travelled abroad and why they travelled for the period 1994–98. The second chart shows their destinations over the same period.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

See the retained original figure for the full table or chart.
```

[Original question page](assets/787a6b795e63c0761e0353a338be17595c378c12f3eadc4da75504e1da2e2ee2.jpg)

![Original figure](assets/787a6b795e63c0761e0353a338be17595c378c12f3eadc4da75504e1da2e2ee2.jpg)

### Task 2

<!-- Source: /api/assets/ede85ca2e8dced4138683742baaa2c4512331d4aa1541966b4695ca353d8e79d.jpg; PDF page 35; L -->

```text
WRITING TASK 2
You should write at least 250 words.

Without capital punishment (the death penalty) our lives are less secure and crimes of violence increase. Capital punishment in essential to control violence in society.

To what extent do you agree or disagree with this opinion?

You should write at least 250 words.

You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.
```

[Original question page](assets/ede85ca2e8dced4138683742baaa2c4512331d4aa1541966b4695ca353d8e79d.jpg)

## 口语

### 原书口语任务

<!-- Source: /api/assets/469076db04b19b86770a13067d0079e693ef98360963fd9936c6a2001b05fc08.png; PDF page 35; R -->

```text
Task:
The candidate is to find out as much information as possible about an environmental group.
Candidate's cue card:
AN ENVIRONMENTAL GROUP
You are interested in joining a group of students at the university who work to protect
the environment.
Ask the Examiner about: the name of the group
action that they take
the cost of membership
what members have to do
number of members
when the group was founded
```

[Original question page](assets/469076db04b19b86770a13067d0079e693ef98360963fd9936c6a2001b05fc08.png)
