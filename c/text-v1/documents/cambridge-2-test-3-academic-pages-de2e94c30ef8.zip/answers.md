# 剑雅 2 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 73

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accented, these are stated in the Key.)
0-17
you are highly unlikely to get
an acceptable score under -
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take 1ELTS
18-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take 1ELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 B
2 C
3 A
4 B
5 both required for one mark, either order
AE
6 both required for one mark, either order
AC
7 both required for one mark, either order
CE
8 B
9 C
10 B
Section 2, Questions 11–20
11–14 A, C, E, G (in any order)
15–16 B, E (in either order)
17 C
18 A
19 A
20 B
Section 3, Questions 21-30
21 21 May or acceptable alternatives
22 18,000-20,000 // 18-20,000 must have both
numbers (or in words)
23 research methods NOT research
24 (draft) plan
25 (do/carry out/conduct) research
26 March (to) May (both for one mark)
27 A
28 A
29 C
30 B
Section 4, Questions 31-40
31 C
32 B
33 C
34 B
35 B
36 C
37 A
38–40 B, D, E (in any order)


1. B

2. C

3. A

4. B

5. A E / A, E / A and E / A & E / A; E / A/E / A,E / AE / E A / E, A / E and A / E & A / E; A / E/A / E,A / EA

6. A C / A, C / A and C / A & C / A; C / A/C / A,C / AC / C A / C, A / C and A / C & A / C; A / C/A / C,A / CA

7. C E / C, E / C and E / C & E / C; E / C/E / C,E / CE / E C / E, C / E and C / E & C / E; C / E/C / E,C / EC

8. B

9. C

10. B

### Part 2 · source page 73

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accented, these are stated in the Key.)
0-17
you are highly unlikely to get
an acceptable score under -
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take 1ELTS
18-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take 1ELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 B
2 C
3 A
4 B
5 both required for one mark, either order
AE
6 both required for one mark, either order
AC
7 both required for one mark, either order
CE
8 B
9 C
10 B
Section 2, Questions 11–20
11–14 A, C, E, G (in any order)
15–16 B, E (in either order)
17 C
18 A
19 A
20 B
Section 3, Questions 21-30
21 21 May or acceptable alternatives
22 18,000-20,000 // 18-20,000 must have both
numbers (or in words)
23 research methods NOT research
24 (draft) plan
25 (do/carry out/conduct) research
26 March (to) May (both for one mark)
27 A
28 A
29 C
30 B
Section 4, Questions 31-40
31 C
32 B
33 C
34 B
35 B
36 C
37 A
38–40 B, D, E (in any order)


11. A / C / E / G

12. A / C / E / G

13. A / C / E / G

14. A / C / E / G

15. B / E

16. B / E

17. C

18. A

19. A

20. B

### Part 3 · source page 73

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accented, these are stated in the Key.)
0-17
you are highly unlikely to get
an acceptable score under -
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take 1ELTS
18-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take 1ELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 B
2 C
3 A
4 B
5 both required for one mark, either order
AE
6 both required for one mark, either order
AC
7 both required for one mark, either order
CE
8 B
9 C
10 B
Section 2, Questions 11–20
11–14 A, C, E, G (in any order)
15–16 B, E (in either order)
17 C
18 A
19 A
20 B
Section 3, Questions 21-30
21 21 May or acceptable alternatives
22 18,000-20,000 // 18-20,000 must have both
numbers (or in words)
23 research methods NOT research
24 (draft) plan
25 (do/carry out/conduct) research
26 March (to) May (both for one mark)
27 A
28 A
29 C
30 B
Section 4, Questions 31-40
31 C
32 B
33 C
34 B
35 B
36 C
37 A
38–40 B, D, E (in any order)


21. 21 May

22. 18,000-20,000 / 18000-20000 / 18-20,000 / 18-20000 / eighteen thousand to twenty thousand

23. research methods

24. plan / draft plan

25. research / do research / carry out research / conduct research

26. March May / March to May

27. A

28. A

29. C

30. B

### Part 4 · source page 73

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accented, these are stated in the Key.)
0-17
you are highly unlikely to get
an acceptable score under -
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take 1ELTS
18-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take 1ELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 B
2 C
3 A
4 B
5 both required for one mark, either order
AE
6 both required for one mark, either order
AC
7 both required for one mark, either order
CE
8 B
9 C
10 B
Section 2, Questions 11–20
11–14 A, C, E, G (in any order)
15–16 B, E (in either order)
17 C
18 A
19 A
20 B
Section 3, Questions 21-30
21 21 May or acceptable alternatives
22 18,000-20,000 // 18-20,000 must have both
numbers (or in words)
23 research methods NOT research
24 (draft) plan
25 (do/carry out/conduct) research
26 March (to) May (both for one mark)
27 A
28 A
29 C
30 B
Section 4, Questions 31-40
31 C
32 B
33 C
34 B
35 B
36 C
37 A
38–40 B, D, E (in any order)


31. C

32. B

33. C

34. B

35. B

36. C

37. A

38. B / D / E

39. B / D / E

40. B / D / E

## A 类阅读

### Academic Reading · source page 73

ACADEMIC READING
Each question correctly answered scores 1 mark.
Reading Passage 1 Questions 1-13
1 NO
2 NO
3 NO
4 YES
5 NOT GIVEN
6 NO
7 YES
8 (local) businesses
9 (work/working) schedule // rostering //
roster(s)
10 excessive
11 voluntary absence/absenteeism
12 twenty// 20
13 communication
Reading Passage 2, Questions 14-26
14 C
15 F
16 E
17 H
18 A
19 D
If you score...
0-15
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
16-24
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take 1ELTS
25-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
20 NOT GIVEN
21 NO
22 NOT GIVEN
23 YES
24 YES
25 YES
26 NO
Reading Passage 3, Questions 27-40
27 iv
28 vii
29 viii
30 iii
31 ii
32 i
33 x
34 B
35 B
36 E
37 A
38 B
39 D
40 E

1. NO

2. NO

3. NO

4. YES

5. NOT GIVEN

6. NO

7. YES

8. businesses / local businesses

9. schedule / work schedule / working schedule / rostering / roster / rosters

10. excessive

11. voluntary absence / absenteeism

12. twenty / 20

13. communication

14. C

15. F

16. E

17. H

18. A

19. D

20. NOT GIVEN

21. NO

22. NOT GIVEN

23. YES

24. YES

25. YES

26. NO

27. iv

28. vii

29. viii

30. iii

31. ii

32. i

33. x

34. B

35. B

36. E

37. A

38. B

39. D

40. E

## A 类写作

### Writing material: c2-t3-w-1

Both original tables inspected. Survey sample in the prompt: 100,000 people; do not confuse this with the annual visit totals. First table title: Visits abroad by UK residents by purpose of visit (1994–98). Columns 1994/1995/1996/1997/1998. Holiday: 15,246/14,898/17,896/19,703/20,700. Business: 3,155/3,188/3,249/3,639/3,957. Visits to friends and relatives: 2,689/2,628/2,774/3,051/3,181. Other reasons: 982/896/1,030/1,054/990. Total: 22,072/21,610/24,949/27,447/28,828. Second table: Destinations of visits abroad by UK residents by main region (1994–98). Rows 1994–1998: Western Europe 19,371/18,944/21,877/23,661/24,519; North America 919/914/1,167/1,559/1,823; other areas 1,782/1,752/1,905/2,227/2,486; total identical to the first table. Holidays and Western Europe dominate. Totals fall slightly in 1995 then rise to the highest level in 1998. North America grows substantially from its small base. Other reasons fluctuate; do not claim every category increases each year.



### Writing material: c2-t3-w-2

The supplied source contains the typographical wording "in essential" and spacing errors in "capitalpunishment". The opinion being discussed is that the death penalty is essential to control violent crime; this is a claim for debate, not an established fact. Preserve freedom to agree, disagree or qualify the claim.



## 口语

### 原书口语任务 · reference on source page 35

Information for the Examiner:
the name of the group Green Action
action that they take planting trees, clearing up rubbish
the cost of membership $10/£5 a year
what members have to do participate in two events (organised by the
group) a year
number of members 4,500
when the group was founded 1996

[Complete original page](assets/0c81da7ce747949445e1548af04792cdbd8d1e12e0b2d65310402e5455ea7167.jpg)
