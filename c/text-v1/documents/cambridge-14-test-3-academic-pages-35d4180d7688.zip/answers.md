# 剑雅 14 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 123

TEST 3 LISTENING
1 Tesla
2 microphone
3 exhibition
4 wifi
5 45
6 135
7 pool
8 airport
9 sea
10 clubs
11 A
12 E
13 B
14 E
15 F
16 A
17 E
18 G
19 D
20 C
21 50
22 regional
23 carnival
24 drummer
25 film
26 parade
27 D
28 B
29 E
30 F
31 violin
32 energy
33 complex
34 opera
35 disturbing
36 clarinet
37 diversity
38 physics
39 dance
40 Olympics
11&12 IN EITHER ORDER: A,E
13&14 IN EITHER ORDER: B,E
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. Tesla

2. microphone

3. exhibition

4. wifi

5. 45

6. 135

7. pool

8. airport

9. sea

10. clubs

### Part 2 · source page 123

TEST 3 LISTENING
1 Tesla
2 microphone
3 exhibition
4 wifi
5 45
6 135
7 pool
8 airport
9 sea
10 clubs
11 A
12 E
13 B
14 E
15 F
16 A
17 E
18 G
19 D
20 C
21 50
22 regional
23 carnival
24 drummer
25 film
26 parade
27 D
28 B
29 E
30 F
31 violin
32 energy
33 complex
34 opera
35 disturbing
36 clarinet
37 diversity
38 physics
39 dance
40 Olympics
11&12 IN EITHER ORDER: A,E
13&14 IN EITHER ORDER: B,E
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A / E

12. A / E

13. B / E

14. B / E

15. F

16. A

17. E

18. G

19. D

20. C

### Part 3 · source page 123

TEST 3 LISTENING
1 Tesla
2 microphone
3 exhibition
4 wifi
5 45
6 135
7 pool
8 airport
9 sea
10 clubs
11 A
12 E
13 B
14 E
15 F
16 A
17 E
18 G
19 D
20 C
21 50
22 regional
23 carnival
24 drummer
25 film
26 parade
27 D
28 B
29 E
30 F
31 violin
32 energy
33 complex
34 opera
35 disturbing
36 clarinet
37 diversity
38 physics
39 dance
40 Olympics
11&12 IN EITHER ORDER: A,E
13&14 IN EITHER ORDER: B,E
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. 50

22. regional

23. carnival

24. drummer

25. film

26. parade

27. D

28. B

29. E

30. F

### Part 4 · source page 123

TEST 3 LISTENING
1 Tesla
2 microphone
3 exhibition
4 wifi
5 45
6 135
7 pool
8 airport
9 sea
10 clubs
11 A
12 E
13 B
14 E
15 F
16 A
17 E
18 G
19 D
20 C
21 50
22 regional
23 carnival
24 drummer
25 film
26 parade
27 D
28 B
29 E
30 F
31 violin
32 energy
33 complex
34 opera
35 disturbing
36 clarinet
37 diversity
38 physics
39 dance
40 Olympics
11&12 IN EITHER ORDER: A,E
13&14 IN EITHER ORDER: B,E
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. violin

32. energy

33. complex

34. opera

35. disturbing

36. clarinet

37. diversity

38. physics

39. dance

40. Olympics

## A 类阅读

### Academic Reading · source page 124

TEST 3 READING
1 B
2 A
3 D
4 NOT GIVEN
5 NO
6 YES
7 B
8 C
9 B
10 A
11 A
12 C
13 A
14 C
15 H
16 A
17 F
18 I
19 B
20 E
21 B
22 C
23 ecology
24 prey
25 habitats
26 antibiotics
27 B
28 G
29 F
30 E
31 C
32 NO
33 YES
34 NOT GIVEN
35 NO
36 YES
37 encouraging
38 desire
39 autonomy
40 targeted
21&22 IN EITHER ORDER: B,C
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. B

2. A

3. D

4. NOT GIVEN

5. NO

6. YES

7. B

8. C

9. B

10. A

11. A

12. C

13. A

14. C

15. H

16. A

17. F

18. I

19. B

20. E

21. B / C

22. B / C

23. ecology

24. prey

25. habitats

26. antibiotics

27. B

28. G

29. F

30. E

31. C

32. NO

33. YES

34. NOT GIVEN

35. NO

36. YES

37. encouraging

38. desire

39. autonomy

40. targeted

## A 类写作

### Writing material: c14-t3-w-1

River supplies high-level reservoir behind dam. Intake open by day, closed at night. Day: water flows downhill through reversible turbines to low-level reservoir; turbines operate generator in power station, power lines transmit electricity to national grid. Night: turbines reverse to pump water from low-level back to high-level reservoir through same conduit. Diagram explicitly separates day generation and night pumping. No fossil fuel, evaporation cycle, depth or operating times given. Do not claim night pumping generates electricity or intake remains open at night.



### Writing material: c14-t3-w-2

Evaluate music bringing together people across both cultural and age differences. General benefits of music alone may not answer the social unifying claim; no required stance.



## 口语
