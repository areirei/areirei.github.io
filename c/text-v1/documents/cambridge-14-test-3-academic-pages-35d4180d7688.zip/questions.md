# 剑雅 14 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/64b04186107f239729c207d13682baf63b68ee0a38529a3c04831fc7231e3176.jpg; PDF page 53; full -->

```text
SECTION 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Flanders Conference Hotel
Example Customer Services Manager: Angela
Date available
• weekend beginning February 4th
Conference facilities
• the (1) __________ room for talks (projector and (2) __________ available)
• area for coffee and an (3) __________
• free (4) __________ throughout
• a standard buffet lunch costs (5) $ __________ per head
Accommodation
• Rooms will cost (6) $ __________ including breakfast.
Other facilities
• The hotel also has a spa and rooftop (7) __________.
• There’s a free shuttle service to the (8) __________.
Location
• Wilby Street (quite near the (9) __________)
• near to restaurants and many (10) __________
```

[Original question page](assets/64b04186107f239729c207d13682baf63b68ee0a38529a3c04831fc7231e3176.jpg)

### Part 2

<!-- Source: /api/assets/27e450cb3772867e839af0520219d023a8a9926e8e9149e6e488e6a5cc6fda9a.jpg; PDF page 54; full -->

```text
Test 3
SECTION 2 Questions 11-20
Questions 11 and 12
Choose TWO letters, A-E.
Which TWO activities that volunteers do are mentioned?
A decorating
B cleaning
C delivering meals
D shopping
E childcare
Questions 13 and 14
Choose TWO letters, A-E.
Which TWO ways that volunteers can benefit from volunteering are mentioned?
A learning how to be part of a team
B having a sense of purpose
C realising how lucky they are
D improved ability at time management
E boosting their employment prospects
```

[Original question page](assets/27e450cb3772867e839af0520219d023a8a9926e8e9149e6e488e6a5cc6fda9a.jpg)

<!-- Source: /api/assets/519f3e2451dead213967e5913b9e309530c73f9a79d1850e74209e743d479ec6.jpg; PDF page 55; full -->

```text
Listening
Questions 15-20
What has each of the following volunteers helped someone to do?
Choose SIX answers from the box and write the correct letter, A-G, next to
Questions 15-20.
What volunteers have helped people to do
A  overcome physical difficulties
B rediscover skills not used for a long time
C  improve their communication skills
D solve problems independently
E escape isolation
F remember past times
G  start a new hobby
Volunteers
15 Habib
16 Consuela
17 Minh
18 Tanya
19 Alexei
20 Juba
55
```

[Original question page](assets/519f3e2451dead213967e5913b9e309530c73f9a79d1850e74209e743d479ec6.jpg)

### Part 3

<!-- Source: /api/assets/fbf1ed96b0707a6746a8f92bbf74e32ee0213282a9f508804f1862f813798603.jpg; PDF page 56; full -->

```text
SECTION 3 Questions 21–26
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Background on school marching band
It consists of around (21) __________ students.
It is due to play in a (22) __________ band competition.
It has been invited to play in the town’s (23) __________.
They have listened to a talk by a (24) __________.
Joe will discuss a (25) __________ with the band.
Joe hopes the band will attend a (26) __________ next month.
```

[Original question page](assets/fbf1ed96b0707a6746a8f92bbf74e32ee0213282a9f508804f1862f813798603.jpg)

<!-- Source: /api/assets/530f2e0e66b8c6470deed1e54759ce1aae76e53263a2f6108a1bcb58c7155816.jpg; PDF page 57; full -->

```text
Questions 27–30
What problem does Joe mention in connection with each of the following band members?
Choose FOUR answers from the box and write the correct letter, A–F, next to Questions 27–30.
Problems
A makes a lot of mistakes in rehearsals
B keeps making unhelpful suggestions
C has difficulty with rhythm
D misses too many rehearsals
E has a health problem
F doesn’t mix with other students
Band members
27 flautist __________
28 trumpeter __________
29 trombonist __________
30 percussionist __________
```

[Original question page](assets/530f2e0e66b8c6470deed1e54759ce1aae76e53263a2f6108a1bcb58c7155816.jpg)

### Part 4

<!-- Source: /api/assets/4c9639a57bf8ecd8a6fc19dcd2ea2576f21098f7862dd43e6fc633c7ca11b1f3.jpg; PDF page 58; full -->

```text
Test 3
SECTION 4 Questions (31) __________-(40) __________
Complete the notes below.
Write ONE WORD AND/OR A NUMBER for each answer.
Concerts in university arts festival
Concert 1
e Australian composer: Liza Lim
* studied piano and (31) __________ before turning to composition
performers and festivals around the world have given her a lot of commissions
compositions show a great deal of (32) __________ and are drawn from
various cultural sources
her music is very expressive and also (33) __________
festival will include her (34) __________ called The Oresteia
Lim described the sounds in The Oresteia as (35) __________
British composers: Ralph Vaughan Williams, Frederick Delius
Concert 2
British composers: Benjamin Britten, Judith Weir
Australian composer: Ross Edwards
festival will include The Tower of Remoteness, inspired by nature
The Tower of Remoteness is performed by piano and (36) __________
compositions include music for children
e — celebrates Australia’s cultural (37) __________
Concert 3
Australian composer: Carl Vine
played cornet then piano
studied (38) __________ before studying music
worked in Sydney as a pianist and composer
became well known as composer of music for (39) __________
festival will include his music for the 1996 (40) __________
British composers: Edward Elgar, Thomas Adès
```

[Original question page](assets/4c9639a57bf8ecd8a6fc19dcd2ea2576f21098f7862dd43e6fc633c7ca11b1f3.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/2cf68f4d14a4e1969f9b76a358915b8bd11260b62eb016c6e6fe833169e96ec9.jpg; PDF page 59; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The concept of intelligence
A Looked at in one way, everyone knows what intelligence is; looked at in another way, no one
does. In other words, people all have unconscious notions — known as ‘implicit theories’ —
of intelligence, but no one knows for certain what it actually is. This chapter addresses how
people conceptualize intelligence, whatever it may actually be.
But why should we even care what people think intelligence is, as opposed only to valuing
whatever it actually is? There are at least four reasons people’s conceptions of intelligence
matter.
B First, implicit theories of intelligence drive the way in which people perceive and evaluate
their own intelligence and that of others. To better understand the judgments people make
about their own and others’ abilities, it is useful to learn about people’s implicit theories.
For example, parents’ implicit theories of their children’s language development will
determine at what ages they will be willing to make various corrections in their children’s
speech. More generally, parents’ implicit theories of intelligence will determine at what ages
they believe their children are ready to perform various cognitive tasks. Job interviewers
will make hiring decisions on the basis of their implicit theories of intelligence. People
will decide who to be friends with on the basis of such theories. In sum, knowledge about
implicit theories of intelligence is important because this knowledge is so often used by
people to make judgments in the course of their everyday lives.
C Second, the implicit theories of scientific investigators ultimately give rise to their explicit
theories. Thus it is useful to find out what these implicit theories are. Implicit theories
provide a framework that is useful in defining the general scope of a phenomenon —
especially a not-well-understood phenomenon. These implicit theories can suggest what
aspects of the phenomenon have been more or less attended to in previous investigations.
D Third, implicit theories can be useful when an investigator suspects that existing explicit
theories are wrong or misleading. If an investigation of implicit theories reveals little
correspondence between the extant implicit and explicit theories, the implicit theories may
be wrong. But the possibility also needs to be taken into account that the explicit theories
are wrong and in need of correction or supplementation. For example, some implicit
theories of intelligence suggest the need for expansion of some of our explicit theories of
the construct.
59
```

[Original question page](assets/2cf68f4d14a4e1969f9b76a358915b8bd11260b62eb016c6e6fe833169e96ec9.jpg)

<!-- Source: /api/assets/8e27a36761ea82389e9a7c0b4fce78912f75d913545db42667e70e6b60c4bb19.jpg; PDF page 60; full -->

```text
E Finally, understanding implicit theories of intelligence can help elucidate developmental and cross-cultural differences. As mentioned earlier, people have expectations for intellectual performances that differ for children of different ages. How these expectations differ is in part a function of culture. For example, expectations for children who participate in Western-style schooling are almost certain to be different from those for children who do not participate in such schooling.
F I have suggested that there are three major implicit theories of how intelligence relates to society as a whole (Sternberg, 1997). These might be called Hamiltonian, Jeffersonian, and Jacksonian. These views are not based strictly, but rather, loosely, on the philosophies of Alexander Hamilton, Thomas Jefferson, and Andrew Jackson, three great statesmen in the history of the United States.
G The Hamiltonian view, which is similar to the Platonic view, is that people are born with different levels of intelligence and that those who are less intelligent need the good offices of the more intelligent to keep them in line, whether they are called government officials or, in Plato’s term, philosopher-kings. Herrnstein and Murray (1994) seem to have shared this belief when they wrote about the emergence of a cognitive (high-IQ) elite, which eventually would have to take responsibility for the largely irresponsible masses of non-elite (low-IQ) people who cannot take care of themselves. Left to themselves, the unintelligent would create, as they always have created, a kind of chaos.
H The Jeffersonian view is that people should have equal opportunities, but they do not necessarily avail themselves equally of these opportunities and are not necessarily equally rewarded for their accomplishments. People are rewarded for what they accomplish, if given equal opportunity. Low achievers are not rewarded to the same extent as high achievers. In the Jeffersonian view, the goal of education is not to favor or foster an elite, as in the Hamiltonian tradition, but rather to allow children the opportunities to make full use of the skills they have. My own views are similar to these (Sternberg, 1997).
I The Jacksonian view is that all people are equal, not only as human beings but in terms of their competencies — that one person would serve as well as another in government or on a jury or in almost any position of responsibility. In this view of democracy, people are essentially intersubstitutable except for specialized skills, all of which can be learned. In this view, we do not need or want any institutions that might lead to favoring one group over another.
J Implicit theories of intelligence and of the relationship of intelligence to society perhaps need to be considered more carefully than they have been because they often serve as underlying presuppositions for explicit theories and even experimental designs that are then taken as scientific contributions. Until scholars are able to discuss their implicit theories and thus their assumptions, they are likely to miss the point of what others are saying when discussing their explicit theories and their data.
```

[Original question page](assets/8e27a36761ea82389e9a7c0b4fce78912f75d913545db42667e70e6b60c4bb19.jpg)

<!-- Source: /api/assets/dd9f06eb5ec75e6c1a5b10c6b5d1a175719bbfb2d74796ed792cb70e6beae2c7.jpg; PDF page 61; full -->

```text
Reading
Questions 1-3
Reading Passage 1 has ten sections, A-J.
Which section contains the following information?
Write the correct letter, A-J, in boxes 1-3 on your answer sheet.
1 information about how non-scientists’ assumptions about intelligence influence their
behaviour towards others
2 a reference to lack of clarity over the definition of intelligence
3 the point that a researcher's implicit and explicit theories may be very different
Questions 4-6
Do the following statements agree with the claims of the writer in Reading Passage 1?
In boxes 4-6 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
4 Slow language development in children is likely to prove disappointing to their
parents.
5 People’s expectations of what children should gain from education are universal.
6 Scholars may discuss theories without fully understanding each other.
61
```

[Original question page](assets/dd9f06eb5ec75e6c1a5b10c6b5d1a175719bbfb2d74796ed792cb70e6beae2c7.jpg)

<!-- Source: /api/assets/a05dc94bed2b5ef772a4a9860216a524167bf57ab7758cb4dee80869c971887c.jpg; PDF page 62; full -->

```text
Test 3
Questions 7-13
Look at the following statements (Questions 7-13) and the list of theories below.
Match each statement with the correct theory, A, B, or C.
Write the correct letter, A, B, or C, in boxes 7-13 on your answer sheet.
NB You may use any letter more than once.
7 It is desirable for the same possibilities to be open to everyone.
8 No section of society should have preferential treatment at the expense of another.
9 People should only gain benefits on the basis of what they actually achieve.
10 Variation in intelligence begins at birth.
11 The more intelligent people should be in positions of power.
12 Everyone can develop the same abilities.
13 People of low intelligence are likely to lead uncontrolled lives.
List of Theories
A Hamiltonian
B Jeffersonian
C Jacksonian
62
```

[Original question page](assets/a05dc94bed2b5ef772a4a9860216a524167bf57ab7758cb4dee80869c971887c.jpg)

<!-- Source: /api/assets/d8505d10121d5b9a4fa1104ac4908663071d18ba4595c85c1d7f004f48fb5a9a.jpg; PDF page 63; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Saving bugs to find new drugs
Zoologist Ross Piper looks at the potential of insects in
pharmaceutical research
A More drugs than you might think are derived from, or inspired by, compounds found
in living things. Looking to nature for the soothing and curing of our ailments is
nothing new — we have been doing it for tens of thousands of years. You only have
to look at other primates — such as the capuchin monkeys who rub themselves with
toxin-oozing millipedes to deter mosquitoes, or the chimpanzees who use noxious
forest plants to rid themselves of intestinal parasites — to realise that our ancient
ancestors too probably had a basic grasp of medicine.
B Pharmaceutical science and chemistry built on these ancient foundations and
perfected the extraction, characterisation, modification and testing of these natural
products. Then, for a while, modern pharmaceutical science moved its focus away
from nature and into the laboratory, designing chemical compounds from scratch.
The main cause of this shift is that although there are plenty of promising chemical
compounds in nature, finding them is far from easy. Securing sufficient numbers of
the organism in question, isolating and characterising the compounds of interest,
and producing large quantities of these compounds are all significant hurdles.
C Laboratory-based drug discovery has achieved varying levels of success,
something which has now prompted the development of new approaches focusing
once again on natural products. With the ability to mine genomes for useful
compounds, it is now evident that we have barely scratched the surface of nature’s
molecular diversity. This realisation, together with several looming health crises,
such as antibiotic resistance, has put bioprospecting — the search for useful
compounds in nature — firmly back on the map.
D Insects are the undisputed masters of the terrestrial domain, where they occupy
every possible niche. Consequently, they have a bewildering array of interactions
with other organisms, something which has driven the evolution of an enormous
range of very interesting compounds for defensive and offensive purposes. Their
remarkable diversity exceeds that of every other group of animals on the planet
combined. Yet even though insects are far and away the most diverse animals in
existence, their potential as sources of therapeutic compounds is yet to be realised.
63
```

[Original question page](assets/d8505d10121d5b9a4fa1104ac4908663071d18ba4595c85c1d7f004f48fb5a9a.jpg)

<!-- Source: /api/assets/12455e5272a6be8ba6afe78c8cc2496f04ae102904fa24dce6c477fdb7e795b9.jpg; PDF page 64; full -->

```text
Test 3
E From the tiny proportion of insects that have been investigated, several promising
compounds have been identified. For example, alloferon, an antimicrobial
compound produced by blow fly larvae, is used as an antiviral and antitumor agent
in South Korea and Russia. The larvae of a few other insect species are being
investigated for the potent antimicrobial compounds they produce. Meanwhile, a
compound from the venom of the wasp Polybia paulista has potential in cancer
treatment.
F Why is it that insects have received relatively little attention in bioprospecting?
Firstly, there are so many insects that, without some manner of targeted approach,
investigating this huge variety of species is a daunting task. Secondly, insects are
generally very small, and the glands inside them that secrete potentially useful
compounds are smaller still. This can make it difficult to obtain sufficient quantities
of the compound for subsequent testing. Thirdly, although we consider insects to be
everywhere, the reality of this ubiquity is vast numbers of a few extremely common
species. Many insect species are infrequently encountered and very difficult to rear
in captivity, which, again, can leave us with insufficient material to work with.
G My colleagues and I at Aberystwyth University in the UK have developed an
approach in which we use our knowledge of ecology as a guide to target our
efforts. The creatures that particularly interest us are the many insects that secrete
powerful poison for subduing prey and keeping it fresh for future consumption.
There are even more insects that are masters of exploiting filthy habitats, such as
faeces and carcasses, where they are regularly challenged by thousands of micro-
organisms. These insects have many antimicrobial compounds for dealing with
pathogenic bacteria and fungi, suggesting that there is certainly potential to find
many compounds that can serve as or inspire new antibiotics.
H Although natural history knowledge points us in the right direction, it doesn’t
solve the problems associated with obtaining useful compounds from insects.
Fortunately, it is now possible to snip out the stretches of the insect’s DNA that
carry the codes for the interesting compounds and insert them into cell lines that
allow larger quantities to be produced. And although the road from isolating and
characterising compounds with desirable qualities to developing a commercial
product is very long and full of pitfalls, the variety of successful animal-derived
pharmaceuticals on the market demonstrates there is a precedent here that is
worth exploring.
I With every bit of wilderness that disappears, we deprive ourselves of potential
medicines. As much as I'd love to help develop a groundbreaking insect-derived
medicine, my main motivation for looking at insects in this way is conservation. I
sincerely believe that all species, however small and seemingly insignificant, have
a right to exist for their own sake. If we can shine a light on the darker recesses
of nature’s medicine cabinet, exploring the useful chemistry of the most diverse
animals on the planet, I believe we can make people think differently about the
value of nature.
```

[Original question page](assets/12455e5272a6be8ba6afe78c8cc2496f04ae102904fa24dce6c477fdb7e795b9.jpg)

<!-- Source: /api/assets/907f1bdb2a147e6d41f20c77cf091bdb71e99800a60e7374e7b20890ebba3f51.jpg; PDF page 65; full -->

```text
:
Reading
Questions 14-20
Reading Passage 2 has nine paragraphs, A-I.
Which paragraph contains the following information?
Write the correct letter, A-I, in boxes 14-20 on your answer sheet.







14 mention of factors driving a renewed interest in natural medicinal compounds
15 how recent technological advances have made insect research easier
16 examples of animals which use medicinal substances from nature
17 reasons why it is challenging to use insects in drug research
18 reference to how interest in drug research may benefit wildlife
19 a reason why nature-based medicines fell out of favour for a period
20 an example of an insect-derived medicine in use at the moment
Questions 21 and 22
Choose TWO letters, A-E.
Write the correct letters in boxes 21 and 22 on your answer sheet.
Which TWO of the following make insects interesting for drug research?
A the huge number of individual insects in the world
B the variety of substances insects have developed to protect themselves
C the potential to extract and make use of insects’ genetic codes
D the similarities between different species of insect
E the manageable size of most insects
```

[Original question page](assets/907f1bdb2a147e6d41f20c77cf091bdb71e99800a60e7374e7b20890ebba3f51.jpg)

<!-- Source: /api/assets/dbc650f425ec4200c48848c818649ed829df50ffa5d2e086c46e48c0792f1b51.jpg; PDF page 66; full -->

```text
Questions 23–26
Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 23–26 on your answer sheet.
Research at Aberystwyth University
Ross Piper and fellow zoologists at Aberystwyth University are using their expertise in (23) __________ when undertaking bioprospecting with insects. They are especially interested in the compounds that insects produce to overpower and preserve their (24) __________. They are also interested in compounds which insects use to protect themselves from pathogenic bacteria and fungi found in their (25) __________. Piper hopes that these substances will be useful in the development of drugs such as (26) __________.
```

[Original question page](assets/dbc650f425ec4200c48848c818649ed829df50ffa5d2e086c46e48c0792f1b51.jpg)

<!-- Source: /api/assets/d9f630580f8ba7b24d0f601d0447fb73559c564c707cd221df0700fd81fdf069.jpg; PDF page 67; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
The power of play
Virtually every child, the world over, plays. The drive to play is so intense that children will do so
in any circumstances, for instance when they have no real toys, or when parents do not actively
encourage the behavior. In the eyes of a young child, running, pretending, and building are fun.
Researchers and educators know that these playful activities benefit the development of the
whole child across social, cognitive, physical, and emotional domains. Indeed, play is such an
instrumental component to healthy child development that the United Nations High Commission
on Human Rights (1989) recognized play as a fundamental right of every child.
Yet, while experts continue to expound a powerful argument for the importance of play in
children’s lives, the actual time children spend playing continues to decrease. Today, children play
eight hours less each week than their counterparts did two decades ago (Elkind 2008). Under
pressure of rising academic standards, play is being replaced by test preparation in kindergartens
and grade schools, and parents who aim to give their preschoolers a leg up are led to believe
that flashcards and educational ‘toys’ are the path to success. Our society has created a false
dichotomy between play and learning.
Through play, children learn to regulate their behavior, lay the foundations for later learning in
science and mathematics, figure out the complex negotiations of social relationships, build a
repertoire of creative problem-solving skills, and so much more. There is also an important role
for adults in guiding children through playful learning opportunities.
Full consensus on a formal definition of play continues to elude the researchers and theorists who
study it. Definitions range from discrete descriptions of various types of play such as physical,
construction, language, or symbolic play (Miller & Almon 2009), to lists of broad criteria, based
on observations and attitudes, that are meant to capture the essence of all play behaviors (e.g.
Rubin et al. 1983).
A majority of the contemporary definitions of play focus on several key criteria. The founder of
the National Institute for Play, Stuart Brown, has described play as ‘anything that spontaneously
is done for its own sake’. More specifically, he says it ‘appears purposeless, produces pleasure
and joy, [and] leads one to the next stage of mastery’ (as quoted in Tippett 2008). Similarly, Miller
and Almon (2009) say that play includes ‘activities that are freely chosen and directed by children
and arise from intrinsic motivation’. Often, play is defined along a continuum as more or less
playful using the following set of behavioral and dispositional criteria (e.g. Rubin et al. 1983):
Play is pleasurable: Children must enjoy the activity or it is not play. It is intrinsically
motivated: Children engage in play simply for the satisfaction the behavior itself brings.
It has no extrinsically motivated function or goal. Play is process oriented: When children
67
```

[Original question page](assets/d9f630580f8ba7b24d0f601d0447fb73559c564c707cd221df0700fd81fdf069.jpg)

<!-- Source: /api/assets/358126de93af9d85f67f80264cf76e93b9a2bedc2f0892d55745048793484ed8.jpg; PDF page 68; full -->

```text
Test 3
play, the means are more important than the ends. It is freely chosen, spontaneous and
voluntary. If a child is pressured, they will likely not think of the activity as play. Play is
actively engaged: Players must be physically and/or mentally involved in the activity. Play
is non-literal. It involves make-believe.
According to this view, children’s playful behaviors can range in degree from 0% to 100%
playful. Rubin and colleagues did not assign greater weight to any one dimension in determining
playfulness; however, other researchers have suggested that process orientation and a lack of
obvious functional purpose may be the most important aspects of play (e.g. Pellegrini 2009).
From the perspective of a continuum, play can thus blend with other motives and attitudes that
are less playful, such as work. Unlike play, work is typically not viewed as enjoyable and it is
extrinsically motivated (i.e. it is goal oriented). Researcher Joan Goodman (1994) suggested that
hybrid forms of work and play are not a detriment to learning; rather, they can provide optimal
contexts for learning. For example, a child may be engaged in a difficult, goal-directed activity
set up by their teacher, but they may still be actively engaged and intrinsically motivated. At this
mid-point between play and work, the child’s motivation, coupled with guidance from an adult,
can create robust opportunities for playful learning.
Critically, recent research supports the idea that adults can facilitate children’s learning while
maintaining a playful approach in interactions known as ‘guided play’ (Fisher et al. 2011). The
adult’s role in play varies as a function of their educational goals and the child’s developmental
level (Hirsch-Pasek et al. 2009).
Guided play takes two forms. At a very basic level, adults can enrich the child’s environment by
providing objects or experiences that promote aspects of a curriculum. In the more direct form
of guided play, parents or other adults can support children’s play by joining in the fun as a
co-player, raising thoughtful questions, commenting on children’s discoveries, or encouraging
further exploration or new facets to the child’s activity. Although playful learning can be
somewhat structured, it must also be child-centered (Nicolopolou et al. 2006). Play should stem
from the child’s own desire.
Both free and guided play are essential elements in a child-centered approach to playful learning.
Intrinsically motivated free play provides the child with true autonomy, while guided play is an
avenue through which parents and educators can provide more targeted learning experiences.
In either case, play should be actively engaged, it should be predominantly child-directed, and it
must be fun.
68
```

[Original question page](assets/358126de93af9d85f67f80264cf76e93b9a2bedc2f0892d55745048793484ed8.jpg)

<!-- Source: /api/assets/8fda8aafed242a503d2659d87a1ea411543a4dee997627693f25538fce1c41e4.jpg; PDF page 69; full -->

```text
Reading
Questions 27-31
Look at the following statements (Questions 27-31) and the list of researchers below.
Match each statement with the correct researcher, A-G.
Write the correct letter, A-G, in boxes 27-31 on your answer sheet.





27 Play can be divided into a number of separate categories.
28 Adults’ intended goals affect how they play with children.
29 Combining work with play may be the best way for children to learn.
30 Certain elements of play are more significant than others.
31 Activities can be classified on a scale of playfulness.
List of Researchers
A Elkind
B Miller & Almon
C Rubin et al.
D Stuart Brown
E Pellegrini
F Joan Goodman
G Hirsch-Pasek et al.
```

[Original question page](assets/8fda8aafed242a503d2659d87a1ea411543a4dee997627693f25538fce1c41e4.jpg)

<!-- Source: /api/assets/73dea3d5be60f426da4e7f0c38287710ef5ce2021567987b56575cd5f6d45750.jpg; PDF page 70; full -->

```text
Test 3
Questions 32-36
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 32-36 on your answer sheet, write






YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
32 Children need toys in order to play.
33 It is a mistake to treat play and learning as separate types of activities.
34 Play helps children to develop their artistic talents.
35 Researchers have agreed on a definition of play.
36 Work and play differ in terms of whether or not they have a target.
```

[Original question page](assets/73dea3d5be60f426da4e7f0c38287710ef5ce2021567987b56575cd5f6d45750.jpg)

<!-- Source: /api/assets/8bfce4b0a5e1f405dec7afc52f45c16da8a9fa113391dec913e2b694d0a75649.jpg; PDF page 71; full -->

```text
Questions 37–40
Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 37–40 on your answer sheet.
Guided play
In the simplest form of guided play, an adult contributes to the environment in which the child is playing. Alternatively, an adult can play with a child and develop the play, for instance by (37) __________ the child to investigate different aspects of their game. Adults can help children to learn through play, and may make the activity rather structured, but it should still be based on the child’s (38) __________ to play.
Play without the intervention of adults gives children real (39) __________; with adults, play can be (40) __________ at particular goals. However, all forms of play should be an opportunity for children to have fun.
```

[Original question page](assets/8bfce4b0a5e1f405dec7afc52f45c16da8a9fa113391dec913e2b694d0a75649.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/3b55f8ee66fddd7bedc369f3b291149247157dc8dd54b8be1c05337af6e90568.jpg; PDF page 72; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagram below shows how electricity is generated in a hydroelectric power station.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/3b55f8ee66fddd7bedc369f3b291149247157dc8dd54b8be1c05337af6e90568.jpg)

![Original figure](assets/3b55f8ee66fddd7bedc369f3b291149247157dc8dd54b8be1c05337af6e90568.jpg)

### Task 2

<!-- Source: /api/assets/81838bf46ffa91c1899bdbec05965411235a66812e2dd88aefc277159d7d5d64.jpg; PDF page 73; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people say that music is a good way of bringing people of different cultures and ages together.

To what extent do you agree or disagree with this opinion?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/81838bf46ffa91c1899bdbec05965411235a66812e2dd88aefc277159d7d5d64.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/2fa9c1519c151bbd4839f2c820c96ddd8eb807031559af1ab97ca8b8ac11ec7d.jpg; PDF page 74; full -->

```text
Test 3
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Neighbours
How often do you see your neighbours? [Why/Why not?]
Do you invite your neighbours to your home? [Why/Why not?]
Do you think you are a good neighbour? [Why/Why not?]
Has a neighbour ever helped you? [Why/Why not?]
PART 2
Describe a very difficult task that you succeeded in doing as part of your work or studies.
You should say:
what task you did
why this task was very difficult
how you worked on this task
and explain how you felt when you had successfully completed this task.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Difficult jobs
Example questions:
What are the most difficult jobs that people do?
Why do you think some people choose to do difficult jobs?
Do you agree or disagree that all jobs are difficult sometimes?
Personal and career success
Example questions:
How important is it for everyone to have a goal in their personal life?
Is it always necessary to work hard in order to achieve career success?
Do you think that successful people are always happy people?
74
```

[Original question page](assets/2fa9c1519c151bbd4839f2c820c96ddd8eb807031559af1ab97ca8b8ac11ec7d.jpg)

### Part 2

<!-- Source: /api/assets/2fa9c1519c151bbd4839f2c820c96ddd8eb807031559af1ab97ca8b8ac11ec7d.jpg; PDF page 74; full -->

```text
Test 3
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Neighbours
How often do you see your neighbours? [Why/Why not?]
Do you invite your neighbours to your home? [Why/Why not?]
Do you think you are a good neighbour? [Why/Why not?]
Has a neighbour ever helped you? [Why/Why not?]
PART 2
Describe a very difficult task that you succeeded in doing as part of your work or studies.
You should say:
what task you did
why this task was very difficult
how you worked on this task
and explain how you felt when you had successfully completed this task.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Difficult jobs
Example questions:
What are the most difficult jobs that people do?
Why do you think some people choose to do difficult jobs?
Do you agree or disagree that all jobs are difficult sometimes?
Personal and career success
Example questions:
How important is it for everyone to have a goal in their personal life?
Is it always necessary to work hard in order to achieve career success?
Do you think that successful people are always happy people?
74
```

[Original question page](assets/2fa9c1519c151bbd4839f2c820c96ddd8eb807031559af1ab97ca8b8ac11ec7d.jpg)

### Part 3

<!-- Source: /api/assets/2fa9c1519c151bbd4839f2c820c96ddd8eb807031559af1ab97ca8b8ac11ec7d.jpg; PDF page 74; full -->

```text
Test 3
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Neighbours
How often do you see your neighbours? [Why/Why not?]
Do you invite your neighbours to your home? [Why/Why not?]
Do you think you are a good neighbour? [Why/Why not?]
Has a neighbour ever helped you? [Why/Why not?]
PART 2
Describe a very difficult task that you succeeded in doing as part of your work or studies.
You should say:
what task you did
why this task was very difficult
how you worked on this task
and explain how you felt when you had successfully completed this task.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Difficult jobs
Example questions:
What are the most difficult jobs that people do?
Why do you think some people choose to do difficult jobs?
Do you agree or disagree that all jobs are difficult sometimes?
Personal and career success
Example questions:
How important is it for everyone to have a goal in their personal life?
Is it always necessary to work hard in order to achieve career success?
Do you think that successful people are always happy people?
74
```

[Original question page](assets/2fa9c1519c151bbd4839f2c820c96ddd8eb807031559af1ab97ca8b8ac11ec7d.jpg)
