# 剑雅 6 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 154

TEST 2 LISTENING
Section 1, Questions 1–10
1 8
2 (in/on) Tamer
3 green button
4 library
5 education department
6 castles
7 old clothes
8 bottle tops
9 Undersea Worlds
10 silver paper
Section 2, Questions 11–20
11 King Street
12 central
13 half hour / 30 minutes
14 refreshments
15 10.15
16 Advance
17 (seat) reservations
18–20 IN ANY ORDER: C; D; G
Section 3, Questions 21–30
21 catalog(ue)s
22 computer centre / center
23 checklist
24 teaching experience
25 classroom
26 review
27 schools
28 ((the) year) 2000
29 end of term
30 research
Section 4, Questions 31–40
31 A
32 B
33 C
34 A
35 A
36 C
37 A
38 Great Train Robbery
39 Sound effects
40 poor sound quality
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. 8

2. Tamer / in Tamer / on Tamer

3. green button

4. library

5. education department

6. castles

7. old clothes

8. bottle tops

9. Undersea Worlds

10. silver paper

### Part 2 · source page 154

TEST 2 LISTENING
Section 1, Questions 1–10
1 8
2 (in/on) Tamer
3 green button
4 library
5 education department
6 castles
7 old clothes
8 bottle tops
9 Undersea Worlds
10 silver paper
Section 2, Questions 11–20
11 King Street
12 central
13 half hour / 30 minutes
14 refreshments
15 10.15
16 Advance
17 (seat) reservations
18–20 IN ANY ORDER: C; D; G
Section 3, Questions 21–30
21 catalog(ue)s
22 computer centre / center
23 checklist
24 teaching experience
25 classroom
26 review
27 schools
28 ((the) year) 2000
29 end of term
30 research
Section 4, Questions 31–40
31 A
32 B
33 C
34 A
35 A
36 C
37 A
38 Great Train Robbery
39 Sound effects
40 poor sound quality
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. King Street

12. central

13. half hour / 30 minutes

14. refreshments

15. 10.15 / 10:15

16. Advance

17. reservations / seat reservations

18. C / D / G

19. C / D / G

20. C / D / G

### Part 3 · source page 154

TEST 2 LISTENING
Section 1, Questions 1–10
1 8
2 (in/on) Tamer
3 green button
4 library
5 education department
6 castles
7 old clothes
8 bottle tops
9 Undersea Worlds
10 silver paper
Section 2, Questions 11–20
11 King Street
12 central
13 half hour / 30 minutes
14 refreshments
15 10.15
16 Advance
17 (seat) reservations
18–20 IN ANY ORDER: C; D; G
Section 3, Questions 21–30
21 catalog(ue)s
22 computer centre / center
23 checklist
24 teaching experience
25 classroom
26 review
27 schools
28 ((the) year) 2000
29 end of term
30 research
Section 4, Questions 31–40
31 A
32 B
33 C
34 A
35 A
36 C
37 A
38 Great Train Robbery
39 Sound effects
40 poor sound quality
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. catalogs / catalogues

22. computer centre / computer center

23. checklist

24. teaching experience

25. classroom

26. review

27. schools

28. 2000 / year 2000 / the year 2000

29. end of term

30. research

### Part 4 · source page 154

TEST 2 LISTENING
Section 1, Questions 1–10
1 8
2 (in/on) Tamer
3 green button
4 library
5 education department
6 castles
7 old clothes
8 bottle tops
9 Undersea Worlds
10 silver paper
Section 2, Questions 11–20
11 King Street
12 central
13 half hour / 30 minutes
14 refreshments
15 10.15
16 Advance
17 (seat) reservations
18–20 IN ANY ORDER: C; D; G
Section 3, Questions 21–30
21 catalog(ue)s
22 computer centre / center
23 checklist
24 teaching experience
25 classroom
26 review
27 schools
28 ((the) year) 2000
29 end of term
30 research
Section 4, Questions 31–40
31 A
32 B
33 C
34 A
35 A
36 C
37 A
38 Great Train Robbery
39 Sound effects
40 poor sound quality
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. A

32. B

33. C

34. A

35. A

36. C

37. A

38. Great Train Robbery

39. Sound effects

40. poor sound quality

## A 类阅读

### Academic Reading · source page 155

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 ii
2 vii
3 iv
4 i
5 iii
6 FALSE
7 TRUE
8 NOT GIVEN
9 FALSE
10 TRUE
11 F
12 D
13 C
Reading Passage 2, Questions 14–26
14 B
15 I
16 F
17 M
18 J
19 N
20 K
21 G
22 A
23 G
24 E
25 H
26 C
Reading Passage 3, Questions 27–40
27 B
28 E
29 A
30 C
31 G
32 TRUE
33 FALSE
34 TRUE
35 FALSE
36 NOT GIVEN
37 TRUE
38 FALSE
39 TRUE
40 NOT GIVEN
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. ii

2. vii

3. iv

4. i

5. iii

6. FALSE

7. TRUE

8. NOT GIVEN

9. FALSE

10. TRUE

11. F

12. D

13. C

14. B

15. I

16. F

17. M

18. J

19. N

20. K

21. G

22. A

23. G

24. E

25. H

26. C

27. B

28. E

29. A

30. C

31. G

32. TRUE

33. FALSE

34. TRUE

35. FALSE

36. NOT GIVEN

37. TRUE

38. FALSE

39. TRUE

40. NOT GIVEN

## A 类写作

### Writing material: c6-t2-w-1

Average distance in MILES travelled per PERSON per YEAR, England, 1985/2000. Walking 255/237; bicycle 51/41; car 3199/4806; local bus 429/274; long distance bus 54/124; train 289/366; taxi 13/42; other 450/585; all modes 4740/6475. Car accounts for the greatest distance in both years and much of the total increase. Walking, cycling and local-bus travel decline; all other listed modes increase. Taxi remains the smallest absolute category despite more than tripling. All modes is a total, not a separate vehicle. Do not change miles to kilometres or annual distances to journey counts.



### Writing material: c6-t2-w-2

Both views and an opinion are explicitly required: justification for high sports earnings, and arguments that the disparity is unfair.



## 口语
