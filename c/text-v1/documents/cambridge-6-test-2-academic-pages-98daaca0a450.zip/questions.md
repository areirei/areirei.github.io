# 剑雅 6 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/462fb47dea868d40dfbdcee4921a0455708c06673dd54eec7422ac5a7d4a369c.jpg; PDF page 34; full -->

```text
Listening
Test 2
LISTENING
SECTION 1 Questions 1-10
Questions 1-5
Complete the notes below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
CHILDREN'S ART AND CRAFT WORKSHOPS
Example Answer
Workshops organised every: Saturday
• Adults must accompany children under 1 .............. ......... .
• Cost: £2.50
• Workshops held in: Winter House , 2 ........................ Street
• Security device: must push the 3 ........................ to open door
• Should leave car behind the 4 ....................... .
• Book workshops by phoning the 5 ................. ....... (on 200765)
33
```

[Original question page](assets/462fb47dea868d40dfbdcee4921a0455708c06673dd54eec7422ac5a7d4a369c.jpg)

<!-- Source: /api/assets/079ee6d07e818caa8ec26cb4425f13b327918ee2688df699b8adbe4fb1b0dbf8.jpg; PDF page 35; full -->

```text
Questions 6–10
Complete the table below. Write NO MORE THAN TWO WORDS for each answer.
Next two workshops
| Date | Workshop title | Children advised to wear | Please bring (if possible) |
| --- | --- | --- | --- |
| 16/11 | Building (6) __________ | (7) __________ | (8) __________ |
| 23/11 | (9) __________ | Nothing special | (10) __________ |
```

[Original question page](assets/079ee6d07e818caa8ec26cb4425f13b327918ee2688df699b8adbe4fb1b0dbf8.jpg)

### Part 2

<!-- Source: /api/assets/f7cb7e5ab278793b0dc3b6e1a2e8bef62f1bc432bf3cde316941e33d0de2f40a.jpg; PDF page 36; full -->

```text
SECTION 2
Questions 11-14
Questions 11-20
Complete the sentences below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
TRAIN INFORMATION
11 Local services depart from ........................ railway station.
12 National services depart from the ........................ railway station.
13 Trains for London depart every ......................... each day during the week.
14 The price of a first class ticket includes ........................ .
Questions 15-17
Complete the table below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
| Type of ticket | Details |
| --- | --- |
| Standard open | no restrictions |
| Supersave | travel after 8.45 |
| Special | travel after (15) __________ and at weekends |
| (16) __________ | buy at least six days ahead; limited numbers; (17) __________ essential |
```

[Original question page](assets/f7cb7e5ab278793b0dc3b6e1a2e8bef62f1bc432bf3cde316941e33d0de2f40a.jpg)

<!-- Source: /api/assets/63a19be7deba7587f882acdcc39583e457a83c644c19b6a670b02b21cf9213cd.jpg; PDF page 37; full -->

```text
Test 2
Questions 18-20
Choose THREE letters, A-G
Which THREE attractions can you visit at present by train from Trebirch?
A a science museum
B a theme park
C a climbing wall
D a mining museum
E an aquarium
F a castle
G a zoo
36
```

[Original question page](assets/63a19be7deba7587f882acdcc39583e457a83c644c19b6a670b02b21cf9213cd.jpg)

### Part 3

<!-- Source: /api/assets/33fd7fe40d3e62309c200a9e2b3098c000fb6616af0a8da43442b8379ca0122b.jpg; PDF page 38; full -->

```text
SECTION 3 Questions 21–30
Complete the tables below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Dissertation Tutorial Record (Education)
Name: Sandy Gibbons
| Targets previously agreed | Work completed | Further action suggested |
| --- | --- | --- |
| Investigate suitable data analysis software | Read IT (21) __________; Spoken to Jane Prince, Head of the (22) __________ | Sign up for some software practice sessions |
| Prepare a (23) __________ for survey | Completed and sent for review | Add questions in section three on (24) __________ |
| Further reading about discipline | Read Banerjee; N.B. Couldn’t find Ericsson’s essays on managing the (25) __________ | Obtain from library through special loans service |
| New Targets | Specific suggestions | Timing |
| Do further work on Chapter 1 (Give the title: Context (26) __________) | Add statistics on the (27) __________ in various zones; Include more references to works dated after (28) __________ | By the (29) __________ |
| Prepare list of main sections for Chapter 2 | Use index cards to help in organisation | Before starting the (30) __________ |
```

[Original question page](assets/33fd7fe40d3e62309c200a9e2b3098c000fb6616af0a8da43442b8379ca0122b.jpg)

### Part 4

<!-- Source: /api/assets/3079c78bc92dc922750d669320948a7240768acd4cf7c30eb7b96216887eda95.jpg; PDF page 39; full -->

```text
Test 2
SECTION 4 Questions 31-40
Questions 31-37
Choose the correct letter, A, B or C.
The history of moving pictures
31 Some photographs of a horse running showed
A all feet off the ground.
B at least one foot on the ground .
C two feet off the ground.
32 The Scotsman employed by Edison
A designed a system to use the technology Edison had invented .
B used available technology to make a new system.
C was already an expert in motion picture technology .
33 One major problem with the first system was that
A only one person could be filmed.
B people could only see very short films.
C the camera was very heavy.
34 Rival systems started to appear in Europe after people had
A been told about the American system .
B seen the American system.
C used the American system.
35 In 1895, a famous new system was developed by
A a French team working alone.
B a French and German team working together.
C a German team who invented the word 'cinema' .
36 Longer films were not made at the time because of problems involving
A the subject matter.
B the camera.
C the film projector.
37 The 'Lantham Loop' invention relied on
A removing tension between the film reels. ·
B adding three more film reels to the system .·
C making one of the film reels more effective.
38
```

[Original question page](assets/3079c78bc92dc922750d669320948a7240768acd4cf7c30eb7b96216887eda95.jpg)

<!-- Source: /api/assets/818240962f03ba6a2cefdd933924811d03da764ea2710ded6dc63a51156e7d6a.jpg; PDF page 40; full -->

```text
Listening
Questions 38-40
Complete the sentences below.
Write NO MORE THAN THREE WORDS for each answer.
38 The first motion picture was called The ........... ............. .
39 ........................ were used for the first time on film in 1926.
40 Subtitles were added to The Lights of New York because of its ........................ .
39
```

[Original question page](assets/818240962f03ba6a2cefdd933924811d03da764ea2710ded6dc63a51156e7d6a.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/0487d1cca13f2029b20a08e0064c53add475003755eca151d27cc45d5bccb4b9.jpg; PDF page 41; full -->

```text
Test 2
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13 , which are based on Reading Passage 1
on the following pages.
Questions 1-5
Reading Passage 1 has five marked paragraphs, A-E.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i-viii , in boxes 1-5 on your answer sheet.
List of Headings
i Avoiding an overcrowded centre
ii A successful exercise in people power
iii The benefits of working together in cities
iv Higher incomes need not mean more cars
v Economic arguments fail to persuade
vi The impact of telecommunications on population distribution
vii Increases in travelling time
viii Responding to arguments against public transport
1 Paragraph A __________
2 Paragraph B __________
3 Paragraph C __________
4 Paragraph D __________
5 Paragraph E __________
```

[Original question page](assets/0487d1cca13f2029b20a08e0064c53add475003755eca151d27cc45d5bccb4b9.jpg)

<!-- Source: /api/assets/c9892b0b52a6acfc87565f40b9449b70352196c07f237e0b7f263c5eccd43161.jpg; PDF page 42; full -->

```text
Reading
Advantages of public transport
A new study conducted for the World Bank by Murdoch University's Institute for Science and
Technology Policy (ISTP) has demonstrated that public transport is more efficient than cars. The
study compared the proportion of wealth poured into transport by thirty-seven cities around the
world . This included both the public and private costs of building, maintaining and using a
transport system.
The study found that the Western Australian city of Perth is a good example of a city with
minimal public transport . As a result, 17% of its wealth went into transport costs. Some
European and Asian cities, on the other hand, spent as little as 5% . Professor Peter Newman,
ISTP Director, pointed out that these more efficient cities were able to put the difference into
attracting industry and jobs or creating a better place to live.
According to Professor Newman, the larger Australian city of Melbourne is a rather unusual city
in this sort of comparison . He describes it as two cities: 'A European city surrounded by a car­
dependent one' . Melbourne 's large tram network has made car use in the inner city much
lower, but the outer suburbs have the same car-based structure as most other Australian cities.
The explosion in demand for accommodation in the inner suburbs of Melbourne suggests a
recent change in many people's preferences as to where they live.
Newman says this is a new, broader way of considering public transport issues. In the past, the
case for public transport has been made on the basis of environmental and social justice
considerations rather than economics . Newman , however, believes the study demonstrates that
'the auto-dependent city model is inefficient and grossly inadequate in economic as well as
environmental terms' .
Bicycle use was not included in the study but Newman noted that the two most 'bicycle friendly'
cities considered -Amsterdam and Copenhagen -were very efficient, even though their public
transport systems were 'reasonable but not special'.
It is common for supporters of road networks to reject the models of cities with good public
transport by arguing that such systems would not work in their particular city. One objection is
climate. Some people say their city could not make more use of public transport because it is
either too hot or too cold. Newman rejects this, pointing out that public transport has been
successful in both Toronto and Singapore and, in fact, he has checked the use of cars against
climate and found 'zero correlation' .
41
```

[Original question page](assets/c9892b0b52a6acfc87565f40b9449b70352196c07f237e0b7f263c5eccd43161.jpg)

<!-- Source: /api/assets/0e50b23dcabacc3f45a9f9740eead992cde5579db7e8bdf700db9d2fcd0b38d5.jpg; PDF page 43; full -->

```text
Test 2
When it comes to other physical features, road lobbies are on stronger ground . For example,
Newman accepts it would be hard for a city as hilly as Auckland to develop a really good rail
network . However, he points out that both Hong Kong and Zurich have managed to make a
success of their rail systems, heavy and light respectively, though there are few cities in the
world as hilly.
A In fact, Newman believes the main reason for adopting one sort of transport over another is
politics: 'The more democratic the process, the more public transport is favored.' He considers
Portland, Oregon, a perfect example of this. Some years ago, federal money was granted to
build a new road. However, local pressure groups forced a referendum over whether to spend
the money on light rail instead. The rail proposal won and the railway worked spectacularly well .
In the years that have followed, more and more rail systems have been put in, dramatically
changing the nature of the city. Newman notes that Portland has about the same population as
Perth and had a similar population density at the time .
B In the UK, travel times to work had been stable for at least six centuries, with people avoiding
situations that required them to spend more than half an hour travelling to work . Trains and cars
initially allowed people to live at greater distances without taking longer to reach their
destination. However, public infrastructure did not keep pace with urban sprawl, causing
massive congestion problems which now make commuting times far higher.
C There is a widespread belief that increasing wealth encourages people to live farther out where
cars are the only viable transport . The example of European cities refutes that. They are often
wealthier than their American counterparts but have not generated the same level of car use. In
Stockholm, car use has actually fallen in recent years as the city has become larger and
wealthier. A new study makes this point even more starkly. Developing cities in Asia, such as
Jakarta and Bangkok, make more use of the car than wealthy Asian cities such as Tokyo and
Singapore. In cities that developed later, the World Bank and Asian Development Bank ·
discouraged the building of public transport and people have been forced to rely on cars­
creating the massive traffic jams that characterize those cities.
D Newman believes one of the best studies on how cities built for cars might be converted to rail
use is The Urban Village report, which used Melbourne as an example. It found that pushing
everyone into the city centre was not the best approach . Instead, the proposal advocated the
creation of urban villages at hundreds of sites, mostly around railway stations. ·
E It was once assumed that improvements in telecommunications would lead to more dispersal in
the population as people were no longer forced into cities. However, the ISTP team's research
demonstrates that the population and job density of cities rose or remained constant in the
1980s after decades of decline. The explanation for this seems to be that it is valuable to place
people working in related fields together. 'The new world will largely depend on human
creativity, and creativity flourishes where people come together face-to-face.'
42
```

[Original question page](assets/0e50b23dcabacc3f45a9f9740eead992cde5579db7e8bdf700db9d2fcd0b38d5.jpg)

<!-- Source: /api/assets/7b4dbd6659ccddc2f24778de2a534d4de2250679c186dd92dfc3f6384dda05ee.jpg; PDF page 44; full -->

```text
Reading
Questions 6-10
Do the following statements agree with the information given in Reading Passage 1?
In boxes 6-10 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
6 The ISTP study examined public and private systems in every city of the world.
7 Efficient cities can improve the quality of life for their inhabitants.
8 An inner-city tram network is dangerous for car drivers.
9 In Melbourne , people prefer to live in the outer suburbs .
10 Cities with high levels of bicycle usage can be efficient even when public transport is
only averagely good.
Questions 11-13
Look at the following cities ( Questions 11-13) and the list of descriptions below.
Match each city with the correct description, A-F.
Write the correct letter, A-F, in boxes 11-13 on your answer sheet.
11 Perth
12 Auckland
13 Portland
List of Descriptions
A successfully uses a light rail transport system in hilly environment
B successful public transport system despite cold winters
C profitably moved from road to light rail transport system
D hilly and inappropriate for rail transport system
E heavily dependent on cars despite widespread poverty
F inefficient due to a limited public transport system
43
```

[Original question page](assets/7b4dbd6659ccddc2f24778de2a534d4de2250679c186dd92dfc3f6384dda05ee.jpg)

<!-- Source: /api/assets/c9245d906813acc887a9e258357047ef26e577ea1501c91e811c094f913c140a.jpg; PDF page 45; full -->

```text
Test 2
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26 , which are based on Reading Passage 2
below.
GREYING POPULATION STAYS IN THE PINK
Elderly people are growing healthier, happier and more independent, say American
scientists. The results of a 14-year study to be announced later this month reveal that the
diseases associated with old age are afflicting fewer and fewer people and when they do
strike, it is much later in life.
In the last 14 years, the National Long-term Health Care Survey has gathered data on the
health and lifestyles of more than 20,000 men and women over 65. Researchers, now
analysing the results of data gathered in 1994, say arthritis, high blood pressure and
circulation problems- the major medical complaints in this age group- are troubling a
smaller proportion every year. And the data confirms that the rate at which these diseases
are declining continues to accelerate . Other diseases of old age- dementia, stroke,
arteriosclerosis and emphysema -are also troubling fewer and fewer people.
‘It really raises the question of what should be considered normal ageing,' says Kenneth
Manton, a demographer from Duke University in North Carolina. He says the problems
doctors accepted as normal in a 65-year-old in 1982 are often not appearing until people
are 70 or 75.
Clearly, certain diseases are beating a retreat in the face of medical advances. But there may
be other contributing factors. Improvements in childhood nutrition in the first quarter of
the twentieth century, for example, gave today's elderly people a better start in life than
their predecessors.
On the downside, the data also reveals failures in public health that have caused surges in
some illnesses. An increase in some cancers and bronchitis may reflect changing smoking
habits and poorer air quality, say the researchers. 'These may be subtle influences,' says
Manton , 'but our subjects have been exposed to worse and worse pollution for over 60
years. It’s not surprising we see some effect.'
One interesting correlation Manton uncovered is that better-educated people are likely to
live longer. For example, 65-year-old women with fewer than eight years of schooling are
expected, on average, to live to 82. Those who continued their education live an extra seven
years. Although some of this can be attributed to a higher income, Manton believes it is
mainly because educated people seek more medical attention .
The survey also assessed how independent people over 65 were, and again found a striking
trend. Almost 80% of those in the 1994 survey could complete everyday activities ranging
from eating and dressing unaided to complex tasks such as cooking and managing their
finances. That represents a significant drop in the number of disabled old people in the
population . If the trends apparent in the United States 14 years ago had continued,
44
```

[Original question page](assets/c9245d906813acc887a9e258357047ef26e577ea1501c91e811c094f913c140a.jpg)

<!-- Source: /api/assets/28624c749b3db55dd80cf7bc4d7aaf0d918b705dd610d818ff7d3b0b6a1d6e0a.jpg; PDF page 46; full -->

```text
Reading
researchers calculate there would be an additional one million disabled elderly people in
today's population. According to Manton, slowing the trend has saved the United States
government's Medicare system more than $200 billion, suggesting that the greying of
America's population may prove less of a financial burden than expected.
The increasing self-reliance of many elderly people is probably linked to a massive increase
in the use of simple home medical aids. For instance, the use of raised toilet seats has more
than doubled since the start of the study, and the use of bath seats has grown by more than
50%. These developments also bring some health benefits, according to a report from the
MacArthur Foundation's research group on successful ageing. The group found that those
elderly people who were able to retain a sense of independence were more likely to stay
healthy in old age.
Maintaining a level of daily physical activity may help mental functioning, says Carl Cotman,
a neuroscientist at the University of California at Irvine . He found that rats that exercise on a
treadmill have raised levels of brain-derived neurotrophic factor coursing through their
brains. Cotman believes this hormone, which keeps neurons functioning, may prevent the
brains of active humans from deteriorating.
As part of the same study, Teresa Seeman, a social epidemiologist at the University of
Southern California in Los Angeles, found a connection between self-esteem and stress in
people over 70. In laboratory simulations of challenging activities such as driving, those who
felt in control of their lives pumped out lower levels of stress hormones such as cortisol.
Chronically high levels of these hormones have been linked to heart disease.
But independence can have drawbacks. Seeman found that elderly people who felt
emotionally isolated maintained higher levels of stress hormones even when asleep. The
research suggests that older people fare best when they feel independent but know they
can get help when they need it.
'Like much research into ageing, these results support common sense,' says Seeman. They
also show that we may be underestimating the impact of these simple factors. 'The sort of
thing that your grandmother always told you turns out to be right on target,' she says.
45
```

[Original question page](assets/28624c749b3db55dd80cf7bc4d7aaf0d918b705dd610d818ff7d3b0b6a1d6e0a.jpg)

<!-- Source: /api/assets/45846393969d46ca93e7edca1b78907ca64bdc74dbe1abc01295f59d87d48c6a.jpg; PDF page 47; full -->

```text
Test 2
Questions 14-22
Complete the summary using the list of words, A-Q, below.
Write the correct letter, A-Q, in boxes 14-22 on your answer sheet.
Research carried out by scientists in the United States has shown that the proportion of
people over 65 suffering from the most common age-related medical problems is
14 ........................ and that the speed of this change is 15 ........................ . It also seems
that these diseases are affecting people 16 ........................ in life than they did in the past.
This is largely due to developments in 17 ........................ ,but other factors such as
improved 18 .............. : ......... may also be playing a part. Increases in some other illnesses
may be due to changes in personal habits and to 19 ......................... The research
establishes a link between levels of 20 ........................ and life expectancy. It also shows that
there has been a considerable reduction in the number of elderly people who are
21 ........................ , which means that the 22 ........................ involved in supporting this
section of the population may be less than previously predicted.
A cost B falling C technology
D undernourished E earlier F later
G disabled H more I increasing
J nutrition K education L constant
M medicine N pollution O environmental
P health Q independent
46
```

[Original question page](assets/45846393969d46ca93e7edca1b78907ca64bdc74dbe1abc01295f59d87d48c6a.jpg)

<!-- Source: /api/assets/0478f6fd7e4423b2d2e2d4b5bc8aa077e5e892d8935bffd02c1debf1e83dffbf.jpg; PDF page 48; full -->

```text
Questions 23-26
Complete each sentence with the correct ending, A-H, below.
Write the correct letter, A-H, in boxes 23-26 on your answer sheet.
23 Home medical aids
24 Regular amounts of exercise
25 Feelings of control over life
26 Feelings of loneliness
A may cause heart disease.
B can be helped by hormone treatment.
C may cause rises in levels of stress hormones.
D have cost the United States government more than $200 billion.
E may help prevent mental decline.
F may get stronger at night.
G allow old people to be more independent.
H can reduce stress in difficult situations.
Reading
47
```

[Original question page](assets/0478f6fd7e4423b2d2e2d4b5bc8aa077e5e892d8935bffd02c1debf1e83dffbf.jpg)

<!-- Source: /api/assets/0d1db25fe01b94318ae952db04eab49a611297d509f31f18b0c00a76f496ea38.jpg; PDF page 49; full -->

```text
Test 2
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40 , which are based on Reading Passage 3
below.
Numeration
One of the first great intellectual feats of a young child is learning
how to talk, closely followed by learning how to count. From earliest
childhood we are so bound up with our system of numeration that it
is a feat of imagination to consider the problems faced by early
humans who had not yet developed this facility . Careful
consideration of our system of numeration leads to the conviction
that, rather than being a facility that comes naturally to a person, it
is one of the great and remarkable achievements of the human race .
It is impossible to learn the sequence of events that led to our developing the concept of
number. Even the earliest of tribes had a system of numeration that, if not advanced, was
sufficient for the tasks that they had to perform. Our ancestors had little use for actual numbers;
instead their considerations would have been more of the kind Is this enough? rather than How
many? when they were engaged in food gathering, for example. However, when early
humans first began to reflect on the nature of things around them, they discovered that they
needed an idea of number simply to keep their thoughts in order . As they began to settle,
grow plants and herd animals , the need for a sophisticated number system became
paramount. It will never be known how and when this numeration ability developed, but it is
certain that numeration was well developed by the time humans had formed even semi­
permanent settlements.
Evidence of early stages of arithmetic and numeration can be readily found . The indigenous
peoples of Tasmania were only able to count one , two, many ; those of South Africa counted
one, two, two and one, two twos, two twos and one, and so on. But in real situations the
number and words are often accompanied by gestures to help resolve any confusion . For
example, when using the one, two, many type of system, the word many would mean, Look at
my hands and see how many fingers I am showing you . This basic approach is limited in the
range of numbers that it can express, but this range will generally suffice when dealing with
the simpler aspects of human existence.
The lack of ability of some cultures to deal with large numbers is not really surprising.
European languages, when traced back to their earlier version, are very poor in number
words and expressions. The ancient Gothic word for ten, tachund, is used to express the
number 100 as tachund tachund. By the seventh century, the word teon had become
interchangeable with the tachund or hund of the Anglo-Saxon language, and so 100 was
denoted as hund teontig, or ten times ten. The average person in the seventh century in Europe
was not as familiar with numbers as we are today . In fact, to qualify as a witness in a court of
law a man had to be able to count to nine!
48
```

[Original question page](assets/0d1db25fe01b94318ae952db04eab49a611297d509f31f18b0c00a76f496ea38.jpg)

<!-- Source: /api/assets/e1744a2fc42f7c6bf93eeccde66b53e63b1aa71b496e5fd8cce8c04a5b37013c.jpg; PDF page 50; full -->

```text
Reading



Perhaps the most fundamental step in developing a sense of number is not the ability to count,

but rather to see that a number is really an abstract idea instead of a simple attachment to a

group of particular objects. It must have been within the grasp of the earliest humans to

conceive that four birds are distinct from two birds; however, it is not an elementary step to

associate the number 4, as connected with four birds, to the number 4, as connected with four

rocks. Associating a number as one of the qualities of a specific object is a great hindrance to

the development of a true number sense. When the number 4 can be registered in the mind as

a specific word, independent of the object being referenced, the individual is ready to take the

first step toward the development of a notational system for numbers and, from there, to

arithmetic.



Traces of the very first stages in the development of numeration can be seen in several living

languages today. The numeration system of the Tsimshian language in British Columbia

contains seven distinct sets of words for numbers according to the class of the item being

counted: for counting flat objects and animals, for round objects and time, for people, for long

objects and trees, for canoes, for measures, and for counting when no particular object is

being numerated. It seems that the last is a later development while the first six groups show

the relics of an older system. This diversity of number names can also be found in some widely

used languages such as Japanese.



Intermixed with the development of a number sense is the development of an ability to count.

Counting is not directly related to the formation of a number concept because it is possible to

count by matching the items being counted against a group of pebbles, grains of corn, or the

counter’s fingers. These aids would have been indispensable to very early people who would

have found the process impossible without some form of mechanical aid. Such aids, while

different, are still used even by the most educated in today’s society due to their convenience.

All counting ultimately involves reference to something other than the things being counted. At

first it may have been grains or pebbles but now it is a memorised sequence of words that

happen to be the names of the numbers.



49
```

[Original question page](assets/e1744a2fc42f7c6bf93eeccde66b53e63b1aa71b496e5fd8cce8c04a5b37013c.jpg)

<!-- Source: /api/assets/f91d74ecf3ab26d752a2946ba75015f239eccbb75e7371d953bb6183fd0f1ddf.jpg; PDF page 51; full -->

```text
Test 2
Questions 27-31
Complete each sentence with the correct ending, A-G, below.
Write the correct letter, A-G, in boxes 27-31 on your answer sheet.
27 A developed system of numbering
28 An additional hand signal
29 In seventh-century Europe , the ability to count to a certain number
30 Thinking about numbers as concepts separate from physical objects
31 Expressing number differently according to class of item
50
A was necessary in order to fulfil a civic role.
B was necessary when people began farming.
C was necessary for the development of arithmetic.
D persists in all societies.
E was used when the range of number words was restricted.
F can be traced back to early European languages.
G was a characteristic of early numeration systems.
```

[Original question page](assets/f91d74ecf3ab26d752a2946ba75015f239eccbb75e7371d953bb6183fd0f1ddf.jpg)

<!-- Source: /api/assets/76214a350a47648467f89d45e7ef9d7497c6d989fcde634dae41af4152ad3692.jpg; PDF page 52; full -->

```text
Reading
Questions 32-40
Do the following statements agree with the information given in Reading Passage 3?
In boxes 32-40 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
32 For the earliest tribes, the concept of sufficiency was more important than the concept
of quantity.
33 Indigenous Tasmanians used only four terms to indicate numbers of objects.
34 Some peoples with simple number systems use body language to prevent
misunderstanding of expressions of number .
35 All cultures have been able to express large numbers clearly.
36 The word 'thousand' has Anglo-Saxon origins.
37 In general, people in seventh-century Europe had poor counting ability.
38 In the Tsimshian language, the number for long objects and canoes is expressed with
the same word.
39 The Tsimshian language contains both older and newer systems of counting .
40 Early peoples found it easier to count by using their fingers rather than a group of
pebbles.
51
```

[Original question page](assets/76214a350a47648467f89d45e7ef9d7497c6d989fcde634dae41af4152ad3692.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/649ab650726394042799947034d38e471a5f5c126645755447bde14416bd1985.jpg; PDF page 53; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The table below gives information about changes in modes of travel in England between 1985 and 2000.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the original figure is retained for the complete plotted data or diagram.]
```

[Original question page](assets/649ab650726394042799947034d38e471a5f5c126645755447bde14416bd1985.jpg)

![Original figure](assets/649ab650726394042799947034d38e471a5f5c126645755447bde14416bd1985.jpg)

### Task 2

<!-- Source: /api/assets/138c57f46887820fff0852924189c85de2ecd937d75d1502840b67d1a6bec8e5.jpg; PDF page 54; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Successful sports professionals can earn a great deal more money than people in other important professions. Some people think this is fully justified while others think it is unfair.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/138c57f46887820fff0852924189c85de2ecd937d75d1502840b67d1a6bec8e5.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/18cdba5716dca265e848dfa6f579dcb7ab6fce60547c56fea565626b477599db.jpg; PDF page 55; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Musical instruments
• Which instrument do you like listening to most? [Why?]
• Have you ever learned to play a musical instrument? [Which one?]
• Do you think children should learn to play a musical instrument at school? [Why/Why not?]
• How easy would it be to learn to play an instrument without a teacher? [Why?]
PART 2
Describe something healthy you enjoy doing.
You should say:
what you do
where you do it
who you do it with
and explain why you think doing this is
healthy.
You will have to talk about the topic for one
to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if you
wish.

PART 3
Discussion topics:
Keeping fit and healthy
Example questions:
What do most people do to keep fit in your country?
How important is it for people to do some regular physical exercise?
Health and modern lifestyles
Example questions:
Why do some people think that modern lifestyles are not healthy?
Why do some people choose to lead unhealthy lives?
Should individuals or governments be responsible for making people's lifestyle healthy?
What could be done to encourage people to live in a healthy way?
54
```

[Original question page](assets/18cdba5716dca265e848dfa6f579dcb7ab6fce60547c56fea565626b477599db.jpg)

### Part 2

<!-- Source: /api/assets/18cdba5716dca265e848dfa6f579dcb7ab6fce60547c56fea565626b477599db.jpg; PDF page 55; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Musical instruments
• Which instrument do you like listening to most? [Why?]
• Have you ever learned to play a musical instrument? [Which one?]
• Do you think children should learn to play a musical instrument at school? [Why/Why not?]
• How easy would it be to learn to play an instrument without a teacher? [Why?]
PART 2
Describe something healthy you enjoy doing.
You should say:
what you do
where you do it
who you do it with
and explain why you think doing this is
healthy.
You will have to talk about the topic for one
to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if you
wish.

PART 3
Discussion topics:
Keeping fit and healthy
Example questions:
What do most people do to keep fit in your country?
How important is it for people to do some regular physical exercise?
Health and modern lifestyles
Example questions:
Why do some people think that modern lifestyles are not healthy?
Why do some people choose to lead unhealthy lives?
Should individuals or governments be responsible for making people's lifestyle healthy?
What could be done to encourage people to live in a healthy way?
54
```

[Original question page](assets/18cdba5716dca265e848dfa6f579dcb7ab6fce60547c56fea565626b477599db.jpg)

### Part 3

<!-- Source: /api/assets/18cdba5716dca265e848dfa6f579dcb7ab6fce60547c56fea565626b477599db.jpg; PDF page 55; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Musical instruments
• Which instrument do you like listening to most? [Why?]
• Have you ever learned to play a musical instrument? [Which one?]
• Do you think children should learn to play a musical instrument at school? [Why/Why not?]
• How easy would it be to learn to play an instrument without a teacher? [Why?]
PART 2
Describe something healthy you enjoy doing.
You should say:
what you do
where you do it
who you do it with
and explain why you think doing this is
healthy.
You will have to talk about the topic for one
to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if you
wish.

PART 3
Discussion topics:
Keeping fit and healthy
Example questions:
What do most people do to keep fit in your country?
How important is it for people to do some regular physical exercise?
Health and modern lifestyles
Example questions:
Why do some people think that modern lifestyles are not healthy?
Why do some people choose to lead unhealthy lives?
Should individuals or governments be responsible for making people's lifestyle healthy?
What could be done to encourage people to live in a healthy way?
54
```

[Original question page](assets/18cdba5716dca265e848dfa6f579dcb7ab6fce60547c56fea565626b477599db.jpg)
