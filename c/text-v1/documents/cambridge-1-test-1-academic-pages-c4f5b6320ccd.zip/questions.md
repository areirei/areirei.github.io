# 剑雅 1 · Test 1

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/cc34949ee3742496bcf3e614ba0e7c6081938121eeb5db10df152cf96a7dfa82.jpg; PDF page 18; full -->

```text
Practice Test 1 — LISTENING
SECTION 1 Questions 1–10
Questions 1–5: Circle the appropriate letter.
Example: What has the woman lost?
A a briefcase [circled example]   B a suitcase   C a handbag   D a wallet
1 What does her briefcase look like?
A / B / C / D: picture choices retained in the original figure below.
2 Which picture shows the distinguishing features?
A / B / C / D: picture choices retained in the original figure below.
3 What did she have inside her briefcase?
A wallet, pens and novel
B papers and wallet
C pens and novel
D papers, pens and novel
```

[Original question page](assets/cc34949ee3742496bcf3e614ba0e7c6081938121eeb5db10df152cf96a7dfa82.jpg)

![Original figure](assets/cc34949ee3742496bcf3e614ba0e7c6081938121eeb5db10df152cf96a7dfa82.jpg)

<!-- Source: /api/assets/4576a4dc55f498560c40237ea3079adf2325c7507eb4541dc5a29bffa843fc25.jpg; PDF page 19; full -->

```text
Listening
4 Where was she standing when she lost her briefcase?
A / B / C / D: picture choices retained in the original figure below.
5 What time was it when she lost her briefcase?
A / B / C / D: clock-picture choices retained in the original figure below.
Questions 6–10
Complete the form Write NO MORE THAN THREE WORDS for each answer.
PERSONAL DETAILS FORM
Name: Mary (6) __________
Address: Flat 2
         (7) __________ (8) __________ Road
         Canterbury
Telephone: (9) __________
Estimated value of lost item: (10) £ __________
```

[Original question page](assets/4576a4dc55f498560c40237ea3079adf2325c7507eb4541dc5a29bffa843fc25.jpg)

![Original figure](assets/4576a4dc55f498560c40237ea3079adf2325c7507eb4541dc5a29bffa843fc25.jpg)

### Part 2

<!-- Source: /api/assets/ffe6a154f38203cb9e92da88b913599783658a1e2b5594162c6261c8aac77e7b.jpg; PDF page 20; full -->

```text
Practice Test 1
SECTION 2 Questions 11–21
Questions 11–13
Tick the THREE other items which are mentioned in the news headlines.
NEWS HEADLINES
A Rivers flood in the north
B Money promised for drought victims [Example: already ticked]
C Nurses on strike in Melbourne
D Passengers rescued from ship
E Passengers rescued from plane
F Bus and train drivers national strike threat
G Teachers demand more pay
H New uniform for QANTAS staff
I National airports under new management
```

[Original question page](assets/ffe6a154f38203cb9e92da88b913599783658a1e2b5594162c6261c8aac77e7b.jpg)

<!-- Source: /api/assets/a8c6d6fff1d1df7f01195bacbcde7f78c1bd2d55e7709b7d755b257ec6a07768.jpg; PDF page 21; full -->

```text
Listening
Questions 14-21
Complete the notes below by writing NO MORE THAN THREE WORDS in the spaces
provided.
The Government plans to give (14) $ ................................................ to assist the
farmers. This money was to be spent on improving Sydney’s
(15) ........................................................................ but has now been re-allocated.
Australia has experienced its worst drought in over fifty years.
Farmers say that the money will not help them because it is
(16) ............................................................. .
An aeroplane which was carrying a group of (17) ..................................................
was forced to land just (18) ................................................. minutes after take-off.
The passengers were rescued by (19) ............................................................ . The
operation was helped because of the good weather. The passengers
thanked the (20) ............................................................... for saving their lives but
unfortunately they lost their (21) .................................................................. .
```

[Original question page](assets/a8c6d6fff1d1df7f01195bacbcde7f78c1bd2d55e7709b7d755b257ec6a07768.jpg)

### Part 3

<!-- Source: /api/assets/e3f89b15224fe6e8831ade01a3578f2ee7e2c5d6bf18a224069d53902d4e11c0.jpg; PDF page 22; full -->

```text
16
Practice Test 1
SECTION 3    Questions 22-31
Questions 22-25
Circle the appropriate letter.
Example
The student is looking for the School of
A Fine Arts.
B Economic History.
C Economics.
D Accountancy.
22 The orientation meeting
A took place recently.
B took place last term.
C will take place tomorrow.
D will take place next week.
23 Attendance at lectures is
A optional after 4 pm.
B closely monitored.
C difficult to enforce.
D sometimes unnecessary.
24 Tutorials take place
A every morning.
B twice a week.
C three mornings a week.
D three afternoons a week.
25 The lecturer’s name is
A Roberts.
B Rawson.
C Rogers.
D Robertson.
```

[Original question page](assets/e3f89b15224fe6e8831ade01a3578f2ee7e2c5d6bf18a224069d53902d4e11c0.jpg)

<!-- Source: /api/assets/086f25439ad2be8fb3bd60d19a0cb2cbbcc96e8d79678dc4eb623ca499576ee3.jpg; PDF page 23; full -->

```text
Listening
Questions 26–31
Complete the notes below using NO MORE THAN THREE WORDS.
Course requirements:
Tutorial paper:
A piece of work on a given topic. Students must:
• (26) __________ for 25 minutes
• (27) __________
• give to lecturer for marking
Essay topic:
Usually (28) __________
Type of exam:
(29) __________
Library:
Important books are in (30) __________.
Focus of course:
Focus on (31) __________.
```

[Original question page](assets/086f25439ad2be8fb3bd60d19a0cb2cbbcc96e8d79678dc4eb623ca499576ee3.jpg)

### Part 4

<!-- Source: /api/assets/741539f7ef05bde7d5f0c4b2c3a3bd2eb5a00ce021bdd4e790e4d2166175b907.jpg; PDF page 24; full -->

```text
18
Practice Test 1
SECTION 4    Questions 32-41
Questions 32-33
Circle the appropriate letter.
32 The speaker works within the Faculty of
A Science and Technology.
B Arts and Social Sciences.
C Architecture.
D Law.
33 The Faculty consists firstly of
A subjects.
B degrees.
C divisions.
D departments.
Questions 34–36
Complete the notes in NO MORE THAN THREE WORDS.
[Editorial transcription: the original printed instruction reads “notes m”; meaning rendered as “notes in”.]
The subjects taken in the first semester in this course are psychology, sociology,
(34) __________ and __________.
Students may have problems with
(35) __________ and
(36) __________.
```

[Original question page](assets/741539f7ef05bde7d5f0c4b2c3a3bd2eb5a00ce021bdd4e790e4d2166175b907.jpg)

<!-- Source: /api/assets/66fac6f293513c2a60dc08140e360f827492f8b50531a5ac95ae9230fa783990.jpg; PDF page 25; full -->

```text
Reading
Questions 37-41
Circle the appropriate letter.
37 The speaker says students can visit her
A every morning.
B some mornings.
C mornings only.
D Friday morning.
38 According to the speaker, a tutorial
A is a type of lecture.
B is less important than a lecture.
C provides a chance to share views.
D provides an alternative to groupwork.
39 When writing essays, the speaker advises the students to
A research their work well.
B name the books they have read.
C share work with their friends.
D avoid using other writers’ ideas.
40 The speaker thinks that plagiarism is
A a common problem.
B an acceptable risk.
C a minor concern.
D a serious offence.
41 The speaker’s aims are to
A introduce students to university expectations.
B introduce students to the members of staff.
C warn students about the difficulties of studying.
D guide students round the university.
```

[Original question page](assets/66fac6f293513c2a60dc08140e360f827492f8b50531a5ac95ae9230fa783990.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/e17946fb461edd79d2c82bb941a1913dff08453c136c84f2c05d971569823ea9.jpg; PDF page 26; full -->

```text
20
Practice Test 1
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-15 which are based on Reading
Passage 1 below
A spark, a flint: How fire leapt to life
The control of fire was the first and perhaps greatest of humanity’s steps towards a life-enhancing technology
To early man, fire was a divine gift randomly delivered in the form of lightning, forest fire or burning lava. Unable to make flame for themselves, the earliest peoples probably stored fire
by keeping slow burning logs alight or by
carrying charcoal in pots.
How and where man learnt how to produce
flame at will is unknown. It was probably a
secondary invention, accidentally made
during tool-making operations with wood or
stone. Studies of primitive societies suggest
that the earliest method of making fire was
through friction. European peasants would
insert a wooden drill in a round hole and
rotate it briskly between their palms This
process could be speeded up by wrapping a
cord around the drill and pulling on each end.
The Ancient Greeks used lenses or concave
mirrors to concentrate the sun’s rays and
burning glasses were also used by Mexican Aztecs and the Chinese.
Percussion methods of fire-lighting date back to Paleolithic times, when some Stone Age tool-makers discovered that chipping flints produced sparks. The technique became more efficient after the discovery of iron, about 5000 years
ago In Arctic North America, the Eskimos
produced a slow-burning spark by striking
quartz against iron pyrites, a compound that
contains sulphur. The Chinese lit their fires
by striking porcelain with bamboo. In
Europe, the combination of steel, flint and
tinder remained the main method of fire-
lighting until the mid 19th century.
Fire-lighting was revolutionised by the
discovery of phosphorus, isolated in 1669
by a German alchemist trying to transmute
silver into gold. Impressed by the element’s
combustibility, several 17th century chemists
used it to manufacture fire-lighting devices,
but the results were dangerously
inflammable. With phosphorus costing the
```

[Original question page](assets/e17946fb461edd79d2c82bb941a1913dff08453c136c84f2c05d971569823ea9.jpg)

<!-- Source: /api/assets/346cf93ffeb394602cac9cbec56a3216c93b7a72b54ec0be16c71ed5c270a112.jpg; PDF page 27; full -->

```text
Reading
equivalent of several hundred pounds per
ounce, the first matches were expensive.
The quest for a practical match really began
after 1781 when a group of French chemists
came up with the Phosphoric Candle  or
Ethereal Match , a sealed glass tube
containing a twist of paper tipped with
phosphorus. When the tube was broken, air
rushed in, causing the phosphorus to self-
combust. An even more hazardous device,
popular in America, was the  Instantaneous
Light Box — a bottle filled with sulphuric
acid into which splints treated with chemicals
were dipped.
The first matches resembling those used
today were made in 1827 by John Walker,
an English pharmacist who borrowed the
formula from a military rocket-maker called
Congreve. Costing a shilling a box,
Congreves were splints coated with sulphur
and tipped with potassium chlorate. To light
them, the user drew them quickly through
folded glass paper.
Walker never patented his invention, and
three years later it was copied by a Samuel
Jones, who marketed his product as Lucifers.
About the same time, a French chemistry
student called Charles Sauria produced the
first “strike-anywhere” match by substituting
white phosphorus for the potassium chlorate
in the Walker formula. However, since white
phosphorus is a deadly poison, from 1845
match-makers exposed to its fumes
succumbed to necrosis, a disease that eats
away jaw-bones. It wasn’t until 1906 that the
substance was eventually banned.
That was 62 years after a Swedish chemist
called Pasch had discovered non-toxic red
or amorphous phosphorus, a development
exploited commercially by Pasch’s
compatriot J E Lundstrom in 1885.
Lundstrom’s safety matches were safe
because the red phosphorus was non-toxic;
it was painted on to the striking surface
instead of the match tip, which contained
potassium chlorate with a relatively high
ignition temperature of 182 degrees
centigrade.
America lagged behind Europe in match
technology and safety standards. It wasn’t
until 1900 that the Diamond Match
Company bought a French patent for safety
matches — but the formula did not work
properly in the different climatic conditions
prevailing in America and it was another 11
years before scientists finally adapted the
French patent for the US.
The Americans, however, can claim several
“firsts” in match technology and marketing.
In 1892 the Diamond Match Company
pioneered book matches. The innovation
didn’t catch on until after 1896, when a
brewery had the novel idea of advertising
its product in match books. Today book
matches are the most widely used type in
the US, with 90 percent handed out free by
hotels, restaurants and others.
Other American innovations include an anti-
afterglow solution to prevent the match from
smouldering after it has been blown out; and
the waterproof match, which lights after
eight hours in water.
```

[Original question page](assets/346cf93ffeb394602cac9cbec56a3216c93b7a72b54ec0be16c71ed5c270a112.jpg)

<!-- Source: /api/assets/aaed0334972729784e53635eaf139ff96d83ae2ffcad324b45560536df001f83.jpg; PDF page 28; full -->

```text
22
Practice Test 1
Questions 1-8
Complete the summary below. Choose your answers from the box at the bottom of the page
and write them in boxes 1–8 on your answer sheet.
NB There are more words than spaces so you will not use them all You may use any of the
words more than once.
EARLY FIRE-LIGHTING METHODS
Primitive societies saw fire as a ... (Example) ... gift.    Answer heavenly
They tried to ... (1) ... burning logs or charcoal ... (2) ... that they could create
fire themselves. It is suspected that the first man-made flames were produced
by ... (3) ...
The very first fire-lighting methods involved the creation of ... (4) ... by, for
example, rapidly ... (5) ... a wooden stick in a round hole. The use of ... (6) ...
or persistent chipping was also widespread in Europe and among other peoples
such as the Chinese and ... (7) ... . European practice of this method continued
until the 1850s ... (8) ... the discovery of phosphorus some years earlier.
List of Words
Mexicans random rotating
despite preserve realising
sunlight lacking heavenly
percussion chance friction
unaware without make
heating Eskimos surprised
until smoke
```

[Original question page](assets/aaed0334972729784e53635eaf139ff96d83ae2ffcad324b45560536df001f83.jpg)

<!-- Source: /api/assets/6511ddbdf9725d35d176e785595102d1a64996f3267605c2d86d83f1a5d31dd3.jpg; PDF page 29; full -->

```text
Reading
Questions 9-15
Look at the following notes that have been made about the matches described in Reading
Passage 1. Decide which type of match (A-H) corresponds with each description and write
your answers in boxes 9–15 on your answer sheet.
NB There are more matches than descriptions so you will not use them all. You may use any
match more than once.
Example Answer
could be lit after soaking in water  H
NOTES
9 made using a less poisonous type of phosphorus
10 identical to a previous type of match
11 caused a deadly illness
12 first to look like modern matches
13 first matches used for advertising
14 relied on an airtight glass container
15 made with the help of an army design
Types of Matches
A the Ethereal Match
B the Instantaneous Lightbox
C Congreves
D Lucifers
E the first strike-anywhere match
F Lundstrom’s safety match
G book matches
H waterproof matches
```

[Original question page](assets/6511ddbdf9725d35d176e785595102d1a64996f3267605c2d86d83f1a5d31dd3.jpg)

<!-- Source: /api/assets/076934ec044cde0f846c970a8c63b7fdd6c848d61dc92f1ce888de4ec347cefd.jpg; PDF page 30; full -->

```text
24
Practice Test 1
READING PASSAGE 2
You should spend about 20 minutes on Questions 16-28 which are based on Reading Passage
2 below.
Zoo  conservation  programmes
One of London Zoo’s recent advertisements caused me some irritation, so
patently did it distort reality. Headlined “Without zoos you might as well tell
these animals to get stuffed”, it was bordered with illustrations of several
endangered species and went on to extol the myth that without zoos like
London Zoo these animals “will almost certainly disappear forever”. With
the zoo world’s rather mediocre record on conservation, one might be
forgiven for being slightly sceptical about such an advertisement.
Zoos were originally created as places of entertainment, and their suggested
involvement with conservation didn’t seriously arise until about 30 years
ago, when the Zoological Society of London held the first formal
international meeting on the subject. Eight years later, a series of world
conferences took place, entitled “The Breeding of Endangered Species”, and
from this point onwards conservation became the zoo community’s
buzzword. This commitment has now been clearh defined in The World Zpo
Conservation Strategy (WZGS, September 1993), which although an
important and welcome document does seem to be based on an unrealistic
optimism about the nature of the zoo industry
The WZCS estimates that there are about 10,000 zoos in the world, of which
around 1,000 represent a core of quality collections capable of participating
in co-ordinated conservation programmes. This is probably the document’s
first failing, as I believe that 10,000 is a serious underestimate of the total
number of places masquerading as zoological establishments. Of course it is
difficult to get accurate data but, to put the issue into perspective, I have
found that, in a year of working in Eastern Europe, I discover fresh zoos on
almost a weekly basis.
The second flaw in the reasoning of the WZCS document is the naive faith it
places in its 1,000 core zoos. One would assume that the calibre of these
institutions would have been carefully examined, but it appears that the criterion
for inclusion on this select list might merely be that the zoo is a member of a
zoo federation or association. This might be a good starting point, working on
the premise that members must meet certain standards, but again the facts don’t
support the theory. The greatly respected American Association of Zoological
Parks and Aquariums (AAZPA) has had extremely dubious members, and in
the UK the Federation of Zoological Gardens of Great Britain and Ireland has
```

[Original question page](assets/076934ec044cde0f846c970a8c63b7fdd6c848d61dc92f1ce888de4ec347cefd.jpg)

<!-- Source: /api/assets/e2542348cd896098f9a44ea5c6fc9a62e1929caa40eeea7cfe3c6275400efe14.jpg; PDF page 31; full -->

```text
Reading
occasionally had members that have been roundly censured in the national press.
These include Robin Hill Adventure Park on the Isle of Wight, which many
considered the most notorious collection of animals in the country. This
establishment, which for years was protected by the Isle’s local council (which
viewed it as a tourist amenity), was finally closed down following a damning
report by a veterinary inspector appointed under the terms of the Zoo Licensing
Act 1981. As it was always a collection of dubious repute, one is obliged to
reflect upon the standards that the Zoo Federation sets when granting
membership. The situation is even worse in developing countries where little
money is available for redevelopment and it is hard to see a way of incorporating
collections into the overall scheme of the WZCS.
Even assuming that the WZCS’s 1,000 core zoos are all of a high standard
complete with scientific staff and research facilities, trained and dedicated
keepers, accommodation that permits normal or natural behaviour, and a policy
of co-operating fully with one another  what might be the potential for
conservation? Colin Tudge, author of Last Animals at the Zoo (Oxford University
Press, 1992), argues that “if the world”s zoos worked together in co-operative
breeding programmes, then even without further expansion they could save
around 2,000 species of endangered land vertebrates’. This seems an extremely
optimistic proposition from a man who must be aware of the failings and
weaknesses of the zoo industry the man who, when a member of the council of
London Zoo, had to persuade the zoo to devote more of its activities to
conservation. Moreover, where are the facts to support such optimism?
Today approximately 16 species might be said to have been “saved” by captive
breeding programmes, although a number of these can hardly be looked upon
as resounding successes. Beyond that, about a further 20 species are being
seriously considered for zoo conservation programmes. Given that the
international conference at London Zoo was held 30 years ago, this is pretty
slow progress, and a long way off Tudge’s target of 2,000.
```

[Original question page](assets/e2542348cd896098f9a44ea5c6fc9a62e1929caa40eeea7cfe3c6275400efe14.jpg)

<!-- Source: /api/assets/4ea2e96f84f5c0542f8c6d6f0ad336918085a685d699bd071b61c8cf401c0376.jpg; PDF page 32; full -->

```text
26
Practice Test 1
Example Answer
London Zoos advertisements are poorly presented.  NOT GIVEN
Questions 16-22
Do the following statements agree with the views of the writer in Reading Passage 2?
In boxes 16-22 write
YES if the statement agrees with the writer
NO if the statement contradicts the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
16 London Zoo’s advertisements are dishonest.
17 Zoos made an insignificant contribution to conservation up until 30 years ago.
18 The WZCS document is not known in Eastern Europe.
19 Zoos in the WZCS select list were carefully inspected.
20 No-one knew how the animals were being treated at Robin Hill Adventure Park.
21 Colin Tudge was dissatisfied with the treatment of animals at London Zoo.
22 The number of successful zoo conservation programmes is unsatisfactory.
Questions 23-25
Choose the appropriate letters A-D and write them in boxes 23-25 on your answer sheet.
23 What were the objectives of the WZCS document?
A to improve the calibre of zoos world-wide
B to identify zoos suitable for conservation practice
C to provide funds for zoos in underdeveloped countries
D to list the endangered species of the world
24 Why does the writer refer to Robin Hill Adventure Park?
A  to support the Isle of Wight local council
B  to criticise the 1981 Zoo Licensing Act
C  to illustrate a weakness in the WZCS document
D  to exemplify the standards in AAZPA zoos
```

[Original question page](assets/4ea2e96f84f5c0542f8c6d6f0ad336918085a685d699bd071b61c8cf401c0376.jpg)

<!-- Source: /api/assets/22d34b02e1c27e550f55202f6b34b1ac741728a7cecb30a5444c821668dc7921.jpg; PDF page 33; full -->

```text
25 What word best describes the writer’s response to Colin Tudges’ prediction on captive
breeding programmes?
A disbelieving
B impartial
C prejudiced
D accepting
Questions 26-28
The writer mentions a number of factors which lead him to doubt the value of the WZCS
document Which THREE of the following factors are mentioned? Write your answers (A-F)
in boxes 26-28 on your answer sheet.

List of Factors
A the number of unregistered zoos in the world
B the lack of money in developing countries
C the actions of the Isle of Wight local council
D the failure of the WZCS to examine the standards of
the “core zoos”
E the unrealistic aim of the WZCS in view of  the
number of species “saved” to date
F the policies of WZCS zoo managers

```

[Original question page](assets/22d34b02e1c27e550f55202f6b34b1ac741728a7cecb30a5444c821668dc7921.jpg)

<!-- Source: /api/assets/d5a92de27de7f5cef041bd7e0be46dd73a1cf770a315bd9d8c44fa9828c8932b.jpg; PDF page 34; full -->

```text
28 Practice Test 1 READING PASSAGE 3 You should spend about 20 minutes on Questions 29-40 which are based on Reading Passage 3 below. ARCHITECTURE - Reaching for the Sky 

Architecture is the art and science of designing buildings and structures. A building reflects the scientific and technological achievements of the age as well as the ideas and aspirations of the designer and client. The appearance of individual buildings, however, is often controversial. 

The use of an architectural style cannot be said to start or finish on a specific date. Neither is it possible to say exactly what characterises a particular movement. But the origins of what is now generally known as modern architecture can be traced back to the social and technological changes of the 18th and 19th centuries. 

Instead of using timber, stone and traditional building techniques, architects began to explore ways of creating buildings by using the latest technology and materials such as steel, glass and concrete strengthened steel bars, known as reinforced concrete. Technological advances also helped bring about the decline of rural industries and an increase in urban populations as people moved to the towns to work in the new factories. Such rapid and uncontrolled growth helped to turn parts of cities into slums. 

By the 1920s architects throughout Europe were reacting against the conditions created by industrialisation. A new style of architecture emerged to reflect more idealistic notions for the future. It was made possible by new materials and construction techniques and was known as Modernism. 

By the 1930s many buildings emerging from this movement were designed in the International Style. This was largely characterised by the bold use of new materials and simple, geometric forms, often with white walls supported by stilt- like pillars. These were stripped of unnecessary decoration that would detract from their primary purpose  to be used or lived in. 

Walter Gropius, Charles Jeanneret (better known as Le Corbusier) and Ludwig Mies van der Rohe were among the most influential of the many architects who contributed to the development of Modernism in the first half of the century. But the economic depression of the 1930s and the second world war (1939-45) prevented their ideas from being widely realised until the economic conditions improved and war-torn cities had to be rebuilt. By the 1950s, the International Style had developed into a universal approach to building, which standardised the appearance of new buildings in cities across the world. 

Unfortunately, this Modernist interest in geometric simplicity and function became exploited for profit. The rediscovery of quick-and-easy-to-handle reinforced concrete and an improved ability to prefabricate building sections meant that builders could meet the budgets of commissioning authorities and handle a renewed demand for development quickly and cheaply. But this led to many badly designed buildings, which discredited the original aims of Modernism. 

Influenced by Le Corbusiers ideas on town planning, every large British city built multi-storey housing estates in the 1960s. Mass- produced, low-cost high-rises seemed to offer a solution to the problem of housing a growing inner-city population. But far from meeting human needs, the new estates often proved to be windswept deserts lacking essential social facilities and services. Many of these buildings were poorly designed and constructed and have since been demolished. 

By the 1970s, a new respect for the place of buildings within the existing townscape arose. Preserving historic buildings or keeping only their facades (or fronts) grew common. Architects also began to make more use of building styles and materials that were traditional to the area. The architectural style usually referred to as High Tech was also emerging. It
```

[Original question page](assets/d5a92de27de7f5cef041bd7e0be46dd73a1cf770a315bd9d8c44fa9828c8932b.jpg)

<!-- Source: /api/assets/a1adb3df1bad9d4202578b5e05c02d6cb50542990bc3f7aeefbbc080c9ff42a0.jpg; PDF page 35; full -->

```text
Reading celebrated scientific and engineering achievements by openly parading the sophisticated techniques used in construction. Such buildings are commonly made of metal and glass; examples are Stansted airport and the Lloyds building in London. 

Disillusionment at the failure of many of the poor imitations of Modernist architecture led to interest in various styles and ideas from the past and present. By the 1980s the coexistence of different styles of architecture in the same building became known as Post Modern. Other architects looked back to the classical tradition. The trend in architecture now favours smaller scale building design that reflects a growing public awareness of environmental issues such as energy efficiency. Like the Modernists, people today recognise that a well designed environment improves the quality of life but is not necessarily achieved by adopting one well defined style of architecture. 

Twentieth century architecture will mainly be remembered for its tall buildings. They have been made possible by the development of light steel frames and safe passenger lifts. They originated in the US over a century ago to help meet the demand for more economical use of land. As construction techniques improved, the skyscraper became a reality. Ruth Coleman

Questions 29–35
Complete the table below using information from Reading Passage 3. Write NO MORE THAN THREE WORDS for each answer. Write your answers in boxes 29–35 on your answer sheet.
PERIOD | STYLE OF PERIOD | BUILDING MATERIALS | CHARACTERISTICS
Before 18th century | traditional [Example] | (29) __________ | [shaded: no answer required]
1920s | introduction of (30) __________ | steel, glass and concrete | exploration of latest technology
1930s–1950s | (31) __________ | [shaded: no answer required] | geometric forms
1960s | decline of Modernism | pre-fabricated sections | (32) __________
1970s | end of Modernist era | traditional materials | (33) __________ of historic buildings
1970s | beginning of (34) __________ era | metal and glass | sophisticated techniques paraded
1980s | Post-Modernism | [shaded: no answer required] | (35) __________
```

[Original question page](assets/a1adb3df1bad9d4202578b5e05c02d6cb50542990bc3f7aeefbbc080c9ff42a0.jpg)

<!-- Source: /api/assets/0b8b2e3b43bbf40aeb2f9c18911a635c6ae7887885340e8646b93f759fffc854.jpg; PDF page 36; full -->

```text
30
Practice Test 1
Questions 36-40
Reading Passage 3 describes a number of cause and effect relationships. Match each Cause
(36-40) in List A, with its Effect (A-H) in List B.
Write your answers (A-H) in boxes 36–40 on your answer sheet.
NB There are more effects in List B than you will need, so you will not use all of them. You
may use any effect more than once if you wish.
List A — CAUSES
36 A rapid movement of people from
rural areas to cities is triggered by
technological advance.
37 Buildings become simple and
functional.
38 An economic depression and the
second world war hit Europe.
39 Multi-storey housing estates are
built according to contemporary
ideas on town planning.
40 Less land must be used for
building.
List B — EFFECTS
A The quality of life is improved.
B Architecture reflects the age.
C A number of these have been
knocked down.
D Light steel frames and lifts are
developed.
E Historical buildings are preserved.
F All decoration is removed.
G Parts of cities become slums.
H Modernist ideas cannot be put
into practice until the second half
of the 20th century.

```

[Original question page](assets/0b8b2e3b43bbf40aeb2f9c18911a635c6ae7887885340e8646b93f759fffc854.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/5ec58052257d36219d6877311a01b2595d01329c2e36f3d945da55e9d1e3f376.jpg; PDF page 37; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show the results of a survey of adult education. The first chart shows the reasons why adults decide to study. The pie chart shows how people think the costs of adult education should be shared.

Write a report for a university lecturer, describing the information shown below.

You should write at least 150 words.

The original figure is retained for the plotted values, labels, arrows and spatial layout.
```

[Original question page](assets/5ec58052257d36219d6877311a01b2595d01329c2e36f3d945da55e9d1e3f376.jpg)

![Original figure](assets/5ec58052257d36219d6877311a01b2595d01329c2e36f3d945da55e9d1e3f376.jpg)

### Task 2

<!-- Source: /api/assets/9c95c2169cd09fdedb6304f6f7aa1100c1d49a9e25f39b2074ffed78f76c9fa2.jpg; PDF page 38; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic:

There are many different types of music in the world today. Why do we need music? Is the traditional music of a country more important than the International music that is heard everywhere nowadays?

You should write at least 250 words.

Use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.
```

[Original question page](assets/9c95c2169cd09fdedb6304f6f7aa1100c1d49a9e25f39b2074ffed78f76c9fa2.jpg)

## 口语

### 原书口语任务

<!-- Source: /api/assets/5915855dfc57afb77088dd25ed2d20430c400f0fc5806fe4f076e43920e5aa96.png; PDF page 39; full -->

```text
SPEAKING
CANDIDATE’S CUE CARD — Task 1
UNIVERSITY CLUBS AND ASSOCIATIONS
You have just arrived at a new university. It is orientation week and you want to know about the different clubs and associations you can join.
Your examiner is a Student Union representative.
Ask the examiner about:
• types of clubs
• meeting times
• benefits
• costs
```

[Original question page](assets/5915855dfc57afb77088dd25ed2d20430c400f0fc5806fe4f076e43920e5aa96.png)
