# 剑雅 1 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 136

Answer keys — PRACTICE TEST 1 — LISTENING
Section 1
1 A
2 C
3 D
4 D
5 C
6 Prescott (must be correct spelling with capital “P”)
7 41
8 Fountain (must have capital “F”)
9 752239
10 £65
Section 2
11 E
12 F
13 H
Questions 11–13: in any order.
14 $250 million
15 roads // road system
16 too late
17 school children // boys
18 3
19 boats // pleasure craft // boats and pleasure craft
[Editorial transcription: the printed separator after “pleasure craft” resembles an extra “y”; alternative-answer separators are normalised here. Existing independently verified accepted answers are unchanged.]
20 pilot
21 (musical) instruments
Section 3
22 A
23 B
24 C
25 A
26 talk // give a talk
27 write up work
28 can choose
29 open book
30 closed reserve
31 vocational (subjects) // (preparing for) work/employment
Section 4
32 B
33 C
34 history and economics
35 (meeting) deadlines (for essays)
36 attendance
37 B
38 C
39 B
40 D
41 A

1. A

2. C

3. D

4. D

5. C

6. Prescott / PRESCOTT

7. 41

8. Fountain / FOUNTAIN

9. 752239

10. £ 65 / £65

### Part 2 · source page 136

Answer keys — PRACTICE TEST 1 — LISTENING
Section 1
1 A
2 C
3 D
4 D
5 C
6 Prescott (must be correct spelling with capital “P”)
7 41
8 Fountain (must have capital “F”)
9 752239
10 £65
Section 2
11 E
12 F
13 H
Questions 11–13: in any order.
14 $250 million
15 roads // road system
16 too late
17 school children // boys
18 3
19 boats // pleasure craft // boats and pleasure craft
[Editorial transcription: the printed separator after “pleasure craft” resembles an extra “y”; alternative-answer separators are normalised here. Existing independently verified accepted answers are unchanged.]
20 pilot
21 (musical) instruments
Section 3
22 A
23 B
24 C
25 A
26 talk // give a talk
27 write up work
28 can choose
29 open book
30 closed reserve
31 vocational (subjects) // (preparing for) work/employment
Section 4
32 B
33 C
34 history and economics
35 (meeting) deadlines (for essays)
36 attendance
37 B
38 C
39 B
40 D
41 A

11. E / F / H

12. E / F / H

13. E / F / H

14. $ 250 million / $250 million

15. roads / road system

16. too late

17. school children / boys

18. 3

19. boats / pleasure craft / boats and pleasure craft

20. pilot

21. instruments / musical instruments

### Part 3 · source page 136

Answer keys — PRACTICE TEST 1 — LISTENING
Section 1
1 A
2 C
3 D
4 D
5 C
6 Prescott (must be correct spelling with capital “P”)
7 41
8 Fountain (must have capital “F”)
9 752239
10 £65
Section 2
11 E
12 F
13 H
Questions 11–13: in any order.
14 $250 million
15 roads // road system
16 too late
17 school children // boys
18 3
19 boats // pleasure craft // boats and pleasure craft
[Editorial transcription: the printed separator after “pleasure craft” resembles an extra “y”; alternative-answer separators are normalised here. Existing independently verified accepted answers are unchanged.]
20 pilot
21 (musical) instruments
Section 3
22 A
23 B
24 C
25 A
26 talk // give a talk
27 write up work
28 can choose
29 open book
30 closed reserve
31 vocational (subjects) // (preparing for) work/employment
Section 4
32 B
33 C
34 history and economics
35 (meeting) deadlines (for essays)
36 attendance
37 B
38 C
39 B
40 D
41 A

22. A

23. B

24. C

25. A

26. talk / give a talk

27. write up work

28. can choose

29. open book

30. closed reserve

31. vocational / vocational subjects / work / preparing for work / employment / preparing for employment

### Part 4 · source page 136

Answer keys — PRACTICE TEST 1 — LISTENING
Section 1
1 A
2 C
3 D
4 D
5 C
6 Prescott (must be correct spelling with capital “P”)
7 41
8 Fountain (must have capital “F”)
9 752239
10 £65
Section 2
11 E
12 F
13 H
Questions 11–13: in any order.
14 $250 million
15 roads // road system
16 too late
17 school children // boys
18 3
19 boats // pleasure craft // boats and pleasure craft
[Editorial transcription: the printed separator after “pleasure craft” resembles an extra “y”; alternative-answer separators are normalised here. Existing independently verified accepted answers are unchanged.]
20 pilot
21 (musical) instruments
Section 3
22 A
23 B
24 C
25 A
26 talk // give a talk
27 write up work
28 can choose
29 open book
30 closed reserve
31 vocational (subjects) // (preparing for) work/employment
Section 4
32 B
33 C
34 history and economics
35 (meeting) deadlines (for essays)
36 attendance
37 B
38 C
39 B
40 D
41 A

32. B

33. C

34. history economics / history, economics / history and economics / history & economics / history; economics / history/economics / history,economics / economics history / economics, history / economics and history / economics & history / economics; history / economics/history / economics,history

35. deadlines / deadlines for essays / meeting deadlines / meeting deadlines for essays

36. attendance

37. B

38. C

39. B

40. D

41. A

## A 类阅读

### Academic Reading · source page 137

131
Answer keys
PRACTICE TEST 1
READING
READING PASSAGE 1 A spark, a flint: How fire leapt to life
Questions 1-8
Questions 9-15
Suggested approach
• Read the task rubric carefully. In this task you
have to decide which match is being described
in each question.
• Decide what information is best to skim for in
the passage: the type of match or the
description. In this question it is best to skim
for the types of match as these are names, some
of which are in italics, they are easier for you to
pick out.
• Skim through the text until you find match A,
the Ethereal Match.
• Read that section of the text and underline any
important features of this match.
• Read through the descriptions and write A next
to any that fit this type of match.
   If you think there is more than one possible
description for the match, note A next to both.
(The rubric states that you may use any match
more than once. )
• Towards the top of the second page of the text
it states that the Ethereal Match consisted of a
“sealed glass tube”, so A is the answer to
question 14. Note that the description is
expressed differently from the text. Sometimes
you have to match the meaning rather than the
words.
• If you think none of the descriptions fits this
type of match, go on to the next the rubric also
states that there are not enough descriptions to
fit all the matches.
Questions Task Skills tested
1-8 Gap fill summary • skimming for information
• detailed understanding of a section of text
• ability to paraphrase/re-word original text
9-15 Matching (items to
descriptions)
• skimming for specific information
• understanding description/characteristics
• understanding paraphrase


Question | Answer | Location of answer in text (where supplied)
1 | preserve
2 | unaware
3 | chance
4 | friction
5 | rotating
6 | percussion
7 | Eskimos
8 | despite
9 | F | “… the red phosphorus was non toxic”
10 | D | “… three years later it was copied …”
11 | E | “… since white phosphorus is a deadly poison …”
12 | C | “The first matches resembling those used today …”
13 | G | “… a brewery had the novel idea of advertising …”
14 | A | “… a sealed glass tube …”
15 | C | “… borrowed the formula from a military rocket-maker …”

### Academic Reading · source page 138

Practice Test 1
READING PASSAGE 2 Zoo conservation programmes
Questions 16-25
Questions 26-28
Suggested approach
• Read the task rubric carefully. Only three of the
factors in the list are correct. The correct
factors explain why the author doubts the value
of the WZCS document.
• Scan the text and mark the section that
discusses the accuracy/value of theWZCS
document. This is from the third paragraph
onwards.
• Read through the list of factors to familiarise
yourself with it.
• Begin reading the third paragraph more
carefully, looking for phrases that signal that
the writer is going to discuss something that is
wrong with the document. The first signal is:
'This is probably the document's first failing …'
You can infer from what the writer
   then states, that A is one of the correct factors.
• Re-read the list of factors from B-F.
• Continue reading the text, looking for other
signals.
• Select the two other correct factors.
Remember that if you put more than one factor
beside each question number on your answer
sheet, you will not get any marks. However the
three correct answers can be written down in
any order.









 in
any
order
Questions Task Skills tested
16-22 Yes, No, Not Given • skimming for detailed information
• identifying attitude and opinion
• understanding gist and paraphrase
23-25 Multiple choice • skimming for factual information
• identifying main and supporting points
• understanding attitude
26-28 Selecting factors • skimming/scanning for specific information
• identifying main ideas
• understanding paraphrase and inference

Question | Answer
16 | YES
17 | YES
18 | NOT GIVEN
19 | NO
20 | NO
21 | NOT GIVEN
22 | YES
23 | B
24 | C
25 | A
Questions26–28: A,D,E in any order.
26 | A | “…10,000 is a serious underestimate of the total number of places masquerading as zoological establishments.”
27 | D | “One would assume that the calibre of these institutions would have been carefully examined but …”
28 | E | The last two paragraphs, especially the passage beginning “Today approximately16species…” and ending “…resounding successes.”

### Academic Reading · source page 139

133
Answer keys
READING PASSAGE 3 Architecture
Questions 29-35
Questions 36-40
Suggested approach
• Read the task rubric carefully. You have to
decide which effect arose from each cause.
• Decide which list you should work from. In
this case it is better to work from List A as you
must find an effect in List B for every question.
The causes also come first chronologically in
the cause/effect relationship: List B contains
results of List A.
• Read through List B to familiarise yourself
with it.
• Read item 36.
• Skim through the passage until you locate the
information in the text.
• Read this section of the text in detail noting any
effects of 36.
• Read through List B again.
• Select the effect of question 36. If you think
there is more than one effect, mark both and
come back to this item later. But remember that
only one answer is correct.
• In the third paragraph it states that the
increase in urban populations “helped to turn
parts of cities into slums”. So the answer to
question 36 is G.
• Repeat this procedure with items 37-40.
Questions Task Skills tested
29-35 Completing a table • following a chronological account
• skimming for specific information
• noting main ideas
36-40 Matching (causes to
effects)
• skimming/scanning for information
• understanding cause and effect relationships
• understanding paraphrase

Question | Answer
29 | timber and stone
30 | Modernism
31 | International style
32 | badly designed buildings // multi-storey housing // mass-produced, low-cost high-rises
33 | preservation
34 | High-Tech
35 | co-existence of styles // different styles together // styles mixed
Question | Answer | Location of answer in text
36 | G | “Such rapid and uncontrolled growth helped to turn parts of cities into slums.”
37 | F | “These were stripped of unnecessary decoration that would detract from their primary purpose — to be used or lived in.”
38 | H | “But the economic depression prevented their ideas from being widely realised until the economic conditions improved …”
39 | C | “Many of these buildings … have since been demolished.”
40 | D | “They originated in the US … to help meet the demand for more economical use of land.”

1. preserve

2. unaware

3. chance

4. friction

5. rotating

6. percussion

7. Eskimos

8. despite

9. F

10. D

11. E

12. C

13. G

14. A

15. C

16. YES

17. YES

18. NOT GIVEN

19. NO

20. NO

21. NOT GIVEN

22. YES

23. B

24. C

25. A

26. A / D / E

27. A / D / E

28. A / D / E

29. timber stone / timber, stone / timber and stone / timber & stone / timber; stone / timber/stone / timber,stone / stone timber / stone, timber / stone and timber / stone & timber / stone; timber / stone/timber / stone,timber

30. Modernism

31. International style

32. badly designed buildings / multi-storey housing / mass-produced, low-cost high-rises

33. preservation

34. High-Tech

35. co-existence of styles / different styles together / styles mixed

36. G

37. F

38. H

39. C

40. D

## A 类写作

### Writing material: c1-t1-w-1

Original bar chart and pie chart inspected. No survey year or country is specified. Reasons for study, percentages: interest in subject 40%; to gain qualifications 38%; helpful for current job 22%; to improve prospects of promotion 20%; enjoy learning/studying 20%; to be able to change jobs 12%; to meet people 9%. These reason percentages are separate responses, not slices of one pie: do not require their sum to be 100%. Cost-sharing pie: individual 40%, employer 35%, taxpayer 25%, together 100%. Subject interest and qualifications are the largest reported reasons; meeting people is the least common. Individuals are allocated the largest cost share, followed by employers and taxpayers.



### Writing material: c1-t1-w-2

Two explicit questions: why music is needed, and the comparative importance of traditional music and international music. Different well-supported positions are permissible.



## 口语

### 原书口语任务 · reference on source page 39

INTERVIEWER’S NOTES
UNIVERSITY CLUBS AND ASSOCIATIONS
Prompts for interviewer
Overseas Students Club
• Meets once a week in Student Centre, near Library — All welcome
• Helps you to meet other students
• Financial contributions welcome
Chess Club
• Meets once a week in Library — Not suitable for beginners
• Plays other universities — Serious players only
• No subscription
Table Tennis Club
• Meets every day at lunch-time in student area near canteen — All welcome
• Arranges tournaments
• $5.00 subscription

[Complete original page](assets/882a0ea859632f0d7bf1ae57cbba5c5b1df5b87604666224041d0c27efe4e518.jpg)
