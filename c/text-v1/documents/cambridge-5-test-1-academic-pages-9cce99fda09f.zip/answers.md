# 剑雅 5 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 153

TEST1 LISTENING
Section1, Questions1–10
1 by minibus / a minibus
2 15 /15people
3 April(the)18th
4 Pallisades
5–6 IN EITHER ORDER: B;D
7 280
8 14
9 20%
10 39745T
Section2, Questions11–20
11 move around / move about
12 brakes
13 fingers
14 satisfactory
15 put(it)together
16 too wide
17 dangerous
18 wheels
19 (the)best / (the)best buy / safe
20 sharp
Section3, Questions21–30
21 B
22 A
23 C
24–25 IN EITHER ORDER: B;D
26 full-time
27 a term / one term
28 intensive
29 two modules / (for)two terms
30 a topic / one topic
Section4, Questions31–40
31 politics
32 learn
33 children’s education / their children’s education
34 a car
35 nursing care
36 crisis
37 early twenties
38 confidence
39 money management
40 low-risk investments
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. by minibus / a minibus

2. 15 / 15 people

3. April 18th / April the 18th

4. Pallisades

5. B / D

6. B / D

7. 280

8. 14

9. 20 per cent / 20 percent / 20%

10. 39745T

### Part 2 · source page 153

TEST1 LISTENING
Section1, Questions1–10
1 by minibus / a minibus
2 15 /15people
3 April(the)18th
4 Pallisades
5–6 IN EITHER ORDER: B;D
7 280
8 14
9 20%
10 39745T
Section2, Questions11–20
11 move around / move about
12 brakes
13 fingers
14 satisfactory
15 put(it)together
16 too wide
17 dangerous
18 wheels
19 (the)best / (the)best buy / safe
20 sharp
Section3, Questions21–30
21 B
22 A
23 C
24–25 IN EITHER ORDER: B;D
26 full-time
27 a term / one term
28 intensive
29 two modules / (for)two terms
30 a topic / one topic
Section4, Questions31–40
31 politics
32 learn
33 children’s education / their children’s education
34 a car
35 nursing care
36 crisis
37 early twenties
38 confidence
39 money management
40 low-risk investments
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. move around / move about

12. brakes

13. fingers

14. satisfactory

15. put together / put it together

16. too wide

17. dangerous

18. wheels

19. best / the best / best buy / the best buy / safe

20. sharp

### Part 3 · source page 153

TEST1 LISTENING
Section1, Questions1–10
1 by minibus / a minibus
2 15 /15people
3 April(the)18th
4 Pallisades
5–6 IN EITHER ORDER: B;D
7 280
8 14
9 20%
10 39745T
Section2, Questions11–20
11 move around / move about
12 brakes
13 fingers
14 satisfactory
15 put(it)together
16 too wide
17 dangerous
18 wheels
19 (the)best / (the)best buy / safe
20 sharp
Section3, Questions21–30
21 B
22 A
23 C
24–25 IN EITHER ORDER: B;D
26 full-time
27 a term / one term
28 intensive
29 two modules / (for)two terms
30 a topic / one topic
Section4, Questions31–40
31 politics
32 learn
33 children’s education / their children’s education
34 a car
35 nursing care
36 crisis
37 early twenties
38 confidence
39 money management
40 low-risk investments
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. B

22. A

23. C

24. B / D

25. B / D

26. full-time

27. a term / one term

28. intensive

29. two modules / two terms / for two terms

30. a topic / one topic

### Part 4 · source page 153

TEST1 LISTENING
Section1, Questions1–10
1 by minibus / a minibus
2 15 /15people
3 April(the)18th
4 Pallisades
5–6 IN EITHER ORDER: B;D
7 280
8 14
9 20%
10 39745T
Section2, Questions11–20
11 move around / move about
12 brakes
13 fingers
14 satisfactory
15 put(it)together
16 too wide
17 dangerous
18 wheels
19 (the)best / (the)best buy / safe
20 sharp
Section3, Questions21–30
21 B
22 A
23 C
24–25 IN EITHER ORDER: B;D
26 full-time
27 a term / one term
28 intensive
29 two modules / (for)two terms
30 a topic / one topic
Section4, Questions31–40
31 politics
32 learn
33 children’s education / their children’s education
34 a car
35 nursing care
36 crisis
37 early twenties
38 confidence
39 money management
40 low-risk investments
If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. politics

32. learn

33. children's education / their children's education

34. a car

35. nursing care

36. crisis

37. early twenties

38. confidence

39. money management

40. low-risk investments

## A 类阅读

### Academic Reading · source page 154

ACADEMIC READING
Reading Passage1, Questions1–13
1–3 IN ANY ORDER: D;E;G
4 clerks / copying clerks
5 library
6 stability
7 pension
8 TRUE
9 FALSE
10 NOT GIVEN
11 FALSE
12 FALSE
13 TRUE
Reading Passage2, Questions14–26
14 F
15 A
16 B
17 D
18 I
19 C
20 B
21 D
22 C
23 NOT GIVEN
24 TRUE
25 FALSE
26 FALSE
Reading Passage3, Questions27–40
27 YES
28 NOT GIVEN
29 NO
30 NOT GIVEN
31 YES
32 NO
33 C
34 D
35 C
36 B
37 B
38 E
39 D
40 I
If you score… (original source guidance, not a new scoring rule)
0–11: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. D / E / G

2. D / E / G

3. D / E / G

4. clerks / copying clerks

5. library

6. stability

7. pension

8. TRUE

9. FALSE

10. NOT GIVEN

11. FALSE

12. FALSE

13. TRUE

14. F

15. A

16. B

17. D

18. I

19. C

20. B

21. D

22. C

23. NOT GIVEN

24. TRUE

25. FALSE

26. FALSE

27. YES

28. NOT GIVEN

29. NO

30. NOT GIVEN

31. YES

32. NO

33. C

34. D

35. C

36. B

37. B

38. E

39. D

40. I

## A 类写作

### Writing material: c5-t1-w-1

Original full-page line graph and the separate structured paper's cropped graph inspected; both show the same three series. Units percentages of population aged 65 and over, years 1940–2040. Legend: thin solid Japan, dashed Sweden, thick solid USA. Approximate starting percentages in 1940: Japan 5%, Sweden 7%, USA 9%. By about 1960 Japan falls to 3%, while Sweden reaches around 9% and the US 10%. Japan stays near 3% for decades, rises to about 5% around 2010 and 10% around 2030, then climbs very sharply to roughly 25% in the mid-2030s and 27% in 2040. The US rises to about 15% around 1980, slips slightly to about 14%, remains fairly level until around 2020, then increases to about 23% by 2040. Sweden reaches roughly 14% in 1980, dips slightly, rises to about 20% around 2010–2020, declines to around 18% around 2030, and reaches about 25% by 2040. All finish above their starts; Japan is lowest for most of the period but is projected to finish highest, with Sweden second and the US third. The late figures are projections; no explicit dividing year between observed and projected data is supplied in the prompt. Do not invent a forecasting boundary or report these as absolute population counts. All plotted readings are approximate.



### Writing material: c5-t1-w-2

The claim concerns equal numbers in EVERY SUBJECT, not merely equal overall university admission or equal opportunity. Address this scope and justify a position; agreement or disagreement is valid.



## 口语
