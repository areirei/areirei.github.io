# 剑雅 5 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/1ed317c5798bf1fcaf523cfa94982c475b413f42772919b528498ecc1b46afa7.jpg; PDF page 11; full -->

```text
LISTENING SECTION1 Questions1–10
Questions1–6: Complete the notes below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
Dreamtime travel agency—Tour information
Example: Holiday name—Whale Watch Experience
Holiday length:2days
Type of transportation:(1) __________
Maximum group size:(2) __________
Next tour date:(3) __________
Hotel name:(4) The __________
```

[Original question page](assets/1ed317c5798bf1fcaf523cfa94982c475b413f42772919b528498ecc1b46afa7.jpg)

<!-- Source: /api/assets/ab23af71bf9fdbf4c5cb53e09eaea502adcdc5efdc3586ec297e685470e92811.jpg; PDF page 12; full -->

```text
Questions 5 and 6 
Choose TWO letters A-E. 
Which TWO things are included in the price of the tour? 
A fishing trip 
B guided bushwalk 
C reptile park entry 
D table tennis 
E tennis 
Questions 7-10 
Complete the sentences below . 
Listening 
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer. 
7 The tour costs $ ......... ............... . 
8 Bookings must be made no later than ........................ days in advance. 
9 A ........................ deposit is required. 
10 The customer's reference number is ........................ . 
11
```

[Original question page](assets/ab23af71bf9fdbf4c5cb53e09eaea502adcdc5efdc3586ec297e685470e92811.jpg)

### Part 2

<!-- Source: /api/assets/e97d4e3edcd4635ebd29570ac859a936815eb4d69843c886cdb0c2e2779f4b68.jpg; PDF page 13; full -->

```text
SECTION2 Questions11–20
Questions11–19: Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
Brand of Cot | Good Points | Problems | Verdict
Baby Safe |Easy to (11) __________|Did not have any (12) __________;Babies could trap their (13) __________ in the side bar|(14) __________
Choice Cots |Easy to (15) __________|Side did not drop down;Spaces between the bars were (16) __________|(17) __________
Mother’s Choice |Base of cot could be moved|Did not have any (18) __________;Pictures could be removed easily|(19) __________
Question20: Complete the notes below. Write ONE WORD ONLY for the answer.
• Metal should not be rusted or bent
• Edges of cot should not be (20) __________
```

[Original question page](assets/e97d4e3edcd4635ebd29570ac859a936815eb4d69843c886cdb0c2e2779f4b68.jpg)

### Part 3

<!-- Source: /api/assets/537a8882f30d88ed9582c5b8998fa5c97db7f3ae0d724465bf4ad5dbe4409e6f.jpg; PDF page 14; full -->

```text
Listening 
SECTION 3 Questions 21-30 
Questions 21-23 
Choose the correct letter. A, B or C 
21 Andrew has worked at the hospital for 
A two years. 
B three years. 
C five years. 
22 During the course Andrew's employers will pay 
A his fees. 
B his living costs. 
C his salary. 
23 The part-time course lasts for . 
A one whole year. 
B 18 months. 
C two years. 
Questions 24 and 25 
Choose TWO letters A-E. 
What TWO types of coursework are required each month on the part-time course? 
A a case study 
B an essay 
C a survey 
D a short report 
E a study diary 
13
```

[Original question page](assets/537a8882f30d88ed9582c5b8998fa5c97db7f3ae0d724465bf4ad5dbe4409e6f.jpg)

<!-- Source: /api/assets/0f308afbbfc3bfa6c14a2863cdff8a17aae0d822318f3384383e7268383498c8.jpg; PDF page 15; full -->

```text
Test 1 
Questions 26-30 
Complete the summary below. 
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer. 
Modular Courses 
Students study 26 ........................ during each module. A module takes 
27 ........................ and the work is very 28 ......... : ............... To get a Diploma each 
student has to study 29 ........................ and then work on 30 ....................... . 
in depth . 
14
```

[Original question page](assets/0f308afbbfc3bfa6c14a2863cdff8a17aae0d822318f3384383e7268383498c8.jpg)

### Part 4

<!-- Source: /api/assets/e8a77eb6448cae97c7675d16f4b4d6d2a88af1ea2fb1f20f4e009dd8281ffa23.jpg; PDF page 16; full -->

```text
Listening 
SECTION 4 Questions 31-40 
Questions 31-35 
Complete the sentences below. 
Write NO MORE THAN THREE WORDS for each answer. 
31 According to George Bernard Shaw, men are supposed to understand ..................... ... , 
economics and finance . 
32 However, women are more prepared to ..... ................... about them. 
33 Women tend to save for ....................... . and a house. 
34 Men tend to save for ........................ and for retirement. 
35 Women who are left alone may have to pay for ........................ when they are old. 
Questions 36-40 
Complete the summary below. 
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer. 
Saving for the future
Research indicates that many women only think about their financial future when a (36) __________ occurs.This is the worst time to make decisions.It is best for women to start thinking about pensions when they are in their (37) __________.A good way for women to develop their (38) __________ in dealing with financial affairs would be to attend classes in (39) __________.When investing in stocks and shares,it is suggested that women should put a high proportion of their savings in (40) __________.In such ways,women can have a comfortable,independent retirement.
```

[Original question page](assets/e8a77eb6448cae97c7675d16f4b4d6d2a88af1ea2fb1f20f4e009dd8281ffa23.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/fd66390da2f76085669f4008ac8e0cd9714b6e41aafd4556aeacf96463e69b3d.jpg; PDF page 17; full -->

```text
Test 1



READING



READING PASSAGE 1



You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage 1



below.



Johnson’s Dictionary



For the century before Johnson's

Dictionary was published in 1775, there

had been concern about the state of the

English language. There was no standard

way of speaking or writing and no

agreement as to the best way of bringing

some order to the chaos of English

spelling. Dr Johnson provided the solution.



There had, of course, been dictionaries in

the past, the first of these being a little

book of some 120 pages, compiled by a

certain Robert Cawdray, published in 1604

under the title A Table Alphabeticall ‘of hard

usuall English wordes’. Like the various

dictionaries that came after it during the

seventeenth century, Cawdray's tended to

concentrate on ‘scholarly’ words; one

function of the dictionary was to enable its

student to convey an impression of fine

learning.



Beyond the practical need to make order

out of chaos, the rise of dictionaries is

associated with the rise of the English

middle class, who were anxious to define

and circumscribe the various worlds to

conquer - lexical as well as social and

commercial. It is highly appropriate that

Dr Samuel Johnson, the very model of an

eighteenth-century literary man, as famous

in his own time as in ours, should have



16







published his Dictionary at the very

beginning of the heyday of the middle

class.



Johnson was a poet and critic who raised

common sense to the heights of genius.

His approach to the problems that had

worried writers throughout the late

seventeenth and early eighteenth centuries

was intensely practical. Up until his time,

the task of producing a dictionary on such

a large scale had seemed impossible

without the establishment of an academy

to make decisions about right and wrong

usage. Johnson decided he did not need

an academy to settle arguments about

language; he would write a dictionary

himself; and he would do it single-handed.

Johnson signed the contract for the

Dictionary with the bookseller Robert

Dosley at a breakfast held at the Golden

Anchor Inn near Holborn Bar on 18 June

1764. He was to be paid £1,575 in

instalments, and from this he took money

to rent 17 Gough Square, in which he set

up his ‘dictionary workshop’.



James Boswell, his biographer, described

the garret where Johnson worked as ‘fitted

up like a counting house’ with a long desk

running down the middle at which the

copying clerks would work standing up.
```

[Original question page](assets/fd66390da2f76085669f4008ac8e0cd9714b6e41aafd4556aeacf96463e69b3d.jpg)

<!-- Source: /api/assets/7ef768cf3e48fb3f4a8bcebeabf5d76edaf1de621a4478d5e616835500f3675a.jpg; PDF page 18; full -->

```text
Johnson himself was stationed on a rickety

chair at an ‘old crazy deal table’

surrounded by a chaos of borrowed

books, He was also helped by six

assistants, two of whom died whilst the

Dictionary was still in preparation,



The work was immense; filling about eighty

large notebooks (and without a library to

hand), Johnson wrote the definitions of

over 40,000 words, and illustrated their

many meanings with some 114,000

quotations drawn from English writing on

every subject, from the Elizabethans to his

own time. He did not expect to achieve

complete originality. Working to a deadline,

he had to draw on the best of all previous

dictionaries, and to make his work one of

heroic synthesis. In fact, it was very much

more. Unlike his predecessors, Johnson

treated English very practically, as a living

language, with many different shades of

meaning, He adopted his definitions on the

principle of English common law —

according to precedent. After its

publication, his Dictionary was not seriously

rivalled for over a century.



After many vicissitudes the Dictionary was

finally published on 15 April 1775. It was

instantly recognised as a landmark

throughout Europe. This very noble work;

wrote the leading Italian lexicographer, ‘will

be a perpetual monument of Fame to the



Reading



Author, an Honour to his own Country in

particular, and a general Benefit to the

republic of Letters throughout Europe.

The fact that Johnson had taken on the

Academies of Europe and matched them

(everyone knew that forty French

academics had taken forty years to

produce the first French national

dictionary) was cause for much English

celebration.



Johnson had worked for nine years, ‘with

little assistance of the learned, and without

any patronage of the great; not in the soft

obscurities of retirement, or under the

shelter of academic bowers, but amidst

inconvenience and distraction, in sickness

and in sorrow’. For all its faults and

eccentricities his two-volume work is a

masterpiece and a landmark, in his own

words, ‘setting the orthography, displaying

the analogy, regulating the structures, and

ascertaining the significations of English

words’. It is the cornerstone of Standard

English, an achievement which, in James

Boswell’s words, ‘conferred stability on the

language of his country’.



The Dictionary, together with his other

writing, made Johnson famous and so well

esteemed that his friends were able to

prevail upon King George III to offer him a

pension. From then on, he was to become

the Johnson of folklore.



17
```

[Original question page](assets/7ef768cf3e48fb3f4a8bcebeabf5d76edaf1de621a4478d5e616835500f3675a.jpg)

<!-- Source: /api/assets/8fd27fd21bc321595cfe7471731efb9c273bfcd062b496155df366b52697f40c.jpg; PDF page 19; full -->

```text
Test 1 
Questions 1-3 
Choose THREE letters A-H. 
Write your answers in boxes 1-3 on your answer sheet. 
NB Your answers may be given in any order. 
Which THREE of the following statements are true of Johnson's Dictionary? 
A It avoided all scholarly words. 
B It was the only English dictionary in general use for 200 years. 
C It was famous because of the large number of people involved. 
D It focused mainly on language from contemporary texts. 
E There was a time limit for its completion. 
F It ignored work done by previous dictionary writers. 
G It took into account subtleties of meaning . 
H Its definitions were famous for their originality. 
Questions 4-7 
Complete the summary. 
Choose NO MORE THAN TWO WORDS from the passage for each answer. 
Write your answers in boxes 4-7 on your answer sheet. 
18 
In 1764 Dr Johnson accepted the contract to produce a dictionary. Having rented a 
garret, he took on a number of 4 .................. ...... , who stood at a long central desk. 
Johnson did not have a 5 .................... .... available to him, but eventually produced 
definitions of in excess of 40,000 words written down in 80 large notebooks. On 
publication, the Dictionary was immediately hailed in many European countries as a 
landmark. According to his biographer. James Boswell, Johnson's principal 
achievement was to bring 6 ................. ....... to the English language. As a reward for his 
hard work, he was granted a 7 ............... ......... by the king.
```

[Original question page](assets/8fd27fd21bc321595cfe7471731efb9c273bfcd062b496155df366b52697f40c.jpg)

<!-- Source: /api/assets/229cb6efd1a0927fcd5e2b0b7a61066f1dac3425858d9f76f9c0f6890e99c377.jpg; PDF page 20; full -->

```text
Questions 8-13 
Do the following statements agree with the information given in Reading Passage 1? 
In boxes 8- 13 on your answer sheet, write 
TRUE 
FALSE 
NOT GIVEN 
if the statement agrees with the information 
if the statement contradicts the information 
if there is no information on this 
8 The growing importance of the middle classes led to an increased demand for 
dictionaries. 
9 Johnson has become more well known since his death . 
10 Johnson had been planning to write a dictionary for several years. 
11 Johnson set up an academy to help with the writing of his Dictionary. 
12 Johnson only received payment for his Dictionary on its completion . 
13 Not all of the assistants survived to see the publication of the Dictionary. 
Reading 
19
```

[Original question page](assets/229cb6efd1a0927fcd5e2b0b7a61066f1dac3425858d9f76f9c0f6890e99c377.jpg)

<!-- Source: /api/assets/f0bfc7b7e67c07c86436921b71166f239e9de8644351d3bb670bdcfe19d602db.jpg; PDF page 21; full -->

```text
Test 1



READING PASSAGE 2



You should spend about 20 minutes on Questions 14-26, which are based on Reading Passage 2

below.



20



Nature or Nurture?



A A few years ago, in one of the most fascinating and disturbing experiments in behavioural

psychology, Stanley Milgram of Yale University tested 40 subjects from all walks of life for

their willingness to obey instructions given by a ‘leader’ in a situation in which the subjects

might feel a personal distaste for the actions they were called upon to perform. Specifically,

Milgram told each volunteer ‘teacher-subject’ that the experiment was in the noble cause of

education, and was designed to test whether or not punishing pupils for their mistakes

would have a positive effect on the pupils’ ability to learn.



B Milgram's experimental set-up involved placing the teacher-subject before a panel of thirty

switches with labels ranging from ‘15 volts of electricity (slight shock)’ to ‘450 volts

(danger - severe shock)’ in steps of 15 volts each. The teacher-subject was told that

whenever the pupil gave the wrong answer to a question, a shock was to be administered,

beginning at the lowest level and increasing in severity with each successive wrong

answer. The supposed ‘pupil’ was in reality an actor hired by Milgram to simulate receiving

the shocks by emitting a spectrum of groans, screams and writhings together with an

assortment of statements and expletives denouncing both the experiment and the

experimenter. Milgram told the teacher-subject to ignore the reactions of the pupil, and to

administer whatever level of shock was called for, as per the rule governing the

experimental situation of the moment.



C As the experiment unfolded, the pupil would deliberately give the wrong answers to

questions posed by the teacher, thereby bringing on various electrical punishments, even

up to the danger level of 300 volts and beyond. Many of the teacher-subjects balked at

administering the higher levels of punishment, and turned to Milgram with questioning

looks and/or complaints about continuing the experiment. In these situations, Milgram

calmly explained that the teacher-subject was to ignore the pupil's cries for mercy and

carry on with the experiment. If the subject was still reluctant to proceed, Milgram said that

it was important for the sake of the experiment that the procedure be followed through to

the end. His final argument was, ‘You have no other choice. You must go on.’ What Milgram

was trying to discover was the number of teacher-subjects who would be willing to

administer the highest levels of shock, even in the face of strong personal and moral

revulsion against the rules and conditions of the experiment.



D Prior to carrying out the experiment, Milgram explained his idea to a group of



39 psychiatrists and asked them to predict the average percentage of people in an

ordinary population who would be willing to administer the highest shock level of 450 volts.

The overwhelming consensus was that virtually all the teacher-subjects would refuse to

obey the experimenter. The psychiatrists felt that ‘most subjects would not go beyond



150 volts’ and they further anticipated that only four per cent would go up to 300 volts.
```

[Original question page](assets/f0bfc7b7e67c07c86436921b71166f239e9de8644351d3bb670bdcfe19d602db.jpg)

<!-- Source: /api/assets/c3bed709b0d18662c67d469c6e09d231b46ecdf00ec39a29b75b937d12aa8d1d.jpg; PDF page 22; full -->

```text
Reading



Furthermore, they thought that only a lunatic fringe of about one in 1,000 would give the

highest shock of 450 volts.



E What were the actual results? Well, over 60 per cent of the teacher-subjects continued to

obey Milgram up to the 450-volt limit! In repetitions of the experiment in other countries, the

percentage of obedient teacher-subjects was even higher, reaching 85 per cent in one

country. How can we possibly account for this vast discrepancy between what calm,

rational, knowledgeable people predict in the comfort of their study and what pressured,

flustered, but cooperative ‘teachers’ actually do in the laboratory of real life?



F One's first inclination might be to argue that there must be some sort of built-in animal

aggression instinct that was activated by the experiment, and that Milgram's teacher-

subjects were just following a genetic need to discharge this pent-up primal urge onto the

pupil by administering the electrical shock. A modern hard-core sociobiologist might even

go so far as to claim that this aggressive instinct evolved as an advantageous trait, having

been of survival value to our ancestors in their struggle against the hardships of life on the

plains and in the caves, ultimately finding its way into our genetic make-up as a remnant of

our ancient animal ways.



G An alternative to this notion of genetic programming is to see the teacher-subjects’ actions

as a result of the social environment under which the experiment was carried out. As

Milgram himself pointed out, ‘Most subjects in the experiment see their behaviour in a

larger context that is benevolent and useful to society - the pursuit of scientific truth. The

psychological laboratory has a strong claim to legitimacy and evokes trust and confidence

in those who perform there. An action such as shocking a victim, which in isolation appears

evil, acquires a completely different meaning when placed in this setting.’



H Thus, in this explanation the subject merges his unique personality and personal and moral

code with that of larger institutional structures, surrendering individual properties like

loyalty, self-sacrifice and discipline to the service of malevolent systems of authority.



I Here we have two radically different explanations for why so many teacher-subjects were

willing to forgo their sense of personal responsibility for the sake of an institutional authority

figure. The problem for biologists, psychologists and anthropologists is to sort out which of

these two polar explanations is more plausible. This, in essence, is the problem of modern

sociobiology - to discover the degree to which hard-wired genetic programming dictates,

or at least strongly biases, the interaction of animals and humans with their environment,

that is, their behaviour. Put another way, sociobiology is concerned with elucidating the

biological basis of all behaviour.



21
```

[Original question page](assets/c3bed709b0d18662c67d469c6e09d231b46ecdf00ec39a29b75b937d12aa8d1d.jpg)

<!-- Source: /api/assets/f62b84e659059370d6f31097218ca95cb477e1ebd7c2bbdda1d3cae488b28bf8.jpg; PDF page 23; full -->

```text
Test 1 
Questions 14-19 
Reading Passage 2 has nine paragraphs, A–I. 
Which paragraph contains the following information? 
Write the correct letter A–I in boxes 14-19 on your answer sheet. 
14 a biological explanation of the teacher-subjects' behaviour 
15 the explanation Milgram gave the teacher-subjects for the experiment 
16 the identity of the pupils 
17 the expected statistical outcome 
18 the general aim of sociobiological study 
19 the way Milgram persuaded the teacher-subjects to continue 
Questions 20-22 
Choose the correct letter. A, B. C or D. 
Write your answers in boxes 20-22 on your answer sheet. 
20 The teacher-subjects were told that they were testing whether 
A a 450-volt shock was dangerous . 
B punishment helps learning. 
C the pupils were honest. 
D they were suited to teaching. 
21 The teacher-subjects were instructed to 
A stop when a pupil asked them to. 
B denounce pupils who made mistakes. 
C reduce the shock level after a correct answer. 
D give punishment according to a rule. 
22 Before the experiment took place the psychiatrists 
22 
A believed that a shock of 150 volts was too dangerous. 
B failed to agree on how the teacher-subjects would respond to instructions. 
C underestimated the teacher-subjects' willingness to comply with experimental 
procedure. 
D thought that many of the teacher-subjects would administer a shock of 450 volts.
```

[Original question page](assets/f62b84e659059370d6f31097218ca95cb477e1ebd7c2bbdda1d3cae488b28bf8.jpg)

<!-- Source: /api/assets/a8a21217fdc070ee7453995f56f2f4f0227db37b0519183031b74459669dda8d.jpg; PDF page 24; full -->

```text
Reading 
Questions 23-26 
Do the following statements agree with the information given in Reading Passage 2? 
In boxes 23-26 on your answer sheet, write 
TRUE 
FALSE 
NOT GIVEN 
if the statement agrees with the information 
·if the statement contradicts the information 
if there is no information on this 
23 Several of the subjects were psychology students at Yale University. 
24 Some people may believe that the teacher-subjects ' behaviour could be explained as a 
positive survival mechanism. 
25 In a sociological explanation, personal values are more powerful than authority. 
26 Milgram's experiment solves an important question in sociobiology. 
23
```

[Original question page](assets/a8a21217fdc070ee7453995f56f2f4f0227db37b0519183031b74459669dda8d.jpg)

<!-- Source: /api/assets/a4e8ff52f6d7d230791de30877f86697f83e925870a87fd77ac8600d0e672acd.jpg; PDF page 25; full -->

```text
Test 1



READING PASSAGE 3



You should spend about 20 minutes on Questions 27-40, which are based on Reading Passage 3

below.



The Truth about the Environment

For many environmentalists, the world seems to be getting worse. They have developed

a hit-list of our main fears: that natural resources are running out; that the population is

ever growing, leaving less and less to eat; that species are becoming extinct in vast

numbers, and that the planet's air and water are becoming ever more polluted.



But a quick look at the facts shows a different picture. First, energy and other natural

resources have become more abundant, not less so, since the book ‘The Limits to

Growth’ was published in 1972 by a group of scientists. Second, more food is now

produced per head of the world’s population than at any time in history. Fewer people

are starving. Third, although species are indeed becoming extinct, only about 0.7% of

them are expected to disappear in the next 50 years, not 25-50%, as has so often been

predicted. And finally, most forms of environmental pollution either appear to have

been exaggerated, or are transient — associated with the early phases of industrialisation

and therefore best cured not by restricting economic growth, but by accelerating it. One

form of pollution - the release of greenhouse gases that causes global warming — does

appear to be a phenomenon that is going to extend well into our future, but its total

impact is unlikely to pose a devastating problem. A bigger problem may well turn out to

be an inappropriate response to it.



Yet opinion polls suggest that many people nurture the belief that environmental

standards are declining and four factors seem to cause this disjunction between

perception and reality.



One is the lopsidedness built into scientific research. Scientific funding goes mainly to

areas with many problems. That may be wise policy, but it will also create an impression

that many more potential problems exist than is the case.



Secondly, environmental groups need to be noticed by the mass media. They also need

to keep the money rolling in. Understandably, perhaps, they sometimes overstate their

arguments. In 1997, for example, the World Wide Fund for Nature issued a press

release entitled: ‘Two thirds of the world's forests lost forever’. The truth turns out to

be nearer 20%.



Though these groups are run overwhelmingly by selfless folk, they nevertheless share

many of the characteristics of other lobby groups. That would matter less if people

applied the same degree of scepticism to environmental lobbying as they do to lobby

groups in other fields. A trade organisation arguing for, say, weaker pollution controls is

instantly seen as self-interested. Yet a green organisation opposing such a weakening is



24
```

[Original question page](assets/a4e8ff52f6d7d230791de30877f86697f83e925870a87fd77ac8600d0e672acd.jpg)

<!-- Source: /api/assets/916f6e7948ef328bfa58df17712a4496aa5e117dd00bd69af44ae016545d5324.jpg; PDF page 26; full -->

```text
Reading



seen as altruistic, even if an impartial view of the controls in question might suggest

they are doing more harm than good.



A third source of confusion is the attitude of the media. People are clearly more curious

about bad news than good. Newspapers and broadcasters are there to provide what the

public wants. That, however, can lead to significant distortions of perception. An

example was America’s encounter with El Niño in 1997 and 1998. This climatic

phenomenon was accused of wrecking tourism, causing allergies, melting the ski-slopes

and causing 22 deaths. However, according to an article in the Bulletin of the American

Meteorological Society, the damage it did was estimated at US$4 billion but the benefits

amounted to some US$19 billion. These came from higher winter temperatures (which

saved an estimated 850 lives, reduced heating costs and diminished spring floods caused

by meltwaters).



The fourth factor is poor individual perception. People worry that the endless rise in the

amount of stuff everyone throws away will cause the world to run out of places to

dispose of waste. Yet, even if America’s trash output continues to rise as it has done in

the past, and even if the American population doubles by 2100, all the rubbish America

produces through the entire 21st century will still take up only one-12,000th of the area

of the entire United States.



So what of global warming? As we know, carbon dioxide emissions are causing the

planet to warm. The best estimates are that the temperatures will rise by 2-3°C in this

century, causing considerable problems, at a total cost of US$5,000 billion.



Despite the intuition that something drastic needs to be done about such a costly

problem, economic analyses clearly show it will be far more expensive to cut carbon

dioxide emissions radically than to pay the costs of adaptation to the increased

temperatures. A model by one of the main authors of the United Nations Climate

Change Panel shows how an expected temperature increase of 2.1 degrees in 2100

would only be diminished to an increase of 1.9 degrees. Or to put it another way, the

temperature increase that the planet would have experienced in 2094 would be

postponed to 2100.



So this does not prevent global warming, but merely buys the world six years. Yet the

cost of reducing carbon dioxide emissions, for the United States alone, will be higher

than the cost of solving the world’s single, most pressing health problem: providing

universal access to clean drinking water and sanitation. Such measures would avoid



2 million deaths every year, and prevent half a billion people from becoming seriously ill.



It is crucial that we look at the facts if we want to make the best possible decisions for

the future. It may be costly to be overly optimistic — but more costly still to be too

pessimistic.



25
```

[Original question page](assets/916f6e7948ef328bfa58df17712a4496aa5e117dd00bd69af44ae016545d5324.jpg)

<!-- Source: /api/assets/bdb26da6af3758aed88ec3e07d8580658746358b7d94bc86eacda8675fd0adc6.jpg; PDF page 27; full -->

```text
Test I 
Questions 27-32 
Do the following statements agree with the claims of the writer in Reading Passage 3? 
In boxes 27-32 on your answer sheet, write 
YES 
NO 
NOT GIVEN 
if the statement agrees with the writer's claims 
if the statement contradicts the writer's claims 
if it is impossible to say what the writer thinks about this 
27 Environmentalists take a pessimistic view of the world for a number of reasons. 
28 Data on the Earth's natural resources has only been collected since 1972. 
29 The number of starving people in the world has increased in recent years. 
30 Extinct species are being replaced by new species. 
31 Some pollution problems have been correctly linked to industrialisation. 
32 It would be best to attempt to slow down economic growth. 
26
```

[Original question page](assets/bdb26da6af3758aed88ec3e07d8580658746358b7d94bc86eacda8675fd0adc6.jpg)

<!-- Source: /api/assets/4c98027f94a153d8decf484c94857922b01c88f363ebfee86f935f18ebeb12cf.jpg; PDF page 28; full -->

```text
Reading 
Questions 33-37 
Choose the correct letter. A, B. C or D. 
Write your answers in boxes 33- 37 on your answer sheet. 
33 What aspect of scientific research does the writer express concern about in paragraph 4? 
A the need to produce results 
B the lack of financial support 
C the selection of areas to research 
D the desire to solve every research problem 
34 The writer quotes from the Worldwide Fund for Nature to illustrate how 
A influential the mass media can be. 
B effective environmental groups can be. 
C the mass media can help groups raise funds. 
D environmental groups can exaggerate their claims. 
35 What is the writer 's main point about lobby groups in paragraph 6? 
A Some are more active than others. 
B Some are better organised than others. 
C Some receive more criticism than others. 
D Some support more important issues than others . 
36 The writer suggests that newspapers print items that are intended to 
A educate readers. 
B meet their readers ' expectations . 
C encourage feedback from readers. 
D mislead readers. 
37 What does the writer say about America 's waste problem? 
A It will increase in line with population growth. 
B It is not as important as we have been led to believe. 
C It has been reduced through public awareness of the issues. 
D It is only significant in certain areas of the country. 
27
```

[Original question page](assets/4c98027f94a153d8decf484c94857922b01c88f363ebfee86f935f18ebeb12cf.jpg)

<!-- Source: /api/assets/99ae296e28ebe0fad6f12e46637c2a2dd2097bf968e929075ed28000e61362a6.jpg; PDF page 29; full -->

```text
Test 1 
Questions 38-40 
Complete the summary with the list of words A–I below. 
Write the correct letter A–I in boxes 38-40 on your answer sheet. 
GLOBAL WARMING 
The writer admits that global warming is a 38 .............. .......... challenge, but says that it will 
not have a catastrophic impact on our future, if we deal with it in the 39 ........................ way. 
If we try to reduce the levels of greenhouse gases, he believes that it would only have a 
minimal impact on rising temperatures. He feels it would be better to spend money on the 
more 40 ........................ health problem of providing the world's population with clean 
drinking water. 
28 
A unrealistic 
E long-term 
I urgent 
B agreed 
F usual 
C expensive 
G surprising 
D right 
H personal
```

[Original question page](assets/99ae296e28ebe0fad6f12e46637c2a2dd2097bf968e929075ed28000e61362a6.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/afcc956794a43b728042c1e9ccd72bccf36e53bf893ec3d6e9c52f9a6a4025dd.jpg; PDF page 30; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below shows the proportion of the population aged 65 and over between 1940 and 2040 in three different countries.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/afcc956794a43b728042c1e9ccd72bccf36e53bf893ec3d6e9c52f9a6a4025dd.jpg)

![Original figure](assets/afcc956794a43b728042c1e9ccd72bccf36e53bf893ec3d6e9c52f9a6a4025dd.jpg)

### Task 2

<!-- Source: /api/assets/36a91500494e5a38584b4530ae743f865f16611881d9f5b5bc182956c767b65e.jpg; PDF page 31; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Universities should accept equal numbers of male and female students in every subject.

To what extent do you agree or disagree?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/36a91500494e5a38584b4530ae743f865f16611881d9f5b5bc182956c767b65e.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/63be91684ca8a8c3ad6c31b9e247f767952618f33be9994ae92608513a31a32f.jpg; PDF page 32; full -->

```text
Speaking 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Your country 
• Which part of your country do most people live in? 
• Tell me about the main industries there. 
• How easy is it to travel around your country? 
• Has your country changed much since you were a child? 
PART 2 
Describe a well-known person you like or 
admire. 
You should say: 
who this person is 
what this person has done 
why this person is well known 
and explain why you admire this person. 
You will have to talk about the topic for 
one to two minutes . 
You have one minute to think about what 
you 're going to say. 
You can make some notes to help you if 
you wish. 

PART 3 
Discussion topics: 
Famous people in your country 
Example questions: 
What kind of people become famous people these days? 
Is this different from the kind of achievement that made people famous in the past? 
In what way? 
How do you think people will become famous in the future? 
Being in the public eye 
Example questions: 
What are the good things about being famous? Are there any disadvantages? 
How does the media in your country treat famous people? 
Why do you think ordinary people are interested in the lives of famous people? 
31
```

[Original question page](assets/63be91684ca8a8c3ad6c31b9e247f767952618f33be9994ae92608513a31a32f.jpg)

### Part 2

<!-- Source: /api/assets/63be91684ca8a8c3ad6c31b9e247f767952618f33be9994ae92608513a31a32f.jpg; PDF page 32; full -->

```text
Speaking 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Your country 
• Which part of your country do most people live in? 
• Tell me about the main industries there. 
• How easy is it to travel around your country? 
• Has your country changed much since you were a child? 
PART 2 
Describe a well-known person you like or 
admire. 
You should say: 
who this person is 
what this person has done 
why this person is well known 
and explain why you admire this person. 
You will have to talk about the topic for 
one to two minutes . 
You have one minute to think about what 
you 're going to say. 
You can make some notes to help you if 
you wish. 

PART 3 
Discussion topics: 
Famous people in your country 
Example questions: 
What kind of people become famous people these days? 
Is this different from the kind of achievement that made people famous in the past? 
In what way? 
How do you think people will become famous in the future? 
Being in the public eye 
Example questions: 
What are the good things about being famous? Are there any disadvantages? 
How does the media in your country treat famous people? 
Why do you think ordinary people are interested in the lives of famous people? 
31
```

[Original question page](assets/63be91684ca8a8c3ad6c31b9e247f767952618f33be9994ae92608513a31a32f.jpg)

### Part 3

<!-- Source: /api/assets/63be91684ca8a8c3ad6c31b9e247f767952618f33be9994ae92608513a31a32f.jpg; PDF page 32; full -->

```text
Speaking 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Your country 
• Which part of your country do most people live in? 
• Tell me about the main industries there. 
• How easy is it to travel around your country? 
• Has your country changed much since you were a child? 
PART 2 
Describe a well-known person you like or 
admire. 
You should say: 
who this person is 
what this person has done 
why this person is well known 
and explain why you admire this person. 
You will have to talk about the topic for 
one to two minutes . 
You have one minute to think about what 
you 're going to say. 
You can make some notes to help you if 
you wish. 

PART 3 
Discussion topics: 
Famous people in your country 
Example questions: 
What kind of people become famous people these days? 
Is this different from the kind of achievement that made people famous in the past? 
In what way? 
How do you think people will become famous in the future? 
Being in the public eye 
Example questions: 
What are the good things about being famous? Are there any disadvantages? 
How does the media in your country treat famous people? 
Why do you think ordinary people are interested in the lives of famous people? 
31
```

[Original question page](assets/63be91684ca8a8c3ad6c31b9e247f767952618f33be9994ae92608513a31a32f.jpg)
