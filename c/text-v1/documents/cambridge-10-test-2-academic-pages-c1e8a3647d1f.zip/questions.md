# 剑雅 10 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/68c3de035f1afcef38662d0c16eafe035c0fe9279597750d5935725c2a403152.jpg; PDF page 26; full -->

```text
SECTION 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Transport Survey
Example — Travelled to town today: by bus
Name: Luisa (1) __________
Address: (2) __________ White Stone Rd
Area: Bradfield
Postcode: (3) __________
Occupation: (4) __________
Reason for visit to town: to go to the (5) __________
Suggestions for improvement:
– better (6) __________
– have more footpaths
– more frequent (7) __________
```

[Original question page](assets/68c3de035f1afcef38662d0c16eafe035c0fe9279597750d5935725c2a403152.jpg)

<!-- Source: /api/assets/89fa9ca60af8f4e3d29c9dc3bdb897c01f1020e631eb0ee550fd99a554fac824.jpg; PDF page 27; full -->

```text
Things that would encourage cycling to work:
– having (8) __________ parking places for bicycles
– being able to use a (9) __________ at work
– the opportunity to have cycling (10) __________ on busy roads
```

[Original question page](assets/89fa9ca60af8f4e3d29c9dc3bdb897c01f1020e631eb0ee550fd99a554fac824.jpg)

### Part 2

<!-- Source: /api/assets/7e37b3ab9d108e0436a3c6ed9770b353d5918ab8c0ddfcc5985caa1c80854866.jpg; PDF page 28; full -->

```text
SECTION 2 Questions 11–20
Questions 11–14
Choose the correct letter, A, B or C.
New city developments
11 The idea for the two new developments in the city came from
A local people.
B the City Council.
C the SWRDC.
12 What is unusual about Brackenside pool?
A its architectural style
B its heating system
C its method of water treatment
13 Local newspapers have raised worries about
A the late opening date.
B the cost of the project.
C the size of the facilities.
14 What decision has not yet been made about the pool?
A whose statue will be at the door
B the exact opening times
C who will open it
```

[Original question page](assets/7e37b3ab9d108e0436a3c6ed9770b353d5918ab8c0ddfcc5985caa1c80854866.jpg)

<!-- Source: /api/assets/dad898b9cc39e971baff0091e8f98cb04c6b5eba54039e5a389e0e83547848e3.jpg; PDF page 29; full -->

```text
Questions 15–20
Which feature is related to each of the following areas of the world represented in the playground?
Choose SIX answers from the box and write the correct letter, A–I, next to questions 15–20.
Features
A ancient forts
B waterways
C ice and snow
D jewels
E local animals
F mountains
G music and film
H space travel
I volcanoes
Areas of the world
15 Asia __________
16 Antarctica __________
17 South America __________
18 North America __________
19 Europe __________
20 Africa __________
```

[Original question page](assets/dad898b9cc39e971baff0091e8f98cb04c6b5eba54039e5a389e0e83547848e3.jpg)

### Part 3

<!-- Source: /api/assets/07c51b7a27cf814e52f6c7f6fe082c5b88b9327b6cf600c5a07e0fbfe9fab46b.jpg; PDF page 30; full -->

```text
SECTION 3 Questions 21–30
Questions 21 and 22
Choose TWO letters, A–E.
Which TWO hobbies was Thor Heyerdahl very interested in as a youth?
A camping
B climbing
C collecting
D hunting
E reading
Questions 23 and 24
Choose TWO letters, A–E.
Which do the speakers say are the TWO reasons why Heyerdahl went to live on an island?
A to examine ancient carvings
B to experience an isolated place
C to formulate a new theory
D to learn survival skills
E to study the impact of an extreme environment
```

[Original question page](assets/07c51b7a27cf814e52f6c7f6fe082c5b88b9327b6cf600c5a07e0fbfe9fab46b.jpg)

<!-- Source: /api/assets/25f59598566c870d2deab0451dfff8cccc0dd2189265625b24b01d170a69d7a7.jpg; PDF page 31; full -->

```text
Questions 25–30
Test 2
Choose the correct letter, A, B or C.
The later life of Thor Heyerdahl
25 According to Victor and Olivia, academics thought that Polynesian migration from
the east was impossible due to
A the fact that Eastern countries were far away.
B the lack of materials for boat building.
C the direction of the winds and currents.
26 Which do the speakers agree was the main reason for Heyerdahl’s raft journey?
A  to overcome a research setback
B to demonstrate a personal quality
C to test a new theory
27 What was most important to Heyerdahl about his raft journey?
A  the fact that he was the first person to do it
B the speed of crossing the Pacific
C the use of authentic construction methods
28 Why did Heyerdahl go to Easter Island?
A  to build a stone statue
B to sail a reed boat
C to learn the local language
29 In Olivia's opinion, Heyerdahl’s greatest influence was on
A theories about Polynesian origins.
B the development of archaeological methodology.
C establishing archaeology as an academic subject.
30 Which criticism do the speakers make of William Oliver’s textbook?
A Its style is out of date.
B Its content is over-simplified.
C Its methodology is flawed.

38
```

[Original question page](assets/25f59598566c870d2deab0451dfff8cccc0dd2189265625b24b01d170a69d7a7.jpg)

### Part 4

<!-- Source: /api/assets/ba92880999d8aa2cc9dbba0e7ee9ddda17807b4170a65e9f1463129895b874bc.jpg; PDF page 32; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
THE FUTURE OF MANAGEMENT
Business markets
– greater (31) __________ among companies
– increase in power of large (32) __________ companies
– rising (33) __________ in certain countries
External influences on businesses
– more discussion with (34) __________ before making business decisions
– environmental concerns which may lead to more (35) __________
Business structures
– more teams will be formed to work on a particular (36) __________
– businesses may need to offer hours that are (37) __________, or the chance to work remotely
Management styles
– increasing need for managers to provide good (38) __________
– changes influenced by (39) __________ taking senior roles
```

[Original question page](assets/ba92880999d8aa2cc9dbba0e7ee9ddda17807b4170a65e9f1463129895b874bc.jpg)

<!-- Source: /api/assets/239bf05d367e78378d1ce3a0ff0d1cd87ee362a6d2e446f23b40391e485ce9d2.jpg; PDF page 33; full -->

```text
Changes in the economy
– service sector continues to be important
– increasing value of intellectual property
– more and more (40) __________ workers
```

[Original question page](assets/239bf05d367e78378d1ce3a0ff0d1cd87ee362a6d2e446f23b40391e485ce9d2.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/6255731c40ab086993bc17b44b3c9e360233a5622eacc40f3894c2ecd80fc07a.jpg; PDF page 34; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1  on the following pages.
Questions 1-7
Reading Passage 1  has seven paragraphs, A-G.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i-ix, in boxes 1-7 on your answer sheet.
List of Headings
i The search for the reasons for an increase in population
ii Industrialisation and the fear of unemployment
iii The development of cities in Japan
iv The time and place of the Industrial Revolution
v The cases of Holland, France and China
vi Changes in drinking habits in Britain
vii Two keys to Britain's industrial revolution
viii Conditions required for industrialisation
ix Comparisons with Japan lead to the answer
1 Paragraph A
2 Paragraph B
3 Paragraph C
4 Paragraph D
5 Paragraph E
6 Paragraph F
7 Paragraph G
41
```

[Original question page](assets/6255731c40ab086993bc17b44b3c9e360233a5622eacc40f3894c2ecd80fc07a.jpg)

<!-- Source: /api/assets/1482fa42b090444d0b0c2e23a572a9f4f6ba5ca7de30c8a7e16ac163787c7fb8.jpg; PDF page 35; full -->

```text
Test 2
Tea and the Industrial Revolution
A Cambridge professor says that a change in drinking habits was the reason for
the Industrial Revolution in Britain. Anjana Ahuja reports
A Alan Macfarlane, professor of anthropological science at King’s College, Cambridge, has, like
other historians, spent decades wrestling with the enigma of the Industrial Revolution. Why
did this particular Big Bang — the world-changing birth of industry — happen in Britain? And
why did it strike at the end of the 18th century?
B Macfarlane compares the puzzle to a combination lock. ‘There are about 20 different
factors and all of them need to be present before the revolution can happen,’ he says. For
industry to take off, there needs to be the technology and power to drive factories, large
urban populations to provide cheap labour, easy transport to move goods around, an
affluent middle-class willing to buy mass-produced objects, a market-driven economy and
a political system that allows this to happen. While this was the case for England, other
nations, such as Japan, the Netherlands and France also met some of these criteria but were
not industrialising. ‘All these factors must have been necessary but not sufficient to cause the
revolution,’ says Macfarlane. ‘After all, Holland had everything except coal, while China also
had many of these factors. Most historians are convinced there are one or two missing factors
that you need to open the lock.’
C The missing factors, he proposes, are to be found in almost every kitchen cupboard. Tea and
beer, two of the nation’s favourite drinks, fuelled the revolution. The antiseptic properties
of tannin, the active ingredient in tea, and of hops in beer — plus the fact that both are
made with boiled water — allowed urban communities to flourish at close quarters without
succumbing to water-borne diseases such as dysentery. The theory sounds eccentric but once
he starts to explain the detective work that went into his deduction, the scepticism gives
way to wary admiration. Macfarlane’s case has been strengthened by support from notable
quarters — Roy Porter, the distinguished medical historian, recently wrote a favourable
appraisal of his research.
D Macfarlane had wondered for a long time how the Industrial Revolution came about.
Historians had alighted on one interesting factor around the mid-18th century that required
explanation. Between about 1650 and 1740, the population in Britain was static. But then
there was a burst in population growth. Macfarlane says: ‘The infant mortality rate halved
in the space of 20 years, and this happened in both rural areas and cities, and across all
classes. People suggested four possible causes. Was there a sudden change in the viruses and
bacteria around? Unlikely. Was there a revolution in medical science? But this was a century
before Lister's revolution*. Was there a change in environmental conditions? There were
improvements in agriculture that wiped out malaria, but these were small gains. Sanitation
did not become widespread until the 19th century. The only option left is food. But the
height and weight statistics show a decline. So the food must have got worse. Efforts to
explain this sudden reduction in child deaths appeared to draw a blank.’
* Joseph Lister was the first doctor to use antiseptic techniques during surgical operations to prevent infections.
42
```

[Original question page](assets/1482fa42b090444d0b0c2e23a572a9f4f6ba5ca7de30c8a7e16ac163787c7fb8.jpg)

<!-- Source: /api/assets/f0f01cb7aa2eadf3b432908befd151245ec7ad3ee5c68c8a49c39244f67ce2d7.jpg; PDF page 36; full -->

```text
Reading
E This population burst seemed to happen at just the right time to provide labour for the
Industrial Revolution. ‘When you start moving towards an industrial revolution, it is
economically efficient to have people living close together,’ says Macfarlane. ‘But then you
get disease, particularly from human waste.’ Some digging around in historical records
revealed that there was a change in the incidence of water-borne disease at that time,
especially dysentery. Macfarlane deduced that whatever the British were drinking must have
been important in regulating disease. He says, ‘We drank beer. For a long time, the English
were protected by the strong antibacterial agent in hops, which were added to help preserve
the beer. But in the late 17th century a tax was introduced on malt, the basic ingredient of
beer. The poor turned to water and gin and in the 1720s the mortality rate began to rise
again. Then it suddenly dropped again. What caused this?’
F Macfarlane looked to Japan, which was also developing large cities about the same time,
and also had no sanitation. Water-borne diseases had a much looser grip on the Japanese
population than those in Britain. Could it be the prevalence of tea in their culture?
Macfarlane then noted that the history of tea in Britain provided an extraordinary
coincidence of dates. Tea was relatively expensive until Britain started a direct clipper trade
with China in the early 18th century. By the 1740s, about the time that infant mortality
was dipping, the drink was common. Macfarlane guessed that the fact that water had to
be boiled, together with the stomach-purifying properties of tea meant that the breast
milk provided by mothers was healthier than it had ever been. No other European nation
sipped tea like the British, which, by Macfarlane's logic, pushed these other countries out of
contention for the revolution.
G But, if tea is a factor in the combination lock, why didn’t Japan forge ahead in a tea-soaked
industrial revolution of its own? Macfarlane notes that even though 17th-century Japan had
large cities, high literacy rates, even a futures market, it had turned its back on the essence
of any work-based revolution by giving up labour-saving devices such as animals, afraid that
they would put people out of work. So, the nation that we now think of as one of the most
technologically advanced entered the 19th century having ‘abandoned the wheel’.
43
```

[Original question page](assets/f0f01cb7aa2eadf3b432908befd151245ec7ad3ee5c68c8a49c39244f67ce2d7.jpg)

<!-- Source: /api/assets/18e0fb64e2e15da9e583ea58557f20072673db041efb8a121538497b1f0edf1e.jpg; PDF page 37; full -->

```text
Questions 8–13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 8–13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
8 China’s transport system was not suitable for industry in the 18th century.
9 Tea and beer both helped to prevent dysentery in Britain.
10 Roy Porter disagrees with Professor Macfarlane’s findings.
11 After 1740, there was a reduction in population in Britain.
12 People in Britain used to make beer at home.
13 The tax on malt indirectly caused a rise in the death rate.
```

[Original question page](assets/18e0fb64e2e15da9e583ea58557f20072673db041efb8a121538497b1f0edf1e.jpg)

<!-- Source: /api/assets/9fc1e1c6411f8c21268d893c5118d8afd64cd68f9c31f6a40b495474697f1b8c.jpg; PDF page 38; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on
Reading Passage 2 below.
Gifted children and learning
A Internationally, ‘giftedness’ is  most frequently determined by a  score on a
general intelligence test, known as an IQ test, which is above a chosen cut­
off point, usually at around the top 2-5%. Children's educational environment
contributes to the IQ score and the way intelligence is used. For example,
a very close positive relationship was found when children's IQ scores were
compared with their home educational provision (Freeman, 2010). The higher
the children's IQ scores, especially over IQ 130, the better the quality of their
educational backup, measured in terms of reported verbal interactions with
parents, number of books and activities in their home etc. Because IQ tests are
decidedly influenced by what the child has learned, they are to some extent
measures of current achievement based on age-norms; that is, how well the
children have learned to manipulate their knowledge and know-how within the
terms of the test. The vocabulary aspect, for example, is dependent on having
heard those words. But IQ tests can neither identify the processes of learning
and thinking nor predict creativity.
B Excellence does not emerge without appropriate help. To reach an
exceptionally high standard in any area very able children need the means to
learn, which includes material to work with and focused challenging tuition
– and the encouragement to follow their dream. There appears to be a
qualitative difference in the way the intellectually highly able think, compared
with more average-ability or older pupils, for whom external regulation by the
teacher often compensates for lack of internal regulation. To be at their most
effective in their self-regulation, all children can be helped to identify their own
ways of learning -  metacognition -  which will include strategies of planning,
monitoring, evaluation, and choice of what to learn. Emotional awareness is
also part of metacognition, so children should be helped to be aware of their
feelings around the area to be learned, feelings of curiosity or confidence, for
example.
C High achievers have been found to use self-regulatory learning strategies
more often and more effectively than lower achievers, and are better able to
transfer these strategies to deal with unfamiliar tasks. This happens to such a
high degree in some children that they appear to be demonstrating talent in
particular areas. Overviewing research on the thinking process of highly able
45
```

[Original question page](assets/9fc1e1c6411f8c21268d893c5118d8afd64cd68f9c31f6a40b495474697f1b8c.jpg)

<!-- Source: /api/assets/af56646d49a719dab82382be5e9894b2997a2c6a62f07b932db465f3bc529b07.jpg; PDF page 39; full -->

```text
Test 2
children, (Shore and Kanevsky, 1993) put the instructor's problem succinctly:
‘If they [the gifted] merely think more quickly, then we need only teach more
quickly. If they merely make fewer errors, then we can shorten the practice'. But
of course, this is not entirely the case; adjustments have to be made in methods
of learning and teaching, to take account of the many ways individuals think.
D Yet in order to learn by themselves, the gifted do need some support from their
teachers. Conversely, teachers who have a tendency to 'overdirect' can diminish
their gifted pupils' learning autonomy. Although 'spoon-feeding' can produce
extremely high examination results, these are not always followed by equally
impressive life successes. Too much dependence on the teacher risks loss of
autonomy and motivation to discover. However, when teachers help pupils to
reflect on their own learning and thinking activities, they increase their pupils'
self-regulation. For a young child, it may be just the simple question 'What have
you learned today?' which helps them to recognise what they are doing. Given
that a fundamental goal of education is to transfer the control of learning from
teachers to pupils, improving pupils' learning to learn techniques should be a
major outcome of the school experience, especially for the highly competent.
There are quite a number of new methods which can help, such as child-
initiated learning, ability-peer tutoring, etc. Such practices have been found to
be particularly useful for bright children from deprived areas.
E But scientific progress is not all theoretical, knowledge is also vital to
outstanding performance: individuals who know a  great deal about a  specific
domain will achieve at a higher level than those who do not (Elshout, 1995).
Research with creative scientists by Simonton (1988) brought him to the
conclusion that above a certain high level, characteristics such as independence
seemed to contribute more to reaching the highest levels of expertise than
intellectual skills, due to the great demands of effort and time needed for
learning and practice. Creativity in all forms can be seen as expertise mixed
with a high level of motivation (Weisberg, 1993).
F To sum up, learning is affected by emotions of both the individual and
significant others. Positive emotions facilitate the creative aspects of learning
and negative emotions inhibit it. Fear, for example, can limit the development
of curiosity, which is a strong force in scientific advance, because it motivates
problem-solving behaviour. In  Boekaerts' (1991) review of emotion in the
learning of very high IQ and highly achieving children, she found emotional
forces in harness. They were not only curious, but often had a strong desire to
control their environment, improve their learning efficiency, and increase their
own learning resources.
46
```

[Original question page](assets/af56646d49a719dab82382be5e9894b2997a2c6a62f07b932db465f3bc529b07.jpg)

<!-- Source: /api/assets/083bcb3c70529f97b35ddb3296bf981af44d733dbcb22668632c6856640ed10a.jpg; PDF page 40; full -->

```text
Questions 14–17
Reading Passage 2 has six paragraphs, A–F.
Which paragraph contains the following information?
Write the correct letter, A–F, in boxes 14–17 on your answer sheet.
NB You may use any letter more than once.
14 a reference to the influence of the domestic background on the gifted child
15 reference to what can be lost if learners are given too much guidance
16 a reference to the damaging effects of anxiety
17 examples of classroom techniques which favour socially-disadvantaged children
Questions 18–22
Look at the following statements (Questions 18–22) and the list of people below.
Match each statement with the correct person or people, A–E.
Write the correct letter, A–E, in boxes 18–22 on your answer sheet.
18 Less time can be spent on exercises with gifted pupils who produce accurate work.
19 Self-reliance is a valuable tool that helps gifted students reach their goals.
20 Gifted children know how to channel their feelings to assist their learning.
21 The very gifted child benefits from appropriate support from close relatives.
22 Really successful students have learnt a considerable amount about their subject.
List of People
A Freeman
B Shore and Kanevsky
C Elshout
D Simonton
E Boekaerts
```

[Original question page](assets/083bcb3c70529f97b35ddb3296bf981af44d733dbcb22668632c6856640ed10a.jpg)

<!-- Source: /api/assets/56ffe2a9b06ced9e7eb795a5ce375f084d7a3d7e023b775f98f08f216c5200ac.jpg; PDF page 41; full -->

```text
Questions 23–26
Complete the sentences below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 23–26 on your answer sheet.
23 One study found a strong connection between children’s IQ and the availability of __________ and __________ at home.
24 Children of average ability seem to need more direction from teachers because they do not have __________.
25 Metacognition involves children understanding their own learning strategies, as well as developing __________.
26 Teachers who rely on what is known as __________ often produce sets of impressive grades in class tests.
```

[Original question page](assets/56ffe2a9b06ced9e7eb795a5ce375f084d7a3d7e023b775f98f08f216c5200ac.jpg)

<!-- Source: /api/assets/39189eecba28d389b23caee1f92d3b08f18d6508f05128c8082d73be43122549.jpg; PDF page 42; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Museums of fine art and their public
The fact that people go to the Louvre museum in
Paris to see the original painting
Mona Lisa
 when
they can see a reproduction anywhere leads us
to question some assumptions about the role of
museums of fine art in today's world
One of the most famous works of art in
the world is Leonardo da Vinci's
Mona
Lisa.
 Nearly everyone who goes to see the
original will already be familiar with it from
reproductions, but they accept that fine art
is more rewardingly viewed in its original
form.
However, if
Mona Lisa
 was a famous
novel, few people would bother to
go to a museum to read the writer's
actual manuscript rather than a printed
reproduction. This might be explained by
the fact that the novel has evolved precisely
because of technological developments
that made it possible to print out huge
numbers of texts, whereas oil paintings have
always been produced as unique objects. In
addition, it could be argued that the practice
of interpreting or 'reading' each medium
follows different conventions. With novels,
the reader attends mainly to the meaning of
words rather than the way they are printed
on the page, whereas the 'reader' of a
painting must attend just as closely to the
material form of marks and shapes in the
picture as to any ideas they may signify.
Yet it has always been possible to make
very accurate facsimiles of pretty well any
fine art work. The seven surviving versions
of
Mona Lisa
 bear witness to the fact that
in the 16th century, artists seemed perfectly
content to assign
the reproduction
of their creations
to their workshop
apprentices as
regular 'bread and butter' work. And
today the task of reproducing pictures is
incomparably more simple and reliable,
with reprographic techniques that allow
the production of high-quality prints made
exactly to the original scale, with faithful
colour values, and even with duplication of
the surface relief of the painting.
But despite an implicit recognition that
the spread of good reproductions can be
culturally valuable, museums continue to
promote the special status of original work.
Unfortunately, this seems to place severe
limitations on the kind of experience offered
to visitors.
One limitation is related to the way the
museum presents its exhibits. As repositories
of unique historical objects, art museums
are often called 'treasure houses'. We are
reminded of this even before we view
a collection by the presence of security
guards, attendants, ropes and display cases
to keep us away from the exhibits. In many
cases, the architectural style of the building
further reinforces that notion. In addition,
a major collection like that of London's
49
```

[Original question page](assets/39189eecba28d389b23caee1f92d3b08f18d6508f05128c8082d73be43122549.jpg)

<!-- Source: /api/assets/476039af2ef8e8c7c7e7e705a2d3676fb537a8d70ce2dc0a89810fac78427e5f.jpg; PDF page 43; full -->

```text
Test 2
National Gallery is housed in numerous
rooms, each with dozens of works, any
one of which is likely to be worth more
than all the average visitor possesses. In a
society that judges the personal status of the
individual so much by their material worth,
it is therefore difficult not to be impressed by
one's own relative 'worthlessness' in such an
environment.
Furthermore, consideration of the ‘value’
of the original work in its treasure house
setting impresses upon the viewer that,
since these works were originally produced,
they have been assigned a huge monetary
value by some person or institution more
powerful than themselves. Evidently,
nothing the viewer thinks about the work
is going to alter that value, and so today's
viewer is deterred from trying to extend that
spontaneous, immediate, self-reliant kind of
reading which would originally have met the
work.
The visitor may then be struck by the
strangeness of seeing such diverse paintings,
drawings and sculptures brought together
in an environment for which they were not
originally created. This 'displacement effect'
is further heightened by the sheer volume of
exhibits. In the case of a major collection,
there are probably more works on display
than we could realistically view in weeks or
even months.
This is particularly distressing because
time seems to be a vital factor in the
appreciation of all art forms. A fundamental
difference between paintings and other art
forms is that there is no prescribed time
over which a painting is viewed. By contrast,
the audience encounters an opera or a play
over a specific time, which is the duration
of the performance. Similarly, novels and
poems are read in a prescribed temporal
sequence, whereas a picture has no clear
place at which to start viewing, or at
which to finish. Thus art works themselves
encourage us to view them superficially,
without appreciating the richness of detail
and labour that is involved.
Consequently, the dominant critical
approach becomes that of the art historian,
a specialised academic approach devoted to
'discovering the meaning' of art within the
cultural context of its time. This is in perfect
harmony with the museum's function, since
the approach is dedicated to seeking out and
conserving 'authentic', 'original' readings of
the exhibits. Again, this seems to put paid
to that spontaneous, participatory criticism
which can be found in abundance in
criticism of classic works of literature, but is
absent from most art history.
The displays of art museums serve
as a warning of what critical practices
can emerge when spontaneous criticism
is suppressed. The museum public, like
any other audience, experience art more
rewardingly when given the confidence
to express their views. If appropriate
works of fine art could be rendered
permanently accessible to the public by
means of high-fidelity reproductions, as
literature and music already are, the public
may feel somewhat less in awe of them.
Unfortunately, that may be too much to ask
from those who seek to maintain and control
the art establishment.
50
```

[Original question page](assets/476039af2ef8e8c7c7e7e705a2d3676fb537a8d70ce2dc0a89810fac78427e5f.jpg)

<!-- Source: /api/assets/23f0b3f382aa33bf2c790f76179d46ad68e2f5226a2c479fac1e7a4816172165.jpg; PDF page 44; full -->

```text
Questions 27–31
Complete the summary using the list of words, A–L, below.
Write the correct letter, A–L, in boxes 27–31 on your answer sheet.
The value attached to original works of art
People go to art museums because they accept the value of seeing an original work of art. But they do not go to museums to read original manuscripts of novels, perhaps because the availability of novels has depended on (27) __________ for so long, and also because with novels, the (28) __________ are the most important thing.
However, in historical times artists such as Leonardo were happy to instruct (29) __________ to produce copies of their work and these days new methods of reproduction allow excellent replication of surface relief features as well as colour and (30) __________.
It is regrettable that museums still promote the superiority of original works of art, since this may not be in the interests of the (31) __________.
A institution
B mass production
C mechanical processes
D public
E paints
F artist
G size
H underlying ideas
I basic technology
J readers
K picture frames
L assistants
```

[Original question page](assets/23f0b3f382aa33bf2c790f76179d46ad68e2f5226a2c479fac1e7a4816172165.jpg)

<!-- Source: /api/assets/f99582d1920ce76316d0c71268ca999d836e3e56bdc7efb3f898bbab954de5b3.jpg; PDF page 45; full -->

```text
Questions 32–35
Choose the correct letter, A, B, C or D. Write the correct letter in boxes 32–35 on your answer sheet.
32 The writer mentions London’s National Gallery to illustrate
A the undesirable cost to a nation of maintaining a huge collection of art.
B the conflict that may arise in society between financial and artistic values.
C the negative effect a museum can have on visitors’ opinions of themselves.
D the need to put individual well-being above large-scale artistic schemes.
33 The writer says that today, viewers may be unwilling to criticise a work because
A they lack the knowledge needed to support an opinion.
B they fear it may have financial implications.
C they have no real concept of the work’s value.
D they feel their personal reaction is of no significance.
34 According to the writer, the ‘displacement effect’ on the visitor is caused by
A the variety of works on display and the way they are arranged.
B the impossibility of viewing particular works of art over a long period.
C the similar nature of the paintings and the lack of great works.
D the inappropriate nature of the individual works selected for exhibition.
35 The writer says that unlike other forms of art, a painting does not
A involve direct contact with an audience.
B require a specific location for a performance.
C need the involvement of other professionals.
D have a specific beginning or end.
```

[Original question page](assets/f99582d1920ce76316d0c71268ca999d836e3e56bdc7efb3f898bbab954de5b3.jpg)

<!-- Source: /api/assets/731004e1b0464b02ba9602223bcc69a29c60b5ac07a5e7862eb88879c0089f38.jpg; PDF page 46; full -->

```text
Questions 36-40
Do the following statements agree with the views of the writer in Reading Passage 3?
Reading
In boxes 36-40 on your answer sheet, write
YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
36 Art history should focus on discovering the meaning of art using a range of media.
37 The approach of art historians conflicts with that of art museums.
38 People should be encouraged to give their opinions openly on works of art.
39 Reproductions of fine art should only be sold to the public if they are of high quality.
40 In the future, those with power are likely to encourage more people to enjoy art.
```

[Original question page](assets/731004e1b0464b02ba9602223bcc69a29c60b5ac07a5e7862eb88879c0089f38.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/8d22304c34f203c96a3f8a4e4bf2d6d3aa77d7203239c67c674175180c61fd45.jpg; PDF page 47; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The tables below give information about sales of Fairtrade*-labelled coffee and bananas in 1999 and 2004 in five European countries.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/8d22304c34f203c96a3f8a4e4bf2d6d3aa77d7203239c67c674175180c61fd45.jpg)

![Original figure](assets/8d22304c34f203c96a3f8a4e4bf2d6d3aa77d7203239c67c674175180c61fd45.jpg)

### Task 2

<!-- Source: /api/assets/680845846d6eeb2a1935406acf23620aadb5695de90506017b437a1dd01d8228.jpg; PDF page 48; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people think that all university students should study whatever they like. Others believe that they should only be allowed to study subjects that will be useful in the future, such as those related to science and technology.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/680845846d6eeb2a1935406acf23620aadb5695de90506017b437a1dd01d8228.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/6e5e718cedc7be01d8d1fc147f8a610a5106e895714a4c7d4d94ccc131ca9ecb.jpg; PDF page 49; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Music
• What types of music do you like to listen to? [Why?]
• At what times of day do you like to listen to music? [Why?]
• Did you learn to play a musical instrument when you were a child? [Why/Why not?]
• Do you think all children should learn to play a musical instrument? [Why/Why not?]
PART 2
Describe a shop near where you live that you sometimes use.
You should say:
what sorts of product or service it sells
what the shop looks like
where it is located
and explain why you use this shop.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Local business
Example questions:
What types of local business are there in your neighbourhood? Are there any
restaurants, shops or dentists for example?
Do you think local businesses are important for a neighbourhood? In what way?
How do large shopping malls and commercial centres affect small local businesses?
Why do you think that is?
People and business
Example questions:
Why do some people want to start their own business?
Are there any disadvantages to running a business? Which is the most serious?
What are the most important qualities that a good business person needs? Why is that?
56
```

[Original question page](assets/6e5e718cedc7be01d8d1fc147f8a610a5106e895714a4c7d4d94ccc131ca9ecb.jpg)

### Part 2

<!-- Source: /api/assets/6e5e718cedc7be01d8d1fc147f8a610a5106e895714a4c7d4d94ccc131ca9ecb.jpg; PDF page 49; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Music
• What types of music do you like to listen to? [Why?]
• At what times of day do you like to listen to music? [Why?]
• Did you learn to play a musical instrument when you were a child? [Why/Why not?]
• Do you think all children should learn to play a musical instrument? [Why/Why not?]
PART 2
Describe a shop near where you live that you sometimes use.
You should say:
what sorts of product or service it sells
what the shop looks like
where it is located
and explain why you use this shop.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Local business
Example questions:
What types of local business are there in your neighbourhood? Are there any
restaurants, shops or dentists for example?
Do you think local businesses are important for a neighbourhood? In what way?
How do large shopping malls and commercial centres affect small local businesses?
Why do you think that is?
People and business
Example questions:
Why do some people want to start their own business?
Are there any disadvantages to running a business? Which is the most serious?
What are the most important qualities that a good business person needs? Why is that?
56
```

[Original question page](assets/6e5e718cedc7be01d8d1fc147f8a610a5106e895714a4c7d4d94ccc131ca9ecb.jpg)

### Part 3

<!-- Source: /api/assets/6e5e718cedc7be01d8d1fc147f8a610a5106e895714a4c7d4d94ccc131ca9ecb.jpg; PDF page 49; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Music
• What types of music do you like to listen to? [Why?]
• At what times of day do you like to listen to music? [Why?]
• Did you learn to play a musical instrument when you were a child? [Why/Why not?]
• Do you think all children should learn to play a musical instrument? [Why/Why not?]
PART 2
Describe a shop near where you live that you sometimes use.
You should say:
what sorts of product or service it sells
what the shop looks like
where it is located
and explain why you use this shop.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Local business
Example questions:
What types of local business are there in your neighbourhood? Are there any
restaurants, shops or dentists for example?
Do you think local businesses are important for a neighbourhood? In what way?
How do large shopping malls and commercial centres affect small local businesses?
Why do you think that is?
People and business
Example questions:
Why do some people want to start their own business?
Are there any disadvantages to running a business? Which is the most serious?
What are the most important qualities that a good business person needs? Why is that?
56
```

[Original question page](assets/6e5e718cedc7be01d8d1fc147f8a610a5106e895714a4c7d4d94ccc131ca9ecb.jpg)
