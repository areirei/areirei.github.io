# 剑雅 10 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 146

TEST 2 LISTENING
1 Hardie
2 19
3 GT8 2LC
4 hairdresser
5 dentist / dentist’s
6 lighting
7 trains
8 safe
9 shower
10 training
11 A
12 C
13 C
14 A
15 E
16 F
17 D
18 H
19 A
20 B
21 B
22 C
23 B
24 E
25 A
26 C
27 C
28 A
29 B
30 A
31 competition
32 global
33 demand
34 customers
35 regulation
36 project
37 flexible
38 leadership
39 women
40 self-employed
21–22 IN EITHER ORDER: B; C
23–24 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. Hardie

2. 19

3. GT8 2LC / GT82LC

4. hairdresser

5. dentist / dentist's

6. lighting

7. trains

8. safe

9. shower

10. training

### Part 2 · source page 146

TEST 2 LISTENING
1 Hardie
2 19
3 GT8 2LC
4 hairdresser
5 dentist / dentist’s
6 lighting
7 trains
8 safe
9 shower
10 training
11 A
12 C
13 C
14 A
15 E
16 F
17 D
18 H
19 A
20 B
21 B
22 C
23 B
24 E
25 A
26 C
27 C
28 A
29 B
30 A
31 competition
32 global
33 demand
34 customers
35 regulation
36 project
37 flexible
38 leadership
39 women
40 self-employed
21–22 IN EITHER ORDER: B; C
23–24 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. A

12. C

13. C

14. A

15. E

16. F

17. D

18. H

19. A

20. B

### Part 3 · source page 146

TEST 2 LISTENING
1 Hardie
2 19
3 GT8 2LC
4 hairdresser
5 dentist / dentist’s
6 lighting
7 trains
8 safe
9 shower
10 training
11 A
12 C
13 C
14 A
15 E
16 F
17 D
18 H
19 A
20 B
21 B
22 C
23 B
24 E
25 A
26 C
27 C
28 A
29 B
30 A
31 competition
32 global
33 demand
34 customers
35 regulation
36 project
37 flexible
38 leadership
39 women
40 self-employed
21–22 IN EITHER ORDER: B; C
23–24 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. B / C

22. B / C

23. B / E

24. B / E

25. A

26. C

27. C

28. A

29. B

30. A

### Part 4 · source page 146

TEST 2 LISTENING
1 Hardie
2 19
3 GT8 2LC
4 hairdresser
5 dentist / dentist’s
6 lighting
7 trains
8 safe
9 shower
10 training
11 A
12 C
13 C
14 A
15 E
16 F
17 D
18 H
19 A
20 B
21 B
22 C
23 B
24 E
25 A
26 C
27 C
28 A
29 B
30 A
31 competition
32 global
33 demand
34 customers
35 regulation
36 project
37 flexible
38 leadership
39 women
40 self-employed
21–22 IN EITHER ORDER: B; C
23–24 IN EITHER ORDER: B; E
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. competition

32. global

33. demand

34. customers

35. regulation

36. project

37. flexible

38. leadership

39. women

40. self-employed

## A 类阅读

### Academic Reading · source page 147

ACADEMIC READING
1 iv
2 viii
3 vii
4 i
5 vi
6 ix
7 ii
8 NOT GIVEN
9 TRUE
10 FALSE
11 FALSE
12 NOT GIVEN
13 TRUE
14 A
15 D
16 F
17 D
18 B
19 D
20 E
21 A
22 C
23 books (and); activities [both required, either order, one mark]
24 internal regulation / self-regulation
25 emotional awareness
26 spoon-feeding
27 B
28 H
29 L
30 G
31 D
32 C
33 D
34 A
35 D
36 NOT GIVEN
37 NO
38 YES
39 NOT GIVEN
40 NO
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. iv

2. viii

3. vii

4. i

5. vi

6. ix

7. ii

8. NOT GIVEN

9. TRUE

10. FALSE

11. FALSE

12. NOT GIVEN

13. TRUE

14. A

15. D

16. F

17. D

18. B

19. D

20. E

21. A

22. C

23. books activities / books, activities / books and activities / books & activities / books; activities / books/activities / books,activities / activities books / activities, books / activities and books / activities & books / activities; books / activities/books / activities,books

24. internal regulation / self-regulation

25. emotional awareness

26. spoon-feeding

27. B

28. H

29. L

30. G

31. D

32. C

33. D

34. A

35. D

36. NOT GIVEN

37. NO

38. YES

39. NOT GIVEN

40. NO

## A 类写作

### Writing material: c10-t2-w-1

Sales in MILLIONS OF EUROS,1999→2004. Coffee table order: UK1.5→20, Switzerland3→6, Denmark1.8→2, Belgium1→1.7, Sweden0.8→1. Banana table order differs: Switzerland15→47, UK1→5.5, Belgium0.6→4, Sweden1.8→1, Denmark2→0.9. Coffee grows in all five; UK overtakes Switzerland and has largest absolute growth. Banana sales grow in Switzerland,UK,Belgium and fall in Sweden,Denmark; Switzerland dominates both years. Footnote Fairtrade: products for which farmers from developing countries have been paid an officially agreed fair price. Monetary sales, not tonnes, profits, or consumption quantities.



### Writing material: c10-t2-w-2

Discuss freedom to choose university subjects and restricting subjects to future usefulness, giving an opinion. Science/technology are examples, not the complete definition of useful subjects.



## 口语
