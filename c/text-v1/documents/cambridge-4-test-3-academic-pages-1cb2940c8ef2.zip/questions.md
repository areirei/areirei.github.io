# 剑雅 4 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/bdef4c6f6004f75697f9ebe9cdac5d65ea49810874d1a5c3653c16b95241e7f4.jpg; PDF page 58; full -->

```text
LISTENING SECTION1 Questions1–10
Questions1–4: Complete the form below. Write NO MORE THAN THREE WORDS AND/OR NUMBERS for each answer.
Accommodation Request Form
Example: Name—Sara Lim
Age:23
Length of time in Australia:(1) __________
Present address: Flat1,539,(2) __________ Road,Canterbury2036
Present course:(3) __________ English
Accommodation required from:(4) __________,7th September
```

[Original question page](assets/bdef4c6f6004f75697f9ebe9cdac5d65ea49810874d1a5c3653c16b95241e7f4.jpg)

<!-- Source: /api/assets/0ccf8e2b09dac06e3b13523a66ada9d3e1161a0efe0b2306ef42861462afd5ab.jpg; PDF page 59; full -->

```text
Questions 5-7 
Choose the correct letter, A, B or C. 
5 Sara requires a 
A single room. 
B twin room. 
C triple room. 
6 She would prefer to live with a 
A family. 
B single person. 
C couple. 
7 She would like to live in a 
A flat. 
B house. 
C studio apartment. 
Questions 8-10 
Complete the sentences below. 
Write NO MORE THAN ONE WORD for each answer. 
8 The .... ...... ..... .... .. ... will be $320. 
9 She needs to pay the rent by cash or cheque on a ...... .... .... ... ....... basis. 
10 She needs to pay her part of the .... .. ........ .... ... .. . bill. 
58
```

[Original question page](assets/0ccf8e2b09dac06e3b13523a66ada9d3e1161a0efe0b2306ef42861462afd5ab.jpg)

### Part 2

<!-- Source: /api/assets/4838c25349f5ada73258dc40ee09103640b37950183bd43b0a44719d03e6f332.jpg; PDF page 60; full -->

```text
SECTION 2 Questions 11-20 
Questions 11-14 
Choose the correct letter, A, B or C 
11 When is this year's festival being held? 
A 1-13 January 
B 5-17 January 
C 25-31January 
12 What will the reviewer concentrate on today? 
A theatre 
B dance 
C exhibitions 
13 How many circuses are there in the festival? 
A one 
B two 
C several 
14 Where does Circus Romano perform? 
A in a theatre 
B in a tent 
C in a stadium 
59
```

[Original question page](assets/4838c25349f5ada73258dc40ee09103640b37950183bd43b0a44719d03e6f332.jpg)

<!-- Source: /api/assets/7cad635bf5f7a4f6d2652b451fae4515474e8aad479c75d4cb43b2b122110eb9.jpg; PDF page 61; full -->

```text
Questions15–20: Complete the notes below. Write NO MORE THAN THREE WORDS for each answer.
Act | Where | Type of performance | Highlights | Type of audience
Circus Romano |[empty non-answer cell]|Clowns and acrobats|Music and (15) __________|(16) __________
Circus Electrica |(17) __________|Dancers and magicians|Aerial displays|(18) __________
Mekong Water Puppets |(19) __________|Puppets|Seeing the puppeteers at the end|(20) __________
```

[Original question page](assets/7cad635bf5f7a4f6d2652b451fae4515474e8aad479c75d4cb43b2b122110eb9.jpg)

### Part 3

<!-- Source: /api/assets/8319a837ff3259dac0b13487e3827b993af079376e78e483eeed077e243ebe99.jpg; PDF page 62; full -->

```text
SECTION 3 Questions 21-30 
Questions 21-25 
Choose the correct letter, A, B or C 
21 The man wants information on courses for 
A people going back to college. 
B postgraduate students. 
C business executives. 
22 The 'Study for Success' seminar lasts for 
A one day. 
B two days. 
C three days. 
23 In the seminar the work on writing aims to improve 
A confidence. 
B speed. 
C clarity. 
24 Reading sessions help students to read 
A analytically. 
B as fast as possible. 
C thoroughly. 
25 The seminar tries to 
A prepare learners physically. 
B encourage interest in learning. 
C develop literacy skills. 
61
```

[Original question page](assets/8319a837ff3259dac0b13487e3827b993af079376e78e483eeed077e243ebe99.jpg)

<!-- Source: /api/assets/205d87889466397e000f3f127b96bad3a1b6e695a4da00acc0f59de11bdbcb1c.jpg; PDF page 63; full -->

```text
Questions 26-30 
Choose the correct letter, A, B or C 
26 A key component of the course is learning how to 
A use time effectively. 
B stay healthy. 
C select appropriate materials. 
27 Students who want to do the 'Study for Success' seminar should 
A register with the Faculty Office. 
B contact their Course Convenor. 
C reserve a place in advance. 
28 The 'Learning Skills for University Study' course takes place on 
A Monday, Wednesday and Friday. 
B Monday, Tuesday and Wednesday. 
C Monday, Thursday and Friday. 
29 A feature of this course is 
A a physical training component. 
B advice on coping with stress. 
C a detailed weekly planner. 
30 The man chooses the 'Study for Success' seminar because 
A he is over forty. 
B he wants to start at the beginning. 
C he seeks to revise his skills. 
62
```

[Original question page](assets/205d87889466397e000f3f127b96bad3a1b6e695a4da00acc0f59de11bdbcb1c.jpg)

### Part 4

<!-- Source: /api/assets/891c1e152048797e7201881bcec8eba6ee4bc5bd720cef0b3355092bf1cdd81f.jpg; PDF page 64; full -->

```text
SECTION4 Questions31–40
Questions31 and32: Complete the notes below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
New Union Building
Procedures to establish student opinion:
• students were asked to give written suggestions on the building’s design
• these points informed the design of a (31) __________ (there were (32) __________ respondents)
• results collated and report produced by Union Committee
Questions33–37: Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
CHOICE OF SITE
Item | Site One | Site Two | Site Three
Location |City centre near Faculty of (33) __________|Outskirts near park|Out of town near the (34) __________
Advantages and/or disadvantages |Problems with (35) __________ and __________|Close to (36) __________|Access to living quarters.Larger site,so more (37) __________
```

[Original question page](assets/891c1e152048797e7201881bcec8eba6ee4bc5bd720cef0b3355092bf1cdd81f.jpg)

<!-- Source: /api/assets/e92d759d71971e99c14c674544806df14975613ebecc9d6e9da29a8df40248a5.jpg; PDF page 65; full -->

```text
Question38: Choose TWO letters A–G.
Which TWO facilities did the students request in the new Union building?
A a library
B a games room
C a student health centre
D a mini fitness centre
E a large swimming pool
F a travel agency
G a lecture theatre
Question39: Choose the correct letter,A,B or C.
Which argument was used AGAINST having a drama theatre?
A It would be expensive and no students would use it.
B It would be a poor use of resources because only a minority would use it.
C It could not accommodate large productions of plays.
Question40: Choose TWO letters A–E.
Which TWO security measures have been requested?
A closed-circuit TV
B show Union Card on entering the building
C show Union Card when asked
D spot searches of bags
E permanent Security Office on site
```

[Original question page](assets/e92d759d71971e99c14c674544806df14975613ebecc9d6e9da29a8df40248a5.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/cb4031335ceadd00707f3058f8a3e869d5540d355d8a05fa2bd8366cac9efbb3.jpg; PDF page 66; full -->

```text
READING 
READING PASSAGE 1 
You should spend about 20 minutes on Questions 1-13 which are based on Reading Passage 1 
below. 
Micro-Enterprise Credit 
for Street Youth 
'I am from a large, poor family and for many years we have done without breakfast. Ever 
since I joined the Street Kids International program I have been able to buy my family 
sugar and buns for breakfast. I have also bought myself decent second-hand clothes and 
shoes.' 
Doreen Soko 
'We've had business experience. Now I'm confident to expand what we've been doing. 
I've learnt cash management, and the way of keeping money so we save for re­
investment. Now business is a part of our lives. As well, we didn't know each other 
before-now we've made new friends.' 
Fan Kaoma 
Participants in the Youth Skills Enterprise Initiative Program, Zambia 
Introduction 
Although small-scale business training and credit programs have become more common throughout the 
world, relatively little attention has been paid to the need to direct such opportunities to young people. 
Even less attention has been paid to children living on the streets or in difficult circumstances . 
Over the past nine years, Street Kids International (S.K.I.) has been working with partner organisations 
in Africa, Latin America and India to support the economic lives of street children. The purpose of this 
paper is to share some of the lessons S.K.I. and our partners have learned. 
Background 
Typically, children do not end up on the streets due to a single cause, but to a combination of factors: a 
dearth of adequately funded schools, the demand for income at home, family breakdown and violence. 
The street may be attractive to children as a place to find adventurous play and money. However, it is also 
a place where some children are exposed, with little or no protection, to exploitative employment, urban 
crime, and abuse. 
65
```

[Original question page](assets/cb4031335ceadd00707f3058f8a3e869d5540d355d8a05fa2bd8366cac9efbb3.jpg)

<!-- Source: /api/assets/e5c16581ebd80cdbfdeafbee803cf0d0f4fc48731cbf6d0d8cf142e2a1076252.jpg; PDF page 67; full -->

```text
66 
Children who work on the streets are generally involved in unskilled, labour-intensive tasks which require 
long hours, such as shining shoes, carrying goods, guarding or washing cars, and informal trading. Some 
may also earn income through begging, or through theft and other illegal activities. At the same time, there 
are street children who take pride in supporting themselves and their families and who often enjoy their 
work. Many children may choose entrepreneurship because it allows them a degree of independence, is 
less exploitative than many forms of paid employment, and is flexible enough to allow them to participate 
in other activities such as education and domestic tasks. 
Street Business Partnerships 
S.K.I. has worked with partner organisations in Latin America, Africa and India to develop innovative 
opportunities for street children to earn income. 
• The S.K.I. Bicycle Courier Service first started in the Sudan . Participants in this enterprise were sup­
plied with bicycles, which they used to deliver parcels and messages, and which they were required 
to pay for gradually from their wages. A similar program was taken up in Bangalore, India. 
• Another successful project, the Shoe Shine Collective, was a partnership program with the Y.W.C.A. 
in the Dominican Republic. In this project, participants were lent money to purchase shoe shine 
boxes. They were also given a safe place to store their equipment, and facilities for individual savings 
plans. 
• The Youth Skills Enterprise Initiative in Zambia is a joint program with the Red Cross Society and the 
Y.W.C.A. Street youths are supported to start their own small business through business training, life 
skills training and access to credit. 
Lessons Learned 
The following lessons have emerged from the programs that S.K.I. and partner organisations have 
created. 
• Being an entrepreneur is not for everyone, nor for every street child. Ideally, potential participants will 
have been involved in the organisation's programs for at least six months, and trust and relationship­
building will have already been established. 
• The involvement of the participants has been essential to the development of relevant programs. 
When children have had a major role in determining procedures, they are more likely to abide by and 
enforce them. 
• It is critical for all loans to be linked to training programs that include the development of basic busi­
ness and life skills. 
• There are tremendous advantages to involving parents or guardians in the program, where such rela­
tionships exist. Home visits allow staff the opportunity to know where the participants live, and to 
understand more about each individual's situation . 
• Small loans are provided initially for purchasing fixed assets such as bicycles, shoe shine kits and 
basic building materials for a market stall. As the entrepreneurs gain experience, the enterprises can 
be gradually expanded and consideration can be given to increasing loan amounts. The loan amounts 
in S.K.I. programs have generally ranged from US$30–$100. 
• All S.K.I. programs have charged interest on the loans, primarily to get the entrepreneurs used to the 
concept of paying interest on borrowed money. Generally the rates have been modest (lower than 
bank rates). 
Conclusion 
There is a need to recognise the importance of access to credit for impoverished young people seeking 
to fulfil economic needs . The provision of small loans to support the entrepreneurial dreams and ambi­
tions of youth can be an effective means to help them change their lives. However, we believe that credit 
must be extended in association with other types of support that help participants develop critical life skills 
as well as productive businesses.
```

[Original question page](assets/e5c16581ebd80cdbfdeafbee803cf0d0f4fc48731cbf6d0d8cf142e2a1076252.jpg)

<!-- Source: /api/assets/887bb48a1b9ef986a877694c3afd9f044972a8f82d81ef5a55416093e96bbe39.jpg; PDF page 68; full -->

```text
Questions 1-4 
Choose the correct letter, A, B, C or D. 
Write your answers in boxes 1-4 on your answer sheet. 
1 The quotations in the box at the beginning of the article 
A exemplify the effects of S.K.I. 
B explain why S.K.I. was set up. 
C outline the problems of street children . 
D highlight the benefits to society of S.K.I. 
2 The main purpose of S.K.I. is to 
A draw the attention of governments to the problem of street children . 
B provide schools and social support for street children. 
C encourage the public to give money to street children. 
D give business training and loans to street children. 
3 Which of the following is mentioned by the writer as a reason why children end up 
living on the streets? 
A unemployment 
B war 
C poverty 
D crime 
4 In order to become more independent, street children may 
A reject paid employment. 
B leave their families. 
C set up their own businesses. 
D employ other children. 
67
```

[Original question page](assets/887bb48a1b9ef986a877694c3afd9f044972a8f82d81ef5a55416093e96bbe39.jpg)

<!-- Source: /api/assets/faa61640df3781869acefa5f8e33bd829a79558b748484eaf161b57d6f84dc24.jpg; PDF page 69; full -->

```text
Questions5–8: Complete the table below. Choose NO MORE THAN THREE WORDS from Reading Passage1 for each answer. Write your answers in boxes5–8 on your answer sheet.
Country | Organisations Involved | Type of Project | Support Provided
(5) __________ and __________ |S.K.I.|courier service|provision of (6) __________
Dominican Republic |S.K.I.;Y.W.C.A.|(7) __________|loans;storage facilities;savings plans
Zambia |S.K.I.;The Red Cross;Y.W.C.A.|setting up small businesses|business training;(8) __________ training;access to credit
```

[Original question page](assets/faa61640df3781869acefa5f8e33bd829a79558b748484eaf161b57d6f84dc24.jpg)

<!-- Source: /api/assets/cc98f7187611abd98d26a93a39a594eadd757597c222cefc8f2b530e4fea5153.jpg; PDF page 70; full -->

```text
Questions 9-12 
Do the following statements agree with the claims of the writer in Reading Passage 1? 
In boxes 9-12 on your answer sheet write 
YES if the statement agrees with the claims of the writer 
NO if the statement contradicts the claims of the writer 
NOT GIVEN if it is impossible to say what the writer thinks about this 
9 Any street child can set up their own small business if given enough support. 
10 In some cases, the families of street children may need financial support from S.K.I. 
11 Only one fixed loan should be given to each child. 
12 The children have to pay back slightly more money than they borrowed. 
Question 13 
Choose the correct letter, A, B, C or D. 
Write your answer in box 13 on your answer sheet. 
The writers conclude that money should only be lent to street children 
A as part of a wider program of aid. 
B for programs that are not too ambitious. 
C when programs are supported by local businesses. 
D if the projects planned are realistic and useful. 
69
```

[Original question page](assets/cc98f7187611abd98d26a93a39a594eadd757597c222cefc8f2b530e4fea5153.jpg)

<!-- Source: /api/assets/f76db711261f97f828d1d560657e2851d6df181107ef5260c983495fdf49ed85.jpg; PDF page 71; full -->

```text
READING PASSAGE 2 
You should spend about 20 minutes on Questions 14-26 which are based on Reading Passage 2 
on the following pages. 
Questions 14-17 
Reading Passage 2 has four sections A-D. 
Choose the correct heading for each section from the list of headings below. 
Write the correct number i-vi in boxes 14-17 on your answer sheet. 
14 Section A 
15 Section B 
16 Section C 
17 Section D 
70 
List of Headings 
i Causes of volcanic eruption 
ii Efforts to predict volcanic eruption 
iii Volcanoes and the features of our planet 
iv Different types of volcanic eruption 
v International relief efforts 
vi The unpredictability of volcanic eruptions
```

[Original question page](assets/f76db711261f97f828d1d560657e2851d6df181107ef5260c983495fdf49ed85.jpg)

<!-- Source: /api/assets/4a6b8dbaecb86e97292b5bcb4d25d1be39fc8e7fa3906f8b7f0fc510c2bdc015.jpg; PDF page 72; full -->

```text
Volcanoes­
earth-shattering 
news 
When Mount Pinatubo suddenly erupted on 9 June 1991, the power of volcanoes 
past and present again hit the headlines 
A Volcanoes are the ultimate earth-moving machinery. A violent eruption can blow 
the top few kilometres off a mountain, scatter fine ash practically all over the globe 
and hurl rock fragments into the stratosphere to darken the skies a continent away. 
But the classic eruption- cone-shaped mountain, big bang, mushroom cloud and 
surges of molten lava - is only a tiny part of a global story. Vulcanism, the name 
given to volcanic processes, really has shaped the world. Eruptions have rifted con­
tinents, raised mountain chains, constructed islands and shaped the topography of 
the earth . The entire ocean floor has a basement of volcanic basalt . 
Volcanoes have not only made the continents, they are also thought to have 
made the world's first stable atmosphere and provided all the water for the oceans, 
rivers and ice-caps . There are now about 600 active volcanoes. Every year they 
add two or three cubic kilometres of rock to the continents . Imagine a similar 
number of volcanoes smoking away for the last 3,500 million years . That is enough 
rock to explain the continental crust. 
What comes out of volcanic craters is mostly gas. More than 90% of this gas is 
water vapour from the deep earth : enough to explain, over 3,500 million years, 
the water in the oceans. The rest of the gas is nitrogen, carbon dioxide, sulphur 
dioxide, methane, ammonia and hydrogen. The quantity of these gases, again mul­
tiplied over 3,500 million years, is enough to explain the mass of the world's atmos­
phere. We are alive because volcanoes provided the soil, air and water we need. 
B Geologists consider the earth as having a molten core, surrounded by a semi-molten 
mantle and a brittle, outer skin. It helps to think of a soft-boiled egg with a runny 
yolk, a firm but squishy white and a hard shell. If the shell is even slightly cracked 
during boiling, the white material bubbles out and sets like a tiny mountain chain 
over the crack - like an archipelago of volcanic islands such as the Hawaiian 
Islands. But the earth is so much bigger and the mantle below is so much hotter. 
Even though the mantle rocks are kept solid by overlying pressure, they can still 
slowly 'flow' like thick treacle. The flow, thought to be in the form of convection cur­
rents, is powerful enough to fracture the 'eggshell' of the crust into plates, and keep 
them bumping and grinding against each other, or even overlapping, at the rate of 
a few centimetres a year. These fracture zones, where the collisions occur, are 
where earthquakes happen. And, very often, volcanoes. 
71
```

[Original question page](assets/4a6b8dbaecb86e97292b5bcb4d25d1be39fc8e7fa3906f8b7f0fc510c2bdc015.jpg)

<!-- Source: /api/assets/eb78f91ce7849072cf9c4910581a570ffce3b727ee1e3b15c33b1aa9ffc14aa3.jpg; PDF page 73; full -->

```text
C These zones are lines of weakness, or hot spots. Every eruption is different, but put

at its simplest, where there are weaknesses, rocks deep in the mantle, heated to

1,350°C, will start to expand and rise. As they do so, the pressure drops, and they

expand and become liquid and rise more swiftly.



Sometimes it is slow: vast bubbles of magma — molten rock from the mantle —

inch towards the surface, cooling slowly, to show through as granite extrusions (as

on Skye, or the Great Whin Sill, the lava dyke squeezed out like toothpaste that

carries part of Hadrian’s Wall in northern England). Sometimes — as in Northern

Ireland, Wales and the Karoo in South Africa — the magma rose faster, and then

flowed out horizontally on to the surface in vast thick sheets. In the Deccan plateau

in western India, there are more than two million cubic kilometres of lava, some of

it 2,400 metres thick, formed over 500,000 years of slurping eruption.



Sometimes the magma moves very swiftly indeed. It does not have time to cool

as it surges upwards. The gases trapped inside the boiling rock expand suddenly,

the lava glows with heat, it begins to froth, and it explodes with tremendous force.

Then the slightly cooler lava following it begins to flow over the lip of the crater. It

happens on Mars, it happened on the moon, it even happens on some of the moons

of Jupiter and Uranus. By studying the evidence, vulcanologists can read the force

of the great blasts of the past. Is the pumice light and full of holes? The explosion

was tremendous. Are the rocks heavy, with huge crystalline basalt shapes, like the

Giant's Causeway in Northern Ireland? It was a slow, gentle eruption.



The biggest eruptions are deep on the mid-ocean floor, where new lava is forcing

the continents apart and widening the Atlantic by perhaps five centimetres a year.

Look at maps of volcanoes, earthquakes and island chains like the Philippines and

Japan, and you can see the rough outlines of what are called tectonic plates — the

plates which make up the earth’s crust and mantle. The most dramatic of these is

the Pacific ‘ring of fire’ where there have been the most violent explosions — Mount

Pinatubo near Manila, Mount St Helen’s in the Rockies and El Chichén in Mexico

about a decade ago, not to mention world-shaking blasts like Krakatoa in the Sunda

Straits in 1883.



D But volcanoes are not very predictable. That is because geological time is not like

human time. During quiet periods, volcanoes cap themselves with their own lava

by forming a powerful cone from the molten rocks slopping over the rim of the

crater; later the lava cools slowly into a huge, hard, stable plug which blocks any

further eruption until the pressure below becomes irresistible. In the case of Mount

Pinatubo, this took 600 years.



Then, sometimes, with only a small warning, the mountain blows its top. It did this



at Mont Pelée in Martinique at 7.49 a.m. on 8 May, 1902. Of a town of 28,000,

only two people survived. In 1815, a sudden blast removed the top 1,280 metres

of Mount Tambora in Indonesia. The eruption was so fierce that dust thrown into the

stratosphere darkened the skies, cancelling the following summer in Europe and

North America. Thousands starved as the harvests failed, after snow in June and

frosts in August. Volcanoes are potentially world news, especially the quiet ones.



72
```

[Original question page](assets/eb78f91ce7849072cf9c4910581a570ffce3b727ee1e3b15c33b1aa9ffc14aa3.jpg)

<!-- Source: /api/assets/a86e867fabac5847a9d8065f460a21f7871edec2545a70757e4ec451c08ee32d.jpg; PDF page 74; full -->

```text
Questions 18-21 
Answer the questions below using NO MORE THAN THREE WORDS AND/OR A 
NUMBER from the passage for each answer. 
Write your answers in boxes 18-21 on your answer sheet. 
18 What are the sections of the earth's crust, often associated with volcanic activity, called? 
19 What is the name given to molten rock from the mantle? 
20 What is the earthquake zone on the Pacific Ocean called? 
21 For how many years did Mount Pinatubo remain inactive? 
Questions 22-26 
Complete the summary below. 
Choose NO MORE THAN TWO WORDS from the passage for each answer. 
Write your answers in boxes 22-26 on your answer sheet. 
Volcanic eruptions have shaped the earth's land surface. They may also have produced the 
world's atmosphere and 22 ...... . Eruptions occur when molten rocks from the earth's mantle 
rise and expand. When they become liquid, they move more quickly through cracks in the 
surface. There are different types of eruption. Sometimes the 23 .... .. moves slowly and forms 
outcrops of granite on the earth's surface. When it moves more quickly it may flow out in 
thick horizontal sheets. Examples of this type of eruption can be found in Northern Ireland, 
Wales, South Africa and 24 ....... A third type of eruption occurs when the lava emerges 
very quickly and 25 ...... violently. This happens because the magma moves so suddenly that 
26 ..... . are emitted. 
73
```

[Original question page](assets/a86e867fabac5847a9d8065f460a21f7871edec2545a70757e4ec451c08ee32d.jpg)

<!-- Source: /api/assets/4d6391e838fd81834cb367023cc4cf4cc760f39285bdd1d50c75e70f05887e68.jpg; PDF page 75; full -->

```text
READING PASSAGE 3 
You should spend about 20 minutes on Questions 27-40 which are based on Reading Passage 3 
below. 
74 
Obtaining 
Linguistic 
Data 
A Many procedures are available for obtaining 
data about a language. They range from a 
carefully planned, intensive field investiga­
tion in a foreign country to a casual intro­
spection about one's mother tongue carried 
out in an armchair at home. 
B In all cases, someone has to act as a source 
of language data - an informant. Informants 
are (ideally) native speakers of a language, 
who provide utterances for analysis and 
other kinds of information about the lan­
guage (e.g. translations, comments about 
correctness, or judgements on usage). Often, 
when studying their mother tongue, linguists 
act as their own informants, judging the 
ambiguity, acceptability, or other properties 
of utterances against their own intuitions. The 
convenience of this approach makes it 
widely used, and it is considered the norm in 
the generative approach to linguistics. But a 
linguist's personal judgements are often 
uncertain, or disagree with the judgements of 
other linguists, at which point recourse is 
needed to more objective methods of 
enquiry, using non-linguists as informants. 
The latter procedure is unavoidable when 
working on foreign languages, or child 
speech. 
C Many factors must be considered when 
selecting informants - whether one is 
working with single speakers (a common sit­
uation when languages have not been 
described before) , two people interacting, 
small groups or large-scale samples. Age, 
sex, social background and other aspects of 
identity are important, as these factors are 
known to influence the kind of language 
used. The topic of conversation and the char­
acteristics of the social setting (e.g. the level 
of formality) are also highly relevant, as are 
the personal qualities of the informants (e.g. 
their fluency and consistency). For larger 
studies, scrupulous attention has been paid 
to the sampling theory employed, and in all 
cases, decisions have to be made about the 
best investigative techniques to use. 
D Today, researchers often tape-record infor­
mants. This enables the linguist's claims about 
· the language to be checked, and provides a
```

[Original question page](assets/4d6391e838fd81834cb367023cc4cf4cc760f39285bdd1d50c75e70f05887e68.jpg)

<!-- Source: /api/assets/664d0ade835d0c41bead8a2a31bb96f004902a129965b68b4f6ebfcda061b336.jpg; PDF page 76; full -->

```text
way of making those claims more accurate 
('difficult' pieces of speech can be listened 
to repeatedly). But obtaining naturalistic, 
good-quality data is never easy. People talk 
abnormally when they know they are being 
recorded , and sound quality can be poor. A 
variety of tape-recording procedures have 
thus been devised to minimise the · observer's 
paradox' (how to observe the way people 
behave when they are not being observed). 
Some recordings are made without the 
speakers being aware of the fact - a proce­
dure that obtains very natural data, though 
ethical objections must be anticipated. 
Alternatively, attempts can be made to make 
the speaker forget about the recording, such 
as keeping the tape recorder out of sight, or 
using radio microphones . A useful technique 
is to introduce a topic that quickly involves 
the speaker, and stimulates a natural language 
style (e.g. asking older informants about how 
times have changed in their locality). 
E An audio tape recording does not solve all 
the linguist's problems, however. Speech is 
often unclear and ambiguous. Where possi­
ble, therefore, the recording has to be sup­
plemented by the observer's written 
comments on the non-verbal behaviour of 
the participants, and about the context in 
general. A facial expression, for example, can 
dramatically alter the meaning of what is said. 
Video recordings avoid these problems to a 
large extent, but even they have limitations 
(the camera cannot be everywhere), and 
transcriptions always benefit from any addi­
tional commentary provided by an observer. 
F Linguists also make great use of structured 
sessions, in which they systematically ask 
their informants for utterances that describe 
certain actions, objects or behaviour. With a 
bilingual informant, or through use of an inter-
preter, it is possible to use translation tech­
niques ('How do you say table in your lan­
guage?'). A large number of points can be 
covered in a short time, using interview work­
sheets and questionnaires. Often, the 
researcher wishes to obtain information 
about just a single variable, in which case a 
restricted set of questions may be used: a 
particular feature of pronunciation, for 
example, can be elicited by asking the infor­
mant to say a restricted set of words. There 
are also several direct methods of elicitation, 
such as asking informants to fill in the blanks 
in a substitution frame (e.g. I_ see a car), 
or feeding them the wrong stimulus for cor­
rection ('Is it possible to say I no can see?'). 
G A representative sample of language, com­
piled for the purpose of linguistic analysis, is 
known as a corpus. A corpus enables the lin­
guist to make unbiased statements about fre­
quency of usage, and it provides accessible 
data for the use of different researchers. Its 
range and size are variable. Some corpora 
attempt to cover the language as a whole, 
taking extracts from many kinds of text; others 
are extremely selective, providing a collec­
tion of material that deals only with a particu­
lar linguistic feature. The size of the corpus 
depends on practical factors, such as the time 
available to collect, process and store the 
data: it can take up to several hours to provide 
an accurate transcription of a few minutes of 
speech. Sometimes a small sample of data 
will be enough to decide a linguistic hypoth­
esis; by contrast, corpora in major research 
projects can total millions of words. An 
important principle is that all corpora, what­
ever their size, are inevitably limited in their 
coverage, and always need to be supple­
mented by data derived from the intuitions of 
native speakers of the language, through 
either introspection or experimentation. -
75
```

[Original question page](assets/664d0ade835d0c41bead8a2a31bb96f004902a129965b68b4f6ebfcda061b336.jpg)

<!-- Source: /api/assets/1fe245d7d0d461e291d6301fb45fc26575dbc5dd6e5a74b21e5461147c3fe03b.jpg; PDF page 77; full -->

```text
Questions 27-31 
Reading Passage 3 has seven paragraphs labelled A-G. 
Which paragraph contains the following information? 
Write the correct letter A-Gin boxes 27-31 on your answer sheet. 
NB You may use any letter more than once. 
27 the effect of recording on the way people talk 
28 the importance of taking notes on body language 
29 the fact that language is influenced by social situation 
30 how informants can be helped to be less self-conscious 
31 various methods that can be used to generate specific data 
Questions 32-36 
Complete the table below. 
Choose NO MORE THAN THREE WORDS from the passage for each answer. 
Write your answers in boxes 32-36 on your answer sheet. 
METHODS OF OBTAINING LINGUISTIC DATA | ADVANTAGES | DISADVANTAGES
(32) __________ as informant |convenient|method of enquiry not objective enough
non-linguist as informant |necessary with (33) __________ and child speech|the number of factors to be considered
recording an informant |allows linguists’ claims to be checked|(34) __________ of sound
videoing an informant |allows speakers’ (35) __________ to be observed|(36) __________ might miss certain things
```

[Original question page](assets/1fe245d7d0d461e291d6301fb45fc26575dbc5dd6e5a74b21e5461147c3fe03b.jpg)

<!-- Source: /api/assets/92d4979e949c0f8824e01f01abd952c8cb264edcebdb473fb433f5e85746b234.jpg; PDF page 78; full -->

```text
Questions 37-40 
Complete the summary of paragraph G below. 
Choose NO MORE THAN THREE WORDS from the passage for each answer. 
Write your answers in boxes 37-40 on your answer sheet. 
A linguist can use a corpus to comment objectively on 37 ....... Some corpora include a wide 
range of language while others are used to focus on a 38 .... .. . The length of time the 
process takes will affect the 39 ..... . of the corpus. No corpus can ever cover the whole 
language and so linguists often find themselves relying on the additional information that 
can be gained from the 40 .. .. .. of those who speak the language concerned. 
77
```

[Original question page](assets/92d4979e949c0f8824e01f01abd952c8cb264edcebdb473fb433f5e85746b234.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/d9f9d689ef6251a10d4ea7401d7c428e31c1e240344ef371ae792f39525a3637.jpg; PDF page 79; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows the different levels of post-school qualifications in Australia and the proportion of men and women who held them in 1999.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original table or chart is retained below.]
```

[Original question page](assets/d9f9d689ef6251a10d4ea7401d7c428e31c1e240344ef371ae792f39525a3637.jpg)

![Original figure](assets/d9f9d689ef6251a10d4ea7401d7c428e31c1e240344ef371ae792f39525a3637.jpg)

### Task 2

<!-- Source: /api/assets/90fc5249138043591a75f4d28f95dfc73f7ef811e07cc906af9ac09504744802.jpg; PDF page 80; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Creative artists should always be given the freedom to express their own ideas (in words, pictures, music or film) in whichever way they wish. There should be no government restrictions on what they do.

To what extent do you agree or disagree with this opinion?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/90fc5249138043591a75f4d28f95dfc73f7ef811e07cc906af9ac09504744802.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/30d8ed1af0e2dcdf9c0418536a9c5c5d8c5e3477a9c4c1e555ba31cd9138beb2.jpg; PDF page 81; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself. his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Leisure 
• Do you have any hobbies or interests? [What are they?] 
• How did you become interested in (whatever hobby/interest the candidate mentions)? 
• What is there to do in your free time in (candidate's home town/village)? 
• How do you usually spend your holidays? 
• Is there anywhere you would particularly like to visit? [Why?] 
PART 2 
Describe a river, lake or sea which you like. 
You should say: 
what the river, lake or sea is called 
where it is 
what the land near it is like 
and explain why you like this river, lake or sea. 
You will have to talk about the topic 
for one to two minutes . 
You have one minute to think about 
what you 're going to say. 
You can make some notes to help you 
if you wish. 

PART 3 
Discussion topics: 
Water-based leisure activities 
Example questions : 
What do people enjoy doing when they visit rivers, lakes or the sea? Why do you think these 
activities are popular? 
What benefits do you think people get from the activities they enjoy in the water? 
What are the different advantages of going to the sea or to a swimming pool to enjoy 
yourself? What do you think the disadvantages are? 
The economic importance of rivers, lakes and the sea 
Example questions: 
How does water transport, like boats and ships , compare with other kinds? Are there any 
advantages/disadvantages of water transport? 
How important is it for a town or city to be located near a river or the sea? Why? 
Have there been any changes in the number of jobs available in fishing and water transport 
industries , do you think? Why do you think this is? 
80
```

[Original question page](assets/30d8ed1af0e2dcdf9c0418536a9c5c5d8c5e3477a9c4c1e555ba31cd9138beb2.jpg)

### Part 2

<!-- Source: /api/assets/30d8ed1af0e2dcdf9c0418536a9c5c5d8c5e3477a9c4c1e555ba31cd9138beb2.jpg; PDF page 81; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself. his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Leisure 
• Do you have any hobbies or interests? [What are they?] 
• How did you become interested in (whatever hobby/interest the candidate mentions)? 
• What is there to do in your free time in (candidate's home town/village)? 
• How do you usually spend your holidays? 
• Is there anywhere you would particularly like to visit? [Why?] 
PART 2 
Describe a river, lake or sea which you like. 
You should say: 
what the river, lake or sea is called 
where it is 
what the land near it is like 
and explain why you like this river, lake or sea. 
You will have to talk about the topic 
for one to two minutes . 
You have one minute to think about 
what you 're going to say. 
You can make some notes to help you 
if you wish. 

PART 3 
Discussion topics: 
Water-based leisure activities 
Example questions : 
What do people enjoy doing when they visit rivers, lakes or the sea? Why do you think these 
activities are popular? 
What benefits do you think people get from the activities they enjoy in the water? 
What are the different advantages of going to the sea or to a swimming pool to enjoy 
yourself? What do you think the disadvantages are? 
The economic importance of rivers, lakes and the sea 
Example questions: 
How does water transport, like boats and ships , compare with other kinds? Are there any 
advantages/disadvantages of water transport? 
How important is it for a town or city to be located near a river or the sea? Why? 
Have there been any changes in the number of jobs available in fishing and water transport 
industries , do you think? Why do you think this is? 
80
```

[Original question page](assets/30d8ed1af0e2dcdf9c0418536a9c5c5d8c5e3477a9c4c1e555ba31cd9138beb2.jpg)

### Part 3

<!-- Source: /api/assets/30d8ed1af0e2dcdf9c0418536a9c5c5d8c5e3477a9c4c1e555ba31cd9138beb2.jpg; PDF page 81; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself. his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Leisure 
• Do you have any hobbies or interests? [What are they?] 
• How did you become interested in (whatever hobby/interest the candidate mentions)? 
• What is there to do in your free time in (candidate's home town/village)? 
• How do you usually spend your holidays? 
• Is there anywhere you would particularly like to visit? [Why?] 
PART 2 
Describe a river, lake or sea which you like. 
You should say: 
what the river, lake or sea is called 
where it is 
what the land near it is like 
and explain why you like this river, lake or sea. 
You will have to talk about the topic 
for one to two minutes . 
You have one minute to think about 
what you 're going to say. 
You can make some notes to help you 
if you wish. 

PART 3 
Discussion topics: 
Water-based leisure activities 
Example questions : 
What do people enjoy doing when they visit rivers, lakes or the sea? Why do you think these 
activities are popular? 
What benefits do you think people get from the activities they enjoy in the water? 
What are the different advantages of going to the sea or to a swimming pool to enjoy 
yourself? What do you think the disadvantages are? 
The economic importance of rivers, lakes and the sea 
Example questions: 
How does water transport, like boats and ships , compare with other kinds? Are there any 
advantages/disadvantages of water transport? 
How important is it for a town or city to be located near a river or the sea? Why? 
Have there been any changes in the number of jobs available in fishing and water transport 
industries , do you think? Why do you think this is? 
80
```

[Original question page](assets/30d8ed1af0e2dcdf9c0418536a9c5c5d8c5e3477a9c4c1e555ba31cd9138beb2.jpg)
