# 剑雅 4 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 157

TEST3 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 1½years
2 Forest / Forrest
3 Academic
4 Thursday
5 B
6 B
7 A
8 deposit
9 monthly
10 telephone / phone
Section2, Questions11–20
11 C
12 A
13 C
14 B
15 lighting / lights / light
16 adult / adults
17 (at) Studio Theatre / (the) Studio Theatre / (at) Studio Theater / (the) Studio Theater
18 the whole family / all the family / families
19 (in) City Gardens / the City Gardens / outdoors
20 young children / younger children / children
Section3, Questions21–30
21 A
22 B
23 C
24 A
25 B
26 A
27 C
28 B
29 B
30 B
Section4, Questions31–40
31 questionnaire
32 approximately2,000 / about2,000
33 Education
34 halls of residence / living quarters
35 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: traffic;parking
36 (most) lecture rooms / lecture halls / lecture theatres / lecture theaters
37 (choice of) facilities / (room for) facilities
38 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: D;F
39 B
40 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: A;C
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. 1½ years / 1.5 years

2. Forest / Forrest

3. Academic

4. Thursday

5. B

6. B

7. A

8. deposit

9. monthly

10. telephone / phone

### Part 2 · source page 157

TEST3 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 1½years
2 Forest / Forrest
3 Academic
4 Thursday
5 B
6 B
7 A
8 deposit
9 monthly
10 telephone / phone
Section2, Questions11–20
11 C
12 A
13 C
14 B
15 lighting / lights / light
16 adult / adults
17 (at) Studio Theatre / (the) Studio Theatre / (at) Studio Theater / (the) Studio Theater
18 the whole family / all the family / families
19 (in) City Gardens / the City Gardens / outdoors
20 young children / younger children / children
Section3, Questions21–30
21 A
22 B
23 C
24 A
25 B
26 A
27 C
28 B
29 B
30 B
Section4, Questions31–40
31 questionnaire
32 approximately2,000 / about2,000
33 Education
34 halls of residence / living quarters
35 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: traffic;parking
36 (most) lecture rooms / lecture halls / lecture theatres / lecture theaters
37 (choice of) facilities / (room for) facilities
38 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: D;F
39 B
40 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: A;C
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. C

12. A

13. C

14. B

15. lighting / lights / light

16. adult / adults

17. Studio Theatre / at Studio Theatre / the Studio Theatre / Studio Theater / at Studio Theater / the Studio Theater

18. the whole family / all the family / families

19. City Gardens / in City Gardens / the City Gardens / outdoors

20. young children / younger children / children

### Part 3 · source page 157

TEST3 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 1½years
2 Forest / Forrest
3 Academic
4 Thursday
5 B
6 B
7 A
8 deposit
9 monthly
10 telephone / phone
Section2, Questions11–20
11 C
12 A
13 C
14 B
15 lighting / lights / light
16 adult / adults
17 (at) Studio Theatre / (the) Studio Theatre / (at) Studio Theater / (the) Studio Theater
18 the whole family / all the family / families
19 (in) City Gardens / the City Gardens / outdoors
20 young children / younger children / children
Section3, Questions21–30
21 A
22 B
23 C
24 A
25 B
26 A
27 C
28 B
29 B
30 B
Section4, Questions31–40
31 questionnaire
32 approximately2,000 / about2,000
33 Education
34 halls of residence / living quarters
35 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: traffic;parking
36 (most) lecture rooms / lecture halls / lecture theatres / lecture theaters
37 (choice of) facilities / (room for) facilities
38 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: D;F
39 B
40 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: A;C
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. A

22. B

23. C

24. A

25. B

26. A

27. C

28. B

29. B

30. B

### Part 4 · source page 157

TEST3 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 1½years
2 Forest / Forrest
3 Academic
4 Thursday
5 B
6 B
7 A
8 deposit
9 monthly
10 telephone / phone
Section2, Questions11–20
11 C
12 A
13 C
14 B
15 lighting / lights / light
16 adult / adults
17 (at) Studio Theatre / (the) Studio Theatre / (at) Studio Theater / (the) Studio Theater
18 the whole family / all the family / families
19 (in) City Gardens / the City Gardens / outdoors
20 young children / younger children / children
Section3, Questions21–30
21 A
22 B
23 C
24 A
25 B
26 A
27 C
28 B
29 B
30 B
Section4, Questions31–40
31 questionnaire
32 approximately2,000 / about2,000
33 Education
34 halls of residence / living quarters
35 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: traffic;parking
36 (most) lecture rooms / lecture halls / lecture theatres / lecture theaters
37 (choice of) facilities / (room for) facilities
38 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: D;F
39 B
40 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: A;C
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. questionnaire

32. approximately 2,000 / approximately 2000 / about 2,000 / about 2000

33. Education

34. halls of residence / living quarters

35. traffic parking / traffic, parking / traffic and parking / traffic & parking / traffic; parking / traffic/parking / traffic,parking / parking traffic / parking, traffic / parking and traffic / parking & traffic / parking; traffic / parking/traffic / parking,traffic

36. lecture rooms / most lecture rooms / lecture halls / lecture theatres / lecture theaters

37. facilities / choice of facilities / room for facilities

38. D F / D, F / D and F / D & F / D; F / D/F / D,F / DF / F D / F, D / F and D / F & D / F; D / F/D / F,D / FD

39. B

40. A C / A, C / A and C / A & C / A; C / A/C / A,C / AC / C A / C, A / C and A / C & A / C; A / C/A / C,A / CA

## A 类阅读

### Academic Reading · source page 158

ACADEMIC READING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Reading Passage1, Questions1–13
1 A
2 D
3 C
4 C
5 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: Sudan;India
6 bicycles
7 Shoe Shine / Shoe Shine Collective
8 life skills
9 NO
10 NOT GIVEN
11 NO
12 YES
13 A
Reading Passage2, Questions14–26
14 iii
15 i
16 iv
17 vi
18 plates / the plates / the tectonic plates
19 magma
20 ring of fire
21 600 /600years/for600years
22 water / the water / oceans / the oceans
23 lava / magma / molten rock
24 India / western India
25 explodes
26 gases / the gases / trapped gases
Reading Passage3, Questions27–40
27 D
28 E
29 C
30 D
31 F
32 (the) linguist (acts) / (the) linguists (act)
33 foreign languages
34 quality / the quality / the poor quality
35 non-verbal behaviour / non-verbal behavior / facial expression / facial expressions
36 camera / video camera / recording / video recording
37 frequency of usage / usage frequency
38 particular linguistic feature
39 size
40 intuitions
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. A

2. D

3. C

4. C

5. Sudan India / Sudan, India / Sudan and India / Sudan & India / Sudan; India / Sudan/India / Sudan,India / India Sudan / India, Sudan / India and Sudan / India & Sudan / India; Sudan / India/Sudan / India,Sudan

6. bicycles

7. Shoe Shine / Shoe Shine Collective

8. life skills

9. NO

10. NOT GIVEN

11. NO

12. YES

13. A

14. iii

15. i

16. iv

17. vi

18. plates / the plates / the tectonic plates

19. magma

20. ring of fire

21. 600 / 600 years / for 600 years

22. water / the water / oceans / the oceans

23. lava / magma / molten rock

24. India / western India

25. explodes

26. gases / the gases / trapped gases

27. D

28. E

29. C

30. D

31. F

32. linguist / linguist acts / the linguist / the linguist acts / linguists / linguists act / the linguists / the linguists act

33. foreign languages

34. quality / the quality / the poor quality

35. non-verbal behaviour / non-verbal behavior / facial expression / facial expressions

36. camera / video camera / recording / video recording

37. frequency of usage / usage frequency

38. particular linguistic feature

39. size

40. intuitions

## A 类写作

### Writing material: c4-t3-w-1

Original chart and gender legend inspected at full resolution. Title: Post-school qualifications in Australia according to gender 1999. Black bars are FEMALES; light bars are MALES. Units are percentages within each qualification category. Approximate male/female splits: skilled vocational diploma 90%/10%; undergraduate diploma 30%/70%; bachelor's degree 45%/55%; postgraduate diploma 70%/30%; master's degree 60%/40%. Each pair represents the gender distribution within that qualification, not the percentage of all men or all women earning it. Men predominate in skilled vocational and postgraduate diplomas and master's degrees; women predominate in undergraduate diplomas and slightly in bachelor's degrees. Skilled vocational diplomas show the largest gender gap; bachelor's degrees the smallest. Do not reverse the legend or invent absolute numbers or changes over time.



### Writing material: c4-t3-w-2

The stated position is an opinion for evaluation. Supported agreement, disagreement or qualification is permitted; do not impose a predetermined position.



## 口语
