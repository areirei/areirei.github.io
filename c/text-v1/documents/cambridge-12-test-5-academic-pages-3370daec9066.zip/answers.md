# 剑雅 12 · Test 5 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 117

TEST 5 LISTENING
1 mountains
2 horse
3 garden(s)
4 lunch
5 map
6 experience
7 Ratchesons
8 helmet
9 shops
10 267
11 A
12 A
13 C
14 C
15 A
16 E
17 F
18 C
19 D
20 B
21 B
22 C
23 C
24 budget
25 employment
26 safety
27 insurance
28 diary
29 database
30 museum
31 damage
32 side effects
33 bridge
34 confusion
35 smartphone
36 resources
37 unnecessary/not necessary
38 chocolate bar
39 problem
40 market share
15&16 IN EITHER ORDER: A,E
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. mountains

2. horse

3. garden / gardens

4. lunch

5. map

6. experience

7. Ratchesons

8. helmet

9. shops

10. 267

### Part 2 · source page 117

TEST 5 LISTENING
1 mountains
2 horse
3 garden(s)
4 lunch
5 map
6 experience
7 Ratchesons
8 helmet
9 shops
10 267
11 A
12 A
13 C
14 C
15 A
16 E
17 F
18 C
19 D
20 B
21 B
22 C
23 C
24 budget
25 employment
26 safety
27 insurance
28 diary
29 database
30 museum
31 damage
32 side effects
33 bridge
34 confusion
35 smartphone
36 resources
37 unnecessary/not necessary
38 chocolate bar
39 problem
40 market share
15&16 IN EITHER ORDER: A,E
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A

12. A

13. C

14. C

15. A / E

16. A / E

17. F

18. C

19. D

20. B

### Part 3 · source page 117

TEST 5 LISTENING
1 mountains
2 horse
3 garden(s)
4 lunch
5 map
6 experience
7 Ratchesons
8 helmet
9 shops
10 267
11 A
12 A
13 C
14 C
15 A
16 E
17 F
18 C
19 D
20 B
21 B
22 C
23 C
24 budget
25 employment
26 safety
27 insurance
28 diary
29 database
30 museum
31 damage
32 side effects
33 bridge
34 confusion
35 smartphone
36 resources
37 unnecessary/not necessary
38 chocolate bar
39 problem
40 market share
15&16 IN EITHER ORDER: A,E
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B

22. C

23. C

24. budget

25. employment

26. safety

27. insurance

28. diary

29. database

30. museum

### Part 4 · source page 117

TEST 5 LISTENING
1 mountains
2 horse
3 garden(s)
4 lunch
5 map
6 experience
7 Ratchesons
8 helmet
9 shops
10 267
11 A
12 A
13 C
14 C
15 A
16 E
17 F
18 C
19 D
20 B
21 B
22 C
23 C
24 budget
25 employment
26 safety
27 insurance
28 diary
29 database
30 museum
31 damage
32 side effects
33 bridge
34 confusion
35 smartphone
36 resources
37 unnecessary/not necessary
38 chocolate bar
39 problem
40 market share
15&16 IN EITHER ORDER: A,E
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. damage

32. side effects

33. bridge

34. confusion

35. smartphone

36. resources

37. unnecessary / not necessary

38. chocolate bar

39. problem

40. market share

## A 类阅读

### Academic Reading · source page 118

TEST 5 READING
1 NOT GIVEN
2 FALSE
3 FALSE
4 TRUE
5 TRUE
6 taste
7 cheaper
8 convenient
9 image
10 sustainable
11 recycled
12 biodiversity
13 desertification
14 antiques
15 triumph
16 information
17 contact/meetings
18 hunt/desire
19 aimless/empty
20 educational
21 Trainspotting
22 NOT GIVEN
23 FALSE
24 NOT GIVEN
25 TRUE
26 TRUE
27 vi
28 viii
29 ii
30 iv
31 iii
32 vii
33 fire science
34 investigators
35 evidence
36 prosecution
37 NOT GIVEN
38 YES
39 NO
40 NO
If you score: 0–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. NOT GIVEN

2. FALSE

3. FALSE

4. TRUE

5. TRUE

6. taste

7. cheaper

8. convenient

9. image

10. sustainable

11. recycled

12. biodiversity

13. desertification

14. antiques

15. triumph

16. information

17. contact / meetings

18. hunt / desire

19. aimless / empty

20. educational

21. Trainspotting

22. NOT GIVEN

23. FALSE

24. NOT GIVEN

25. TRUE

26. TRUE

27. vi

28. viii

29. ii

30. iv

31. iii

32. vii

33. fire science

34. investigators

35. evidence

36. prosecution

37. NOT GIVEN

38. YES

39. NO

40. NO

## A 类写作

### Writing material: c12-t5-w-1

Australia2010; percentages doing regular physical activity, male/female by age:15–24 52.8/47.7;25–34 42.2/48.9;35–44 39.5/52.5;45–54 43.1/53.3;55–64 45.1/53.0;65and over46.7/47.1. Men lead only in youngest group; women lead all others, oldest almost equal. Male rate falls then rises, female rate rises to45–54 then falls. Denominators are each sex-age group, not shares of all participants; no head counts or other years supplied.



### Writing material: c12-t5-w-2

Discuss broad information sharing versus limits on freely sharing important/valuable information, with opinion. Scientific research,business,academic world define scope; do not recast solely as social-media privacy.



## 口语
