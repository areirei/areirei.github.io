# 剑雅 12 · Test 5

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/b8e5b90945b11de9ecfd83ff9070d3bbbcf47b72354fee864576f6878d6b7499.jpg; PDF page 11; full -->

```text
Test 5
LISTENING
SECTION 1 Questions 1-10
Complete the notes below.
Write ONE WORD AND/OR A NUMBER for each answer.
FAMILY EXCURSIONS
Cruise on a lake
Example
• Travel on an old steamship [example]
• Can take photos of the 1 ........................................... that surround the lake
Farm visit
• Children can help feed the sheep
• Visit can include a 40-minute ride on a 2 .......................................... .
• Visitors can walk in the farm's 3 ........................................... by the lake
• 4 ........................................... is available at extra cost
Cycling trips
• Cyclists explore the Back Road
• A 5 ........................................... is provided
• Only suitable for cyclists who have some 6 .......................................... .
Bikes can be hired from 7 ........................................... (near the Cruise Ship
Terminal)
10
```

[Original question page](assets/b8e5b90945b11de9ecfd83ff9070d3bbbcf47b72354fee864576f6878d6b7499.jpg)

<!-- Source: /api/assets/50bacc75d1ec79f08001ee23a62403d5fb9591c58294be54984bfa21e8d63caf.jpg; PDF page 12; full -->

```text
• Cyclists need:
a repair kit
food and drink
a 8 ........................................... (can be hired)
• There are no 9 ........................................... or accommodation in the area
Cost
Listening
• Total cost for whole family of cruise and farm visit: 10 $ .......................................... .
11
```

[Original question page](assets/50bacc75d1ec79f08001ee23a62403d5fb9591c58294be54984bfa21e8d63caf.jpg)

### Part 2

<!-- Source: /api/assets/25870c25ec6a8d413f587821dc3149b9488b49c4d9f54294fe4380bfe4314a24.jpg; PDF page 13; full -->

```text
Test 5
SECTION 2 Questions 11-20
Questions 11-14
Choose the correct letter, A, B or C.
Talk to new kitchen assistants
11 According to the manager, what do most people like about the job of kitchen
assistant?
A the variety of work
B the friendly atmosphere
C the opportunities for promotion
12 The manager is concerned about some of the new staff's
A jewellery .
B hair styles.
C shoes .
13 The manager says that the day is likely to be busy for kitchen staff because
A it is a public holiday.
B the head chef is absent.
C the restaurant is almost fully booked.
14 Only kitchen staff who are 18 or older are allowed to use
A the waste disposal unit.
B the electric mixer.
C the meat slicer.
Questions 15 and 16
Choose TWO letters , A-E.
According to the manager, which TWO things can make the job of kitchen assistant
stressful?
A They have to follow orders immediately.
B The kitchen gets very hot.
C They may not be able to take a break.
D They have to do overtime.
E The work is physically demanding.
12
```

[Original question page](assets/25870c25ec6a8d413f587821dc3149b9488b49c4d9f54294fe4380bfe4314a24.jpg)

<!-- Source: /api/assets/6e933c155ec11341b1fc8ce107c8c8d6ce79b9aa3091793159c0eaefdbf2407c.jpg; PDF page 14; full -->

```text
Questions 17-20
What is the responsibility of each of the following restaurant staff?
Choose FOUR answers from the box and write the correct letter, A-F, next to
Questions 17-20.
Responsibilities
A training courses
B food stocks
C first aid
D breakages
E staff discounts
F timetables
Restaurant staff
17 Joy Parkins ......................
18 David Field ······················
19 Dexter Wills ......................
20 Mike Smith ......................
Listening
13
```

[Original question page](assets/6e933c155ec11341b1fc8ce107c8c8d6ce79b9aa3091793159c0eaefdbf2407c.jpg)

### Part 3

<!-- Source: /api/assets/2e488b7e1bf81bb3700446cdcfd79fd3bd706af4ba40f251168fcbcb1ba50936.jpg; PDF page 15; full -->

```text
Test 5
SECTION 3 Questions 21-30
Questions 21-23
Choose the correct letter, A, B or C.
Paper on Public Libraries
21 What will be the main topic of Trudie and Stewart's paper?
A how public library services are organised in different countries
B how changes in society are reflected in public libraries
C how the funding of public libraries has changed
22 They agree that one disadvantage of free digitalised books is that
A they may take a long time to read.
B they can be difficult to read.
C they are generally old.
23 Stewart expects that in the future libraries will
A maintain their traditional function .
B become centres for local communities.
C no longer contain any books.
Questions 24-30
Complete the notes below.
Write ONE WORD ONLY for each answer.
Study of local library: possible questions
• whether it has a 24 ..... ... ....... ... ... of its own
• its policy regarding noise of various kinds
• how it's affected by laws regarding all aspects of 25 ....... ... ..... ... .. .
• how the design needs to take the 26 .......... ........... of customers into account
• what 27 ...... ... ........ .. .. is required in case of accidents
• why a famous person's 28 .......... ........... is located in the library
• whether it has a 29 ..................... of local organisations
• how it's different from a library in a 30 .... .... ............ .
14
```

[Original question page](assets/2e488b7e1bf81bb3700446cdcfd79fd3bd706af4ba40f251168fcbcb1ba50936.jpg)

### Part 4

<!-- Source: /api/assets/386aed3ee0593c9afa859f3ef731321ef63dd8860409157ca30c9c006088c7c9.jpg; PDF page 16; full -->

```text
Listening
SECTION 4 Questions 31-40
Complete the notes below.
Write NO MORE THAN TWO WORDS for each answer.
Four business values
Many business values can result in 31 ........................................... .
Senior managers need to understand and deal with the potential
32 ........................................... that may result.
Collaboration
During a training course, the speaker was in a team that had to build a
33 ........................................... .
Other teams experienced 34 ....................... , ................... from trying to collaborate.
The speaker's team won because they reduced collaboration.
Sales of a 35 ........................................... were poor because of collaboration.
Industriousness
Hard work may be a bad use of various company 36 ........................................... .
The word 'lazy' in this context refers to people who avoid doing tasks that
are 37 ........................................... .
Creativity
An advertising campaign for a 38 ........................................... was memorable but failed to
boost sales.
Creativity should be used as a response to a particular 39 ........................................... .
Excellence
According to one study, on average, pioneers had a 40 ........................................... that
was far higher than that of followers.
Companies that always aim at excellence may miss opportunities.
15
```

[Original question page](assets/386aed3ee0593c9afa859f3ef731321ef63dd8860409157ca30c9c006088c7c9.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/b7e0a5a1c844f4eeca8560f7b26293a047227070526e00f59dc0a9f6c749e245.jpg; PDF page 17; full -->

```text
Test 5
READING PASSAGE 1
You should spend about 20 minutes on Questions 1—13, which are based on Reading
Passage 1 below.
Cork
Cork - the thick bark of the cork oak
tree (Quercus suber) - is a remarkable
material. It is tough, elastic, buoyant,
and fire-resistant, and suitable for a
wide range of purposes. It has also
been used for millennia: the ancient
Egyptians sealed their sarcophagi
(stone coffins) with cork, while the
ancient Greeks and Romans used it
for anything from beehives to sandals.
And the cork oak itself is an
extraordinary tree. Its bark grows
up to 20 cm in thickness, insulating
the tree like a coat wrapped around
the trunk and branches and keeping
the inside at a constant 20°C all year
round. Developed most probably as
a defence against forest fires, the
bark of the cork oak has a particular
cellular structure - with about
40 million cells per cubic centimetre —
that technology has never succeeded
in replicating. The cells are filled with
air, which is why cork is so buoyant.
It also has an elasticity that means
you can squash it and watch it spring
back to its original size and shape
when you release the pressure.
Cork oaks grow in a number of
Mediterranean countries, including
Portugal, Spain, Italy, Greece and
Morocco. They flourish in warm, sunny
climates where there is a minimum of
400 millimetres of rain per year, and
not more than 800 millimetres. Like
grape vines, the trees thrive in poor
soil, putting down deep roots in search
of moisture and nutrients. Southern
Portugal’s Alentejo region meets all of
these requirements, which explains
why, by the early 20th century, this
region had become the world’s largest
producer of cork, and why today it
accounts for roughly half of all cork
production around the world.
Most cork forests are family-owned.
Many of these family businesses, and
indeed many of the trees themselves,
are around 200 years old. Cork
production is, above all, an exercise in
patience. From the planting of a cork
sapling to the first harvest takes 25
years, and a gap of approximately a
decade must separate harvests from
an individual tree. And for top-quality
cork, it’s necessary to wait a further
15 or 20 years. You even have to wait
for the right kind of summer’s day to:
harvest cork. If the bark is stripped on
a day when it’s too cold- or when the
air is damp — the tree will be damaged.
```

[Original question page](assets/b7e0a5a1c844f4eeca8560f7b26293a047227070526e00f59dc0a9f6c749e245.jpg)

<!-- Source: /api/assets/6a464ccfa55e6a98bee5d7edcb3c4b14600381d3392bd958ffa622b69a7515db.jpg; PDF page 18; full -->

```text
Cork harvesting is a very specialised
profession. No mechanical means
of stripping cork bark has been
invented, so the job is done by teams
of highly skilled workers. First, they
make vertical cuts down the bark
using small sharp axes, then lever
it away in pieces as large as they
can manage. The most skilful cork-
strippers prise away a semi-circular
husk that runs the length of the trunk
from just above ground level to the
first branches. It is then dried on the
ground for about four months, before
being taken to factories, where it is
boiled to kill any insects that might
remain in the cork. Over 60% of
cork then goes on to be made into
traditional bottle stoppers, with most
of the remainder being used in the
construction trade. Corkboard and
cork tiles are ideal for thermal and
acoustic insulation, while granules of
cork are used in the manufacture of
concrete.
Recent years have seen the end of
the virtual monopoly of cork as the
material for bottle stoppers, due to
concerns about the effect it may have
on the contents of the bottle. This
Reading
is caused by a chemical compound
called 2,4,6-trichloroanisole (TCA),
which forms through the interaction
of plant phenols, chlorine and mould.
The tiniest concentrations — as little
as three or four parts to a trillion -
can spoil the taste of the product
contained in the bottle. The result
has been a gradual yet steady move
first towards plastic stoppers and,
more recently, to aluminium screw
caps. These substitutes are cheaper to
manufacture and, in the case of screw
caps, more convenient for the user.
The classic cork stopper does
have several advantages, however.
Firstly, its traditional image is more
in keeping with that of the type of
high quality goods with which it has
long been associated. Secondly —
and very importantly - cork is a
sustainable product that can be
recycled without difficulty. Moreover,
cork forests are a resource which
support local biodiversity, and prevent
desertification in the regions where
they are planted. So, given the current
concerns about environmental issues,
the future of this ancient material
once again looks promising.
17
```

[Original question page](assets/6a464ccfa55e6a98bee5d7edcb3c4b14600381d3392bd958ffa622b69a7515db.jpg)

<!-- Source: /api/assets/0217d6a4542c44c7496c7803f8241d50d6a4f956724f22966b8262125b9ed63f.jpg; PDF page 19; full -->

```text
Test 5
Questions 1-5
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-5 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 The cork oak has the thickest bark of any living tree.
2 Scientists have developed a synthetic cork with the same cellular structure as
natural cork.
3 Individual cork oak trees must be left for 25 years between the first and second
harvest.
4 Cork bark should be stripped in dry atmospheric conditions.
5 The only way to remove the bark from cork oak trees is by hand .
18
```

[Original question page](assets/0217d6a4542c44c7496c7803f8241d50d6a4f956724f22966b8262125b9ed63f.jpg)

<!-- Source: /api/assets/2abc7cc944b0eeef40b9ba1c5bcb87ae1a9b56df6161e57531e26bd43a5e8ab7.jpg; PDF page 20; full -->

```text
Questions 6-13
Complete the notes below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 6-13 on your answer sheet.
Comparison of aluminium screw caps and
cork bottle stoppers
Advantages of aluminium screw caps
• do not affect the 6 ...... ....... ........ of the bottle contents
• are 7 ............. ...... .. to produce
• are 8 .. ..... .. ............ to use
Advantages of cork bottle stoppers
• suit the 9 ..................... of quality products
• made from a 10 ........... .......... material
• easily 11 ... ....... .......... .
• cork forests aid 12 ....... ....... ...... .
• cork forests stop 13 ..... .... ..... ....... happening
Reading
19
```

[Original question page](assets/2abc7cc944b0eeef40b9ba1c5bcb87ae1a9b56df6161e57531e26bd43a5e8ab7.jpg)

<!-- Source: /api/assets/cbf05dbe8d7a7ed45d3d612f16dfb26ef005274802053d296a07d33a08a76987.jpg; PDF page 21; full -->

```text
Test 5
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
COLLECTING AS A HOBBY
Collecting must be one of the most varied
of human activities, and it’s one that many
of us psychologists find fascinating. Many
forms of collecting have been dignified
with a technical name: an archtophilist
collects teddy bears, a philatelist collects
postage stamps, and a deltiologist
collects postcards. Amassing hundreds or
even thousands of postcards, chocolate
wrappers or whatever, takes time, energy
and money that could surely be put to
much more productive use. And yet there
are millions of collectors around the world.
Why do they do it?
There are the people who collect because
they want to make money - this could be
called an instrumental reason for collecting;
that is, collecting as a means to an end.
They'll look for, say, antiques that they
can buy cheaply and expect to be able
to sell at a profit. But there may well be a
psychological element, too — buying cheap
and selling dear can give the collector a
sense of triumph. And as selling online is so
easy, more and more people are joining in.
Many collectors collect to develop their
social life, attending meetings of a group
of collectors and exchanging information
on items. This is a variant on joining a
bridge club or a gym, and similarly brings
them into contact with like-minded people.
Another motive for collecting is the desire
to find something special, or a particular
example of the collected item, such as a
rare early recording by a particular singer.
Some may spend their whole lives in a
hunt for this. Psychologically, this can give
a purpose to a life that otherwise feels
aimless. There is a danger, though, that
if the individual is ever lucky enough to
find what they're looking for, rather than
celebrating their success, they may feel
empty, now that the goal that drove them
on has gone.
If you think about collecting postage
stamps, another potential reason for
it — or, perhaps, a result of collecting — is
its educational value. Stamp collecting
opens a window to other countries, and
to the plants, animals, or famous people
shown on their stamps. Similarly, in the
19th century, many collectors amassed
fossils, animals and plants from around
the globe, and their collections provided
a vast amount of information about the
natural world. Without those collections,
our understanding would be greatly inferior
to what it is.
In the past — and nowadays, too, though
to a lesser extent — a popular form of
collecting, particularly among boys
and men, was trainspotting. This might
involve trying to see every locomotive of a
particular type, using published data that
identifies each one, and ticking off each
engine as it is seen. Trainspotters exchange
information, these days often by mobile
phone, so they can work out where to go
to, to see a particular engine. As a by-
product, many practitioners of the hobby
become very knowledgeable about railway
```

[Original question page](assets/cbf05dbe8d7a7ed45d3d612f16dfb26ef005274802053d296a07d33a08a76987.jpg)

<!-- Source: /api/assets/3289c1339e8204ad7530262e4878704c73b8086781e1f85b6238c0976addfa63.jpg; PDF page 22; full -->

```text
operations, or the technical specifications
of different engine types.
Similarly, people who collect dolls may go
beyond simply enlarging their collection,
and develop an interest in the way that
dolls are made, or the materials that
are used. These have changed over the
centuries from the wood that was standard
in 16th century Europe, through the wax
and porcelain of later centuries, to the
plastics of today’s dolls. Or collectors
might be inspired to study how dolls
reflect notions of what children like, or
ought to like.
Not all collectors are interested in learning
from their hobby, though, so what we
might call a psychological reason for
collecting is the need for a sense of
control, perhaps as a way of dealing with
insecurity. Stamp collectors, for instance,
arrange their stamps in albums, usually very
neatly, organising their collection according
to certain commonplace principles —
Reading
perhaps by country in alphabetical order,
or grouping stamps by what they depict —
people, birds, maps, and so on.
One reason, conscious or not, for what
someone chooses to collect is to show
the collector's individualism. Someone
who decides to collect something as
unexpected as dog collars, for instance,
may be conveying their belief that they
must be interesting themselves. And
believe it or not, there is at least one dog
collar museum in existence, and it grew out
of a personal collection.
Of course, all hobbies give pleasure, but
the common factor in collecting is usually
passion: pleasure is putting it far too
mildly. More than most other hobbies,
collecting can be totally engrossing,
and can give a strong sense of personal
fulfilment. To non-collectors it may appear
an eccentric, if harmless, way of spending
time, but potentially, collecting has a lot
going for it.
21
```

[Original question page](assets/3289c1339e8204ad7530262e4878704c73b8086781e1f85b6238c0976addfa63.jpg)

<!-- Source: /api/assets/dce09bd355d52ef518cd42d177cc7dd8ac80a8d42cf00684610d94c94004b609.jpg; PDF page 23; full -->

```text
Test 5
Questions 14-21
Complete the sentences below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 14-21 on your answer sheet.
14 The writer mentions collecting ............ as an example of collecting in order to
make money.
15 Collectors may get a feeling of .. ... ....... from buying and selling items.
16 Collectors' clubs provide opportunities to share .... ...... .. .
17 Collectors' clubs offer ........ .. .. with people who have similar interests.
18 Collecting sometimes involves a life-long .... .. ...... for a special item.
19 Searching for something particular may prevent people from feeling their life is
completely ..... .... .. . .
20 Stamp collecting may be ............ because it provides facts about different
countries.
21 .... ........ tends to be mostly a male hobby.
Questions 22-26
Do the following statements agree with the information given in the passage on
pages 20 and 21?
In boxes 22-26 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
22 The number of people buying dolls has grown over the centuries .
23 Sixteenth century European dolls were normally made of wax and porcelain.
24 Arranging a stamp collection by the size of the stamps is less common than other
methods .
25 Someone who collects unusual objects may want others to think he or she is also
unusual.
26 Collecting gives a feeling that other hobbies are unlikely to inspire.
22
```

[Original question page](assets/dce09bd355d52ef518cd42d177cc7dd8ac80a8d42cf00684610d94c94004b609.jpg)

<!-- Source: /api/assets/f3c84486077e0f25d763e162af2a4e12f17f0f117a88e8262bf408e7d0a8a9e9.jpg; PDF page 24; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40 , which are based on Reading
Passage 3 on pages 24 and 25.
Questions 27-32
Reading Passage 3 has six sections, A-F.
Choose the correct heading for each section from the list of headings below.
Write the correct number, i-viii, in boxes 27-32 on your answer sheet.
27 Section A
28 Section B
29 Section C
30 Section D
31 Section E
32 Section F
List of Headings
i Courses that require a high level of commitment
ii A course title with two meanings
iii The equal importance of two key issues
iv Applying a theory in an unexpected context
v The financial benefits of studying
vi A surprising course title
vii Different names for different outcomes
viii The possibility of attracting the wrong kind of student
23
```

[Original question page](assets/f3c84486077e0f25d763e162af2a4e12f17f0f117a88e8262bf408e7d0a8a9e9.jpg)

<!-- Source: /api/assets/89945ccb30be9729b9a5c93533e882933bfc466c573e953cde050047530a6f34.jpg; PDF page 25; full -->

```text
Test 5
What's the purpose of gaining knowledge?
A ‘I would found an institution where any person can find instruction in any
subject.’ That was the founder's motto for Cornell University, and it seems an apt
characterization of the different university, also in the USA, where I currently teach
philosophy. A student can prepare for a career in resort management, engineering,
interior design, accounting, music, law enforcement, you name it. But what would
the founders of these two institutions have thought of a course called ‘Arson for Profit’?
I kid you not: we have it on the books. Any undergraduates who have met the academic
requirements can sign up for the course in our program in ‘fire science’.
B Naturally, the course is intended for prospective arson investigators, who can learn all
the tricks of the trade for detecting whether a fire was deliberately set, discovering who
did it, and establishing a chain of evidence for effective prosecution in a court of law.
But wouldn't this also be the perfect course for prospective arsonists to sign up for? My
point is not to criticize academic programs in fire science: they are highly welcome as
part of the increasing professionalization of this and many other occupations. However,
it’s not unknown for a firefighter to torch a building. This example suggests how
dishonest and illegal behavior, with the help of higher education, can creep into every
aspect of public and business life.
C I realized this anew when I was invited to speak before a class in marketing, which is
another of our degree programs. The regular instructor is a colleague who appreciates
the kind of ethical perspective I can bring as a philosopher. There are endless ways
I could have approached this assignment, but I took my cue from the title of the
course: ‘Principles of Marketing’. It made me think to ask the students, ‘Is marketing
principled?’ After all, a subject matter can have principles in the sense of being codified,
having rules, as with football or chess, without being principled in the sense of being
ethical. Many of the students immediately assumed that the answer to my question
about marketing principles was obvious: no. Just look at the ways in which everything
under the sun has been marketed; obviously it need not be done in a principled
(=ethical) fashion.
D Is that obvious? I made the suggestion, which may sound downright crazy in light of
the evidence, that perhaps marketing is by definition principled. My inspiration for this
judgement is the philosopher Immanuel Kant, who argued that any body of knowledge
consists of an end (or purpose) and a means.
```

[Original question page](assets/89945ccb30be9729b9a5c93533e882933bfc466c573e953cde050047530a6f34.jpg)

<!-- Source: /api/assets/29f0027aeac2d75eeb003cc73c319c0dacf263147d4ce1f2818f76cdea3a38e0.jpg; PDF page 26; full -->

```text
Reading
E Let us apply both the terms ‘means’ and ‘end’ to marketing. The students have signed
up for a course in order to learn how to market effectively. But to what end? There seem
to be two main attitudes toward that question. One is that the answer is obvious: the
purpose of marketing is to sell things and to make money. The other attitude is that the
purpose of marketing is irrelevant: Each person comes to the program and course with
his or her own plans, and these need not even concern the acquisition of marketing
expertise as such. My proposal, which I believe would also be Kant’s, is that neither of
these attitudes captures the significance of the end to the means for marketing. A field
of knowledge or a professional endeavor is defined by both the means and the end;
hence both deserve scrutiny. Students need to study both how to achieve X, and also
what X is.
F It is at this point that ‘Arson for Profit’ becomes supremely relevant. That course is
presumably all about means: how to detect and prosecute criminal activity. It is therefore
assumed that the end is good in an ethical sense. When I ask fire science students to
articulate the end, or purpose, of their field, they eventually generalize to something like,
“The safety and welfare of society, which seems right. As we have seen, someone could
use the very same knowledge of means to achieve a much less noble end, such as personal
profit via destructive, dangerous, reckless activity. But we would not call that firefighting.
We have a separate word for it: arson. Similarly, if you employed the ‘principles of
marketing’ in an unprincipled way, you would not be doing marketing. We have another
term for it: fraud. Kant gives the example of a doctor and a poisoner, who use the
identical knowledge to achieve their divergent ends. We would say that one is practicing
medicine, the other, murder.
25
```

[Original question page](assets/29f0027aeac2d75eeb003cc73c319c0dacf263147d4ce1f2818f76cdea3a38e0.jpg)

<!-- Source: /api/assets/10c1bf0010def5ea8460d52370b936f3f14895d3a5ade665d5ed0f1989f297ab.jpg; PDF page 27; full -->

```text
Test 5
Questions 33-36
Complete the summary below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 33-36 on your answer sheet.
The 'Arson for Profit' course
This is a university course intended for students who are undergraduates and who
are studying 33 ............ . The expectation is that they will become 34 ........... .
specialising in arson. The course will help them to detect cases of arson and find
35 ............ of criminal intent, leading to successful 36 ............ in the courts.
Questions 37-40
Do the following statements agree with the views of the writer in Reading Passage 3?
In boxes 37-40 on your answer sheet, write
YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
37 It is difficult to attract students onto courses that do not focus on a career.
38 The 'Arson for Profit' course would be useful for people intending to set fire to
buildings.
39 Fire science courses are too academic to help people to be good at the job of
firefighting.
40 The writer's fire science students provided a detailed definition of the purpose of
their studies.
26
```

[Original question page](assets/10c1bf0010def5ea8460d52370b936f3f14895d3a5ade665d5ed0f1989f297ab.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/9b0d8b18557acd126081d071cc655babbee4f6ba78d6c335fc8a44761d206ea5.jpg; PDF page 28; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The bar chart below shows the percentage of Australian men and women in different age groups who did regular physical activity in 2010.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/9b0d8b18557acd126081d071cc655babbee4f6ba78d6c335fc8a44761d206ea5.jpg)

![Original figure](assets/9b0d8b18557acd126081d071cc655babbee4f6ba78d6c335fc8a44761d206ea5.jpg)

### Task 2

<!-- Source: /api/assets/6819365c3380c3d170bd32be58b0b7cbc034ce0b4495c37336974efabac84ec8.jpg; PDF page 29; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that it is good to share as much information as possible in scientific research, business and the academic world. Others believe that some information is too important or too valuable to be shared freely.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/6819365c3380c3d170bd32be58b0b7cbc034ce0b4495c37336974efabac84ec8.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/47d38dbfe7d32a33e420cbb09ff49b29aaa701daff98e94de04ef0a83e2ea601.jpg; PDF page 30; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Health
• Is it important to you to eat healthy food? [Why?/Why not?]
• If you catch a cold, what do you do to help you feel better? [Why?]
• Do you pay attention to public information about health? [Why?/Why not?]
• What could you do to have a healthier lifestyle?
PART 2
Describe an occasion when you had to wait
a long time for someone or something to
arrive.
You should say:
who or what you were waiting for
how long you had to wait
why you had to wait a long time
and explain how you felt about waiting a
long time.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Arriving early
Example questions:
In what kinds of situations should people always arrive early?
How important it is to arrive early in your country?
How can modern technology help people to arrive early?
Being patient
Example questions:
What kinds of jobs require the most patience?
Is it always better to be patient in work (or studies)?
Do you agree or disagree that the older people are, the more patient they are?
29
```

[Original question page](assets/47d38dbfe7d32a33e420cbb09ff49b29aaa701daff98e94de04ef0a83e2ea601.jpg)

### Part 2

<!-- Source: /api/assets/47d38dbfe7d32a33e420cbb09ff49b29aaa701daff98e94de04ef0a83e2ea601.jpg; PDF page 30; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Health
• Is it important to you to eat healthy food? [Why?/Why not?]
• If you catch a cold, what do you do to help you feel better? [Why?]
• Do you pay attention to public information about health? [Why?/Why not?]
• What could you do to have a healthier lifestyle?
PART 2
Describe an occasion when you had to wait
a long time for someone or something to
arrive.
You should say:
who or what you were waiting for
how long you had to wait
why you had to wait a long time
and explain how you felt about waiting a
long time.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Arriving early
Example questions:
In what kinds of situations should people always arrive early?
How important it is to arrive early in your country?
How can modern technology help people to arrive early?
Being patient
Example questions:
What kinds of jobs require the most patience?
Is it always better to be patient in work (or studies)?
Do you agree or disagree that the older people are, the more patient they are?
29
```

[Original question page](assets/47d38dbfe7d32a33e420cbb09ff49b29aaa701daff98e94de04ef0a83e2ea601.jpg)

### Part 3

<!-- Source: /api/assets/47d38dbfe7d32a33e420cbb09ff49b29aaa701daff98e94de04ef0a83e2ea601.jpg; PDF page 30; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Health
• Is it important to you to eat healthy food? [Why?/Why not?]
• If you catch a cold, what do you do to help you feel better? [Why?]
• Do you pay attention to public information about health? [Why?/Why not?]
• What could you do to have a healthier lifestyle?
PART 2
Describe an occasion when you had to wait
a long time for someone or something to
arrive.
You should say:
who or what you were waiting for
how long you had to wait
why you had to wait a long time
and explain how you felt about waiting a
long time.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Arriving early
Example questions:
In what kinds of situations should people always arrive early?
How important it is to arrive early in your country?
How can modern technology help people to arrive early?
Being patient
Example questions:
What kinds of jobs require the most patience?
Is it always better to be patient in work (or studies)?
Do you agree or disagree that the older people are, the more patient they are?
29
```

[Original question page](assets/47d38dbfe7d32a33e420cbb09ff49b29aaa701daff98e94de04ef0a83e2ea601.jpg)
