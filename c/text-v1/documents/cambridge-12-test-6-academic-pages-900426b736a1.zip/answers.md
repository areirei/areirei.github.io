# 剑雅 12 · Test 6 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 119

TEST 6 LISTENING
1 2.45
2 band
3 play
4 scientist
5 river
6 grandparents
7 Handsworth
8 traditional
9 outdoor
10 logo
11 B
12 C
13 A
14 B
15 C
16 F
17 B
18 E
19 G
20 C
21 C
22 B
23 C
24 A
25 C
26 E
27 G
28 D
29 C
30 A
31 bullying
32 superiority
33 personality
34 structural
35 absence
36 confidence
37 visions
38 democratic
39 respect
40 mediator
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. 2.45 / 2:45

2. band

3. play

4. scientist

5. river

6. grandparents

7. Handsworth

8. traditional

9. outdoor

10. logo

### Part 2 · source page 119

TEST 6 LISTENING
1 2.45
2 band
3 play
4 scientist
5 river
6 grandparents
7 Handsworth
8 traditional
9 outdoor
10 logo
11 B
12 C
13 A
14 B
15 C
16 F
17 B
18 E
19 G
20 C
21 C
22 B
23 C
24 A
25 C
26 E
27 G
28 D
29 C
30 A
31 bullying
32 superiority
33 personality
34 structural
35 absence
36 confidence
37 visions
38 democratic
39 respect
40 mediator
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B

12. C

13. A

14. B

15. C

16. F

17. B

18. E

19. G

20. C

### Part 3 · source page 119

TEST 6 LISTENING
1 2.45
2 band
3 play
4 scientist
5 river
6 grandparents
7 Handsworth
8 traditional
9 outdoor
10 logo
11 B
12 C
13 A
14 B
15 C
16 F
17 B
18 E
19 G
20 C
21 C
22 B
23 C
24 A
25 C
26 E
27 G
28 D
29 C
30 A
31 bullying
32 superiority
33 personality
34 structural
35 absence
36 confidence
37 visions
38 democratic
39 respect
40 mediator
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. C

22. B

23. C

24. A

25. C

26. E

27. G

28. D

29. C

30. A

### Part 4 · source page 119

TEST 6 LISTENING
1 2.45
2 band
3 play
4 scientist
5 river
6 grandparents
7 Handsworth
8 traditional
9 outdoor
10 logo
11 B
12 C
13 A
14 B
15 C
16 F
17 B
18 E
19 G
20 C
21 C
22 B
23 C
24 A
25 C
26 E
27 G
28 D
29 C
30 A
31 bullying
32 superiority
33 personality
34 structural
35 absence
36 confidence
37 visions
38 democratic
39 respect
40 mediator
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. bullying

32. superiority

33. personality

34. structural

35. absence

36. confidence

37. visions

38. democratic

39. respect

40. mediator

## A 类阅读

### Academic Reading · source page 120

TEST 6 READING
1 A
2 B
3 H
4 D
5 B
6 C
7 G
8 B
9 A
10 D
11 E
12 C
13 D
14 iv
15 vi
16 viii
17 v
18 i
19 vii
20 iii
21 TRUE
22 FALSE
23 FALSE
24 NOT GIVEN
25 rubber
26 farmer
27 eye movements
28 language co-activation
29 Stroop Task
30 conflict management
31 cognitive control
32 YES
33 NOT GIVEN
34 NO
35 NO
36 NOT GIVEN
37 D
38 G
39 B
40 C
10&11 IN EITHER ORDER: D,E
12&13 IN EITHER ORDER: C,D
If you score: 0–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. A

2. B

3. H

4. D

5. B

6. C

7. G

8. B

9. A

10. D / E

11. D / E

12. C / D

13. C / D

14. iv

15. vi

16. viii

17. v

18. i

19. vii

20. iii

21. TRUE

22. FALSE

23. FALSE

24. NOT GIVEN

25. rubber

26. farmer

27. eye movements

28. language co-activation

29. Stroop Task

30. conflict management

31. cognitive control

32. YES

33. NOT GIVEN

34. NO

35. NO

36. NOT GIVEN

37. D

38. G

39. B

40. C

## A 类写作

### Writing material: c12-t6-w-1

Compass north up. Current: east–west main road with shops both sides; countryside north; housing south; school southwest; park southeast. Plan: dual carriageway surrounds centre, former central main road becomes pedestrians only. North row shops replaced by bus station,shopping centre,car park,new housing from west to east; southern shops retained. Additional new housing south of shops near park; park becomes smaller; school and southern housing remain outside ring road. New short access to northeastern housing/car park. All changes are planned, not completed; no dates or dimensions supplied.



### Writing material: c12-t6-w-2

Weigh advantages and disadvantages of a relatively large young-adult population compared with older people. Do not answer an ageing-population question or substitute young children for young adults.



## 口语
