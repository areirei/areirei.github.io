# 剑雅 12 · Test 6

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/37c9245dc346b47f0945e603ff4d7ba14aba1aca85c5222f2949aa1b05f25e64.jpg; PDF page 31; full -->

```text
Test 6
LISTENING
SECTION 1 Questions 1-10
Complete the notes below.
Write ONE WORD AND/OR A NUMBER for each answer.
30
Events during Kenton Festival
Example
Start date: 16th May [example]
Opening ceremony (first day)
• In town centre, starting at 1 .......................................... .
The mayor will make a speech
A 2 ........................................... will perform
Performance of a 3 .................................... about Helen Tungate (a 4 .................................... )
Evening fireworks display situated across the 5 .......................................... .
Other events
• Videos about relationships that children have with their 6 .......................................... .
Venue: 7 ........................................... House
• Performance of 8 ........................................... dances
Venue: the 9 ........................................... market in the town centre
Time: 2 and 5 pm every day except 1st day of festival
• Several professional concerts and one by children
Venue: library
Time: 6.30 pm on the 18th
Tickets available online from festival box office and from shops which have
the festival 10 ........................................... in their windows
```

[Original question page](assets/37c9245dc346b47f0945e603ff4d7ba14aba1aca85c5222f2949aa1b05f25e64.jpg)

### Part 2

<!-- Source: /api/assets/01c075d4c505325a1c54b001cfbe56c02f65478cbcdf6ab592311935f78c841c.jpg; PDF page 32; full -->

```text
SECTION 2
Questions 11-15
Questions 11-20
Choose the correct letter, A, B or C.
Theatre trip to Munich
11 When the group meet at the airport they will have
A breakfast.
B coffee.
C lunch.
12 The group will be met at Munich Airport by
A an employee at the National Theatre.
B a theatre manager.
C a tour operator.
13 How much will they pay per night for a double room at the hotel?
A 110 euros
B 120 euros
C 150 euros
14 What type of restaurant will they go to on Tuesday evening?
A an Italian restaurant
B a Lebanese restaurant
C a typical restaurant of the region
15 Who will they meet on Wednesday afternoon?
A an actor
B a playwright
C a theatre director
Listening
31
```

[Original question page](assets/01c075d4c505325a1c54b001cfbe56c02f65478cbcdf6ab592311935f78c841c.jpg)

<!-- Source: /api/assets/d7140e279e8c17cf60cafd16232c3db355f51a201e193281ee5daacee713a375.jpg; PDF page 33; full -->

```text
Questions 16–20
What does the man say about the play on each of the following days?
Choose FIVE answers from the box and write the correct letter, A–G, next to Questions 16–20.
Comments
A The playwright will be present.
B The play was written to celebrate an anniversary.
C The play will be performed inside a historic building.
D The play will be accompanied by live music.
E The play will be performed outdoors.
F The play will be performed for the first time.
G The performance will be attended by officials from the town.
Days
16 Wednesday __________
17 Thursday __________
18 Friday __________
19 Saturday __________
20 Monday __________
```

[Original question page](assets/d7140e279e8c17cf60cafd16232c3db355f51a201e193281ee5daacee713a375.jpg)

### Part 3

<!-- Source: /api/assets/7aad85916958d76bc81e64e76c69957ab8b3860fbee9eb0d458424ed974fe116.jpg; PDF page 34; full -->

```text
SECTION 3
Questions 21-25
Questions 21-30
Choose the correct letter, A, B or C.
Scandinavian Studies
21 James chose to take Scandinavian Studies because when he was a child
A he was often taken to Denmark.
B his mother spoke to him in Danish.
C a number of Danish people visited his family.
22 When he graduates, James would like to
A take a postgraduate course.
B work in the media.
C become a translator.
23 Which course will end this term?
A Swedish cinema
B Danish television programmes
C Scandinavian literature
24 They agree that James's literature paper this term will be on
A 19th century playwrights.
B the Icelandic sagas.
C modern Scandinavian novels.
25 Beth recommends that James's paper should be
A a historical overview of the genre.
B an in-depth analysis of a single writer.
C a study of the social background to the literature.
Listening
33
```

[Original question page](assets/7aad85916958d76bc81e64e76c69957ab8b3860fbee9eb0d458424ed974fe116.jpg)

<!-- Source: /api/assets/09809fbf37d1759c925461634ed0379c0df5085d2a97d3514f8e40c99be4aae8.jpg; PDF page 35; full -->

```text
Test 6
Questions 26-30
Complete the flow-chart below.
Choose FIVE answers from the box and write the correct letter, A-G, next to
Questions 26-30.
A bullet points
B film
C notes
D structure
E student paper
F textbook
G documentary
How James will write his paper on the Vikings
He'll read a 26 ...................... and choose his topic.
↓ He'll borrow a 27 ...................... from Beth.
↓
↓ He'll plan the 28 ...................... of the paper.
↓ He'll read some source material and write 29 ...................... .
↓ He'll write the paper using 30 ...................... .
↓ He'll write the complete paper.
34
```

[Original question page](assets/09809fbf37d1759c925461634ed0379c0df5085d2a97d3514f8e40c99be4aae8.jpg)

### Part 4

<!-- Source: /api/assets/50c0a765d2b8822e8ff51b45324a8c7cf55cba13765c75f7c66fb0040a3a569c.jpg; PDF page 36; full -->

```text
Listening
SECTION 4 Questions 31-40
Complete the notes below.
Write ONE WORD ONLY for each answer.
Conflict at work
Conflict mostly consists of behaviour in the general category of 31 .......................................... .
Often a result of people wanting to prove their 32 .......................................... .
Also caused by differences in 33 ........................................... between people
34 ' .......................................... .' conflicts: people more concerned about own team than about
company
Conflict-related stress can cause 35 ........................................... that may last for months
Chief Executives (CEOs)
Many have both 36 ........................................... and anxiety
May not like to have their decisions questioned
There may be conflict between people who have different 37 .......................................... .
Other managers
A structure that is more 38 ........................................... may create a feeling of uncertainty
about who staff should report to.
Minimising conflict
Bosses need to try hard to gain 39 ......................................... ..
Someone from outside the company may be given the role of 40 ........................................... in
order to resolve conflicts.
35
```

[Original question page](assets/50c0a765d2b8822e8ff51b45324a8c7cf55cba13765c75f7c66fb0040a3a569c.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/4acd1df4a13bdb1bff75066816cc8e43e237ea195beace9ac8056f044db5def0.jpg; PDF page 37; full -->

```text
Test 6
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The risks agriculture faces in developing countries
Synthesis of an online debate*
A Two things distinguish food production from all other productive activities: first,
every single person needs food each day and has a right to it; and second, it is
hugely dependent on nature. These two unique aspects, one political, the other
natural, make food production highly vulnerable and different from any other
business. At the same time, cultural values are highly entrenched in food and
agricultural systems worldwide.
B Farmers everywhere face major risks, including extreme weather, long-term
climate change, and price volatility in input and product markets. However,
smallholder farmers in developing countries must in addition deal with adverse
environments, both natural, in terms of soil quality, rainfall, etc., and human, in
terms of infrastructure, financial systems, markets, knowledge and technology.
Counter-intuitively, hunger is prevalent among many smallholder farmers in the
developing world.
C Participants in the online debate argued that our biggest challenge is to address the
underlying causes of the agricultural system's inability to ensure sufficient food for
all, and they identified as drivers of this problem our dependency on fossil fuels and
unsupportive government policies.
D On the question of mitigating the risks farmers face, most essayists called for
greater state intervention. In his essay, Kanayo F. Nwanze, President of the
International Fund for Agricultural Development, argued that governments can
significantly reduce risks for farmers by providing basic services like roads to get
produce more efficiently to markets, or water and food storage facilities to reduce
losses. Sophia Murphy, senior advisor to the Institute for Agriculture and Trade
Policy, suggested that the procurement and holding of stocks by governments
can also help mitigate wild swings in food prices by alleviating uncertainties about
market supply.
*The personal names in the text refer to the authors of written contributions to the online debate.
36
```

[Original question page](assets/4acd1df4a13bdb1bff75066816cc8e43e237ea195beace9ac8056f044db5def0.jpg)

<!-- Source: /api/assets/e59cc5e55d1d97af7d96af204c4c0316b334ea99edd4a0acab4dd4a042c8c197.jpg; PDF page 38; full -->

```text
Reading
E Shenggen Fan, Director General of the International Food Policy Research
Institute, held up social safety nets and public welfare programmes in Ethiopia,
Brazil and Mexico as valuable ways to address poverty among farming families
and reduce their vulnerability to agriculture shocks. However, some commentators
responded that cash transfers to poor families do not necessarily translate into
increased food security, as these programmes do not always strengthen food
production or raise incomes. Regarding state subsidies for agriculture, Rokeya
Kabir, Executive Director of Bangladesh Nari Progati Sangha, commented in her
essay that these 'have not compensated for the stranglehold exercised by private
traders. In fact, studies show that sixty percent of beneficiaries of subsidies are not
poor, but rich landowners and non-farmer traders.'
F Nwanze, Murphy and Fan argued that private risk management tools, like private
insurance, commodity futures markets, and rural finance can help small-scale
producers mitigate risk and allow for investment in improvements. Kabir warned
that financial support schemes often encourage the adoption of high-input
agricultural practices, which in the medium term may raise production costs
beyond the value of their harvests. Murphy noted that when futures markets
become excessively financialised they can contribute to short-term price volatility,
which increases farmers' food insecurity. Many participants and commentators
emphasised that greater transparency in markets is needed to mitigate the impact
of volatility, and make evident whether adequate stocks and supplies are available.
Others contended that agribusiness companies should be held responsible for
paying for negative side effects.
G Many essayists mentioned climate change and its consequences for small-scale
agriculture. Fan explained that 'in addition to reducing crop yields, climate change
increases the magnitude and the frequency of extreme weather events, which
increase smallholder vulnerability.' The growing unpredictability of weather patterns
increases farmers' difficulty in managing weather-related risks. According to this
author, one solution would be to develop crop varieties that are more resilient
to new climate trends and extreme weather patterns. Accordingly, Pat Mooney,
co-founder and executive director of the ETC Group, suggested that 'if we are to
survive climate change, we must adopt policies that let peasants diversify the plant
and animal species and varieties/breeds that make up our menus.'
37
```

[Original question page](assets/e59cc5e55d1d97af7d96af204c4c0316b334ea99edd4a0acab4dd4a042c8c197.jpg)

<!-- Source: /api/assets/9dac59856ce93581d6027d2ebeef3539074927f336b69278fed0dccc7d2a51a0.jpg; PDF page 39; full -->

```text
Test 6
H Some participating authors and commentators argued in favour of community­
based and autonomous risk management strategies through collective action
groups, co-operatives or producers' groups. Such groups enhance market
opportunities for small-scale producers, reduce marketing costs and synchronise
buying and selling with seasonal price conditions. According to Murphy, 'collective
action offers an important way for farmers to strengthen their political and economic
bargaining power, and to reduce their business risks.' One commentator, Giel Ton,
warned that collective action does not come as a free good. It takes time, effort
and money to organise, build trust and to experiment. Others, like Marcel Vernooij
and Marcel Beukeboom, suggested that in order to 'apply what we already know',
all stakeholders, including business, government, scientists and civil society, must
work together, starting at the beginning of the value chain.
I Some participants explained that market price volatility is often worsened by the
presence of intermediary purchasers who, taking advantage of farmers' vulnerability,
dictate prices. One commentator suggested farmers can gain greater control over
prices and minimise price volatility by selling directly to consumers. Similarly, Sonali
Bisht, founder and advisor to the Institute of Himalayan Environmental Research
and Education (INHERE), India, wrote that community-supported agriculture, where
consumers invest in local farmers by subscription and guarantee producers a fair
price, is a risk-sharing model worth more attention. Direct food distribution systems
not only encourage small-scale agriculture but also give consumers more control
over the food they consume, she wrote.
```

[Original question page](assets/9dac59856ce93581d6027d2ebeef3539074927f336b69278fed0dccc7d2a51a0.jpg)

<!-- Source: /api/assets/d63b0104642cec7bdc3c1c97cb98330e1b28c288f96f1e502c1ed425ec1fb45f.jpg; PDF page 40; full -->

```text
Questions 1-3
Reading Passage 1 has nine paragraphs, A–I.
Which paragraph contains the following information?
Write the correct letter, A-I, in boxes 1-3 on your answer sheet.
1 a reference to characteristics that only apply to food production
2 a reference to challenges faced only by farmers in certain parts of the world
3 a reference to difficulties in bringing about co-operation between farmers
Reading
39
```

[Original question page](assets/d63b0104642cec7bdc3c1c97cb98330e1b28c288f96f1e502c1ed425ec1fb45f.jpg)

<!-- Source: /api/assets/ff074fe0e92bced975182bc773d5eaeda2637c1283cc284f3c7430d262d0480a.jpg; PDF page 41; full -->

```text
Test 6
Questions 4-9
Look at the following statements (Questions 4-9) and the list of people below.
Match each statement with the correct person, A-G.
Write the correct letter, A-G, in boxes 4-9 on your answer sheet.
NB You may use any letter more than once.
4 Financial assistance from the government does not always go to the farmers who
most need it.
5 Farmers can benefit from collaborating as a group.
6 Financial assistance from the government can improve the standard of living of
farmers.
7 Farmers may be helped if there is financial input by the same individuals who buy
from them.
8 Governments can help to reduce variation in prices.
9 Improvements to infrastructure can have a major impact on risk for farmers.
List of People
A Kanayo F. Nwanze
B Sophia Murphy
C Shenggen Fan
D Rokeya Kabir
E Pat Mooney
F Giel Ton
G Sonali Bisht
40
```

[Original question page](assets/ff074fe0e92bced975182bc773d5eaeda2637c1283cc284f3c7430d262d0480a.jpg)

<!-- Source: /api/assets/b2f0a5a6b36353f4d7251b4ea4f3bae06c29d46c747f033cc23eeb5709c06a9f.jpg; PDF page 42; full -->

```text
Questions 10 and 11
Choose TWO letters, A-E.
Write the correct letters in boxes 10 and 11 on your answer sheet.
Which TWO problems are mentioned which affect farmers with small farms in
developing countries?
A lack of demand for locally produced food
B lack of irrigation programmes
C being unable to get insurance
D the effects of changing weather patterns
E having to sell their goods to intermediary buyers
Questions 12 and 13
Choose TWO letters, A-E.
Write the correct letters in boxes 12 and 13 on your answer sheet.
Which TWO actions are recommended for improving conditions for farmers?
A reducing the size of food stocks
B attempting to ensure that prices rise at certain times of the year
C organising co-operation between a wide range of interested parties
D encouraging consumers to take a financial stake in farming
E making customers aware of the reasons for changing food prices
Reading
41
```

[Original question page](assets/b2f0a5a6b36353f4d7251b4ea4f3bae06c29d46c747f033cc23eeb5709c06a9f.jpg)

<!-- Source: /api/assets/4f8f62a4c52433ff478f41dae36c324e71e1de0ecfb9ee7939bc5a0a518b642d.jpg; PDF page 43; full -->

```text
Test 6
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Questions 14-20
Reading Passage 2 has seven paragraphs, A-G.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i-viii, in boxes 14-20 on your answer sheet.
14 Paragraph A
15 Paragraph B
16 Paragraph C
17 Paragraph D
18 Paragraph E
19 Paragraph F
20 Paragraph G
42
List of Headings
i Different accounts of the same journey
ii Bingham gains support
iii A common belief
iv The aim of the trip
v A dramatic description
vi A new route
vii Bingham publishes his theory
viii Bingham's lack of enthusiasm
```

[Original question page](assets/4f8f62a4c52433ff478f41dae36c324e71e1de0ecfb9ee7939bc5a0a518b642d.jpg)

<!-- Source: /api/assets/846b149f8c13b496d8caea4fd0dfdd392e866496234e680a6fc0734c64c6302a.jpg; PDF page 44; full -->

```text
Reading
The Lost City
An explorer's encounter with the ruined city of Machu Picchu, the most famous
icon of the Inca civilisation
A When the US explorer and academic Hiram Bingham arrived in South America in
1911, he was ready for what was to be the greatest achievement of his life: the
exploration of the remote hinterland to the west of Cusco, the old capital of the Inca
empire in the Andes mountains of Peru. His goal was to locate the remains of a city
called Vitcos, the last capital of the Inca civilisation. Cusco lies on a high plateau
at an elevation of more than 3,000 metres, and Bingham's plan was to descend
from this plateau along the valley of the Urubamba river, which takes a circuitous
route down to the Amazon and passes through an area of dramatic canyons and
mountain ranges.
B When Bingham and his team set off down the Urubamba in late July, they had
an advantage over travellers who had preceded them: a track had recently been
blasted down the valley canyon to enable rubber to be brought up by mules from
the jungle. Almost all previous travellers had left the river at Ollantaytambo and
taken a high pass across the mountains to rejoin the river lower down, thereby
cutting a substantial corner, but also therefore never passing through the area
around Machu Picchu.
C On 24 July they were a few days into their descent of the valley. The day began
slowly, with Bingham trying to arrange sufficient mules for the next stage of the
trek. His companions showed no interest in accompanying him up the nearby hill
to see some ruins that a local farmer, Melchor Arteaga, had told them about the
night before. The morning was dull and damp, and Bingham also seems to have
been less than keen on the prospect of climbing the hill. In his book Lost City of the
Incas, he relates that he made the ascent without having the least expectation that
he would find anything at the top.
D Bingham writes about the approach in vivid style in his book. First, as he climbs
up the hill, he describes the ever-present possibility of deadly snakes, 'capable of
making considerable springs when in pursuit of their prey'; not that he sees any.
Then there's a sense of mounting discovery as he comes across great sweeps
of terraces, then a mausoleum, followed by monumental staircases and, finally,
the grand ceremonial buildings of Machu Picchu. 'It seemed like an unbelievable
dream ... the sight held me spellbound ... ' he wrote.
43
```

[Original question page](assets/846b149f8c13b496d8caea4fd0dfdd392e866496234e680a6fc0734c64c6302a.jpg)

<!-- Source: /api/assets/44151bf03923d4a6f8b661f4cfa24760cc54047590bb611fef5ca216e17d6e74.jpg; PDF page 45; full -->

```text
Test 6
E We should remember, however, that Lost City of the Incas is a work of hindsight,
not written until 1948, many years after his journey. His journal entries of the
time reveal a much more gradual appreciation of his achievement. He spent
the afternoon at the ruins noting down the dimensions of some of the buildings,
then descended and rejoined his companions, to whom he seems to have said
little about his discovery. At this stage, Bingham didn't realise the extent or the
importance of the site, nor did he realise what use he could make of the discovery.
F However, soon after returning it occurred to him that he could make a name for
himself from this discovery. When he came to write the National Geographic
magazine article that broke the story to the world in April 1913, he knew he had
to produce a big idea. He wondered whether it could have been the birthplace of
the very first Inca, Manco the Great, and whether it could also have been what
chroniclers described as 'the last city of the Incas'. This term refers to Vilcabamba,
the settlement where the Incas had fled from Spanish invaders in the 1530s.
Bingham made desperate attempts to prove this belief for nearly 40 years. Sadly,
his vision of the site as both the beginning and end of the Inca civilisation, while
a magnificent one, is inaccurate. We now know that Vilcabamba actually lies 65
kilometres away in the depths of the jungle.
G One question that has perplexed visitors, historians and archaeologists alike ever
since Bingham, is why the site seems to have been abandoned before the Spanish
Conquest. There are no references to it by any of the Spanish chroniclers - and if
they had known of its existence so close to Cusco they would certainly have come
in search of gold. An idea which has gained wide acceptance over the past few
years is that Machu Picchu was a moya, a country estate built by an Inca emperor
to escape the cold winters of Cusco, where the elite could enjoy monumental
architecture and spectacular views. Furthermore, the particular architecture of
Machu Picchu suggests that it was constructed at the time of the greatest of all the
Incas, the emperor Pachacuti (c. 1438-71 ). By custom, Pachacuti's descendants
built other similar estates for their own use, and so Machu Picchu would have been
abandoned after his death, some 50 years before the Spanish Conquest.
44
```

[Original question page](assets/44151bf03923d4a6f8b661f4cfa24760cc54047590bb611fef5ca216e17d6e74.jpg)

<!-- Source: /api/assets/7ba10023b183ddb9fb5ecf41085cf5ae3cbfb2d945a349fe5ba9cb436a4f891f.jpg; PDF page 46; full -->

```text
Reading
Questions 21-24
Do the following statements agree with the information given in Reading Passage 2?
In boxes 21-24 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
21 Bingham went to South America in search of an Inca city.
22 Bingham chose a particular route down the Urubamba valley because it was the
most common route used by travellers.
23 Bingham understood the significance of Machu Picchu as soon as he saw it.
24 Bingham returned to Machu Picchu in order to find evidence to support his theory.
Questions 25-26
Complete the sentences below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 25-26 on your answer sheet.
25 The track that took Bingham down the Urubamba valley had been created for the
transportation of ........................................... .
26 Bingham found out about the ruins of Machu Picchu from a ........................................... in the
Urubamba valley.
45
```

[Original question page](assets/7ba10023b183ddb9fb5ecf41085cf5ae3cbfb2d945a349fe5ba9cb436a4f891f.jpg)

<!-- Source: /api/assets/41f8619198ef7842ddd90d9d38741c0badce46d11db6f5edede49a6ad168ebb2.jpg; PDF page 47; full -->

```text
Test 6
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
The Benefits of Being Bilingual
A According to the latest figures, the majority of the world's population is now bilingual
or multilingual, having grown up speaking two or more languages. In the past, such
children were considered to be at a disadvantage compared with their monolingual
peers. Over the past few decades, however, technological advances have allowed
researchers to look more deeply at how bilingualism interacts with and changes
the cognitive and neurological systems, thereby identifying several clear benefits of
being bilingual.
B Research shows that when a bilingual person uses one language, the other is
active at the same time. When we hear a word, we don't hear the entire word all at
once: the sounds arrive in sequential order. Long before the word is finished, the
brain's language system begins to guess what that word might be. If you hear 'can',
you will likely activate words like 'candy' and 'candle' as well, at least during the
earlier stages of word recognition. For bilingual people, this activation is not limited
to a single language; auditory input activates corresponding words regardless
of the language to which they belong. Some of the most compelling evidence
for this phenomenon, called 'language co-activation', comes from studying eye
movements. A Russian-English bilingual asked to 'pick up a marker' from a set of
objects would look more at a stamp than someone who doesn't know Russian,
because the Russian word for 'stamp', marka, sounds like the English word he or
she heard, 'marker'. In cases like this, language co-activation occurs because what
the listener hears could map onto words in either language.
C Having to deal with this persistent linguistic competition can result in difficulties,
however. For instance, knowing more than one language can cause speakers to
name pictures more slowly, and can increase 'tip-of-the-tongue states', when you
can almost, but not quite, bring a word to mind. As a result, the constant juggling of
two languages creates a need to control how much a person accesses a language
at any given time. For this reason, bilingual people often perform better on tasks
that require conflict management. In the classic Stroop Task, people see a word
and are asked to name the colour of the word's font. When the colour and the
word match (i.e., the word 'red' printed in red), people correctly name the colour
more quickly than when the colour and the word don't match (i.e., the word 'red'
printed in blue). This occurs because the word itself ('red') and its font colour (blue)
conflict. Bilingual people often excel at tasks such as this, which tap into the ability
to ignore competing perceptual information and focus on the relevant aspects of
the input. Bilinguals are also better at switching between two tasks; for example,
when bilinguals have to switch from categorizing objects by colour (red or green)
```

[Original question page](assets/41f8619198ef7842ddd90d9d38741c0badce46d11db6f5edede49a6ad168ebb2.jpg)

<!-- Source: /api/assets/8ccd2373fdad2f4b96a82d56fc9fe99a3328d364b65c27c5613a29a0e98f32aa.jpg; PDF page 48; full -->

```text
Reading
to categorizing them by shape (circle or triangle), they do so more quickly than
monolingual people, reflecting better cognitive control when having to make rapid
changes of strategy.
D It also seems that the neurological roots of the bilingual advantage extend to brain
areas more traditionally associated with sensory processing. When monolingual
and bilingual adolescents listen to simple speech sounds without any intervening
background noise, they show highly similar brain stem responses. When
researchers play the same sound to both groups in the presence of background
noise, however, the bilingual listeners' neural response is considerably larger,
reflecting better encoding of the sound's fundamental frequency, a feature of sound
closely related to pitch perception.
E Such improvements in cognitive and sensory processing may help a bilingual
person to process information in the environment, and help explain why bilingual
adults acquire a third language better than monolingual adults master a second
language. This advantage may be rooted in the skill of focussing on information
about the new language while reducing interference from the languages they
already know.
F Research also indicates that bilingual experience may help to keep the cognitive
mechanisms sharp by recruiting alternate brain networks to compensate for those
that become damaged during aging. Older bilinguals enjoy improved memory
relative to monolingual people, which can lead to real-world health benefits. In a
study of over 200 patients with Alzheimer's disease, a degenerative brain disease,
bilingual patients reported showing initial symptoms of the disease an average
of five years later than monolingual patients. In a follow-up study, researchers
compared the brains of bilingual and monolingual patients matched on the severity
of Alzheimer's symptoms. Surprisingly, the bilinguals' brains had more physical
signs of disease than their monolingual counterparts, even though their outward
behaviour and abilities were the same. If the brain is an engine, bilingualism may
help it to go farther on the same amount of fuel.
G Furthermore, the benefits associated with bilingual experience seem to start
very early. In one study, researchers taught seven-month-old babies growing
up in monolingual or bilingual homes that when they heard a tinkling sound, a
puppet appeared on one side of a screen. Halfway through the study, the puppet
began appearing on the opposite side of the screen. In order to get a reward, the
infants had to adjust the rule they'd learned; only the bilingual babies were able to
successfully learn the new rule. This suggests that for very young children, as well
as for older people, navigating a multilingual environment imparts advantages that
transfer far beyond language.
47
```

[Original question page](assets/8ccd2373fdad2f4b96a82d56fc9fe99a3328d364b65c27c5613a29a0e98f32aa.jpg)

<!-- Source: /api/assets/c8d48b6b3f9f3d7f97a0081a9526cb602360c4d30620b7b9d71b0f574886474c.jpg; PDF page 49; full -->

```text
Test 6
Questions 27-31
Complete the table below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 27-31 on your answer sheet.
| Test | Findings |
| --- | --- |
| Observing the (27) __________ of Russian-English bilingual people when asked to select certain objects | Bilingual people engage both languages simultaneously: a mechanism known as (28) __________ |
| A test called the (29) __________, focusing on naming colours | Bilingual people are more able to handle tasks involving a skill called (30) __________ |
| A test involving switching between tasks | When changing strategies, bilingual people have superior (31) __________ |
Questions 32-36
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 32-36 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
32 Attitudes towards bilingualism have changed in recent years.
33 Bilingual people are better than monolingual people at guessing correctly what
words are before they are finished.
34 Bilingual people consistently name images faster than monolingual people.
35 Bilingual people's brains process single sounds more efficiently than monolingual
people in all situations.
36 Fewer bilingual people than monolingual people suffer from brain disease in
old age.
48
```

[Original question page](assets/c8d48b6b3f9f3d7f97a0081a9526cb602360c4d30620b7b9d71b0f574886474c.jpg)

<!-- Source: /api/assets/3e9de3659770bf0a1fd301379a641872b71a17a072a6148a18b2d95e655f2f72.jpg; PDF page 50; full -->

```text
Reading
Questions 37-40
Reading Passage 3 has seven paragraphs, A-G.
Which paragraph contains the following information?
Write the correct letter, A-G, in boxes 37-40 on your answer sheet.
37 an example of how bilingual and monolingual people's brains respond differently
to a certain type of non-verbal auditory input
38 a demonstration of how a bilingual upbringing has benefits even before we learn
to speak
39 a description of the process by which people identify words that they hear
40 reference to some negative consequences of being bilingual
49
```

[Original question page](assets/3e9de3659770bf0a1fd301379a641872b71a17a072a6148a18b2d95e655f2f72.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/f4bc415ac303f8c62594ed070ccb44d77ee7e5ecdb2795b2a4f2352edce0c486.jpg; PDF page 51; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The maps below show the centre of a small town called Islip as it is now, and plans for its development.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/f4bc415ac303f8c62594ed070ccb44d77ee7e5ecdb2795b2a4f2352edce0c486.jpg)

![Original figure](assets/f4bc415ac303f8c62594ed070ccb44d77ee7e5ecdb2795b2a4f2352edce0c486.jpg)

### Task 2

<!-- Source: /api/assets/bcc6f0faae096545e62830d28d62b8cd80e4d1c124e608c16c0132a64af42cca.jpg; PDF page 52; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

At the present time, the population of some countries includes a relatively large number of young adults, compared with the number of older people.

Do the advantages of this situation outweigh the disadvantages?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/bcc6f0faae096545e62830d28d62b8cd80e4d1c124e608c16c0132a64af42cca.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/0781e300a643d275be2ff47ae87835b04526e7f95f82d28b63d3a9a199003f50.jpg; PDF page 53; full -->

```text
Test 6
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Songs and singing
• Did you enjoy singing when you were younger? [Why?/Why not?]
• How often do you sing now? [Why?]
• Do you have a favourite song you like listening to? [Why?/Why not?]
• How important is singing in your culture? [Why?]
PART 2
Describe a film/movie actor from your country
who is very popular.
You should say:
who this actor is
what kinds of films/movies he/she acts in
what you know about this actor's life
and explain why this actor is so popular.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Watching films/movies
Example questions:
What are the most popular types of films in your country?
What is the difference between watching a film in the cinema and watching a film at
home?
Do you think cinemas will close in the future?
Theatre
Example questions:
How important is the theatre in your country's history?
How strong a tradition is it today in your country to go to the theatre?
Do you think the theatre should be run as a business or as a public service?
52
```

[Original question page](assets/0781e300a643d275be2ff47ae87835b04526e7f95f82d28b63d3a9a199003f50.jpg)

### Part 2

<!-- Source: /api/assets/0781e300a643d275be2ff47ae87835b04526e7f95f82d28b63d3a9a199003f50.jpg; PDF page 53; full -->

```text
Test 6
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Songs and singing
• Did you enjoy singing when you were younger? [Why?/Why not?]
• How often do you sing now? [Why?]
• Do you have a favourite song you like listening to? [Why?/Why not?]
• How important is singing in your culture? [Why?]
PART 2
Describe a film/movie actor from your country
who is very popular.
You should say:
who this actor is
what kinds of films/movies he/she acts in
what you know about this actor's life
and explain why this actor is so popular.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Watching films/movies
Example questions:
What are the most popular types of films in your country?
What is the difference between watching a film in the cinema and watching a film at
home?
Do you think cinemas will close in the future?
Theatre
Example questions:
How important is the theatre in your country's history?
How strong a tradition is it today in your country to go to the theatre?
Do you think the theatre should be run as a business or as a public service?
52
```

[Original question page](assets/0781e300a643d275be2ff47ae87835b04526e7f95f82d28b63d3a9a199003f50.jpg)

### Part 3

<!-- Source: /api/assets/0781e300a643d275be2ff47ae87835b04526e7f95f82d28b63d3a9a199003f50.jpg; PDF page 53; full -->

```text
Test 6
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Songs and singing
• Did you enjoy singing when you were younger? [Why?/Why not?]
• How often do you sing now? [Why?]
• Do you have a favourite song you like listening to? [Why?/Why not?]
• How important is singing in your culture? [Why?]
PART 2
Describe a film/movie actor from your country
who is very popular.
You should say:
who this actor is
what kinds of films/movies he/she acts in
what you know about this actor's life
and explain why this actor is so popular.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Watching films/movies
Example questions:
What are the most popular types of films in your country?
What is the difference between watching a film in the cinema and watching a film at
home?
Do you think cinemas will close in the future?
Theatre
Example questions:
How important is the theatre in your country's history?
How strong a tradition is it today in your country to go to the theatre?
Do you think the theatre should be run as a business or as a public service?
52
```

[Original question page](assets/0781e300a643d275be2ff47ae87835b04526e7f95f82d28b63d3a9a199003f50.jpg)
