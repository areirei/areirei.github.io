# 剑雅 9 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/5b5ac94ace94b4f41413432aa9a45ecaa15cd8510b97ebd0885850d2e7effaad.jpg; PDF page 48; full -->

```text
SECTION 1 Questions 1–10
Questions 1–5
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
| Apartments | Facilities | Other Information | Cost |
| --- | --- | --- | --- |
| Rose Garden Apartments | studio flat | Example — entertainment programme: Greek dancing | £219 |
| Blue Bay Apartments | large salt-water swimming pool | just (1) __________ metres from beach; near shops | £275 |
| (2) __________ Apartments | terrace | watersports | £490 |
| The Grand | Greek paintings; (3) __________ | overlooking (4) __________; near a supermarket and a disco | (5) £__________ |
```

[Original question page](assets/5b5ac94ace94b4f41413432aa9a45ecaa15cd8510b97ebd0885850d2e7effaad.jpg)

<!-- Source: /api/assets/eadd0d49cd602ec956b03a5868ea3c462f0d6ab44ce3a632145ed310b5ba0e8e.jpg; PDF page 49; full -->

```text
Questions 6–10
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
GREEK ISLAND HOLIDAYS
| Insurance Benefits | Maximum Amount |
| --- | --- |
| Cancellation | (6) £__________ |
| Hospital | £600. Additional benefit allows a (7) __________ to travel to resort |
| (8) __________ departure | Up to £1000. Depends on reason |
| Personal belongings | Up to £3000; £500 for one (9) __________ |
Name of Assistant Manager: Ben (10) __________
Direct phone line: 081260 543216
```

[Original question page](assets/eadd0d49cd602ec956b03a5868ea3c462f0d6ab44ce3a632145ed310b5ba0e8e.jpg)

### Part 2

<!-- Source: /api/assets/06c4a1fc8dd7004af31e8899ef529d3270df6acc0760deed609410a11916d554.jpg; PDF page 50; full -->

```text
Test 3

SECTION 2 Questions 11-20
Questions 11-13

Choose the correct letter, A, B or C.

Winridge Forest Railway Park

11. Simon’s idea for a theme park came from

A his childhood hobby.
B his interest in landscape design.
C his visit to another park.

12 When they started, the family decided to open the park only when

A the weather was expected to be good.
B the children weren't at school.
C there were fewer farming commitments.

13 Since opening, the park has had

A 50,000 visitors.
B 1,000,000 visitors.
C 1,500,000 visitors.

58
```

[Original question page](assets/06c4a1fc8dd7004af31e8899ef529d3270df6acc0760deed609410a11916d554.jpg)

<!-- Source: /api/assets/2b642f8515ee3d5fbb55e4ec17ef1a5d72a1300e6211c25d551f976fb9fb205b.jpg; PDF page 51; full -->

```text
Questions 14–18
What is currently the main area of work of each of the following people?
Choose FIVE answers from the box and write the correct letter, A–H, next to questions 14–18.
Area of work
A advertising
B animal care
C building
D educational links
E engine maintenance
F food and drink
G sales
H staffing
People
14 Simon (the speaker) __________
15 Liz __________
16 Sarah __________
17 Duncan __________
18 Judith __________
Questions 19 and 20
Complete the table below. Write ONE WORD AND/OR NUMBERS for each answer.
| Feature | Size | Biggest challenge | Target age group |
| --- | --- | --- | --- |
| Railway | 1.2 km | Making tunnels | |
| Go-Kart arena | (19) __________ m² | Removing mounds on the track | (20) __________ year-olds |
```

[Original question page](assets/2b642f8515ee3d5fbb55e4ec17ef1a5d72a1300e6211c25d551f976fb9fb205b.jpg)

### Part 3

<!-- Source: /api/assets/a165accc9116b1534b791e76b96147154760fa775dde1573de875cbedfe4b84c.jpg; PDF page 52; full -->

```text
SECTION 3 Questions 21–30
Complete the notes below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
Study Skills Tutorial – Caroline Benning
Dissertation topic: the (21) __________
Strengths: (22) __________; computer modelling
Weaknesses: lack of background information; poor (23) __________ skills
| Possible strategy | Benefits | Problems |
| --- | --- | --- |
| peer group discussion | increases (24) __________ | dissertations tend to contain the same (25) __________ |
| use the (26) __________ service | provides structured programme | limited (27) __________ |
| consult study skills books | are a good source of reference | can be too (28) __________ |
Recommendations: use a card index; read all notes (29) __________
Next tutorial date: (30) __________ January
```

[Original question page](assets/a165accc9116b1534b791e76b96147154760fa775dde1573de875cbedfe4b84c.jpg)

### Part 4

<!-- Source: /api/assets/f57b32c2c86718c5af1a38156021f700332a36c4a3aa10144e9ba0aa801e0499.jpg; PDF page 53; full -->

```text
Listening

SECTION 4 Questions 31-40
Questions 31 and 32
Choose the correct letter, A, B or C.

31 The owners of the underground house

A had no experience of living in a rural area.
B were interested in environmental issues.
C wanted a professional project manager.

32 What does the speaker say about the site of the house?

A The land was quite cheap.
B Stone was being extracted nearby.
C It was in a completely unspoilt area.

61
```

[Original question page](assets/f57b32c2c86718c5af1a38156021f700332a36c4a3aa10144e9ba0aa801e0499.jpg)

<!-- Source: /api/assets/e66699548a7e7b21b9e8a9e762e66c5714d64bac46f41b48a1e770d0f3241ed6.jpg; PDF page 54; full -->

```text
Questions 33–40
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
The Underground House
Design
– Built in the earth, with two floors
– The south-facing side was constructed of two layers of (33) __________
– Photovoltaic tiles were attached
– A layer of foam was used to improve the (34) __________ of the building
Special features
– To increase the light, the building has many internal mirrors and (35) __________
– In future, the house may produce more (36) __________ than it needs
– Recycled wood was used for the (37) __________ of the house
– The system for processing domestic (38) __________ is organic
Environmental issues
– The use of large quantities of (39) __________ in construction was environmentally harmful
– But the house will have paid its ‘environmental debt’ within (40) __________
```

[Original question page](assets/e66699548a7e7b21b9e8a9e762e66c5714d64bac46f41b48a1e770d0f3241ed6.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/d9f50070f773c458dca86525ff27c74b8cfa5d8cb30eede28a95dbc88452b765.jpg; PDF page 55; full -->

```text
Reading

READING PASSAGE 1

You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.

Attitudes to language

It is not easy to be systematic and objective about language study. Popular linguistic debate
regularly deteriorates into invective and polemic. Language belongs to everyone, so most
people feel they have a right to hold an opinion about it. And when opinions differ, emotions
can run high. Arguments can start as easily over minor points of usage as over major policies
of linguistic education.

Language, moreover, is a very public behaviour, so it is easy for different usages to be noted
and criticised. No part of society or social behaviour is exempt: linguistic factors influence
how we judge personality, intelligence, social status, educational standards, job aptitude,
and many other areas of identity and social survival. As a result, it is easy to hurt, and to be
hurt, when language use is unfeelingly attacked.

In its most general sense, prescriptivism is the view that one variety of language has an
inherently higher value than others, and that this ought to be imposed on the whole of

the speech community. The view is propounded especially in relation to grammar and
vocabulary, and frequently with reference to pronunciation. The variety which is favoured,
in this account, is usually a version of the ‘standard’ written language, especially as
encountered in literature, or in the formal spoken language which most closely reflects this
style. Adherents to this variety are said to speak or write ‘correctly’; deviations from it are
said to be ‘incorrect’.

All the main languages have been studied prescriptively, especially in the 18th century
approach to the writing of grammars and dictionaries. The aims of these early grammarians
were threefold: (a) they wanted to codify the principles of their languages, to show that
there was a system beneath the apparent chaos of usage, (b) they wanted a means of
settling disputes over usage, and (c) they wanted to point out what they felt to be common
errors, in order to ‘improve’ the language. The authoritarian nature of the approach is best
characterised by its reliance on ‘rules’ of grammar. Some usages are ‘prescribed’, to be
learnt and followed accurately; others are ‘proscribed’, to be avoided. In this early period,
there were no half-measures: usage was either right or wrong, and it was the task of the
grammarian not simply to record alternatives, but to pronounce judgement upon them.

These attitudes are still with us, and they motivate a widespread concern that linguistic
standards should be maintained. Nevertheless, there is an alternative point of view that
is concerned less with standards than with the facts of linguistic usage. This approach is
summarised in the statement that it is the task of the grammarian to describe, not prescribe

63
```

[Original question page](assets/d9f50070f773c458dca86525ff27c74b8cfa5d8cb30eede28a95dbc88452b765.jpg)

<!-- Source: /api/assets/2ac9b329ab846a0c089c78bf7b41f63130486e0f54a80fa679387feca2d93961.jpg; PDF page 56; full -->

```text
Test 3

-to record the facts of linguistic diversity, and not to attempt the impossible tasks of
evaluating language variation or halting language change. In the second half of the 18th
century, we already find advocates of this view, such as Joseph Priestley, whose Rudiments
of English Grammar (1761) insists that ‘the custom of speaking is the original and only
just standard of any language’. Linguistic issues, it is argued, cannot be solved by logic

and legislation. And this view has become the tenet of the modern linguistic approach to
grammatical analysis.

In our own time, the opposition between ‘descriptivists’ and ‘prescriptivists’ has often
become extreme, with both sides painting unreal pictures of the other. Descriptive
grammarians have been presented as people who do not care about standards, because
of the way they see all forms of usage as equally valid. Prescriptive grammarians have
been presented as blind adherents to a historical tradition. The opposition has even been
presented in quasi-political terms - of radical liberalism vs elitist conservatism.

64
```

[Original question page](assets/2ac9b329ab846a0c089c78bf7b41f63130486e0f54a80fa679387feca2d93961.jpg)

<!-- Source: /api/assets/a41824d8e855cb5fe8a6687b1d0397b31e9c20e90f4b9c8e5a43e8b26af935a6.jpg; PDF page 57; full -->

```text
Questions 1–8
Do the following statements agree with the claims of the writer in Reading Passage 1?
In boxes 1–8 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
1 There are understandable reasons why arguments occur about language.
2 People feel more strongly about language education than about small differences in language usage.
3 Our assessment of a person’s intelligence is affected by the way he or she uses language.
4 Prescriptive grammar books cost a lot of money to buy in the 18th century.
5 Prescriptivism still exists today.
6 According to descriptivists it is pointless to try to stop language change.
7 Descriptivism only appeared after the 18th century.
8 Both descriptivists and prescriptivists have been misrepresented.
```

[Original question page](assets/a41824d8e855cb5fe8a6687b1d0397b31e9c20e90f4b9c8e5a43e8b26af935a6.jpg)

<!-- Source: /api/assets/35a5743ba036dfca912407babd72c598688aff139c51957b930a2ed2a22cd3d7.jpg; PDF page 58; full -->

```text
Questions 9–12
Complete the summary using the list of words, A–I, below.
Write the correct letter, A–I, in boxes 9–12 on your answer sheet.
The language debate
According to (9) __________, there is only one correct form of language. Linguists who take this approach to language place great importance on grammatical (10) __________. Conversely, the view of (11) __________, such as Joseph Priestley, is that grammar should be based on (12) __________.
A descriptivists
B language experts
C popular speech
D formal language
E evaluation
F rules
G modern linguists
H prescriptivists
I change
Question 13
Choose the correct letter, A, B, C or D. Write the correct letter in box 13 on your answer sheet.
What is the writer’s purpose in Reading Passage 1?
A to argue in favour of a particular approach to writing dictionaries and grammar books
B to present a historical account of differing views of language
C to describe the differences between spoken and written language
D to show how a certain view of language has been discredited
```

[Original question page](assets/35a5743ba036dfca912407babd72c598688aff139c51957b930a2ed2a22cd3d7.jpg)

<!-- Source: /api/assets/546574713e54927ec9f3c362a43ef10bee16f34303e2555b1dba22846fde3004.jpg; PDF page 59; full -->

```text
Reading

READING PASSAGE 2

You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.

Tidal Power

Undersea turbines which produce electricity from the tides are set to
become an important source of renewable energy for Britain. It is still too
early to predict the extent of the impact they may have, but all the signs are
that they will play a significant role in the future

A Operating on the same principle as wind turbines, the power in sea turbines
comes from tidal currents which turn blades similar to ships’ propellers,
but, unlike wind, the tides are predictable and the power input is constant.
The technology raises the prospect of Britain becoming self-sufficient in
renewable energy and drastically reducing its carbon dioxide emissions. If
tide, wind and wave power are all developed, Britain would be able to close
gas, coal and nuclear power plants and export renewable power to other
parts of Europe. Unlike wind power, which Britain originally developed and
then abandoned for 20 years allowing the Dutch to make it a major industry,
undersea turbines could become a big export earner to island nations such
as Japan and New Zealand.

B Tidal sites have already been identified that will produce one sixth or more
of the UK’s power - and at prices competitive with modern gas turbines and
undercutting those of the already ailing nuclear industry. One site alone, the
Pentland Firth, between Orkney and mainland Scotland, could produce 10%
of the country’s electricity with banks of turbines under the sea, and another
at Alderney in the Channel Islands three times the 1,200 megawatts of
Britain’s largest and newest nuclear plant, Sizewell B, in Suffolk. Other
sites identified include the Bristol Channel and the west coast of Scotland,
particularly the channel between Campbeltown and Northern Ireland.

C Work on designs for the new turbine blades and sites are well advanced
at the University of Southampton’s sustainable energy research group. The
first station is expected to be installed off Lynmouth in Devon shortly to
test the technology in a venture jointly funded by the department of Trade
and Industry and the European Union. AbuBakr Bahaj, in charge of the
Southampton research, said: ‘The prospects for energy from tidal currents
are far better than from wind because the flows of water are predictable
and constant. The technology for dealing with the hostile saline environment
under the sea has been developed in the North Sea oil industry and much

67
```

[Original question page](assets/546574713e54927ec9f3c362a43ef10bee16f34303e2555b1dba22846fde3004.jpg)

<!-- Source: /api/assets/e9b516deab29bbc9008c1ee7100fbe16b7c4f92a4f9d70b8e44eaac8a94d57fe.jpg; PDF page 60; full -->

```text
Test 3

68

is already known about turbine blade design, because of wind power and
ship propellers. There are a few technical difficulties, but I believe in the

next five to ten years we will be installing commercial marine turbine farms.’
Southampton has been awarded £215,000 over three years to develop

the turbines and is working with Marine Current Turbines, a subsidiary of

IT power, on the Lynmouth project. EU research has now identified 106
potential sites for tidal power, 80% round the coasts of Britain. The best
sites are between islands or around heavily indented coasts where there are
strong tidal currents.

D A marine turbine blade needs to be only one third of the size of a wind
generator to produce three times as much power. The blades will be about
20 metres in diameter, so around 30 metres of water is required. Unlike
wind power, there are unlikely to be environmental objections. Fish and other
creatures are thought unlikely to be at risk from the relatively slow-turning
blades. Each turbine will be mounted on a tower which will connect to the
national power supply grid via underwater cables. The towers will stick out of
the water and be lit, to warn shipping, and also be designed to be lifted out
of the water for maintenance and to clean seaweed from the blades.

E Dr Bahaj has done most work on the Alderney site, where there are
powerful currents. The single undersea turbine farm would produce far more
power than needed for the Channel Islands and most would be fed into the
French Grid and be re-imported into Britain via the cable under the Channel.

F One technical difficulty is cavitation, where low pressure behind a turning
blade causes air bubbles. These can cause vibration and damage the blades
of the turbines. Dr Bahaj said: ‘We have to test a number of blade types to
avoid this happening or at least make sure it does not damage the turbines
or reduce performance. Another slight concern is submerged debris floating
into the blades. So far we do not know how much of a problem it might

be. We will have to make the turbines robust because the sea is a hostile
environment, but all the signs that we can do it are good.’
```

[Original question page](assets/e9b516deab29bbc9008c1ee7100fbe16b7c4f92a4f9d70b8e44eaac8a94d57fe.jpg)

<!-- Source: /api/assets/8f7037dc653632e567ae9f83f95f42d78d4eb3a34ab96b4434425d70b3cbc675.jpg; PDF page 61; full -->

```text
Questions 14–17
Reading Passage 2 has six paragraphs, A–F.
Which paragraph contains the following information?
Write the correct letter, A–F, in boxes 14–17 on your answer sheet.
NB You may use any letter more than once.
14 the location of the first test site
15 a way of bringing the power produced on one site back into Britain
16 a reference to a previous attempt by Britain to find an alternative source of energy
17 mention of the possibility of applying technology from another industry
Questions 18–22
Choose FIVE letters, A–J. Write the correct letters in boxes 18–22 on your answer sheet.
Which FIVE of the following claims about tidal power are made by the writer?
A It is a more reliable source of energy than wind power.
B It would replace all other forms of energy in Britain.
C Its introduction has come as a result of public pressure.
D It would cut down on air pollution.
E It could contribute to the closure of many existing power stations in Britain.
F It could be a means of increasing national income.
G It could face a lot of resistance from other fuel industries.
H It could be sold more cheaply than any other type of fuel.
I It could compensate for the shortage of inland sites for energy production.
J It is best produced in the vicinity of coastlines with particular features.
```

[Original question page](assets/8f7037dc653632e567ae9f83f95f42d78d4eb3a34ab96b4434425d70b3cbc675.jpg)

<!-- Source: /api/assets/599e5d20bf16da21398089b1aa482db9f1c4ead303bd25db2dfa85abd0488a09.jpg; PDF page 62; full -->

```text
Questions 23–26
Label the diagram below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 23–26 on your answer sheet.
An Undersea Turbine
[Original tower/turbine/fish diagram retained.]
Whole tower can be raised for (23) __________ and the extraction of seaweed from the blades [arrow to bracket spanning the tower].
Sea life not in danger due to the fact that blades are comparatively (24) __________ [arrow to blade/fish area].
Air bubbles result from the (25) __________ behind blades. This is known as (26) __________ [arrow to bubbles behind blades].
```

[Original question page](assets/599e5d20bf16da21398089b1aa482db9f1c4ead303bd25db2dfa85abd0488a09.jpg)

![Original figure](assets/599e5d20bf16da21398089b1aa482db9f1c4ead303bd25db2dfa85abd0488a09.jpg)

<!-- Source: /api/assets/e79e64940ddb7e84ddbb2a5e055b2453708f78e42b5374d520c56ada6cfe4b47.jpg; PDF page 63; full -->

```text
Reading

READING PASSAGE 3

You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.

Information theory – the big idea
Information theory lies at the heart of everything — from DVD players
and the genetic code of DNA to the physics of the universe at its most
fundamental. It has been central to the development of the science of
communication, which enables data to be sent electronically and has
therefore had a major impact on our lives

A In April 2002 an event took place which demonstrated one of the many applications
of information theory. The space probe, Voyager I, launched in 1977, had sent back
spectacular images of Jupiter and Saturn and then soared out of the Solar System on a
one-way mission to the stars. After 25 years of exposure to the freezing temperatures
of deep space, the probe was beginning to show its age. Sensors and circuits were
on the brink of failing and NASA experts realised that they had to do something or
lose contact with their probe forever. The solution was to get a message to Voyager
I to instruct it to use spares to change the failing parts. With the probe 12 billion
kilometres from Earth, this was not an easy task. By means of a radio dish belonging
to NASA’s Deep Space Network, the message was sent out into the depths of space.
Even travelling at the speed of light, it took over 11 hours to reach its target, far
beyond the orbit of Pluto. Yet, incredibly, the little probe managed to hear the faint
call from its home planet, and successfully made the switchover.

B It was the longest-distance repair job in history, and a triumph for the NASA
engineers. But it also highlighted the astonishing power of the techniques developed
by American communications engineer Claude Shannon, who had died just a year
earlier. Born in 1916 in Petoskey, Michigan, Shannon showed an early talent for
maths and for building gadgets, and made breakthroughs in the foundations of
computer technology when still a student. While at Bell Laboratories, Shannon
developed information theory, but shunned the resulting acclaim. In the 1940s,
he single-handedly created an entire science of communication which has since
inveigled its way into a host of applications, from DVDs to satellite communications
to bar codes — any area, in short, where data has to be conveyed rapidly yet
accurately.

71
```

[Original question page](assets/e79e64940ddb7e84ddbb2a5e055b2453708f78e42b5374d520c56ada6cfe4b47.jpg)

<!-- Source: /api/assets/c4f5c5bb018842fd4070d26e52454a1cdf67533d1b481f4f58b01fecc48cd366.jpg; PDF page 64; full -->

```text
Test 3

C This all seems light years away from the down-to-earth uses Shannon originally
had for his work, which began when he was a 22-year-old graduate engineering
student at the prestigious Massachusetts Institute of Technology in 1939. He set out
with an apparently simple aim: to pin down the precise meaning of the concept
of ‘information’. The most basic form of information, Shannon argued, is whether
something is true or false - which can be captured in the binary unit, or ‘bit’, of the
form 1 or 0. Having identified this fundamental unit, Shannon set about defining
otherwise vague ideas about information and how to transmit it from place to place.
In the process he discovered something surprising: it is always possible to guarantee
information will get through random interference - ‘noise’ - intact.

D Noise usually means unwanted sounds which interfere with genuine information.
Information theory generalises this idea via theorems that capture the effects of
noise with mathematical precision. In particular, Shannon showed that noise sets
a limit on the rate at which information can pass along communication channels
while remaining error-free. This rate depends on the relative strengths of the signal
and noise travelling down the communication channel, and on its capacity (its
‘bandwidth’). The resulting limit, given in units of bits per second, is the absolute
maximum rate of error-free communication given signal strength and noise level. The
trick, Shannon showed, is to find ways of packaging up - ‘coding’ - information to
cope with the ravages of noise, while staying within the information-carrying capacity
- ‘bandwidth’ - of the communication system being used.

E Over the years scientists have devised many such coding methods, and they have
proved crucial in many technological feats. The Voyager spacecraft transmitted
data using codes which added one extra bit for every single bit of information; the
result was an error rate of just one bit in 10,000 - and stunningly clear pictures of
the planets. Other codes have become part of everyday life - such as the Universal
Product Code, or bar code, which uses a simple error-detecting system that ensures
supermarket check-out lasers can read the price even on, say, a crumpled bag of
crisps. As recently as 1993, engineers made a major breakthrough by discovering
so-called turbo codes - which come very close to Shannon’s ultimate limit for the
maximum rate that data can be transmitted reliably, and now play a key role in the
mobile videophone revolution.

F Shannon also laid the foundations of more efficient ways of storing information, by
stripping out superfluous (‘redundant’) bits from data which contributed little real
information. As mobile phone text messages like ‘I CN C U’ show, it is often possible
to leave out a lot of data without losing much meaning. As with error correction,
however, there’s a limit beyond which messages become too ambiguous. Shannon
showed how to calculate this limit, opening the way to the design of compression
methods that cram maximum information into the minimum space.

72
```

[Original question page](assets/c4f5c5bb018842fd4070d26e52454a1cdf67533d1b481f4f58b01fecc48cd366.jpg)

<!-- Source: /api/assets/0462acd8e1a7ae62e2a60736825d38bfc6ea27423c168e36fe258645b7cac01e.jpg; PDF page 65; full -->

```text
Questions 27–32
Reading Passage 3 has six paragraphs, A–F.
Which paragraph contains the following information?
Write the correct letter, A–F, in boxes 27–32 on your answer sheet.
27 an explanation of the factors affecting the transmission of information
28 an example of how unnecessary information can be omitted
29 a reference to Shannon’s attitude to fame
30 details of a machine capable of interpreting incomplete information
31 a detailed account of an incident involving information theory
32 a reference to what Shannon initially intended to achieve in his research
```

[Original question page](assets/0462acd8e1a7ae62e2a60736825d38bfc6ea27423c168e36fe258645b7cac01e.jpg)

<!-- Source: /api/assets/20617619f3007b99b57dae705f13eb12c1b3a7b6c1f259630ced961ec601072c.jpg; PDF page 66; full -->

```text
Questions 33–37
Complete the notes below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 33–37 on your answer sheet.
The Voyager 1 Space Probe
– The probe transmitted pictures of both (33) __________ and __________, then left the (34) __________.
– The freezing temperatures were found to have a negative effect on parts of the space probe.
– Scientists feared that both the (35) __________ and __________ were about to stop working.
– The only hope was to tell the probe to replace them with (36) __________ – but distance made communication with the probe difficult.
– A (37) __________ was used to transmit the message at the speed of light.
– The message was picked up by the probe and the switchover took place.
```

[Original question page](assets/20617619f3007b99b57dae705f13eb12c1b3a7b6c1f259630ced961ec601072c.jpg)

<!-- Source: /api/assets/801ee52c5c951a71893b8f3ba1c8d9e3aef05caee51ed910ac0e82c71ed539e6.jpg; PDF page 67; full -->

```text
Questions 38–40
Do the following statements agree with the information given in Reading Passage 3?
In boxes 38–40 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
38 The concept of describing something as true or false was the starting point for Shannon in his attempts to send messages over distances.
39 The amount of information that can be sent in a given time period is determined with reference to the signal strength and noise level.
40 Products have now been developed which can convey more information than Shannon had anticipated as possible.
```

[Original question page](assets/801ee52c5c951a71893b8f3ba1c8d9e3aef05caee51ed910ac0e82c71ed539e6.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/47e35f1dcc2f455caa533f47280ec0f66958ad63da71d8c20a38df96682672bd.jpg; PDF page 68; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below give information on the ages of the populations of Yemen and Italy in 2000 and projections for 2050.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/47e35f1dcc2f455caa533f47280ec0f66958ad63da71d8c20a38df96682672bd.jpg)

![Original figure](assets/47e35f1dcc2f455caa533f47280ec0f66958ad63da71d8c20a38df96682672bd.jpg)

### Task 2

<!-- Source: /api/assets/df8f46d4d8a83b78a5b1264a4399dabacc47ec42e609817fa25e18dcfac060de.jpg; PDF page 69; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people say that the best way to improve public health is by increasing the number of sports facilities. Others, however, say that this would have little effect on public health and that other measures are required.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/df8f46d4d8a83b78a5b1264a4399dabacc47ec42e609817fa25e18dcfac060de.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/aa0fd0d21d4a0afb7e3bbe61da7d4df13bc92ba7eeeb01efca42a22e2ea4f51e.jpg; PDF page 70; full -->

```text
Test 3

SPEAKING

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Telephoning

* How often do you make telephone calls? [Why/Why not?]

* Who do you spend most time talking to on the telephone? [Why?]

* When do you think you'll next make a telephone call? [Why?]

* Do you sometimes prefer to send a text message instead of telephoning? [Why/Why not?]

PART 2
Describe a journey [e.g. by car, plane, boat] that you remember well.
You should say:
where you went
how you travelled
why you went on the journey
and explain why you remember this journey well.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Reasons for daily travel

Example questions:

Why do people need to travel every day?

What problems can people have when they are on their daily journey, for example to
work or school? Why is this?

Some people say that daily journeys like these will not be so common in the future. Do
you agree or disagree? Why?

Benefits of international travel

Example questions:

What do you think people can learn from travelling to other countries? Why?

Can travel make a positive difference to the economy of a country? How?

Do you think a society can benefit if its members have experience of travelling to other
countries? In what ways?

78
```

[Original question page](assets/aa0fd0d21d4a0afb7e3bbe61da7d4df13bc92ba7eeeb01efca42a22e2ea4f51e.jpg)

### Part 2

<!-- Source: /api/assets/aa0fd0d21d4a0afb7e3bbe61da7d4df13bc92ba7eeeb01efca42a22e2ea4f51e.jpg; PDF page 70; full -->

```text
Test 3

SPEAKING

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Telephoning

* How often do you make telephone calls? [Why/Why not?]

* Who do you spend most time talking to on the telephone? [Why?]

* When do you think you'll next make a telephone call? [Why?]

* Do you sometimes prefer to send a text message instead of telephoning? [Why/Why not?]

PART 2
Describe a journey [e.g. by car, plane, boat] that you remember well.
You should say:
where you went
how you travelled
why you went on the journey
and explain why you remember this journey well.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Reasons for daily travel

Example questions:

Why do people need to travel every day?

What problems can people have when they are on their daily journey, for example to
work or school? Why is this?

Some people say that daily journeys like these will not be so common in the future. Do
you agree or disagree? Why?

Benefits of international travel

Example questions:

What do you think people can learn from travelling to other countries? Why?

Can travel make a positive difference to the economy of a country? How?

Do you think a society can benefit if its members have experience of travelling to other
countries? In what ways?

78
```

[Original question page](assets/aa0fd0d21d4a0afb7e3bbe61da7d4df13bc92ba7eeeb01efca42a22e2ea4f51e.jpg)

### Part 3

<!-- Source: /api/assets/aa0fd0d21d4a0afb7e3bbe61da7d4df13bc92ba7eeeb01efca42a22e2ea4f51e.jpg; PDF page 70; full -->

```text
Test 3

SPEAKING

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Telephoning

* How often do you make telephone calls? [Why/Why not?]

* Who do you spend most time talking to on the telephone? [Why?]

* When do you think you'll next make a telephone call? [Why?]

* Do you sometimes prefer to send a text message instead of telephoning? [Why/Why not?]

PART 2
Describe a journey [e.g. by car, plane, boat] that you remember well.
You should say:
where you went
how you travelled
why you went on the journey
and explain why you remember this journey well.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Reasons for daily travel

Example questions:

Why do people need to travel every day?

What problems can people have when they are on their daily journey, for example to
work or school? Why is this?

Some people say that daily journeys like these will not be so common in the future. Do
you agree or disagree? Why?

Benefits of international travel

Example questions:

What do you think people can learn from travelling to other countries? Why?

Can travel make a positive difference to the economy of a country? How?

Do you think a society can benefit if its members have experience of travelling to other
countries? In what ways?

78
```

[Original question page](assets/aa0fd0d21d4a0afb7e3bbe61da7d4df13bc92ba7eeeb01efca42a22e2ea4f51e.jpg)
