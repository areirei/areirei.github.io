# 剑雅 9 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 148

TEST 3 LISTENING
1 300
2 Sunshade
3 balcony
4 forest / forests
5 319
6 10,000
7 relative
8 missed
9 item
10 Ludlow
11 C
12 A
13 C
14 E
15 H
16 F
17 C
18 G
19 120
20 5 to 12
21 fishing industry
22 statistics
23 note-taking
24 confidence
25 ideas
26 student support
27 places
28 general
29 3 times
30 25
31 B
32 A
33 glass
34 insulation
35 windows
36 electricity
37 floor / floors
38 waste
39 concrete
40 15 years
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. 300

2. Sunshade

3. balcony

4. forest / forests

5. 319

6. 10,000 / 10000

7. relative

8. missed

9. item

10. Ludlow

### Part 2 · source page 148

TEST 3 LISTENING
1 300
2 Sunshade
3 balcony
4 forest / forests
5 319
6 10,000
7 relative
8 missed
9 item
10 Ludlow
11 C
12 A
13 C
14 E
15 H
16 F
17 C
18 G
19 120
20 5 to 12
21 fishing industry
22 statistics
23 note-taking
24 confidence
25 ideas
26 student support
27 places
28 general
29 3 times
30 25
31 B
32 A
33 glass
34 insulation
35 windows
36 electricity
37 floor / floors
38 waste
39 concrete
40 15 years
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. C

12. A

13. C

14. E

15. H

16. F

17. C

18. G

19. 120

20. 5 to 12

### Part 3 · source page 148

TEST 3 LISTENING
1 300
2 Sunshade
3 balcony
4 forest / forests
5 319
6 10,000
7 relative
8 missed
9 item
10 Ludlow
11 C
12 A
13 C
14 E
15 H
16 F
17 C
18 G
19 120
20 5 to 12
21 fishing industry
22 statistics
23 note-taking
24 confidence
25 ideas
26 student support
27 places
28 general
29 3 times
30 25
31 B
32 A
33 glass
34 insulation
35 windows
36 electricity
37 floor / floors
38 waste
39 concrete
40 15 years
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. fishing industry

22. statistics

23. note-taking

24. confidence

25. ideas

26. student support

27. places

28. general

29. 3 times

30. 25

### Part 4 · source page 148

TEST 3 LISTENING
1 300
2 Sunshade
3 balcony
4 forest / forests
5 319
6 10,000
7 relative
8 missed
9 item
10 Ludlow
11 C
12 A
13 C
14 E
15 H
16 F
17 C
18 G
19 120
20 5 to 12
21 fishing industry
22 statistics
23 note-taking
24 confidence
25 ideas
26 student support
27 places
28 general
29 3 times
30 25
31 B
32 A
33 glass
34 insulation
35 windows
36 electricity
37 floor / floors
38 waste
39 concrete
40 15 years
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. B

32. A

33. glass

34. insulation

35. windows

36. electricity

37. floor / floors

38. waste

39. concrete

40. 15 years

## A 类阅读

### Academic Reading · source page 149

ACADEMIC READING
1 YES
2 NO
3 YES
4 NOT GIVEN
5 YES
6 YES
7 NO
8 YES
9 H
10 F
11 A
12 C
13 B
14 C
15 E
16 A
17 C
18 A
19 D
20 E
21 F
22 J
23 maintenance
24 slow (turning)
25 low pressure
26 cavitation
27 D
28 F
29 B
30 E
31 A
32 C
33 Jupiter; Saturn [both required, either order, one mark]
34 Solar System
35 sensors; circuits [both required, either order, one mark]
36 spares
37 radio dish
38 TRUE
39 TRUE
40 FALSE
18–22 IN ANY ORDER: A; D; E; F; J
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. YES

2. NO

3. YES

4. NOT GIVEN

5. YES

6. YES

7. NO

8. YES

9. H

10. F

11. A

12. C

13. B

14. C

15. E

16. A

17. C

18. A / D / E / F / J

19. A / D / E / F / J

20. A / D / E / F / J

21. A / D / E / F / J

22. A / D / E / F / J

23. maintenance

24. slow / slow turning

25. low pressure

26. cavitation

27. D

28. F

29. B

30. E

31. A

32. C

33. Jupiter Saturn / Jupiter, Saturn / Jupiter and Saturn / Jupiter & Saturn / Jupiter; Saturn / Jupiter/Saturn / Jupiter,Saturn / Saturn Jupiter / Saturn, Jupiter / Saturn and Jupiter / Saturn & Jupiter / Saturn; Jupiter / Saturn/Jupiter / Saturn,Jupiter

34. Solar System

35. sensors circuits / sensors, circuits / sensors and circuits / sensors & circuits / sensors; circuits / sensors/circuits / sensors,circuits / circuits sensors / circuits, sensors / circuits and sensors / circuits & sensors / circuits; sensors / circuits/sensors / circuits,sensors

36. spares

37. radio dish

38. TRUE

39. TRUE

40. FALSE

## A 类写作

### Writing material: c9-t3-w-1

Legend checked: diagonal stripes0–14years, dark15–59years, white60+years. Yemen2000:50.1%,46.3%,3.6%; Yemen2050 projected:37.0%,57.3%,5.7%. Italy2000:14.3%,61.6%,24.1%; Italy2050 projected:11.5%,46.2%,42.3%. Each pie totals100%. Yemen remains younger; its working-age share rises while Italy’s falls. Both elderly shares grow and child shares fall. Italy’s elderly share approaches but does not exceed its15–59share in2050. Future values are projections, not observed results. Percentages do not establish absolute population sizes.



### Writing material: c9-t3-w-2

Discuss both increased sports facilities as the best solution and the view that their effect is limited and other measures are required. Give own opinion; do not replace the second view with a claim that sport itself has no health benefit.



## 口语
