# 剑雅 12 · Test 8 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 123

TEST 8 LISTENING
1 temporary
2 doctor
3 Africa
4 youth
5 May
6 cheese
7 Arbuthnot
8 DG7 4PH
9 Tuesday
10 talk/presentation
11 A
12 C
13 B
14 B
15 H
16 C
17 F
18 G
19 I
20 B
21 classification
22 worst
23 slides
24 issues
25 F
26 A
27 E
28 C
29 G
30 B
31 garden(s)
32 political
33 work/study
34 fountain
35 social
36 lively
37 training
38 culture
39 nature
40 silent
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. temporary

2. doctor

3. Africa

4. youth

5. May

6. cheese

7. Arbuthnot

8. DG7 4PH / DG74PH

9. Tuesday

10. talk / presentation

### Part 2 · source page 123

TEST 8 LISTENING
1 temporary
2 doctor
3 Africa
4 youth
5 May
6 cheese
7 Arbuthnot
8 DG7 4PH
9 Tuesday
10 talk/presentation
11 A
12 C
13 B
14 B
15 H
16 C
17 F
18 G
19 I
20 B
21 classification
22 worst
23 slides
24 issues
25 F
26 A
27 E
28 C
29 G
30 B
31 garden(s)
32 political
33 work/study
34 fountain
35 social
36 lively
37 training
38 culture
39 nature
40 silent
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A

12. C

13. B

14. B

15. H

16. C

17. F

18. G

19. I

20. B

### Part 3 · source page 123

TEST 8 LISTENING
1 temporary
2 doctor
3 Africa
4 youth
5 May
6 cheese
7 Arbuthnot
8 DG7 4PH
9 Tuesday
10 talk/presentation
11 A
12 C
13 B
14 B
15 H
16 C
17 F
18 G
19 I
20 B
21 classification
22 worst
23 slides
24 issues
25 F
26 A
27 E
28 C
29 G
30 B
31 garden(s)
32 political
33 work/study
34 fountain
35 social
36 lively
37 training
38 culture
39 nature
40 silent
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. classification

22. worst

23. slides

24. issues

25. F

26. A

27. E

28. C

29. G

30. B

### Part 4 · source page 123

TEST 8 LISTENING
1 temporary
2 doctor
3 Africa
4 youth
5 May
6 cheese
7 Arbuthnot
8 DG7 4PH
9 Tuesday
10 talk/presentation
11 A
12 C
13 B
14 B
15 H
16 C
17 F
18 G
19 I
20 B
21 classification
22 worst
23 slides
24 issues
25 F
26 A
27 E
28 C
29 G
30 B
31 garden(s)
32 political
33 work/study
34 fountain
35 social
36 lively
37 training
38 culture
39 nature
40 silent
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. garden / gardens

32. political

33. work / study

34. fountain

35. social

36. lively

37. training

38. culture

39. nature

40. silent

## A 类阅读

### Academic Reading · source page 124

TEST 8 READING
1 obsidian
2 spears
3 beads
4 impurities
5 Romans
6 lead
7 clouding
8 taxes
9 TRUE
10 FALSE
11 NOT GIVEN
12 TRUE
13 FALSE
14 D
15 A
16 C
17 A
18 C
19 E
20 D
21 F
22 A
23 NO
24 NOT GIVEN
25 YES
26 YES
27 iv
28 ii
29 vi
30 viii
31 vii
32 i
33 iii
34 YES
35 NOT GIVEN
36 NO
37 NO
38 information
39 financial
40 shareholders/investors
If you score: 0–14 unlikely;15–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. obsidian

2. spears

3. beads

4. impurities

5. Romans

6. lead

7. clouding

8. taxes

9. TRUE

10. FALSE

11. NOT GIVEN

12. TRUE

13. FALSE

14. D

15. A

16. C

17. A

18. C

19. E

20. D

21. F

22. A

23. NO

24. NOT GIVEN

25. YES

26. YES

27. iv

28. ii

29. vi

30. viii

31. vii

32. i

33. iii

34. YES

35. NOT GIVEN

36. NO

37. NO

38. information

39. financial

40. shareholders / investors

## A 类写作

### Writing material: c12-t8-w-1

Five numbered stages, original labels retained. Cold water pumped down4.5km via injection well into geothermal zone of hot rocks. Water passes through hot rocks and is heated; hot water pumped up through production well to surface vessel labelled Condenser. Steam exits that vessel and drives turbine; turbine powers generator producing electricity supplied to grid. Source calls vessel Condenser even though diagram shows steam produced there; preserve original label rather than silently correcting to boiler. Do not invent temperature, fuels, combustion, additional recirculation pipe or imply generator drives turbine.



### Writing material: c12-t8-w-2

Discuss concern about selfishness resulting from children’s everyday choices and the value of children deciding matters affecting them. Give opinion; a generic discussion of adult freedom would miss scope.



## 口语
