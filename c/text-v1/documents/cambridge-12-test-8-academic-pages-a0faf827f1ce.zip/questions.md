# 剑雅 12 · Test 8

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/40ec295efbdc00261bea509e26a95a0f3580441f70cd390dc12789d6c9ced984.jpg; PDF page 75; full -->

```text
LISTENING
SECTION 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Cycle tour leader: Applicant enquiry
Example Name: Margaret Smith
About the applicant:
• wants a (1) __________ job
• will soon start work as a (2) __________
• has led cycle trips in (3) __________
• interested in being a leader of a cycling trip for families
• is currently doing voluntary work with members of a (4) __________ club
• available for five months from the 1st of (5) __________
• can't eat (6) __________
Contact details:
• address: 27 (7) __________ Place, Dumfries
• postcode: (8) __________
Interview:
• interview at 2.30 pm on (9) __________
• will plan a short (10) __________ about being a tour guide
```

[Original question page](assets/40ec295efbdc00261bea509e26a95a0f3580441f70cd390dc12789d6c9ced984.jpg)

### Part 2

<!-- Source: /api/assets/cf344416b005d4da185919bba6f217b21246fb8825081da8c8f49959da50c142.jpg; PDF page 76; full -->

```text
Listening
SECTION 2
Questions 11-14
Questions 11-20
Choose the correct letter, A, B or C.
Visiting the Sheepmarket area
11 Which is the most rapidly-growing group of residents in the Sheepmarket area?
A young professional people
B students from the university
C employees in the local market
12 The speaker recommends the side streets in the Sheepmarket for their
A international restaurants.
B historical buildings.
C arts and crafts.
13 Clothes designed by entrants for the Young Fashion competition must
A be modelled by the designers themselves.
B be inspired by aspects of contemporary culture.
C be made from locally produced materials.
14 Car parking is free in some car parks if you
A stay for less than an hour.
B buy something in the shops.
C park in the evenings or at weekends.
75
```

[Original question page](assets/cf344416b005d4da185919bba6f217b21246fb8825081da8c8f49959da50c142.jpg)

<!-- Source: /api/assets/1d6778725281113e232195581c9be9dd7c5d0be0a7e6bf8a56c6c181f27f9f0f.jpg; PDF page 77; full -->

```text
Questions 15–20
Label the map below. Write the correct letter, A–I, next to Questions 15–20.
Art and History in the Sheepmarket
[Original map retained: north arrow; Bank, Station Square, Hill Road, City Road, Public Gardens and Crawley Road; locations A–I.]
15 The Reynolds House __________
16 The Thumb __________
17 The Museum __________
18 The Contemporary Art Gallery __________
19 The Warner Gallery __________
20 Nucleus __________
```

[Original question page](assets/1d6778725281113e232195581c9be9dd7c5d0be0a7e6bf8a56c6c181f27f9f0f.jpg)

![Original figure](assets/1d6778725281113e232195581c9be9dd7c5d0be0a7e6bf8a56c6c181f27f9f0f.jpg)

### Part 3

<!-- Source: /api/assets/3feb0097e35e8166ee0f5f72e7854bb82c17655eefbc23d951e7b3ca4cb5bc1a.jpg; PDF page 78; full -->

```text
SECTION 3 Questions 21–30
Questions 21–24
Complete the table below. Write ONE WORD ONLY for each answer.
Presentation on film adaptations of Shakespeare’s plays
| Stages of presentation | Work still to be done |
| --- | --- |
| Introduce Giannetti’s book containing a (21) __________ of adaptations | Organise notes |
| Ask class to suggest the (22) __________ adaptations | No further work needed |
| Present Rachel Malchow’s ideas | Prepare some (23) __________ |
| Discuss relationship between adaptations and (24) __________ at the time of making the film | No further work needed |
```

[Original question page](assets/3feb0097e35e8166ee0f5f72e7854bb82c17655eefbc23d951e7b3ca4cb5bc1a.jpg)

<!-- Source: /api/assets/f77abc3ff9ea71329deb091474ae0f0ad29f51433bede7b4a30c0b44a4c5b9ca.jpg; PDF page 79; full -->

```text
Questions 25–30
What do the speakers say about each of the following films?
Choose SIX answers from the box and write the correct letter, A–G, next to Questions 25–30.
A clearly shows the historical period
B contains only parts of the play
C is too similar to another kind of film
D turned out to be unpopular with audiences
E presents the play in a different period from the original
F sets the original in a different country
G incorporates a variety of art forms
25 Ran __________
26 Much Ado About Nothing __________
27 Romeo & Juliet __________
28 Hamlet __________
29 Prospero’s Books __________
30 Looking for Richard __________
```

[Original question page](assets/f77abc3ff9ea71329deb091474ae0f0ad29f51433bede7b4a30c0b44a4c5b9ca.jpg)

### Part 4

<!-- Source: /api/assets/7d3061c63ed071e4afd5874b145331aa9eb36ff1af57678b7d72ac8daa10ed43.jpg; PDF page 80; full -->

```text
Listening
SECTION 4 Questions 31-40
Complete the notes below.
Write ONE WORD ONLY for each answer.
Noise in Cities
Past research focused on noise level (measured in decibels) and people's responses.
Noise 'maps'
• show that the highest noise levels are usually found on roads
• do not show other sources of noise, e.g. when windows are open or people's
neighbours are in their 31 ......................................... ..
• ignore variations in people's perceptions of noise
• have made people realize that the noise is a 32 ........................................... issue that
must be dealt with
Problems caused by noise
• sleep disturbance
• increase in amount of stress
• effect on the 33 ........................................... of schoolchildren
Different types of noise
Some noises can be considered pleasant e.g. the sound of a 34 .......................................... .
in a town
To investigate this, researchers may use methods from 35 .......................................... .
sciences e.g. questionnaires
What people want
Plenty of activity in urban environments which are 36 ........................................... , but also
allow people to relax
But architects and town planners
• do not get much 37 ........................................... in acoustics
• regard sound as the responsibility of engineers
Understanding sound as an art form
We need to know
• how sound relates to 38 ......................................... ..
• what can be learnt from psychology about the effects of sound
• whether physics can help us understand the 39 ........................................... of sound
Virtual reality programs
• advantage: predict the effect of buildings
0 current disadvantage: they are 40 ......................................... ..
79
```

[Original question page](assets/7d3061c63ed071e4afd5874b145331aa9eb36ff1af57678b7d72ac8daa10ed43.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/f35c7bbfbda6ee5c72cc425ef7e5ecb5e0b0112b2eaee23bef6a88ce38c7453a.jpg; PDF page 81; full -->

```text
Test 8
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The History of Glass
From our earliest origins, man has been
making use of glass. Historians have
discovered that a type of natural glass
- obsidian - formed in places such as
the mouth of a volcano as a result of
the intense heat of an eruption melting
sand - was first used as tips for spears.
Archaeologists have even found evidence
of man-made glass which dates back to
4000 BC; this took the form of glazes used
for coating stone beads. It was not until
1500 BC, however, that the first hollow
glass container was made by covering a
sand core with a layer of molten glass.
Glass blowing became the most common
way to make glass containers from the
first century BC. The glass made during
this time was highly coloured due to the
impurities of the raw material. In the
first century AD, methods of creating
colourless glass were developed, which
was then tinted by the addition of
colouring materials. The secret of glass
making was taken across Europe by the
Romans during this century. However,
they guarded the skills and technology
required to make glass very closely, and
it was not until their empire collapsed
in 476 AD that glass-making knowledge
became widespread throughout Europe
and the Middle East. From the 10th
century onwards, the Venetians gained a
reputation for technical skill and artistic
ability in the making of glass bottles, and
many of the city's craftsmen left Italy to
set up glassworks throughout Europe.
A major milestone in the history of glass
occurred with the invention of lead crystal
glass by the English glass manufacturer
George Ravenscroft (1632-1683). He
attempted to counter the effect of
clouding that sometimes occurred in
blown glass by introducing lead to the raw
materials used in the process. The new
glass he created was softer and easier
to decorate, and had a higher refractive
index, adding to its brilliance and beauty,
and it proved invaluable to the optical
industry. It is thanks to Ravenscroft's
invention that optical lenses, astronomical
telescopes, microscopes and the like
became possible.
In Britain, the modern glass industry only
really started to develop after the repeal
of the Excise Act in 1845. Before that
time, heavy taxes had been placed on the
amount of glass melted in a glasshouse,
and were levied continuously from
1745 to 1845. Joseph Paxton's Crystal
Palace at London's Great Exhibition of
1851 marked the beginning of glass as a
material used in the building industry. This
revolutionary new building encouraged
the use of glass in public, domestic
and horticultural architecture. Glass
```

[Original question page](assets/f35c7bbfbda6ee5c72cc425ef7e5ecb5e0b0112b2eaee23bef6a88ce38c7453a.jpg)

<!-- Source: /api/assets/bd318ffec1335ce39230be04348ec345344e6c6538c06b889a8462bcb2b51680.jpg; PDF page 82; full -->

```text
manufacturing techniques also improved
with the advancement of science and the
development of better technology.
From 1887 onwards, glass making
developed from traditional mouth-blowing
to a semi-automatic process, after factory­
owner HM Ashley introduced a machine
capable of producing 200 bottles per hour
in Castleford, Yorkshire, England - more
than three times quicker than any previous
production method. Then in 1907, the first
fully automated machine was developed
in the USA by Michael Owens - founder
of the Owens Bottle Machine Company
(later the major manufacturers Owens­
Illinois) - and installed in its factory.
Owens' invention could produce an
impressive 2,500 bottles per hour. Other
developments followed rapidly, but: it
was not until the First World War, when
Britain became cut off from essential glass
suppliers, that glass became part of the
scientific sector. Previous to this, glass
had been seen as a craft rather than a
precise science.
Today, glass making is big business. It
has become a modern, hi-tech industry
Reading
operating in a fiercely competitive global
market where quality, design and service
levels are critical to maintaining market
share. Modem glass plants are capable
of making millions of glass containers a
day in many different colours, with green,
brown and clear remaining the most
popular. Few of us can imagine modern
life without glass. It features in almost
every aspect of our lives - in our homes,
our cars and whenever we sit down to eat
or drink. Glass packaging is used for many
products, many beverages are sold in
glass, as are numerous foodstuffs, as well ·
as medicines and cosmetics.
Glass is an ideal material for recycling,
and with growing consumer concern
for green issues, .glass bottles and
jars are becoming ever more popular.
Glass recycling is good news for
the environment. It saves used glass
containers being sent to landfill. As less
energy is needed to melt recycled glass
than to melt down raw materials, this also
saves fuel and production costs. Recycling
also reduces the need for raw materials
to be quarried, thus saving precious
resources.
81
```

[Original question page](assets/bd318ffec1335ce39230be04348ec345344e6c6538c06b889a8462bcb2b51680.jpg)

<!-- Source: /api/assets/590610de7896e64fe8351946f582a0ab705f6343473a5311324ab70b2b70884f.jpg; PDF page 83; full -->

```text
Test 8
Questions 1-8
Complete the notes below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1-8 on your answer sheet.
The History of Glass
• Early humans used a material called 1 ........................................... to make the sharp points
of their 2 ........................................... .
• 4000 BC: 3 ........................................... made of stone were covered in a coating of
man-made glass.
• First century BC: glass was coloured because of the 4 .......................................... in the
material.
• Until 476 AD: Only the 5 ........... ............................... knew how to make glass.
• From 10th century: Venetians became famous for making bottles out of glass.
• 17th century: George Ravenscroft developed a process using 6 .......................................... .
to avoid the occurrence of 7 ........................................... in blown glass.
• Mid-19th century: British glass production developed after changes to laws
concerning 8 ........................................... .
Questions 9-13
In boxes 9-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
9 In 1887, HM Ashley had the fastest bottle-producing machine that existed at the
time.
10 Michael Owens was hired by a large US company to design a fully-automated
bottle manufacturing machine for them.
11 Nowadays, most glass is produced by large international manufacturers.
12 Concern for the environment is leading to an increased demand for glass
containers.
13 It is more expensive to produce recycled glass than to manufacture new glass.
82
```

[Original question page](assets/590610de7896e64fe8351946f582a0ab705f6343473a5311324ab70b2b70884f.jpg)

<!-- Source: /api/assets/beed6231ded622bdb7ed5de3690b6ccf0b550a439569f697766f4cd058203b87.jpg; PDF page 84; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Bring back the big cats
It's time to start returning vanished native animals to Britain, says John Vesty
There is a poem, written around 598 AD,
which describes hunting a mystery animal
called a llewyn. But what was it? Nothing
seemed to fit, until 2006, when an animal
bone, dating from around the same
period, was found in the Kinsey Cave in
northern England. Until this discovery, the
lynx - a large spotted cat with tasselled
ears - was presumed to have died out in
Britain at least 6,000 years ago, before
the inhabitants of these islands took up
farming. But the 2006 find, together with
three others in Yorkshire and Scotland, is
compelling evidence that the lynx and the
mysterious llewyn were in fact one and the
same animal. If this is so, it would bring
forward the tassel-eared cat's estimated
extinction date by roughly 5,000 years.
However, this is not quite the last glimpse
of the animal in British culture. A 9th­
century stone cross from the Isle of Eigg
shows, alongside the deer, boar and
___ aurochs pursued by a mounted hunter, a
speckled cat with tasselled ears. Were it not
for the animal's backside having worn away
with time, we could have been certain, as
the lynx's stubby tail is unmistakable. But
even without this key feature, it's hard to
see what else the creature could have been.
The lynx is now becoming the totemic
animal of a movement that is transforming
British environmentalism: rewilding.
Rewilding means the mass restoration of
damaged ecosystems. It involves letting
trees return to places that have been
denuded, allowing parts of the seabed
to recover from trawling and dredging,
permitting rivers to flow freely again.
Above all, it means bringing back missing
species. One of the most striking findings
of modern ecology is that ecosystems
without large predators behave in
completely different ways from those that
retain them. Some of them drive dynamic
processes that resonate through the whole
food chain, creating niches for hundreds
of species that might otherwise struggle to
survive. The killers turn out to be bringers
of life.
Such findings present a big challenge
to British conservation, which has often
selected arbitrary assemblages of plants
and animals and sought, at great effort and
expense, to prevent them from changing.
It has tried to preserve the living world as
if it were a jar of pickles, letting nothing
in and nothing out, keeping nature in
a state of arrested development. But
ecosystems are not merely collections of
species; they are also the dynamic and
ever-shifting relationships between them.
And this dynamism often depends on large
predators.
At sea the potential is even greater: by
protecting large areas from commercial
fishing, we could once more see what
18th-century literature describes: vast
shoals of fish being chased by fin and
83
```

[Original question page](assets/beed6231ded622bdb7ed5de3690b6ccf0b550a439569f697766f4cd058203b87.jpg)

<!-- Source: /api/assets/e360025df0d4e99d3cf16aabcae52d7f2eda326ee25c818ec32d1d08c6d601cf.jpg; PDF page 85; full -->

```text
Test 8
sperm whales, within sight of the English
shore. This policy would also greatly boost
catches in the surrounding seas; the fishing
industry's insistence on scouring every inch
of seabed, leaving no breeding reserves,
could not be more damaging to its own
interests.
Rewilding is a rare example of an
environmental movement in which
campaigners articulate what they are for
rather than only what they are against.
One of the reasons why the enthusiasm for
rewilding is spreading so quickly in Britain
is that it helps to create a more inspiring
vision than the green movement's usual
promise of 'Follow us and the world will be
slightly less awful than it would otherwise
have been.'
The lynx presents no threat to human
beings: there is no known instance of one
preying on people. It is a specialist predator
of roe deer, a species that has exploded in
Britain in recent decades, holding back, by
intensive browsing, attempts to re-establish
forests. It will also winkle out sika deer:
an exotic species that is almost impossible
for human beings to control, as it hides in
impenetrable plantations of young trees.
The attempt to reintroduce this predator
marries well with the aim of bringing
forests back to parts of our bare and barren
uplands. The lynx requires deep cover, and
as such presents little risk to sheep and
other livestock, which are supposed, as a
condition of farm subsidies, to be kept out
of the woods.
84
On a recent trip to the Cairngorm
Mountains, I heard several conservationists
suggest that the lynx could be reintroduced
there within 20 years. If trees return to
the bare hills elsewhere in Britain, the big
cats could soon follow. There is nothing
extraordinary about these proposals,
seen from the perspective of anywhere
else in Europe. The lynx has now been
reintroduced to the Jura Mountains, the
Alps, the Vosges in eastern France and
the Harz mountains in Germany, and has
re-established itself in many more places.
The European population has tripled since
1970 to roughly 10,000. As with wolves,
bears, beavers, boar, bison, moose and
many other species, the lynx has been able
to spread as farming has left the hills and
people discover that it is more lucrative to
protect charismatic wildlife than to hunt it,
as tourists will pay for the chance to see it.
Large-scale rewilding is happening almost
everywhere - except Britain.
Here, attitudes are just beginning to
change. Conservationists are starting to
accept that the old preservation-jar model
is failing, even on its own terms. Already,
projects such as Trees for Life in the
Highlands provide a hint of what might be
coming. An organisation is being set up
that will seek to catalyse the rewilding of
land and sea across Britain, its aim being to
reintroduce that rarest of species to British
ecosystems: hope.
```

[Original question page](assets/e360025df0d4e99d3cf16aabcae52d7f2eda326ee25c818ec32d1d08c6d601cf.jpg)

<!-- Source: /api/assets/68c24424f5217d77f8637fe2f0c3b43659d0d12da13a23be54a5068d5e5f44f6.jpg; PDF page 86; full -->

```text
Reading
Questions 14-18
Write the correct letter, A, B, C or D, in boxes 14-18 on your answer sheet.
14 What did the 2006 discovery of the animal bone reveal about the lynx?
A Its physical appearance was very distinctive.
B Its extinction was linked to the spread of farming.
C It vanished from Britain several thousand years ago.
D It survived in Britain longer than was previously thought.
15 What point does the writer make about large predators in the third paragraph?
A Their presence can increase biodiversity.
B They may cause damage to local ecosystems.
C Their behaviour can alter according to the environment.
D They should be reintroduced only to areas where they were native.
16 What does the writer suggest about British conservation in the fourth paragraph?
A It has failed to achieve its aims.
B It is beginning to change direction.
C It has taken a misguided approach.
D It has focused on the most widespread species.
17 Protecting large areas of the sea from commercial fishing would result in
A practical benefits for the fishing industry.
B some short-term losses to the fishing industry.
C widespread opposition from the fishing industry.
D certain changes to techniques within the fishing industry.
18 According to the author, what distinguishes rewilding from other environmental
campaigns?
A Its objective is more achievable.
B Its supporters are more articulate.
C Its positive message is more appealing.
D It is based on sounder scientific principles.
85
```

[Original question page](assets/68c24424f5217d77f8637fe2f0c3b43659d0d12da13a23be54a5068d5e5f44f6.jpg)

<!-- Source: /api/assets/03583109805b6269b7c59fd04be2f47ef9fda3ed75dca55c55ee02cfe0bf7d0d.jpg; PDF page 87; full -->

```text
Test 8
Questions 19-22
Complete the summary using the list of words and phrases A-F below.
Write the correct letter, A-F, in boxes 19-22 on your answer sheet.
Reintroducing the lynx to Britain
There would be many advantages to reintroducing the lynx to Britain. While there is no
evidence that the lynx has ever put 19 ...................................... in danger, it would reduce the
numbers of certain 20 ...................................... whose populations have increased enormously in
recent decades. It would present only a minimal threat to 21 ...................................... , provided
these were kept away from lynx habitats. Furthermore, the reintroduction programme
would also link efficiently with initiatives to return native 22 ...................................... to certain
areas of the country.
A trees
B endangered species
C hillsides
D wild animals
E humans
F farm animals
```

[Original question page](assets/03583109805b6269b7c59fd04be2f47ef9fda3ed75dca55c55ee02cfe0bf7d0d.jpg)

<!-- Source: /api/assets/217993dd3015458efd14e854b105a4638bef036c7bf0dfcadd668c02e890c3f1.jpg; PDF page 88; full -->

```text
Reading
Questions 23-26
Do the following statements agree with the claims of the writer in Reading Passage 2?
In boxes 23-26 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
23 Britain could become the first European country to reintroduce the lynx.
24 The large growth in the European lynx population since 1970 has exceeded
conservationists' expectations.
25 Changes in agricultural practices have extended the habitat of the lynx in Europe.
26 It has become apparent that species reintroduction has commercial advantages.
87
```

[Original question page](assets/217993dd3015458efd14e854b105a4638bef036c7bf0dfcadd668c02e890c3f1.jpg)

<!-- Source: /api/assets/d78e16f01d77276d6960c166035a9a65d54f8898eba306aa4165377a7e435634.jpg; PDF page 89; full -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27–40, which are based on Reading Passage 3 on pages 89 and 90.
Questions 27–33
Reading Passage 3 has seven paragraphs, A–G.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i–viii, in boxes 27–33 on your answer sheet.
List of Headings
i Disputes over financial arrangements regarding senior managers
ii The impact on companies of being subjected to close examination
iii The possible need for fundamental change in every area of business
iv Many external bodies being held responsible for problems
v The falling number of board members with broad enough experience
vi A risk that not all directors take part in solving major problems
vii Boards not looking far enough ahead
viii A proposal to change the way the board operates
27 Paragraph A
28 Paragraph B
29 Paragraph C
30 Paragraph D
31 Paragraph E
32 Paragraph F
33 Paragraph G
```

[Original question page](assets/d78e16f01d77276d6960c166035a9a65d54f8898eba306aa4165377a7e435634.jpg)

<!-- Source: /api/assets/7946410f14c71a9a104454fb24d79da4d46e1fb757a8fb0b0b35ac97fdcabd56.jpg; PDF page 90; full -->

```text
Reading
UK companies need more effective boards of directors
A After a number of serious failures of governance (that is, how they are managed
at the highest level), companies in Britain, as well as elsewhere, should consider
radical changes to their directors' roles. It is clear that the role of a board director
today is not an easy one. Following the 2008 financial meltdown, which resulted in
a deeper and more prolonged period of economic downturn than anyone expected,
the search for explanations in the many post-mortems of the crisis has meant
blame has been spread far and wide. Governments, regulators, central banks and
auditors have all been in the frame. The role of bank directors and management
and their widely publicised failures have been extensively picked over and
examined in reports, inquiries and commentaries.
B The knock-on effect of this scrutiny has been to make the governance of
companies in general an issue of intense public debate and has significantly
increased the pressures on, and the responsibilities of, directors. At the simplest
and most practical level, the time involved in fulfilling the demands of a board
directorship has increased significantly, calling into question the effectiveness of
the classic model of corporate governance by part-time, independent non-executive
directors. Where once a board schedule may have consisted of between eight and
ten meetings a year, in many companies the number of events requiring board
input and decisions has dramatically risen. Furthermore, the amount of reading
and preparation required for each meeting is increasing. Agendas can become
overloaded and this can mean the time for constructive debate must necessarily be
restricted in favour of getting through the business.
C Often, board business is devolved to committees in order to cope with the
workload, which may be more efficient but can mean that the board as a whole
is less involved in fully addressing some of the most important issues. It is not
uncommon for the audit committee meeting to last longer than the main board
meeting itself. Process may take the place of discussion and be at the expense of
real collaboration, so that boxes are ticked rather than issues tackled.
D A radical solution, which may work for some very large companies whose
businesses are extensive and complex, is the professional board, whose members­
would work up to three or four days a week, supported by their own dedicated staff
and advisers. There are obvious risks to this — and it would be important to establish
clear guidelines for such a board to ensure that it did not step on the toes of
management by becoming too engaged in the day-to-day running of the company.
Problems of recruitment, remuneration and independence could also arise and this
structure would not be appropriate for all companies. However, more professional
and better-informed boards would have been particularly appropriate for banks
where the executives had access to information that part-time non-executive
directors lacked, leaving the latter unable to comprehend or anticipate the 2008
crash.
89
```

[Original question page](assets/7946410f14c71a9a104454fb24d79da4d46e1fb757a8fb0b0b35ac97fdcabd56.jpg)

<!-- Source: /api/assets/cbb8c034ff28c4eac46ca36b046eadd80ed3da851734a6202508500bc7185c69.jpg; PDF page 91; full -->

```text
Test 8
E One of the main criticisms of boards and their directors is that they do not focus
sufficiently on longer-term matters of strategy, sustainability and governance,
but instead concentrate too much on short-term financial metrics. Regulatory
requirements and the structure of the market encourage this behaviour. The tyranny
of quarterly reporting can distort board decision-making, as directors have to 'make
the numbers' every four months to meet the insatiable appetite of the market for
more data. This serves to encourage the trading methodology of a certain kind of
investor who moves in and out of a stock without engaging in constructive dialogue
with the company about strategy or performance, and is simply seeking a short­
term financial gain. This effect has been made worse by the changing profile of
investors due to the globalisation of capital and the increasing use of automated
trading systems. Corporate culture adapts and management teams are largely
incentivised to meet financial goals.
F Compensation for chief executives has become a combat zone where pitched
battles between investors, management and board members are fought, often
behind closed doors but increasingly frequently in the full glare of press attention.
Many would argue that this is in the interest of transparency and good governance
as shareholders use their muscle in the area of pay to pressure boards to
remove underperforming chief executives. Their powers to vote down executive
remuneration policies increased when binding votes came into force. The chair
of the remuneration committee can be an exposed and lonely role, as Alison
Carnwath, chair of Barclays Bank's remuneration committee, found when she had
to resign, having been roundly criticised for trying to defend the enormous bonus
to be paid to the chief executive; the irony being that she was widely understood to
have spoken out against it in the privacy of the committee.
G The financial crisis stimulated a debate about the role and purpose of the company
and a heightened awareness of corporate ethics. Trust in the corporation has been
eroded and academics such as Michael Sandel, in his thoughtful and bestselling
book What Money Can't Buy, are questioning the morality of capitalism and the
market economy. Boards of companies in all sectors will need to widen their
perspective to encompass these issues and this may involve a realignment of
corporate goals. We live in challenging times.
90
```

[Original question page](assets/cbb8c034ff28c4eac46ca36b046eadd80ed3da851734a6202508500bc7185c69.jpg)

<!-- Source: /api/assets/57f5cfee34f7e819febe37c39665635139b8ef701540ba88a2d32c26fa04c5c2.jpg; PDF page 92; full -->

```text
Reading
Questions 34-37
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 34-37 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
34 Close scrutiny of the behaviour of boards has increased since the economic
downturn.
35 Banks have been mismanaged to a greater extent than other businesses.
36 Board meetings normally continue for as long as necessary to debate matters
in full.
37 Using a committee structure would ensure that board members are fully informed
about significant issues.
Questions 38-40
Complete the sentences below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 38-40 on your answer sheet.
38 Before 2008, non-executive directors were at a disadvantage because of their lack
of ........................................... .
39 Boards tend to place too much emphasis on ........................................... considerations that
are only of short-term relevance.
40 On certain matters, such as pay, the board may have to accept the views
of __________.
```

[Original question page](assets/57f5cfee34f7e819febe37c39665635139b8ef701540ba88a2d32c26fa04c5c2.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/26ec2e8be1d136e70fc386a875d3586f284e0de2f88ab46f4535ed9e276a2d5d.jpg; PDF page 93; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagram below shows how geothermal energy is used to produce electricity.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/26ec2e8be1d136e70fc386a875d3586f284e0de2f88ab46f4535ed9e276a2d5d.jpg)

![Original figure](assets/26ec2e8be1d136e70fc386a875d3586f284e0de2f88ab46f4535ed9e276a2d5d.jpg)

### Task 2

<!-- Source: /api/assets/153b5296527f018ff5d938474f43b10b41597e082abff35b68fac0730bc54391.jpg; PDF page 94; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that allowing children to make their own choices on everyday matters (such as food, clothes and entertainment) is likely to result in a society of individuals who only think about their own wishes. Other people believe that it is important for children to make decisions about matters that affect them.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/153b5296527f018ff5d938474f43b10b41597e082abff35b68fac0730bc54391.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/51e7e835f8235d0f39dda73270cd7e132cafa39f797277f97afd008825681a0d.jpg; PDF page 95; full -->

```text
Test 8
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Art
• Did you enjoy doing art lessons when you were a child? [Why?/Why not?]
• Do you ever draw or paint pictures now? [Why?/Why not?]
• When was the last time you went to an art gallery or exhibition? [Why?]
• What kind of pictures do you like having in your home? [Why?]
PART 2
Describe a time when you visited a friend
or family member at their workplace.
You should say:
who you visited
where this person worked
why you visited this person's
workplace
and explain how you felt about visiting this
person's workplace.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Different kinds of workplaces
Example questions:
What things make an office comfortable to work in?
Why do some people prefer to work outdoors?
Do you agree that the building people work in is more important than the colleagues
they work with?
The importance of work
Example questions:
What would life be like if people didn't have to work?
Are all jobs of equal importance?
Why do some people become workaholics?
94
```

[Original question page](assets/51e7e835f8235d0f39dda73270cd7e132cafa39f797277f97afd008825681a0d.jpg)

### Part 2

<!-- Source: /api/assets/51e7e835f8235d0f39dda73270cd7e132cafa39f797277f97afd008825681a0d.jpg; PDF page 95; full -->

```text
Test 8
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Art
• Did you enjoy doing art lessons when you were a child? [Why?/Why not?]
• Do you ever draw or paint pictures now? [Why?/Why not?]
• When was the last time you went to an art gallery or exhibition? [Why?]
• What kind of pictures do you like having in your home? [Why?]
PART 2
Describe a time when you visited a friend
or family member at their workplace.
You should say:
who you visited
where this person worked
why you visited this person's
workplace
and explain how you felt about visiting this
person's workplace.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Different kinds of workplaces
Example questions:
What things make an office comfortable to work in?
Why do some people prefer to work outdoors?
Do you agree that the building people work in is more important than the colleagues
they work with?
The importance of work
Example questions:
What would life be like if people didn't have to work?
Are all jobs of equal importance?
Why do some people become workaholics?
94
```

[Original question page](assets/51e7e835f8235d0f39dda73270cd7e132cafa39f797277f97afd008825681a0d.jpg)

### Part 3

<!-- Source: /api/assets/51e7e835f8235d0f39dda73270cd7e132cafa39f797277f97afd008825681a0d.jpg; PDF page 95; full -->

```text
Test 8
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Art
• Did you enjoy doing art lessons when you were a child? [Why?/Why not?]
• Do you ever draw or paint pictures now? [Why?/Why not?]
• When was the last time you went to an art gallery or exhibition? [Why?]
• What kind of pictures do you like having in your home? [Why?]
PART 2
Describe a time when you visited a friend
or family member at their workplace.
You should say:
who you visited
where this person worked
why you visited this person's
workplace
and explain how you felt about visiting this
person's workplace.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Different kinds of workplaces
Example questions:
What things make an office comfortable to work in?
Why do some people prefer to work outdoors?
Do you agree that the building people work in is more important than the colleagues
they work with?
The importance of work
Example questions:
What would life be like if people didn't have to work?
Are all jobs of equal importance?
Why do some people become workaholics?
94
```

[Original question page](assets/51e7e835f8235d0f39dda73270cd7e132cafa39f797277f97afd008825681a0d.jpg)
