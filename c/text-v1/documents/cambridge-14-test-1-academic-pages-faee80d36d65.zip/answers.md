# 剑雅 14 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 119

TEST 1 LISTENING
1 Canadian
2 furniture
3 Park
4 250 (sterling)
5 phone
6 10(th) September
7 museum
8 time
9 blond(e)
10 87954 82361
11 A
12 C
13 B
14 E
15 B
16 B
17 C
18 A
19 A
20 C
21 B
22 A
23 C
24 B
25 A
26 B
27 A
28 F
29 G
30 C
31 industry
32 constant
33 direction
34 floor
35 predictable
36 bay
37 gates
38 fuel
39 jobs
40 migration
11&12 IN EITHER ORDER: A,C
13&14 IN EITHER ORDER: B,E
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. Canadian

2. furniture

3. Park

4. 250 / 250 sterling

5. phone

6. 10 September / 10th September

7. museum

8. time

9. blond / blonde

10. 87954 82361 / 8795482361

### Part 2 · source page 119

TEST 1 LISTENING
1 Canadian
2 furniture
3 Park
4 250 (sterling)
5 phone
6 10(th) September
7 museum
8 time
9 blond(e)
10 87954 82361
11 A
12 C
13 B
14 E
15 B
16 B
17 C
18 A
19 A
20 C
21 B
22 A
23 C
24 B
25 A
26 B
27 A
28 F
29 G
30 C
31 industry
32 constant
33 direction
34 floor
35 predictable
36 bay
37 gates
38 fuel
39 jobs
40 migration
11&12 IN EITHER ORDER: A,C
13&14 IN EITHER ORDER: B,E
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A / C

12. A / C

13. B / E

14. B / E

15. B

16. B

17. C

18. A

19. A

20. C

### Part 3 · source page 119

TEST 1 LISTENING
1 Canadian
2 furniture
3 Park
4 250 (sterling)
5 phone
6 10(th) September
7 museum
8 time
9 blond(e)
10 87954 82361
11 A
12 C
13 B
14 E
15 B
16 B
17 C
18 A
19 A
20 C
21 B
22 A
23 C
24 B
25 A
26 B
27 A
28 F
29 G
30 C
31 industry
32 constant
33 direction
34 floor
35 predictable
36 bay
37 gates
38 fuel
39 jobs
40 migration
11&12 IN EITHER ORDER: A,C
13&14 IN EITHER ORDER: B,E
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B

22. A

23. C

24. B

25. A

26. B

27. A

28. F

29. G

30. C

### Part 4 · source page 119

TEST 1 LISTENING
1 Canadian
2 furniture
3 Park
4 250 (sterling)
5 phone
6 10(th) September
7 museum
8 time
9 blond(e)
10 87954 82361
11 A
12 C
13 B
14 E
15 B
16 B
17 C
18 A
19 A
20 C
21 B
22 A
23 C
24 B
25 A
26 B
27 A
28 F
29 G
30 C
31 industry
32 constant
33 direction
34 floor
35 predictable
36 bay
37 gates
38 fuel
39 jobs
40 migration
11&12 IN EITHER ORDER: A,C
13&14 IN EITHER ORDER: B,E
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. industry

32. constant

33. direction

34. floor

35. predictable

36. bay

37. gates

38. fuel

39. jobs

40. migration

## A 类阅读

### Academic Reading · source page 120

TEST 1 READING
1 creativity
2 rules
3 cities
4 traffic
5 crime
6 competition
7 evidence
8 life
9 TRUE
10 TRUE
11 NOT GIVEN
12 FALSE
13 TRUE
14 E
15 C
16 F
17 C
18 A
19 B
20 D
21 D
22 E
23 activists
24 consumerism
25 leaflets
26 police
27 E
28 D
29 B
30 D
31 C
32 YES
33 NO
34 NO
35 NOT GIVEN
36 restaurants
37 performance
38 turnover
39 goals
40 characteristics
4&5 IN EITHER ORDER: traffic,crime
19&20 IN EITHER ORDER: B,D
21&22 IN EITHER ORDER: D,E
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. creativity

2. rules

3. cities

4. traffic / crime

5. traffic / crime

6. competition

7. evidence

8. life

9. TRUE

10. TRUE

11. NOT GIVEN

12. FALSE

13. TRUE

14. E

15. C

16. F

17. C

18. A

19. B / D

20. B / D

21. D / E

22. D / E

23. activists

24. consumerism

25. leaflets

26. police

27. E

28. D

29. B

30. D

31. C

32. YES

33. NO

34. NO

35. NOT GIVEN

36. restaurants

37. performance

38. turnover

39. goals

40. characteristics

## A 类写作

### Writing material: c14-t1-w-1

Typical meals consumed in USA. Breakfast/lunch/dinner/snacks respectively: sodium14/29/43/14%; saturated fat16/26/37/21%; added sugar16/19/23/42%. Legend patterns checked: dinner dark, lunch crosshatched, breakfast grey, snacks white. Dinner largest sodium/fat share, snacks largest sugar share. Breakfast tied with snacks for lowest sodium; breakfast lowest fat/sugar. Each nutrient pie totals100%. These are distribution of each nutrient among meals, not nutrient composition of a meal or percent of recommended intake. No dates, quantities or total calories provided.



### Writing material: c14-t1-w-2

Discuss acceptance versus attempts to improve bad situations, giving own opinion. Job and money are examples, not mandatory two separate questions; conditional positions are acceptable.



## 口语
