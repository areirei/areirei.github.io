# 剑雅 14 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/6de2a53281bfd910a788edb7daec7799896489c68a89781cf878bd002e24432e.jpg; PDF page 10; full -->

```text
LISTENING
SECTION 1 Questions 1–10
Complete the form below. Write ONE WORD AND/OR A NUMBER for each answer.
CRIME REPORT FORM
Type of crime: theft
Personal information
Example Name: Louise Taylor
Nationality: (1) __________
Date of birth: 14 December 1977
Occupation: interior designer
Reason for visit: business (to buy antique (2) __________)
Length of stay: two months
Current address: (3) __________ Apartments (No 15)
Details of theft
Items stolen:
– a wallet containing approximately (4) £ __________
– a (5) __________
Date of theft: (6) __________
Possible time and place of theft
Location: outside the (7) __________ at about 4 pm
Details of suspect:
– some boys asked for the (8) __________ then ran off
– one had a T-shirt with a picture of a tiger
– he was about 12, slim build with (9) __________ hair
Crime reference number allocated: (10) __________
```

[Original question page](assets/6de2a53281bfd910a788edb7daec7799896489c68a89781cf878bd002e24432e.jpg)

### Part 2

<!-- Source: /api/assets/9478f37853a8392cc6b8e414fc0beaaacd8289d101bfe4ed87416c5b5e46a39c.jpg; PDF page 11; full -->

```text
SECTION 2 Questions 11–20
Induction talk for new apprentices
Questions 11 and 12
Choose TWO letters, A–E.
Which TWO pieces of advice for the first week of an apprenticeship does the manager give?
A get to know colleagues
B learn from any mistakes
C ask lots of questions
D react positively to feedback
E enjoy new challenges
Questions 13 and 14
Choose TWO letters, A–E.
Which TWO things does the manager say mentors can help with?
A confidence-building
B making career plans
C completing difficult tasks
D making a weekly timetable
E reviewing progress
```

[Original question page](assets/9478f37853a8392cc6b8e414fc0beaaacd8289d101bfe4ed87416c5b5e46a39c.jpg)

<!-- Source: /api/assets/792e9680b662735e7adfde45ab5d77fd3b247f1ccb234ec27e95027f384d14d3.jpg; PDF page 12; full -->

```text
Test 1
Questions 15-20
What does the manager say about each of the following aspects of the company policy
for apprentices?
Write the correct letter, A, B or C, next to Questions 15-20.
A It is encouraged.
B There are some restrictions.
C It is against the rules.
Company policy for apprentices
15 Using the internet
16 Flexible working
17 Booking holidays
18 Working overtime
19 Wearing trainers
20 Bringing food to work
12
```

[Original question page](assets/792e9680b662735e7adfde45ab5d77fd3b247f1ccb234ec27e95027f384d14d3.jpg)

### Part 3

<!-- Source: /api/assets/461cedcd472206148b285617649f20f27ae021d07b976eab9eb1ed89fd1167d6.jpg; PDF page 13; full -->

```text
Listening
SECTION 3 Questions 21-30
Questions 21-25
Choose the correct letter, A, B or C.





Cities built by the sea
21 Carla and Rob were surprised to learn that coastal cities
A contain nearly half the world’s population.
B  include most of the world’s largest cities.
C are growing twice as fast as other cities.
22 According to Rob, building coastal cities near to rivers
A may bring pollution to the cities.
B  may reduce the land available for agriculture.
C may mean the countryside is spoiled by industry.
23 What mistake was made when building water drainage channels in Miami in
the 1950s?
A There were not enough of them.
B  They were made of unsuitable materials.
C They did not allow for the effects of climate change.
24 What do Rob and Carla think that the authorities in Miami should do immediately?
A take measures to restore ecosystems
B pay for a new flood prevention system
C stop disposing of waste materials into the ocean
25 What do they agree should be the priority for international action?
A greater coordination of activities
B more sharing of information
C agreement on shared policies
13
```

[Original question page](assets/461cedcd472206148b285617649f20f27ae021d07b976eab9eb1ed89fd1167d6.jpg)

<!-- Source: /api/assets/1be5af8de59e7657602a54aee1721d35097392bbd5ec096f8de8e0b11fe7907c.jpg; PDF page 14; full -->

```text
Questions 26–30
What decision do the students make about each of the following parts of their presentation?
Choose FIVE answers from the box and write the correct letter, A–G, next to Questions 26–30.
Decisions
A use visuals
B keep it short
C involve other students
D check the information is accurate
E provide a handout
F focus on one example
G do online research
Parts of the presentation
26 Historical background __________
27 Geographical factors __________
28 Past mistakes __________
29 Future risks __________
30 International implications __________
```

[Original question page](assets/1be5af8de59e7657602a54aee1721d35097392bbd5ec096f8de8e0b11fe7907c.jpg)

### Part 4

<!-- Source: /api/assets/9c8955409a12ec92a164dac495e76b1ffed77821df1f1b1645d24458588461d8.jpg; PDF page 15; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Marine renewable energy (ocean energy)
Introduction
More energy required because of growth in population and (31) __________
What’s needed:
• renewable energy sources
• methods that won’t create pollution
Wave energy
Advantage: waves provide a (32) __________ source of renewable energy
Electricity can be generated using offshore or onshore systems
Onshore systems may use a reservoir
Problems:
• waves can move in any (33) __________
• movement of sand, etc. on the (34) __________ of the ocean may be affected
Tidal energy
Tides are more (35) __________ than waves
Planned tidal lagoon in Wales:
• will be created in a (36) __________ at Swansea
• breakwater (dam) containing 16 turbines
• rising tide forces water through turbines, generating electricity
• stored water is released through (37) __________, driving the turbines in the reverse direction
Advantages:
• not dependent on weather
• no (38) __________ is required to make it work
• likely to create a number of (39) __________
Problem:
• may harm fish and birds, e.g. by affecting (40) __________ and building up silt
Ocean thermal energy conversion
Uses a difference in temperature between the surface and lower levels
Water brought to the surface in a pipe
```

[Original question page](assets/9c8955409a12ec92a164dac495e76b1ffed77821df1f1b1645d24458588461d8.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/3872c3728934edc640665a7e9890c55b0cf69d8389ad9b85cfb506502f24bd81.jpg; PDF page 16; full -->

```text
Test 1
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
THE IMPORTANCE OF CHILDREN’S PLAY
Brick by brick, six-year-old Alice is building a magical kingdom. Imagining fairy-tale turrets and
fire-breathing dragons, wicked witches and gallant heroes, she’s creating an enchanting world.
Although she isn’t aware of it, this fantasy is helping her take her first steps towards her capacity for
creativity and so it will have important repercussions in her adult life.
Minutes later, Alice has abandoned the kingdom in favour of playing schools with her younger
brother. When she bosses him around as his ‘teacher’, she’s practising how to regulate her emotions
through pretence. Later on, when they tire of this and settle down with a board game, she’s learning
about the need to follow rules and take turns with a partner.
“Play in all its rich variety is one of the highest achievements of the human species,’ says
Dr David Whitebread from the Faculty of Education at the University of Cambridge, UK. ‘It
underpins how we develop as intellectual, problem-solving adults and is crucial to our success as
a highly adaptable species.’
Recognising the importance of play is not new: over two millennia ago, the Greek philosopher
Plato extolled its virtues as a means of developing skills for adult life, and ideas about play-based
learning have been developing since the 19th century.
But we live in changing times, and Whitebread is mindful of a worldwide decline in play, pointing
out that over half the people in the world now live in cities. ‘The opportunities for free play, which
I experienced almost every day of my childhood, are becoming increasingly scarce,’ he says.
Outdoor play is curtailed by perceptions of risk to do with traffic, as well as parents’ increased
wish to protect their children from being the victims of crime, and by the emphasis on ‘earlier is
better’ which is leading to greater competition in academic learning and schools.
International bodies like the United Nations and the European Union have begun to develop
policies concerned with children’s right to play, and to consider implications for leisure facilities
and educational programmes. But what they often lack is the evidence to base policies on.
‘The type of play we are interested in is child-initiated, spontaneous and unpredictable — but, as
soon as you ask a five-year-old “to play”, then you as the researcher have intervened,’ explains
Dr Sara Baker. ‘And we want to know what the long-term impact of play is. It’s a real challenge.’
16
```

[Original question page](assets/3872c3728934edc640665a7e9890c55b0cf69d8389ad9b85cfb506502f24bd81.jpg)

<!-- Source: /api/assets/1642c03f8dae1e89b6874b5ed00ab72efc3a96b6c2ce89f98a6e8597c96cb553.jpg; PDF page 17; full -->

```text
Reading
Dr Jenny Gibson agrees, pointing out that although some of the steps in the puzzle of how and
why play is important have been looked at, there is very little data on the impact it has on the
child’s later life.
Now, thanks to the university’s new Centre for Research on Play in Education, Development and
Learning (PEDAL), Whitebread, Baker, Gibson and a team of researchers hope to provide evidence
on the role played by play in how a child develops.
‘A strong possibility is that play supports the early development of children’s self-control,’
explains Baker. “This is our ability to develop awareness of our own thinking processes — it
influences how effectively we go about undertaking challenging activities.’
In a study carried out by Baker with toddlers and young pre-schoolers, she found that children with
greater self-control solved problems more quickly when exploring an unfamiliar set-up requiring
scientific reasoning. ‘This sort of evidence makes us think that giving children the chance to play will
make them more successful problem-solvers in the long run.’
If playful experiences do facilitate this aspect of development, say the researchers, it could be
extremely significant for educational practices, because the ability to self-regulate has been
shown to be a key predictor of academic performance.
Gibson adds: ‘Playful behaviour is also an important indicator of healthy social and emotional
development. In my previous research, I investigated how observing children at play can
give us important clues about their well-being and can even be useful in the diagnosis of
neurodevelopmental disorders like autism.’
Whitebread’s recent research has involved developing a play-based approach to supporting
children’s writing. ‘Many primary school children find writing difficult, but we showed in a
previous study that a playful stimulus was far more effective than an instructional one.’ Children
wrote longer and better-structured stories when they first played with dolls representing
characters in the story. In the latest study, children first created their story with Lego*, with
similar results. ‘Many teachers commented that they had always previously had children saying
they didn’t know what to write about. With the Lego building, however, not a single child said
this through the whole year of the project.’
Whitebread, who directs PEDAL, trained as a primary school teacher in the early 1970s, when,
as he describes, ‘the teaching of young children was largely a quiet backwater, untroubled by any
serious intellectual debate or controversy.’ Now, the landscape is very different, with hotly debated
topics such as school starting age.
“Somehow the importance of play has been lost in recent decades. It’s regarded as something
trivial, or even as something negative that contrasts with “work”. Let’s not lose sight of its
benefits, and the fundamental contributions it makes to human achievements in the arts, sciences
and technology. Let’s make sure children have a rich diet of play experiences.’
* Lego: coloured plastic building blocks and other pieces that can be joined together
```

[Original question page](assets/1642c03f8dae1e89b6874b5ed00ab72efc3a96b6c2ce89f98a6e8597c96cb553.jpg)

<!-- Source: /api/assets/28637042428fa6d6623b0860b02c3ae3436a777f4b9af96be5b0d5412c7b6cb5.jpg; PDF page 18; full -->

```text
Questions 1–8
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–8 on your answer sheet.
Children’s play
Uses of children’s play
• building a ‘magical kingdom’ may help develop (1) __________
• board games involve (2) __________ and turn-taking
Recent changes affecting children’s play
• populations of (3) __________ have grown
• opportunities for free play are limited due to
– fear of (4) __________
– fear of (5) __________
– increased (6) __________ in schools
International policies on children’s play
• it is difficult to find (7) __________ to support new policies
• research needs to study the impact of play on the rest of the child’s (8) __________
```

[Original question page](assets/28637042428fa6d6623b0860b02c3ae3436a777f4b9af96be5b0d5412c7b6cb5.jpg)

<!-- Source: /api/assets/54429e61a436f19d7e560a6bcee8bbd8c396985336222b75e3c1b1f2cc787040.jpg; PDF page 19; full -->

```text
Reading
Questions 9-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 9-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN _ if there is no information on this
9 — Children with good self-control are known to be likely to do well at school later on.
10 The way a child plays may provide information about possible medical problems.
11 Playing with dolls was found to benefit girls’ writing more than boys’ writing.
12 Children had problems thinking up ideas when they first created the story
with Lego.
13. People nowadays regard children’s play as less significant than they did in the past.
```

[Original question page](assets/54429e61a436f19d7e560a6bcee8bbd8c396985336222b75e3c1b1f2cc787040.jpg)

<!-- Source: /api/assets/053f2815987d8cb391c9140a2216f9245b8bcb2ba409ae9946c8efce597280b1.jpg; PDF page 20; full -->

```text
Test 1
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
The growth of bike-sharing schemes around
the world
How Dutch engineer Luud Schimmelpennink helped to devise urban
bike-sharing schemes
A The original idea for an urban bike-sharing scheme dates back to a summer’s day
in Amsterdam in 1965. Provo, the organisation that came up with the idea, was a
group of Dutch activists who wanted to change society. They believed the scheme,
which was known as the Witte Fietsenplan, was an answer to the perceived threats
of air pollution and consumerism. In the centre of Amsterdam, they painted a small
number of used bikes white. They also distributed leaflets describing the dangers of
cars and inviting people to use the white bikes. The bikes were then left unlocked at
various locations around the city, to be used by anyone in need of transport.
B Luud Schimmelpennink, a Dutch industrial engineer who still lives and cycles
in Amsterdam, was heavily involved in the original scheme. He recalls how the
scheme succeeded in attracting a great deal of attention — particularly when it
came to publicising Provo’s aims — but struggled to get off the ground. The police
were opposed to Provo’s initiatives and almost as soon as the white bikes were
distributed around the city, they removed them. However, for Schimmelpennink and
for bike-sharing schemes in general, this was just the beginning. ‘The first Witte
Fietsenplan was just a symbolic thing,’ he says. ‘We painted a few bikes white, that
was all. Things got more serious when I became a member of the Amsterdam city
council two years later.’
C Schimmelpennink seized this opportunity to present a more elaborate Witte
Fietsenplan to the city council. ‘My idea was that the municipality of Amsterdam
would distribute 10,000 white bikes over the city, for everyone to use,’ he explains.
‘I made serious calculations. It turned out that a white bicycle — per person, per
kilometre — would cost the municipality only 10% of what it contributed to public
transport per person per kilometre.’ Nevertheless, the council unanimously rejected
the plan. ‘They said that the bicycle belongs to the past. They saw a glorious future
for the car,’ says Schimmelpennink. But he was not in the least discouraged.
D Schimmelpennink never stopped believing in bike-sharing, and in the mid-90s,
two Danes asked for his help to set up a system in Copenhagen. The result was
the world’s first large-scale bike-share programme. It worked on a deposit: ‘You
dropped a coin in the bike and when you returned it, you got your money back.’
After setting up the Danish system, Schimmelpennink decided to try his luck again
```

[Original question page](assets/053f2815987d8cb391c9140a2216f9245b8bcb2ba409ae9946c8efce597280b1.jpg)

<!-- Source: /api/assets/c91c5d196fc305c1a479ffd75c8494e8d22556a9007f6c784e87b7375fca3e54.jpg; PDF page 21; full -->

```text
Reading
in the Netherlands — and this time he succeeded in arousing the interest of the
Dutch Ministry of Transport. ‘Times had changed,’ he recalls. ‘People had become
more environmentally conscious, and the Danish experiment had proved that
bike-sharing was a real possibility.’ A new Witte Fietsenplan was launched in 1999
in Amsterdam. However, riding a white bike was no longer free; it cost one guilder
per trip and payment was made with a chip card developed by the Dutch bank
Postbank. Schimmelpennink designed conspicuous, sturdy white bikes locked
in special racks which could be opened with the chip card — the plan started with
250 bikes, distributed over five stations.
E Theo Molenaar, who was a system designer for the project, worked alongside
Schimmelpennink. ‘I remember when we were testing the bike racks, he announced
that he had already designed better ones. But of course, we had to go through with
the ones we had.’ The system, however, was prone to vandalism and theft. ‘After
every weekend there would always be a couple of bikes missing,’ Molenaar says.
‘I really have no idea what people did with them, because they could instantly be
recognised as white bikes.’ But the biggest blow came when Postbank decided to
abolish the chip card, because it wasn’t profitable. ‘That chip card was pivotal to the
system,’ Molenaar says. ‘To continue the project we would have needed to set up
another system, but the business partner had lost interest.’
F Schimmelpennink was disappointed, but — characteristically — not for long. In 2002
he got a call from the French advertising corporation JC Decaux, who wanted to set
up his bike-sharing scheme in Vienna. ‘That went really well. After Vienna, they set
up a system in Lyon. Then in 2007, Paris followed. That was a decisive moment in
the history of bike-sharing.’ The huge and unexpected success of the Parisian
bike-sharing programme, which now boasts more than 20,000 bicycles, inspired cities
all over the world to set up their own schemes, all modelled on Schimmelpennink’s.
‘It’s wonderful that this happened,’ he says. ‘But financially I didn’t really benefit from
it, because I never filed for a patent.’
G In Amsterdam today, 38% of all trips are made by bike and, along with
Copenhagen, it is regarded as one of the two most cycle-friendly capitals in the
world — but the city never got another Witte Fietsenplan. Molenaar believes this
may be because everybody in Amsterdam already has a bike. Schimmelpennink,
however, cannot see that this changes Amsterdam’s need for a bike-sharing
scheme. ‘People who travel on the underground don’t carry their bikes around.
But often they need additional transport to reach their final destination.’ Although
he thinks it is strange that a city like Amsterdam does not have a successful bike-
sharing scheme, he is optimistic about the future. ‘In the 60s we didn’t stand a
chance because people were prepared to give their lives to keep cars in the city.
But that mentality has totally changed. Today everybody longs for cities that are not
dominated by cars.’
24
```

[Original question page](assets/c91c5d196fc305c1a479ffd75c8494e8d22556a9007f6c784e87b7375fca3e54.jpg)

<!-- Source: /api/assets/11a718c5919d1a98b1dca0f1c22e33d01ac0bb9b13246b0b2083319994370dbc.jpg; PDF page 22; full -->

```text
Test 1
Questions 14-18
Reading Passage 2 has seven paragraphs, A-G.
Which paragraph contains the following information?
Write the correct letter, A~G, in boxes 14-18 on your answer sheet.
NB You may use any letter more than once.
14 a description of how people misused a bike-sharing scheme
15 an explanation of why a proposed bike-sharing scheme was turned down
16 a reference to a person being unable to profit from their work
17 an explanation of the potential savings a bike-sharing scheme would bring
18 a reference to the problems a bike-sharing scheme was intended to solve
Questions 19 and 20
Choose TWO letters, A-E.
Write the correct letters in boxes 19 and 20 on your answer sheet.
Which TWO of the following statements are made in the text about the Amsterdam
bike-sharing scheme of 1999?
A It was initially opposed by a government department.
B It failed when a partner in the scheme withdrew support.
C It aimed to be more successful than the Copenhagen scheme.
D It was made possible by a change in people’s attitudes.
E It attracted interest from a range of bike designers.
```

[Original question page](assets/11a718c5919d1a98b1dca0f1c22e33d01ac0bb9b13246b0b2083319994370dbc.jpg)

<!-- Source: /api/assets/667505ffbf45f49bb67c040c2ae48be7407cb5a5232f39a5229879b2bdaaeb8b.jpg; PDF page 23; full -->

```text
Reading
Questions 21 and 22
Choose TWO letters, A-E.
Write the correct letters in boxes 21 and 22 on your answer sheet.
Which TWO of the following statements are made in the text about Amsterdam today?
A The majority of residents would like to prevent all cars from entering the city.
B There is little likelihood of the city having another bike-sharing scheme.
C More trips in the city are made by bike than by any other form of transport.
D A bike-sharing scheme would benefit residents who use public transport.
E The city has a reputation as a place that welcomes cyclists.
```

[Original question page](assets/667505ffbf45f49bb67c040c2ae48be7407cb5a5232f39a5229879b2bdaaeb8b.jpg)

<!-- Source: /api/assets/c3dad6eac108ed03cd16385840262e96854f1df6cfa5406613035bb2d5791355.jpg; PDF page 24; full -->

```text
Questions 23–26
Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 23–26 on your answer sheet.
The first urban bike-sharing scheme
The first bike-sharing scheme was the idea of the Dutch group Provo. The people who belonged to this group were (23) __________. They were concerned about damage to the environment and about (24) __________, and believed that the bike-sharing scheme would draw attention to these issues. As well as painting some bikes white, they handed out (25) __________ that condemned the use of cars.
However, the scheme was not a great success: almost as quickly as Provo left the bikes around the city, the (26) __________ took them away. According to Schimmelpennink, the scheme was intended to be symbolic. The idea was to get people thinking about the issues.
```

[Original question page](assets/c3dad6eac108ed03cd16385840262e96854f1df6cfa5406613035bb2d5791355.jpg)

<!-- Source: /api/assets/431e9301c8472f59d92342d49d5b7cad149b36842ec98f4fbe64bde55efa9224.jpg; PDF page 25; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Motivational factors and the hospitality industry
A critical ingredient in the success of hotels is developing and maintaining superior performance
from their employees. How is that accomplished? What Human Resource Management (HRM)
practices should organizations invest in to acquire and retain great employees?
Some hotels aim to provide superior working conditions for their employees. The idea originated
from workplaces — usually in the non-service sector — that emphasized fun and enjoyment as
part of work-life balance. By contrast, the service sector, and more specifically hotels, has
traditionally not extended these practices to address basic employee needs, such as good
working conditions.
Pfeffer (1994) emphasizes that in order to succeed in a global business environment,
organizations must make investment in Human Resource Management (HRM) to allow them
to acquire employees who possess better skills and capabilities than their competitors. This
investment will be to their competitive advantage. Despite this recognition of the importance
of employee development, the hospitality industry has historically been dominated by
underdeveloped HR practices (Lucas, 2002).
Lucas also points out that ‘the substance of HRM practices does not appear to be designed to
foster constructive relations with employees or to represent a managerial approach that enables
developing and drawing out the full potential of people, even though employees may be broadly
satisfied with many aspects of their work’ (Lucas, 2002). In addition, or maybe as a result, high
employee turnover has been a recurring problem throughout the hospitality industry. Among
the many cited reasons are low compensation, inadequate benefits, poor working conditions and
compromised employee morale and attitudes (Maroudas et al., 2008).
Ng and Sorensen (2008) demonstrated that when managers provide recognition to employees,
motivate employees to work together, and remove obstacles preventing effective performance,
employees feel more obligated to stay with the company. This was succinctly summarized by
Michel et al. (2013): ‘[P]roviding support to employees gives them the confidence to perform
their jobs better and the motivation to stay with the organization.’ Hospitality organizations can
therefore enhance employee motivation and retention through the development and improvement
of their working conditions. These conditions are inherently linked to the working environment.
While it seems likely that employees’ reactions to their job characteristics could be affected
by a predisposition to view their work environment negatively, no evidence exists to support
this hypothesis (Spector et al., 2000). However, given the opportunity, many people will find
25
```

[Original question page](assets/431e9301c8472f59d92342d49d5b7cad149b36842ec98f4fbe64bde55efa9224.jpg)

<!-- Source: /api/assets/4db482ae10f706c6fd289e6408f4c9d421e6400dd2cc449de9fc3532f3ee20ac.jpg; PDF page 26; full -->

```text
Test 1
something to complain about in relation to their workplace (Poulston, 2009). There is a strong
link between the perceptions of employees and particular factors of their work environment that
are separate from the work itself, including company policies, salary and vacations.
Such conditions are particularly troubling for the luxury hotel market, where high-quality service,
requiring a sophisticated approach to HRM, is recognized as a critical source of competitive
advantage (Maroudas et al., 2008). In a real sense, the services of hotel employees represent
their industry (Schneider and Bowen, 1993). This representation has commonly been limited to
guest experiences. This suggests that there has been a dichotomy between the guest environment
provided in luxury hotels and the working conditions of their employees.
It is therefore essential for hotel management to develop HRM practices that enable them to
inspire and retain competent employees. This requires an understanding of what motivates
employees at different levels of management and different stages of their careers (Enz and Siguaw,
2000). This implies that it is beneficial for hotel managers to understand what practices are most
favorable to increase employee satisfaction and retention.
Herzberg (1966) proposes that people have two major types of needs, the first being extrinsic
motivation factors relating to the context in which work is performed, rather than the work
itself. These include working conditions and job security. When these factors are unfavorable,
job dissatisfaction may result. Significantly, though, just fulfilling these needs does not result in
satisfaction, but only in the reduction of dissatisfaction (Maroudas et al., 2008).
Employees also have intrinsic motivation needs or motivators, which include such factors as
achievement and recognition. Unlike extrinsic factors, motivator factors may ideally result in job
satisfaction (Maroudas et al., 2008). Herzberg’s (1966) theory discusses the need for a ‘balance’
of these two types of needs.
The impact of fun as a motivating factor at work has also been explored. For example, Tews,
Michel and Stafford (2013) conducted a study focusing on staff from a chain of themed restaurants
in the United States. It was found that fun activities had a favorable impact on performance and
manager support for fun had a favorable impact in reducing turnover. Their findings support the
view that fun may indeed have a beneficial effect, but the framing of that fun must be carefully
aligned with both organizational goals and employee characteristics. ‘Managers must learn how to
achieve the delicate balance of allowing employees the freedom to enjoy themselves at work while
simultaneously maintaining high levels of performance’ (Tews et al., 2013).
Deery (2008) has recommended several actions that can be adopted at the organizational level to
retain good staff as well as assist in balancing work and family life. Those particularly appropriate
to the hospitality industry include allowing adequate breaks during the working day, staff
functions that involve families, and providing health and well-being opportunities.
26
```

[Original question page](assets/4db482ae10f706c6fd289e6408f4c9d421e6400dd2cc449de9fc3532f3ee20ac.jpg)

<!-- Source: /api/assets/bd83fc853f8780057d4e6a45ca41b7d180884442990fa5dc02b330217a280df3.jpg; PDF page 27; full -->

```text
Reading
Questions 27-31
Look at the following statements (Questions 27-31) and the list of researchers below.
Match each statement with the correct researcher, A-F.
Write the correct letter, A-F, in boxes 27-31 on your answer sheet.
NB You may use any letter more than once.
27 Hotel managers need to know what would encourage good staff to remain.
28 The actions of managers may make staff feel they shouldn’t move to a different
employer.
29 Little is done in the hospitality industry to help workers improve their skills.
30 Staff are less likely to change jobs if cooperation is encouraged.
31. Dissatisfaction with pay is not the only reason why hospitality workers change jobs.
List of Researchers
A Pfeffer
B Lucas
C Maroudas et al.
D Ng and Sorensen
E Enz and Siguaw
F Deery
```

[Original question page](assets/bd83fc853f8780057d4e6a45ca41b7d180884442990fa5dc02b330217a280df3.jpg)

<!-- Source: /api/assets/df82673bba2701fc3350669c1eb98a6df272c2b58cf364944dc985bc44712723.jpg; PDF page 28; full -->

```text
Test 1
Questions 32-35
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 32-35 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
32 One reason for high staff turnover in the hospitality industry is poor morale.
33 Research has shown that staff have a tendency to dislike their workplace.
34 An improvement in working conditions and job security makes staff satisfied with
their jobs.
35 Staff should be allowed to choose when they take breaks during the working day.
Questions 36-40
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 36-40 on your answer sheet.
Fun at work
Tews, Michel and Stafford carried out research on staff in an American chain of (36) __________. They discovered that activities designed for staff to have fun improved their (37) __________, and that management involvement led to lower staff (38) __________. They also found that the activities needed to fit with both the company’s (39) __________ and the (40) __________ of the staff. A balance was required between a degree of freedom and maintaining work standards.
```

[Original question page](assets/df82673bba2701fc3350669c1eb98a6df272c2b58cf364944dc985bc44712723.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/378687714143238883ee5929918a76514c84a831cdb7e32df3b0730a58f74501.jpg; PDF page 29; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show the average percentages in typical meals of three types of nutrients, all of which may be unhealthy if eaten too much.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/378687714143238883ee5929918a76514c84a831cdb7e32df3b0730a58f74501.jpg)

![Original figure](assets/378687714143238883ee5929918a76514c84a831cdb7e32df3b0730a58f74501.jpg)

### Task 2

<!-- Source: /api/assets/3fc455f5a13e85d43622a002a4aad8cb8e338747b8b239eead2cb94ec31dc141.jpg; PDF page 30; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that it is best to accept a bad situation, such as an unsatisfactory job or shortage of money. Others argue that it is better to try and improve such situations.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/3fc455f5a13e85d43622a002a4aad8cb8e338747b8b239eead2cb94ec31dc141.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/dd909a328a20f54ed2e0934a9a97de7a266b17ac404a97b989d52e40cb4134f9.jpg; PDF page 31; full -->

```text
SPEAKING
PART 1
Speaking
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Future
What job would you like to have ten years from now? [Why?]
How useful will English be for your future? [Why/Why not?]
How much travelling do you hope to do in the future? [Why/Why not?]
How do you think your life will change in the future? [Why/Why not?]
PART 2
Describe a book that you enjoyed reading because you had to think a lot.
You should say:
what this book was
why you decided to read it
what reading this book made you think about
and explain why you enjoyed reading this book.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Children and reading
Example questions:
What are the most popular types of children’s books in your country?
What are the benefits of parents reading books to their children?
Should parents always let children choose the books they read?
Electronic books
Example questions:
How popular are electronic books are in your country?
What are the advantages of parents reading electronic books (compared to
printed books)?
Will electronic books ever completely replace printed books in the future?
```

[Original question page](assets/dd909a328a20f54ed2e0934a9a97de7a266b17ac404a97b989d52e40cb4134f9.jpg)

### Part 2

<!-- Source: /api/assets/dd909a328a20f54ed2e0934a9a97de7a266b17ac404a97b989d52e40cb4134f9.jpg; PDF page 31; full -->

```text
SPEAKING
PART 1
Speaking
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Future
What job would you like to have ten years from now? [Why?]
How useful will English be for your future? [Why/Why not?]
How much travelling do you hope to do in the future? [Why/Why not?]
How do you think your life will change in the future? [Why/Why not?]
PART 2
Describe a book that you enjoyed reading because you had to think a lot.
You should say:
what this book was
why you decided to read it
what reading this book made you think about
and explain why you enjoyed reading this book.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Children and reading
Example questions:
What are the most popular types of children’s books in your country?
What are the benefits of parents reading books to their children?
Should parents always let children choose the books they read?
Electronic books
Example questions:
How popular are electronic books are in your country?
What are the advantages of parents reading electronic books (compared to
printed books)?
Will electronic books ever completely replace printed books in the future?
```

[Original question page](assets/dd909a328a20f54ed2e0934a9a97de7a266b17ac404a97b989d52e40cb4134f9.jpg)

### Part 3

<!-- Source: /api/assets/dd909a328a20f54ed2e0934a9a97de7a266b17ac404a97b989d52e40cb4134f9.jpg; PDF page 31; full -->

```text
SPEAKING
PART 1
Speaking
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Future
What job would you like to have ten years from now? [Why?]
How useful will English be for your future? [Why/Why not?]
How much travelling do you hope to do in the future? [Why/Why not?]
How do you think your life will change in the future? [Why/Why not?]
PART 2
Describe a book that you enjoyed reading because you had to think a lot.
You should say:
what this book was
why you decided to read it
what reading this book made you think about
and explain why you enjoyed reading this book.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Children and reading
Example questions:
What are the most popular types of children’s books in your country?
What are the benefits of parents reading books to their children?
Should parents always let children choose the books they read?
Electronic books
Example questions:
How popular are electronic books are in your country?
What are the advantages of parents reading electronic books (compared to
printed books)?
Will electronic books ever completely replace printed books in the future?
```

[Original question page](assets/dd909a328a20f54ed2e0934a9a97de7a266b17ac404a97b989d52e40cb4134f9.jpg)
