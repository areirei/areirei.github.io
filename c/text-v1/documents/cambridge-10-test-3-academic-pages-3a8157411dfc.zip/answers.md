# 剑雅 10 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 148

TEST 3 LISTENING
1 4
2 46 Wombat
3 Thursday
4 8.30
5 red
6 lunch
7 glasses
8 BALL
9 aunt
10 month
11 C
12 E
13 B
14 A
15 C
16 B
17 C
18 D
19 D
20 A
21 C
22 A
23 A
24 B
25 B
26 E
27 D
28 A
29 G
30 C
31 achievement / achievements
32 personality / character
33 Situational
34 friend
35 aspirations / ambitions
36 style
37 development
38 vision
39 structures
40 innovation / innovations
11 & 12 IN EITHER ORDER: C, E
If you score: 0–11: unlikely to get an acceptable score; spend a lot of time improving English before IELTS. 12–27: may get an acceptable score; consider more practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

1. 4

2. 46 Wombat

3. Thursday

4. 8.30 / 8:30

5. red

6. lunch

7. glasses

8. BALL

9. aunt

10. month

### Part 2 · source page 148

TEST 3 LISTENING
1 4
2 46 Wombat
3 Thursday
4 8.30
5 red
6 lunch
7 glasses
8 BALL
9 aunt
10 month
11 C
12 E
13 B
14 A
15 C
16 B
17 C
18 D
19 D
20 A
21 C
22 A
23 A
24 B
25 B
26 E
27 D
28 A
29 G
30 C
31 achievement / achievements
32 personality / character
33 Situational
34 friend
35 aspirations / ambitions
36 style
37 development
38 vision
39 structures
40 innovation / innovations
11 & 12 IN EITHER ORDER: C, E
If you score: 0–11: unlikely to get an acceptable score; spend a lot of time improving English before IELTS. 12–27: may get an acceptable score; consider more practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

11. C / E

12. C / E

13. B

14. A

15. C

16. B

17. C

18. D

19. D

20. A

### Part 3 · source page 148

TEST 3 LISTENING
1 4
2 46 Wombat
3 Thursday
4 8.30
5 red
6 lunch
7 glasses
8 BALL
9 aunt
10 month
11 C
12 E
13 B
14 A
15 C
16 B
17 C
18 D
19 D
20 A
21 C
22 A
23 A
24 B
25 B
26 E
27 D
28 A
29 G
30 C
31 achievement / achievements
32 personality / character
33 Situational
34 friend
35 aspirations / ambitions
36 style
37 development
38 vision
39 structures
40 innovation / innovations
11 & 12 IN EITHER ORDER: C, E
If you score: 0–11: unlikely to get an acceptable score; spend a lot of time improving English before IELTS. 12–27: may get an acceptable score; consider more practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

21. C

22. A

23. A

24. B

25. B

26. E

27. D

28. A

29. G

30. C

### Part 4 · source page 148

TEST 3 LISTENING
1 4
2 46 Wombat
3 Thursday
4 8.30
5 red
6 lunch
7 glasses
8 BALL
9 aunt
10 month
11 C
12 E
13 B
14 A
15 C
16 B
17 C
18 D
19 D
20 A
21 C
22 A
23 A
24 B
25 B
26 E
27 D
28 A
29 G
30 C
31 achievement / achievements
32 personality / character
33 Situational
34 friend
35 aspirations / ambitions
36 style
37 development
38 vision
39 structures
40 innovation / innovations
11 & 12 IN EITHER ORDER: C, E
If you score: 0–11: unlikely to get an acceptable score; spend a lot of time improving English before IELTS. 12–27: may get an acceptable score; consider more practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

31. achievement / achievements

32. personality / character

33. Situational

34. friend

35. aspirations / ambitions

36. style

37. development

38. vision

39. structures

40. innovation / innovations

## A 类阅读

### Academic Reading · source page 149

TEST 3 ACADEMIC READING
1 ii
2 i
3 v
4 vii
5 TRUE
6 NOT GIVEN
7 NOT GIVEN
8 TRUE
9 NOT GIVEN
10 FALSE
11 source of income / industry
12 employer
13 domestic tourism
14 C
15 B
16 H
17 B
18 E
19 sun(light)
20 upper
21 dry
22 north
23 FALSE
24 TRUE
25 NOT GIVEN
26 B
27 B
28 F
29 I
30 G
31 D
32 C
33 A
34 D
35 C
36 NO
37 YES
38 NOT GIVEN
39 YES
40 NOT GIVEN
If you score: 0–11: unlikely to get an acceptable score; spend a lot of time improving English before IELTS. 12–27: may get an acceptable score; consider more practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

1. ii

2. i

3. v

4. vii

5. TRUE

6. NOT GIVEN

7. NOT GIVEN

8. TRUE

9. NOT GIVEN

10. FALSE

11. source of income / industry

12. employer

13. domestic tourism

14. C

15. B

16. H

17. B

18. E

19. sun / sunlight

20. upper

21. dry

22. north

23. FALSE

24. TRUE

25. NOT GIVEN

26. B

27. B

28. F

29. i

30. G

31. D

32. C

33. A

34. D

35. C

36. NO

37. YES

38. NOT GIVEN

39. YES

40. NOT GIVEN

## A 类写作

### Writing material: c10-t3-w-1

UK2008, counts of students EXCLUDING full-time work. Four categories: part-time work, voluntary work, further study, unemployment. Graduates:17,735;3,500;29,665;16,235. Postgraduates:2,535;345;2,725;1,625. Graduate vertical axis0–30,000; postgraduate0–3,000, so heights are not directly comparable as counts. Further study largest and voluntary work smallest in both. Graduate further study far exceeds part-time work; postgraduate gap is small. Do not treat values as percentages, include full-time employment, or infer all UK students are in these groups.



### Writing material: c10-t3-w-2

Evaluate increasing similarity caused by availability of the same products worldwide. Explain consequences and give a clear positive/negative or justified qualified evaluation; a generic globalisation essay may miss this specific mechanism.



## 口语
