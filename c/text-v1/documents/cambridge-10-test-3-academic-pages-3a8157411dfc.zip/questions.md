# 剑雅 10 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/a19e7933ba8cc51216f62b5e2f773344faa21551f3e2bd3ae5354e60dc4bfe3a.jpg; PDF page 50; full -->

```text
Test 3
LISTENING
SECTION 1  Questions 1–10
Complete the form below.
Write ONE WORD AND/OR A NUMBER for each answer.
Early Learning Childcare Centre
Enrolment Form
Example
Parent or guardian: Carol
.........
Smith
..........
Personal Details
Child’s name: Kate
Age: 1 ...............................
Address: 2 ..................................Road, Woodside, 4032
Phone: 3345 9865
Childcare Information
Days enrolled for: Monday and 3 ...............................
Start time: 4
.................................................................. am
Childcare group: the 5 ...............................group
Which meal/s are required each day? 6 ...............................
Medical conditions: needs 7 ...............................
Emergency contact: Jenny 8 ...............................Phone: 3346 7523
Relationship to child: 9 ...............................
Fees
Will pay each 10 ...............................
57
```

[Original question page](assets/a19e7933ba8cc51216f62b5e2f773344faa21551f3e2bd3ae5354e60dc4bfe3a.jpg)

### Part 2

<!-- Source: /api/assets/da4af20ce7bab3f56ed35566d8c9db252789d475982be2f51abf6390d592ef59.jpg; PDF page 51; full -->

```text
SECTION 2 Questions 11–20
Questions 11 and 12
Choose TWO letters, A–E.
Which TWO things does Alice say about the Dolphin Conservation Trust?
A Children make up most of the membership.
B It’s the country’s largest conservation organisation.
C It helps finance campaigns for changes in fishing practices.
D It employs several dolphin experts full-time.
E Volunteers help in various ways.
Questions 13–15
Choose the correct letter, A, B, or C.
13 Why is Alice so pleased the Trust has won the Charity Commission award?
A It has brought in extra money.
B It made the work of the trust better known.
C It has attracted more members.
14 Alice says oil exploration causes problems to dolphins because of
A noise.
B oil leaks.
C movement of ships.
15 Alice became interested in dolphins when
A she saw one swimming near her home.
B she heard a speaker at her school.
C she read a book about them.
```

[Original question page](assets/da4af20ce7bab3f56ed35566d8c9db252789d475982be2f51abf6390d592ef59.jpg)

<!-- Source: /api/assets/12e56653f554dadca0e1a0596c6f081febf1e743132f46265d8050c24fc5d63d.jpg; PDF page 52; full -->

```text
Listening
Which dolphin does Alice make each of the following comments about?
Write the correct letter, A, B, C or D, next to questions 16-20.
Questions 16-20
Dolphins
A Moondancer
B Echo
C Kiwi
D Samson
Comments
16 It has not been seen this year.
17 It is photographed more than the others.
18 It is always very energetic.
19 It is the newest one in the scheme.
20 It has an unusual shape.
59
```

[Original question page](assets/12e56653f554dadca0e1a0596c6f081febf1e743132f46265d8050c24fc5d63d.jpg)

### Part 3

<!-- Source: /api/assets/ef40f07e2434131e129655a59fc9fe0ef5c4f9ed3d297fb742c2ba89f46b82c9.jpg; PDF page 53; full -->

```text
SECTION 3 Questions 21–30
Test 3
Questions 21-25
Choose the correct letter, A, B or C.
Theatre Studies Course
21 What helped Rob to prepare to play the character of a doctor?
A  the stories his grandfather told him
B the times when he watched his grandfather working
C the way he imagined his grandfather at work
22 In the play’s first scene, the boredom of village life was suggested by
A repetition of words and phrases.
B scenery painted in dull colours.
C long pauses within conversations.
23 What has Rob learned about himself through working in a group?
A He likes to have clear guidelines.
B He copes well with stress.
C He thinks he is a good leader.
24 To support the production, research material was used which described
A political developments.
B changing social attitudes.
C economic transformations.
25 What problem did the students overcome in the final rehearsal?
A one person forgetting their words
B an equipment failure
C the injury of one character

60
```

[Original question page](assets/ef40f07e2434131e129655a59fc9fe0ef5c4f9ed3d297fb742c2ba89f46b82c9.jpg)

<!-- Source: /api/assets/a8d8191d6abfdbd57b88458eeeab9287352ef586cc1d8b4a48244c598600b602.jpg; PDF page 54; full -->

```text
Listening
Choose FIVE answers from the box and write the correct letter, A-G, next to
questions 26-30.
Questions 26-30
What action is needed for the following stages in doing the ‘year abroad’ option?
Action
A be on time
B get a letter of recommendation
C plan for the final year
D make sure the institution’s focus is relevant
E show ability in Theatre Studies
F make travel arrangements and bookings
G ask for help
Stages in doing the ‘year abroad' option
26 in the second year of the course ......
27 when first choosing where to go
28 when sending in your choices
29 when writing your personal statement ......
30 when doing the year abroad
61
```

[Original question page](assets/a8d8191d6abfdbd57b88458eeeab9287352ef586cc1d8b4a48244c598600b602.jpg)

### Part 4

<!-- Source: /api/assets/81c6f177a40a1e2eae927b9e861f2d6438fef3ceec514361eb665623da8750e5.jpg; PDF page 55; full -->

```text
SECTION 4 Questions 31–40
Test 3
Complete the notes below.
Write ONE WORD ONLY for each answer.
‘Self-regulatory focus theory’ and leadership
Self-regulatory focus theory
People's focus is to approach pleasure or avoid pain
Promotion goals focus on 31 ...............................
Prevention goals emphasise avoiding punishment
Factors that affect people's focus
The Chronic Factor
• comes from one's 32 ...............................
The 33 ...............................Factor
• we are more likely to focus on promotion goals when with a 34
............................
• we are more likely to focus on prevention goals with our boss
How people's focus affects them
Promotion Focus: People think about an ideal version of themselves, their
35 ...............................and their gains.
Prevention Focus: People think about their 'ought' self and their obligations

62
```

[Original question page](assets/81c6f177a40a1e2eae927b9e861f2d6438fef3ceec514361eb665623da8750e5.jpg)

<!-- Source: /api/assets/5622bac7244e4e4338200451c99b29322f48fc30b52a7bd67b3bfc2e15428349.jpg; PDF page 56; full -->

```text
Listening
Leaders
Leadership behaviour and 36 ...............................affects people's focus
Transformational Leaders:
• pay special attention to the 37 ...............................of their followers
• passionately communicate a clear 38
................................
• inspire promotion focus in followers
Transactional Leaders:
• create 39 ...............................to make expectations clear
• emphasise the results of a mistake
• inspire prevention focus in followers
Conclusion
Promotion Focus is good for jobs requiring 40 ...............................
Prevention Focus is good for work such as a surgeon
Leaders' actions affect which focus people use
63
```

[Original question page](assets/5622bac7244e4e4338200451c99b29322f48fc30b52a7bd67b3bfc2e15428349.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/6b75f7c14af12f6d4e1f9f1deb85ae0303aa66140872a569ace530b3dfa328ca.jpg; PDF page 57; full -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1–13, which are based on Reading Passage 1 on the following pages.
Questions 1–4
Reading Passage 1 has five paragraphs, A–E.
Choose the correct heading for paragraphs B–E from the list of headings below.
Write the correct number, i–vii, in boxes 1–4 on your answer sheet.
List of Headings
i Economic and social significance of tourism
ii The development of mass tourism
iii Travel for the wealthy
iv Earning foreign exchange through tourism
v Difficulty in recognising the economic effects of tourism
vi The contribution of air travel to tourism
vii The world impact of tourism
viii The history of travel
Example — Paragraph A: viii
1 Paragraph B
2 Paragraph C
3 Paragraph D
4 Paragraph E
[Source note: printed instruction says i–vii although the heading list includes viii; reproduced as printed.]
```

[Original question page](assets/6b75f7c14af12f6d4e1f9f1deb85ae0303aa66140872a569ace530b3dfa328ca.jpg)

<!-- Source: /api/assets/d4bdce77ac4784f389afa0c633b29513fa2762298c2769db90d6907471893f32.jpg; PDF page 58; full -->

```text
The Context, Meaning and Scope of Tourism
A Travel has existed since the beginning of time, when primitive man set out, often
traversing great distances in search of game, which provided the food and clothing
necessary for his survival. Throughout the course of history, people have travelled
for purposes of trade, religious conviction, economic gain, war, migration and other
equally compelling motivations. In the Roman era, wealthy aristocrats and high
government officials also travelled for pleasure. Seaside resorts located at Pompeii
and Herculaneum afforded citizens the opportunity to escape to their vacation villas
in order to avoid the summer heat of Rome. Travel, except during the Dark Ages,
has continued to grow and, throughout recorded history, has played a vital role in the
development of civilisations and their economies.
B Tourism in the
mass
form as we know it today is a distinctly twentieth-century
phenomenon. Historians suggest that the advent of mass tourism began in England
during the industrial revolution with the rise of the middle class and the availability
of relatively inexpensive transportation. The creation of the commercial airline
industry following the Second World War and the subsequent development of the
jet aircraft in the 1950s signalled the rapid growth and expansion of international
travel. This growth led to the development of a major new industry: tourism. In turn,
international tourism became the concern of a number of world governments since
it not only provided new employment opportunities but also produced a means of
earning foreign exchange.
C Tourism today has grown significantly in both economic and social importance. In
most industrialised countries over the past few years the fastest growth has been
seen in the area of services. One of the largest segments of the service industry,
although largely unrecognised as an entity in some of these countries, is travel
and tourism. According to the World Travel and Tourism Council (1992), ‘Travel
and tourism is the largest industry in the world on virtually any economic measure
including value-added capital investment, employment and tax contributions’. In
1992, the industry’s gross output was estimated to be $3.5 trillion, over 12 per cent
of all consumer spending. The travel and tourism industry is the world’s  largest
employer with almost 130 million jobs, or almost 7 per cent of all employees. This
industry is the world’s leading industrial contributor, producing over 6 per cent of
the world’s gross national product and accounting for capital investment in excess
of $422 billion in direct, indirect and personal taxes each year. Thus, tourism has a
profound impact both on the world economy and, because of the educative effect of
travel and the effects on employment, on society itself.
65
```

[Original question page](assets/d4bdce77ac4784f389afa0c633b29513fa2762298c2769db90d6907471893f32.jpg)

<!-- Source: /api/assets/d179d979b622a0ba18bc012c510ffbf37c905012a4ed44ef381d282991aa0613.jpg; PDF page 59; full -->

```text
Test 3
D However, the
major
problems of the travel and
tourism industry
that have hidden,
or obscured, its economic impact are the diversity and fragmentation of the
industry itself. The travel industry includes: hotels, motels and other types of
accommodation; restaurants and other food services; transportation services and
facilities; amusements, attractions and other leisure facilities; gift shops and a
large number of other enterprises. Since many of these businesses also serve
local residents, the impact of spending by visitors can easily be overlooked or
underestimated. In addition, Meis (1992) points out that the tourism industry
involves concepts that have remained amorphous to both analysts and decision
makers. Moreover, in all nations this problem has made it difficult for the industry
to develop any type of reliable or credible tourism information base in order to
estimate the contribution it makes to regional, national and global economies.
However, the nature of this very diversity makes travel and tourism ideal vehicles
for economic development in a wide variety of countries, regions or communities.
E Once the exclusive province of the wealthy, travel and
tourism
have become an
institutionalised way of life for most of the population. In fact, McIntosh and
Goeldner (1990) suggest that tourism has become the largest commodity in
international trade for many nations and, for a significant number of other countries,
it ranks second or third. For example, tourism is the major source of income in
Bermuda, Greece, Italy, Spain, Switzerland and most Caribbean countries. In
addition, Hawkins and Ritchie, quoting from data published by the American
Express Company, suggest that the travel and tourism industry is the number
one ranked employer in the Bahamas, Brazil, Canada, France, (the former) West
Germany, Hong Kong, Italy, Jamaica, Japan, Singapore, the United Kingdom and
the United States. However, because of problems of definition, which directly affect
statistical measurement, it is not possible with any degree of certainty to provide
precise, valid or reliable data about the extent of world-wide tourism participation
or its economic impact. In many cases, similar difficulties arise when attempts are
made to measure domestic tourism.
66
```

[Original question page](assets/d179d979b622a0ba18bc012c510ffbf37c905012a4ed44ef381d282991aa0613.jpg)

<!-- Source: /api/assets/387576e957cdfb019ff19506cef54826c7a8e551c882c9689d3739f1f479a259.jpg; PDF page 60; full -->

```text
Questions 5-10
Do the following statements agree with the information given in Reading Passage 1?
Reading
In boxes 5-10 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
5 The largest employment figures in the world are found in the travel and tourism
industry.
6 Tourism contributes over six per cent of the Australian gross national product.
7 Tourism has a social impact because it promotes recreation.
8 Two main features of the travel and tourism industry make its economic significance
difficult to ascertain.
9 Visitor spending is always greater than the spending of residents in tourist areas.
10 It is easy to show statistically how tourism affects individual economies.
Questions 11-13
Complete the sentences below.
Choose NO MORE THAN THREE WORDS from the passage for each answer.
Write your answers in boxes 11-13 on your answer sheet.
11 In Greece, tourism is the most important
.................
12 The travel and tourism industry in Jamaica is the major
.................
13 The problems associated with measuring international tourism are often reflected in
the measurement of
.................
```

[Original question page](assets/387576e957cdfb019ff19506cef54826c7a8e551c882c9689d3739f1f479a259.jpg)

<!-- Source: /api/assets/53b8964401abfc1142da81fe352d1ffac690191c321b0d34b83ca1a54b4fbe14.jpg; PDF page 61; full -->

```text
Test 3
READING PASSAGE 2
You should spend about 20 minutes on Q uestions 14-26, which are based on Reading
Passage 2 below.
Autumn leaves
Canadian writer Jay Ingram investigates the mystery of why leaves turn red in the fall
A One of the most captivating natural events of the year in many areas
throughout
North America is the turning of the leaves in the fall. The colours are magnificent,
but the question of exactly why some trees turn yellow or orange, and others red or
purple, is something which has long puzzled scientists.
B Summer leaves are green because they are full of chlorophyll, the molecule that
captures sunlight and converts that energy into new building materials for the tree.
As fall approaches in the northern hemisphere, the amount of solar energy available
declines considerably. For many trees -  evergreen conifers being an exception
—
the best strategy is to abandon photosynthesis* until the spring. So rather than
maintaining the now redundant leaves throughout the winter, the tree saves its
precious resources and discards them. But before letting its leaves go, the tree
dismantles their chlorophyll molecules and ships their valuable nitrogen back into
the twigs. As chlorophyll is depleted, other colours that have been dominated by it
throughout the summer begin to be revealed. This unmasking explains the autumn
colours of yellow and orange, but not the brilliant reds and purples of trees such as
the maple or sumac.
C The source of the red is widely known: it is created by anthocyanins, water-soluble
plant pigments reflecting the red to blue range of the visible spectrum. They belong to
a class of sugar-based chemical compounds also known as flavonoids. What’s puzzling
is that anthocyanins are actually newly minted, made in the leaves at the same time as
the tree is preparing to drop them. But it is hard to make sense of the manufacture of
anthocyanins - why should a tree bother making new chemicals in its leaves when it’s
already scrambling to withdraw and preserve the ones already there?
D Some
theories about
anthocyanins have
argued
that they might act as a
chemical
defence against attacks by insects or fungi, or that they might attract fruit-eating
birds or increase a leaf’s tolerance to freezing. However there are problems with
each of these theories, including the fact that leaves are red for such a relatively
short period that the expense of energy needed to manufacture the anthocyanins
would outweigh any anti-fungal or anti-herbivore activity achieved.
* photosynthesis: the production of new material from sunlight, water and carbon dioxide
68
```

[Original question page](assets/53b8964401abfc1142da81fe352d1ffac690191c321b0d34b83ca1a54b4fbe14.jpg)

<!-- Source: /api/assets/7d97d0c3023c209e1bcc49ad328651b9fa193d80845e74955fefe296565d699e.jpg; PDF page 62; full -->

```text
Reading
E It has also been proposed that trees may produce vivid red colours to convince
herbivorous insects that they are healthy and robust and would be easily able
to mount chemical defences against infestation. If insects paid attention to
such advertisements, they might be prompted to lay their eggs on a duller, and
presumably less resistant host. The flaw in this theory lies in the lack of proof
to support it. No one has as yet ascertained whether more robust trees sport the
brightest leaves, or whether insects make choices according to colour intensity.
F
Perhaps the most plausible suggestion
as
to why leaves
would
go to the trouble
of making anthocyanins when they’re busy packing up for the winter is the
theory known as the ‘light screen’ hypothesis. It sounds paradoxical, because the
idea behind this hypothesis is that the red pigment is made in autumn leaves to
protect chlorophyll, the light-absorbing chemical, from too much light. Why does
chlorophyll need protection when it is the natural world’s supreme light absorber?
Why protect chlorophyll at a time when the tree is breaking it down to salvage as
much of it as possible?
G Chlorophyll, although
exquisitely
evolved to capture the energy of sunlight,
can sometimes be overwhelmed by it, especially in situations of drought, low
temperatures, or nutrient deficiency. Moreover, the problem of oversensitivity
to light is even more acute in the fall, when the leaf is busy preparing for winter
by dismantling its internal machinery. The energy absorbed by the chlorophyll
molecules of the unstable autumn leaf is not immediately channelled into useful
products and processes, as it would be in an intact summer leaf. The weakened fall
leaf then becomes vulnerable to the highly destructive effects of the oxygen created
by the excited chlorophyll molecules.
H Even if  you had
never suspected
that this is what was going on when
leaves
turn
red, there are clues out there. One is straightforward: on many trees, the leaves that
are the reddest are those on the side of the tree which gets most sun. Not only that,
but the red is brighter on the upper side of the leaf. It has also been recognised for
decades that the best conditions for intense red colours are dry, sunny days and cool
nights, conditions that nicely match those that make leaves susceptible to excess
light. And finally, trees such as maples usually get much redder the more north you
travel in the northern hemisphere. It’s colder there, they’re more stressed, their
chlorophyll is more sensitive and it needs more sunblock.
I What is still not fully understood, however, is why some trees resort to producing
red pigments while others don’t bother, and simply reveal their orange or yellow
hues. Do these trees have other means at their disposal to prevent overexposure to
light in autumn? Their story, though not as spectacular to the eye, will surely turn
out to be as subtle and as complex.
69
```

[Original question page](assets/7d97d0c3023c209e1bcc49ad328651b9fa193d80845e74955fefe296565d699e.jpg)

<!-- Source: /api/assets/a13588df436de3a1280df2f262317cc1711c088ed8df75bf856d6ef90775270c.jpg; PDF page 63; full -->

```text
Questions 14-18
Reading Passage 2 has nine paragraphs, A–I.
Test 3
Which paragraph contains the following information?
Write the correct letter, A–I, in boxes 14-18 on your answer sheet.
NB You may use any letter more than once.
14 a description of the substance responsible for the red colouration of leaves
15 the reason why trees drop their leaves in autumn
16 some evidence to confirm a theory about the purpose of the red leaves
17 an explanation of the function of chlorophyll
18 a suggestion that the red colouration in leaves could serve as a warning signal
Questions 19-22
Complete the notes below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 19-22 on your answer sheet.
Why believe the ‘light screen’ hypothesis?
• The most vividly coloured red leaves are found on the side of the tree facing the
19
.................
• The 20
...............
surfaces of leaves contain the most red pigment.
• Red leaves are most abundant when daytime weather conditions are 21
............
and sunny.
• The intensity of the red colour of leaves increases as you go further 22
...............
```

[Original question page](assets/a13588df436de3a1280df2f262317cc1711c088ed8df75bf856d6ef90775270c.jpg)

<!-- Source: /api/assets/d99912df3d12159001eb6b749aea57474144ae5af9116314ba23301aa293a24e.jpg; PDF page 64; full -->

```text
Questions 23-25
Do the following statements agree with the information given in Reading Passage 2?
Reading
In boxes 23-25 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
23 It is likely that the red pigments help to protect the leaf from freezing temperatures.
24 The ‘light screen’ hypothesis would initially seem to contradict what is known about
chlorophyll.
25 Leaves which turn colours other than red are more likely to be damaged by
sunlight.
Question 26
Choose the correct letter A, B, C or D.
Write the correct letter in box 26 on your answer sheet.
For which of the following questions does the writer offer an explanation?
A why conifers remain green in  winter
B how leaves turn orange and yellow in autumn
C how herbivorous insects choose which trees to lay their eggs in
D why anthocyanins are restricted to certain trees
```

[Original question page](assets/d99912df3d12159001eb6b749aea57474144ae5af9116314ba23301aa293a24e.jpg)

<!-- Source: /api/assets/d972a26ae7356779a78b335a5350faf03ea7c6268238450e4246ea90cf9891d2.jpg; PDF page 65; full -->

```text
Test 3
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Beyond the blue horizon
Ancient voyagers who settled the far-flung islands of the
Pacific Ocean
An important archaeological discovery on
the island of Éfaté in the Pacific archipelago
of Vanuatu has revealed traces of an ancient
seafaring people, the distant ancestors of today’s
Polynesians. The site came to light only by chance.
An agricultural worker, digging in the grounds of
a derelict plantation, scraped open a grave - the
first of dozens in a burial ground some 3,000
years old. It is the oldest cemetery ever found in the
Pacific islands, and it harbors the remains of an
ancient people archaeologists call the Lapita.
They were daring blue-water adventurers
who used basic canoes to rove across the ocean.
But they were not just explorers. They were also
pioneers who carried with them everything they
would need to build new lives —  their livestock,
taro seedlings and stone tools. Within the span
of several centuries, the Lapita stretched the
boundaries of their world from the jungle-clad
volcanoes of Papua New Guinea to the loneliest
coral outliers of Tonga.
The Lapita left precious few clues about
themselves, but Éfaté expands the volume of data
available to researchers dramatically. The remains
of 62 individuals have been uncovered so far,
and archaeologists were also thrilled to find six
complete Lapita pots. Other items included a
Lapita burial urn with modeled birds arranged
on the rim as though peering down at the human
remains sealed inside. ‘It’s an important discovery,’
says Matthew Spriggs, professor of archaeology at
the Australian National University and head of
the international team digging up the site, ‘for it
conclusively identifies the remains as Lapita.’
DNA teased from these  human remains may
help answer one of the most puzzling questions in
Pacific anthropology: did all Pacific islanders spring
from one source or many? Was there only one
outward migration from a single point in Asia, or
several from different points? ‘This represents the
best opportunity we’ve had yet,’ says Spriggs, ‘to
find out who the Lapita actually were, where they
came from, and who their closest descendants are
today.’
There is one stubborn question for which
archaeology has yet to provide any answers: how
did the Lapita accomplish the ancient equivalent
of a moon landing, many times over? No-one
has found one of their canoes or any rigging,
which could reveal how the canoes were sailed.
Nor do the oral histories and traditions of later
Polynesians offer any insights, for they turn into
myths long before they reach as far back in time
as the Lapita.
72
[Map retained: Pacific locations labelled Australia, Guam, Papua New Guinea, Solomon Is, Vanuatu, Fiji, Samoa, Tahiti, Hawaii and USA.]
```

[Original question page](assets/d972a26ae7356779a78b335a5350faf03ea7c6268238450e4246ea90cf9891d2.jpg)

![Original figure](assets/d972a26ae7356779a78b335a5350faf03ea7c6268238450e4246ea90cf9891d2.jpg)

<!-- Source: /api/assets/344da8278d82f1a36e5aee1e17b3c3e8233d2074dd485c0c155e449f6cb3139f.jpg; PDF page 66; full -->

```text
Reading
All we can say for certain is that the Lapita
had canoes that were capable of ocean voyages,
and they had the ability to sail them,’ says Geoff
Irwin, a professor of archaeology at the University
of Auckland. Those sailing skills, he says, were
developed and passed down over thousands of
years by earlier mariners who worked their way
through the archipelagoes of the western Pacific,
making short crossings to nearby islands. The real
adventure didn’t begin, however, until their Lapita
descendants sailed out of sight of land, with
empty horizons on every side. This must have
been as difficult for them as landing on the moon
is for us today. Certainly it distinguished them
from their ancestors, but what gave them the
courage to launch out on such risky voyages?
The Lapita’s thrust into the Pacific was
eastward, against the prevailing trade winds,
Irwin notes. Those nagging headwinds, he argues,
may have been the key to their success. ‘They
could sail out for days into the unknown and assess
the area, secure in the knowledge that if they
didn’t find anything, they could turn about
and catch a swift ride back on the trade winds.
This is what would have made the whole thing
work.’ Once out there, skilled seafarers would
have detected abundant leads to follow to land:
seabirds, coconuts and twigs carried out to sea by
the tides, and the afternoon pile-up of clouds on
the horizon which often indicates an island in the
distance.
For returning explorers, successful or not, the
geography of their own archipelagoes would have
provided a safety net. Without this to go by,
overshooting their home ports, getting lost and
sailing off into eternity would have been all too
easy. Vanuatu, for example, stretches more than
500 miles in a northwest-southeast trend, its
scores of intervisible islands forming a backstop
for mariners riding the trade winds home.
All this presupposes one essential detail, says
Atholl Anderson, professor of prehistory at the
Australian National University: the Lapita had
mastered the advanced art of sailing against the
wind. And there’s no proof they could do any
such thing,’ Anderson says. ‘There has been
this assumption they did, and people have built
canoes to re-create those early voyages based on that
assumption. But nobody has any idea what their
canoes looked like or how they were rigged.’
Rather than give all the credit to human
skill, Anderson invokes the winds of chance. El
Niño, the same climate disruption that affects the
Pacific today, may have helped scatter the Lapita,
Anderson suggests. He points out that climate data
obtained from slow-growing corals around the
Pacific indicate a series of unusually frequent El
Niños around the time of the Lapita expansion. By
reversing the regular east-to-west flow of the trade
winds for weeks at a time, these super El Niños’
might have taken the Lapita on long unplanned
voyages.
However they did it, the Lapita spread
themselves a third of the way across the Pacific,
then called it quits for reasons known only to
them. Ahead lay the vast emptiness of the central
Pacific and perhaps they were too thinly stretched
to venture farther. They probably never numbered
more than a few thousand in total, and in their
rapid migration eastward they encountered
hundreds of islands —  more than 300 in Fiji alone.
73
```

[Original question page](assets/344da8278d82f1a36e5aee1e17b3c3e8233d2074dd485c0c155e449f6cb3139f.jpg)

<!-- Source: /api/assets/2b993166e4f4af7dac20aa8f2a937eab3be1d45a5b3dee8fe972de665527ae20.jpg; PDF page 67; full -->

```text
Questions 27-31
Complete the summary using the list of words and phrases, A-J, below.
Test 3
Write the correct letter, A-J, in boxes 27-31 on your answer sheet.
The Efate burial site
A 3,000-year-old burial ground of a seafaring people called the Lapita has been found
on an abandoned 27
...............
on the Pacific island of Efate. The cemetery, which is a
significant 28
...............
.
was uncovered accidentally by an agricultural worker.
The Lapita explored and colonised many Pacific islands over several centuries. They
took many things with them on their voyages including 29
...............
and tools.
The burial ground increases the amount of information about the Lapita available to
scientists. A team of researchers, led by Matthew Spriggs from the Australian National
University, are helping with the excavation of the site. Spriggs believes the 30
...............
which was found at the site is very important since it confirms that the 31
...............
found
inside are Lapita.
```

[Original question page](assets/2b993166e4f4af7dac20aa8f2a937eab3be1d45a5b3dee8fe972de665527ae20.jpg)

<!-- Source: /api/assets/2a06e079eb0dce960c79e0356c247772f0fb741c297362676a66d0631c401930.jpg; PDF page 68; full -->

```text
Questions 32–35
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 32–35 on your answer sheet.
32 According to the writer, there are difficulties explaining how the Lapita accomplished their journeys because
A the canoes that have been discovered offer relatively few clues.
B archaeologists have shown limited interest in this area of research.
C little information relating to this period can be relied upon for accuracy.
D technological advances have altered the way such achievements are viewed.
33 According to the sixth paragraph, what was extraordinary about the Lapita?
A They sailed beyond the point where land was visible.
B Their cultural heritage discouraged the expression of fear.
C They were able to build canoes that withstood ocean voyages.
D Their navigational skills were passed on from one generation to the next.
34 What does ‘This’ refer to in the seventh paragraph?
A the Lapita’s seafaring talent
B the Lapita’s ability to detect signs of land
C the Lapita’s extensive knowledge of the region
D the Lapita’s belief they would be able to return home
35 According to the eighth paragraph, how was the geography of the region significant?
A It played an important role in Lapita culture.
B It meant there were relatively few storms at sea.
C It provided a navigational aid for the Lapita.
D It made a large number of islands habitable.
```

[Original question page](assets/2a06e079eb0dce960c79e0356c247772f0fb741c297362676a66d0631c401930.jpg)

<!-- Source: /api/assets/840aeedfef72748005ccbf07d4fc619527c7fbbc568e78789f8f7167b4869b87.jpg; PDF page 69; full -->

```text
Questions 36-40
Do the following statements agree with the views of the writer in Reading Passage 3?
Test 3
In boxes 36-40 on your answer sheet, write
YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
36 It is now clear that the Lapita could sail into a prevailing wind.
37 Extreme climate conditions may have played a role in Lapita migration.
38 The Lapita learnt to predict the duration of El Ninos.
39 It remains unclear why the Lapita halted their expansion across the Pacific.
40 It is likely that the majority of Lapita settled on Fiji.
```

[Original question page](assets/840aeedfef72748005ccbf07d4fc619527c7fbbc568e78789f8f7167b4869b87.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/d63296f0ad84e729c66e616734ce9333f4e739163841d402dae12b8bd8668aad.jpg; PDF page 70; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show what UK graduate and postgraduate students who did not go into full-time work did after leaving college in 2008.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/d63296f0ad84e729c66e616734ce9333f4e739163841d402dae12b8bd8668aad.jpg)

![Original figure](assets/d63296f0ad84e729c66e616734ce9333f4e739163841d402dae12b8bd8668aad.jpg)

### Task 2

<!-- Source: /api/assets/9f19e48147c08b96532aca2a46c2420e26b4dda0ede41cfec910fdd2dd849ac7.jpg; PDF page 71; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Countries are becoming more and more similar because people are able to buy the same products anywhere in the world.

Do you think this is a positive or negative development?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/9f19e48147c08b96532aca2a46c2420e26b4dda0ede41cfec910fdd2dd849ac7.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/ee8c6862408396770c0d5b69b2a159e33b825d7dad600bbbf496b6462adbf3f3.jpg; PDF page 72; full -->

```text
Speaking
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Travel
• Do you enjoy travelling? [Why/Why not?]
• Have you done much travelling? [Why/Why not?]
• Do you think it’s better to travel alone or with other people? [Why?]
• Where would you like to travel in the future? [Why?]

PART 2
Describe a child that you know.
You should say:
– who this child is and how often you see him or her
– how old this child is
– what he or she is like
and explain what you feel about this child.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topi cs:
Relationships between parents and children
Example questions:
How much time do children spend with their parents in your country? Do you think that
is enough?
How important do you think spending time together is for the relationships between
parents and children? Why?
Have relationships between parents and children changed in recent years? Why do you
think that is?
Children’s free-time activities
Example questions:
What are the most popular free-time activities with children today?
Do you think the free-time activities children do today are good for their health? Why is that?
How do you think children’s activities will change in the future? Will this be a
positive change?
```

[Original question page](assets/ee8c6862408396770c0d5b69b2a159e33b825d7dad600bbbf496b6462adbf3f3.jpg)

### Part 2

<!-- Source: /api/assets/ee8c6862408396770c0d5b69b2a159e33b825d7dad600bbbf496b6462adbf3f3.jpg; PDF page 72; full -->

```text
Speaking
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Travel
• Do you enjoy travelling? [Why/Why not?]
• Have you done much travelling? [Why/Why not?]
• Do you think it’s better to travel alone or with other people? [Why?]
• Where would you like to travel in the future? [Why?]

PART 2
Describe a child that you know.
You should say:
– who this child is and how often you see him or her
– how old this child is
– what he or she is like
and explain what you feel about this child.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topi cs:
Relationships between parents and children
Example questions:
How much time do children spend with their parents in your country? Do you think that
is enough?
How important do you think spending time together is for the relationships between
parents and children? Why?
Have relationships between parents and children changed in recent years? Why do you
think that is?
Children’s free-time activities
Example questions:
What are the most popular free-time activities with children today?
Do you think the free-time activities children do today are good for their health? Why is that?
How do you think children’s activities will change in the future? Will this be a
positive change?
```

[Original question page](assets/ee8c6862408396770c0d5b69b2a159e33b825d7dad600bbbf496b6462adbf3f3.jpg)

### Part 3

<!-- Source: /api/assets/ee8c6862408396770c0d5b69b2a159e33b825d7dad600bbbf496b6462adbf3f3.jpg; PDF page 72; full -->

```text
Speaking
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Travel
• Do you enjoy travelling? [Why/Why not?]
• Have you done much travelling? [Why/Why not?]
• Do you think it’s better to travel alone or with other people? [Why?]
• Where would you like to travel in the future? [Why?]

PART 2
Describe a child that you know.
You should say:
– who this child is and how often you see him or her
– how old this child is
– what he or she is like
and explain what you feel about this child.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topi cs:
Relationships between parents and children
Example questions:
How much time do children spend with their parents in your country? Do you think that
is enough?
How important do you think spending time together is for the relationships between
parents and children? Why?
Have relationships between parents and children changed in recent years? Why do you
think that is?
Children’s free-time activities
Example questions:
What are the most popular free-time activities with children today?
Do you think the free-time activities children do today are good for their health? Why is that?
How do you think children’s activities will change in the future? Will this be a
positive change?
```

[Original question page](assets/ee8c6862408396770c0d5b69b2a159e33b825d7dad600bbbf496b6462adbf3f3.jpg)
