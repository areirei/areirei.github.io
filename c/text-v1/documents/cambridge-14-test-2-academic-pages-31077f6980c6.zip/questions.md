# 剑雅 14 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/dd45a39c411702357d5040b2c0a2e840f26d84c243b485c738a9a9b7f5f77e9d.jpg; PDF page 32; full -->

```text
SECTION 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
TOTAL HEALTH CLINIC
PATIENT DETAILS
Personal information
Example Name: Julie Anne Garcia
Contact phone: (1) __________
Date of birth: (2) __________, 1992
Occupation: works as a (3) __________
Insurance company: (4) __________ Life Insurance
Details of the problem
Type of problem: pain in her left (5) __________
When it began: (6) __________ ago
Action already taken: has taken painkillers and applied ice
Other information
Sports played: belongs to a (7) __________ club; goes (8) __________ regularly
Medical history: injured her (9) __________ last year; no allergies; no regular medication apart from (10) __________
```

[Original question page](assets/dd45a39c411702357d5040b2c0a2e840f26d84c243b485c738a9a9b7f5f77e9d.jpg)

### Part 2

<!-- Source: /api/assets/25c263025c1f738fb31c2d8a97f47a4b243b593b8aa203a92425eb75d370f7b2.jpg; PDF page 33; full -->

```text
SECTION 2 Questions 11-20
Questions 11-15
Choose the correct letter, A, B or C.





Visit to Branley Castle
11 Before Queen Elizabeth I visited the castle in 1576,
A repairs were carried out to the guest rooms.
B a new building was constructed for her.
C a fire damaged part of the main hall.
12 In 1982, the castle was sold to
A  the government.
B  the Fenys family.
C an entertainment company.
13 In some of the rooms, visitors can
A  speak to experts on the history of the castle.
B interact with actors dressed as famous characters.
C see models of historical figures moving and talking.
14 In the castle park, visitors can
A see an 800-year-old tree.
B go to an art exhibition.
C visit a small zoo.
15 At the end of the visit, the group will have
A  afternoon tea in the conservatory.
B _ the chance to meet the castle’s owners.
C a photograph together on the Great Staircase.
Listening
33
```

[Original question page](assets/25c263025c1f738fb31c2d8a97f47a4b243b593b8aa203a92425eb75d370f7b2.jpg)

<!-- Source: /api/assets/055733797fa805e5f500e3d693c11f1276510dc10632f7b318a272cf3f2990a5.jpg; PDF page 34; full -->

```text
Questions 16–20
Label the plan below. Write the correct letter, A–H, next to Questions 16–20.
Branley Castle
[Original plan retained: compass, River, North gate, South gate, Great Hall, Tower, Walls, Main entrance and locations A–H.]
16 Starting point for walking the walls __________
17 Bow and arrow display __________
18 Hunting birds display __________
19 Traditional dancing __________
20 Shop __________
```

[Original question page](assets/055733797fa805e5f500e3d693c11f1276510dc10632f7b318a272cf3f2990a5.jpg)

![Original figure](assets/055733797fa805e5f500e3d693c11f1276510dc10632f7b318a272cf3f2990a5.jpg)

### Part 3

<!-- Source: /api/assets/01db55c01728e8ba9dc847f89143d5d430998e49a87397649f79a85c63ad3ede.jpg; PDF page 35; full -->

```text
Listening
SECTION 3 Questions 21-30
Questions 21-24
Choose the correct letter, A, B or C.




Woolly mammoths on St Paul’s Island
21 How will Rosie and Martin introduce their presentation?
A with a drawing of woolly mammoths in their natural habitat
B  with a timeline showing when woolly mammoths lived
C  with a video clip about woolly mammoths
22 What was surprising about the mammoth tooth found by Russell Graham?
A It was still embedded in the mammoth’s jawbone.
B It was from an unknown species of mammoth.
C  It was not as old as mammoth remains from elsewhere.
23 The students will use an animated diagram to demonstrate how the mammoths
A  became isolated on the island.
B spread from the island to other areas.
C coexisted with other animals on the island.
24 According to Martin, what is unusual about the date of the mammoths’ extinction on
the island?
A how exact it is
B how early it is
C how it was established
35
```

[Original question page](assets/01db55c01728e8ba9dc847f89143d5d430998e49a87397649f79a85c63ad3ede.jpg)

<!-- Source: /api/assets/d5f03d4e76168d64152f2f2a22c15373fc4f84458cf97cb18d156bc18a839060.jpg; PDF page 36; full -->

```text
Test 2
Questions 25-30
What action will the students take for each of the following sections of their
presentation?
Choose SIX answers from the box and write the correct letter, A-H, next to
Questions 25-30.
Actions
A make it more interactive
B reduce visual input
C add personal opinions
D contact one of the researchers
E make detailed notes
F find information online
G check timing
H organise the content more clearly
Sections of presentation
25 Introduction
26 Discovery of the mammoth tooth
27 Initial questions asked by the researchers
28 Further research carried out on the island
29 Findings and possible explanations
30 Relevance to the present day
36
```

[Original question page](assets/d5f03d4e76168d64152f2f2a22c15373fc4f84458cf97cb18d156bc18a839060.jpg)

### Part 4

<!-- Source: /api/assets/33801c6aff6be94b8d6a51486ef06e842d7e148f2ccfdb128b85fcd1bf29d980.jpg; PDF page 37; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
The history of weather forecasting
Ancient cultures
• many cultures believed that floods and other disasters were involved in the creation of the world
• many cultures invented (31) __________ and other ceremonies to make the weather gods friendly
• people needed to observe and interpret the sky to ensure their (32) __________
• around 650 BC, Babylonians started forecasting, using weather phenomena such as (33) __________
• by 300 BC, the Chinese had a calendar made up of a number of (34) __________ connected with the weather
Ancient Greeks
• a more scientific approach
• Aristotle tried to explain the formation of various weather phenomena
• Aristotle also described haloes and (35) __________
Middle Ages
• Aristotle’s work considered accurate
• many proverbs, e.g. about the significance of the colour of the (36) __________, passed on accurate information.
15th–19th centuries
• 15th century: scientists recognised value of (37) __________ for the first time
• Galileo invented the (38) __________
• Pascal showed relationship between atmospheric pressure and altitude
• from the 17th century, scientists could measure atmospheric pressure and temperature
• 18th century: Franklin identified the movement of (39) __________
• 19th century: data from different locations could be sent to the same place by (40) __________
```

[Original question page](assets/33801c6aff6be94b8d6a51486ef06e842d7e148f2ccfdb128b85fcd1bf29d980.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/eac9feaba7b313d19dfe4501c387ce75c7d7b9cc26557bfd4da4af9cbbde6664.jpg; PDF page 38; full -->

```text
Test 2
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Alexander Henderson (1831-1913)
Born in Scotland, Henderson emigrated to Canada in 1855 and became a
well-known landscape photographer
Alexander Henderson was born in Scotland in 1831 and was the son of a successful merchant.
His grandfather, also called Alexander, had founded the family business, and later became
the first chairman of the National Bank of Scotland. The family had extensive landholdings in
Scotland. Besides its residence in Edinburgh, it owned Press Estate, 650 acres of farmland about
35 miles southeast of the city. The family often stayed at Press Castle, the large mansion on the
northern edge of the property, and Alexander spent much of his childhood in the area, playing on
the beach near Eyemouth or fishing in the streams nearby.
Even after he went to school at Murcheston Academy on the outskirts of Edinburgh, Henderson
returned to Press at weekends. In 1849 he began a three-year apprenticeship to become an
accountant. Although he never liked the prospect of a business career, he stayed with it to
please his family. In October 1855, however, he emigrated to Canada with his wife Agnes Elder
Robertson and they settled in Montreal.
Henderson learned photography in Montreal around the year 1857 and quickly took it up
as a serious amateur. He became a personal friend and colleague of the Scottish-Canadian
photographer William Notman. The two men made a photographic excursion to Niagara Falls in
1860 and they cooperated on experiments with magnesium flares as a source of artificial light
in 1865. They belonged to the same societies and were among the founding members of the Art
Association of Montreal. Henderson acted as chairman of the association’s first meeting, which
was held in Notman’s studio on 11 January 1860.
In spite of their friendship, their styles of photography were quite different. While Notman’s
landscapes were noted for their bold realism, Henderson for the first 20 years of his career
produced romantic images, showing the strong influence of the British landscape tradition. His
artistic and technical progress was rapid and in 1865 he published his first major collection of
landscape photographs. The publication had limited circulation (only seven copies have ever been
found), and was called Canadian Views and Studies. The contents of each copy vary significantly
and have proved a useful source for evaluating Henderson’s early work.
This text is taken, for the most part, verbatim from the Dictionary of Canadian Biography Volume XIV (1911-1920). For design purposes,
quotation marks have been omitted. Source: http://www.biographi.ca/en/bio/henderson_alexander_1831_1913_14E.html. Reproduced
with permission.
38
```

[Original question page](assets/eac9feaba7b313d19dfe4501c387ce75c7d7b9cc26557bfd4da4af9cbbde6664.jpg)

<!-- Source: /api/assets/f3943c2d3aa68178688bad519c9038c705bac2f35507b58314a0778cbcdfc67b.jpg; PDF page 39; full -->

```text
Reading
In 1866, he gave up his business to open a photographic studio, advertising himself as a portrait
and landscape photographer. From about 1870 he dropped portraiture to specialize in landscape
photography and other views. His numerous photographs of city life revealed in street scenes,
houses, and markets are alive with human activity, and although his favourite subject was
landscape he usually composed his scenes around such human pursuits as farming the land,
cutting ice on a river, or sailing down a woodland stream. There was sufficient demand for these
types of scenes and others he took depicting the lumber trade, steamboats and waterfalls to enable
him to make a living. There was little competing hobby or amateur photography before the late
1880s because of the time-consuming techniques involved and the weight of the equipment.
People wanted to buy photographs as souvenirs of a trip or as gifts, and catering to this market,
Henderson had stock photographs on display at his studio for mounting, framing, or inclusion
in albums.
Henderson frequently exhibited his photographs in Montreal and abroad, in London, Edinburgh,
Dublin, Paris, New York, and Philadelphia. He met with greater success in 1877 and 1878 in
New York when he won first prizes in the exhibition held by E and HT Anthony and Company
for landscapes using the Lambertype process. In 1878 his work won second prize at the world
exhibition in Paris.
In the 1870s and 1880s Henderson travelled widely throughout Quebec and Ontario, in Canada,
documenting the major cities of the two provinces and many of the villages in Quebec. He was
especially fond of the wilderness and often travelled by canoe on the Blanche, du Liévre, and
other noted eastern rivers. He went on several occasions to the Maritimes and in 1872 he sailed
by yacht along the lower north shore of the St Lawrence River. That same year, while in the lower
St Lawrence River region, he took some photographs of the construction of the Intercolonial
Railway. This undertaking led in 1875 to a commission from the railway to record the principal
structures along the almost-completed line connecting Montreal to Halifax. Commissions from
other railways followed. In 1876 he photographed bridges on the Quebec, Montreal, Ottawa and
Occidental Railway between Montreal and Ottawa. In 1885 he went west along the Canadian
Pacific Railway (CPR) as far as Rogers Pass in British Columbia, where he took photographs of
the mountains and the progress of construction.
In 1892 Henderson accepted a full-time position with the CPR as manager of a photographic
department which he was to set up and administer. His duties included spending four months
in the field each year. That summer he made his second trip west, photographing extensively
along the railway line as far as Victoria. He continued in this post until 1897, when he retired
completely from photography.
When Henderson died in 1913, his huge collection of glass negatives was stored in the basement
of his house. Today collections of his work are held at the National Archives of Canada, Ottawa,
and the McCord Museum of Canadian History, Montreal.
This text is taken, for the most part, verbatim from the Dictionary of Canadian Biography Volume XIV (1911-1920). For design purposes,
quotation marks have been omitted. Source: http://www.biographi.ca/en/bio/henderson_alexander_1831_1913_14E.html. Reproduced
with permission.
39
```

[Original question page](assets/f3943c2d3aa68178688bad519c9038c705bac2f35507b58314a0778cbcdfc67b.jpg)

<!-- Source: /api/assets/e03c6aa31d46a265ef2207e819ac1d6864fcb4fccddbe8cfd648073b12e80e44.jpg; PDF page 40; full -->

```text
Questions 1–8
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1–8 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 Henderson rarely visited the area around Press estate when he was younger.
2 Henderson pursued a business career because it was what his family wanted.
3 Henderson and Notman were surprised by the results of their 1865 experiment.
4 There were many similarities between Henderson’s early landscapes and those of Notman.
5 The studio that Henderson opened in 1866 was close to his home.
6 Henderson gave up portraiture so that he could focus on taking photographs of scenery.
7 When Henderson began work for the Intercolonial Railway, the Montreal to Halifax line had been finished.
8 Henderson’s last work as a photographer was with the Canadian Pacific Railway.
```

[Original question page](assets/e03c6aa31d46a265ef2207e819ac1d6864fcb4fccddbe8cfd648073b12e80e44.jpg)

<!-- Source: /api/assets/36e0017c1b8d2c1a3811a2b0c31db5693f02760b026dd07c223920253f8fd75b.jpg; PDF page 41; full -->

```text
Questions 9–13
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 9–13 on your answer sheet.
Alexander Henderson
Early life
• was born in Scotland in 1831 — father was a (9) __________
• trained as an accountant, emigrated to Canada in 1855
Start of a photographic career
• opened up a photographic studio in 1866
• took photos of city life, but preferred landscape photography
• people bought Henderson’s photos because photography took up considerable time and the (10) __________ was heavy
• the photographs Henderson sold were (11) __________ or souvenirs
Travelling as a professional photographer
• travelled widely in Quebec and Ontario in 1870s and 1880s
• took many trips along eastern rivers in a (12) __________
• worked for Canadian railways between 1875 and 1897
• worked for CPR in 1885 and photographed the (13) __________ and the railway at Rogers Pass
```

[Original question page](assets/36e0017c1b8d2c1a3811a2b0c31db5693f02760b026dd07c223920253f8fd75b.jpg)

<!-- Source: /api/assets/2469390b6029248183b380fa7e7287d986d6d541d866c2aa6d8492c4cf3c47cc.jpg; PDF page 42; full -->

```text
Test 2
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Back to the future of skyscraper design
Answers to the problem of excessive electricity use by skyscrapers
and large public buildings can be found in ingenious but forgotten
architectural designs of the 19th and early-20th centuries
A The Recovery of Natural Environments in Architecture by Professor Alan Short is
the culmination of 30 years of research and award-winning green building design
by Short and colleagues in Architecture, Engineering, Applied Maths and Earth
Sciences at the University of Cambridge.
‘The crisis in building design is already here,’ said Short. ‘Policy makers think
you can solve energy and building problems with gadgets. You can't. As global
temperatures continue to rise, we are going to continue to squander more and more
energy on keeping our buildings mechanically cool until we have run out of capacity.’
B Short is calling for a sweeping reinvention of how skyscrapers and major public
buildings are designed — to end the reliance on sealed buildings which exist solely
via the ‘life support’ system of vast air conditioning units.
Instead, he shows it is entirely possible to accommodate natural ventilation
and cooling in large buildings by looking into the past, before the widespread
introduction of air conditioning systems, which were ‘relentlessly and aggressively
marketed’ by their inventors.
C Short points out that to make most contemporary buildings habitable, they have
to be sealed and air conditioned. The energy use and carbon emissions this
generates is spectacular and largely unnecessary. Buildings in the West account for
40-50% of electricity usage, generating substantial carbon emissions, and the rest
of the world is catching up at a frightening rate. Short regards glass, steel and
air-conditioned skyscrapers as symbols of status, rather than practical ways of
meeting our requirements.
D Short’s book highlights a developing and sophisticated art and science of ventilating
buildings through the 19th and earlier-20th centuries, including the design of
ingeniously ventilated hospitals. Of particular interest were those built to the
designs of John Shaw Billings, including the first Johns Hopkins Hospital in the US
city of Baltimore (1873-1889).
‘We spent three years digitally modelling Billings’ final designs,’ says Short. ‘We
put pathogens* in the airstreams, modelled for someone with tuberculosis (TB)
coughing in the wards and we found the ventilation systems in the room would
have kept other patients safe from harm.’
* pathogens: microorganisms that can cause disease
```

[Original question page](assets/2469390b6029248183b380fa7e7287d986d6d541d866c2aa6d8492c4cf3c47cc.jpg)

<!-- Source: /api/assets/7c46bce320c45a5fb2fa5ffe0aea807f0d4e8966e5b5e917cefe3504f9647400.jpg; PDF page 43; full -->

```text
E ‘We discovered that 19th-century hospital wards could generate up to 24 air changes
an hour — that's similar to the performance of a modern-day, computer-controlled
operating theatre. We believe you could build wards based on these principles now.
Single rooms are not appropriate for all patients. Communal wards appropriate for
certain patients — older people with dementia, for example — would work just as well
in today’s hospitals, at a fraction of the energy cost.’
Professor Short contends the mindset and skill-sets behind these designs have
been completely lost, lamenting the disappearance of expertly designed theatres,
opera houses, and other buildings where up to half the volume of the building was
given over to ensuring everyone got fresh air.
F Much of the ingenuity present in 19th-century hospital and building design was
driven by a panicked public clamouring for buildings that could protect against
what was thought to be the lethal threat of miasmas — toxic air that spread disease.
Miasmas were feared as the principal agents of disease and epidemics for
centuries, and were used to explain the spread of infection from the Middle Ages
right through to the cholera outbreaks in London and Paris during the 1850s. Foul
air, rather than germs, was believed to be the main driver of ‘hospital fever’, leading
to disease and frequent death. The prosperous steered clear of hospitals.
While miasma theory has been long since disproved, Short has for the last 30 years
advocated a return to some of the building design principles produced in its wake.
G Today, huge amounts of a building’s space and construction cost are given over to
air conditioning. ‘But I have designed and built a series of buildings over the past
three decades which have tried to reinvent some of these ideas and then measure
what happens.’
‘To go forward into our new low-energy, low-carbon future, we would be well
advised to look back at design before our high-energy, high-carbon present
appeared. What is surprising is what a rich legacy we have abandoned.’
H Successful examples of Short’s approach include the Queen’s Building at De
Montfort University in Leicester. Containing as many as 2,000 staff and students,
the entire building is naturally ventilated, passively cooled and naturally lit, including
the two largest auditoria, each seating more than 150 people. The award-winning
building uses a fraction of the electricity of comparable buildings in the UK.
Short contends that glass skyscrapers in London and around the world will become
a liability over the next 20 or 30 years if climate modelling predictions and energy
price rises come to pass as expected.
I He is convinced that sufficiently cooled skyscrapers using the natural environment
can be produced in almost any climate. He and his team have worked on hybrid
buildings in the harsh climates of Beijing and Chicago — built with natural ventilation
assisted by back-up air conditioning — which, surprisingly perhaps, can be switched
off more than half the time on milder days and during the spring and autumn.
Short looks at how we might reimagine the cities, offices and homes of the future.
Maybe it’s time we changed our outlook.
```

[Original question page](assets/7c46bce320c45a5fb2fa5ffe0aea807f0d4e8966e5b5e917cefe3504f9647400.jpg)

<!-- Source: /api/assets/2574503039b413421c5312a997681fef95d46d14cc27cad5f62c6e75be09b224.jpg; PDF page 44; full -->

```text
Test 2
Questions 14-18
Reading Passage 2 has nine sections, A–I.
Which section contains the following information?
Write the correct letter, A-I, in boxes 14-18 on your answer sheet.
14 why some people avoided hospitals in the 19th century
15 a suggestion that the popularity of tall buildings is linked to prestige
16 a comparison between the circulation of air in a 19th-century building and modern
standards
17 how Short tested the circulation of air in a 19th-century building
18 an implication that advertising led to the large increase in the use of air conditioning
44
```

[Original question page](assets/2574503039b413421c5312a997681fef95d46d14cc27cad5f62c6e75be09b224.jpg)

<!-- Source: /api/assets/929c28703aa94cd96ff5fe1307c4608fe6e0f60b3245d270553aaaded8ec226c.jpg; PDF page 45; full -->

```text
Questions 19–26
Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 19–26 on your answer sheet.
Ventilation in 19th-century hospital wards
Professor Alan Short examined the work of John Shaw Billings, who influenced the architectural (19) __________ of hospitals to ensure they had good ventilation. He calculated that (20) __________ in the air coming from patients suffering from (21) __________ would not have harmed other patients. He also found that the air in (22) __________ in hospitals could change as often as in a modern operating theatre. He suggests that energy use could be reduced by locating more patients in (23) __________ areas.
A major reason for improving ventilation in 19th-century hospitals was the demand from the (24) __________ for protection against bad air, known as (25) __________. These were blamed for the spread of disease for hundreds of years, including epidemics of (26) __________ in London and Paris in the middle of the 19th century.
```

[Original question page](assets/929c28703aa94cd96ff5fe1307c4608fe6e0f60b3245d270553aaaded8ec226c.jpg)

<!-- Source: /api/assets/c2e6ef8aaccf79eee2b28585beee18abf1194e938a01dc9dcf5f1bca4c5791d5.jpg; PDF page 46; full -->

```text
Test 2
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 on pages 47 and 48.
Questions 27-34
Reading Passage 3 has eight sections, A-H.
Choose the correct heading for each section from the list of headings below.
Write the correct number, i-ix, in boxes 27-34 on your answer sheet.
List of Headings
i Complaints about the impact of a certain approach
ii Fundamental beliefs that are in fact incorrect
iii Early recommendations concerning business activities
iv Organisations that put a new approach into practice
v Companies that have suffered from changing their approach
vi What people are increasingly expected to do
vii How to achieve outcomes that are currently impossible
viii Neither approach guarantees continuous improvement
ix Evidence that a certain approach can have more
disadvantages than advantages
27 Section A
28 Section B
29 Section C
30 Section D
31 Section E
32 Section F
33 Section G
34 Section H
46
```

[Original question page](assets/c2e6ef8aaccf79eee2b28585beee18abf1194e938a01dc9dcf5f1bca4c5791d5.jpg)

<!-- Source: /api/assets/31618068d8a3ec0069fa8ccdc98d74bdce9725d45f4a46977fa6035fbe29125f.jpg; PDF page 47; full -->

```text
Reading
Why companies should welcome disorder
A Organisation is big business. Whether it is of our lives — all those inboxes and calendars —
or how companies are structured, a multi-billion dollar industry helps to meet this need.
We have more strategies for time management, project management and
self-organisation than at any other time in human history. We are told that we ought to
organise our company, our home life, our week, our day and even our sleep, all as a means
to becoming more productive. Every week, countless seminars and workshops take place
around the world to tell a paying public that they ought to structure their lives in order to
achieve this.
This rhetoric has also crept into the thinking of business leaders and entrepreneurs, much
to the delight of self-proclaimed perfectionists with the need to get everything right. The
number of business schools and graduates has massively increased over the past 50 years,
essentially teaching people how to organise well.
B Ironically, however, the number of businesses that fail has also steadily increased.
Work-related stress has increased. A large proportion of workers from all demographics
claim to be dissatisfied with the way their work is structured and the way they are managed.
This begs the question: what has gone wrong? Why is it that on paper the drive for
organisation seems a sure shot for increasing productivity, but in reality falls well short of
what is expected?
C This has been a problem for a while now. Frederick Taylor was one of the forefathers of
scientific management. Writing in the first half of the 20th century, he designed a number
of principles to improve the efficiency of the work process, which have since become
widespread in modern companies. So the approach has been around for a while.
D New research suggests that this obsession with efficiency is misguided. The problem is not
necessarily the management theories or strategies we use to organise our work; it’s the basic
assumptions we hold in approaching how we work. Here it’s the assumption that order is a
necessary condition for productivity. This assumption has also fostered the idea that disorder
must be detrimental to organisational productivity. The result is that businesses and people
spend time and money organising themselves for the sake of organising, rather than actually
looking at the end goal and usefulness of such an effort.
E  What’s more, recent studies show that order actually has diminishing returns. Order does
increase productivity to a certain extent, but eventually the usefulness of the process of
organisation, and the benefit it yields, reduce until the point where any further increase in
order reduces productivity. Some argue that in a business, if the cost of formally structuring
something outweighs the benefit of doing it, then that thing ought not to be formally
structured. Instead, the resources involved can be better used elsewhere.
47
```

[Original question page](assets/31618068d8a3ec0069fa8ccdc98d74bdce9725d45f4a46977fa6035fbe29125f.jpg)

<!-- Source: /api/assets/8a9dd41224321e7a5857540c81d57c2e27362b834a22491533cd834e3aa9bde9.jpg; PDF page 48; full -->

```text
Test 2
F In fact, research shows that, when innovating, the best approach is to create an environment
devoid of structure and hierarchy and enable everyone involved to engage as one organic
group. These environments can lead to new solutions that, under conventionally structured
environments (filled with bottlenecks in terms of information flow, power structures, rules,
and routines) would never be reached.
G In recent times companies have slowly started to embrace this disorganisation. Many of
them embrace it in terms of perception (embracing the idea of disorder, as opposed to
fearing it) and in terms of process (putting mechanisms in place to reduce structure).
For example, Oticon, a large Danish manufacturer of hearing aids, used what it called a
‘spaghetti’ structure in order to reduce the organisation’s rigid hierarchies. This involved
scrapping formal job titles and giving staff huge amounts of ownership over their own time
and projects. This approach proved to be highly successful initially, with clear improvements
in worker productivity in all facets of the business.
In similar fashion, the former chairman of General Electric embraced disorganisation,
putting forward the idea of the ‘boundaryless’ organisation. Again, it involves breaking
down the barriers between different parts of a company and encouraging virtual
collaboration and flexible working. Google and a number of other tech companies have
embraced (at least in part) these kinds of flexible structures, facilitated by technology and
strong company values which glue people together.
H A word of warning to others thinking of jumping on this bandwagon: the evidence so far
suggests disorder, much like order, also seems to have diminishing utility, and can also have
detrimental effects on performance if overused. Like order, disorder should be embraced
only so far as it is useful. But we should not fear it — nor venerate one over the other.
This research also shows that we should continually question whether or not our existing
assumptions work.
```

[Original question page](assets/8a9dd41224321e7a5857540c81d57c2e27362b834a22491533cd834e3aa9bde9.jpg)

<!-- Source: /api/assets/e2dd82cef4e15e07e2e304235250898abbfac19e6e51bb3876ec93c12b191518.jpg; PDF page 49; full -->

```text
Reading
Questions 35-37
Complete the sentences below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 35-37 on your answer sheet.
35 Numerous training sessions are aimed at people who feel they are not __________ enough.
36 Being organised appeals to people who regard themselves as __________.
37 Many people feel __________ with aspects of their work.
Questions 38-40
Do the following statements agree with the information given in Reading Passage 3?
In boxes 38-40 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN _ if there is no information on this
38 Both businesses and people aim at order without really considering its value.
39 Innovation is most successful if the people involved have distinct roles.
40 Google was inspired to adopt flexibility by the success of General Electric.
49
```

[Original question page](assets/e2dd82cef4e15e07e2e304235250898abbfac19e6e51bb3876ec93c12b191518.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/cf30a8530d631068c3f44a2652957a48fd211594dcd10af7629375dafcb7fd40.jpg; PDF page 50; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows the value of one country’s exports in various categories during 2015 and 2016. The table shows the percentage change in each category of exports in 2016 compared with 2015.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/cf30a8530d631068c3f44a2652957a48fd211594dcd10af7629375dafcb7fd40.jpg)

![Original figure](assets/cf30a8530d631068c3f44a2652957a48fd211594dcd10af7629375dafcb7fd40.jpg)

### Task 2

<!-- Source: /api/assets/e278121742c34ddfde1b55a6aae415f95523cfd0d3a61d7bfa75194c978fb965.jpg; PDF page 51; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people say that the main environmental problem of our time is the loss of particular species of plants and animals. Others say that there are more important environmental problems.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/e278121742c34ddfde1b55a6aae415f95523cfd0d3a61d7bfa75194c978fb965.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/59bfac0569d273561e11975fd03a502c910b7e5e3c668a1b704b4e73a6ea5fa4.jpg; PDF page 52; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Social media
* Which social media websites do you use?
* How much time do you spend on social media sites? [Why/Why not?]
¢ What kind of information about yourself have you put on social media? [Why/Why not?]
* Is there anything you don’t like about social media? [Why?]
PART 2
Describe something you liked very much which you bought for your home.
You should say:
what you bought
when and where you bought it
why you chose this particular thing
and explain why you liked it so much.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Creating a nice home
Example questions:
Why do some people buy lots of things for their home?
Do you think it is very expensive to make a home look nice?
Why don’t some people care about how their home looks?
Different types of home
Example questions:
In what ways is living in a flat/apartment better than living in a house?
Do you think homes will look different in the future?
Do you agree that the kinds of homes people prefer change as they get older?
52
```

[Original question page](assets/59bfac0569d273561e11975fd03a502c910b7e5e3c668a1b704b4e73a6ea5fa4.jpg)

### Part 2

<!-- Source: /api/assets/59bfac0569d273561e11975fd03a502c910b7e5e3c668a1b704b4e73a6ea5fa4.jpg; PDF page 52; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Social media
* Which social media websites do you use?
* How much time do you spend on social media sites? [Why/Why not?]
¢ What kind of information about yourself have you put on social media? [Why/Why not?]
* Is there anything you don’t like about social media? [Why?]
PART 2
Describe something you liked very much which you bought for your home.
You should say:
what you bought
when and where you bought it
why you chose this particular thing
and explain why you liked it so much.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Creating a nice home
Example questions:
Why do some people buy lots of things for their home?
Do you think it is very expensive to make a home look nice?
Why don’t some people care about how their home looks?
Different types of home
Example questions:
In what ways is living in a flat/apartment better than living in a house?
Do you think homes will look different in the future?
Do you agree that the kinds of homes people prefer change as they get older?
52
```

[Original question page](assets/59bfac0569d273561e11975fd03a502c910b7e5e3c668a1b704b4e73a6ea5fa4.jpg)

### Part 3

<!-- Source: /api/assets/59bfac0569d273561e11975fd03a502c910b7e5e3c668a1b704b4e73a6ea5fa4.jpg; PDF page 52; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Social media
* Which social media websites do you use?
* How much time do you spend on social media sites? [Why/Why not?]
¢ What kind of information about yourself have you put on social media? [Why/Why not?]
* Is there anything you don’t like about social media? [Why?]
PART 2
Describe something you liked very much which you bought for your home.
You should say:
what you bought
when and where you bought it
why you chose this particular thing
and explain why you liked it so much.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Creating a nice home
Example questions:
Why do some people buy lots of things for their home?
Do you think it is very expensive to make a home look nice?
Why don’t some people care about how their home looks?
Different types of home
Example questions:
In what ways is living in a flat/apartment better than living in a house?
Do you think homes will look different in the future?
Do you agree that the kinds of homes people prefer change as they get older?
52
```

[Original question page](assets/59bfac0569d273561e11975fd03a502c910b7e5e3c668a1b704b4e73a6ea5fa4.jpg)
