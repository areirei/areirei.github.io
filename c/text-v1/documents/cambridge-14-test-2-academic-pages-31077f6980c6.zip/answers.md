# 剑雅 14 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 121

TEST 2 LISTENING
1 219 442 9785
2 10(th) October
3 manager
4 Cawley
5 knee
6 3 weeks
7 tennis
8 running
9 shoulder
10 vitamins
11 B
12 C
13 C
14 B
15 A
16 H
17 D
18 F
19 A
20 E
21 B
22 C
23 A
24 A
25 E
26 D
27 A
28 H
29 G
30 C
31 dances
32 survival
33 clouds
34 festivals
35 comets
36 sky
37 instruments
38 thermometer
39 storms
40 telegraph
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. 219 442 9785 / 2194429785

2. 10 October / 10th October

3. manager

4. Cawley

5. knee

6. 3 weeks

7. tennis

8. running

9. shoulder

10. vitamins

### Part 2 · source page 121

TEST 2 LISTENING
1 219 442 9785
2 10(th) October
3 manager
4 Cawley
5 knee
6 3 weeks
7 tennis
8 running
9 shoulder
10 vitamins
11 B
12 C
13 C
14 B
15 A
16 H
17 D
18 F
19 A
20 E
21 B
22 C
23 A
24 A
25 E
26 D
27 A
28 H
29 G
30 C
31 dances
32 survival
33 clouds
34 festivals
35 comets
36 sky
37 instruments
38 thermometer
39 storms
40 telegraph
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B

12. C

13. C

14. B

15. A

16. H

17. D

18. F

19. A

20. E

### Part 3 · source page 121

TEST 2 LISTENING
1 219 442 9785
2 10(th) October
3 manager
4 Cawley
5 knee
6 3 weeks
7 tennis
8 running
9 shoulder
10 vitamins
11 B
12 C
13 C
14 B
15 A
16 H
17 D
18 F
19 A
20 E
21 B
22 C
23 A
24 A
25 E
26 D
27 A
28 H
29 G
30 C
31 dances
32 survival
33 clouds
34 festivals
35 comets
36 sky
37 instruments
38 thermometer
39 storms
40 telegraph
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B

22. C

23. A

24. A

25. E

26. D

27. A

28. H

29. G

30. C

### Part 4 · source page 121

TEST 2 LISTENING
1 219 442 9785
2 10(th) October
3 manager
4 Cawley
5 knee
6 3 weeks
7 tennis
8 running
9 shoulder
10 vitamins
11 B
12 C
13 C
14 B
15 A
16 H
17 D
18 F
19 A
20 E
21 B
22 C
23 A
24 A
25 E
26 D
27 A
28 H
29 G
30 C
31 dances
32 survival
33 clouds
34 festivals
35 comets
36 sky
37 instruments
38 thermometer
39 storms
40 telegraph
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. dances

32. survival

33. clouds

34. festivals

35. comets

36. sky

37. instruments

38. thermometer

39. storms

40. telegraph

## A 类阅读

### Academic Reading · source page 122

TEST 2 READING
1 FALSE
2 TRUE
3 NOT GIVEN
4 FALSE
5 NOT GIVEN
6 TRUE
7 FALSE
8 TRUE
9 merchant
10 equipment
11 gifts
12 canoe
13 mountains
14 F
15 C
16 E
17 D
18 B
19 design(s)
20 pathogens
21 tuberculosis
22 wards
23 communal
24 public
25 miasmas
26 cholera
27 vi
28 i
29 iii
30 ii
31 ix
32 vii
33 iv
34 viii
35 productive
36 perfectionists
37 dissatisfied
38 TRUE
39 FALSE
40 NOT GIVEN
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. FALSE

2. TRUE

3. NOT GIVEN

4. FALSE

5. NOT GIVEN

6. TRUE

7. FALSE

8. TRUE

9. merchant

10. equipment

11. gifts

12. canoe

13. mountains

14. F

15. C

16. E

17. D

18. B

19. design / designs

20. pathogens

21. tuberculosis

22. wards

23. communal

24. public

25. miasmas

26. cholera

27. vi

28. i

29. iii

30. ii

31. ix

32. vii

33. iv

34. viii

35. productive

36. perfectionists

37. dissatisfied

38. TRUE

39. FALSE

40. NOT GIVEN

## A 类写作

### Writing material: c14-t2-w-1

Bar chart values in $BILLIONS,2015→2016, approximate readings: petroleum products60→62; engineered goods57→62; gems/jewellery43→41; agricultural products31→just above31; textiles26→31. Table gives exact relative changes:+3%,+8.5%,-5.18%,+0.81%,+15.24% in same category order. Petroleum and engineered goods highest, textiles lowest initially and fastest proportional growth; gems/jewellery only decline. Agricultural change smallest positive. Do not call table changes billions or percentage points, infer country name, or treat bar approximations as exact data.



### Writing material: c14-t2-w-2

Discuss species loss as the main problem and the view that other environmental problems are more important, with own opinion. Preserve comparison of priorities; species loss is not claimed unimportant by the second view.



## 口语
