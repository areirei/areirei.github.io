# 剑雅 11 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 123

TEST 1 LISTENING
1 Charlton
2 (£)115 / a/one hundred (and) fifteen
3 cash
4 parking
5 music
6 entry
7 stage
8 code
9 floor/floors
10 decoration/decorations
11 animal/animals
12 tool/tools
13 shoes
14 dog/dogs
15 F
16 G
17 D
18 H
19 C
20 A
21 C
22 B
23 B
24 C
25 A
26 B
27 C
28 A
29 B
30 A
31 conservation
32 food/foods
33 surface
34 oxygen/O2
35 mammals
36 ice
37 decline/declining/decrease
38 map
39 migration
40 consumption
If you score: 0–14: unlikely; 15–28: may; 29–40: likely to get an acceptable score under examination conditions. Improve English or consider more practice/lessons before IELTS; institutions accept different scores.

1. Charlton

2. 115 / £ 115 / £115 / a hundred fifteen / a hundred and fifteen / one hundred fifteen / one hundred and fifteen

3. cash

4. parking

5. music

6. entry

7. stage

8. code

9. floor / floors

10. decoration / decorations

### Part 2 · source page 123

TEST 1 LISTENING
1 Charlton
2 (£)115 / a/one hundred (and) fifteen
3 cash
4 parking
5 music
6 entry
7 stage
8 code
9 floor/floors
10 decoration/decorations
11 animal/animals
12 tool/tools
13 shoes
14 dog/dogs
15 F
16 G
17 D
18 H
19 C
20 A
21 C
22 B
23 B
24 C
25 A
26 B
27 C
28 A
29 B
30 A
31 conservation
32 food/foods
33 surface
34 oxygen/O2
35 mammals
36 ice
37 decline/declining/decrease
38 map
39 migration
40 consumption
If you score: 0–14: unlikely; 15–28: may; 29–40: likely to get an acceptable score under examination conditions. Improve English or consider more practice/lessons before IELTS; institutions accept different scores.

11. animal / animals

12. tool / tools

13. shoes

14. dog / dogs

15. F

16. G

17. D

18. H

19. C

20. A

### Part 3 · source page 123

TEST 1 LISTENING
1 Charlton
2 (£)115 / a/one hundred (and) fifteen
3 cash
4 parking
5 music
6 entry
7 stage
8 code
9 floor/floors
10 decoration/decorations
11 animal/animals
12 tool/tools
13 shoes
14 dog/dogs
15 F
16 G
17 D
18 H
19 C
20 A
21 C
22 B
23 B
24 C
25 A
26 B
27 C
28 A
29 B
30 A
31 conservation
32 food/foods
33 surface
34 oxygen/O2
35 mammals
36 ice
37 decline/declining/decrease
38 map
39 migration
40 consumption
If you score: 0–14: unlikely; 15–28: may; 29–40: likely to get an acceptable score under examination conditions. Improve English or consider more practice/lessons before IELTS; institutions accept different scores.

21. C

22. B

23. B

24. C

25. A

26. B

27. C

28. A

29. B

30. A

### Part 4 · source page 123

TEST 1 LISTENING
1 Charlton
2 (£)115 / a/one hundred (and) fifteen
3 cash
4 parking
5 music
6 entry
7 stage
8 code
9 floor/floors
10 decoration/decorations
11 animal/animals
12 tool/tools
13 shoes
14 dog/dogs
15 F
16 G
17 D
18 H
19 C
20 A
21 C
22 B
23 B
24 C
25 A
26 B
27 C
28 A
29 B
30 A
31 conservation
32 food/foods
33 surface
34 oxygen/O2
35 mammals
36 ice
37 decline/declining/decrease
38 map
39 migration
40 consumption
If you score: 0–14: unlikely; 15–28: may; 29–40: likely to get an acceptable score under examination conditions. Improve English or consider more practice/lessons before IELTS; institutions accept different scores.

31. conservation

32. food / foods

33. surface

34. oxygen / O2

35. mammals

36. ice

37. decline / declining / decrease

38. map

39. migration

40. consumption

## A 类阅读

### Academic Reading · source page 124

TEST 1 READING
1 tomatoes
2 urban centres/centers
3 energy
4 fossil fuel
5 artificial
6 (stacked) trays
7 (urban) rooftops
8 NOT GIVEN
9 TRUE
10 FALSE
11 TRUE
12 FALSE
13 TRUE
14 FALSE
15 NOT GIVEN
16 TRUE
17 NOT GIVEN
18 FALSE
19 TRUE
20 gates
21 clamp
22 axle
23 cogs
24 aqueduct
25 wall
26 locks
27 D
28 B
29 A
30 sunshade
31 iron
32 algae
33 clouds
34 cables
35 snow
36 rivers
37 B
38 D
39 C
40 A
If you score: 0–11: unlikely; 12–24: may; 25–40: likely to get an acceptable score under examination conditions. Improve English or consider more practice/lessons before IELTS; institutions accept different scores.

1. tomatoes

2. urban centres / urban centers

3. energy

4. fossil fuel

5. artificial

6. trays / stacked trays

7. rooftops / urban rooftops

8. NOT GIVEN

9. TRUE

10. FALSE

11. TRUE

12. FALSE

13. TRUE

14. FALSE

15. NOT GIVEN

16. TRUE

17. NOT GIVEN

18. FALSE

19. TRUE

20. gates

21. clamp

22. axle

23. cogs

24. aqueduct

25. wall

26. locks

27. D

28. B

29. A

30. sunshade

31. iron

32. algae

33. clouds

34. cables

35. snow

36. rivers

37. B

38. D

39. C

40. A

## A 类写作

### Writing material: c11-t1-w-1

Industrial/agricultural/domestic shares respectively: North America48/39/13%; South America10/71/19%; Europe53/32/15%; Africa7/84/9%; Central Asia5/88/7%; South East Asia12/81/7%. Legend: white industrial, diagonal agricultural, grey domestic. Agriculture dominates four regions; industry leads Europe and North America. Domestic smaller than agricultural in all, but exceeds industry in South America,Africa,Central Asia. Each regional pie totals100%; no dates or absolute water volumes supplied, so regional percentages do not establish global quantities.



### Writing material: c11-t1-w-2

Evaluate allocating government spending to railways rather than roads. A qualified allocation argument is acceptable; focus on public spending priorities, not merely whether rail travel is pleasant.



## 口语
