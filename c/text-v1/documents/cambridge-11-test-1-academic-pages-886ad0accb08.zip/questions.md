# 剑雅 11 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/03ccdf1692b9b2f5117cb361bad25a92a2ab99caaba8e657e7632d8781664762.jpg; PDF page 9; full -->

```text
SECTION 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
HIRING A PUBLIC ROOM
Example — the Main Hall: seats 200
Room and cost
– the (1) __________ Room — seats 100
– Cost of Main Hall for Saturday evening: (2) £ __________
+ £250 deposit ((3) __________ payment is required)
– Cost includes use of tables and chairs and also (4) __________
– Additional charge for use of the kitchen: £25
Before the event
– Will need a (5) __________ licence
– Need to contact caretaker (Mr Evans) in advance to arrange (6) __________
During the event
– The building is no smoking
– The band should use the (7) __________ door at the back
– Don’t touch the system that controls the volume
– For microphones, contact the caretaker
```

[Original question page](assets/03ccdf1692b9b2f5117cb361bad25a92a2ab99caaba8e657e7632d8781664762.jpg)

<!-- Source: /api/assets/64da6709af8e25e80885186767f33761efea98a79ae61144e8cb04823172337e.jpg; PDF page 10; full -->

```text
After the event
– Need to know the (8) __________ for the cleaning cupboard
– The (9) __________ must be washed and rubbish placed in black bags
– All (10) __________ must be taken down
– Chairs and tables must be piled up
```

[Original question page](assets/64da6709af8e25e80885186767f33761efea98a79ae61144e8cb04823172337e.jpg)

### Part 2

<!-- Source: /api/assets/f382832f9b982aa5d353b442da050e7f48266f71dd72eb71afec819858d1af5f.jpg; PDF page 11; full -->

```text
SECTION 2 Questions 11–20
Questions 11–14
Complete the notes below. Write ONE WORD for each answer.
Fiddy Working Heritage Farm
Advice about visiting the farm
Visitors should
– take care not to harm any (11) __________
– not touch any (12) __________
– wear (13) __________
– not bring (14) __________ into the farm, with certain exceptions
```

[Original question page](assets/f382832f9b982aa5d353b442da050e7f48266f71dd72eb71afec819858d1af5f.jpg)

<!-- Source: /api/assets/b4ebfac82ca16e2139546e0397d0185abec41a8d317022904b1d2667477d2d33.jpg; PDF page 12; full -->

```text
Questions 15–20
Label the map below. Write the correct letter A–I, next to Questions 15–20.
[Original map retained with locations A–I: Road, Footpath, Farm Yard, Main Path, Fish Pool, Side Path, Car Park, New Barn and “You are here”. Refer to the map for positions.]
15 Scarecrow __________
16 Maze __________
17 Café __________
18 Black Barn __________
19 Covered picnic area __________
20 Fiddy House __________
```

[Original question page](assets/b4ebfac82ca16e2139546e0397d0185abec41a8d317022904b1d2667477d2d33.jpg)

![Original figure](assets/b4ebfac82ca16e2139546e0397d0185abec41a8d317022904b1d2667477d2d33.jpg)

### Part 3

<!-- Source: /api/assets/5e6a72a0c9fd4ea1263e6dad41631a336191a00bd308b9da666561f05ab97795.jpg; PDF page 13; full -->

```text
SECTION 3 Questions 21-30
Choose the correct letter, A, B or C.
Study on Gender in Physics
21 The students in Akira Miyake’s study were all majoring in
A physics.
B psychology or physics.
C science, technology, engineering or mathematics.
22 The aim of Miyake’s study was to investigate
A what kind of women choose to study physics.
B a way of improving women’s performance in physics.
C whether fewer women than men study physics at college.
23 The female physics students were wrong to believe that
A the teachers marked them in an unfair way.
B the male students expected them to do badly.
C their test results were lower than the male students'.
24 Miyake’s team asked the students to write about
A what they enjoyed about studying physics.
B the successful experiences of other people.
C something that was important to them personally.
25 What was the aim of the writing exercise done by the subjects?
A to reduce stress
B to strengthen verbal ability
C to encourage logical thinking
26 What surprised the researchers about the study?
A how few students managed to get A grades
B the positive impact it had on physics results for women
C the difference between male and female performance
27 Greg and Lisa think Miyake’s results could have been affected by
14
A the length of the writing task.
B the number of students who took part.
C the information the students were given.
```

[Original question page](assets/5e6a72a0c9fd4ea1263e6dad41631a336191a00bd308b9da666561f05ab97795.jpg)

<!-- Source: /api/assets/9a152e515a9ca881d750504be40392e5835218e5605909128f6bb4299faeb159.jpg; PDF page 14; full -->

```text
28 Greg and Lisa decide that in their own project, they will compare the effects of
A two different writing tasks.
B a writing task with an oral task.
C two different oral tasks.
29 The main finding of Smolinsky’s research was that class teamwork activities
A were most effective when done by all-women groups.
B had no effect on the performance of men or women.
C improved the results of men more than of women.
30 What will Lisa and Greg do next?
A talk to a professor
B observe a science class
C look at the science timetable
15
```

[Original question page](assets/9a152e515a9ca881d750504be40392e5835218e5605909128f6bb4299faeb159.jpg)

### Part 4

<!-- Source: /api/assets/4300e64a0d3d99dbcf7123c2e90005361601fcca8b9e2c3c334a9a3e8b196435.jpg; PDF page 15; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Ocean Biodiversity
Biodiversity hotspots
– areas containing many different species
– important for locating targets for (31) __________
– at first only identified on land
Boris Worm, 2005
– identified hotspots for large ocean predators, e.g. sharks
– found that ocean hotspots:
  – were not always rich in (32) __________
  – had higher temperatures at the (33) __________
  – had sufficient (34) __________ in the water
Lisa Ballance, 2007
– looked for hotspots for marine (35) __________
– found these were all located where ocean currents meet
Census of Marine Life
– found new ocean species living:
  – under the (36) __________
  – near volcanoes on the ocean floor
```

[Original question page](assets/4300e64a0d3d99dbcf7123c2e90005361601fcca8b9e2c3c334a9a3e8b196435.jpg)

<!-- Source: /api/assets/60e411409e7daff4f4e14e88502e50b513a2643e6132b43090b5d525b3ddee81.jpg; PDF page 16; full -->

```text
Global Marine Species Assessment
– want to list endangered ocean species, considering:
  – population size
  – geographical distribution
  – rate of (37) __________
– Aim: to assess 20,000 species and make a distribution (38) __________ for each one
Recommendations to retain ocean biodiversity
– increase the number of ocean reserves
– establish (39) __________ corridors (e.g. for turtles)
– reduce fishing quotas
– catch fish only for the purpose of (40) __________
```

[Original question page](assets/60e411409e7daff4f4e14e88502e50b513a2643e6132b43090b5d525b3ddee81.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/f13d5656e1705cca5c0751ab67f2cf743927be75bf2f16d47734ef5d03c30228.jpg; PDF page 17; full -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Crop-growing skyscrapers
By the year 2050, nearly 80% of
the Earth’s population will live in
urban centres. Applying the most
conservative estimates to current
demographic trends, the human
population will increase by about
three billion people by then. An
estimated 10^9 hectares of new land
(about 20% larger than Brazil) will be
needed to grow enough food to feed
them, if traditional farming methods
continue as they are practised today.
At present, throughout the world,
over 80% of the land that is suitable
for raising crops is in use. Historically,
some 15% of that has been laid waste
by poor management practices. What
can be done to ensure enough food
for the world’s population to live on?
The concept of indoor farming is
not new, since hothouse production
of tomatoes and other produce has
been in vogue for some time. What
is new is the urgent need to scale
up this technology to accommodate
another three billion people. Many
believe an entirely new approach to
indoor farming is required, employing
cutting-edge technologies. One such
proposal is for the ‘Vertical Farm’.
The concept is of multi-storey

buildings in which food crops are
grown in environmentally controlled
conditions. Situated in the heart of
urban centres, they would drastically
reduce the amount of transportation
required to bring food to consumers.
Vertical farms would need to be
efficient, cheap to construct and
safe to operate. If successfully
implemented, proponents claim,
vertical farms offer the promise
of urban renewal, sustainable
production of a safe and varied
food supply (through year-round
production of all crops), and the
eventual repair of ecosystems that
have been sacrificed for horizontal
farming.
It took humans 10,000 years to
learn how to grow most of the crops
we now take for granted. Along the
way, we despoiled most of the land
we worked, often turning verdant,
natural ecozones into semi-arid
deserts. Within that same time frame,
we evolved into an urban species, in
which 60% of the human population
now lives vertically in cities. This
means that, for the majority, we
humans have shelter from the
elements, yet we subject our food-
```

[Original question page](assets/f13d5656e1705cca5c0751ab67f2cf743927be75bf2f16d47734ef5d03c30228.jpg)

<!-- Source: /api/assets/0c7dad77b3afc7460297fdf0eeacce2a2cbd7d3794b9b90999fbb46a4d4bb815.jpg; PDF page 18; full -->

```text
bearing plants to the rigours of the
great outdoors and can do no more
than hope for a good weather year.
However, more often than not now,
due to a rapidly changing climate,
that is not what happens. Massive
floods, long droughts, hurricanes and
severe monsoons take their toll each
year, destroying millions of tons of
valuable crops.
The supporters of vertical farming
claim many potential advantages for
the system. For instance, crops would
be produced all year round, as they
would be kept in artificially controlled,
optimum growing conditions. There
would be no weather-related crop
failures due to droughts, floods or
pests. All the food could be grown
organically, eliminating the need for
herbicides, pesticides and fertilisers.
The system would greatly reduce the
incidence of many infectious diseases
that are acquired at the agricultural
interface. Although the system would
consume energy, it would return
energy to the grid via methane
generation from composting non-
edible parts of plants. It would also
dramatically reduce fossil fuel use,
by cutting out the need for tractors,
ploughs and shipping.
A major drawback of vertical farming,
however, is that the plants would
require artificial light. Without it,
those plants nearest the windows
would be exposed to more sunlight
and grow more quickly, reducing
the efficiency of the system. Single-
storey greenhouses have the benefit
of natural overhead light: even so,
many still need artificial lighting.
A multi-storey facility with no natural
overhead light would require far
more. Generating enough light could
be prohibitively expensive, unless
cheap, renewable energy is available,
and this appears to be rather a future
aspiration than a likelihood for the
near future.
One variation on vertical farming that
has been developed is to grow plants
in stacked trays that move on rails.
Moving the trays allows the plants to
get enough sunlight. This system is
already in operation, and works well
within a single-storey greenhouse
with light reaching it from above: it
is not certain, however, that it can be
made to work without that overhead
natural light.
Vertical farming is an attempt to
address the undoubted problems
that we face in producing enough
food for a growing population. At the
moment, though, more needs to be
done to reduce the detrimental impact
it would have on the environment,
particularly as regards the use of
energy. While it is possible that
much of our food will be grown in
skyscrapers in future, most experts
currently believe it is far more likely
that we will simply use the space
available on urban rooftops.
```

[Original question page](assets/0c7dad77b3afc7460297fdf0eeacce2a2cbd7d3794b9b90999fbb46a4d4bb815.jpg)

<!-- Source: /api/assets/a7044e8329993eabd417ef35b2242a77381d94bca305e9e92a3756eec3e7d3ea.jpg; PDF page 19; full -->

```text
Questions 1-7
Complete the sentences below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 1-7 on your answer sheet.
Indoor farming
1 Some food plants, including ....... .. ..... ... are already grown indoors.
2 Vertical farms would be located in .... … … , meaning that there would be less
need to take them long distances to customers.
3 Vertical farms could use methane from plants and animals to produce ........ .
4 The consumption of ................. .... would be cut because agricultural vehicles would be
unnecessary.
5 The fact that vertical farms would need …............….. light is a disadvantage.
6 One form of vertical farming involves planting in ...................... which are not fixed.
7 The most probable development is that food will be grown on .........… ...... in towns
and cities.
Questions 8-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 8-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
8 Methods for predicting the Earth’s population have recently changed.
9 Human beings are responsible for some of the destruction to food-producing land.
10 The crops produced in vertical farms will depend on the season.
11 Some damage to food crops is caused by climate change.
12 Fertilisers will be needed for certain crops in vertical farms.
13 Vertical farming will make plants less likely to be affected by infectious diseases.
20
```

[Original question page](assets/a7044e8329993eabd417ef35b2242a77381d94bca305e9e92a3756eec3e7d3ea.jpg)

<!-- Source: /api/assets/06db4de1d556d40037921f49d58e1265c21722d8ae561e62581b7295922bb646.jpg; PDF page 20; full -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
THE FALKIRK WHEEL
A unique engineering achievement
The Falkirk Wheel in Scotland is the
world’s first and only rotating boat lift.
Opened in 2002, it is central to the
ambitious £84.5m Millennium Link project
to restore navigability across Scotland by
reconnecting the historic waterways of the
Forth & Clyde and Union Canals.
The major challenge of the project lay in
the fact that the Forth & Clyde Canal is
situated 35 metres below the level of the
Union Canal. Historically, the two canals
had been joined near the town of Falkirk
by a sequence of 11 locks — enclosed
sections of canal in which the water level
could be raised or lowered - that stepped
down across a distance of 1.5 km. This had
been dismantled in 1933, thereby breaking
the link. When the project was launched
in 1994, the British Waterways authority
were keen to create a dramatic twenty-first-
century landmark which would not only be
a fitting commemoration of the Millennium,
but also a lasting symbol of the economic
regeneration of the region.
Numerous ideas were submitted for the
project, including concepts ranging from
rolling eggs to tilting tanks, from giant see-
saws to overhead monorails. The eventual
winner was a plan for the huge rotating
steel boat lift which was to become The
Falkirk Wheel. The unique shape of the
structure is claimed to have been inspired
by various sources, both manmade and
natural, most notably a Celtic double-
headed axe, but also the vast turning
propeller of a ship, the ribcage of a whale
or the spine of a fish.
The various parts of The Falkirk Wheel
were all constructed and assembled, like
one giant toy building set, at Butterley
Engineering's Steelworks in Derbyshire,
some 400 km from Falkirk. A team there
carefully assembled the 1,200 tonnes
of steel, painstakingly fitting the pieces
together to an accuracy of just 10 mm to
ensure a perfect final fit. In the summer of
2001, the structure was then dismantled
and transported on 35 lorries to Falkirk,
before all being bolted back together
again on the ground, and finally lifted into
position in five large sections by crane. The
Wheel would need to withstand immense
and constantly changing stresses as it
rotated, so to make the structure more
robust, the steel sections were bolted
rather than welded together. Over 45,000
bolt holes were matched with their bolts,
and each bolt was hand-tightened.
The Wheel consists of two sets of opposing
axe-shaped arms, attached about 25
metres apart to a fixed central spine.
Two diametrically opposed water-filled
‘gondolas', each with a capacity of 360,000
litres, are fitted between the ends of the
arms. These gondolas always weigh the
same, whether or not they are carrying
boats. This is because, according to
Archimedes’ principle of displacement,
21
```

[Original question page](assets/06db4de1d556d40037921f49d58e1265c21722d8ae561e62581b7295922bb646.jpg)

<!-- Source: /api/assets/0b2d0ed726140578034387ffe66868f8848e2c48e7538a8cb7b9bca18130aa28.jpg; PDF page 21; full -->

```text
floating objects displace their own weight
in water. So when a boat enters a gondola,
the amount of water leaving the gondola
weighs exactly the same as the boat. This
keeps the Wheel balanced and so, despite
its enormous mass, it rotates through 180°
in five and a half minutes while using very
little power. It takes just 1.5 kilowatt-hours
(5.4 MJ) of energy to rotate the Wheel —
roughly the same as boiling eight small
domestic kettles of water.
Boats needing to be lifted up enter the
canal basin at the level of the Forth &
Clyde Canal and then enter the lower
gondola of the Wheel. Two hydraulic steel
gates are raised, so as to seal the gondola
off from the water in the canal basin. The
water between the gates is then pumped
out. A hydraulic clamp, which prevents
the arms of the Wheel moving while the
gondola is docked, is removed, allowing
the Wheel to turn. In the central machine
room an array of ten hydraulic motors
then begins to rotate the central axle. The
axle connects to the outer arms of the
Wheel, which begin to rotate at a speed
of 1/8 of a revolution per minute. As the
wheel rotates, the gondolas are kept in
the upright position by a simple gearing
system. Two eight-metre-wide cogs orbit
a fixed inner cog of the same width,
connected by two smaller cogs travelling
in the opposite direction to the outer cogs
— so ensuring that the gondolas always
remain level. When the gondola reaches
the top, the boat passes straight onto the
aqueduct situated 24 metres above the
canal basin.
The remaining 11 metres of lift needed
to reach the Union Canal is achieved by
means of a pair of locks. The Wheel could
not be constructed to elevate boats over
the full 35-metre difference between the
two canals, owing to the presence of the
historically important Antonine Wall, which
was built by the Romans in the second
century AD. Boats travel under this wall via
a tunnel, then through the locks, and finally
on to the Union Canal.
```

[Original question page](assets/0b2d0ed726140578034387ffe66868f8848e2c48e7538a8cb7b9bca18130aa28.jpg)

<!-- Source: /api/assets/753c7cc7d0bb6966bfaa2764be20688907deebed6f8fd8399c08bd1a3e3b2b89.jpg; PDF page 22; full -->

```text
Questions 14-19
Do the following statements agree with the information given in Reading Passage 2?
In boxes 14-19 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
14 The Falkirk Wheel has linked the Forth & Clyde Canal with the Union Canal for the
first time in their history.
15 There was some opposition to the design of the Falkirk Wheel at first.
16 The Falkirk Wheel was initially put together at the location where its components
were manufactured.
17 The Falkirk Wheel is the only boat lift in the world which has steel sections bolted
together by hand.
18 The weight of the gondolas varies according to the size of boat being carried.
19 The construction of the Falkirk Wheel site took into account the presence of a
nearby ancient monument.
23
```

[Original question page](assets/753c7cc7d0bb6966bfaa2764be20688907deebed6f8fd8399c08bd1a3e3b2b89.jpg)

<!-- Source: /api/assets/538fe73603092617b178adad7a3238d156c372e87a3395e9792fbbfefb89fc64.jpg; PDF page 23; full -->

```text
Questions 20–26
Label the diagram below. Choose ONE WORD from the passage for each answer.
Write your answers in boxes 20–26 on your answer sheet.
How a boat is lifted on the Falkirk Wheel
[Original labelled mechanical diagram retained.]
A pair of (20) __________ are lifted in order to shut out water from canal basin
A (21) __________ is taken out, enabling Wheel to rotate
Hydraulic motors drive (22) __________
Boat is raised, floating in one of Wheel’s two gondolas
A range of different-sized (23) __________ ensures boat keeps upright
Boat reaches top Wheel, then moves directly onto (24) __________
Boat travels through tunnel beneath Roman (25) __________
(26) __________ raise boat 11 m to level of Union Canal
```

[Original question page](assets/538fe73603092617b178adad7a3238d156c372e87a3395e9792fbbfefb89fc64.jpg)

![Original figure](assets/538fe73603092617b178adad7a3238d156c372e87a3395e9792fbbfefb89fc64.jpg)

<!-- Source: /api/assets/d0b6678f7657621f834b8d3c4a0b71d877f9d22b63bd03109c8b7202a345a30b.jpg; PDF page 24; full -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Reducing the Effects of Climate Change
Mark Rowe reports on the increasingly ambitious geo-engineering projects
being explored by scientists
A Such is our dependence on fossil fuels, and such is the volume of carbon dioxide already
released into the atmosphere, that many experts agree that significant global warming is now
inevitable. They believe that the best we can do is keep it at a reasonable level, and at present
the only serious option for doing this is cutting back on our carbon emissions. But while a few
countries are making major strides in this regard, the majority are having great difficulty even
stemming the rate of increase, let alone reversing it. Consequently, an increasing number of
scientists are beginning to explore the alternative of geo-engineering — a term which generally
refers to the intentional large-scale manipulation of the environment. According to its
proponents, geo-engineering is the equivalent of a backup generator: if Plan A — reducing our
dependency on fossil fuels — fails, we require a Plan B, employing grand schemes to slow down
or reverse the process of global warming.
B Geo-engineering has been shown to work, at least on a small localised scale. For decades, May
Day parades in Moscow have taken place under clear blue skies, aircraft having deposited dry
ice, silver iodide and cement powder to disperse clouds. Many of the schemes now suggested
look to do the opposite, and reduce the amount of sunlight reaching the planet. The most
eye-catching idea of all is suggested by Professor Roger Angel of the University of Arizona. His
scheme would employ up to 16 trillion minute spacecraft, each weighing about one gram, to
form a transparent, sunlight-refracting sunshade in an orbit 1.5 million km above the Earth.
This could, argues Angel, reduce the amount of light reaching the Earth by two per cent.
C The majority of geo-engineering projects so far carried out — which include planting forests
in deserts and depositing iron in the ocean to stimulate the growth of algae — have focused on
achieving a general cooling of the Earth. But some look specifically at reversing the melting
at the poles, particularly the Arctic. The reasoning is that if you replenish the ice sheets and
frozen waters of the high latitudes, more light will be reflected back into space, so reducing the
warming of the oceans and atmosphere.
D The concept of releasing aerosol sprays into the stratosphere above the Arctic has been proposed
by several scientists. This would involve using sulphur or hydrogen sulphide aerosols so that
sulphur dioxide would form clouds, which would, in turn, lead to a global dimming. The idea
is modelled on historic volcanic explosions, such as that of Mount Pinatubo in the Philippines
in 1991, which led to a short-term cooling of global temperatures by 0.5 °C. Scientists have
also scrutinised whether it’s possible to preserve the ice sheets of Greenland with reinforced
high-tension cables, preventing icebergs from moving into the sea. Meanwhile in the Russian
Arctic, geo-engineering plans include the planting of millions of birch trees. Whereas the
region's native evergreen pines shade the snow and absorb radiation, birches would shed their
25
```

[Original question page](assets/d0b6678f7657621f834b8d3c4a0b71d877f9d22b63bd03109c8b7202a345a30b.jpg)

<!-- Source: /api/assets/6cd741f30c419aa2168a1cea5a5e40e2e7bfe96752e8425f3b9a2dc492b8a2db.jpg; PDF page 25; full -->

```text
leaves in winter, thus enabling radiation to be reflected by the snow. Re-routing Russian rivers
to increase cold water flow to ice-forming areas could also be used to slow down warming, say
some climate scientists.
E But will such schemes ever be implemented? Generally speaking, those who are most cautious
about geo-engineering are the scientists involved in the research. Angel says that his plan is ‘no
substitute for developing renewable energy: the only permanent solution’. And Dr Phil Rasch of
the US-based Pacific Northwest National Laboratory is equally guarded about the role of geo-
engineering: ‘I think all of us agree that if we were to end geo-engineering on a given day, then
the planet would return to its pre-engineered condition very rapidly, and probably within ten to
twenty years. That's certainly something to worry about.”
F The US National Center for Atmospheric Research has already suggested that the proposal
to inject sulphur into the atmosphere might affect rainfall patterns across the tropics and the
Southern Ocean. ‘Geo-engineering plans to inject stratospheric aerosols or to seed clouds would
act to cool the planet, and act to increase the extent of sea ice,’ says Rasch. ‘But all the models
suggest some impact on the distribution of precipitation.”
G ‘A further risk with geo-engineering projects is that you can “overshoot”,’ says Dr Dan
Lunt, from the University of Bristol’s School of Geophysical Sciences, who has studied the
likely impacts of the sunshade and aerosol schemes on the climate. ‘You may bring global
temperatures back to pre-industrial levels, but the risk is that the poles will still be warmer than
they should be and the tropics will be cooler than before industrialisation.’ To avoid such a
scenario, Lunt says Angel's project would have to operate at half strength; all of which reinforces
his view that the best option is to avoid the need for geo-engineering altogether.
H The main reason why geo-engineering is supported by many in the scientific community is that
most researchers have little faith in the ability of politicians to agree — and then bring in — the
necessary carbon cuts. Even leading conservation organisations see the value of investigating the
potential of geo-engineering. According to Dr Martin Sommerkorn, climate change advisor for
the World Wildlife Fund’s International Arctic Programme, ‘Human-induced climate change
has brought humanity to a position where we shouldn't exclude thinking thoroughly about this
topic and its possibilities.’
```

[Original question page](assets/6cd741f30c419aa2168a1cea5a5e40e2e7bfe96752e8425f3b9a2dc492b8a2db.jpg)

<!-- Source: /api/assets/4ccaedb57ec84b6cf8050267009039b6071cf21ed0719039350f84fad41cc1ca.jpg; PDF page 26; full -->

```text
Questions 27-29
Reading Passage 3 has eight paragraphs A-H.
Which paragraph contains the following information?
Write the correct letter, A-H, in boxes 27-29 on your answer sheet.
27 mention of a geo-engineering project based on an earlier natural phenomenon
28 an example of a successful use of geo-engineering
29 a common definition of geo-engineering
27
```

[Original question page](assets/4ccaedb57ec84b6cf8050267009039b6071cf21ed0719039350f84fad41cc1ca.jpg)

<!-- Source: /api/assets/9bf1d8bf000b6a4f3a64a93a8a4317752379f2e599849128d45fd28cb1be5ad3.jpg; PDF page 27; full -->

```text
Questions 30–36
Complete the table below. Choose ONE WORD from the passage for each answer.
Write your answers in boxes 30–36 on your answer sheet.
GEO-ENGINEERING PROJECTS
| Procedure | Aim |
| --- | --- |
| put a large number of tiny spacecraft into orbit far above Earth | to create a (30) __________ that would reduce the amount of light reaching Earth |
| place (31) __________ in the sea | to encourage (32) __________ to form |
| release aerosol sprays into the stratosphere | to create (33) __________ that would reduce the amount of light reaching Earth |
| fix strong (34) __________ to Greenland ice sheets | to prevent icebergs moving into the sea |
| plant trees in Russian Arctic that would lose their leaves in winter | to allow the (35) __________ to reflect radiation |
| change the direction of (36) __________ | to bring more cold water into ice-forming areas |
```

[Original question page](assets/9bf1d8bf000b6a4f3a64a93a8a4317752379f2e599849128d45fd28cb1be5ad3.jpg)

<!-- Source: /api/assets/b211586be262558719a42204edd8728c9d25b6d8ffb2c43bdf312476c57868e5.jpg; PDF page 28; full -->

```text
Questions 37-40
Look at the following statements (Questions 37-40) and the list of scientists below.
Match each statement with the correct scientist, A-D.
Write the correct letter, A-D, in boxes 37-40 on your answer sheet.
37 The effects of geo-engineering may not be long-lasting.
38 Geo-engineering is a topic worth exploring.
39 It may be necessary to limit the effectiveness of geo-engineering projects.
40 Research into non-fossil-based fuels cannot be replaced by geo-engineering.
List of Scientists
A Roger Angel
B Phil Rasch
C Dan Lunt
D Martin Sommerkorn
29
```

[Original question page](assets/b211586be262558719a42204edd8728c9d25b6d8ffb2c43bdf312476c57868e5.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/7afa52c5227e7a23791d019c5e5f09bfb43cc109b5c59a3493058ef82f691ac7.jpg; PDF page 29; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show the percentage of water used for different purposes in six areas of the world.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/7afa52c5227e7a23791d019c5e5f09bfb43cc109b5c59a3493058ef82f691ac7.jpg)

![Original figure](assets/7afa52c5227e7a23791d019c5e5f09bfb43cc109b5c59a3493058ef82f691ac7.jpg)

### Task 2

<!-- Source: /api/assets/679ebd63636f0b810ffd95e28a604ccc6fcda70ff3ac218e8ca5cc8be1786d62.jpg; PDF page 30; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Governments should spend money on railways rather than roads.

To what extent do you agree or disagree with this statement?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/679ebd63636f0b810ffd95e28a604ccc6fcda70ff3ac218e8ca5cc8be1786d62.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/6fcb176543e5d83a19196a455e597cc061bf3b3005a52d30e2a319931ed772a9.jpg; PDF page 31; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Food and cooking
+ What sorts of food do you like eating most? [Why?]
+ Who normally does the cooking in your home? [Why/Why not?]
+ Do you watch cookery programmes on TV? [Why/Why not?]
* In general, do you prefer eating out or eating at home? [Why?]
PART 2
Describe a house/apartment that someone you know lives in.
You should say:
– whose house/apartment this is
– where the house/apartment is
– what it looks like inside
and explain what you like or dislike about this person’s house/apartment.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Different types of home
Example questions:
What kinds of home are most popular in your country? Why is this?
What do you think are the advantages of living in a house rather than an apartment?
Do you think that everyone would like to live in a larger home? Why is that?
Finding a place to live
Example questions:
How easy is it to find a place to live in your country?
Do you think it’s better to rent or to buy a place to live in? Why?
Do you agree that there is a right age for young adults to stop living with their parents?
Why is that?
32
```

[Original question page](assets/6fcb176543e5d83a19196a455e597cc061bf3b3005a52d30e2a319931ed772a9.jpg)

### Part 2

<!-- Source: /api/assets/6fcb176543e5d83a19196a455e597cc061bf3b3005a52d30e2a319931ed772a9.jpg; PDF page 31; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Food and cooking
+ What sorts of food do you like eating most? [Why?]
+ Who normally does the cooking in your home? [Why/Why not?]
+ Do you watch cookery programmes on TV? [Why/Why not?]
* In general, do you prefer eating out or eating at home? [Why?]
PART 2
Describe a house/apartment that someone you know lives in.
You should say:
– whose house/apartment this is
– where the house/apartment is
– what it looks like inside
and explain what you like or dislike about this person’s house/apartment.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Different types of home
Example questions:
What kinds of home are most popular in your country? Why is this?
What do you think are the advantages of living in a house rather than an apartment?
Do you think that everyone would like to live in a larger home? Why is that?
Finding a place to live
Example questions:
How easy is it to find a place to live in your country?
Do you think it’s better to rent or to buy a place to live in? Why?
Do you agree that there is a right age for young adults to stop living with their parents?
Why is that?
32
```

[Original question page](assets/6fcb176543e5d83a19196a455e597cc061bf3b3005a52d30e2a319931ed772a9.jpg)

### Part 3

<!-- Source: /api/assets/6fcb176543e5d83a19196a455e597cc061bf3b3005a52d30e2a319931ed772a9.jpg; PDF page 31; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Food and cooking
+ What sorts of food do you like eating most? [Why?]
+ Who normally does the cooking in your home? [Why/Why not?]
+ Do you watch cookery programmes on TV? [Why/Why not?]
* In general, do you prefer eating out or eating at home? [Why?]
PART 2
Describe a house/apartment that someone you know lives in.
You should say:
– whose house/apartment this is
– where the house/apartment is
– what it looks like inside
and explain what you like or dislike about this person’s house/apartment.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Different types of home
Example questions:
What kinds of home are most popular in your country? Why is this?
What do you think are the advantages of living in a house rather than an apartment?
Do you think that everyone would like to live in a larger home? Why is that?
Finding a place to live
Example questions:
How easy is it to find a place to live in your country?
Do you think it’s better to rent or to buy a place to live in? Why?
Do you agree that there is a right age for young adults to stop living with their parents?
Why is that?
32
```

[Original question page](assets/6fcb176543e5d83a19196a455e597cc061bf3b3005a52d30e2a319931ed772a9.jpg)
