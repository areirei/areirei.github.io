# 剑雅 3 · Test 3

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/cfbaacced57a8141bb5cc884ccb87f6c501f1dfab6a33cad5d5ac481b4e4e248.jpg; PDF page 58; full -->

```text
SECTION1 Questions1–10
Complete the notes below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
NOTES — Christmas Dinner
Example: Number to book for —45
Date of dinner:21December
Choices for venue:
First choice (1) __________ — Tel.number:not known
Second choice (2) __________ — Tel.number:777192
Third choice (3) __________ — Tel.number:(4) __________
Price per person:£12
Restaurant must have vegetarian food and a (5) __________.
Menu: First course—French Onion Soup OR Fruit Juice
Main course—Roast Dinner OR (6) __________
Dessert—Plum Pudding OR Apple Pie; Coffee
Restaurant requires from us: (7) __________ and letter of confirmation; and we must (8) __________ in advance.
Must confirm in writing by: (9) __________
Put notice in (10) __________.
```

[Original question page](assets/cfbaacced57a8141bb5cc884ccb87f6c501f1dfab6a33cad5d5ac481b4e4e248.jpg)

### Part 2

<!-- Source: /api/assets/173ad5f1b1219f265e3b2fdd2d2b0b27e9eec2e31da3831d5fd5e7c529e62a5f.jpg; PDF page 59; full -->

```text
Listening 
 55
SECTION2        Questions 11-20 
 
Questions 11-13 
 
Complete the table below. 
 
Write NO MORE THAN THREE WORDS OR A NUMBER for each answer. 
 
MEMBERSHIP OF SPORTS CENTRE 
Cost 11 £..............................per 12.............................. 
Where? 13................................. 
When? 2 to 6 pm, Monday to Thursday 
Bring: Union card  
 
Photo  
 
Fee 
 
Questions 14-16 
 
Complete the table below. 
 
Write NO MORE THAN THREE WORDS for each answer. 
 
Always bring sports 14.................................when you come to 15.................................or use the 
Centre’s facilities. 
Opening hours 9 am to 10 pm on 16.................................  
10 am to 6 pm on Saturdays 
50% ‘morning discount’ 9 am to 12 noon on weekdays
```

[Original question page](assets/173ad5f1b1219f265e3b2fdd2d2b0b27e9eec2e31da3831d5fd5e7c529e62a5f.jpg)

<!-- Source: /api/assets/be34df5b669a5cc081584aca66c42428ebccde6c6941ff0536a30a4b5096a45a.jpg; PDF page 60; full -->

```text
Test 3 
 56
Questions 17-20 
 
Look at the map of the Sports Complex below. 
 
Label the buildings on the map of the Sports Complex. 
 
Choose your answers from the box below and write them against Questions 17-20. 
 
Arts Studio  
Football Pitch  
Tennis Courts  
Dance Studio  
Fitness Room  
Reception  
Squash Courts
```

[Original question page](assets/be34df5b669a5cc081584aca66c42428ebccde6c6941ff0536a30a4b5096a45a.jpg)

![Original figure](assets/be34df5b669a5cc081584aca66c42428ebccde6c6941ff0536a30a4b5096a45a.jpg)

### Part 3

<!-- Source: /api/assets/3c7c063fca4aebc1a4e4a4c7b9910430a7869b9f2ea637a7ea2a410a5ed5a73d.jpg; PDF page 61; full -->

```text
SECTION3 Questions21–30
Complete the form below. Write NO MORE THAN THREE WORDS AND/OR NUMBER for each answer.
YOUNG ELECTRONIC ENGINEER COMPETITION
Name(s) of designer(s): John Brown; (21) __________
Age: (22) __________
Name of design: (23) __________
Dimensions of equipment: (24) Width __________cm; Length __________cm; Depth __________cm
Power: Battery
Special features: (25) __________; (26) __________; (27) __________
Cost: parts$5; (28) __________ $9.50
Other comments: need help to make (29) __________; would like to develop range of sizes
Send by: (30) __________
```

[Original question page](assets/3c7c063fca4aebc1a4e4a4c7b9910430a7869b9f2ea637a7ea2a410a5ed5a73d.jpg)

### Part 4

<!-- Source: /api/assets/94f14f53f050225214386c6e34c58e8871e1e021094eb6feebbba2fe92a72817.jpg; PDF page 62; full -->

```text
Test 3 
 58
SECTIO N 4         Questions 31-40  
 
Questions 31-33 
 
Complete the table below. 
 
Write NO MORE THAN TWO WORDS for each answer. 
 
"NEW" MEAT | CAN BE COMPARED TO | PROBLEM
kangaroo |(31) __________|(32) __________
crocodile |chicken|fatty
ostrich |(33) __________|[grey non-answer cell]
Questions34–36: Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
OSTRICH PRODUCT | USE
Ostrich feathers |tribal ceremonial dress; (34) __________; decorated hats
Ostrich hide |(35) __________
Ostrich (36) __________ |‘biltong’
```

[Original question page](assets/94f14f53f050225214386c6e34c58e8871e1e021094eb6feebbba2fe92a72817.jpg)

<!-- Source: /api/assets/c3d34bf3064a4900c760dc0cb65d3e85e3defa9d3d75151050782c3c55aa5027.jpg; PDF page 63; full -->

```text
Listening 
 59
Questions 37-40 
 
Choose the correct letters A-C. 
 
37     Ostrich meat 
A     has more protein than beef.  
B     tastes nearly as good as beef.  
C     is very filling. 
 
38     One problem with ostrich farming in Britain is 
A     the climate. 
B     the cost of transporting birds. 
C     the price of ostrich eggs. 
 
39     Ostrich chicks reared on farms 
A     must be kept in incubators until mature. 
B     are very independent. 
C     need looking after carefully. 
 
40     The speaker suggests ostrich farms are profitable because 
A     little initial outlay is required.  
B     farmed birds are very productive.  
C     there is a good market for the meat.
```

[Original question page](assets/c3d34bf3064a4900c760dc0cb65d3e85e3defa9d3d75151050782c3c55aa5027.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/5df34f382dca2d9ea60976bb0fc94fc6280ab039c3d4f75e10ff1aabb2b665d0.jpg; PDF page 64; full -->

```text
Test 3 
 60
READING 
 
READING PASSAGE 1 
 
You should spend about 20 minutes on Questions 1—12 which are based on Reading Passage 1 below. 
 
THE DEPARTMENT OF ETHNOGRAPHY 
The Department of Ethnography was 
created as a separate department within 
the British Museum in 1946, after 140 
years of gradual development from the 
original Department of Antiquities. If is 
concerned with the people of Africa, the 
Americas, Asia, the Pacific and parts of 
Europe. While this includes complex 
kingdoms, as in Africa, and ancient 
empires, such as those of the Americas, 
the primary focus of attention in the 
twentieth century has been on small-scale 
societies. Through its collections, the 
Department’s specific interest is to 
document how objects are created and 
used, and to understand their importance 
and significance to those who produce 
them. Such objects can include both the 
extraordinary and the mundane, the 
beautiful and the banal. 
The collections of the Department of 
Ethnography include approximately 
300,000 artefacts, of which about half are 
the product of the present century. The 
Department has a vital role to play in 
providing information on non-Western 
cultures to visitors and scholars. To this 
end, the collecting emphasis has often 
been less on individual objects than on 
groups of material which allow the display 
of a broad range of a society’s cultural 
expressions. 
 
Much of the more recent collecting was 
carried out in the field, sometimes by 
Museum staff working on general 
anthropological projects in collaboration 
with a wide variety of national governments 
and other institutions. The material 
collected includes great technical series - 
for instance, of textiles from Bolivia, 
Guatemala, Indonesia and areas of West 
Africa - or of artefact types such as boats. 
The latter include working examples of 
coracles from India, reed boats from Lake 
Titicaca in the Andes, kayaks from the 
Arctic, and dug-out canoes from several 
countries. The field assemblages, such as 
those from the Sudan, Madagascar and 
Yemen, include a whole range of material 
culture representative of one people. This 
might cover the necessities of life of an 
African herdsman or an Arabian farmer, 
ritual objects, or even on occasion airport 
art. Again, a series of acquisitions might
[Editorial note: obvious typographical substitutions in the supplied PDF were corrected in this transcription; the original image and per-page correction record are retained. Names, quantities and claims are unchanged.]
```

[Original question page](assets/5df34f382dca2d9ea60976bb0fc94fc6280ab039c3d4f75e10ff1aabb2b665d0.jpg)

<!-- Source: /api/assets/e2768a0aa83c937386e92470c51230c2ee1ffaced69c74e01936f204925d19dc.jpg; PDF page 65; full -->

```text
Reading 
 61
represent a decade’s fieldwork 
documenting social experience as 
expressed in the varieties of clothing and 
jewellery styles, tents and camel trappings 
from various Middle Eastern countries, or in 
the developing preferences in personal 
adornment and dress from Papua New 
Guinea. Particularly interesting are a series 
of collections which continue to document 
the evolution of ceremony and of material 
forms for which the Department already 
possesses early (if not the earliest) 
collections formed after the first contact 
with Europeans.  
The importance of these acquisitions 
extends beyond the objects themselves. 
They come to the Museum with 
documentation of the social context, ideally 
including photographic records. Such 
acquisitions have multiple purposes. Most 
significantly they document for future 
change. Most people think of the cultures 
represented in the collection in terms of the 
absence of advanced technology. In fact, 
traditional practices draw on a continuing 
wealth of technological ingenuity. Limited 
resources and ecological constraints are 
often overcome by personal skills that 
would be regarded as exceptional in the 
West. Of growing interest is the way in 
which much of what we might see as 
disposable is, elsewhere, recycled and 
reused. 
With the Independence of much of Asia 
and Africa after 1945, it was assumed that 
economic progress would rapidly lead to 
the   disappearance   or  assimilation   of 
many small-scale societies. Therefore, it 
was felt that the Museum should acquire 
materials representing people whose art or 
material culture, ritual or political structures 
were on the point of irrevocable change. 
This attitude altered with the realisation that 
marginal communities can survive and 
adapt in spite of partial integration into a 
notoriously fickle world economy. Since the 
seventeenth century, with the advent of 
trading companies exporting manufactured 
textiles to North America and Asia, the 
importation of cheap goods has often 
contributed to the destruction of local skills 
and indigenous markets. On the one hand 
modern imported goods may be used in an 
everyday setting, while on the other hand 
other traditional objects may still be 
required for ritually significant events. 
Within this context trade and exchange 
attitudes are inverted. What are utilitarian 
objects to a Westerner may be prized 
objects in other cultures - when 
transformed by local ingenuity - principally 
for aesthetic value. In the same way, the 
West imports goods from other peoples 
and in certain circumstances categorises 
them as ‘art’. 
Collections act as an ever-expanding 
database, not merely for scholars and 
anthropologists, but for people involved in 
a whole range of educational and artistic 
purposes. These include schools and 
universities as well as colleges of art and 
design. The provision of information about 
non-Western aesthetics and techniques, 
not just for designers and artists but for all 
visitors, is a growing responsibility for a 
Department whose own context is an 
increasingly multicultural European society.
[Editorial note: obvious typographical substitutions in the supplied PDF were corrected in this transcription; the original image and per-page correction record are retained. Names, quantities and claims are unchanged.]
```

[Original question page](assets/e2768a0aa83c937386e92470c51230c2ee1ffaced69c74e01936f204925d19dc.jpg)

<!-- Source: /api/assets/4a8bb690086b84e3f495dce7616a9cb72f687bce49f9cbbdfb1cbeb4ced883d6.jpg; PDF page 66; full -->

```text
Test 3 
 62
Questions 1-6 
 
Do the following statements agree with the information given in Reading Passage 1?  
 
In boxes 1-6 on your answer sheet write 
 
TRUE            if the statement is true according to the passage 
FALSE          if the statement is false according to the passage 
NOT GIVEN  if the information is not given in the passage 
 
Example 
The Department of Ethnography 
replaced the Department of Antiquities 
at the British Museum. 
Answer 
FALSE  
 
1      The twentieth-century collections come mainly from mainstream societies such as the US and 
Europe. 
2      The Department of Ethnography focuses mainly on modern societies. 
3      The Department concentrates on collecting single unrelated objects of great value. 
4      The textile collection of the Department of Ethnography is the largest in the world. 
5      Traditional societies are highly inventive in terms of technology. 
6      Many small-scale societies have survived and adapted in spite of predictions to the contrary.
```

[Original question page](assets/4a8bb690086b84e3f495dce7616a9cb72f687bce49f9cbbdfb1cbeb4ced883d6.jpg)

<!-- Source: /api/assets/6687fd1cec0b6da1950422441ba2b132be438cb8719f3c8d75ed514942eeb5ba.jpg; PDF page 67; full -->

```text
Reading 
 63
Questions 7-12 
 
Some of the exhibits at the Department of Ethnography are listed below (Questions 7-12). 
 
The writer gives these exhibits as examples of different collection types. 
 
Match each exhibit with the collection type with which it is associated in Reading Passage 1. 
 
Write the appropriate letters in boxes 7-12 on your answer sheet. 
 
NB You may use any collection type more than once. 
 
 Collection Types 
AT Artefact Types 
EC Evolution of Ceremony 
FA Field Assemblages 
SE Social Experience 
TS Technical Series 
 
Example 
Boats 
Answer 
AT  
 
7    Bolivian textiles 
8    Indian coracles 
9    airport art 
10    Arctic kayaks 
11    necessities of life of an Arabian farmer 
12    tents from the Middle East
```

[Original question page](assets/6687fd1cec0b6da1950422441ba2b132be438cb8719f3c8d75ed514942eeb5ba.jpg)

<!-- Source: /api/assets/61b1030d9e60bd672c04cb68be187f21a921ecef6ae55decd3bde9e9008c8a81.jpg; PDF page 68; full -->

```text
Test 3 
 64
READING PASSAGE 2 
 
You should spend about 20 minutes on Questions 13-25 which are based on Reading Passage 2 on 
the following pages. 
 
Questions 13-15 
 
Reading Passage 2 has six sections A-F. 
 
Choose the most suitable headings for sections A, B and D from the list of headings below. 
 
Write the appropriate numbers i-vii in boxes 13-15 on your answer sheet. 
 
 List of Headings 
i Amazonia as unable to sustain complex 
societies 
ii The role of recent technology in ecological 
research in Amazonia 
iii The hostility of the indigenous population 
to North American influences 
iv Recent evidence 
v Early research among the Indian Amazons 
vi The influence of prehistoric inhabitants on 
Amazonian natural history 
vii The great difficulty of changing local 
attitudes and practices 
 
13     Section A 
14     Section B 
Example 
Paragraph C 
Answer 
iv  
 
15    Section D
```

[Original question page](assets/61b1030d9e60bd672c04cb68be187f21a921ecef6ae55decd3bde9e9008c8a81.jpg)

<!-- Source: /api/assets/0eac75363c575989a592702114368cb7f668a667ff26e3481abe455fcab91811.jpg; PDF page 69; full -->

```text
Secrets of the Forest
Reading 
 65
 
 
A In 1942 Allan R Holmberg, a doctoral student in anthropology from Yale University, USA, 
ventured deep into the jungle of Bolivian Amazonia and searched out an isolated band of 
Siriono Indians. The Siriono, Holmberg later wrote, led a "strikingly backward" existence. 
Their villages were little more than clusters of thatched huts. Life itself was a perpetual and 
punishing search for food: some families grew manioc 
and other starchy crops in small garden 
plots cleared from the forest, while other members of the tribe scoured the country for small 
game and promising fish holes. When local resources became depleted, the tribe moved on. 
As for technology, Holmberg noted, the Siriono "may be classified among the most 
handicapped peoples of the world". Other than bows, arrows and crude digging sticks, the 
only tools the Siriono seemed to possess were "two machetes worn to the size of pocket-
knives". 
B Although the lives of the Siriono have changed in the intervening decades, the image of them 
as Stone Age relics has endured. Indeed, in many respects the Siriono epitomize the popular 
conception of life in Amazonia. To casual observers, as well as to influential natural scientists 
and regional planners, the luxuriant forests of Amazonia seem ageless, unconquerable, a 
habitat totally hostile to human civilization. The apparent simplicity of Indian ways of life has 
been judged an evolutionary adaptation to forest ecology, living proof that Amazonia could 
not - and cannot - sustain a more complex society. Archaeological traces of far more elaborate 
cultures have been dismissed as the ruins of invaders from outside the region, abandoned to 
decay in the uncompromising tropical environment. 
C The popular conception of Amazonia and its native residents would be enormously 
consequential if it were true. But the human history of Amazonia in the past 11,000 years 
betrays that view as myth. Evidence gathered in recent years from anthropology and 
archaeology indicates that the region has supported a series of indigenous cultures for eleven 
thousand years; an extensive network of complex societies - some with populations perhaps as 
large as 100,000 - thrived there for more than 1,000 years before the arrival of Europeans. 
(Indeed, some contemporary tribes, including the Siriono, still live among the earthworks of 
earlier cultures.) Far from being evolutionarily retarded, prehistoric Amazonian people 
developed technologies and cultures that were advanced for their time. If the lives of Indians 
today seem "primitive", the appearance is not the result of some environmental adaptation or 
ecological barrier; rather it is a comparatively recent adaptation to centuries of economic and 
political pressure. Investigators who argue otherwise have unwittingly projected the present 
onto the past. 
D The evidence for a revised view of Amazonia will take many people by surprise. Ecologists 
have assumed that tropical ecosystems were shaped entirely by natural forces and they have
```

[Original question page](assets/0eac75363c575989a592702114368cb7f668a667ff26e3481abe455fcab91811.jpg)

<!-- Source: /api/assets/2fbaad33bfe42bc64ce17cb334101c6a3a2514661d8bd9f26336a38784efeb37.jpg; PDF page 70; full -->

```text
Test 3 
 66
focused their research on habitats they believe have escaped human influence. But as the 
University of Florida ecologist, Peter Feinsinger, has noted, an approach that leaves people 
out of the equation is no longer tenable. The archaeological evidence shows that the natural 
history of Amazonia is to a surprising extent tied to the activities of its prehistoric inhabitants. 
E The realization comes none too soon. In June 1992 political and environmental leaders from 
across the world met in Rio de Janeiro to discuss how developing countries can advance their 
economies without destroying their natural resources. The challenge is especially difficult in 
Amazonia. Because the tropical forest has been depicted as ecologically unfit for large-scale 
human occupation, some environmentalists have opposed development of any kind. 
Ironically, one major casualty of that extreme position has been the environment itself. While 
policy makers struggle to define and implement appropriate legislation, development of the 
most destructive kind has continued apace over vast areas. 
F The other major casualty of the "naturalism" of environmental scientists has been the 
indigenous Amazonians, whose habits of hunting, fishing, and slash-and-burn cultivation 
often have been represented as harmful to the habitat. In the clash between environmentalists 
and developers, the Indians, whose presence is in fact crucial to the survival of the forest, 
have suffered the most. The new understanding of the pre-history of Amazonia, however, 
points toward a middle ground. Archaeology makes clear that with judicious management 
selected parts of the region could support more people than anyone thought before. The long-
buried past, it seems, offers hope for the future.
```

[Original question page](assets/2fbaad33bfe42bc64ce17cb334101c6a3a2514661d8bd9f26336a38784efeb37.jpg)

<!-- Source: /api/assets/d730966c5ec99b7639168bac2d6c3f15fcdb72e561f019c9422493d5597596a6.jpg; PDF page 71; full -->

```text
Reading 
 67
Questions 16-21 
 
Do the following statements agree with the views of the writer in Reading Passage 2?  
 
In boxes 16—21 on your answer sheet write 
 
YES               if the statement agrees with the views of the writer 
NO                if the statement contradicts the views of the writer 
NOT GIVEN if it is impossible to say what the writer thinks about this 
 
Example 
The prehistoric inhabitants of 
Amazonia were relatively backward in 
technological terms. 
Answer 
NO  
 
16    The reason for the simplicity of the Indian way of life is that Amazonia has always been unable 
to support a more complex society. 
 
17     There is a crucial popular misconception about the human history of Amazonia. 
 
18     There are lessons to be learned from similar ecosystems in other parts of the world. 
 
19    Most ecologists were aware that the areas of Amazonia they were working in had been shaped 
by human settlement. 
 
20     The indigenous Amazonian Indians are necessary to the well-being of the forest. 
 
21     It would be possible for certain parts of Amazonia to support a higher population.
```

[Original question page](assets/d730966c5ec99b7639168bac2d6c3f15fcdb72e561f019c9422493d5597596a6.jpg)

<!-- Source: /api/assets/1220fe9cb8527b9d2e825c0188601f01c2af42e8c93acebb29c37b053ba6b1dc.jpg; PDF page 72; full -->

```text
Test 3 
 68
Questions 22-25 
 
Choose the appropriate letters A-D and write them in boxes 22-25 on your answer sheet. 
 
22    In 1942 the US anthropology student concluded that the Siriono 
A     were unusually aggressive and cruel. 
B     had had their way of life destroyed by invaders. 
C     were an extremely primitive society. 
D     had only recently made permanent settlements. 
 
23    The author believes recent discoveries of the remains of complex societies in Amazonia  
A     are evidence of early indigenous communities. 
B     are the remains of settlements by invaders. 
C     are the ruins of communities established since the European invasions. 
D     show the region has only relatively recently been covered by forest. 
 
24    The assumption that the tropical ecosystem of Amazonia has been created solely by natural 
forces 
A     has often been questioned by ecologists in the past. 
B     has been shown to be incorrect by recent research. 
C     was made by Peter Feinsinger and other ecologists. 
D     has led to some fruitful discoveries. 
 
25     The application of our new insights into the Amazonian past would 
A     warn us against allowing any development at all. 
B     cause further suffering to the Indian communities. 
C     change present policies on development in the region. 
D     reduce the amount of hunting, fishing, and ‘slash-and-burn’.
```

[Original question page](assets/1220fe9cb8527b9d2e825c0188601f01c2af42e8c93acebb29c37b053ba6b1dc.jpg)

<!-- Source: /api/assets/6b2fc3979359161fb6303324bc38f97bf78ac7d6fe7a9353e6fd78fa7ab283e2.jpg; PDF page 73; full -->

```text
Reading 
 69
READING PASSAGE 3 
 
You should spend about 20 minutes on Questions 26-40 which are based on Reading Passage 3 below 
. 
 
 
HIGHS & LOWS

Hormone levels - and hence our moods -may 
be affected by the weather. Gloomy weather 
can cause depression, but sunshine appears to 
raise the spirits. In Britain, for example, the 
dull weather of winter drastically cuts down 
the amount of sunlight that is experienced 
which strongly affects some people. They 
become so depressed and lacking in energy 
that their work and social life are affected. 
This condition has been given the name SAD 
(Seasonal Affective Disorder). Sufferers can 
fight back by making the most of any sunlight 
in winter and by spending a few hours each 
day under special, full-spectrum lamps. These 
provide more ultraviolet and blue-green light 
than ordinary fluorescent and tungsten lights. 
Some Russian scientists claim that children 
learn better after being exposed to ultraviolet 
light. In warm countries, hours of work are 
often arranged so that workers can take a 
break, or even a siesta, during the hottest part 
of the day. Scientists are working to discover 
the links between the weather and human 
beings’ moods and performance. 
It is generally believed that tempers grow 
shorter in hot, muggy weather. There is no 
doubt that ‘crimes against the person’ rise in 
the summer, when the weather is hotter and 
fall in the winter when the weather is colder. 
Research in the United States has shown a 
relationship between temperature and street 
riots. The frequency of riots rises dramatically 
as the weather gets warmer, hitting a peak 
around 27-30°C. But is this effect really due to 
a mood change caused by the heat? Some 
scientists argue that trouble starts more often 
in hot weather merely because there are more 
people in the street when the weather is good. 
Psychologists have also studied how being 
cold affects performance. Researchers 
compared divers working in icy cold water at 
5°C with others in water at 20°C (about 
swimming pool temperature). The colder 
water made the divers worse at simple 
arithmetic and other mental tasks. But 
significantly, their performance was impaired 
as soon as they were put into the cold water - 
before their bodies had time to cool down. 
This suggests that the low temperature did 
not slow down mental functioning directly, 
but the feeling of cold distracted the divers 
from their tasks.
```

[Original question page](assets/6b2fc3979359161fb6303324bc38f97bf78ac7d6fe7a9353e6fd78fa7ab283e2.jpg)

<!-- Source: /api/assets/c51f65a59acbc0724a00a3d146819b6899de63905b1d4b0e869920cc8b708d1f.jpg; PDF page 74; full -->

```text
Test 3 
 70
Psychologists have conducted studies 
showing that people become less sceptical and 
more optimistic when the weather is sunny 
However, this apparently does not just 
depend on the temperature. An American 
psychologist studied customers in a 
temperature-controlled restaurant. They gave 
bigger tips when the sun was shining and 
smaller tips when it wasn’t, even though the 
temperature in the restaurant was the same. A 
link between weather and mood is made 
believable by the evidence for a connection 
between behaviour and the length of the 
daylight hours. This in turn might involve the 
level of a hormone called melatonin, 
produced in the pineal gland in the brain. The 
amount of melatonin falls with greater 
exposure to daylight. Research shows that 
melatonin plays an important part in the 
seasonal behaviour of certain animals. For 
example, food consumption of stags increases 
during the winter, reaching a peak in 
February/ March. It falls again to a low point 
in May, then rises to a peak in September, 
before dropping to another minimum in 
November. These changes seem to be 
triggered by varying melatonin levels. 
In the laboratory, hamsters put on more 
weight when the nights are getting shorter 
and their melatonin levels are falling. On the 
other hand, if they are given injections of 
melatonin, they will stop eating altogether. It 
seems that time cues provided by the 
changing lengths of day and night trigger 
changes in animals’ behaviour - changes that 
are needed to cope with the cycle of the 
seasons. People’s moods too, have been 
shown to react to the length of the daylight 
hours. Sceptics might say that longer exposure 
to sunshine puts people in a better mood 
because they associate it with the happy 
feelings of holidays and freedom from 
responsibility. However, the belief that rain 
and murky weather make people more 
unhappy is borne out by a study in Belgium, 
which showed that a telephone counselling 
service gets more telephone calls from people 
with suicidal feelings when it rains. 
When there is a thunderstorm brewing, some 
people complain of the air being ‘heavy’ and 
of feeling irritable, moody and on edge. They 
may be reacting to the fact that the air can 
become slightly positively charged when large 
thunderclouds are generating the intense 
electrical fields that cause lightning flashes. 
The positive charge increases the levels of 
serotonin (a chemical involved in sending 
signals in the nervous system). High levels of 
serotonin in certain areas of the nervous 
system make people more active and reactive 
and, possibly, more aggressive. When certain 
winds are blowing, such as the Mistral in 
southern France and the Fohn in southern 
Germany, mood can be affected - and the 
number of traffic accidents rises. It may be 
significant that the concentration of positively 
charged particles is greater than normal in 
these winds. In the United Kingdom, 400,000 
ionizers are sold every year. These small 
machines raise the number of negative ions in 
the air in a room. Many people claim they feel 
better in negatively charged air.
```

[Original question page](assets/c51f65a59acbc0724a00a3d146819b6899de63905b1d4b0e869920cc8b708d1f.jpg)

<!-- Source: /api/assets/d84426d06ff2c9087360fab0e45bdaa2d25642bf752c97732af237c06d9da2b4.jpg; PDF page 75; full -->

```text
Reading 
 71
Questions 26-28 
 
Choose the appropriate letters A—D and write them in boxes 26—28 on your answer sheet. 
26    Why did the divers perform less well in colder conditions? 
A     They were less able to concentrate. 
B     Their body temperature fell too quickly. 
C     Their mental functions were immediately affected by the cold. 
D     They were used to swimming pool conditions. 
27     The number of daylight hours 
A     affects the performance of workers in restaurants. 
B     influences animal feeding habits. 
C     makes animals like hamsters more active. 
D     prepares humans for having greater leisure time. 
28     Human irritability may be influenced by 
A     how nervous and aggressive people are. 
B     reaction to certain weather phenomena. 
C     the number of ions being generated by machines. 
D     the attitude of people to thunderstorms. 
 
Questions 29-34 
 
Do the following statements agree with the information in Reading Passage 3?  
 
In boxes 29-34 on your answer sheet write 
 
TRUE            if the statement is true according to the passage 
FALSE           if the statement is false according to the passage 
NOT GIVEN  if the information is not given in the passage 
 
29     Seasonal Affective Disorder is disrupting children’s education in Russia. 
30     Serotonin is an essential cause of human aggression. 
31     Scientific evidence links ‘happy associations with weather’ to human mood. 
32     A link between depression and the time of year has been established. 
33     Melatonin levels increase at certain times of the year. 
34     Positively charged ions can influence eating habits.
```

[Original question page](assets/d84426d06ff2c9087360fab0e45bdaa2d25642bf752c97732af237c06d9da2b4.jpg)

<!-- Source: /api/assets/6132b65ea6abfd00691f7a68dcee38f489897f7a6ab2cbd7b7942d913641aab6.jpg; PDF page 76; full -->

```text
Test 3 
 72
Questions 35-37 
 
According to the text which THREE of the following conditions have been scientifically proved to 
have a psychological effect on humans? 
 
Choose THREE letters A—G and write them in boxes 35—37 on your answer sheet. 
 
A     lack of negative ions 
B     rainy weather 
C     food consumption 
D     high serotonin levels 
E     sunny weather 
F     freedom from worry 
G     lack of counselling facilities 
 
Questions 38-40 
 
Complete each of the following statements with the best ending from the box below.  
 
Write the appropriate letters A-G in boxes 38—40 on your answer sheet. 
 
38    It has been established that social tension increases significantly in the United States during ... 
 
39     Research has shown that a hamster’s bodyweight increases according to its exposure to 
 
40    Animals cope with changing weather and food availability because they are influenced by... 
 
A daylight 
B hot weather 
C melatonin 
D moderate temperatures 
E poor co-ordination 
F time cues 
G impaired performance
```

[Original question page](assets/6132b65ea6abfd00691f7a68dcee38f489897f7a6ab2cbd7b7942d913641aab6.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/a77a361d6f38d8f0e1ad2d0c7f30c0bb8b54225915121db27fe98f1f02e620c5.jpg; PDF page 77; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show the levels of participation in education and science in developing and industrialised countries in 1980 and 1990.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

[Text edition note: the complete original figure is retained for all plotted series and labels.]
```

[Original question page](assets/a77a361d6f38d8f0e1ad2d0c7f30c0bb8b54225915121db27fe98f1f02e620c5.jpg)

![Original figure](assets/a77a361d6f38d8f0e1ad2d0c7f30c0bb8b54225915121db27fe98f1f02e620c5.jpg)

### Task 2

<!-- Source: /api/assets/9a968d4e86df45dad541324f9886e9d8d3d84d5459655ac2285cf2a91e77cc15.jpg; PDF page 78; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic.

In many countries children are engaged in some kind of paid work. Some people regard this as completely wrong, while others consider it as valuable work experience, important for learning and taking responsibility.

What are your opinions on this?

You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.

You should write at least 250 words.
```

[Original question page](assets/9a968d4e86df45dad541324f9886e9d8d3d84d5459655ac2285cf2a91e77cc15.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/9b2a12f83af971a1956fdc937931320b0a8b00d682a874ef039daa4d0c2efb87.jpg; PDF page 79; full -->

```text
Speaking 
 75
SPEAKING 
 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE 
Visitors 
•   What would you suggest a visitor should see and do in your country? 
•   Are there any traditional arts or music you would recommend? 
•   Tell me about the kind of foreign visitors or tourists who go to your country. 
•   In what ways has tourism changed your country? 
 
PART 2 
Describe a memorable event in your life.  
You should say: 
when the event took place  
where the event took place  
what happened exactly  
and explain why this event was memorable for you. 
You will have to talk about the topic 
for 1 to 2 minutes You have one 
minute to think about what you’re 
going to say. You can make some 
notes to help you if you wish. 
 
PART 3 
Discussion topics: 
The role of ceremony in our lives 
Example questions: 
How important are ceremonies in our lives? 
Do you see the role of private and public ceremonies changing in the future? 
 
Attitudes to marriage in your country 
Example questions: 
Have attitudes to marriage changed in recent years? 
In what ways do men and women feel differently about marriage, in your opinion? 
 
Events of national/global significance 
Example questions: 
What sort of national events make headlines in your country? 
Does the media in your country pay more attention to global or national events?
```

[Original question page](assets/9b2a12f83af971a1956fdc937931320b0a8b00d682a874ef039daa4d0c2efb87.jpg)

### Part 2

<!-- Source: /api/assets/9b2a12f83af971a1956fdc937931320b0a8b00d682a874ef039daa4d0c2efb87.jpg; PDF page 79; full -->

```text
Speaking 
 75
SPEAKING 
 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE 
Visitors 
•   What would you suggest a visitor should see and do in your country? 
•   Are there any traditional arts or music you would recommend? 
•   Tell me about the kind of foreign visitors or tourists who go to your country. 
•   In what ways has tourism changed your country? 
 
PART 2 
Describe a memorable event in your life.  
You should say: 
when the event took place  
where the event took place  
what happened exactly  
and explain why this event was memorable for you. 
You will have to talk about the topic 
for 1 to 2 minutes You have one 
minute to think about what you’re 
going to say. You can make some 
notes to help you if you wish. 
 
PART 3 
Discussion topics: 
The role of ceremony in our lives 
Example questions: 
How important are ceremonies in our lives? 
Do you see the role of private and public ceremonies changing in the future? 
 
Attitudes to marriage in your country 
Example questions: 
Have attitudes to marriage changed in recent years? 
In what ways do men and women feel differently about marriage, in your opinion? 
 
Events of national/global significance 
Example questions: 
What sort of national events make headlines in your country? 
Does the media in your country pay more attention to global or national events?
```

[Original question page](assets/9b2a12f83af971a1956fdc937931320b0a8b00d682a874ef039daa4d0c2efb87.jpg)

### Part 3

<!-- Source: /api/assets/9b2a12f83af971a1956fdc937931320b0a8b00d682a874ef039daa4d0c2efb87.jpg; PDF page 79; full -->

```text
Speaking 
 75
SPEAKING 
 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE 
Visitors 
•   What would you suggest a visitor should see and do in your country? 
•   Are there any traditional arts or music you would recommend? 
•   Tell me about the kind of foreign visitors or tourists who go to your country. 
•   In what ways has tourism changed your country? 
 
PART 2 
Describe a memorable event in your life.  
You should say: 
when the event took place  
where the event took place  
what happened exactly  
and explain why this event was memorable for you. 
You will have to talk about the topic 
for 1 to 2 minutes You have one 
minute to think about what you’re 
going to say. You can make some 
notes to help you if you wish. 
 
PART 3 
Discussion topics: 
The role of ceremony in our lives 
Example questions: 
How important are ceremonies in our lives? 
Do you see the role of private and public ceremonies changing in the future? 
 
Attitudes to marriage in your country 
Example questions: 
Have attitudes to marriage changed in recent years? 
In what ways do men and women feel differently about marriage, in your opinion? 
 
Events of national/global significance 
Example questions: 
What sort of national events make headlines in your country? 
Does the media in your country pay more attention to global or national events?
```

[Original question page](assets/9b2a12f83af971a1956fdc937931320b0a8b00d682a874ef039daa4d0c2efb87.jpg)
