# 剑雅 3 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 157

Answer key 
 153
TEST 3 
 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS. ( Where alternative spellings are accepted these are stated in the key.) 
Section 1, Questions 1-10 
1      Rajdoot 
2      Park View (Hotel) 
3      London Arms 
4     208657 
5      no/non(-)smoking section/area 
6      Lentil curry 
7     fifty pound(s)/£50 deposit // deposit (of) £50/fifty 
pound(s) 
8     choose/decide (on)/select (the) menu 
9     4 November 
ALTERNATIVE FORMS ACCEPTED 
10     (the) Newsletter 
Section 2, Questions 11-20 
11      (£)9.50 
12      year // annum NOT annual 
13      reception NOT Sports Centre 
14     card 
15      book 
16     weekdays 
17     Reception (Area) 
18      Dance Studio 
19      Squash Courts 
20      Fitness Room 
Section 3, Questions 21-30 
21      Anne Rea 
22      (both) 16 (years old) 
23      Blind (Jigsaw) Puzzle NOT Jigsaw 
24     MUST BE IN ORDER 20 (cm) 50 (cm) 2.5 (cm) 
// 2 and a half (cm) 
25–27 IN ANY ORDER:
• safe for children
• (it’s) educational
• price (is) good // inexpensive // not expensive // cheap(price) // (is) good price
28     electrics NOT electric 
29     plastic pieces // in plastic NOT pieces 
30      1 July 
ALTERNATIVE FORMS ACCEPTED 
Section 4, Questions 31-40 
31      rabbit (meat) 
32     (rather) tough 
33     beef 
34      (ladies’) (feather) fans 
35      (delicate) (fine) (good quality) leather 
36     meat 
37      A // has more protein than beef 
38     C // the price of ostrich eggs 
39     C // need looking after carefully 
40      B // farmed birds are very productive 
 

If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–25: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
26–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


1. Rajdoot

2. Park View / Park View Hotel

3. London Arms

4. 208657

5. nonsmoking section / non-smoking section / nonsmoking area / non-smoking area

6. Lentil curry

7. fifty pound / fifty pounds / £ 50 deposit / £50 deposit / deposit £ 50 / deposit £50 / deposit of £ 50 / deposit of £50 / deposit fifty pound / deposit fifty pounds / deposit of fifty pound / deposit of fifty pounds

8. choose menu / choose the menu / decide menu / decide the menu / decide on menu / decide on the menu / select menu / select the menu

9. 4 November

10. Newsletter / the Newsletter

### Part 2 · source page 157

Answer key 
 153
TEST 3 
 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS. ( Where alternative spellings are accepted these are stated in the key.) 
Section 1, Questions 1-10 
1      Rajdoot 
2      Park View (Hotel) 
3      London Arms 
4     208657 
5      no/non(-)smoking section/area 
6      Lentil curry 
7     fifty pound(s)/£50 deposit // deposit (of) £50/fifty 
pound(s) 
8     choose/decide (on)/select (the) menu 
9     4 November 
ALTERNATIVE FORMS ACCEPTED 
10     (the) Newsletter 
Section 2, Questions 11-20 
11      (£)9.50 
12      year // annum NOT annual 
13      reception NOT Sports Centre 
14     card 
15      book 
16     weekdays 
17     Reception (Area) 
18      Dance Studio 
19      Squash Courts 
20      Fitness Room 
Section 3, Questions 21-30 
21      Anne Rea 
22      (both) 16 (years old) 
23      Blind (Jigsaw) Puzzle NOT Jigsaw 
24     MUST BE IN ORDER 20 (cm) 50 (cm) 2.5 (cm) 
// 2 and a half (cm) 
25–27 IN ANY ORDER:
• safe for children
• (it’s) educational
• price (is) good // inexpensive // not expensive // cheap(price) // (is) good price
28     electrics NOT electric 
29     plastic pieces // in plastic NOT pieces 
30      1 July 
ALTERNATIVE FORMS ACCEPTED 
Section 4, Questions 31-40 
31      rabbit (meat) 
32     (rather) tough 
33     beef 
34      (ladies’) (feather) fans 
35      (delicate) (fine) (good quality) leather 
36     meat 
37      A // has more protein than beef 
38     C // the price of ostrich eggs 
39     C // need looking after carefully 
40      B // farmed birds are very productive 
 

If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–25: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
26–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


11. 9.50 / 9:50 / £ 9.50 / £ 9:50 / £9.50 / £9:50

12. year / annum

13. reception

14. card

15. book

16. weekdays

17. Reception / Reception Area

18. Dance Studio

19. Squash Courts

20. Fitness Room

### Part 3 · source page 157

Answer key 
 153
TEST 3 
 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS. ( Where alternative spellings are accepted these are stated in the key.) 
Section 1, Questions 1-10 
1      Rajdoot 
2      Park View (Hotel) 
3      London Arms 
4     208657 
5      no/non(-)smoking section/area 
6      Lentil curry 
7     fifty pound(s)/£50 deposit // deposit (of) £50/fifty 
pound(s) 
8     choose/decide (on)/select (the) menu 
9     4 November 
ALTERNATIVE FORMS ACCEPTED 
10     (the) Newsletter 
Section 2, Questions 11-20 
11      (£)9.50 
12      year // annum NOT annual 
13      reception NOT Sports Centre 
14     card 
15      book 
16     weekdays 
17     Reception (Area) 
18      Dance Studio 
19      Squash Courts 
20      Fitness Room 
Section 3, Questions 21-30 
21      Anne Rea 
22      (both) 16 (years old) 
23      Blind (Jigsaw) Puzzle NOT Jigsaw 
24     MUST BE IN ORDER 20 (cm) 50 (cm) 2.5 (cm) 
// 2 and a half (cm) 
25–27 IN ANY ORDER:
• safe for children
• (it’s) educational
• price (is) good // inexpensive // not expensive // cheap(price) // (is) good price
28     electrics NOT electric 
29     plastic pieces // in plastic NOT pieces 
30      1 July 
ALTERNATIVE FORMS ACCEPTED 
Section 4, Questions 31-40 
31      rabbit (meat) 
32     (rather) tough 
33     beef 
34      (ladies’) (feather) fans 
35      (delicate) (fine) (good quality) leather 
36     meat 
37      A // has more protein than beef 
38     C // the price of ostrich eggs 
39     C // need looking after carefully 
40      B // farmed birds are very productive 
 

If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–25: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
26–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


21. Anne Rea

22. 16 / 16 years old / both 16 / both 16 years old

23. Blind Puzzle / Blind Jigsaw Puzzle

24. 20 50 2.5 / 20, 50, 2.5 / 20 and 50 and 2.5 / 20 & 50 & 2.5 / 20; 50; 2.5 / 20/50/2.5 / 20,50,2.5 / 20, 50 and 2.5 / 20 50 2.5 cm / 20, 50, 2.5 cm / 20 and 50 and 2.5 cm / 20 & 50 & 2.5 cm / 20; 50; 2.5 cm / 20/50/2.5 cm / 20,50,2.5 cm / 20, 50 and 2.5 cm / 20 50 2 and a half / 20, 50, 2 and a half / 20 and 50 and 2 and a half / 20 & 50 & 2 and a half / 20; 50; 2 and a half / 20/50/2 and a half / 20,50,2 and a half / 20, 50 and 2 and a half / 20 50 2 and a half cm / 20, 50, 2 and a half cm / 20 and 50 and 2 and a half cm / 20 & 50 & 2 and a half cm / 20; 50; 2 and a half cm / 20/50/2 and a half cm / 20,50,2 and a half cm / 20, 50 and 2 and a half cm / 20 50 cm 2.5 / 20, 50 cm, 2.5 / 20 and 50 cm and 2.5 / 20 & 50 cm & 2.5 / 20; 50 cm; 2.5 / 20/50 cm/2.5 / 20,50 cm,2.5 / 20, 50 cm and 2.5 / 20 50 cm 2.5 cm / 20, 50 cm, 2.5 cm / 20 and 50 cm and 2.5 cm / 20 & 50 cm & 2.5 cm / 20; 50 cm; 2.5 cm / 20/50 cm/2.5 cm / 20,50 cm,2.5 cm / 20, 50 cm and 2.5 cm / 20 50 cm 2 and a half / 20, 50 cm, 2 and a half / 20 and 50 cm and 2 and a half / 20 & 50 cm & 2 and a half / 20; 50 cm; 2 and a half / 20/50 cm/2 and a half / 20,50 cm,2 and a half / 20, 50 cm and 2 and a half / 20 50 cm 2 and a half cm / 20, 50 cm, 2 and a half cm / 20 and 50 cm and 2 and a half cm / 20 & 50 cm & 2 and a half cm / 20; 50 cm; 2 and a half cm / 20/50 cm/2 and a half cm / 20,50 cm,2 and a half cm / 20, 50 cm and 2 and a half cm / 20 cm 50 2.5 / 20 cm, 50, 2.5 / 20 cm and 50 and 2.5 / 20 cm & 50 & 2.5 / 20 cm; 50; 2.5 / 20 cm/50/2.5 / 20 cm,50,2.5 / 20 cm, 50 and 2.5 / 20 cm 50 2.5 cm / 20 cm, 50, 2.5 cm / 20 cm and 50 and 2.5 cm / 20 cm & 50 & 2.5 cm / 20 cm; 50; 2.5 cm / 20 cm/50/2.5 cm / 20 cm,50,2.5 cm / 20 cm, 50 and 2.5 cm / 20 cm 50 2 and a half / 20 cm, 50, 2 and a half / 20 cm and 50 and 2 and a half / 20 cm & 50 & 2 and a half / 20 cm; 50; 2 and a half / 20 cm/50/2 and a half / 20 cm,50,2 and a half / 20 cm, 50 and 2 and a half / 20 cm 50 2 and a half cm / 20 cm, 50, 2 and a half cm / 20 cm and 50 and 2 and a half cm / 20 cm & 50 & 2 and a half cm / 20 cm; 50; 2 and a half cm / 20 cm/50/2 and a half cm / 20 cm,50,2 and a half cm / 20 cm, 50 and 2 and a half cm / 20 cm 50 cm 2.5 / 20 cm, 50 cm, 2.5 / 20 cm and 50 cm and 2.5 / 20 cm & 50 cm & 2.5 / 20 cm; 50 cm; 2.5 / 20 cm/50 cm/2.5 / 20 cm,50 cm,2.5 / 20 cm, 50 cm and 2.5 / 20 cm 50 cm 2.5 cm / 20 cm, 50 cm, 2.5 cm / 20 cm and 50 cm and 2.5 cm / 20 cm & 50 cm & 2.5 cm / 20 cm; 50 cm; 2.5 cm / 20 cm/50 cm/2.5 cm / 20 cm,50 cm,2.5 cm / 20 cm, 50 cm and 2.5 cm / 20 cm 50 cm 2 and a half / 20 cm, 50 cm, 2 and a half / 20 cm and 50 cm and 2 and a half / 20 cm & 50 cm & 2 and a half / 20 cm; 50 cm; 2 and a half / 20 cm/50 cm/2 and a half / 20 cm,50 cm,2 and a half / 20 cm, 50 cm and 2 and a half / 20 cm 50 cm 2 and a half cm / 20 cm, 50 cm, 2 and a half cm / 20 cm and 50 cm and 2 and a half cm / 20 cm & 50 cm & 2 and a half cm / 20 cm; 50 cm; 2 and a half cm / 20 cm/50 cm/2 and a half cm / 20 cm,50 cm,2 and a half cm / 20 cm, 50 cm and 2 and a half cm

25. safe for children / educational / it's educational / price good / price is good / inexpensive / not expensive / cheap / cheap price / good price / is good price

26. safe for children / educational / it's educational / price good / price is good / inexpensive / not expensive / cheap / cheap price / good price / is good price

27. safe for children / educational / it's educational / price good / price is good / inexpensive / not expensive / cheap / cheap price / good price / is good price

28. electrics

29. plastic pieces / in plastic

30. 1 July

### Part 4 · source page 157

Answer key 
 153
TEST 3 
 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS. ( Where alternative spellings are accepted these are stated in the key.) 
Section 1, Questions 1-10 
1      Rajdoot 
2      Park View (Hotel) 
3      London Arms 
4     208657 
5      no/non(-)smoking section/area 
6      Lentil curry 
7     fifty pound(s)/£50 deposit // deposit (of) £50/fifty 
pound(s) 
8     choose/decide (on)/select (the) menu 
9     4 November 
ALTERNATIVE FORMS ACCEPTED 
10     (the) Newsletter 
Section 2, Questions 11-20 
11      (£)9.50 
12      year // annum NOT annual 
13      reception NOT Sports Centre 
14     card 
15      book 
16     weekdays 
17     Reception (Area) 
18      Dance Studio 
19      Squash Courts 
20      Fitness Room 
Section 3, Questions 21-30 
21      Anne Rea 
22      (both) 16 (years old) 
23      Blind (Jigsaw) Puzzle NOT Jigsaw 
24     MUST BE IN ORDER 20 (cm) 50 (cm) 2.5 (cm) 
// 2 and a half (cm) 
25–27 IN ANY ORDER:
• safe for children
• (it’s) educational
• price (is) good // inexpensive // not expensive // cheap(price) // (is) good price
28     electrics NOT electric 
29     plastic pieces // in plastic NOT pieces 
30      1 July 
ALTERNATIVE FORMS ACCEPTED 
Section 4, Questions 31-40 
31      rabbit (meat) 
32     (rather) tough 
33     beef 
34      (ladies’) (feather) fans 
35      (delicate) (fine) (good quality) leather 
36     meat 
37      A // has more protein than beef 
38     C // the price of ostrich eggs 
39     C // need looking after carefully 
40      B // farmed birds are very productive 
 

If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–25: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
26–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


31. rabbit / rabbit meat

32. tough / rather tough

33. beef

34. fans / feather fans / ladies' fans / ladies' feather fans

35. leather / good quality leather / fine leather / fine good quality leather / delicate leather / delicate good quality leather / delicate fine leather / delicate fine good quality leather

36. meat

37. A

38. C

39. C

40. B

## A 类阅读

### Academic Reading · source page 158

Answer key 
 
 154
ACADEMIC READING 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN ALL 
ANSWERS. 
Reading Passage 1, Questions 1-12 
1      FALSE // F 
2      FALSE // F 
3     FALSE // F 
4      NOT GIVEN // NG 
5     TRUE // T 
6     TRUE // T 
7     TS // Technical Series 
8     AT // Artefact Types 
9      FA // Field Assemblages 
10     AT // Artefact Types 
11      FA//Field Assemblages 
12      SE // Social Experience 
Reading Passage 2, Questions 13—25 
13      v // Early research among the Indian Amazons 
14     i // Amazonia as unable to sustain complex 
societies 
15      vi // The influence of prehistoric inhabitants on 
Amazonian natural history 
16      NO // N 
17     YES // Y 
18      NOT GIVEN // NG 
19      NO//N 
20     YES // Y 
21      YES // Y 
22      C // were an extremely primitive society 
23      A // are evidence of early indigenous 
communities 
24      B // has been shown to be incorrect by recent 
research 
25     C // change present policies on development in the 
region 
Reading Passage 3, Questions 26-40 
26     A // They were less able to concentrate 
27      B // influences animal feeding habits 
28      B // reaction to certain weather phenomena 
29     NOT GIVEN // NG 
30      FALSE // F 
31      FALSE // F 
32      TRUE // T 
33     TRUE // T 
34     NOT GIVEN//NG 35-37      IN ANY ORDER 
B // rainy weather 
D // high serotonin levels 
E // sunny weather 
38     B // hot weather 
39     A // daylight 
40      F // time cues 
 
 

If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


1. FALSE

2. FALSE

3. FALSE

4. NOT GIVEN

5. TRUE

6. TRUE

7. TS / Technical Series

8. AT / Artefact Types

9. FA / Field Assemblages

10. AT / Artefact Types

11. FA / Field Assemblages

12. SE / Social Experience

13. v

14. i

15. vi

16. NO

17. YES

18. NOT GIVEN

19. NO

20. YES

21. YES

22. C

23. A

24. B

25. C

26. A

27. B

28. B

29. NOT GIVEN

30. FALSE

31. FALSE

32. TRUE

33. TRUE

34. NOT GIVEN

35. B / D / E

36. B / D / E

37. B / D / E

38. B

39. A

40. F

## A 类写作

### Writing material: c3-t3-w-1

All three original bar charts and the shared legend inspected at full resolution. Grey bars developing countries; black bars industrialised countries. Years 1980 and 1990. Chart 1, average years of schooling: developing countries about 2.5–3 years rising to about 3.5; industrialised countries about 8.5–9 rising to about 10.5. Chart 2, scientists and technicians per 1000 people: developing countries about 10 rising to roughly 15–20; industrialised countries roughly 40–45 rising to about 70. Chart 3, spending on research and development, US$ billions: developing countries about 50 declining to roughly 25; industrialised countries roughly 150–160 increasing to about 350. Values are unlabelled bar-height estimates and must not be treated as exact. Industrialised countries have higher figures on all three measures in both years, with large increases in research spending and scientific staffing. Both groups increase schooling and scientific workforce participation; developing countries are the exception to increasing research expenditure, which falls. Do not confuse years, per-thousand staffing and billions of dollars.



### Writing material: c3-t3-w-2

The prompt presents two opposing views and asks for the writer's opinions. It does not literally add a separate Discuss both views instruction. Address the issue and justify a position; no predefined position or fixed paragraph count is required.



## 口语
