# 剑雅 3 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 153

149
Answer key 
 
TEST 1 
 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN ALL 
ANSWERS. ( Where alternative spellings are accepted these are stated in the key.) 
 
Section 1, Questions 1-10 
1      (the) city centre (itself) ACCEPT center 
2      (£) 250 (pounds) (to) (£) (about) 500 (pounds) 
3      (a) garden 
4      (£) 325 (pounds) 
5      (the) water (bill(s)) 
6      (the) telephone/phone (rental) 
7      Wednesday/Wed (afternoon) 
8      (your) employer 
9     two/2 weeks’/wks’ // (a) fortnight // fourteen/ 14 
days’ 
10      (1/one) month(‘s) rent NOT one month 
Section 2, Questions 11-20 
11      (her) daughter (Anna) // Anna // Ana // (her) child 
12      (a) practice // practices 
13      (about) 6 // six (doctors) 
14      (about) 4 // four (doctors) 
15      better // more efficient // faster 
16      elderly // old // older 
17      back problems/trouble // bad backs 
18      9 // nine (am) // 9.00 // nine/9 o’clock 
19      EITHER ORDER  
B // unemployed people  
E // pregnant women 
20      (£) 5 // five (pounds) 
Section 3, Questions 21-30 
21      Politics 
22      (West) Africa 
23      1990 to 1992 NOT 1993 
24     Teach South 
25      rural co(-)operative 
26      Geography 
27      (Form) 5/five/V 
28     (very) homesick // missed (my/his) family // 
homesickness 
29      favourite subject ACCEPT favorite 
30      (many) (useful) applications 
Section 4, Questions 31—40 
31      A 
32      B // osteoporosis 
33      B // relaxation therapy 
34      C // its response to injury often results in more 
damage 
35      A // for a maximum of two days 
36      B // worsens existing back pain 
37      B // Recommended in certain circumstances 
38      A // Strongly recommended 
39      B // Recommended in certain circumstances 
40      C // Not recommended 
 
 

If you score… (original source guidance, not a new scoring rule)
0–17: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
18–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


1. city centre / city centre itself / the city centre / the city centre itself / city center / city center itself / the city center / the city center itself

2. 250 to 500 / 250 to 500 pounds / 250 to about 500 / 250 to about 500 pounds / 250 to £ 500 / 250 to £ 500 pounds / 250 to £ about 500 / 250 to £about 500 / 250 to £ about 500 pounds / 250 to £about 500 pounds / 250 pounds to 500 / 250 pounds to 500 pounds / 250 pounds to about 500 / 250 pounds to about 500 pounds / 250 pounds to £ 500 / 250 pounds to £ 500 pounds / 250 pounds to £ about 500 / 250 pounds to £about 500 / 250 pounds to £ about 500 pounds / 250 pounds to £about 500 pounds / £ 250 to 500 / £250 to 500 / £ 250 to 500 pounds / £250 to 500 pounds / £ 250 to about 500 / £250 to about 500 / £ 250 to about 500 pounds / £250 to about 500 pounds / £ 250 to £ 500 / £250 to £ 500 / £ 250 to £ 500 pounds / £250 to £ 500 pounds / £ 250 to £ about 500 / £250 to £about 500 / £ 250 to £ about 500 pounds / £250 to £about 500 pounds / £ 250 pounds to 500 / £250 pounds to 500 / £ 250 pounds to 500 pounds / £250 pounds to 500 pounds / £ 250 pounds to about 500 / £250 pounds to about 500 / £ 250 pounds to about 500 pounds / £250 pounds to about 500 pounds / £ 250 pounds to £ 500 / £250 pounds to £ 500 / £ 250 pounds to £ 500 pounds / £250 pounds to £ 500 pounds / £ 250 pounds to £ about 500 / £250 pounds to £about 500 / £ 250 pounds to £ about 500 pounds / £250 pounds to £about 500 pounds / 250-500 / 250-500 pounds / £ 250-500 / £250-500 / £ 250-500 pounds / £250-500 pounds

3. garden / a garden

4. 325 / 325 pounds / £ 325 / £325 / £ 325 pounds / £325 pounds

5. water / water bill / water bills / the water / the water bill / the water bills

6. telephone / telephone rental / the telephone / the telephone rental / phone / phone rental / the phone / the phone rental

7. Wednesday / Wed / Wed afternoon

8. employer / your employer

9. two weeks / 2 weeks / 2 wks / fortnight / a fortnight / fourteen days / 14 days

10. month rent / month's rent / 1 month rent / 1 month's rent / one month rent / one month's rent

### Part 2 · source page 153

149
Answer key 
 
TEST 1 
 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN ALL 
ANSWERS. ( Where alternative spellings are accepted these are stated in the key.) 
 
Section 1, Questions 1-10 
1      (the) city centre (itself) ACCEPT center 
2      (£) 250 (pounds) (to) (£) (about) 500 (pounds) 
3      (a) garden 
4      (£) 325 (pounds) 
5      (the) water (bill(s)) 
6      (the) telephone/phone (rental) 
7      Wednesday/Wed (afternoon) 
8      (your) employer 
9     two/2 weeks’/wks’ // (a) fortnight // fourteen/ 14 
days’ 
10      (1/one) month(‘s) rent NOT one month 
Section 2, Questions 11-20 
11      (her) daughter (Anna) // Anna // Ana // (her) child 
12      (a) practice // practices 
13      (about) 6 // six (doctors) 
14      (about) 4 // four (doctors) 
15      better // more efficient // faster 
16      elderly // old // older 
17      back problems/trouble // bad backs 
18      9 // nine (am) // 9.00 // nine/9 o’clock 
19      EITHER ORDER  
B // unemployed people  
E // pregnant women 
20      (£) 5 // five (pounds) 
Section 3, Questions 21-30 
21      Politics 
22      (West) Africa 
23      1990 to 1992 NOT 1993 
24     Teach South 
25      rural co(-)operative 
26      Geography 
27      (Form) 5/five/V 
28     (very) homesick // missed (my/his) family // 
homesickness 
29      favourite subject ACCEPT favorite 
30      (many) (useful) applications 
Section 4, Questions 31—40 
31      A 
32      B // osteoporosis 
33      B // relaxation therapy 
34      C // its response to injury often results in more 
damage 
35      A // for a maximum of two days 
36      B // worsens existing back pain 
37      B // Recommended in certain circumstances 
38      A // Strongly recommended 
39      B // Recommended in certain circumstances 
40      C // Not recommended 
 
 

If you score… (original source guidance, not a new scoring rule)
0–17: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
18–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


11. daughter / daughter Anna / her daughter / her daughter Anna / Anna / Ana / child / her child

12. practice / a practice / practices

13. 6 / 6 doctors / about 6 / about 6 doctors / six / six doctors / about six / about six doctors

14. 4 / 4 doctors / about 4 / about 4 doctors / four / four doctors / about four / about four doctors

15. better / more efficient / faster

16. elderly / old / older

17. back problems / back trouble / bad backs

18. 9 / nine / nine am / 9.00 / 9:00 / nine o'clock / 9 o'clock

19. B E / B, E / B and E / B & E / B; E / B/E / B,E / BE / E B / E, B / E and B / E & B / E; B / E/B / E,B / EB / B pregnant women / B, pregnant women / B and pregnant women / B & pregnant women / B; pregnant women / B/pregnant women / B,pregnant women / pregnant women B / pregnant women, B / pregnant women and B / pregnant women & B / pregnant women; B / pregnant women/B / pregnant women,B / unemployed people E / unemployed people, E / unemployed people and E / unemployed people & E / unemployed people; E / unemployed people/E / unemployed people,E / E unemployed people / E, unemployed people / E and unemployed people / E & unemployed people / E; unemployed people / E/unemployed people / E,unemployed people / unemployed people pregnant women / unemployed people, pregnant women / unemployed people and pregnant women / unemployed people & pregnant women / unemployed people; pregnant women / unemployed people/pregnant women / unemployed people,pregnant women / pregnant women unemployed people / pregnant women, unemployed people / pregnant women and unemployed people / pregnant women & unemployed people / pregnant women; unemployed people / pregnant women/unemployed people / pregnant women,unemployed people

20. 5 / £ 5 / £5 / five / five pounds

### Part 3 · source page 153

149
Answer key 
 
TEST 1 
 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN ALL 
ANSWERS. ( Where alternative spellings are accepted these are stated in the key.) 
 
Section 1, Questions 1-10 
1      (the) city centre (itself) ACCEPT center 
2      (£) 250 (pounds) (to) (£) (about) 500 (pounds) 
3      (a) garden 
4      (£) 325 (pounds) 
5      (the) water (bill(s)) 
6      (the) telephone/phone (rental) 
7      Wednesday/Wed (afternoon) 
8      (your) employer 
9     two/2 weeks’/wks’ // (a) fortnight // fourteen/ 14 
days’ 
10      (1/one) month(‘s) rent NOT one month 
Section 2, Questions 11-20 
11      (her) daughter (Anna) // Anna // Ana // (her) child 
12      (a) practice // practices 
13      (about) 6 // six (doctors) 
14      (about) 4 // four (doctors) 
15      better // more efficient // faster 
16      elderly // old // older 
17      back problems/trouble // bad backs 
18      9 // nine (am) // 9.00 // nine/9 o’clock 
19      EITHER ORDER  
B // unemployed people  
E // pregnant women 
20      (£) 5 // five (pounds) 
Section 3, Questions 21-30 
21      Politics 
22      (West) Africa 
23      1990 to 1992 NOT 1993 
24     Teach South 
25      rural co(-)operative 
26      Geography 
27      (Form) 5/five/V 
28     (very) homesick // missed (my/his) family // 
homesickness 
29      favourite subject ACCEPT favorite 
30      (many) (useful) applications 
Section 4, Questions 31—40 
31      A 
32      B // osteoporosis 
33      B // relaxation therapy 
34      C // its response to injury often results in more 
damage 
35      A // for a maximum of two days 
36      B // worsens existing back pain 
37      B // Recommended in certain circumstances 
38      A // Strongly recommended 
39      B // Recommended in certain circumstances 
40      C // Not recommended 
 
 

If you score… (original source guidance, not a new scoring rule)
0–17: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
18–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


21. Politics

22. Africa / West Africa

23. 1990 to 1992 / 1990-1992

24. Teach South

25. rural cooperative / rural co-operative

26. Geography

27. 5 / Form 5 / five / Form five / V / Form V

28. homesick / very homesick / missed family / missed my family / missed his family / homesickness

29. favourite subject / favorite subject

30. applications / useful applications / many applications / many useful applications

### Part 4 · source page 153

149
Answer key 
 
TEST 1 
 
LISTENING 
 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN ALL 
ANSWERS. ( Where alternative spellings are accepted these are stated in the key.) 
 
Section 1, Questions 1-10 
1      (the) city centre (itself) ACCEPT center 
2      (£) 250 (pounds) (to) (£) (about) 500 (pounds) 
3      (a) garden 
4      (£) 325 (pounds) 
5      (the) water (bill(s)) 
6      (the) telephone/phone (rental) 
7      Wednesday/Wed (afternoon) 
8      (your) employer 
9     two/2 weeks’/wks’ // (a) fortnight // fourteen/ 14 
days’ 
10      (1/one) month(‘s) rent NOT one month 
Section 2, Questions 11-20 
11      (her) daughter (Anna) // Anna // Ana // (her) child 
12      (a) practice // practices 
13      (about) 6 // six (doctors) 
14      (about) 4 // four (doctors) 
15      better // more efficient // faster 
16      elderly // old // older 
17      back problems/trouble // bad backs 
18      9 // nine (am) // 9.00 // nine/9 o’clock 
19      EITHER ORDER  
B // unemployed people  
E // pregnant women 
20      (£) 5 // five (pounds) 
Section 3, Questions 21-30 
21      Politics 
22      (West) Africa 
23      1990 to 1992 NOT 1993 
24     Teach South 
25      rural co(-)operative 
26      Geography 
27      (Form) 5/five/V 
28     (very) homesick // missed (my/his) family // 
homesickness 
29      favourite subject ACCEPT favorite 
30      (many) (useful) applications 
Section 4, Questions 31—40 
31      A 
32      B // osteoporosis 
33      B // relaxation therapy 
34      C // its response to injury often results in more 
damage 
35      A // for a maximum of two days 
36      B // worsens existing back pain 
37      B // Recommended in certain circumstances 
38      A // Strongly recommended 
39      B // Recommended in certain circumstances 
40      C // Not recommended 
 
 

If you score… (original source guidance, not a new scoring rule)
0–17: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
18–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


31. A

32. B / osteoporosis

33. B / relaxation therapy

34. C / its response to injury often results in more damage

35. A / for a maximum of two days

36. B / worsens existing back pain

37. B / Recommended in certain circumstances

38. A / Strongly recommended

39. B / Recommended in certain circumstances

40. C / Not recommended

## A 类阅读

### Academic Reading · source page 154

Answer key 
 
 150
ACADEMIC READING 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN ALL 
ANSWERS. 
 
Reading Passage 1, Questions 1-14 
1      iv // Undeveloped for centuries 
2      i // How the reaction principle works 
3      v // The first rockets 
4     vii // Rockets for military use 
5      B // space travel became a reality 
6      D // from the late nineteenth century to the present 
day 
7      A // the Chinese 
8     A // the Chinese 
9      B // the Indians 
10      E //the Americans 
11      B 
12      E 
13      F 
14     G 
Reading Passage 2, Questions 15-28 
15      B // are strongly linked to cigarette smoking 
16      A // inhibits the flow of oxygen to the heart 
17      C // formation of blood clots 
18      NO // N 
19     NOT GIVEN // NG 
20     YES // Y 
21      NOT GIVEN // NG 
22      E // is more harmful to non-smokers than to 
smokers 
23     G // is more likely to be at risk of contracting 
various cancers 
24     H // opposes smoking and publishes research on 
the subject 
25      A // a finding of the UCSF study 
26      B // an opinion of the UCSF study 
27      B // an opinion of the UCSF study 
28     C // a finding of the EPA report 
Reading Passage 3, Questions 29-40 
29     iv // Explaining the inductive method 
30     vii // The role of hypotheses in scientific research 
31      iii // The testing of hypotheses 
32      v // Anticipating results before data is collected 
33     vi // How research is done and how it is reported 
34 & 35      IN EITHER ORDER 
B  
F 
36      YES // Y 
37      NO // N 
38     NOT GIVEN // NG 
39     YES // Y 
40     D // to help Ph.D students by explaining different 
conceptions of the research process 
 
 

If you score… (original source guidance, not a new scoring rule)
0–13: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–25: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
26–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.


1. iv

2. i

3. v

4. vii

5. B

6. D

7. A

8. A

9. B

10. E

11. B

12. E

13. F

14. G

15. B

16. A

17. C

18. NO

19. NOT GIVEN

20. YES

21. NOT GIVEN

22. E

23. G

24. H

25. A

26. B

27. B

28. C

29. iv

30. vii

31. iii

32. v

33. vi

34. B / F

35. B / F

36. YES

37. NO

38. NOT GIVEN

39. YES

40. D

## A 类写作

### Writing material: c3-t1-w-1

Both original charts inspected at full resolution. Bar chart: Japanese tourists travelling abroad, millions, annually 1985–1995. Approximate heights: 1985 5.0; 1986 5.6; 1987 6.8; 1988 8.5; 1989 9.7; 1990 11.0; 1991 10.6; 1992 11.8; 1993 12.0; 1994 13.5; 1995 15.3 million. The total increases substantially, with a small fall in 1991 and little change in 1993. Line chart: Australia's share of Japan's tourist market, percentages coming to Australia. Labelled plotted points run from 1985 to 1994; the axis also labels 1995 but no value is plotted there. Approximate shares: 1985 2%; 1986 3%; 1987 4%; 1988 just under 5%; 1989 a little over 4%; 1990 just under 5%; 1991 just over 5%; 1992 nearly 6%; 1993 just over 6%; 1994 6%. The share grows overall, with a dip in 1989 and a small decline after the 1993 peak. Do not invent an Australian share for 1995 or confuse percentages with millions. An unlabelled left-hand baseline point is not a basis for inventing an additional year. All bar and line readings are approximate, not exact tabulated figures.



### Writing material: c3-t1-w-2

The stated position is an opinion for evaluation. A supported agreement, disagreement or qualified position is valid; do not require a predetermined stance.



## 口语
