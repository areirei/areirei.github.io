# 剑雅 3 · Test 1

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/218359ebcdd613712bd0e62628eac0d36096b39e605255e980daaaf21a05c8de.jpg; PDF page 12; full -->

```text
Test1 — LISTENING
SECTION1 Questions1–10
Complete the notes below.
Example — Name of agent: Flagstone
Areas dealt with: (1) __________; north suburbs
Rent: from (2) £ __________ to £ __________ a month
Depends on: the area; availability of (3) __________; garage
Properties available:
West Park Road — rent (4) £ __________ a month, including (5) __________
Tithe Road — rent £380 a month, including (6) __________ rental
Viewing arrangements: meet at office on (7) __________ at5.00pm
Need: letter from bank; reference from (8) __________
Must: give (9) __________ notice of moving in; give deposit of (10) __________; pay for contract.
[The original note-completion instruction states no word limit here; none is added.]
```

[Original question page](assets/218359ebcdd613712bd0e62628eac0d36096b39e605255e980daaaf21a05c8de.jpg)

### Part 2

<!-- Source: /api/assets/d3cd291cf38b56c9b347894db2be34d3f0e03f999af9092d20b15304955fd530.jpg; PDF page 13; full -->

```text
Listening 
 9 
SECTON 2         Questions 11-20  
 
Questions 11 and 12 
 
Write NO MORE THAN THREE WORDS for each answer. 
 
11     Who is Mrs Sutton worried about? 
 
…………………………………………….. 
 
12     What is the name for a group of family doctors working in the same building together? 
 
……………………………………….. 
 
Questions 13-17 
 
Complete the table below. 
 
Write NO MORE THAN THREE WORDS OR A NUMBER for each answer. 
 
Name of Health 
Centre 
Number of doctors Other information Information about 
doctors 
Dean End 13............................. Appointment system 
15.............................  
than South Hay 
Dr Jones is good with 
16............................. 
patients. 
Dr Shaw is good with 
small children. 
South Hay 14............................. Building less modern than 
Dean End 
Dr Williams helps people 
with 17............................. 
            ………………….Name of Health Centre | Number of doctors | Other information | Information about doctors
Dean End | (13) __________ | Appointment system (15) __________ than South Hay | Dr Jones is good with (16) __________ patients. Dr Shaw is good with small children.
South Hay | (14) __________ | Building less modern than Dean End | Dr Williams helps people with (17) __________.
```

[Original question page](assets/d3cd291cf38b56c9b347894db2be34d3f0e03f999af9092d20b15304955fd530.jpg)

<!-- Source: /api/assets/58a5d63dbf16cfd3bf4d8a5ab0128390c61cf32fb2439b37088208624ba5d4ef.jpg; PDF page 14; full -->

```text
Test 1 
 10
Questions 18-20  
 
Question 18 
 
Write NO MORE THAN TWO WORDS OR A NUMBER. 
 
Doctors start seeing patients at the Health Centre from........................o’clock. 
 
Question 19 
 
Choose TWO letters A-E. 
 
Which TWO groups of patients receive free medication? 
A     people over 17 years old 
B     unemployed people 
C     non-UK residents 
D     people over 60 years old 
E     pregnant women 
 
Question 20 
 
Write NO MORE THAN TWO WORDS OR A NUMBER 
 
The charge for one item of medication is about £..................................
```

[Original question page](assets/58a5d63dbf16cfd3bf4d8a5ab0128390c61cf32fb2439b37088208624ba5d4ef.jpg)

### Part 3

<!-- Source: /api/assets/011a71242bf90db4f1ed1a3b01c71dbcc9ddded6145f0ca25a894a54d6916c0a.jpg; PDF page 15; full -->

```text
SECTION3 Questions21–30
Complete the notes below. Write NUMBERS AND/OR NO MORE THAN THREE WORDS for each answer.
NOTES ON APPLICATION
Name: Jonathan Briggs
Degree: Economics and (21) __________
Teaching experience: Volunteer Teacher
Location: (22) __________
Dates: (23) __________
Volunteer Organisation: (24) __________
Type of school: (25) __________
Subjects taught:
• (26) __________ — Forms1,2and3
• English — Form (27) __________
• Agricultural Science — Form6
Other responsibilities: ran school farm
NOTES (continued)
Reasons for wanting to leave in first year: (28) __________; few teaching resources
Reasons for wanting to extend tour: success of cattle breeding project; obtained funds for farm buildings
Reasons for wanting to train to teach Geography: It is his (29) __________; It has many (30) __________.
```

[Original question page](assets/011a71242bf90db4f1ed1a3b01c71dbcc9ddded6145f0ca25a894a54d6916c0a.jpg)

### Part 4

<!-- Source: /api/assets/1be1ca267c1b7f52b867eea45d86da6e1d01412394bbc31e26930da03c1b572e.jpg; PDF page 16; full -->

```text
Test 1 
 12
SECTION 4        Questions 31-40 
 
Questions 31-36 
 
Choose the correct letters A-C. 
 
31     Which column of the bar chart represents the figures quoted? 
 
 
 
Original bar options A/B/C retained: people with back pain, UK daily figures; axis labels250,000,500,000,1,000,000.
32     According to the speaker, the main cause of back pain in women is 
A     pregnancy.  
B     osteoporosis.  
C     lack of exercise. 
 
33    As treatment for back pain the Clinic mainly recommends 
A     pain killers. 
B     relaxation therapy. 
C     exercise routines. 
 
34     The back is different from other parts of the body because 
A     it is usually better at self-repair. 
B     a back injury is usually more painful. 
C     its response to injury often results in more damage. 
 
35     Bed rest is advised 
A     for a maximum of two days. 
B     for extreme pain only. 
C     for pain lasting more than two days. 
 
36     Being overweight 
A     is a major source of back pain. 
B     worsens existing back pain. 
C     reduces the effectiveness of exercise.
```

[Original question page](assets/1be1ca267c1b7f52b867eea45d86da6e1d01412394bbc31e26930da03c1b572e.jpg)

![Original figure](assets/1be1ca267c1b7f52b867eea45d86da6e1d01412394bbc31e26930da03c1b572e.jpg)

<!-- Source: /api/assets/d67472b499342b6d1b4307f5547d9307d4f67a88af3d7869f1ac525eceaa894b.jpg; PDF page 17; full -->

```text
Questions37–40: Choose the correct letters A–C.
A Strongly recommended
B Recommended in certain circumstances
C Not recommended
Example: Diet if overweight — A.
37 Buy special orthopaedic chairs: A / B / C
Example: Buy orthopaedic mattresses — B.
38 Buy shock-absorbing inserts: A / B / C
39 Wear flat shoes: A / B / C
40 Buy TENS machine: A / B / C
```

[Original question page](assets/d67472b499342b6d1b4307f5547d9307d4f67a88af3d7869f1ac525eceaa894b.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/d21e57309c89e8250424148ccc5f18edd80453469678843d1d5ca3dfaaed2398.jpg; PDF page 18; full -->

```text
Test 1 
 14
 READING_  
 
READING PASSAGE 1 
 
You should spend about 20 minutes on Questions 1-14 which are based on Reading Passage 1 on 
the following pages. 
 
Questions 1-4 
 
Reading Passage 1 has six paragraphs A-F. 
Choose the most suitable headings for paragraphs B-E from the list of headings below. 
Write the appropriate numbers i-ix in boxes 1—4 on your answer sheet. 
 
 List of Headings 
i How the reaction principle works 
ii The impact of the reaction principle 
iii Writers’ theories of the reaction principle 
iv Undeveloped for centuries 
v The first rockets 
vi The first use of steam 
vii Rockets for military use 
viii Developments of fire 
ix What’s next? 
 
Example 
Paragraph A  Answer 
ii  
 
1      Paragraph B 
 
2      Paragraph C 
 
3      Paragraph D 
 
4      Paragraph E 
 
Example 
Paragraph F  Answer 
ix
```

[Original question page](assets/d21e57309c89e8250424148ccc5f18edd80453469678843d1d5ca3dfaaed2398.jpg)

<!-- Source: /api/assets/4ff2781abc5c9b6ab9c7f97588bfcbbb6bec252902a8bd0ddcafd7510bce368a.jpg; PDF page 19; full -->

```text
Reading 
 15
THE ROCKET - FROM EAST TO WEST 
 
A   The concept of the rocket, or rather the mechanism behind the idea of propelling an 
object into the air, has been around for well over two thousand years. However, it 
wasn’t until the discovery of the reaction principle, which was the key to space travel 
and so represents one of the great milestones in the history of scientific thought, that 
rocket technology was able to develop. Not only did it solve a problem that had 
intrigued man for ages, but, more importantly, it literally opened the door to 
exploration of the universe. 
 
B   An intellectual breakthrough, brilliant though it may be, does not automatically 
ensure that the transition is made from theory to practice. Despite the fact that 
rockets had been used sporadically for several hundred years, they remained a 
relatively minor artefact of civilisation until the twentieth century. Prodigious efforts, 
accelerated during two world wars, were required before the technology of primitive 
rocketry could be translated into the reality of sophisticated astronauts. It is strange 
that the rocket was generally ignored by writers of fiction to transport their heroes to 
mysterious realms beyond the Earth, even though it had been commonly used in 
fireworks displays in China since the thirteenth century. The reason is that nobody 
associated the reaction principle with the idea of travelling through space to a 
neighbouring world. 
 
C   A simple analogy can help us to understand how a rocket operates. It is much like a 
machine gun mounted on the rear of a boat. In reaction to the backward discharge of 
bullets, the gun, and hence the boat, move forwards. A rocket motor’s ‘bullets’ are 
minute, high-speed particles produced by burning propellants in a suitable chamber. 
The reaction to the ejection of these small particles causes the rocket to move 
forwards. There is evidence that the reaction principle was applied practically well 
before the rocket was invented. In his Noctes Atticae or Greek Nights, Aulus Gellius 
describes ‘the pigeon of Archytas’, an invention dating back to about 360 BC. 
Cylindrical in shape, made of wood, and hanging from string, it was moved to and fro 
by steam blowing out from small exhaust ports at either end. The reaction to the 
discharging steam provided the bird with motive power. 
 
D   The invention of rockets is linked inextricably with the invention of ‘black powder’. 
Most historians of technology credit the Chinese with its discovery. They base their 
belief on studies of Chinese writings or on the notebooks of early Europeans who 
settled in or made long visits to China to study its history and civilisation. It is 
probable that, some time in the tenth century, black powder was first compounded 
from its basic ingredients of saltpetre, charcoal and sulphur. But this does not mean 
that it was immediately used to propel rockets. By the thirteenth century, powder-
propelled fire arrows had become rather common. The Chinese relied on this type of 
technological development to produce incendiary projectiles of many sorts,
```

[Original question page](assets/4ff2781abc5c9b6ab9c7f97588bfcbbb6bec252902a8bd0ddcafd7510bce368a.jpg)

<!-- Source: /api/assets/e3c0cec0582c964e3524789b9513783baedda1d621e595faf5e9368051a47a7a.jpg; PDF page 20; full -->

```text
Test 1 
 16
      explosive grenades and possibly cannons to repel their enemies. One such weapon 
was the ‘basket of fire’ or, as directly translated from Chinese, the ‘arrows like flying 
leopards’. The 0.7 metre-long arrows, each with a long tube of gunpowder attached 
near the point of each arrow, could be fired from a long, octagonal-shaped basket at 
the same time and had a range of 400 paces. Another weapon was the ‘arrow as a 
flying sabre’, which could be fired from crossbows. The rocket, placed in a similar 
position to other rocket-propelled arrows, was designed to increase the range. A 
small iron weight was attached to the 1.5m bamboo shaft, just below the feathers, to 
increase the arrow’s stability by moving the centre of gravity to a position below the 
rocket. At a similar time, the Arabs had developed the ‘egg which moves and burns’. 
This ‘egg’ was apparently full of gunpowder and stabilised by a 1.5m tail. It was fired 
using two rockets attached to either side of this tail. 
 
E    It was not until the eighteenth century that Europe became seriously interested in the 
possibilities of using the rocket itself as a weapon of war and not just to propel other 
weapons. Prior to this, rockets were used only in pyrotechnic displays. The incentive 
for the more aggressive use of rockets came not from within the European continent 
but from far-away India, whose leaders had built up a corps of rocketeers and used 
rockets successfully against the British in the late eighteenth century. The Indian 
rockets used against the British were described by a British Captain serving in India 
as ‘an iron envelope about 200 millimetres long and 40 millimetres in diameter with 
sharp points at the top and a 3m-long bamboo guiding stick’. In the early nineteenth 
century the British began to experiment with incendiary barrage rockets. The British 
rocket differed from the Indian version in that it was completely encased in a stout, 
iron cylinder, terminating in a conical head, measuring one metre in diameter and 
having a stick almost five metres long and constructed in such a way that it could be 
firmly attached to the body of the rocket. The Americans developed a rocket, 
complete with its own launcher, to use against the Mexicans in the mid-nineteenth 
century. A long cylindrical tube was propped up by two sticks and fastened to the top 
of the launcher, thereby allowing the rockets to be inserted and  lit from the other 
end.  However, the results were sometimes not that impressive as the behaviour of 
the rockets in flight was less than predictable. 
 
F   Since then, there have been huge developments in rocket technology, often with 
devastating results in the forum of war. Nevertheless, the modern day space 
programs owe their success to the humble beginnings of those in previous centuries 
who developed the foundations of the reaction principle. Who knows what it will be 
like in the future?
```

[Original question page](assets/e3c0cec0582c964e3524789b9513783baedda1d621e595faf5e9368051a47a7a.jpg)

<!-- Source: /api/assets/190f572a525f1d437322ba8e0ae4f72ea7221d1d987dfafc3e0889be08f935b0.jpg; PDF page 21; full -->

```text
Reading 
 17
Questions 5 and 6 
 
Choose the appropriate letters A-D and write them in boxes 5 and 6 on your answer sheet. 
 
5    The greatest outcome of the discovery of the reaction principle was that 
A     rockets could be propelled into the air. 
B     space travel became a reality. 
C     a major problem had been solved. 
D     bigger rockets were able to be built. 
 
6    According to the text, the greatest progress in rocket technology was made 
A     from the tenth to the thirteenth centuries. 
B     from the seventeenth to the nineteenth centuries. 
C     from the early nineteenth to the late nineteenth century. 
D     from the late nineteenth century to the present day. 
 
Questions 7-10 
 
From the information in the text, indicate who FIRST invented or used the items in the list 
below. 
Write the appropriate letters A-E in boxes 7-10 on your answer sheet. 
NB You may use any letter more than once. 
 
Example 
rockets for displays  Answer 
A  
 
7    black powder 
 
8    rocket-propelled arrows for fighting 
 
9    rockets as war weapons  
 
10    the rocket launcher 
 
FIRST invented or used by 
A the Chinese 
B the Indians 
C the British 
D the Arabs 
E the Americans
```

[Original question page](assets/190f572a525f1d437322ba8e0ae4f72ea7221d1d987dfafc3e0889be08f935b0.jpg)

<!-- Source: /api/assets/a082c7e94697de3b3baaa9830ff23bc379833aa7c9d346906669efa913aa7022.jpg; PDF page 22; full -->

```text
Test 1 
 18
Questions 11-14 
 
Look at the drawings of different projectiles below, A-H, and the names of types of projectiles given 
in the passage, Questions 11-14. Match each name with one drawing. 
 
Write the appropriate letters A-H in boxes 11-14 on your answer sheet.  
 
Example 
The Greek ‘pigeon of Archytas’ 
Answer 
C  
 
11     The Chinese ‘basket of fire’ 
 
12     The Arab ‘egg which moves and burns’ 
 
13    The Indian rocket 
 
14    The British barrage rocket
```

[Original question page](assets/a082c7e94697de3b3baaa9830ff23bc379833aa7c9d346906669efa913aa7022.jpg)

![Original figure](assets/a082c7e94697de3b3baaa9830ff23bc379833aa7c9d346906669efa913aa7022.jpg)

<!-- Source: /api/assets/1b6c3f5c30ae5e25cff8b0c3ce717b9127e46f25176f60d1b26583cbf0e43b11.jpg; PDF page 23; full -->

```text
Reading 
 19
READING PASSAGE 2 
 
You should spend about 20 minutes on Questions 15-28 which are based on Reading Passage 2 below. 
 
                          
                         The Risks of Cigarette  
                         Smoke 
 
 
Discovered in the early 1800s and named nicotianine, the oily essence now called 
nicotine is the main active insredient of tobacco. Nicotine, however, is only a small 
component of cigarette smoke, which contains more than 4,700 chemical compounds, 
including 43 cancer-causing substances. In recent times, scientific research has been 
providing evidence that years of cigarette smoking vastly increases the risk of 
developing fatal medical conditions. 
 
In addition to being responsible for more than 85 per cent of lung cancers, smoking is 
associated with cancers of, amongst others, the mouth, stomach and kidneys, and is 
thought to cause about 14 per cent of leukemia and cervical cancers. In 1990, smoking 
caused more than 84,000 deaths, mainly resulting from such problems as pneumonia, 
bronchitis and influenza. Smoking, it is believed, is responsible for 30 per cent of all 
deaths from cancer and clearly represents the most important preventable cause of 
cancer in countries like the United States today. 
 
Passive smoking, the breathing in of the side-stream smoke from the burning of 
tobacco between puffs or of the smoke exhaled by a smoker, also causes a serious 
health risk. A report published in 1992 by the US Environmental Protection Agency 
(EPA) emphasized the health dangers, especially from side-stream smoke. This type of 
smoke contains more, smaller particles and is therefore more likely to be deposited 
deep in the lungs. On the basis of this report, the EPA has classified environmental 
tobacco smoke in the highest risk category for causing cancer. 
 
As an illustration of the health risks, in the case of a married couple where one partner 
is a smoker and one a non-smoker, the latter is believed to have a 30 per cent higher 
risk of death from heart disease because of passive smoking. The risk of lung cancer 
also increases over the years of exposure and the figure jumps to 80 per cent if the 
spouse has been smoking four packs a day for 20 years. It has been calculated that 17 
per cent of cases of lung cancer can be attributed to high levels of exposure to second-
hand tobacco smoke during childhood and adolescence.
```

[Original question page](assets/1b6c3f5c30ae5e25cff8b0c3ce717b9127e46f25176f60d1b26583cbf0e43b11.jpg)

<!-- Source: /api/assets/0ab14342d8574ce8d11f2dd6a8ef0c89484562f9db469043f6289a93bed8d60b.jpg; PDF page 24; full -->

```text
Test 1 
 20
A more recent study by researchers at the University of California at San Francisco (UCSF) 
has shown that second-hand cigarette smoke does more harm to non-smokers than to 
smokers. Leaving aside the philosophical question of whether anyone should have to 
breathe someone else’s cigarette smoke, the report suggests that the smoke experienced 
by many people in their daily lives is enough to produce substantial adverse effects on a 
person’s heart and lungs. 
 
The report, published in the Journal of the American Medical Association (AMA), was 
based on the researchers’ own earlier research but also includes a review of studies over 
the past few years. The American Medical Association represents about half of all US 
doctors and is a strong opponent of smoking. The study suggests that people who smoke 
cigarettes are continually damaging their cardiovascular system, which adapts in order to 
compensate for the effects of smoking. It further states that people who do not smoke do 
not have the benefit of their system adapting to the smoke inhalation. Consequently, the 
effects of passive smoking are far greater on non-smokers than on smokers. 
 
This report emphasizes that cancer is not caused by a single element in cigarette smoke; 
harmful effects to health are caused by many components. Carbon monoxide, for example, 
competes with oxygen in red blood cells and interferes with the blood’s ability to deliver life-
giving oxygen to the heart. Nicotine and other toxins in cigarette smoke activate small 
blood cells called platelets, which increases the likelihood of blood clots, thereby affecting 
blood circulation throughout the body. 
 
The researchers criticize the practice of some scientific consultants who work with the 
tobacco industry for assuming that cigarette smoke has the same impact on smokers as it 
does on non-smokers. They argue that those scientists are underestimating the damage 
done by passive smoking and, in support of their recent findings, cite some previous 
research which points to passive smoking as the cause for between 30,000 and 60,000 
deaths from heart attacks each year in the United States. This means that passive smoking 
is the third most preventable cause of death after active smoking and alcohol-related 
diseases. 
 
The study argues that the type of action needed against passive smoking should be similar 
to that being taken against illegal drugs and AIDS (SIDA). The UCSF researchers maintain 
that the simplest and most cost-effective action is to establish smoke-free work places, 
schools and public places.
```

[Original question page](assets/0ab14342d8574ce8d11f2dd6a8ef0c89484562f9db469043f6289a93bed8d60b.jpg)

<!-- Source: /api/assets/1a1e8a5335d80e09466dc1f25b5b95c971b1196f09db6ae3bd00f3be90a71722.jpg; PDF page 25; full -->

```text
Reading 
 21
Questions 15-17 
 
Choose the appropriate letters A—D and write them in boxes 15—17 on your answer sheet. 
 
15    According to information in the text, leukaemia and pneumonia 
A     are responsible for 84,000 deaths each year. 
B     are strongly linked to cigarette smoking. 
C     are strongly linked to lung cancer. 
D     result in 30 per cent of deaths per year. 
 
16    According to information in the text, intake of carbon monoxide 
A     inhibits the flow of oxygen to the heart. 
B     increases absorption of other smoke particles. 
C     inhibits red blood cell formation. 
D     promotes nicotine absorption. 
 
17    According to information in the text, intake of nicotine encourages 
A     blood circulation through the body. 
B     activity of other toxins in the blood. 
C     formation of blood clots. 
D     an increase of platelets in the blood. 
 
 
Questions 18-21 
 
Do the following statements reflect the claims of the writer in Reading Passage 2?  
 
In boxes 18-21 on your answer sheet write 
 
YES                 if the statement reflects the claims of the writer 
NO                  if the statement contradicts the claims of the writer 
NOT GIVEN    if it is impossible to say what the writer thinks about this 
 
18    Thirty per cent of deaths in the United States are caused by smoking-related diseases. 
 
19    If one partner in a marriage smokes, the other is likely to take up smoking. 
 
20    Teenagers whose parents smoke are at risk of getting lung cancer at some time during their 
lives. 
21     Opponents of smoking financed the UCSF study.
```

[Original question page](assets/1a1e8a5335d80e09466dc1f25b5b95c971b1196f09db6ae3bd00f3be90a71722.jpg)

<!-- Source: /api/assets/a935fded44ef79e7bc8e14078ce825f9eba4ad7e17e830be445c1c9542c4b609.jpg; PDF page 26; full -->

```text
Test 1
 22
Questions 22-24

Choose ONE phrase from the list of phrases A—J below to complete each of the following sentences (Questions
22-24).

Write the appropriate letters in boxes 22—24 on your answer sheet.

22     Passive smoking ...

23     Compared with a non-smoker, a smoker ...

24     The American Medical Association ...

A includes reviews of studies in its reports.
B argues for stronger action against smoking in public places.
C is one of the two most preventable causes of death.
D is more likely to be at risk from passive smoking diseases.
E is more harmful to non-smokers than to smokers.
F is less likely to be at risk of contracting lung cancer.
G is more likely to be at risk of contracting various cancers.
H opposes smoking and publishes research on the subject.
I is just as harmful to smokers as it is to non-smokers.
J reduces the quantity of blood flowing around the body.
Questions 25-28

Classify the following statements as being

A   a finding of the UCSF study
B   an opinion of the UCSF study
C   a finding of the EPA report
D   an assumption of consultants to the tobacco industry

Write the appropriate letters A—D in boxes 25—28 on your answer sheet.

NB You may use any letter more than once.

25     Smokers’ cardiovascular systems adapt to the intake of environmental smoke.

26    There is a philosophical question as to whether people should have to inhale others’ smoke.

27     Smoke-free public places offer the best solution.

28    The intake of side-stream smoke is more harmful than smoke exhaled by a smoker.
```

[Original question page](assets/a935fded44ef79e7bc8e14078ce825f9eba4ad7e17e830be445c1c9542c4b609.jpg)

<!-- Source: /api/assets/65967d14cd5fab626ff126bcae00be42c4cf9ad25dca747487866f0dfddc9fa6.jpg; PDF page 27; full -->

```text
Reading 
 23
READING PASSAGE 3 
 
You should spend about 20 minutes on Questions 29-40 which are based on Reading Passage 3 on the following 
pages. 
 
Questions 29-33 
 
Reading Passage 3 has seven paragraphs A-G. 
 
Choose the most suitable headings for paragraphs C-G from the list of headings below.  
 
Write the appropriate numbers i-x in boxes 29-33 on your answer sheet. 
 
 List of Headings 
i The Crick and Watson approach to 
research 
ii Antidotes to bacterial infection 
iii The testing of hypotheses 
iv Explaining the inductive method 
v Anticipating results before data is 
collected 
vi How research is done and how it is 
reported 
vii The role of hypotheses in scientific 
research 
viii Deducing the consequences of 
hypotheses 
ix Karl Popper’s claim that the scientific 
method is hypothetico-deductive 
x The unbiased researcher 
 
Example 
Paragraph A 
Answer 
ix  
 
29     Paragraph C 
30     Paragraph D 
31     Paragraph E 
32     Paragraph F 
33     Paragraph G
```

[Original question page](assets/65967d14cd5fab626ff126bcae00be42c4cf9ad25dca747487866f0dfddc9fa6.jpg)

<!-- Source: /api/assets/2cc5e8f4619dbcde3c2155a9d7e4e64b0aeb2a5ad65b33ee696e7cc1c3ff9133.jpg; PDF page 28; full -->

```text
Test 1 
 24
THE 
SCIENTIFIC 
METHOD 
 
A   ‘Hypotheses,’ said Medawar in 1964, 
‘are imaginative and inspirational in 
character’; they are ‘adventures of the 
mind’. He was arguing in favour of the 
position taken by Karl Popper in The 
Logic of Scientific Discovery (1972, 3rd 
edition) that the nature of scientific 
method is hypothetico-deductive and 
not, as is generally believed, inductive. 
B    It is essential that you, as an intending 
researcher, understand the difference 
between these two interpretations of the 
research process so that you do not 
become discouraged or begin to suffer 
from a feeling of ‘cheating’ or not going 
about it the right way. 
C   The myth of scientific method is that it is 
inductive: that the formulation of 
scientific theory starts with the basic, 
raw evidence of the senses - simple, 
unbiased, unprejudiced observation. Out 
of these sensory data - commonly 
referred to as ‘facts’ — generalisations 
will form. The myth is that from a 
disorderly array of factual information 
an orderly, relevant theory will 
somehow emerge. However, the starting 
point of induction is an impossible one. 
D   There is no such thing as an unbiased 
observation. Every act of observation 
we make is a function of what we have 
seen or otherwise experienced in the 
past. All scientific work of an 
experimental or exploratory nature starts 
with some expectation about the 
outcome. This expectation is a 
hypothesis. Hypotheses provide the 
initiative and incentive for the inquiry 
and influence the method. It is in the 
light of an expectation that some 
observations are held to be relevant and 
some irrelevant, that one methodology 
is chosen and others discarded, that 
some experiments are conducted and 
others are not. Where is, your naive, 
pure and objective researcher now? 
E    Hypotheses arise by guesswork, or by 
inspiration, but having been formulated 
they can and must be tested rigorously, 
using the appropriate methodology. If 
the predictions you make as a result of 
deducing certain consequences from 
your hypothesis are not shown to be 
correct then you discard or modify your 
hypothesis. If the predictions turn out to 
be correct then your hypothesis has been 
supported and may be retained until 
such time as some further test shows it 
not to be correct. Once you have arrived 
at your hypothesis, which is a product of 
your imagination, you then proceed to a 
strictly logical and rigorous process, 
based upon deductive argument — 
hence the term ‘hypothetico-deductive’.
```

[Original question page](assets/2cc5e8f4619dbcde3c2155a9d7e4e64b0aeb2a5ad65b33ee696e7cc1c3ff9133.jpg)

<!-- Source: /api/assets/b32dd67bf2514ac1c4d14a0e8f7412b5a17014f831851f9d20cfb9b319ea1a6a.jpg; PDF page 29; full -->

```text
Reading 
 25
F    So don’t worry if you have some idea of 
what your results will tell you before 
you even begin to collect data; there are 
no scientists in existence who really wait 
until they have all the evidence in front 
of them before they try to work out what 
it might possibly mean. The closest we 
ever get to this situation is when 
something happens by accident; but 
even then the researcher has to 
formulate a hypothesis to be tested 
before being sure that, for example, a 
mould might prove to be a successful 
antidote to bacterial infection. 
G   The myth of scientific method is not 
only that it is inductive (which we have 
seen is incorrect) but also that the 
hypothetico-deductive method proceeds 
in a step-by-step, inevitable fashion. The 
hypothetico-deductive method describes 
the logical approach to much research 
work, but it does not describe the 
psychological behaviour that brings it 
about. This is much more holistic — 
involving guesses, reworkings, 
corrections, blind alleys and above all 
inspiration, in the deductive as well as 
the hypothetic component -than is 
immediately apparent from reading the 
final thesis or published papers. These 
have been, quite properly, organised into 
a more serial, logical order so that the 
worth of the output may be evaluated 
independently of the behavioural 
processes by which it was obtained. It is 
the difference, for example between the 
academic papers with which Crick and 
Watson demonstrated the structure of 
the DNA molecule and the fascinating 
book The Double Helix in which Watson 
(1968) described how they did it. From 
this point of view, ‘scientific method’ 
may more usefully be thought of as a 
way of writing up research rather than as 
a way of carrying it out.
```

[Original question page](assets/b32dd67bf2514ac1c4d14a0e8f7412b5a17014f831851f9d20cfb9b319ea1a6a.jpg)

<!-- Source: /api/assets/0f98b25a4f7f402248e5ab633bf6827624cc9f407377c3762ba985522aa651d0.jpg; PDF page 30; full -->

```text
Test 1 
 26
Questions 34 and 35 
 
In which TWO paragraphs in Reading Passage 3 does the writer give advice directly to the reader? 
 
Write the TWO appropriate letters (A—G) in boxes 34 and 35 on your answer sheet.  
 
Questions 36-39 
 
Do the following statements reflect the opinions of the writer in Reading Passage 3?  
 
In boxes 36-39 on your answer sheet write 
 
YES               if the statement reflects the opinion of the writer 
NO                 if the statement contradicts the opinion of the writer 
NOT GIVEN   if it is impossible to say what the writer thinks about this 
 
36    Popper says that the scientific method is hypothetico-deductive. 
37     If a prediction based on a hypothesis is fulfilled, then the hypothesis is confirmed as true. 
38     Many people carry out research in a mistaken way. 
39     The ‘scientific method’ is more a way of describing research than a way of doing it.  
Question 40 
 
Choose the appropriate letter A-D and write it in box 40 on your answer sheet. 
 
Which of the following statements best describes the writer’s main purpose in Reading Passage 3? 
 
A     to advise Ph.D students not to cheat while carrying out research 
B     to encourage Ph.D students to work by guesswork and inspiration 
C     to explain to Ph.D students the logic which the scientific research paper follows 
D     to help Ph.D students by explaining different conceptions of the research process
```

[Original question page](assets/0f98b25a4f7f402248e5ab633bf6827624cc9f407377c3762ba985522aa651d0.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/8a35519211f3f7f0cd82540c29eb554fa5cee5fb14878ef08e9c57aabcf6165a.jpg; PDF page 31; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show the number of Japanese tourists travelling abroad between 1985 and 1995 and Australia's share of the Japanese tourist market.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

[Text edition note: the complete original figure is retained for all plotted series and labels.]
```

[Original question page](assets/8a35519211f3f7f0cd82540c29eb554fa5cee5fb14878ef08e9c57aabcf6165a.jpg)

![Original figure](assets/8a35519211f3f7f0cd82540c29eb554fa5cee5fb14878ef08e9c57aabcf6165a.jpg)

### Task 2

<!-- Source: /api/assets/5c53f82f7b9c61ca096c7a5afab85acecc363d3ef1fb2caf2574bde58e2da199.jpg; PDF page 32; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic.

Popular events like the football World Cup and other international sporting occasions are essential in easing international tensions and releasing patriotic emotions in a safe way.

To what extent do you agree or disagree with this opinion?

You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.

You should write at least 250 words.
```

[Original question page](assets/5c53f82f7b9c61ca096c7a5afab85acecc363d3ef1fb2caf2574bde58e2da199.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/eb32a98ae1e261018514b87452be3cbb99210b3b768b9f23018b598cf26d7e41.jpg; PDF page 33; full -->

```text
Speaking 
 29
SPEAKING 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE 
Family 
•   Do you have a large family or a small family? 
•   Can you tell me something about them? 
•   How much time do you manage to spend with members of your family? 
•   What sorts of things do you like to do together? 
•   Did/Do you get on well with your family? [Why?] 
 
PART 2 
 
Describe a teacher who has influenced you in your education. 
You should say:  
where you met them  
what subject they taught  
what was special about them  
and explain why this person influenced you so much. 
You will have to talk about the 
topic for 1 to 2 minutes. You 
have one minute to think 
about what you’re going to 
say. You can make some notes 
to help you if you wish. 
 
PART 3  
Discussion topics:  
Developments in education 
Example questions: 
How has education changed in your country in the last 10 years? 
What changes do you foresee in the next 50 years? 
 
A national education system 
 
Example questions: 
How do the expectations of today’s school leavers compare with those of the previous 
generation? 
What role do you think extracurricular activities play in education? 
 
Different styles/methods of teaching and learning 
 
Example questions: 
What method of learning works best for you? 
How beneficial do you think it is to group students according to their level of ability?
```

[Original question page](assets/eb32a98ae1e261018514b87452be3cbb99210b3b768b9f23018b598cf26d7e41.jpg)

### Part 2

<!-- Source: /api/assets/eb32a98ae1e261018514b87452be3cbb99210b3b768b9f23018b598cf26d7e41.jpg; PDF page 33; full -->

```text
Speaking 
 29
SPEAKING 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE 
Family 
•   Do you have a large family or a small family? 
•   Can you tell me something about them? 
•   How much time do you manage to spend with members of your family? 
•   What sorts of things do you like to do together? 
•   Did/Do you get on well with your family? [Why?] 
 
PART 2 
 
Describe a teacher who has influenced you in your education. 
You should say:  
where you met them  
what subject they taught  
what was special about them  
and explain why this person influenced you so much. 
You will have to talk about the 
topic for 1 to 2 minutes. You 
have one minute to think 
about what you’re going to 
say. You can make some notes 
to help you if you wish. 
 
PART 3  
Discussion topics:  
Developments in education 
Example questions: 
How has education changed in your country in the last 10 years? 
What changes do you foresee in the next 50 years? 
 
A national education system 
 
Example questions: 
How do the expectations of today’s school leavers compare with those of the previous 
generation? 
What role do you think extracurricular activities play in education? 
 
Different styles/methods of teaching and learning 
 
Example questions: 
What method of learning works best for you? 
How beneficial do you think it is to group students according to their level of ability?
```

[Original question page](assets/eb32a98ae1e261018514b87452be3cbb99210b3b768b9f23018b598cf26d7e41.jpg)

### Part 3

<!-- Source: /api/assets/eb32a98ae1e261018514b87452be3cbb99210b3b768b9f23018b598cf26d7e41.jpg; PDF page 33; full -->

```text
Speaking 
 29
SPEAKING 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE 
Family 
•   Do you have a large family or a small family? 
•   Can you tell me something about them? 
•   How much time do you manage to spend with members of your family? 
•   What sorts of things do you like to do together? 
•   Did/Do you get on well with your family? [Why?] 
 
PART 2 
 
Describe a teacher who has influenced you in your education. 
You should say:  
where you met them  
what subject they taught  
what was special about them  
and explain why this person influenced you so much. 
You will have to talk about the 
topic for 1 to 2 minutes. You 
have one minute to think 
about what you’re going to 
say. You can make some notes 
to help you if you wish. 
 
PART 3  
Discussion topics:  
Developments in education 
Example questions: 
How has education changed in your country in the last 10 years? 
What changes do you foresee in the next 50 years? 
 
A national education system 
 
Example questions: 
How do the expectations of today’s school leavers compare with those of the previous 
generation? 
What role do you think extracurricular activities play in education? 
 
Different styles/methods of teaching and learning 
 
Example questions: 
What method of learning works best for you? 
How beneficial do you think it is to group students according to their level of ability?
```

[Original question page](assets/eb32a98ae1e261018514b87452be3cbb99210b3b768b9f23018b598cf26d7e41.jpg)
