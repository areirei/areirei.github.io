# 剑雅 13 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/f7aa31e2128a659571571eec3ce9bb86d4615bb998aca036ab1f84e42a9f14c4.jpg; PDF page 55; full -->

```text
Test 3
LISTENING
SECTION 1 Questions 1–10
Complete the notes below.
Write ONE WORD AND/OR A NUMBER for each answer.
Moving to Banford City
Example
Linda recommends living in suburb of: Dalton [example]
Accommodation
• Average rent: 1£.......................................... a month
Transport
• Linda travels to work by 2 ......................................... ..
• Limited 3 ........................................... in city centre
• Trains to London every 4 ....................................... minutes
• Poor train service at 5 ...... ..
Advantages of living in Banford
• New 6 ...................................... opened recently
• 7 ................... ….................... has excellent reputation
• Good 8 ........................................... on Bridge Street
Meet Linda
• Meet Linda on 9 .......................................... after 5.30 pm
• In the 10 ........................................... opposite the station
54
```

[Original question page](assets/f7aa31e2128a659571571eec3ce9bb86d4615bb998aca036ab1f84e42a9f14c4.jpg)

### Part 2

<!-- Source: /api/assets/933c4e9de73f3cfa6cd53b87e9c56eff2932da18fec88e0edd0c462e00106703.jpg; PDF page 56; full -->

```text
SECTION 2 Questions 11–20
Questions 11–16
What advantage does the speaker mention for each of the following physical activities?
Choose SIX answers from the box and write the correct letter, A–G, next to Questions 11–16.
Advantages
A not dependent on season
B enjoyable
C low risk of injury
D fitness level unimportant
E sociable
F fast results
G motivating
Physical activities
11 using a gym __________
12 running __________
13 swimming __________
14 cycling __________
15 doing yoga __________
16 training with a personal trainer __________
```

[Original question page](assets/933c4e9de73f3cfa6cd53b87e9c56eff2932da18fec88e0edd0c462e00106703.jpg)

<!-- Source: /api/assets/1775919071bcd619cd602ac861f27f75152651e3afe3d4f86fcd099d84a6e0c6.jpg; PDF page 57; full -->

```text
Test 3
Questions 17 and 18
Choose TWO letters, A-E.
For which TWO reasons does the speaker say people give up going to the gym?
A lack of time
B loss of confidence
C too much effort required
D high costs
E feeling less successful than others
Questions 19 and 20
Choose TWO letters, A-E.
Which TWO pieces of advice does the speaker give for setting goals?
A write goals down
B have achievable aims
C set a time limit
D give yourself rewards
E challenge yourself
```

[Original question page](assets/1775919071bcd619cd602ac861f27f75152651e3afe3d4f86fcd099d84a6e0c6.jpg)

### Part 3

<!-- Source: /api/assets/03fda1707aa00560ea3a7bd6a6a335cc142f34c7128e13962ab1c4bea3e38763.jpg; PDF page 58; full -->

```text
SECTION 3 Questions 21–30
Listening
Questions 21-24
Choose the correct letter, A, B or C.
Project on using natural dyes to colour fabrics
21 What first inspired Jim to choose this project?
A textiles displayed in an exhibition
B a book about a botanic garden
C carpets he saw on holiday
22 Jim eventually decided to do a practical investigation which involved
A using a range of dyes with different fibres.
B applying different dyes to one type of fibre.
C testing one dye and a range of fibres.
23 When doing his experiments, Jim was surprised by
A how much natural material was needed to make the dye.
B the fact that dyes were widely available on the internet
C the time that he had to leave the fabric in the dye.
24 What problem did Jim have with using tartrazine as a fabric dye?
A It caused a slight allergic reaction.
B It was not a permanent dye on cotton.
C It was ineffective when used on nylon.

57
```

[Original question page](assets/03fda1707aa00560ea3a7bd6a6a335cc142f34c7128e13962ab1c4bea3e38763.jpg)

<!-- Source: /api/assets/13d8674eab7214b17986ec7ea3129e76271725585222687a6a4d70243eaa5e42.jpg; PDF page 59; full -->

```text
Questions 25–30
Test 3
What problem is identified with each of the following natural dyes?
Choose SIX answers from the box and write the correct letter, A— H, next to
Questions 25-30.
Problems
A It is expensive.
B The colour is too strong.
C The colour is not long-lasting.
D It is very poisonous.
E It can damage the fabric.
F The colour may be unexpected.
G It is unsuitable for some fabrics.
H It is not generally available.
Natural dyes
25 turmeric
26 beetroot
27 Tyrian purple
28 logwood
29 cochineal
30 metal oxide
58
```

[Original question page](assets/13d8674eab7214b17986ec7ea3129e76271725585222687a6a4d70243eaa5e42.jpg)

### Part 4

<!-- Source: /api/assets/531d8f674fa43625989f356eba5d4b3a450f01efd5318e759e34d3079abf1a45.jpg; PDF page 60; full -->

```text
SECTION 4 Questions 31–40
Listening
Complete the notes below.
Write ONE WORD ONLY for each answer.

The sleepy lizard (tiliqua rugosa)
Description
• They are common in Western and South Australia
• They are brown, but recognisable by their blue 31....................
• They are relatively large
• Their diet consists mainly of 32....................
• Their main predators are large birds and 33....................
Navigation study
• One study found that lizards can use the 34....................to help
them navigate
Observations in the wild
• Observations show that these lizards keep the same 35....................
for several years
What people want
• Possible reasons:
- to improve the survival of their young
(but little 36....................has been noted between parents and
children)
- to provide 37....................for female lizards
Tracking study
- A study was carried out using GPS systems attached to
the 38....................of the lizards
- This provided information on the lizards' location and even the number
of 39....................taken
一 It appeared that the lizards were trying to avoid one another
- This may be in order to reduce chances of 40....................
59
```

[Original question page](assets/531d8f674fa43625989f356eba5d4b3a450f01efd5318e759e34d3079abf1a45.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/a0f2e7906265cc4bb85d6646b62098b213638ed43c87662cc23971736c53f109.jpg; PDF page 61; full -->

```text
READING PASSAGE 1
Test 3
READING
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The coconut palm
For millennia, the coconut has been central to the lives of Polynesian and Asian peoples.
In the western world, on the other hand, coconuts have always been exotic and unusual,
sometimes rare. The Italian merchant traveller Marco Polo apparently saw coconuts
in South Asia in the late 13th century, and among the mid-14th-century travel writings
of Sir John Mandeville there is mention of ‘great Notes of Ynde’ (great Nuts of India).
Today, images of palm-fringed tropical beaches are cliches in the west to sell holidays,
chocolate bars, fizzy drinks and even romance.
Typically, we envisage coconuts as brown cannonballs that, when opened, provide
sweet white flesh. But we see only part of the fruit and none of the plant from which they
come. The coconut palm has a smooth, slender, grey trunk, up to 30 metres tall. This
is an important source of timber for building houses, and is increasingly being used as
a replacement for endangered hardwoods in the furniture construction industry. The
trunk is surmounted by a rosette of leaves, each of which may be up to six metres long.
The leaves have hard veins in their centres which, in many parts of the world, are used
as brushes after the green part of the leaf has been stripped away. Immature coconut
flowers are tightly clustered together among the leaves at the top of the trunk. The flower
stems may be tapped for their sap to produce a drink, and the sap can also be reduced
by boiling to produce a type of sugar used for cooking.
Coconut palms produce as many as seventy fruits per year, weighing more than a
kilogram each. The wall of the fruit has three layers: a waterproof outer layer, a fibrous
middle layer and a hard, inner layer. The thick fibrous middle layer produces coconut
fibre, ‘coir’, which has numerous uses and is particularly important in manufacturing
ropes. The woody innermost layer, the shell, with its three prominent ‘eyes, , surrounds
the seed. An important product obtained from the shell is charcoal, which is widely used
in various industries as well as in the home as a cooking fuel. When broken in half, the
shells are also used as bowls in many parts of Asia.
Inside the shell are the nutrients (endosperm) needed by the developing seed. Initially,
the endosperm is a sweetish liquid, coconut water, which is enjoyed as a drink, but also
provides the hormones which encourage other plants to grow more rapidly and produce
higher yields. As the fruit matures, the coconut water gradually solidifies to form the
brilliant white, fat-rich, edible flesh or meat. Dried coconut flesh, ‘copra, , is made into
coconut oil and coconut milk, which are widely used in cooking in different parts of the
world, as well as in cosmetics. A derivative of coconut fat, glycerine, acquired strategic

60
```

[Original question page](assets/a0f2e7906265cc4bb85d6646b62098b213638ed43c87662cc23971736c53f109.jpg)

<!-- Source: /api/assets/61de5b6ad4e9ed1c28bc13ddf7ad731a85e447e948fa239758fed9c576ad8ffd.jpg; PDF page 62; full -->

```text
Reading
importance in a quite different sphere, as Alfred Nobel introduced the world to his
nitroglycerine-based invention: dynamite.
Their biology would appear to make coconuts the great maritime voyagers and coastal
colonizers of the plant world. The large, energy-rich fruits are able to float in water and
tolerate salt, but cannot remain viable indefinitely; studies suggest after about 110 days
at sea they are no longer able to germinate. Literally cast onto desert island shores,
with little more than sand to grow in and exposed to the full glare of the tropical sun,
coconut seeds are able to germinate and root. The air pocket in the seed, created as the
endosperm solidifies, protects the embryo. In addition, the fibrous fruit wall that helped
it to float during the voyage stores moisture that can be taken up by the roots of the
coconut seedling as it starts to grow.
There have been centuries of academic debate over the origins of the coconut. There
were no coconut palms in West Africa, the Caribbean or the east coast of the Americas
before the voyages of the European explorers Vasco da Gama and Columbus in the
late 15th and early 16th centuries. 16th century trade and human migration patterns
reveal that Arab traders and European sailors are likely to have moved coconuts from
South and Southeast Asia to Africa and then across the Atlantic to the east coast of
America. But the origin of coconuts discovered along the west coast of America by
16th century sailors has been the subject of centuries of discussion. Two diametrically
opposed origins have been proposed: that they came from Asia, or that they were native
to America. Both suggestions have problems.In Asia, there is a large degree of coconut
diversity and evidence of millennia of human use — but there are no relatives growing
in the wild. In America, there are close coconut relatives, but no evidence that coconuts
are indigenous. These problems have led to the intriguing suggestion that coconuts
originated on coral islands in the Pacific and were dispersed from there.
61
```

[Original question page](assets/61de5b6ad4e9ed1c28bc13ddf7ad731a85e447e948fa239758fed9c576ad8ffd.jpg)

<!-- Source: /api/assets/ca52fd91c99045713ee4a9593cde82bddaa94613ebb2fbfb6a650d8c0113eec8.jpg; PDF page 63; full -->

```text
Questions 1–8
Complete the table below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–8 on your answer sheet.
THE COCONUT PALM
| Part | Description | Uses |
| --- | --- | --- |
| trunk | up to 30 metres | timber for houses and the making of (1) __________ |
| leaves | up to 6 metres long | to make brushes |
| flowers | at the top of the trunk | stems provide sap, used as a drink or a source of (2) __________ |
| fruits | outer layer | |
| fruits | middle layer (coir fibres) | used for (3) __________, etc. |
| fruits | inner layer (shell) | a source of (4) __________; (when halved) for (5) __________ |
| fruits | coconut water | a drink; a source of (6) __________ for other plants |
| fruits | coconut flesh | oil and milk for cooking and (7) __________; glycerine (an ingredient in (8) __________) |
```

[Original question page](assets/ca52fd91c99045713ee4a9593cde82bddaa94613ebb2fbfb6a650d8c0113eec8.jpg)

<!-- Source: /api/assets/697fce17c4ff0426bf54de0cd0be734349db82d3276796381a8f12c0a676f346.jpg; PDF page 64; full -->

```text
Questions 9–13
Reading
Do the following statements agree with the information given in Reading Passage 1?
In boxes 9-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
9 Coconut seeds need shade in order to germinate.
10 Coconuts were probably transported to Asia from America in the 16th century.
11 Coconuts found on the west coast of America were a different type from those
found on the east coast.
12 All the coconuts found in Asia are cultivated varieties.
13 Coconuts are cultivated in different ways in America and the Pacific.

63
```

[Original question page](assets/697fce17c4ff0426bf54de0cd0be734349db82d3276796381a8f12c0a676f346.jpg)

<!-- Source: /api/assets/a24aab20d31738b8d044c6dd3db03cd8988e954f6e494ca482155cb277aea9f9.jpg; PDF page 65; full -->

```text
READING PASSAGE 2
Test 3
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
How baby talk gives infant brains a boost
A The typical way of talking to a baby 一 high-pitched, exaggerated and repetitious 一 is
a source of fascination for linguists who hope to understand how 'baby talk’ impacts
on learning. Most babies start developing their hearing while still in the womb,
prompting some hopeful parents to play classical music to their pregnant bellies.
Some research even suggests that infants are listening to adult speech as early
as 10 weeks before being born, gathering the basic building blocks of their family's
native tongue.
B Early language exposure seems to have benefits to the brain —  for instance, studies
suggest that babies raised in bilingual homes are better at learning how to mentally
prioritize information. So how does the sweet if sometimes absurd sound of infant-
directed speech influence a baby’s development? Here are some recent studies
that explore the science behind baby talk.
C Fathers don’t use baby talk as often or in the same ways as mothers - and that’s
perfectly OK, according to a new study. Mark VanDam of Washington State
University at Spokane and colleagues equipped parents with recording devices and
speech-recognition software to study the way they interacted with their youngsters
during a normal day. ‘We found that moms do exactly what you'd expect and what’s
been described many times over,’ VanDam explains. ‘But we found that dads aren't
doing the same thing. Dads didn't raise their pitch or fundamental frequency when
they talked to kids., Their role may be rooted in what is called the bridge hypothesis,
which dates back to 1975. It suggests that fathers use less familial language to
provide their children with a bridge to the kind of speech they'll hear in public. The
idea is that a kid gets to practice a certain kind of speech with mom and another
kind of speech with dad, so the kid then has a wider repertoire of kinds of speech to
practice,' says VanDam.
D Scientists from the University of Washington and the University of Connecticut
collected thousands of 30-second conversations between parents and their babies,
fitting 26 children with audio-recording vests that captured language and sound
during a typical eight-hour day. The study found that the more baby talk parents
used, the more their youngsters began to babble. And when researchers saw
the same babies at age two, they found that frequent baby talk had dramatically
boosted vocabulary, regardless of socioeconomic status. Those children who
listened to a lot of baby talk were talking more than the babies that listened to more

64
```

[Original question page](assets/a24aab20d31738b8d044c6dd3db03cd8988e954f6e494ca482155cb277aea9f9.jpg)

<!-- Source: /api/assets/eb7cef8e078b8ef19c4d366f1c562b534ed25c31bdc81ca00960d6dd13c15174.jpg; PDF page 66; full -->

```text
Reading
adult talk or standard speech,, says Nairán Ramírez-Esparza of the University of
Connecticut. ‘We also found that it really matters whether you use baby talk in a
one-on-one context,' she adds. The more parents use baby talk one-on-one, the
more babies babble, and the more they babble, the more words they produce later
in life.’
E Another study suggests that parents might want to pair their youngsters up so
they can babble more with their own kind. Researchers from McGill University
and Université du Québec à Montréal found that babies seem to like listening to
each other rather than to adults - which may be why baby talk is such a universal
tool among parents. They played repeating vowel sounds made by a special
synthesizing device that mimicked sounds made by either an adult woman or
another baby. This way, only the impact of the auditory cues was observed. The
team then measured how long each type of sound held the infants’ attention. They
found that the ‘infant' sounds held babies' attention nearly 40 percent longer. The
baby noises also induced more reactions in the listening infants, like smiling or lip
moving, which approximates sound making. The team theorizes that this attraction
to other infant sounds could help launch the learning process that leads to speech.
'It may be some property of the sound that is just drawing their attention,’ says
study co-author Linda Polka. ‘Or maybe they are really interested in that particular
type of sound because they are starting to focus on their own ability to make
sounds. We are speculating here but it might catch their attention because they
recognize it as a sound they could possibly make.’
F In a study published in Proceedings of the National Academy of Sciences, a total
of 57 babies from two slightly different age groups - seven months and eleven and
a half months - were played a number of syllables from both their native language
(English) and a non-native tongue (Spanish). The infants were placed in a brain-
activation scanner that recorded activity in a brain region known to guide the motor
movements that produce speech. The results suggest that listening to baby talk
prompts infant brains to start practicing their language skills. ‘Finding activation in
motor areas of the brain when infants are simply listening is significant, because
it means the baby brain is engaged in trying to talk back right from the start, and
suggests that seven-month-olds’ brains are already trying to figure out how to make
the right movements that will produce words,’ says co-author Patricia Kuhl. Another
interesting finding was that while the seven-month-olds responded to all speech
sounds regardless of language, the brains of the older infants worked harder at the
motor activations of non-native sounds compared to native sounds. The study may
have also uncovered a process by which babies recognize differences between
their native language and other tongues.
65
```

[Original question page](assets/eb7cef8e078b8ef19c4d366f1c562b534ed25c31bdc81ca00960d6dd13c15174.jpg)

<!-- Source: /api/assets/772615a23fa948f711f328947de4403611f1fa12fe616e2107e5d7d9e7009940.jpg; PDF page 67; full -->

```text
Questions 14-17
Look at the following ideas (Questions 14-17) and the list of researchers below.
Test 3
Match each idea with the correct researcher, A, B or C.
Write the correct letter, A, B or C, in boxes 14-17 on your answer sheet.
NB You may use any letter more than once.
14 the importance of adults giving babies individual attention when talking to them
15 the connection between what babies hear and their own efforts to create speech
16 the advantage for the baby of having two parents each speaking in a different way
17 the connection between the amount of baby talk babies hear and how much
vocalising they do themselves
List of Researchers
A Mark VanDam
B Nairán Ramírez-Esparza
C Patricia Kuhl
66
```

[Original question page](assets/772615a23fa948f711f328947de4403611f1fa12fe616e2107e5d7d9e7009940.jpg)

<!-- Source: /api/assets/9561b1b36426533d078ee5a1c222c5058018cb36933ff57662132e3b93b7d5bd.jpg; PDF page 68; full -->

```text
Reading
Questions 18-23
Complete the summary below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 18-23 on your answer sheet.
Research into how parents talk to babies
Researchers at Washington State University used 18...................., together with
specialised computer programs, to analyse how parents interacted with their babies
during a normal day. The study revealed that 19....................tended not to modify
their ordinary speech patterns when interacting with their babies. According to an idea
known as the 20...................., they may use a more adult type of speech to
prepare infants for the language they will hear outside the family home. According to the
researchers, hearing baby talk from one parent and ‘normal’ language from the other
expands the baby's 21....................of types of speech which they can practise.
Meanwhile, another study carried out by scientists from the University of Washington
and the University of Connecticut recorded speech and sound using special
22 ....................that the babies were equipped with. When they studied the babies
again at age two, they found that those who had heard a lot of baby talk in infancy had a
much larger 23....................than those who had not.
Questions 24-26
Reading Passage 2 has six paragraphs, A-F.
Which paragraph contains the following information?
Write the correct letter, A-F, in boxes 24-26 on your answer sheet.
24 a reference to a change which occurs in babies’ brain activity before the end of their
first year
25 an example of what some parents do for their baby’s benefit before birth
26 a mention of babies’ preference for the sounds that other babies make
67
```

[Original question page](assets/9561b1b36426533d078ee5a1c222c5058018cb36933ff57662132e3b93b7d5bd.jpg)

<!-- Source: /api/assets/2b6c4b42d9f80220e66b42c5da2be2e1bd7cbaa52ee24d1f89aca0b6fd6bf7a0.jpg; PDF page 69; full -->

```text
READING PASSAGE 3
Test 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Whatever happened to the Harappan Civilisation?
New research sheds light on the disappearance of an ancient society
A The Harappan Civilisation of ancient Pakistan and India flourished 5,000 years
ago, but a thousand years later their cities were abandoned. The Harappan
Civilisation was a sophisticated Bronze Age society who built ‘megacities’ and
traded internationally in luxury craft products, and yet seemed to have left almost
no depictions of themselves. But their lack of self-imagery - at a time when the
Egyptians were carving and painting representations of themselves all over their
temples - is only part of the mystery.
B There is plenty of archaeological evidence to tell us about the rise of the Harappan
Civilisation, but relatively little about its fall, ’ explains archaeologist Dr Cameron
Petrie of the University of Cambridge. ‘As populations increased, cities were
built that had great baths, craft workshops, palaces and halls laid out in distinct
sectors. Houses were arranged in blocks, with wide main streets and narrow
alleyways, and many had their own wells and drainage systems. It was very much
a “thriving” civilisation.’ Then around 2100 BC, a transformation began. Streets
went uncleaned, buildings started to be abandoned, and ritual structures fell out of
use. After their final demise, a millennium passed before really large-scale cities
appeared once more in South Asia.
C Some have claimed that major glacier-fed rivers changed their course, dramatically
affecting the water supply and agriculture; or that the cities could not cope with an
increasing population, they exhausted their resource base, the trading economy
broke down or they succumbed to invasion and conflict; and yet others that climate
change caused an environmental change that affected food and water provision.
'It is unlikely that there was a single cause for the decline of the civilisation. But the
fact is, until now, we have had little solid evidence from the area for most of the key
elements, , said Petrie. ‘A lot of the archaeological debate has really only been well-
argued speculation.,
D A research team led by Petrie, together with Dr Ravindanath Singh of Banaras
Hindu University in India, found early in their investigations that many of the
archaeological sites were not where they were supposed to be, completely altering
understanding of the way that this region was inhabited in the past. When they
carried out a survey of how the larger area was settled in relation to sources of
water, they found inaccuracies in the published geographic locations of ancient
settlements ranging from several hundred metres to many kilometres. They realised

68
```

[Original question page](assets/2b6c4b42d9f80220e66b42c5da2be2e1bd7cbaa52ee24d1f89aca0b6fd6bf7a0.jpg)

<!-- Source: /api/assets/43bbfcbf46c57fb1447df3f1bc27a152ea51bb16d58559bb144bc0fa9b25d921.jpg; PDF page 70; full -->

```text
Reading
that any attempts to use the existing data were likely to be fundamentally flawed.
Over the course of several seasons of fieldwork they carried out new surveys,
finding an astonishing 198 settlement sites that were previously unknown.
E Now, research published by Dr Yama Dixit and Professor David Hodell, both
from Cambridge’s Department of Earth Sciences, has provided the first definitive
evidence for climate change affecting the plains of north-western India, where
hundreds of Harappan sites are known to have been situated. The researchers
gathered shells of Melanoides tuberculata snails from the sediments of an ancient
lake and used geochemical analysis as a means of tracing the climate history of
the region. ‘As today, the major source of water into the lake is likely to have been
the summer monsoon, ’ says Dixit. ‘But we have observed that there was an abrupt
change about 4,100 years ago, when the amount of evaporation from the lake
exceeded the rainfall — indicative of a drought.’ Hodell adds: 'We estimate that the
weakening of the Indian summer monsoon climate lasted about 200 years before
recovering to the previous conditions, which we still see today.,
F It has long been thought that other great Bronze Age civilisations also declined at
a similar time, with a global-scale climate event being seen as the cause. While it
is possible that these local-scale processes were linked, the real archaeological
interest lies in understanding the impact of these larger-scale events on different
environments and different populations. ‘Considering the vast area of the Harappan
Civilisation with its variable weather systems, ’ explains Singh, ‘it is essential that we
obtain more climate data from areas close to the two great cities at Mohenjodaro
and Harappa and also from the Indian Punjab.’
G Petrie and Singh's team is now examining archaeological records and trying to
understand details of how people led their lives in the region five millennia ago.
They are analysing grains cultivated at the time, and trying to work out whether
they were grown under extreme conditions of water stress, and whether they
were adjusting the combinations of crops they were growing for different weather
systems. They are also looking at whether the types of pottery used, and other
aspects of their material culture, were distinctive to specific regions or were more
similar across larger areas. This gives us insight into the types of interactive
networks that the population was involved in, and whether those changed.
H Petrie believes that archaeologists are in a unique position to investigate how
past societies responded to environmental and climatic change. ‘By investigating
responses to environmental pressures and threats, we can learn from the past to
engage with the public, and the relevant governmental and administrative bodies,
to be more proactive in issues such as the management and administration of
water supply, the balance of urban and rural development, and the importance of
preserving cultural heritage in the future.’
69
```

[Original question page](assets/43bbfcbf46c57fb1447df3f1bc27a152ea51bb16d58559bb144bc0fa9b25d921.jpg)

<!-- Source: /api/assets/b8fe7c1b6608988225b386e6b7a258e98700118ae752973c8994ac5c0b8f5c83.jpg; PDF page 71; full -->

```text
Questions 27–31
Test 3
Reading Passage 3 has eight paragraphs, A-H.
Which paragraph contains the following information?
Write the correct letter, A-H, in boxes 27-31 on your answer sheet.
NB You may use any letter more than once.
27 proposed explanations for the decline of the Harappan Civilisation
28 reference to a present-day application of some archaeological research findings
29 a difference between the Harappan Civilisation and another culture of the same
period
30 a description of some features of Harappan urban design
31 reference to the discovery of errors made by previous archaeologists

70
```

[Original question page](assets/b8fe7c1b6608988225b386e6b7a258e98700118ae752973c8994ac5c0b8f5c83.jpg)

<!-- Source: /api/assets/5149893a65bf7b180cc4e65a67103962a1fd2f977f9f04a17ae83c43fbba0e28.jpg; PDF page 72; full -->

```text
Reading
Questions 32-36
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 32-36 on your answer sheet.
Looking at evidence of climate change
Yama Dixit and David Hodell have found the first definitive evidence of climate change
affecting the plains of north-western India thousands of years ago. By collecting the
32
....................of snails and analysing them, they discovered evidence of a
change in water levels in a 33....................in the region. This occurred when
there was less 34....................than evaporation, and suggests that there was an
extended period of drought.
Petrie and Singh’s team are using archaeological records to look at 35....................
from five millennia ago, in order to know whether people had adapted their agricultural
practices to changing climatic conditions. They are also examining objects including
36...................., so as to find out about links between inhabitants of different parts
of the region and whether these changed over time.
71
```

[Original question page](assets/5149893a65bf7b180cc4e65a67103962a1fd2f977f9f04a17ae83c43fbba0e28.jpg)

<!-- Source: /api/assets/7f6209a54be5cb730601243d05b1f79fc167af2d13f3813d98265b0233ccd9e1.jpg; PDF page 73; full -->

```text
Questions 37–40
Test 3
Look at the following statements () and the list of researchers below.
Match each statement with the correct researcher, A, B, C or D.
Write the correct letter, A, B, C or D, in boxes 37-40 on your answer sheet
NB You may use any letter more than once.
37 Finding further information about changes to environmental conditions in the region
is vital.
38 Examining previous patterns of behaviour may have long-term benefits.
39 Rough calculations indicate the approximate length of a period of water shortage.
40 Information about the decline of the Harappan Civilisation has been lacking.

List of Researchers
A Cameron Petrie
B Ravindanath Singh
C Yama Dixit
D David Hodell
72
```

[Original question page](assets/7f6209a54be5cb730601243d05b1f79fc167af2d13f3813d98265b0233ccd9e1.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/b3f78c24b3d01b5c8a4354bee5215a017332cf1b604bbab8e592162f06fb646c.jpg; PDF page 74; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The bar chart below shows the top ten countries for the production and consumption of electricity in 2014.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/b3f78c24b3d01b5c8a4354bee5215a017332cf1b604bbab8e592162f06fb646c.jpg)

![Original figure](assets/b3f78c24b3d01b5c8a4354bee5215a017332cf1b604bbab8e592162f06fb646c.jpg)

### Task 2

<!-- Source: /api/assets/296c29175e5a7622152ae225c9555780ef6e5616cc468f522f027444f4ce73f6.jpg; PDF page 75; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people say History is one of the most important school subjects. Other people think that, in today’s world, subjects like Science and Technology are more important than History.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/296c29175e5a7622152ae225c9555780ef6e5616cc468f522f027444f4ce73f6.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/8b4dea81d08496158b025124fd5f49c11617afa393f7ce9eb39e1f1e2423748e.jpg; PDF page 76; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Money
• When you go shopping, do you prefer to pay for things in cash or by card? [Why?]
• Do you ever save money to buy special things? [Why/Why not?]
• Would you ever take a job which had low pay? [Why/Why not?]
• Would winning a lot of money make a big difference to your life? [Why/Why not?]
PART 2
Describe an interesting discussion you had as part of
your work or studies.
You should say:
what the subject of the discussion was
who you discussed the subject with
what opinions were expressed
and explain why you found the discussion interesting.
75
You will have to talk
about the topic for one
to two minutes.You
have one minute to
think about what you
are going to say.You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Discussing problems with others
Example questions:
Why is it good to discuss problems with other people?
Do you think that it’s better to talk to friends and not family about problems?
Is it always a good idea to tell lots of people about a problem?
Communication skills at work
Example questions:
Which communication skills are most important when taking part in meetings
with colleagues?
What are the possible effects of poor written communication skills at work?
What do you think will be the future impact of technology on communication in
the workplace?
```

[Original question page](assets/8b4dea81d08496158b025124fd5f49c11617afa393f7ce9eb39e1f1e2423748e.jpg)

### Part 2

<!-- Source: /api/assets/8b4dea81d08496158b025124fd5f49c11617afa393f7ce9eb39e1f1e2423748e.jpg; PDF page 76; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Money
• When you go shopping, do you prefer to pay for things in cash or by card? [Why?]
• Do you ever save money to buy special things? [Why/Why not?]
• Would you ever take a job which had low pay? [Why/Why not?]
• Would winning a lot of money make a big difference to your life? [Why/Why not?]
PART 2
Describe an interesting discussion you had as part of
your work or studies.
You should say:
what the subject of the discussion was
who you discussed the subject with
what opinions were expressed
and explain why you found the discussion interesting.
75
You will have to talk
about the topic for one
to two minutes.You
have one minute to
think about what you
are going to say.You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Discussing problems with others
Example questions:
Why is it good to discuss problems with other people?
Do you think that it’s better to talk to friends and not family about problems?
Is it always a good idea to tell lots of people about a problem?
Communication skills at work
Example questions:
Which communication skills are most important when taking part in meetings
with colleagues?
What are the possible effects of poor written communication skills at work?
What do you think will be the future impact of technology on communication in
the workplace?
```

[Original question page](assets/8b4dea81d08496158b025124fd5f49c11617afa393f7ce9eb39e1f1e2423748e.jpg)

### Part 3

<!-- Source: /api/assets/8b4dea81d08496158b025124fd5f49c11617afa393f7ce9eb39e1f1e2423748e.jpg; PDF page 76; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Money
• When you go shopping, do you prefer to pay for things in cash or by card? [Why?]
• Do you ever save money to buy special things? [Why/Why not?]
• Would you ever take a job which had low pay? [Why/Why not?]
• Would winning a lot of money make a big difference to your life? [Why/Why not?]
PART 2
Describe an interesting discussion you had as part of
your work or studies.
You should say:
what the subject of the discussion was
who you discussed the subject with
what opinions were expressed
and explain why you found the discussion interesting.
75
You will have to talk
about the topic for one
to two minutes.You
have one minute to
think about what you
are going to say.You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Discussing problems with others
Example questions:
Why is it good to discuss problems with other people?
Do you think that it’s better to talk to friends and not family about problems?
Is it always a good idea to tell lots of people about a problem?
Communication skills at work
Example questions:
Which communication skills are most important when taking part in meetings
with colleagues?
What are the possible effects of poor written communication skills at work?
What do you think will be the future impact of technology on communication in
the workplace?
```

[Original question page](assets/8b4dea81d08496158b025124fd5f49c11617afa393f7ce9eb39e1f1e2423748e.jpg)
