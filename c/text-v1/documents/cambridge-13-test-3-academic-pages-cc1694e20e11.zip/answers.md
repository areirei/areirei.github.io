# 剑雅 13 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 123

TEST 3 LISTENING
1 850
2 bike / bicycle
3 parking
4 30 / thirty
5 weekend(s)
6 cinema
7 hospital
8 dentist
9 Thursday
10 café
11 F
12 D
13 A
14 B
15 C
16 G
17 B
18 C
19 B
20 D
21 C
22 A
23 A
24 B
25 C
26 F
27 H
28 D
29 A
30 E
31 tongue(s)
32 plants
33 snakes
34 sky
35 partner(s)
36 contact
37 protection
38 tail(s)
39 steps
40 injury / injuries
17&18 IN EITHER ORDER: B,C
19&20 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. 850

2. bike / bicycle

3. parking

4. 30 / thirty

5. weekend / weekends

6. cinema

7. hospital

8. dentist

9. Thursday

10. café / cafe

### Part 2 · source page 123

TEST 3 LISTENING
1 850
2 bike / bicycle
3 parking
4 30 / thirty
5 weekend(s)
6 cinema
7 hospital
8 dentist
9 Thursday
10 café
11 F
12 D
13 A
14 B
15 C
16 G
17 B
18 C
19 B
20 D
21 C
22 A
23 A
24 B
25 C
26 F
27 H
28 D
29 A
30 E
31 tongue(s)
32 plants
33 snakes
34 sky
35 partner(s)
36 contact
37 protection
38 tail(s)
39 steps
40 injury / injuries
17&18 IN EITHER ORDER: B,C
19&20 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. F

12. D

13. A

14. B

15. C

16. G

17. B / C

18. B / C

19. B / D

20. B / D

### Part 3 · source page 123

TEST 3 LISTENING
1 850
2 bike / bicycle
3 parking
4 30 / thirty
5 weekend(s)
6 cinema
7 hospital
8 dentist
9 Thursday
10 café
11 F
12 D
13 A
14 B
15 C
16 G
17 B
18 C
19 B
20 D
21 C
22 A
23 A
24 B
25 C
26 F
27 H
28 D
29 A
30 E
31 tongue(s)
32 plants
33 snakes
34 sky
35 partner(s)
36 contact
37 protection
38 tail(s)
39 steps
40 injury / injuries
17&18 IN EITHER ORDER: B,C
19&20 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. C

22. A

23. A

24. B

25. C

26. F

27. H

28. D

29. A

30. E

### Part 4 · source page 123

TEST 3 LISTENING
1 850
2 bike / bicycle
3 parking
4 30 / thirty
5 weekend(s)
6 cinema
7 hospital
8 dentist
9 Thursday
10 café
11 F
12 D
13 A
14 B
15 C
16 G
17 B
18 C
19 B
20 D
21 C
22 A
23 A
24 B
25 C
26 F
27 H
28 D
29 A
30 E
31 tongue(s)
32 plants
33 snakes
34 sky
35 partner(s)
36 contact
37 protection
38 tail(s)
39 steps
40 injury / injuries
17&18 IN EITHER ORDER: B,C
19&20 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. tongue / tongues

32. plants

33. snakes

34. sky

35. partner / partners

36. contact

37. protection

38. tail / tails

39. steps

40. injury / injuries

## A 类阅读

### Academic Reading · source page 124

TEST 3 READING
1 furniture
2 sugar
3 ropes
4 charcoal
5 bowls
6 hormones
7 cosmetics
8 dynamite
9 FALSE
10 FALSE
11 NOT GIVEN
12 TRUE
13 NOT GIVEN
14 B
15 C
16 A
17 B
18 recording devices
19 fathers / dads
20 bridge hypothesis
21 repertoire
22 (audio-recording) vests
23 vocabulary
24 F
25 A
26 E
27 C
28 H
29 A
30 B
31 D
32 shells
33 lake
34 rainfall
35 grains
36 pottery
37 B
38 A
39 D
40 A
If you score: 0–16 unlikely;17–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. furniture

2. sugar

3. ropes

4. charcoal

5. bowls

6. hormones

7. cosmetics

8. dynamite

9. FALSE

10. FALSE

11. NOT GIVEN

12. TRUE

13. NOT GIVEN

14. B

15. C

16. A

17. B

18. recording devices

19. fathers / dads

20. bridge hypothesis

21. repertoire

22. vests / audio-recording vests

23. vocabulary

24. F

25. A

26. E

27. C

28. H

29. A

30. B

31. D

32. shells

33. lake

34. rainfall

35. grains

36. pottery

37. B

38. A

39. D

40. A

## A 类写作

### Writing material: c13-t3-w-1

2014, BILLION kWh, production/consumption: China5398/5322; United States4099/3866; Russia1057/1038; Japan936.2/856.7; India871/698.8; Canada618.9/499.9; France561.2/462.9; Brazil530.7/455.8; Germany526.6/582.5; Korea,Rep.485.1/449.5. China and US far exceed others. Production exceeds consumption except Germany. Ranking is by production; Germany consumption exceeds Brazil and France. Do not reverse legend, use million kWh, confuse power with emissions, or infer imports/exports quantitatively without further data.



### Writing material: c13-t3-w-2

Discuss History as highly important and Science/Technology as more important today, with own opinion. Neither view says History must be removed entirely.



## 口语
