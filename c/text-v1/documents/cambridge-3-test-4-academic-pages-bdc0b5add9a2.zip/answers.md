# 剑雅 3 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 159

Answer key 
 155
TEST 4 
 
LISTENING 
 
Each question correctly answered scores I mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS, (Where alternative spellings are accepted, these are stated in the key.) 
 
Section 1, Questions 1-10 
1      4.25 // 4 1/4 // four and (a) quarter 
2     46 // forty-six 
3     A // State Bank 
4      D // Library 
5      C // Garage 
6     (a) (box) (of) chocolates 
7      (a) (soft) toy // (a) teddy (bear) // (a) bear 
8      (at the) market(s) 
9     (at the) market(s) 
10      ($)35/thirty-five (dollars) 
Section 2, Questions 11-20 
11      glass 
12     eighteen/18 hours/hrs 
13      (a) (strange) taste 
14      (the) small size // small // (the) size 
15      metal 
16     A 
17      outside/outdoor activities // outdoors 
18      underwater // under/beneath water 
19      (a) weak light 
20     flashing light 
 
Section 3, Questions 21-30 
21      B // hospital 
22     C // the middle section 
23     C // found it difficult to do 
24     C // remove completely 
25      B // rewrite 
26     C // remove completely 
27     Sight and Sound 
28      Support Tutor NOT Tutor 
29     proof reading // proof read 
30      10 July 
ALTERNATIVE FORMS ACCEPTED 
Section 4, Questions 31-40 
31      7.30pm (to/and) 5.30am NOT 7.30 to 5.30 
32      housewives // housewifes 
33     Sunday(s) 
34      (about) $25,000/twenty-five thousand dollars 
NOT 25,000 
35     C // 67 decibels 
36     C // for ceilings 
37     W // for walls 
38      C // for ceilings 
39     D 
40     C 
 
 

If you score… (original source guidance, not a new scoring rule)
0–15: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
16–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. 4.25 / 4:25 / 4¼ / four and quarter / four and a quarter

2. 46 / forty-six

3. A / State Bank

4. D / Library

5. C / Garage

6. chocolates / of chocolates / box chocolates / box of chocolates / a chocolates / a of chocolates / a box chocolates / a box of chocolates

7. toy / soft toy / a toy / a soft toy / teddy / teddy bear / a teddy / a teddy bear / bear / a bear

8. market / markets / at the market / at the markets

9. market / markets / at the market / at the markets

10. 35 / $ 35 / $35 / thirty-five / thirty-five dollars

### Part 2 · source page 159

Answer key 
 155
TEST 4 
 
LISTENING 
 
Each question correctly answered scores I mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS, (Where alternative spellings are accepted, these are stated in the key.) 
 
Section 1, Questions 1-10 
1      4.25 // 4 1/4 // four and (a) quarter 
2     46 // forty-six 
3     A // State Bank 
4      D // Library 
5      C // Garage 
6     (a) (box) (of) chocolates 
7      (a) (soft) toy // (a) teddy (bear) // (a) bear 
8      (at the) market(s) 
9     (at the) market(s) 
10      ($)35/thirty-five (dollars) 
Section 2, Questions 11-20 
11      glass 
12     eighteen/18 hours/hrs 
13      (a) (strange) taste 
14      (the) small size // small // (the) size 
15      metal 
16     A 
17      outside/outdoor activities // outdoors 
18      underwater // under/beneath water 
19      (a) weak light 
20     flashing light 
 
Section 3, Questions 21-30 
21      B // hospital 
22     C // the middle section 
23     C // found it difficult to do 
24     C // remove completely 
25      B // rewrite 
26     C // remove completely 
27     Sight and Sound 
28      Support Tutor NOT Tutor 
29     proof reading // proof read 
30      10 July 
ALTERNATIVE FORMS ACCEPTED 
Section 4, Questions 31-40 
31      7.30pm (to/and) 5.30am NOT 7.30 to 5.30 
32      housewives // housewifes 
33     Sunday(s) 
34      (about) $25,000/twenty-five thousand dollars 
NOT 25,000 
35     C // 67 decibels 
36     C // for ceilings 
37     W // for walls 
38      C // for ceilings 
39     D 
40     C 
 
 

If you score… (original source guidance, not a new scoring rule)
0–15: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
16–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. glass

12. eighteen hours / 18 hours / eighteen hrs / 18 hrs

13. taste / strange taste / a taste / a strange taste

14. small size / the small size / small / size / the size

15. metal

16. A

17. outside activities / outdoor activities / outdoors

18. underwater / under water / beneath water

19. weak light / a weak light

20. flashing light

### Part 3 · source page 159

Answer key 
 155
TEST 4 
 
LISTENING 
 
Each question correctly answered scores I mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS, (Where alternative spellings are accepted, these are stated in the key.) 
 
Section 1, Questions 1-10 
1      4.25 // 4 1/4 // four and (a) quarter 
2     46 // forty-six 
3     A // State Bank 
4      D // Library 
5      C // Garage 
6     (a) (box) (of) chocolates 
7      (a) (soft) toy // (a) teddy (bear) // (a) bear 
8      (at the) market(s) 
9     (at the) market(s) 
10      ($)35/thirty-five (dollars) 
Section 2, Questions 11-20 
11      glass 
12     eighteen/18 hours/hrs 
13      (a) (strange) taste 
14      (the) small size // small // (the) size 
15      metal 
16     A 
17      outside/outdoor activities // outdoors 
18      underwater // under/beneath water 
19      (a) weak light 
20     flashing light 
 
Section 3, Questions 21-30 
21      B // hospital 
22     C // the middle section 
23     C // found it difficult to do 
24     C // remove completely 
25      B // rewrite 
26     C // remove completely 
27     Sight and Sound 
28      Support Tutor NOT Tutor 
29     proof reading // proof read 
30      10 July 
ALTERNATIVE FORMS ACCEPTED 
Section 4, Questions 31-40 
31      7.30pm (to/and) 5.30am NOT 7.30 to 5.30 
32      housewives // housewifes 
33     Sunday(s) 
34      (about) $25,000/twenty-five thousand dollars 
NOT 25,000 
35     C // 67 decibels 
36     C // for ceilings 
37     W // for walls 
38      C // for ceilings 
39     D 
40     C 
 
 

If you score… (original source guidance, not a new scoring rule)
0–15: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
16–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. B

22. C

23. C

24. C

25. B

26. C

27. Sight and Sound

28. Support Tutor

29. proof reading / proof read

30. 10 July

### Part 4 · source page 159

Answer key 
 155
TEST 4 
 
LISTENING 
 
Each question correctly answered scores I mark. Please note! CORRECT SPELLING NEEDED IN 
ALL ANSWERS, (Where alternative spellings are accepted, these are stated in the key.) 
 
Section 1, Questions 1-10 
1      4.25 // 4 1/4 // four and (a) quarter 
2     46 // forty-six 
3     A // State Bank 
4      D // Library 
5      C // Garage 
6     (a) (box) (of) chocolates 
7      (a) (soft) toy // (a) teddy (bear) // (a) bear 
8      (at the) market(s) 
9     (at the) market(s) 
10      ($)35/thirty-five (dollars) 
Section 2, Questions 11-20 
11      glass 
12     eighteen/18 hours/hrs 
13      (a) (strange) taste 
14      (the) small size // small // (the) size 
15      metal 
16     A 
17      outside/outdoor activities // outdoors 
18      underwater // under/beneath water 
19      (a) weak light 
20     flashing light 
 
Section 3, Questions 21-30 
21      B // hospital 
22     C // the middle section 
23     C // found it difficult to do 
24     C // remove completely 
25      B // rewrite 
26     C // remove completely 
27     Sight and Sound 
28      Support Tutor NOT Tutor 
29     proof reading // proof read 
30      10 July 
ALTERNATIVE FORMS ACCEPTED 
Section 4, Questions 31-40 
31      7.30pm (to/and) 5.30am NOT 7.30 to 5.30 
32      housewives // housewifes 
33     Sunday(s) 
34      (about) $25,000/twenty-five thousand dollars 
NOT 25,000 
35     C // 67 decibels 
36     C // for ceilings 
37     W // for walls 
38      C // for ceilings 
39     D 
40     C 
 
 

If you score… (original source guidance, not a new scoring rule)
0–15: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
16–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. 7.30 pm to 5.30 am / 7.30pm to 5.30am / 7:30 pm to 5:30 am / 7:30pm to 5:30am / 7.30 pm and 5.30 am / 7.30pm and 5.30am / 7:30 pm and 5:30 am / 7:30pm and 5:30am / 7.30 pm-5.30 am / 7.30pm-5.30am / 7:30 pm-5:30 am / 7:30pm-5:30am

32. housewives / housewifes

33. Sunday / Sundays

34. $ 25,000 / $ 25000 / $25,000 / $25000 / about $ 25,000 / about $ 25000 / about $25,000 / about $25000 / twenty-five thousand dollars / about twenty-five thousand dollars

35. C

36. C

37. W

38. C

39. D

40. C

## A 类阅读

### Academic Reading · source page 160

Answer key 
 
 156
ACADEMIC READING 
Each question correctly answered scores 1 mark. Please note! CORRECT SPELLING NEEDED IN ALL 
ANSWERS. 
 
Reading Passage 1, Questions 1-13 
1      Los Angeles 
2      London 
3     Singapore 
4      London 
5      Los Angeles 
6     YES // Y 
7     YES // Y 
8      NO // N 
9     NO // N 
10      NO // N 
11      A // one 
12      D // particulate matter 
13     C // the old and ill 
Reading Passage 2, Questions 14-27 
14     C // the success of the movement’s corporate 
image 
15      D // It had a clear purpose and direction 
16      BOTH FOR ONE MARK D // 1918 AND E // 
1928 
17     (selling) advertising (space) 
18     colour scheme // (three) colours // purple, white, 
(and) green 
19      (the) Woman’s Exhibition 
20     NO // N 
21      YES // Y 
22      NO // N 
23     NO // N 
24     NOT GIVEN // NG 
25      YES // Y 
26     YES // Y 
27      D // informative 
Reading Passage 3, Questions 28-40 
28     A // establish whether increased productivity 
should be sought at any cost 
29     C // had identical patterns of organisation 
30     C // the staff involved spent a number of months 
preparing for the study 
31      supervision // leadership // management 
32     productivity 
33      reduced // cut // decreased 
34     (group methods of) leadership 
35      overstaffed 
36     reduced // cut // decreased 
37     C // Changes in productivity 
38     D // Employees’ feelings of responsibility towards 
completion of work 
39     G // Employees feel closer to their supervisors 
40      F // Employees’ opinion as to extent of personal 
support from management 
 
 

If you score… (original source guidance, not a new scoring rule)
0–15: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
16–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. Los Angeles

2. London

3. Singapore

4. London

5. Los Angeles

6. YES

7. YES

8. NO

9. NO

10. NO

11. A

12. D

13. C

14. C

15. D

16. D E / D, E / D and E / D & E / D; E / D/E / D,E / DE / E D / E, D / E and D / E & D / E; D / E/D / E,D / ED / D 1928 / D, 1928 / D and 1928 / D & 1928 / D; 1928 / D/1928 / D,1928 / 1928 D / 1928, D / 1928 and D / 1928 & D / 1928; D / 1928/D / 1928,D / 1918 E / 1918, E / 1918 and E / 1918 & E / 1918; E / 1918/E / 1918,E / E 1918 / E, 1918 / E and 1918 / E & 1918 / E; 1918 / E/1918 / E,1918 / 1918 1928 / 1918, 1928 / 1918 and 1928 / 1918 & 1928 / 1918; 1928 / 1918/1928 / 1918,1928 / 1928 1918 / 1928, 1918 / 1928 and 1918 / 1928 & 1918 / 1928; 1918 / 1928/1918 / 1928,1918

17. advertising / advertising space / selling advertising / selling advertising space

18. colour scheme / colours / three colours / purple, white green / purple, white and green

19. Woman's Exhibition / the Woman's Exhibition

20. NO

21. YES

22. NO

23. NO

24. NOT GIVEN

25. YES

26. YES

27. D

28. A

29. C

30. C

31. supervision / leadership / management

32. productivity

33. reduced / cut / decreased

34. leadership / group methods of leadership

35. overstaffed

36. reduced / cut / decreased

37. C

38. D

39. G

40. F

## A 类写作

### Writing material: c3-t4-w-1

Original line graph inspected at full resolution. Title: Unemployment Rates: US and Japan. Vertical units percentage of work force, displayed range 2.0–7.5%; horizontal labelled March 1993 through March 1999. Dotted series is US; solid line is Japan. US starts around 7% and declines with small fluctuations to around 5% at the end; intermediate values are roughly 6.5% around early 1994, 5.5–6% in 1995, a little over 5% during 1996–1997, and near 5% in 1998–1999. Japan begins near 2.5%, rises rapidly to about 3% and reaches around 3.5–4% during 1994–1995. It approaches 4.4% then briefly dips below 4% around 1996, before resuming its rise. It jumps to just above 5% in 1998 and finishes around 5%. The wide initial gap narrows almost completely; the lines meet around 1998 and remain close thereafter. The US is not higher at every single point. All readings are approximate; neither country follows a perfectly monotonic trend. These are historical unemployment rates, not prisoner numbers or forecasts.



### Writing material: c3-t4-w-2

The stated position is an opinion for evaluation. A supported agreement, disagreement or qualified position is valid; do not require a predetermined stance.



## 口语
