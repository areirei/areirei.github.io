# 剑雅 3 · Test 4

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/50464aea7b75f21e6aa4700fc0b50beec1e7573622b71257a6e2305dff6d5029.jpg; PDF page 80; full -->

```text
LISTENING SECTION1 Questions1–10
Questions1 and2: Complete the form opposite. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Birth Statistics
Example: Date of birth—10August
Sex: male; First name: Tom; Surname: Lightfoot
Weight: (1) __________ kgs
Length: (2) __________ cms
Colour of hair: black
Questions3–5: Label the map. Choose your answers from the box below. Write the appropriate letters A–E on the map.
A State Bank
B St George’s Hospital
C Garage
D Library
E University
Use the original map with blanks3,4,5 and John’s house on Chesterfield Road.
```

[Original question page](assets/50464aea7b75f21e6aa4700fc0b50beec1e7573622b71257a6e2305dff6d5029.jpg)

![Original figure](assets/50464aea7b75f21e6aa4700fc0b50beec1e7573622b71257a6e2305dff6d5029.jpg)

<!-- Source: /api/assets/e3bfee06662404d638590d1e95fbe506e7a9b233514a82a4051e333f274e0f3c.jpg; PDF page 81; full -->

```text
Questions6–10
Write NO MORE THAN THREE WORDS OR A NUMBER for each answer.
Item | Gift for Susan | Gift for baby
What will they buy? | (6) __________ | (7) __________
Where will they buy the gifts? | (8) __________ | (9) __________
Approximate prices? | $15 | (10) $__________
```

[Original question page](assets/e3bfee06662404d638590d1e95fbe506e7a9b233514a82a4051e333f274e0f3c.jpg)

### Part 2

<!-- Source: /api/assets/42f02efbc723f3bef23e0f39a7d6a79c1fd276d28b9b8db1451e4d4a54f46ebb.jpg; PDF page 82; full -->

```text
SECTION2 Questions11–20
Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
For the recommendation column, write A: You must buy this. B: Maybe you should buy this. C: You should never buy this.
Name | Advantage(s) | Disadvantage(s) | Recommendation
Unbreakable Vacuum Flask | Contains no (11) __________; Steel guaranteed for20years; Keeps warm for (12) __________ | Expensive; Leaves (13) __________ | B
Whistle Key Holder | Press-button light useful for finding keyhole; (14) __________ | Unpleasant noise; Doesn’t work through (15) __________ | (16) __________
Army Flashlight (squeeze light) | Useful for (17) __________; Works (18) __________ | Has (19) __________ | C
Decoy Camera (to trick burglars) | Realistic (20) __________ | Difficult to fix onto wall | A
```

[Original question page](assets/42f02efbc723f3bef23e0f39a7d6a79c1fd276d28b9b8db1451e4d4a54f46ebb.jpg)

### Part 3

<!-- Source: /api/assets/1f8643537030815167b0183d9a8d063b464bfded1e1567f1e8dc0705561c137b.jpg; PDF page 83; full -->

```text
Listening 
 79
SEC TIO N 3         Questions 21-30  
 
Questions 21-23 
 
Choose the correct letters A—C. 
 
21     Amina’s project is about a local 
A     school.  
B     hospital.  
C     factory. 
 
22     Dr Bryson particularly liked 
A     the introduction.  
B     the first chapter.  
C     the middle section. 
 
23     Amina was surprised because she 
A     thought it was bad. 
B      wrote it quickly. 
C     found it difficult to do. 
 
Questions 24-26 
 
What suggestions does Dr Bryson make? Complete the table as follows. 
 
Write A           if he says KEEP UNCHANGED 
Write B           if he says REWRITE 
Write C           if he says REMOVE COMPLETELY 
 
Example 
Section headings 
Answer 
B  
 
Information on housing 24      ................. 
 
Interview data                    25     ................. 
 
Chronology                       26      .................
```

[Original question page](assets/1f8643537030815167b0183d9a8d063b464bfded1e1567f1e8dc0705561c137b.jpg)

<!-- Source: /api/assets/c2e3a212a51240820216296603a95cf3322e48f1659b2503269ed379e3d69702.jpg; PDF page 84; full -->

```text
Questions27–30
Complete the notes below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
SCHEDULE OF ACTION
• Read ‘Approaches to Local History’ by John Mervis.
• Read (27) ‘__________’ by Kate Oakwell.
• Make changes and show to (28) __________.
• Do (29) __________ by29June.
• Laser print before (30) __________.
• Hand in to Faculty Office.
```

[Original question page](assets/c2e3a212a51240820216296603a95cf3322e48f1659b2503269ed379e3d69702.jpg)

### Part 4

<!-- Source: /api/assets/2c650e1c18794b4189c940a5a17e982d869bdd24f053a14a05e4b3ab5218cca9.jpg; PDF page 85; full -->

```text
Listening 
 81
SECTION4        Questions 31-40 
 
Questions 31-34 
 
Write NUMBERS AND/OR NO MORE THAN FOUR WORDS for each answer. 
 
31     Between what times is the road traffic lightest? 
……………………………………………………………………………………………….. 
32     Who will notice the noise most? 
……………………………………………………………………………………………….. 
33     Which day of the week has the least traffic? 
……………………………………………………………………………………………….. 
34     What will be the extra cost of modifying houses? 
……………………………………………………………………………………………….. 
 
Question 35 
 
Choose the correct letter A-D. 
 
The noise levels at the site can reach 
A     45 decibels. 
B     55 decibels. 
C     67 decibels. 
D     70 decibels.
```

[Original question page](assets/2c650e1c18794b4189c940a5a17e982d869bdd24f053a14a05e4b3ab5218cca9.jpg)

<!-- Source: /api/assets/e29d99bc9cefd6bc704f32a106910a4bb5c1b84148ecb73e0277eb3e4f858df1.jpg; PDF page 86; full -->

```text
Test 4 
 82
Questions 36-38 
 
Complete the table showing where devices used in reducing noise could be fitted in the houses. 
 
Write: W for walls  
D for doors  
C  for ceilings 
 
Example 
acoustic seals 
Answer 
D  
 
36 double thickness plaster board  
37 mechanical ventilation  
38 air conditioning  
 
Questions 39 and 40 
 
Choose the correct letters A-D. 
 
39    Which is the correct construction for acoustic double glazing?
Use the original four cross-section diagrams. OUTSIDE is on the left, INSIDE on the right.
Option | outside pane | inside pane | gap
A |8mm|6mm|6cm
B |8mm|8mm|6cm
C |6mm|7mm|7cm
D |8mm|6mm|7cm
```

[Original question page](assets/e29d99bc9cefd6bc704f32a106910a4bb5c1b84148ecb73e0277eb3e4f858df1.jpg)

![Original figure](assets/e29d99bc9cefd6bc704f32a106910a4bb5c1b84148ecb73e0277eb3e4f858df1.jpg)

<!-- Source: /api/assets/f08468fb56698ea87ff4aa0014d5adb89727962f56284a6ebbe99ebcb06614f0.jpg; PDF page 87; full -->

```text
Question40: What is the best layout for the houses?
Use the original diagram, with the Highway above the four houses.
Option | rooms nearer Highway | rooms farther from Highway
A |Living Rooms|Bedrooms
B |Bedrooms|Kitchen
C |Kitchen|Living Rooms
D |Dining Room|Garage
```

[Original question page](assets/f08468fb56698ea87ff4aa0014d5adb89727962f56284a6ebbe99ebcb06614f0.jpg)

![Original figure](assets/f08468fb56698ea87ff4aa0014d5adb89727962f56284a6ebbe99ebcb06614f0.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/378123ffb54fd880a2e5a61a6d174e9a883d49ae58a653e1de4fd94816fd055e.jpg; PDF page 88; full -->

```text
Test 4 
 84
READING 
 
READING PASSAGE 1 
 
You should spend about 20 minutes on Questions 1—13 which are based on Reading Passage 1 below. 
 
 
 
Part One 
A Air pollution is increasingly becoming the focus of government and citizen concern around the globe. 
From Mexico City and New York, to Singapore and Tokyo, new solutions to this old problem are being 
proposed, Mailed and implemented with ever increasing speed. It is feared that unless pollution 
reduction measures are able to keep pace with the continued pressures of urban growth, air quality in 
many of the world’s major cities will deteriorate beyond reason. 
B Action is being taken along several fronts: through new legislation, improved enforcement and 
innovative technology. In Los Angeles, state regulations are forcing manufacturers to try to sell ever 
cleaner cars: their first of the cleanest, titled "Zero Emission Vehicles’, have to be available soon, 
since they are intended to make up 2 per cent of sales in 1997. Local authorities in London are 
campaigning to be allowed to enforce anti-pollution laws themselves; at present only the police have 
the power to do so, but they tend to be busy elsewhere. In Singapore, renting out road space to users 
is the way of the future. 
C When Britain’s Royal Automobile Club monitored the exhausts of 60,000 vehicles, it found that 12 per 
cent of them produced more than half the total pollution. Older cars were the worst offenders; though 
a sizeable number of quite new cars were also identified as gross polluters, they were simply badly 
tuned. California has developed a scheme to get these gross polluters off the streets: they offer a flat 
$700 for any old, run-down vehicle driven in by its owner. The aim is to remove the heaviest-polluting, 
most decrepit vehicles from the roads. 
D As part of a European Union environmental programme, a London council is resting an infra-red 
spectrometer from the University of Denver in Colorado. It gauges the pollution from a passing 
vehicle - more useful than the annual stationary rest that is the British standard today - by bouncing a 
beam through the exhaust and measuring what gets blocked. The councils next step may be to link 
the system to a computerised video camera able to read number plates automatically. 
E The effort to clean up cars may do little to cut pollution if nothing is done about the tendency to drive 
them more. Los Angeles has some of the world’s cleanest cars - far better than those of Europe - but 
the total number of miles those cars drive continues to grow. One solution is car-pooling, an
[Editorial note: obvious typographical substitutions were corrected; the source image and exact replacements are retained in the review record. The original numerical claims and uncertain wording are preserved.]
```

[Original question page](assets/378123ffb54fd880a2e5a61a6d174e9a883d49ae58a653e1de4fd94816fd055e.jpg)

<!-- Source: /api/assets/ee0d5e3844cb212a980e0dfae1b4e0495c44688422834a908bc24cf4e2590447.jpg; PDF page 89; full -->

```text
Reading 
 85
arrangement in which a number of people who share the same destination share the use of one car. 
However, the average number of people in a car on the freeway in Los Angeles, which is 1.0, has 
been falling steadily. Increasing it would be an effective way of reducing emissions as well as easing 
congestion. The trouble is, Los Angelenos seem to like being alone in their cars. 
 
F Singapore has for a while had a scheme that forces drivers to buy a badge if they wish to visit a 
certain part of the city. Electronic innovations make possible increasing sophistication: rates can vary 
according to road conditions, time of day and so on. Singapore is advancing in this direction, with a 
city-wide network of transmitters to collect information and charge drivers as they pass certain points. 
Such road-pricing, however, can be controversial. When the local government in Cambridge, 
England, considered introducing Singaporean techniques, it faced vocal and ultimately successful 
opposition. 
 
Part Two 
The scope of the problem facing the world’s cities is immense. In 1992, the United Nations 
Environmental Programme and the World Health Organisation (WHO) concluded that all of a sample 
of twenty megacities - places likely to have more than ten million inhabitants in the year 2000 - 
already exceeded the level the WHO deems healthy in at least one major pollutant. Two-thirds of 
them exceeded the guidelines for two, seven for three or more. 
Of the six pollutants monitored by the WHO - carbon dioxide, nitrogen dioxide, ozone, sulphur dioxide, 
lead and particulate matter - it is this last category that is attracting the most attention from health 
researchers. PM10, a sub-category of particulate matter measuring ten-millionths of a metre across, 
has been implicated in thousands of deaths a year in Britain alone. Research being conducted in two 
counties of Southern California is reaching similarly disturbing conclusions concerning this little-
understood pollutant. 
A world-wide rise in allergies, particularly asthma, over the past four decades is now said to be linked 
with increased air pollution. The lungs and brains of children who grow up in polluted air offer further 
evidence of its destructive power The old and ill, however, are the most vulnerable to the acute effects 
of heavily polluted stagnant air. It can actually hasten death, as it did in December 1991 when a cloud 
of exhaust fumes lingered over the city of London for over a week. 
The United Nations has estimated that in the year 2000 there will be twenty-four mega-cities and a 
further eighty-five cities of more than three million people. The pressure on public officials, 
corporations and urban citizens to reverse established trends in air pollution is likely to grow in 
proportion with the growth of cities themselves. Progress is being made. The question, though, 
remains the same: ‘Will change happen quickly enough?’
[Editorial note: obvious typographical substitutions were corrected; the source image and exact replacements are retained in the review record. The original numerical claims and uncertain wording are preserved.]
```

[Original question page](assets/ee0d5e3844cb212a980e0dfae1b4e0495c44688422834a908bc24cf4e2590447.jpg)

<!-- Source: /api/assets/462a8b7dd0f611877edcc368662afbf5af4a53f3a2bb7b2221b045c463f8c02f.jpg; PDF page 90; full -->

```text
Test 4 
 86
Questions 1-5 
 
Look at the following solutions (Questions 1-5) and locations.  
 
Match each solution with one location. 
 
Write the appropriate locations in boxes 1-5 on your answer sheet.  
 
NB You may use any location more than once. 
 
SOLUTIONS 
1       Manufacturers must sell cleaner cars. 
2      Authorities want to have power to enforce anti-pollution laws. 
3      Drivers will be charged according to the roads they use. 
4      Moving vehicles will be monitored for their exhaust emissions. 
5      Commuters are encouraged to share their vehicles with others. 
 
LOCATIONS 
Singapore 
Tokyo 
London 
New York 
Mexico City 
Cambridge 
Los Angeles
```

[Original question page](assets/462a8b7dd0f611877edcc368662afbf5af4a53f3a2bb7b2221b045c463f8c02f.jpg)

<!-- Source: /api/assets/5459a721a4290a82dfe3085a54624599bfe015f9d23d9cb681d1d7094b39514f.jpg; PDF page 91; full -->

```text
Reading 
 87
Questions 6-10 
 
Do the following statements reflect the claims of the writer in Reading Passage 1? 
 
In boxes 6-10 on your answer sheet write 
 
YES              if the statement reflects the claims of the writer 
NO                if the statement contradicts the claims of the writer 
NOT GIVEN if it is impossible to say what the writer thinks about this 
 
6    According to British research, a mere twelve per cent of vehicles tested produced over fifty per 
cent of total pollution produced by the sample group. 
7    It is currently possible to measure the pollution coming from individual vehicles whilst they are 
moving. 
8    Residents of Los Angeles are now tending to reduce the yearly distances they travel by car. 
9    Car-pooling has steadily become more popular in Los Angeles in recent years. 
10  Charging drivers for entering certain parts of the city has been successfully done in Cambridge, 
England. 
Questions 11-13 
 
Choose the appropriate letters A—D and write them in boxes 11-13 on your answer sheet. 
 
11     How many pollutants currently exceed WHO guidelines in all megacities studied? 
A     one  
B     two 
C     three 
D     seven 
 
12    Which pollutant is currently the subject of urgent research? 
A     nitrogen dioxide 
B     ozone 
C     lead 
D     particulate matter 
 
13    Which of the following groups of people are the most severely affected by intense air 
pollution? 
A     allergy sufferers 
B     children 
C     the old and ill 
D     asthma sufferers
```

[Original question page](assets/5459a721a4290a82dfe3085a54624599bfe015f9d23d9cb681d1d7094b39514f.jpg)

<!-- Source: /api/assets/905683e9e62cccea3b3f1d53fb3a0d2209d506f091c80cd05f48aeb5440e9734.jpg; PDF page 92; full -->

```text
Test 4 
 88
READING PASSAGE 2
VOTES FOR WOMEN 
 
You should spend about 20 minutes on Questions 14-27 which are based on Reading Passage 2 below. 
 
 
 
 
 
The suffragette movement, 
which campaigned for votes 
for women in the early 
twentieth century, is most 
commonly associated with the 
Pankhurst family and militant 
acts of varying degrees of 
violence. The Museum of 
London has drawn on its 
archive collection to convey a 
fresh picture with its 
exhibition 
The Purple, White and Green: 
Suffragettes in London 1906-
14. 
The name is a reference to the 
colour scheme that the 
Women’s Social and Political 
Union (WSPU) created to give 
the movement a uniform, 
nationwide image. By doing 
so, it became one of the first 
groups to project a corporate 
identity, and it is this advanced 
marketing strategy, along with 
the other organisational and 
commercial achievements of 
the WSPU, to which the 
exhibition is devoted. 
Formed in 1903 by the 
political campaigner Mrs 
Emmeline Pankhurst and her 
daughters Christabel and 
Sylvia, the WSPU began an 
educated campaign to put 
women’s suffrage on the 
political agenda. New Zealand, 
Australia and parts of the 
United States had already 
enfranchised women, and 
growing numbers of their 
British counterparts wanted 
the same opportunity. 
With their slogan ‘Deeds not 
words’, and the introduction of 
the colour scheme, the WSPU 
soon brought the movement 
the cohesion and focus it had 
previously lacked. 
Membership grew rapidly as 
women deserted the many 
other, less directed, groups and 
joined it. By 1906 the WSPU 
headquarters, called the 
Women’s Press Shop, had 
been established in Charing 
Cross Road and in spite of 
limited communications (no 
radio or television, and 
minimal use of the telephone) 
the message had spread around 
the country, with members and 
branch officers stretching to as 
far away as Scotland. 
The newspapers produced by 
the WSPU, first Votes for 
Women and later The 
Suffragette, played a vital role 
in this communication. Both 
were sold throughout the 
country and proved an 
invaluable way of informing 
members of meetings, 
marches, fund-raising events 
and the latest news and views 
on the movement. 
Equally importantly for a 
rising political group, the 
newspaper returned a profit. 
This was partly because
```

[Original question page](assets/905683e9e62cccea3b3f1d53fb3a0d2209d506f091c80cd05f48aeb5440e9734.jpg)

<!-- Source: /api/assets/70a6b90063ae369e11434ac8cb189dc412fc84c4d24613c6ff620932454609cc.jpg; PDF page 93; full -->

```text
Reading 
 89
advertising space was bought 
in the paper by large 
department stores such as 
Selfridges, and jewellers such 
as Mappin & Webb. These 
two, together with other like-
minded commercial 
enterprises sympathetic to the 
cause, had quickly identified a 
direct way to reach a huge 
market of women, many with 
money to spend. 
The creation of the colour 
scheme provided another 
money-making opportunity 
which the WSPU was quick to 
exploit. The group began to 
sell playing cards, board 
games, Christmas and greeting 
cards, and countless other 
goods, all in the purple, white 
and green colours. In 1906 
such merchandising of a 
corporate identity was a new 
marketing concept. 
But the paper and 
merchandising activities alone 
did not provide sufficient 
funds for the WSPU to meet 
organisational costs, so 
numerous other fund-raising 
activities combined to fill the 
coffers of the ‘war chest’. The 
most notable of these was the 
Woman’s Exhibition, which 
took place in 1909 in a 
Knightsbridge ice-skating rink, 
and in 10 days raised the 
equivalent of £250,000 today. 
The Museum of London’s 
exhibition is largely visual, 
with a huge number of items 
on show. Against a quiet 
background hum of street 
sounds, copies of The 
Suffragette, campaign banners 
and photographs are all on 
display, together with one of 
Mrs Pankhurst’s shoes and a 
number of purple, white and 
green trinkets. 
Photographs depict vivid 
scenes of a suffragette’s life: 
WSPU members on a self-
proclaimed ‘monster’ march, 
wearing their official uniforms 
of a white frock decorated 
with purple, white and green 
accessories; women selling 
The Suffragette at street 
corners, or chalking up 
pavements with details of a 
forthcoming meeting. 
Windows display postcards 
and greeting cards designed by 
women artists for the 
movement, and the quality of 
the artwork indicates the 
wealth of resources the WSPU 
could call on from its talented 
members. 
Visitors can watch a short film 
made up of old newsreels and 
cinema material which clearly 
reveals the political mood of 
the day towards the 
suffragettes. The programme 
begins with a short film 
devised by the ‘antis’ - those 
opposed to women having the 
vote -depicting a suffragette as 
a fierce harridan bullying her 
poor, abused husband. 
Original newsreel footage 
shows the suffragette Emily 
Wilding Davison throwing 
herself under King George V’s 
horse at a famous race- 
Although the exhibition 
officially charts the years 1906 
to 1914, graphic display 
boards outlining the bills of 
enfranchisement of 1918 and 
1928, which gave the adult 
female populace of Britain the 
vote, show what was achieved. 
It demonstrates how advanced 
the suffragettes were in their 
thinking, in the marketing of 
their campaign, and in their 
work as shrewd and skilful 
image-builders. It also conveys 
a sense of the energy and 
ability the suffragettes brought 
to their fight for freedom and 
equality. And it illustrates the 
intelligence employed by 
women who were at that time 
deemed by several politicians 
to have ‘brains too small to 
know how to vote’.
```

[Original question page](assets/70a6b90063ae369e11434ac8cb189dc412fc84c4d24613c6ff620932454609cc.jpg)

<!-- Source: /api/assets/780f045d291e6407f4ff30c801ca2e3c3b6893ca000c0ff166a1ce41c6caf6d1.jpg; PDF page 94; full -->

```text
Test 4 
 90
Questions 14 and 15 
 
Choose the appropriate letters A-D and write them in boxes 14 and 15 on your answer sheet. 
 
14    What is the main aspect of the suffragette movement’s work to which the exhibition at the 
Museum of London is devoted? 
A     the role of the Pankhurst family in the suffrage movement 
B     the violence of the movement’s political campaign 
C     the success of the movement’s corporate image 
D     the movement’s co-operation with suffrage groups overseas 
 
15    Why was the WSPU more successful than other suffrage groups? 
A     Its leaders were much better educated. 
B     It received funding from movements abroad. 
C     It had access to new technology. 
D     It had a clear purpose and direction. 
 
Question 16 
 
Choose TWO letters A-E and write them in box 16 on your answer sheet. 
 
In which TWO of the following years were laws passed allowing British women to vote? 
A         1906 
B         1909 
C         1914 
D         1918 
E         1928 
 
Questions 17-19 
 
Complete the notes below. 
 
Choose NO MORE THAN THREE WORDS from Reading Passage 2 for each answer. 
 
Write your answers in boxes 17-19 on your answer sheet. 
 
Three ways in which the WSPU raised money: 
•  the newspapers: mainly through selling ... 17...  
•  merchandising activities: selling a large variety of goods 
produced in their ...18...  
•  additional fund-raising activities: for example, ...19...
```

[Original question page](assets/780f045d291e6407f4ff30c801ca2e3c3b6893ca000c0ff166a1ce41c6caf6d1.jpg)

<!-- Source: /api/assets/b30edcbde1ca579dbb82304cda857987479f76d8f4431beb83e61feb659818d9.jpg; PDF page 95; full -->

```text
Reading 
 91
Questions 20-26 
 
Do the following statements reflect the situation as described by the writer in Reading Passage 2? 
 
In boxes 20-26 on your answer sheet write 
 
YES              if the statement reflects the situation as described by the writer 
NO                if the statement contradicts the writer 
NOT GIVEN if it is impossible to know what the situation is from the passage 
 
Example 
The WSPU was founded in 1906 by 
Emmeline Pankhurst 
Answer 
NO  
 
20     In 1903 women in Australia were still not allowed to vote. 
21     The main organs of communication for the WSPU were its two newspapers. 
22    The work of the WSPU was mainly confined to London and the south. 
23    The WSPU’s newspapers were mainly devoted to society news and gossip. 
24    The Woman’s Exhibition in 1909 met with great opposition from Parliament. 
25     The Museum of London exhibition includes some of the goods sold by the movement. 
26    The opponents of the suffragettes made films opposing the movement.  
 
Question 27 
Choose the appropriate letter A-D and write it in box 27 on your answer sheet.  
 
The writer of the article finds the exhibition to be 
A     misleading. 
B     exceptional. 
C     disappointing. 
D     informative.
```

[Original question page](assets/b30edcbde1ca579dbb82304cda857987479f76d8f4431beb83e61feb659818d9.jpg)

<!-- Source: /api/assets/3fefc3eec5c270d6d9e19e028b40066d58fa6752db729740b40a083bbdb67f27.jpg; PDF page 96; full -->

```text
Test 4 
 92
READING PASSAGE 3 
 
You should spend about 20 minutes on Questions 28-40 which are based on Reading Passage 3 
below. 
 
Measuring Organisational Performance 
 
There is clear-cut evidence that, for a period of at least one year, supervision which increases the direct pressure for 
productivity can achieve significant increases in production. However, such short-term increases are obtained only at a 
substantial and serious cost to the organisation. 
To what extent can a manager make an impressive earnings record over a short period of one to three years by exploiting 
the company’s investment in the human organisation in his plant or division? To what extent will the quality of his 
organisation suffer if he does so? The following is a description of an important study conducted by the Institute for Social 
Research designed to answer these questions. 
The study covered 500 clerical employees in four parallel divisions. Each division was organised in exactly the same way, 
used the same technology, did exactly the same kind of work, and had employees of comparable aptitudes. 
Productivity in all four of the divisions depended on the number of clerks involved. The work entailed the processing of 
accounts and generating of invoices. Although the volume of work was considerable, the nature of the business was such 
that it could only be processed as it came along. Consequently, the only way in which productivity could be increased was 
to change the size of the workgroup. 
The four divisions were assigned to two experimental programmes on a random basis. Each programme was assigned at 
random a division that had been historically high in productivity and a division that had been below average in 
productivity. No attempt was made to place a division in the programme that would best fit its habitual methods of 
supervision used by the manager, assistant managers, supervisors and assistant supervisors. 
The experiment at the clerical level lasted for one year. Beforehand, several months were devoted to planning, and there 
was also a training period of approximately six months. Productivity was measured continuously and computed weekly 
throughout the year. The attitudes of employees and supervisory staff towards their work were measured just before and 
after the period. 
Turning now to the heart of the study, in two divisions an attempt was made to change the supervision so that the 
decision levels were pushed down and detailed supervision of the workers reduced. More general supervision of the 
clerks and their supervisors was introduced. In addition, the managers, assistant managers, supervisors and assistant 
supervisors of these two divisions were trained in group methods of leadership, which they endeavoured to use as much 
as their skill would permit during the experimental year. For easy reference, the experimental changes in these two 
divisions will be labelled the ‘participative programme! 
In the other two divisions, by contrast, the programme called for modifying the supervision so as to increase the 
closeness of supervision and move the decision levels upwards. This will be labelled the ‘hierarchically controlled 
programme’. These changes were accomplished by a further extension of the scientific management approach. For 
example, one of the major changes made was to have the jobs timed and to have standard times computed. This showed 
that these divisions were overstaffed by about 30%. The general manager then ordered the managers of these two 
divisions to cut staff by 25%. This was done by transfers without replacing the persons who left; no one was to be 
dismissed. 
Results of the Experiment 
Changes in Productivity 
Figure 1 shows the changes in salary costs per unit of work, which reflect the change in productivity that occurred in the 
divisions. As will be observed, the hierarchically controlled programmes increased productivity by about 25%. This was a 
result of the direct orders from the general manager to reduce staff by that amount. Direct pressure produced a 
substantial increase in production. 
A significant increase in productivity of 20% was also achieved in the participative programme, but this was not as great
[Editorial note: obvious typographical substitutions were corrected; the source image and exact replacements are retained in the review record. The original numerical claims and uncertain wording are preserved.]
```

[Original question page](assets/3fefc3eec5c270d6d9e19e028b40066d58fa6752db729740b40a083bbdb67f27.jpg)

<!-- Source: /api/assets/6dbf96f61bf138a9144903eb1962c47201825943a9e4efab9e1b7911b3ca918d.jpg; PDF page 97; full -->

```text
Reading 
 93
an increase as in the hierarchically controlled programme. To bring about this improvement, the clerks themselves 
participated in the decision to reduce the size of the work group. (They were aware of course that productivity increases 
were sought by management in conducting these experiments.) Obviously, deciding to reduce the size of a work group by 
eliminating some of its members is probably one of the most difficult decisions for a work group to make. Yet the clerks 
made it. In fact, one division in the participative programme increased its productivity by about the same amount as each 
of the two divisions in the hierarchically controlled programme. The other participative division, which historically had 
been the poorest of all the divisions, did not do so well and increased productivity by only 15%. 
Changes in Attitudes 
Although both programmes had similar effects on productivity, they had significantly different results in other respects. 
The productivity increases in the hierarchically controlled programme were accompanied by shifts in an adverse direction 
in such factors as loyalty, attitudes, interest, and involvement in the work. But just the opposite was true in the 
participative programme. 
For example, Figure 2 shows that when more general supervision and increased participation were provided, the 
employees’ feeling of responsibility to see that the work got done increased. Again, when the supervisor was away, they 
kept on working. In the hierarchically controlled programme, however, the feeling of responsibility decreased, and when 
the supervisor was absent, work tended to stop. 
As Figure 3 shows, the employees in the participative programme at the end of the year felt that their manager and 
assistant manager were ‘closer to them’ than at the beginning of the year. The opposite was true in the hierarchical 
programme. Moreover, as Figure 4 shows, employees in the participative programme felt that their supervisors were more 
likely to ‘pull’ for them, or for the company and them, and not be solely interested in the company, while in the 
hierarchically controlled programme, the opposite trend occurred.
[Figures1–2 are retained from the original page below: salary costs per unit of work and before/after employee silhouettes.]
```

[Original question page](assets/6dbf96f61bf138a9144903eb1962c47201825943a9e4efab9e1b7911b3ca918d.jpg)

![Original figure](assets/6dbf96f61bf138a9144903eb1962c47201825943a9e4efab9e1b7911b3ca918d.jpg)

<!-- Source: /api/assets/d470c173b9f3a5dcb1ef0424a191c95569c4e605043f33c19e61e6b9395beab7.jpg; PDF page 98; full -->

```text
Figures3 and4: See the original diagrams below.
Both compare PARTICIPATIVE and HIERARCHICALLY CONTROLLED programmes, Before and After.
Figure3 vertical scale1–5: Not close to Very close.
Figure4 vertical scale1–5: Company only to Employees.
```

[Original question page](assets/d470c173b9f3a5dcb1ef0424a191c95569c4e605043f33c19e61e6b9395beab7.jpg)

![Original figure](assets/d470c173b9f3a5dcb1ef0424a191c95569c4e605043f33c19e61e6b9395beab7.jpg)

<!-- Source: /api/assets/4f1ca0781300dbaaa296d711d1abd0bfd15d9e3ef67f71f04594e5b059cbc252.jpg; PDF page 99; full -->

```text
Reading 
 95
Questions 28-30 
 
Choose the appropriate letters A-D and write them in boxes 28-30 on your answer sheet. 
 
28     The experiment was designed to 
A     establish whether increased productivity should be sought at any cost. 
B      show that four divisions could use the same technology. 
C     perfect a system for processing accounts. 
D     exploit the human organisation of a company in order to increase profits. 
 
29     The four divisions 
A     each employed a staff of 500 clerks. 
B     each had equal levels of productivity. 
C     had identical patterns of organisation. 
D     were randomly chosen for the experiment. 
 
30     Before the experiment 
A     the four divisions were carefully selected to suit a specific programme. 
B     each division was told to reduce its level of productivity. 
C     the staff involved spent a number of months preparing for the study. 
D     the employees were questioned about their feelings towards the study. 
 
Questions 31-36 
 
Complete the summary below. Choose ONE word from Reading Passage 3 for each answer. 
 
Write your answers in boxes 31-36 on your answer sheet. 
 
This experiment involved an organisation comprising four divisions, which were divided into two programmes: the 
hierarchically controlled programme and the participative programme. For a period of one year a different method 
of ... 31 ... was used in each programme. Throughout this time ... 32 ... was calculated on a weekly basis. During 
the course of the experiment the following changes were made in an attempt to improve performance. 
 
In the participative programme: 
•    supervision of all workers was ... 33 ...  
•    supervisory staff were given training in ... 34 ... 
 
In the hierarchically controlled programme: 
•    supervision of all workers was increased. 
•    work groups were found to be ... 35 ... by 30%. 
•    the work force was ... 36 ... by 25%.
```

[Original question page](assets/4f1ca0781300dbaaa296d711d1abd0bfd15d9e3ef67f71f04594e5b059cbc252.jpg)

<!-- Source: /api/assets/dbb1792463e61fec3cb5ee64e4959c19ed3416ad3d352f3d450a698bf66b5e16.jpg; PDF page 100; full -->

```text
Test 4 
 96
Questions 37-40 
 
Look at Figures 1, 2, 3 and 4 in Reading Passage 3. 
 
Choose the most appropriate label, A—I, for each Figure from the box below. 
 
Write your answers in boxes 37-40 on your answer sheet. 
 
A    Employees’ interest in the company 
B     Cost increases for the company 
C    Changes in productivity 
D     Employees’ feelings of responsibility towards 
completion of work 
E     Changes in productivity when supervisor was 
absent 
F      Employees’ opinion as to extent of personal 
support from management 
G     Employees feel closer to their supervisors 
H     Employees’ feelings towards increased supervision 
I      Supervisors’ opinion as to closeness of work group 
 
37     Fig 1................... 
38     Fig2................... 
39     Fig 3................... 
40     Fig 4...................
```

[Original question page](assets/dbb1792463e61fec3cb5ee64e4959c19ed3416ad3d352f3d450a698bf66b5e16.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/a38d87a5bcd8e2d90ccb553f4c7b78855f88489406d80404c0cf371937a8fb2d.jpg; PDF page 101; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below shows the unemployment rates in the US and Japan between March 1993 and March 1999.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

[Text edition note: the complete original figure is retained for all plotted series and labels.]
```

[Original question page](assets/a38d87a5bcd8e2d90ccb553f4c7b78855f88489406d80404c0cf371937a8fb2d.jpg)

![Original figure](assets/a38d87a5bcd8e2d90ccb553f4c7b78855f88489406d80404c0cf371937a8fb2d.jpg)

### Task 2

<!-- Source: /api/assets/7e58e0d18740b1595ddab6c95a1131d86e689ae9e627334a06c572e7fee7bbf4.jpg; PDF page 102; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic.

Improvements in health, education and trade are essential for the development of poorer nations. However, the governments of richer nations should take more responsibility for helping the poorer nations in such areas.

To what extent do you agree or disagree with this opinion?

You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.

You should write at least 250 words.
```

[Original question page](assets/7e58e0d18740b1595ddab6c95a1131d86e689ae9e627334a06c572e7fee7bbf4.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/9a1b737093f2d94b49052b54d0bba1e4d1d09bb9fa1f8c3034fbde0412622b6e.jpg; PDF page 103; full -->

```text
Speaking 
 99
SPEAKING 
 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE  
Daily Routine 
•   What would you like to change in your daily routine? 
•   Are all your days the same? 
•   Tell me about your typical weekday and your typical weekend. 
•   What is the balance of work/study and free time in your normal day? 
 
PART 2 
Describe something you own which is very important to you.  
You should say:  
where you got it from  
how long you have had it  
what you use it for  
and explain why it is so important to you. 
You will have to talk about the 
topic for 1 to 2 minutes. You have 
one minute to think about what 
you’re going to say. You can make 
some notes to help you if you wish. 
 
PART 3  
 
Discussion topics:  
How values can change 
Example questions: 
What kind of possessions show status in your country? 
Do you think it was different for your grandparents? 
The consumer society 
Example questions: 
Modern society is often called ‘materialistic’. Why do you think this is? 
Do you think consumerism is a positive or a negative development? 
The consumer market 
Example questions: 
What is the role of advertising? 
How do you think the Internet will affect buying patterns in the future?
```

[Original question page](assets/9a1b737093f2d94b49052b54d0bba1e4d1d09bb9fa1f8c3034fbde0412622b6e.jpg)

### Part 2

<!-- Source: /api/assets/9a1b737093f2d94b49052b54d0bba1e4d1d09bb9fa1f8c3034fbde0412622b6e.jpg; PDF page 103; full -->

```text
Speaking 
 99
SPEAKING 
 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE  
Daily Routine 
•   What would you like to change in your daily routine? 
•   Are all your days the same? 
•   Tell me about your typical weekday and your typical weekend. 
•   What is the balance of work/study and free time in your normal day? 
 
PART 2 
Describe something you own which is very important to you.  
You should say:  
where you got it from  
how long you have had it  
what you use it for  
and explain why it is so important to you. 
You will have to talk about the 
topic for 1 to 2 minutes. You have 
one minute to think about what 
you’re going to say. You can make 
some notes to help you if you wish. 
 
PART 3  
 
Discussion topics:  
How values can change 
Example questions: 
What kind of possessions show status in your country? 
Do you think it was different for your grandparents? 
The consumer society 
Example questions: 
Modern society is often called ‘materialistic’. Why do you think this is? 
Do you think consumerism is a positive or a negative development? 
The consumer market 
Example questions: 
What is the role of advertising? 
How do you think the Internet will affect buying patterns in the future?
```

[Original question page](assets/9a1b737093f2d94b49052b54d0bba1e4d1d09bb9fa1f8c3034fbde0412622b6e.jpg)

### Part 3

<!-- Source: /api/assets/9a1b737093f2d94b49052b54d0bba1e4d1d09bb9fa1f8c3034fbde0412622b6e.jpg; PDF page 103; full -->

```text
Speaking 
 99
SPEAKING 
 
PART 1 
 
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar 
topics. 
EXAMPLE  
Daily Routine 
•   What would you like to change in your daily routine? 
•   Are all your days the same? 
•   Tell me about your typical weekday and your typical weekend. 
•   What is the balance of work/study and free time in your normal day? 
 
PART 2 
Describe something you own which is very important to you.  
You should say:  
where you got it from  
how long you have had it  
what you use it for  
and explain why it is so important to you. 
You will have to talk about the 
topic for 1 to 2 minutes. You have 
one minute to think about what 
you’re going to say. You can make 
some notes to help you if you wish. 
 
PART 3  
 
Discussion topics:  
How values can change 
Example questions: 
What kind of possessions show status in your country? 
Do you think it was different for your grandparents? 
The consumer society 
Example questions: 
Modern society is often called ‘materialistic’. Why do you think this is? 
Do you think consumerism is a positive or a negative development? 
The consumer market 
Example questions: 
What is the role of advertising? 
How do you think the Internet will affect buying patterns in the future?
```

[Original question page](assets/9a1b737093f2d94b49052b54d0bba1e4d1d09bb9fa1f8c3034fbde0412622b6e.jpg)
