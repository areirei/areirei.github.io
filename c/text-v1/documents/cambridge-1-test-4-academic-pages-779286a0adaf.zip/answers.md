# 剑雅 1 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 148

142
Practice Test 4
PRACTICE TEST 4
LISTENING
Section 1
1C
2A
3B
4D
5D
6Julia Perkins (must be correct spelling
with capital letters)
7 15 Waratah Road (must be correct
spelling of Waratah with capital letter)
8 Brisbane (must have capital letter)
9 to be advised//not connected//no phone//
none (blank not acceptable)
10 first year Law (must have all three words)
11 C
12 D
Section 2
13 Hope Street (must have capitals)
14 evidence
15 passport
16 current/student (account)
17 chequebook
18 withdraw//draw (out)//take out
19 directly from//right out of
20 permission of/from bank
21 4.30 pm or/to 5 pm
Section 3
22 300 million
23 paper clips
24 magazine pages//pieces of paper//pages
25 three times
26 thicker
27 label
28 (a) dome
29 flange (correct spelling)
30 25%
31 scored opening
Section 4
32 a university lecture
33 Sports Studies (programme)
34 management
35 top athletes
36 makes winners//makes them/people win
37 market forces
38 (other) leisure activities
39 entertainment//to be entertained
40 exercise science
41 fitness testing//body measurements
42 cellular research//cellular change//body
cells

1. C

2. A

3. B

4. D

5. D

6. Julia Perkins / JULIA PERKINS

7. 15 Waratah Road / 15 WARATAH ROAD / 15WARATAHROAD

8. Brisbane / BRISBANE

9. to be advised / not connected / no phone / none

10. first year Law

11. C

12. D

### Part 2 · source page 148

142
Practice Test 4
PRACTICE TEST 4
LISTENING
Section 1
1C
2A
3B
4D
5D
6Julia Perkins (must be correct spelling
with capital letters)
7 15 Waratah Road (must be correct
spelling of Waratah with capital letter)
8 Brisbane (must have capital letter)
9 to be advised//not connected//no phone//
none (blank not acceptable)
10 first year Law (must have all three words)
11 C
12 D
Section 2
13 Hope Street (must have capitals)
14 evidence
15 passport
16 current/student (account)
17 chequebook
18 withdraw//draw (out)//take out
19 directly from//right out of
20 permission of/from bank
21 4.30 pm or/to 5 pm
Section 3
22 300 million
23 paper clips
24 magazine pages//pieces of paper//pages
25 three times
26 thicker
27 label
28 (a) dome
29 flange (correct spelling)
30 25%
31 scored opening
Section 4
32 a university lecture
33 Sports Studies (programme)
34 management
35 top athletes
36 makes winners//makes them/people win
37 market forces
38 (other) leisure activities
39 entertainment//to be entertained
40 exercise science
41 fitness testing//body measurements
42 cellular research//cellular change//body
cells

13. Hope Street / HOPE STREET

14. evidence

15. passport

16. current / current account / student / student account

17. chequebook

18. withdraw / draw / draw out / take out

19. directly from / right out of

20. permission of bank / permission from bank

21. 4.30 pm / 4.30pm / 4:30 pm / 4:30pm / 5 pm / 5pm / 4.30 pm to 5 pm / 4.30pm to 5pm / 4:30 pm to 5 pm / 4:30pm to 5pm

### Part 3 · source page 148

142
Practice Test 4
PRACTICE TEST 4
LISTENING
Section 1
1C
2A
3B
4D
5D
6Julia Perkins (must be correct spelling
with capital letters)
7 15 Waratah Road (must be correct
spelling of Waratah with capital letter)
8 Brisbane (must have capital letter)
9 to be advised//not connected//no phone//
none (blank not acceptable)
10 first year Law (must have all three words)
11 C
12 D
Section 2
13 Hope Street (must have capitals)
14 evidence
15 passport
16 current/student (account)
17 chequebook
18 withdraw//draw (out)//take out
19 directly from//right out of
20 permission of/from bank
21 4.30 pm or/to 5 pm
Section 3
22 300 million
23 paper clips
24 magazine pages//pieces of paper//pages
25 three times
26 thicker
27 label
28 (a) dome
29 flange (correct spelling)
30 25%
31 scored opening
Section 4
32 a university lecture
33 Sports Studies (programme)
34 management
35 top athletes
36 makes winners//makes them/people win
37 market forces
38 (other) leisure activities
39 entertainment//to be entertained
40 exercise science
41 fitness testing//body measurements
42 cellular research//cellular change//body
cells

22. 300 million

23. paper clips

24. magazine pages / pieces of paper / pages

25. three times

26. thicker

27. label

28. dome / a dome

29. flange

30. 25 per cent / 25 percent / 25%

31. scored opening

### Part 4 · source page 148

142
Practice Test 4
PRACTICE TEST 4
LISTENING
Section 1
1C
2A
3B
4D
5D
6Julia Perkins (must be correct spelling
with capital letters)
7 15 Waratah Road (must be correct
spelling of Waratah with capital letter)
8 Brisbane (must have capital letter)
9 to be advised//not connected//no phone//
none (blank not acceptable)
10 first year Law (must have all three words)
11 C
12 D
Section 2
13 Hope Street (must have capitals)
14 evidence
15 passport
16 current/student (account)
17 chequebook
18 withdraw//draw (out)//take out
19 directly from//right out of
20 permission of/from bank
21 4.30 pm or/to 5 pm
Section 3
22 300 million
23 paper clips
24 magazine pages//pieces of paper//pages
25 three times
26 thicker
27 label
28 (a) dome
29 flange (correct spelling)
30 25%
31 scored opening
Section 4
32 a university lecture
33 Sports Studies (programme)
34 management
35 top athletes
36 makes winners//makes them/people win
37 market forces
38 (other) leisure activities
39 entertainment//to be entertained
40 exercise science
41 fitness testing//body measurements
42 cellular research//cellular change//body
cells

32. a university lecture

33. Sports Studies / Sports Studies programme

34. management

35. top athletes

36. makes winners / makes them win / makes people win

37. market forces

38. leisure activities / other leisure activities

39. entertainment / to be entertained

40. exercise science

41. fitness testing / body measurements

42. cellular research / cellular change / body cells

## A 类阅读

### Academic Reading · source page 149

143
Answer keys
READING
READING PASSAGE 1  Glass
Questions 1-5
Suggested approach
• Read the task rubric carefully. You have to
decide which heading best fits each paragraph
in the passage.
• Read paragraph A and look at the example.
• Skim through the list of paragraph headings to
familiarise yourself with them.
• Read paragraph B and underline parts that are
relevant to the main focus of the paragraph.
• Paragraph B begins “On the horizon”
suggesting that it is going to discuss a future
use of glass. It goes on to discuss fibre optics
and how they could be used in the future to
improve optical instruments. Phrases such as
“could function hundreds of times faster” and
“the surge in fibre optic use” all indicate that
this paragraph is about “Exciting innovations in
fibre optics”. So viii is the heading for
paragraph B.
• Go on to paragraph C.
• If you think there is more than one possible
heading for a paragraph, re-read the paragraph
and try to decide which heading is most
appropriate.
• If you cannot decide go on to the next
paragraph — you can come back to any
questions that you can’t do, later.

Question | Answer | Focus
1 | viii | The future of fibre optics and the excitement felt about this.
2 | i | The increase in trade for glass artists.
3 | ix | The impact of a machine for glass objects made in 1920.
4 | iii | Reasons why glass is so easy to shape.
5 | vi | The future with glass for designers of buildings and homes.
6 | molten glass // ribbon of glass // molten glass ribbon
7 | belt of steel // steel belt // moving belt
8 | (lightbulb) moulds
9 | A
10 | B
11 | A
12 | C
13 | A
Questions Task Skills tested

1-5 Paragraph headings • reading for detail
• identifying main ideas/themes/topics
• understanding gist
6-8 Labelling a diagram • following a description of a process
9-13 Classification • skimming/scanning for specific information
• understanding gist and paraphrase

### Academic Reading · source page 150

144
Practice Test 4
READING PASSAGE 2 Why some women cross the finish line ahead of men
Questions 14-23
Questions 24-27
Suggested approach
• Read the task rubric carefully. Note that you
must use a maximum of three words for each
answer.
• You can take a straightforward approach to this
set of questions.
• Read question 24. Note that it makes reference
to the annual survey.
• Skim through the text until it discusses an
annual survey. This is in paragraph D.
• Look for a comment on changing numbers of
female managers or directors. In the text the
survey is quoted as showing a “doubling of the
numbers”. Thus the change referred to in the
question is the fact that the numbers have
doubled.
• Read the question again to make sure you give
a grammatically appropriate answer. In this
case, the best answer would be “it has doubled’
although “double” alone would be acceptable
because it is an understandable response to the
question.
• Repeat this procedure with questions 25 to 27.

Question | Answer
14 | E
15 | G
16 | A
17 | C
18 | F
19 | D
20 | A
21 | S
22 | M
23 | S
24 | (it has) double(d) // doubling
25 | de-layering
26 | demographic trends
27 | employers
Locations for24–27: “This year the survey shows a doubling of the number of women serving as non-executive directors …”; “Sears said that this (de-layering) has halted progress for women …”; “Demographic trends suggest that the number of women going into employment is steadily increasing.”; “Until there is a belief among employers until they value the difference nothing will change.”
Questions Task Skills tested

14-19 Identifying paragraphs • skimming for detailed information
• understanding paraphrase and summary
20-23 Matching • skimming/scanning for speakers and information
• understanding gist and paraphrase
24-27 Short-answer questions • skimming for specific information
• identifying question focus


### Academic Reading · source page 151

145
Answer keys
READING PASSAGE 3 Population viability analysis
Questions 28-31
Questions 32-35
Suggested approach
• Read the task rubric carefully. Note that these
questions are based on Part B of the reading
passage. You will have to decide which
paragraphs in this part cover which processes.
• Note that there are two extra processes which
are not described. The extra processes will be
close to the correct answers but not correct.
Read the text carefully so that you do not fall
into any traps.
• Read through the list of processes to familiarise
yourself with them.
• Read paragraph A carefully, noting any
sections that relate to the processes described in
i - vi.
• Paragraph A states that survival of a species is
largely a “matter of chance” and that not all
animals produce young at the same rate. The
meaning of this paragraph can therefore be
glossed as “the haphazard nature of
reproduction” and vi is the correct answer to
question 32.
• Repeat this procedure with questions 33-35.

Question | Answer | Focus (where supplied)
28 | YES
29 | NO
30 | NO
31 | NOT GIVEN
32 | vi | The fluctuation in reproduction rates.
33 | iii | The problems of having a small or unequal number of one sex.
34 | i | The effect on survival of an animal’s ability to adapt to changes and therefore avoid extinction.
35 | ii | The fluctuating environment in Australia, e.g. fire, flood and drought.
36 | will/may not survive // will/may/could become extinct
37 | locality // distribution
38 | logging takes place/occurs
39 | B
Questions Task Skills tested

28-31 Yes, No, Not Given •skimming for detailed information
• understanding gist and paraphrase
• identifying opinion
32-35 Matching (processes to
paragraphs)
• detailed reading
• identifying main and supporting points
• understanding gist and paraphrase
36-38 Sentence completion • skimming for information
•  understanding paraphrase
39 Global multiple choice • understanding the overall theme of the passage

1. viii

2. i

3. ix

4. iii

5. vi

6. molten glass / ribbon of glass / molten glass ribbon

7. belt of steel / steel belt / moving belt

8. moulds / lightbulb moulds

9. A

10. B

11. A

12. C

13. A

14. E

15. G

16. A

17. C

18. F

19. D

20. A

21. S

22. M

23. S

24. double / doubled / it has double / it has doubled / doubling

25. de-layering

26. demographic trends

27. employers

28. YES

29. NO

30. NO

31. NOT GIVEN

32. vi

33. iii

34. i

35. ii

36. will not survive / may not survive / will become extinct / may become extinct / could become extinct

37. locality / distribution

38. logging takes place / logging occurs

39. B

## A 类写作

### Writing material: c1-t4-w-1

Original development map and legend inspected. Title: Village of Chorleywood showing development between 1868 and 1994. Four shading periods: 1868–1883 (unshaded); 1883–1922 (horizontal stripes); 1922–1970 (solid grey); 1970–1994 (diagonal hatching). Thick single lines are main roads. The railway, shown by alternating dark/light segments, was built in 1909 and runs across the lower part of the map past Chorleywood Station. The motorway is a double line on the right and was built in 1970. Chorleywood Park and Golf course occupy the central area. The earliest settlement is a small area next to the western main road near the park; development in 1883–1922 extends toward and south of the station/railway. Grey 1922–1970 development lies west of the western road and in a larger area to the right of the station below the railway. The latest hatched development is concentrated around the motorway, at its junctions with the main road and railway, with areas on both sides of it. Development spreads as transport routes are added, but the map gives no numeric population figures, plot areas or travel times. No compass is supplied; spatial descriptions should follow the printed layout without inventing bearings.



### Writing material: c1-t4-w-2

The original early-format prompt gives a statement and asks for a written argument or case for an educated reader. It does not contain a separate To what extent question. Preserve this format and accept a justified position on changing careers and lifelong education.



## 口语

### 原书口语任务 · reference on source page 99

INTERVIEWER’S NOTES
THE EXCURSION
Select an authentic tourist destination about two hours` drive from your city.
Provide the following information according to local facts:
• Details about what can be seen/done there
• Special bus provided
• Departure and arrival times
• Suggest appropriate local cost
• Meals not provided — students can buy or bring food
• Walking shoes recommended

[Complete original page](assets/6f476f1bc3be1b66f39c072dd35b776d9ce363b71ddc6690c324ff9d12381b2d.jpg)
