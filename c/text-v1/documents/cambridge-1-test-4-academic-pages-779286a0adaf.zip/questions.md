# 剑雅 1 · Test 4

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/9630e170f41ff11fd5f6033971ce7db525bfb704a24be752d49cda13135cea1a.jpg; PDF page 81; full -->

```text
Practice Test 4 — LISTENING
SECTION 1 Questions 1–12
Questions 1–5: Circle the appropriate letter.
Example: What are the students looking for?
A Main Hall [circled example] / B Great Hall / C Old Hall / D Old Building
1 Where is the administration building? Original map options A–D retained below.
2 How many people are waiting in the queue? A 50 / B 100 / C 200 / D 300
3 What does the woman order for lunch? Original food options A–D retained below.
```

[Original question page](assets/9630e170f41ff11fd5f6033971ce7db525bfb704a24be752d49cda13135cea1a.jpg)

![Original figure](assets/9630e170f41ff11fd5f6033971ce7db525bfb704a24be752d49cda13135cea1a.jpg)

<!-- Source: /api/assets/475ba48bb4058599240e5042474de82dd42cb90142b6979b30de7d18e439d415.jpg; PDF page 82; full -->

```text
Practice Test 4
4 What does the woman order to drink? Original drink options A–D retained below.
5 How much money does the woman give the man? A $2.00 / B $3.00 / C $3.50 / D $5.00
Questions 6–10
Complete the registration form using NO MORE THAN THREE WORDS.
Name of student: (6) __________
Address: (7) Flat 5/ __________
Town: (8) __________
Tel: (9) __________
Course: (10) __________
Questions 11–12
11 What did the man buy for her to eat? Original illustrated options A–D retained below.
12 What must the students do as part of registration at the university?
A Check the notice board in the Law Faculty.
B Find out about lectures.
C Organise tutorial groups.
D Pay the union fees.
```

[Original question page](assets/475ba48bb4058599240e5042474de82dd42cb90142b6979b30de7d18e439d415.jpg)

![Original figure](assets/475ba48bb4058599240e5042474de82dd42cb90142b6979b30de7d18e439d415.jpg)

### Part 2

<!-- Source: /api/assets/713a1533716aef09bd884d8bffe3da6e43c843ab8a86a33444573d29ac70628f.jpg; PDF page 83; full -->

```text
Listening — SECTION 2 Questions 13–21
Complete the notes. Write NO MORE THAN THREE WORDS for each answer.
STUDENT BANKING
Recommended Banks | Location
Barclays | Realty Square
National Westminster | Example: Preston Park
Lloyds | City Plaza
Midland | (13) __________
Note: May not be allowed all facilities given to resident students.
Funding
 Must provide (14)  ....................................  I can support myself.
 Services will depend on personal circumstances and discretion of Bank Manager.
Opening an account
 Take with me: (15) .................................... and letter of enrolment.
 Recommended account: (16) .........................................................
 Bank supplies: (17) ................................ and chequecard which guarantees
    cheques.
Other services
 Cashcard: (you can (18) ....................................... cash at any time.)
 Switch/Delta cards: (take the money (19) .......................... the account.)
Overdraft
 Must have (20)  ....................................................
Sometimes must pay interest.
Opening times
 Most banks open until (21) ...................................... during the week.
 Some open for a limited time on Saturdays.

```

[Original question page](assets/713a1533716aef09bd884d8bffe3da6e43c843ab8a86a33444573d29ac70628f.jpg)

### Part 3

<!-- Source: /api/assets/1b7f6901713e59ad75c7648fe553b927118c6f94b13706e733ac4accbe520e20.jpg; PDF page 84; full -->

```text
78
Practice Test 4
SECTION 3     Questions 22-31
Questions 22-25
Complete the factsheet. Write NO MORE THAN THREE WORDS for each answer.
FACTSHEET - Aluminium Cans
• (22) ............................................ produced every day in the US — more cans
produced than nails or (23) .......................................................
• each can weighs 0.48 ounces — thinner than two
(24) .........................................................................
• can take more than 90 pounds of pressure per square inch — over
(25) ............................................ the pressure of a car tyre
Questions 26-31
Label the aluminium can. Write NO MORE THAN THREE WORDS  for each answer.
Original aluminium can diagram retained below. Label positions:
Body — (26) __________ at base.
(27) __________ — reflective surface of aluminium can easily be decorated.
Base — shaped like (28) __________ to withstand pressure.
Magnified seam beside rim — (29) __________.
Lid — makes up (30) __________ of total weight.
Top-left two-arrow label — (31) __________.
The printed top-left label is incorrectly numbered (26), duplicating the body label. It is presented as (31) here to match the question range 26–31 and the source answer key. Fixed labels Tab, Rim, Body, Lid and Base remain on the original diagram.
```

[Original question page](assets/1b7f6901713e59ad75c7648fe553b927118c6f94b13706e733ac4accbe520e20.jpg)

![Original figure](assets/1b7f6901713e59ad75c7648fe553b927118c6f94b13706e733ac4accbe520e20.jpg)

### Part 4

<!-- Source: /api/assets/c1db2a1861e50c5f1c9e5b5e311a15b44adc5294bcfd5f7b6ec79683135faacd.jpg; PDF page 85; full -->

```text
79
Listening
SECTION 4 Questions 32-42
Questions 32-42
Complete the lecture notes. Use NO MORE THAN THREE WORDS for each answer.
Purpose of the mini lecture
To experience To find out about
(32) .....................................................     (33)..........................................................
The three strands of Sports Studies are:
a Sports psychology
b Sports (34) ..............................................
c Sports physiology
a The psychologists work with
a The psychologists work with (35) ...................................................................
They want to discover what (36) ...................................................................
b Sports marketing looks at (37) ...................................................................
Sport now competes with (38) ...................................................................
Spectators want (39) ...................................................................
c Sports physiology is also known as
(40) ...................................................................
Macro levels look at (41) ...................................................................
Micro level looks at (42) ...................................................................
```

[Original question page](assets/c1db2a1861e50c5f1c9e5b5e311a15b44adc5294bcfd5f7b6ec79683135faacd.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/3d9bfe05fc009c91b9aea390e413a6ab71d1078768fbd7e5f6f5890f34f8602d.jpg; PDF page 86; full -->

```text
80
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13 which are based on Reading Passage 1
below
Practice Test 4
GLASS
CAPTURING THE DANCE
OF LIGHT
A  Glass, in one form or another, has long been in noble
service to humans As one of the most widely used
of manufactured materials, and certainly the most
versatile, it can be as imposing as a telescope mirror
the width of a tennis court or as small and simple as
a marble rolling across dirt The uses of this
adaptable material have been broadened
dramatically by new technologies glass fibre
optics — more than eight million miles —
carrying telephone and television signals
across nations, glass ceramics serving as the
nose cones of missiles and as crowns for
teeth; tiny glass beads taking radiation doses
inside the body to specific organs, even a new
type of glass fashioned of nuclear waste in
order to dispose of that unwanted material.
B   On the horizon are optical computers These
could   store   programs   and   process
information by means of light - pulses from
tiny lasers - rather than electrons And the
pulses would travel over glass fibres, not
copper wire These machines could function
hundreds of times faster than today’s
electronic computers and hold vastly more
information Today fibre optics are used
to obtain a clearer image of smaller and
smaller objects than ever before - even bacterial
```

[Original question page](assets/3d9bfe05fc009c91b9aea390e413a6ab71d1078768fbd7e5f6f5890f34f8602d.jpg)

![Original figure](assets/3d9bfe05fc009c91b9aea390e413a6ab71d1078768fbd7e5f6f5890f34f8602d.jpg)

<!-- Source: /api/assets/4bf6e2e0be405f1189affb9b805cf09000194ad05a6a4ab12f9fd50774465f23.jpg; PDF page 87; full -->

```text
81
viruses. A new generation of optical
instruments is emerging that can provide
detailed imaging of the inner workings
of cells. It is the surge in fibre optic use
and in liquid crystal displays that has set
the U.S. glass industry (a 16 billion dollar
business employing some 150,000
workers) to building new plants to meet
demand.
C  But it is not only in technology and
commerce that glass has widened its
horizons. The use of glass as art, a
tradition spins back at least to Roman
times,   is   also   booming.   Nearly
everywhere, it seems, men and women
are blowing glass and creating works of
art. «I didn’t sell a piece of glass until
1975,» Dale Chihuly said, smiling, for
in the 18 years since the end of the dry
spell, he has become one of the most
financially successful artists of the 20th
century. He now has a new commission
- a glass sculpture for the headquarters
building of a pizza company - for which
his fee is half a million dollars.
D  But not all the glass technology that
touches our lives is ultra-modern.
Consider the simple light bulb; at the turn
of the century most light bulbs were hand
blown, and the cost of one was equivalent
to half a day’s pay for the average worker.
In effect, the invention of the ribbon
machine by Corning in the 1920s lighted
a nation. The price of a bulb plunged.
Small wonder that the machine has been
called one of the great mechanical
achievements of all time. Yet it is very
simple: a narrow ribbon of molten glass
travels over a moving belt of steel in
which there are holes. The glass sags
through the holes and into waiting
moulds. Puffs of compressed air then
shape the glass. In this way, the envelope
of a light bulb is made by a single
machine at the rate of 66,000 an hour, as
compared with 1,200 a day produced by
a team of four glassblowers.
E   The secret of the versatility of glass lies
in its interior structure. Although it is
rigid, and thus like a solid, the atoms are
arranged in a random disordered fashion,
characteristic of a liquid. In the melting
process, the atoms in the raw materials
are disturbed from their normal position
in the molecular structure; before they
can find their way back to crystalline
arrangements the glass cools. This
looseness in molecular structure gives
the material what engineers call
tremendous “formability” which allows
technicians to tailor glass to whatever
they need.
F   Today, scientists continue to experiment
with new glass mixtures and building
designers test their imaginations with
applications of special types of glass. A
London architect, Mike Davies, sees
even more dramatic buildings using
molecular chemistry. “Glass is the great
building material of the future, the
«dynamic skin»,’ he said. “Think of glass
that has been treated to react to electric
currents going through it, glass that will
change from clear to opaque at the push
of a button, that gives you instant
curtains. Think of how the tall buildings
in New York could perform a symphony
of colours as the glass in them is made
to change colours instantly.” Glass as
instant curtains is available now, but the
cost is exorbitant. As for the glass
changing colours instantly, that may
come true. Mike Davies’s vision may
indeed be on the way to fulfilment.
Adapted from “Glass: Capturing the Dance of Light” by William S. Ellis, National Geographic
Reading
```

[Original question page](assets/4bf6e2e0be405f1189affb9b805cf09000194ad05a6a4ab12f9fd50774465f23.jpg)

<!-- Source: /api/assets/881e63d3d24e872e59062da7247eb876a3c4c8ee36af09be9613a3489746ca7e.jpg; PDF page 88; full -->

```text
82
Practice Test 4
Example Answer
     Paragraph A x
Questions 1-5
Reading Passage 1 has six paragraphs (A-F). Choose the most suitable heading for each
paragraph from the list of headings below. Write the appropriate numbers (i-x) in boxes 1-5
on your answer sheet. Paragraph A has been done for you as an example.
NB There are more headings than paragraphs so you will not use all of them.
You may use any heading more at once.
List of Headings
i Growth in the market for glass crafts
ii Computers and their dependence on glass
iii What makes glass so adaptable
iv Historical development of glass
v Scientists’ dreams cost millions
vi Architectural experiments with glass
vii Glass art galleries flourish
viii Exciting innovations in fibre optics
ix A former glass technology
x Everyday uses of glass
1 Paragraph B
2 Paragraph C
3 Paragraph D
4 Paragraph E
5 Paragraph F
```

[Original question page](assets/881e63d3d24e872e59062da7247eb876a3c4c8ee36af09be9613a3489746ca7e.jpg)

<!-- Source: /api/assets/d4175a039e612eba0f507a11367902538a3ebfcb692857f37c731539440b743b.jpg; PDF page 89; full -->

```text
83
Reading
Questions 6-8
The diagram below shows the principle of Coming’s ribbon machine. Label the diagram by
selecting NO MORE THAN THREE WORDS from the Reading Passage to fill each
numbered space. Write your answers in boxes 6-8 on your answer sheet.
Diagram positions (original retained): (6) incoming material above the moving ribbon; (7) moving horizontal strip with holes; (8) shaped envelopes beneath the strip.
Questions 9-13
Look at the list below of the uses of glass. According to the passage, state whether these uses
exist today, will exist in the future or are not mentioned by the writer. In boxes 9-13 write
A if the uses exist today
B  if the uses will exist in the future
C if the uses are not mentioned by the writer
9 dental fittings
10 optical computers
11 sculptures
12 fashions
13 curtains
```

[Original question page](assets/d4175a039e612eba0f507a11367902538a3ebfcb692857f37c731539440b743b.jpg)

![Original figure](assets/d4175a039e612eba0f507a11367902538a3ebfcb692857f37c731539440b743b.jpg)

<!-- Source: /api/assets/2cfc95e4ffbff089026d90bcd11e2904998a1c0f43acb709dfcfa667d89b26c7.jpg; PDF page 90; full -->

```text
84
Practice Test 4
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-27 which are based on Reading
Passage 2 below
Why some women cross
the finish line ahead of men
RECRUITMENT
The course is tougher but women are
 staying the distance, reports Andrew
 Crisp.
A  Women who apply for jobs in middle or
senior management have a higher success
rate than men, according to an
employment survey. But of course far
fewer of them apply for these positions.
The study, by recruitment consultants NB
Selection, shows that while one in six
men who appear on interview shortlists
get jobs, the figure rises to one in four
for women.
B  The study concentrated on applications
for management positions in the $45,000
to $110,000 salary range and found that
women are more successful than men in
both the private and public sectors Dr
Elisabeth Marx from London-based NB
Selection described the findings as
```

[Original question page](assets/2cfc95e4ffbff089026d90bcd11e2904998a1c0f43acb709dfcfa667d89b26c7.jpg)

![Original figure](assets/2cfc95e4ffbff089026d90bcd11e2904998a1c0f43acb709dfcfa667d89b26c7.jpg)

<!-- Source: /api/assets/2ab2d6516257c1ae02cda278eb8c977f608fb8ecdbde08bf2928f2bcea13bcbf.jpg; PDF page 91; full -->

```text
85
Rreading
encouraging for women, in that they send
a positive message to them to apply for
interesting management positions. But
she added, “We should not lose sight of
the fact that significantly fewer women
apply for senior positions in comparison
with men.”
C  Reasons for higher success rates among
women are difficult to isolate. One
explanation suggested is that if a woman
candidate manages to get on a shortlist,
then she has probably already proved
herself to be an exceptional candidate.
Dr Marx said that when women apply
for positions they tend to be better
qualified than their male counterparts but
are more selective and conservative in
their job search. Women tend to research
thoroughly before applying for positions
or attending interviews. Men, on the
other hand, seem to rely on their ability
to sell themselves and to convince
employers that any shortcomings they
have will not prevent them from doing a
good job.
D  Managerial and executive progress made
by women is confirmed by the annual
survey of boards of directors carried out
by Korn/Ferry/Carre/ Orban
International. This year the survey shows
a doubling of the number of women
serving as non-executive directors
compared with the previous year.
However, progress remains painfully
slow and there were still only 18 posts
filled by women out of a total of 354 non-
executive positions surveyed. Hilary
Sears, a partner with Korn/Ferry, said,
“Women have raised the level of grades
we are employed in but we have still not
broken through barriers to the top.”
E   In Europe a recent feature of corporate
life in the recession has been the de-
layering of management structures.
Sears said that this has halted progress
for women in as much as de-layering has
taken place either where women are
working or in layers they aspire to. Sears
also noted a positive trend from the
recession, which has been the growing
number of women who have started up
on their own.
F   In business as a whole, there are a
number of factors encouraging the
prospect of greater equality in the
workforce. Demographic trends suggest
that the number of women going into
employment is steadily increasing. In
addition a far greater number of women
are now passing through higher
education, making them better qualified
to move into management positions.
G  Organisations such as the European
Women’s Management Development
Network  provide  a  range  of
opportunities for women to enhance
their skills and contacts. Through a series
of both pan-European and national
workshops and conferences the barriers
to women in employment are being
broken down. However, Ariane Berthoin
Antal, director of the International
Institute     for Organisational Change of
Archamps in France, said that there is
only anecdotal evidence of changes in
recruitment patterns. And she said, “It”s
still so hard for women to even get on to
shortlists -there are so many hurdles and
barriers.’ Antal agreed that there have
been some positive signs but said “Until
there is a belief among employers, until
they value the difference, nothing will
change.”
```

[Original question page](assets/2ab2d6516257c1ae02cda278eb8c977f608fb8ecdbde08bf2928f2bcea13bcbf.jpg)

<!-- Source: /api/assets/00b5f4e56f6a70c8127fa4960665c2964a255b937fe2f8dccdc5044753353bf7.jpg; PDF page 92; full -->

```text
86
Example Answer
 The salary range studied in the NB Selection survey.        B
Practice Test 4
Questions 14-19
Reading Passage 2 has 7 paragraphs (A-G). State which paragraph discusses each of the
points below. Write the appropriate letter (A-G) in boxes 14-19 on your answer sheet.
14 The drawbacks of current company restructuring patterns.
15 Associations that provide support for professional women.
16 The success rate of female job applicants for management positions.
17 Male and female approaches to job applications.
18 Reasons why more women are being employed in the business sector.
19 The improvement in female numbers on company management structures.
Questions 20-23
The author makes reference to three consultants in the Reading Passage. Which of the list of
points below do these consultants make? In boxes 20-23 write
M if the point is made by Dr Marx
S if the point is made by Hilary Sears
A if the point is made by Ariane Berthoin Antal
20 Selection procedures do not favour women.
21 The number of female-run businesses is increasing.
22 Male applicants exceed female applicants for top posts.
23 Women hold higher positions now than they used to.
Questions 24-27
Using NO MORE THAN THREE WORDS answer the following questions. Write your
answers in boxes 24-27 on your answer sheet.
24 What change has there been in the number of women in top management positions
detailed in the annual survey?
25 What aspect of company structuring has disadvantaged women?
26 What information tells us that more women are working nowadays?
27 Which group of people should change their attitude to recruitment?
```

[Original question page](assets/00b5f4e56f6a70c8127fa4960665c2964a255b937fe2f8dccdc5044753353bf7.jpg)

<!-- Source: /api/assets/42eb56cf371842afc7765e2446bfb8f91661ca6e5bd7d80dbedda0008feec48d.jpg; PDF page 93; full -->

```text
87
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 28-39 which are based on Reading Passage
3 below.
Population viability analysis
Part A
To make political decisions about the extent and type of forestry in a region
it is important to understand the consequences of those decisions. One tool
for assessing the impact of forestry on the ecosystem is population viability
analysis (PVA). This is a tool for predicting the probability that a species
will become extinct in a particular region over a specific period. It has been
successfully used in the United States to provide input into resource
exploitation decisions and assist wildlife managers and there is now enormous
potential for using population viability to assist wildlife management in
Australia’s forests.
A species becomes extinct when the last individual dies. This observation is
a useful starting point for any discussion of extinction as it highlights the
role of luck and chance in the extinction process. To make a prediction about
extinction we need to understand the processes that can contribute to it and
these fall into four broad categories which are discussed below.
Part B
A  Early attempts to predict population viability were based on demographic
uncertainty Whether an individual survives from one year to the next
will largely be a matter of chance. Some pairs may produce several young
in a single year while others may produce none in that same year. Small
populations will fluctuate enormously because of the random nature of
birth and death and these chance fluctuations can cause species extinctions
even if, on average, the population size should increase. Taking only this
uncertainty of ability to reproduce into account, extinction is unlikely if
the number of individuals in a population is above about 50 and the
population is growing.
B Small populations cannot avoid a certain amount of inbreeding. This is
particularly true if there is a very small number of one sex. For example,
if there are only 20 individuals of a species and only one is a male, all
future individuals in the species must be descended from that one male.
For most animal species such individuals are less likely to survive and
reproduce. Inbreeding increases the chance of extinction.
```

[Original question page](assets/42eb56cf371842afc7765e2446bfb8f91661ca6e5bd7d80dbedda0008feec48d.jpg)

<!-- Source: /api/assets/104d4bb71bbc5d6049985a6f15e8e2a7bbd7d9e8865d64d7e46b95c8a8671a8e.jpg; PDF page 94; full -->

```text
88
Practice Test 4
C   Variation within a species is the raw material upon which natural selection
acts. Without genetic variability a species lacks the capacity to evolve and
cannot adapt to changes in its environment or to new predators and new
diseases. The loss of genetic diversity associated with reductions in
population size will contribute to the likelihood of extinction.
D  Recent research has shown that other factors need to be considered.
Australia’s environment fluctuates enormously from year to year. These
fluctuations add yet another degree of uncertainty to the survival of many
species. Catastrophes such as fire, flood, drought or epidemic may reduce
population sizes to a small fraction of their average level. When allowance
is made for these two additional elements of uncertainty the population
size necessary to be confident of persistence for a few hundred years may
increase to several thousand.
Part C
Beside these processes we need to bear in mind the distribution of a population.
A species that occurs in five isolated places each containing 20 individuals
will not have the same probability of extinction as a species with a single
population of 100 individuals in a single locality.
Where logging occurs (that is, the cutting down of forests for timber) forest-
dependent creatures in that area will be forced to leave. Ground-dwelling
herbivores may return within a decade. However, arboreal marsupials (that is
animals which live in trees) may not recover to pre-logging densities for over
a century. As more forests are logged, animal population sizes will be reduced
further. Regardless of the theory or model that we choose, a reduction in
population size decreases the genetic diversity of a population and increases
the probability of extinction because of any or all of the processes listed above.
It is therefore a scientific fact that increasing the area that is loaded in any
region will increase the probability that forest-dependent animals will become
extinct.
```

[Original question page](assets/104d4bb71bbc5d6049985a6f15e8e2a7bbd7d9e8865d64d7e46b95c8a8671a8e.jpg)

<!-- Source: /api/assets/5f05e231ebfa705143a6bf0cbb6f4c9ffc7bf3150051a2ed33918930f628335e.jpg; PDF page 95; full -->

```text
89
Reading
Questions 28-31
Do the following statements agree with the views of the writer in Part A of Reading
Passage 3? In boxes 28-31 on your answer sheet write
YES if the statement agrees with the writer
NO if the statement contradicts the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
Example Answer
 A link exist between the consequences of decisions and
 the decision making process itself. YES
28 Scientists are interested in the effect of forestry on native animals.
29 PVA has been used in Australia for many years.
30 A species is said to be extinct when only one individual exists.
31 Extinction is a naturally occurring phenomenon.
Questions 32-35
These questions are based on Part B of Reading Passage 3.
In paragraphs A to D the author describes four processes which may contribute to the
extinction of a species. Match the list of processes (i-vi) to the paragraphs. Write the
appropriate number (i-vi) in boxes 32-35 on your answer sheet.
NB There are more processes than paragraphs so you will not use all of them.
Processes
i Loss of ability to adapt
ii Natural disasters
iii An imblance of the sexes
iv Human disasters
v Evolution
vi The haphazard nature of
reproduction
32 Paragraph A
33 Paragraph B
34 Paragraph C
35 Paragraph D
```

[Original question page](assets/5f05e231ebfa705143a6bf0cbb6f4c9ffc7bf3150051a2ed33918930f628335e.jpg)

<!-- Source: /api/assets/314ff70febf95e6e099e131b62d1d458e3c969eead0663f18e386b7dbffccf9c.jpg; PDF page 96; full -->

```text
90
Questions 36-38
Based on your reading of Part C, complete the sentences below with words taken from the
passage. Use NO MORE THAN THREE WORDS for each answer. Write your answers in
boxes 36-38 on your answer sheet.
While the population of a species may be on the increase, there is always a
chance that small isolated groups ... (36) ...
Survival of a species depends on a balance between the size of a population
and its ... (37) ...
The likelihood that animals which live in forests will become extinct is
increased when ... (38) ...
Question 39
Choose the appropriate letter A-D and write it in box 39 on your answer sheet.
39 An alternative heading for the passage could be:
A The protection of native flora and fauna
B Influential factors in assessing survival probability
C An economic rationale for the logging of forests
D Preventive measures for the extinction of a species
Practice Test 4
```

[Original question page](assets/314ff70febf95e6e099e131b62d1d458e3c969eead0663f18e386b7dbffccf9c.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/2feb74d4b6f1d7af24be9015144f9ef8fde0daf564274db7f4f84668c18f7b50.jpg; PDF page 97; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

Chorleywood is a village near London whose population has increased steadily since the middle of the nineteenth century. The map below shows the development of the village.

Write a report for a university lecturer describing the development of the village.

You should write at least 150 words.

The original figure is retained for the plotted values, labels, arrows and spatial layout.
```

[Original question page](assets/2feb74d4b6f1d7af24be9015144f9ef8fde0daf564274db7f4f84668c18f7b50.jpg)

![Original figure](assets/2feb74d4b6f1d7af24be9015144f9ef8fde0daf564274db7f4f84668c18f7b50.jpg)

### Task 2

<!-- Source: /api/assets/841eb0357da99335be244ee5317733a60f75a0a46407110b1befdb2656ae3a7c.jpg; PDF page 98; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic:

The idea of having a single career is becoming an old fashioned one. The new fashion will be to have several careers or ways of earning money and further education will be something that continues throughout life.

You should write at least 250 words.

Use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.
```

[Original question page](assets/841eb0357da99335be244ee5317733a60f75a0a46407110b1befdb2656ae3a7c.jpg)

## 口语

### 原书口语任务

<!-- Source: /api/assets/c99c69138bca78867b528f8fcde7e8c860bd6e340c2d64b576570c09457f5482.png; PDF page 99; full -->

```text
93
SPEAKING
Speaking
CANDIDATE`S CUE CARD       Task 4
THE EXCURSION
The Overseas Students` Club is organising an excursion to a local tourist spot.
You are thinking of joining the exursion. Your examiner is one of the
organisers.
Ask the examiner about: destination
means of transport
length of excursion
cost
meals
clothing/equipment
```

[Original question page](assets/c99c69138bca78867b528f8fcde7e8c860bd6e340c2d64b576570c09457f5482.png)
