# 剑雅 15 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 119

TEST 2 LISTENING
1 Eustatis
2 review
3 dance
4 Chat
5 healthy
6 posters
7 wood
8 lake
9 insects
10 blog
11 C
12 A
13 B
14 C
15 E
16 C
17 B
18 A
19 G
20 D
21 B
22 D
23 B
24 C
25 G
26 B
27 D
28 C
29 H
30 F
31 irrigation
32 women
33 wire(s)
34 seed(s)
35 posts
36 transport
37 preservation
38 fish(es)
39 bees
40 design
21&22 IN EITHER ORDER: B,D
23&24 IN EITHER ORDER: B,C
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. Eustatis

2. review

3. dance

4. Chat

5. healthy

6. posters

7. wood

8. lake

9. insects

10. blog

### Part 2 · source page 119

TEST 2 LISTENING
1 Eustatis
2 review
3 dance
4 Chat
5 healthy
6 posters
7 wood
8 lake
9 insects
10 blog
11 C
12 A
13 B
14 C
15 E
16 C
17 B
18 A
19 G
20 D
21 B
22 D
23 B
24 C
25 G
26 B
27 D
28 C
29 H
30 F
31 irrigation
32 women
33 wire(s)
34 seed(s)
35 posts
36 transport
37 preservation
38 fish(es)
39 bees
40 design
21&22 IN EITHER ORDER: B,D
23&24 IN EITHER ORDER: B,C
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. C

12. A

13. B

14. C

15. E

16. C

17. B

18. A

19. G

20. D

### Part 3 · source page 119

TEST 2 LISTENING
1 Eustatis
2 review
3 dance
4 Chat
5 healthy
6 posters
7 wood
8 lake
9 insects
10 blog
11 C
12 A
13 B
14 C
15 E
16 C
17 B
18 A
19 G
20 D
21 B
22 D
23 B
24 C
25 G
26 B
27 D
28 C
29 H
30 F
31 irrigation
32 women
33 wire(s)
34 seed(s)
35 posts
36 transport
37 preservation
38 fish(es)
39 bees
40 design
21&22 IN EITHER ORDER: B,D
23&24 IN EITHER ORDER: B,C
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B / D

22. B / D

23. B / C

24. B / C

25. G

26. B

27. D

28. C

29. H

30. F

### Part 4 · source page 119

TEST 2 LISTENING
1 Eustatis
2 review
3 dance
4 Chat
5 healthy
6 posters
7 wood
8 lake
9 insects
10 blog
11 C
12 A
13 B
14 C
15 E
16 C
17 B
18 A
19 G
20 D
21 B
22 D
23 B
24 C
25 G
26 B
27 D
28 C
29 H
30 F
31 irrigation
32 women
33 wire(s)
34 seed(s)
35 posts
36 transport
37 preservation
38 fish(es)
39 bees
40 design
21&22 IN EITHER ORDER: B,D
23&24 IN EITHER ORDER: B,C
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. Irrigation

32. women

33. wire / wires

34. seed / seeds

35. posts

36. transport

37. preservation

38. fish / fishes

39. bees

40. design

## A 类阅读

### Academic Reading · source page 120

TEST 2 READING
1 B
2 C
3 F
4 D
5 E
6 A
7 safety
8 traffic
9 carriageway
10 mobile
11 dangerous
12 communities
13 healthy
14 F
15 A
16 D
17 A
18 genetic traits
19 heat loss
20 ears
21 (insulating) fat
22 (carbon) emissions
23 B
24 C
25 A
26 C
27 C
28 A
29 B
30 B
31 D
32 F
33 H
34 C
35 D
36 E
37 NOT GIVEN
38 YES
39 NO
40 NO
If you score: 0–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. B

2. C

3. F

4. D

5. E

6. A

7. safety

8. traffic

9. carriageway

10. mobile

11. dangerous

12. communities

13. healthy

14. F

15. A

16. D

17. A

18. genetic traits

19. heat loss

20. ears

21. fat / insulating fat

22. emissions / carbon emissions

23. B

24. C

25. A

26. C

27. C

28. A

29. B

30. B

31. D

32. F

33. H

34. C

35. D

36. E

37. NOT GIVEN

38. YES

39. NO

40. NO

## A 类写作

### Writing material: c15-t2-w-1

Millions of visitors2010/11/12/13/14/15/16/17. Total1/1.25/1.5/2/2.5/2.75/2.75/3.5. Staying on cruise ships0.25/0.5/0.25/0.5/1/1.25/1.5/2. Staying on island0.75/0.75/1.25/1.5/1.5/1.5/1.25/1.5. Grid-aligned readings; intermediate quarter-million readings approximate. Total grows except2015–16plateau. Cruise visitors overtake island visitors in2016. Island stays plateau2013–15 then dip/recover. Do not count cruise passengers as staying on island, double-count total plus components, or invent island name.



### Writing material: c15-t2-w-2

Evaluate categorical prediction that nobody will buy printed newspapers/books because all desired reading is free online. Absolute nobody/everything and payment assumption matter; a generic internet essay is insufficient.



## 口语
