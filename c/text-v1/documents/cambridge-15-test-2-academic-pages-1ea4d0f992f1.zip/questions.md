# 剑雅 15 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/b55bedb9235207cf3487353b2fb563bf0e50b982c2f05c09f216aeedc8203887.jpg; PDF page 29; full -->

```text
LISTENING
PART 1 Questions 1–10
Questions 1–4
Complete the table below. Write ONE WORD ONLY for each answer.
Festival information
| Date | Type of event | Details |
| --- | --- | --- |
| 17th | a concert | performers from Canada |
| 18th | a ballet | company called (1) __________ |
| 19th–20th (afternoon) | a play | type of play: a comedy called Jemima; has had a good (2) __________ |
| 20th (evening) | a (3) __________ show | show is called (4) __________ |
Questions 5–10
Complete the notes below. Write ONE WORD ONLY for each answer.
Workshops
• Making (5) __________ food
• (children only) Making (6) __________
• (adults only) Making toys from (7) __________ using various tools
Outdoor activities
• Swimming in the (8) __________
• Walking in the woods, led by an expert on (9) __________
See the festival organiser’s (10) __________ for more information
```

[Original question page](assets/b55bedb9235207cf3487353b2fb563bf0e50b982c2f05c09f216aeedc8203887.jpg)

### Part 2

<!-- Source: /api/assets/3417ccf7388ba7e5a14035309ec1af830775ab64e72ffad5a4967fb5652c19fa.jpg; PDF page 30; full -->

```text
Test 2
PART 2 Questions 11-20
Questions 11-14
Choose the correct letter, A, B or C.




32
Minster Park
11 The park was originally established
A as an amenity provided by the city council.
B as land belonging to a private house.
C as a shared area set up by the local community.
12 Why is there a statue of Diane Gosforth in the park?
A She was a resident who helped to lead a campaign.
B She was a council member responsible for giving the public access.
C She was a senior worker at the park for many years.
13 During the First World War, the park was mainly used for
A exercises by troops.
B growing vegetables.
C public meetings.
14 When did the physical transformation of the park begin?
A 2013
B 2015
C 2016
```

[Original question page](assets/3417ccf7388ba7e5a14035309ec1af830775ab64e72ffad5a4967fb5652c19fa.jpg)

<!-- Source: /api/assets/fccf30448640a9e6925172f68e1b49c466476c6de49fdeee65a92ce82eabd32d.jpg; PDF page 31; full -->

```text
Questions 15–20
Label the map below. Write the correct letter, A–I, next to Questions 15–20.
Minster Park
[Original labelled map retained: River at north, west/east/south gates, lily pond and locations A–I. Use the original map to answer.]
15 statue of Diane Gosforth __________
16 wooden sculptures __________
17 playground __________
18 maze __________
19 tennis courts __________
20 fitness area __________
```

[Original question page](assets/fccf30448640a9e6925172f68e1b49c466476c6de49fdeee65a92ce82eabd32d.jpg)

![Original figure](assets/fccf30448640a9e6925172f68e1b49c466476c6de49fdeee65a92ce82eabd32d.jpg)

### Part 3

<!-- Source: /api/assets/ea840d74c0e5553bffe28214235c5a1d2418ba5ea156a524ed744b79b96470d0.jpg; PDF page 32; full -->

```text
Test 2
PART 3 Questions 21-30
Questions 21 and 22
Choose TWO letters, A-E.
Which TWO groups of people is the display primarily intended for?
A  students from the English department
B  residents of the local area
C the university's teaching staff
D potential new students
E  students from other departments
Questions 23 and 24
Choose TWO letters, A-E.
What are Cathy and Graham’s TWO reasons for choosing the novelist Charles Dickens?
A His speeches inspired others to try to improve society.
B He used his publications to draw attention to social problems.
C His novels are well-known now.
D He was consulted on a number of social issues.
E His reputation has changed in recent times.
```

[Original question page](assets/ea840d74c0e5553bffe28214235c5a1d2418ba5ea156a524ed744b79b96470d0.jpg)

<!-- Source: /api/assets/6682bfc987f4a0cebcac98e9984eec6c5bad48b44a9e43e866508ed2f6d8d240.jpg; PDF page 33; full -->

```text
Questions 25–30
What topic do Cathy and Graham choose to illustrate with each novel?
Choose SIX answers from the box and write the correct letter, A–H, next to Questions 25–30.
Topics
A poverty
B education
C Dickens’s travels
D entertainment
E crime and the law
F wealth
G medicine
H a woman’s life
Novels by Dickens
25 The Pickwick Papers __________
26 Oliver Twist __________
27 Nicholas Nickleby __________
28 Martin Chuzzlewit __________
29 Bleak House __________
30 Little Dorrit __________
```

[Original question page](assets/6682bfc987f4a0cebcac98e9984eec6c5bad48b44a9e43e866508ed2f6d8d240.jpg)

### Part 4

<!-- Source: /api/assets/7dfbb5cc3ac4089bd5b688de9140750d621c61aed026ef06ef3a3c69cb02bc25.jpg; PDF page 34; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Agricultural programme in Mozambique
How the programme was organised
• It focused on a dry and arid region in Chicualacuala district, near the Limpopo River.
• People depended on the forest to provide charcoal as a source of income.
• (31) __________ was seen as the main priority to ensure the supply of water.
• Most of the work organised by farmers’ associations was done by (32) __________.
• Fenced areas were created to keep animals away from crops.
• The programme provided
– (33) __________ for the fences
– (34) __________ for suitable crops
– water pumps.
• The farmers provided
– labour
– (35) __________ for the fences on their land.
Further developments
• The marketing of produce was sometimes difficult due to lack of (36) __________.
• Training was therefore provided in methods of food (37) __________.
• Farmers made special places where (38) __________ could be kept.
• Local people later suggested keeping (39) __________.
Evaluation and lessons learned
• Agricultural production increased, improving incomes and food security.
• Enough time must be allowed, particularly for the (40) __________ phase of the programme.
```

[Original question page](assets/7dfbb5cc3ac4089bd5b688de9140750d621c61aed026ef06ef3a3c69cb02bc25.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/ba688bb44d431d72160586871ec76e20a5e19bda56ef9b601dfdfd116c1ba59e.jpg; PDF page 35; full -->

```text
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Could urban engineers learn from dance?
A The way we travel around cities has a major impact on whether they are sustainable.
Transportation is estimated to account for 30% of energy consumption in most of the
world’s most developed nations, so lowering the need for energy-using vehicles is essential
for decreasing the environmental impact of mobility. But as more and more people move to
cities, it is important to think about other kinds of sustainable travel too. The ways we travel
affect our physical and mental health, our social lives, our access to work and culture, and
the air we breathe. Engineers are tasked with changing how we travel round cities through
urban design, but the engineering industry still works on the assumptions that led to the
creation of the energy-consuming transport systems we have now: the emphasis placed
solely on efficiency, speed, and quantitative data. We need radical changes, to make it
healthier, more enjoyable, and less environmentally damaging to travel around cities.
B Dance might hold some of the answers. That is not to suggest everyone should dance their
way to work, however healthy and happy it might make us, but rather that the techniques
used by choreographers to experiment with and design movement in dance could provide
engineers with tools to stimulate new ideas in city-making. Richard Sennett, an influential
urbanist and sociologist who has transformed ideas about the way cities are made,
argues that urban design has suffered from a separation between mind and body since the
introduction of the architectural blueprint.
C Whereas medieval builders improvised and adapted construction through their intimate
knowledge of materials and personal experience of the conditions on a site, building designs
are now conceived and stored in media technologies that detach the designer from the
physical and social realities they are creating. While the design practices created by these
new technologies are essential for managing the technical complexity of the modern city,
they have the drawback of simplifying reality in the process.
D To illustrate, Sennett discusses the Peachtree Center in Atlanta, USA, a development typical
of the modernist approach to urban planning prevalent in the 1970s. Peachtree created a grid
of streets and towers intended as a new pedestrian-friendly downtown for Atlanta. According
to Sennett, this failed because its designers had invested too much faith in computer-aided
design to tell them how it would operate. They failed to take into account that purpose-built
street cafés could not operate in the hot sun without the protective awnings common in older
buildings, and would need energy-consuming air conditioning instead, or that its giant car
park would feel so unwelcoming that it would put people off getting out of their cars. What
seems entirely predictable and controllable on screen has unexpected results when translated
into reality.
37
```

[Original question page](assets/ba688bb44d431d72160586871ec76e20a5e19bda56ef9b601dfdfd116c1ba59e.jpg)

<!-- Source: /api/assets/60f2d273502e102ab8587937a73a9ee082846018d9bfad3a8ffceecfde20a7af.jpg; PDF page 36; full -->

```text
Test 2
38
E The same is true in transport engineering, which uses models to predict and shape the
way people move through the city. Again, these models are necessary, but they are built
on specific world views in which certain forms of efficiency and safety are considered
and other experiences of the city ignored. Designs that seem logical in models appear
counter-intuitive in the actual experience of their users. The guard rails that will be familiar
to anyone who has attempted to cross a British road, for example, were an engineering
solution to pedestrian safety based on models that prioritise the smooth flow of traffic. On
wide major roads, they often guide pedestrians to specific crossing points and slow down
their progress across the road by using staggered access points to divide the crossing into
two — one for each carriageway. In doing so they make crossings feel longer, introducing
psychological barriers greatly impacting those that are the least mobile, and encouraging
others to make dangerous crossings to get around the guard rails. These barriers don’t
just make it harder to cross the road: they divide communities and decrease opportunities
for healthy transport. As a result, many are now being removed, causing disruption, cost,
and waste.
F If their designers had had the tools to think with their bodies — like dancers — and imagine
how these barriers would feel, there might have been a better solution. In order to bring
about fundamental changes to the ways we use our cities, engineering will need to develop
a richer understanding of why people move in certain ways, and how this movement affects
them. Choreography may not seem an obvious choice for tackling this problem. Yet it shares
with engineering the aim of designing patterns of movement within limitations of space.
It is an art form developed almost entirely by trying out ideas with the body, and gaining
instant feedback on how the results feel. Choreographers have deep understanding of the
psychological, aesthetic, and physical implications of different ways of moving.
G Observing the choreographer Wayne McGregor, cognitive scientist David Kirsh described
how he ‘thinks with the body’. Kirsh argues that by using the body to simulate outcomes,
McGregor is able to imagine solutions that would not be possible using purely abstract
thought. This kind of physical knowledge is valued in many areas of expertise, but currently
has no place in formal engineering design processes. A suggested method for transport
engineers is to improvise design solutions and get instant feedback about how they
would work from their own experience of them, or model designs at full scale in the way
choreographers experiment with groups of dancers. Above all, perhaps, they might learn to
design for emotional as well as functional effects.
```

[Original question page](assets/60f2d273502e102ab8587937a73a9ee082846018d9bfad3a8ffceecfde20a7af.jpg)

<!-- Source: /api/assets/58fad571975da38e753826ccdcb46c79742e3fe24c992a928c4ba5b72db2140f.jpg; PDF page 37; full -->

```text
Questions 1–6
Reading Passage 1 has seven paragraphs, A–G.
Which paragraph contains the following information?
Write the correct letter, A–G, in boxes 1–6 on your answer sheet.
1 reference to an appealing way of using dance that the writer is not proposing
2 an example of a contrast between past and present approaches to building
3 mention of an objective of both dance and engineering
4 reference to an unforeseen problem arising from ignoring the climate
5 why some measures intended to help people are being reversed
6 reference to how transport has an impact on human lives
Questions 7–13
Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 7–13 on your answer sheet.
Guard rails
Guard rails were introduced on British roads to improve the (7) __________ of pedestrians, while ensuring that the movement of (8) __________ is not disrupted. Pedestrians are led to access points, and encouraged to cross one (9) __________ at a time.
An unintended effect is to create psychological difficulties in crossing the road, particularly for less (10) __________ people. Another result is that some people cross the road in an (11) __________ way. The guard rails separate (12) __________, and make it more difficult to introduce forms of transport that are (13) __________.
```

[Original question page](assets/58fad571975da38e753826ccdcb46c79742e3fe24c992a928c4ba5b72db2140f.jpg)

<!-- Source: /api/assets/d4428ba1eb05e85193b4eeb6838cf416b498053b2d738219aa75db148462463e.jpg; PDF page 38; full -->

```text
Test 2
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
40
Should we try to bring extinct species back to life?
A The passenger pigeon was a legendary species. Flying in vast numbers across
North America, with potentially many millions within a single flock, their migration
was once one of nature’s great spectacles. Sadly, the passenger pigeon’s existence
came to an end on 1 September 1914, when the last living specimen died at
Cincinnati Zoo. Geneticist Ben Novak is lead researcher on an ambitious project
which now aims to bring the bird back to life through a process known as ‘de-
extinction’. The basic premise involves using cloning technology to turn the DNA of
extinct animals into a fertilised embryo, which is carried by the nearest relative still
in existence — in this case, the abundant band-tailed pigeon — before being born as
a living, breathing animal. Passenger pigeons are one of the pioneering species in
this field, but they are far from the only ones on which this cutting-edge technology
is being trialled.
B In Australia, the thylacine, more commonly known as the Tasmanian tiger, is
another extinct creature which genetic scientists are striving to bring back to life.
‘There is no carnivore now in Tasmania that fills the niche which thylacines once
occupied,’ explains Michael Archer of the University of New South Wales. He points
out that in the decades since the thylacine went extinct, there has been a spread in
a ‘dangerously debilitating’ facial tumour syndrome which threatens the existence
of the Tasmanian devils, the island's other notorious resident. Thylacines would
have prevented this spread because they would have killed significant numbers
of Tasmanian devils. ‘If that contagious cancer had popped up previously, it would
have burned out in whatever region it started. The return of thylacines to Tasmania
could help to ensure that devils are never again subjected to risks of this kind.’
C If extinct species can be brought back to life, can humanity begin to correct the
damage it has caused to the natural world over the past few millennia? ‘The idea
of de-extinction is that we can reverse this process, bringing species that no
longer exist back to life,’ says Beth Shapiro of University of California Santa Cruz's
Genomics Institute. ‘I don’t think that we can do this. There is no way to bring
back something that is 100 per cent identical to a species that went extinct a long
time ago.’ A more practical approach for long-extinct species is to take the DNA of
existing species as a template, ready for the insertion of strands of extinct animal
DNA to create something new; a hybrid, based on the living species, but which
looks and/or acts like the animal which died out.
```

[Original question page](assets/d4428ba1eb05e85193b4eeb6838cf416b498053b2d738219aa75db148462463e.jpg)

<!-- Source: /api/assets/35d107a63451086fe04a383132077081c6c215e53604dd8e5f2f1f5fbdbcb720.jpg; PDF page 39; full -->

```text
Reading
D This complicated process and questionable outcome begs the question: what is
the actual point of this technology? ‘For us, the goal has always been replacing
the extinct species with a suitable replacement,’ explains Novak. ‘When it comes
to breeding, band-tailed pigeons scatter and make maybe one or two nests per
hectare, whereas passenger pigeons were very social and would make 10,000
or more nests in one hectare.’ Since the disappearance of this key species,
ecosystems in the eastern US have suffered, as the lack of disturbance caused
by thousands of passenger pigeons wrecking trees and branches means there
has been minimal need for regrowth. This has left forests stagnant and therefore
unwelcoming to the plants and animals which evolved to help regenerate the forest
after a disturbance. According to Novak, a hybridised band-tailed pigeon, with the
added nesting habits of a passenger pigeon, could, in theory, re-establish that
forest disturbance, thereby creating a habitat necessary for a great many other
native species to thrive.
E Another popular candidate for this technology is the woolly mammoth. George
Church, professor at Harvard Medical School and leader of the Woolly Mammoth
Revival Project, has been focusing on cold resistance, the main way in which the
extinct woolly mammoth and its nearest living relative, the Asian elephant, differ.
By pinpointing which genetic traits made it possible for mammoths to survive the
icy climate of the tundra, the project's goal is to return mammoths, or a mammoth-
like species, to the area. ‘My highest priority would be preserving the endangered
Asian elephant,’ says Church, ‘expanding their range to the huge ecosystem of the
tundra. Necessary adaptations would include smaller ears, thicker hair, and extra
insulating fat, all for the purpose of reducing heat loss in the tundra, and all traits
found in the now extinct woolly mammoth.’ This repopulation of the tundra and
boreal forests of Eurasia and North America with large mammals could also be a
useful factor in reducing carbon emissions — elephants punch holes through snow
and knock down trees, which encourages grass growth. This grass growth would
reduce temperatures, and mitigate emissions from melting permafrost.
F While the prospect of bringing extinct animals back to life might capture
imaginations, it is, of course, far easier to try to save an existing species which
is merely threatened with extinction. ‘Many of the technologies that people have
in mind when they think about de-extinction can be used as a form of “genetic
rescue”,’ explains Shapiro. She prefers to focus the debate on how this emerging
technology could be used to fully understand why various species went extinct in
the first place, and therefore how we could use it to make genetic modifications
which could prevent mass extinctions in the future. ‘I would also say there's an
incredible moral hazard to not do anything at all,’ she continues. ‘We know that
what we are doing today is not enough, and we have to be willing to take some
calculated and measured risks.’
41
```

[Original question page](assets/35d107a63451086fe04a383132077081c6c215e53604dd8e5f2f1f5fbdbcb720.jpg)

<!-- Source: /api/assets/b1dddd74cdd59d9d94d18497ef44c242de76440e0a5da3e8f957d82c4c440754.jpg; PDF page 40; full -->

```text
Test 2
Questions 14-17
Reading Passage 2 has six paragraphs, A-F.
Which paragraph contains the following information?
Write the correct letter, A-F, in boxes 14-17 on your answer sheet.
NB You may use any letter more than once.
14 a reference to how further disappearance of multiple species could be avoided
15 explanation of a way of reproducing an extinct animal using the DNA of only that
species
16 reference to a habitat which has suffered following the extinction of a species
17 mention of the exact point at which a particular species became extinct
Questions 18-22
Complete the summary below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 18-22 on your answer sheet.
The woolly mammoth revival project
Professor George Church and his team are trying to identify the (18) __________ which enabled mammoths to live in the tundra. The findings could help preserve the mammoth’s close relative, the endangered Asian elephant.
According to Church, introducing Asian elephants to the tundra would involve certain physical adaptations to minimise (19) __________. To survive in the tundra, the species would need to have the mammoth-like features of thicker hair, (20) __________ of a reduced size and more (21) __________.
Repopulating the tundra with mammoths or Asian elephant/mammoth hybrids would also have an impact on the environment, which could help to reduce temperatures and decrease (22) __________.
```

[Original question page](assets/b1dddd74cdd59d9d94d18497ef44c242de76440e0a5da3e8f957d82c4c440754.jpg)

<!-- Source: /api/assets/2ccfb24b12c3e584ef6f97e2885bbd5600ec067267c5d7c5ed7b4bc6c71b35de.jpg; PDF page 41; full -->

```text
Reading
Questions 23-26
Look at the following statements (Questions 23-26) and the list of people below.
Match each statement with the correct person, A, B or C.
Write the correct letter, A, B or C, in boxes 23-26 on your answer sheet.
NB You may use any letter more than once.
23 Reintroducing an extinct species to its original habitat could improve the health of a
particular species living there.
24 It is important to concentrate on the causes of an animal’s extinction.
25 A species brought back from extinction could have an important beneficial impact
on the vegetation of its habitat.
26 Our current efforts at preserving biodiversity are insufficient.
List of People
A Ben Novak
B Michael Archer
C Beth Shapiro
>/@ p. 122 43
```

[Original question page](assets/2ccfb24b12c3e584ef6f97e2885bbd5600ec067267c5d7c5ed7b4bc6c71b35de.jpg)

<!-- Source: /api/assets/93e380cc02c2622afaef009b4eaee83d290ed1ad462b1efb10a9bca3c7e8a31b.jpg; PDF page 42; full -->

```text
Test 2
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Having a laugh
The findings of psychological scientists reveal the importance of humour
Humans start developing a sense of humour as early as six weeks old, when babies begin to laugh
and smile in response to stimuli. Laughter is universal across all human cultures and even exists
in some form in rats, chimps, and bonobos. Like other human emotions and expressions, laughter
and humour provide psychological scientists with rich resources for studying human psychology,
ranging from the development of language to the neuroscience of social perception.
Theories focusing on the evolution of laughter point to it as an important adaptation for social
communication. Take, for example, the recorded laughter in TV comedy shows. Back in 1950,
US sound engineer Charley Douglass hated dealing with the unpredictable laughter of live
audiences, so started recording his own ‘laugh tracks’. These were intended to help people at
home feel like they were in a social situation, such as a crowded theatre. Douglass even recorded
various types of laughter, as well as mixtures of laughter from men, women, and children. In
doing so, he picked up on a quality of laughter that is now interesting researchers: a simple ‘haha’
communicates a remarkable amount of socially relevant information.
In one study conducted in 2016, samples of laughter from pairs of English-speaking students
were recorded at the University of California, Santa Cruz. A team made up of more than 30
psychological scientists, anthropologists, and biologists then played these recordings to listeners
from 24 diverse societies, from indigenous tribes in New Guinea to city-dwellers in India and
Europe. Participants were asked whether they thought the people laughing were friends or
strangers. On average, the results were remarkably consistent: worldwide, people’s guesses were
correct approximately 60% of the time.
Researchers have also found that different types of laughter serve as codes to complex human
social hierarchies. A team led by Christopher Oveis from the University of California, San
Diego, found that high-status individuals had different laughs from low-status individuals, and
that strangers’ judgements of an individual’s social status were influenced by the dominant or
submissive quality of their laughter. In their study, 48 male college students were randomly
assigned to groups of four, with each group composed of two low-status members, who had just
joined their college fraternity group, and two high-status members, older students who had been
active in the fraternity for at least two years. Laughter was recorded as each student took a turn
at being teased by the others, involving the use of mildly insulting nicknames. Analysis revealed
that, as expected, high-status individuals produced more dominant laughs and fewer submissive
laughs relative to the low-status individuals. Meanwhile, low-status individuals were more likely
to change their laughter based on their position of power; that is, the newcomers produced more
44
```

[Original question page](assets/93e380cc02c2622afaef009b4eaee83d290ed1ad462b1efb10a9bca3c7e8a31b.jpg)

<!-- Source: /api/assets/c2638785b33d897b54f9dffb151c00448f0fab597cbcf96cf099b082d6129d79.jpg; PDF page 43; full -->

```text
Reading
dominant laughs when they were in the ‘powerful’ role of teasers. Dominant laughter was higher
in pitch, louder, and more variable in tone than submissive laughter.
A random group of volunteers then listened to an equal number of dominant and submissive
laughs from both the high- and low-status individuals, and were asked to estimate the social status
of the laugher. In line with predictions, laughers producing dominant laughs were perceived to be
significantly higher in status than laughers producing submissive laughs. ‘This was particularly
true for low-status individuals, who were rated as significantly higher in status when displaying a
dominant versus submissive laugh,’ Oveis and colleagues note. ‘Thus, by strategically displaying
more dominant laughter when the context allows, low-status individuals may achieve higher
status in the eyes of others.’ However, high-status individuals were rated as high-status whether
they produced their natural dominant laugh or tried to do a submissive one.
Another study, conducted by David Cheng and Lu Wang of Australian National University,
was based on the hypothesis that humour might provide a respite from tedious situations in the
workplace. This ‘mental break’ might facilitate the replenishment of mental resources. To test this
theory, the researchers recruited 74 business students, ostensibly for an experiment on perception.
First, the students performed a tedious task in which they had to cross out every instance of the
letter ‘e’ over two pages of text. The students then were randomly assigned to watch a video
clip eliciting either humour, contentment, or neutral feelings. Some watched a clip of the BBC
comedy Mr. Bean, others a relaxing scene with dolphins swimming in the ocean, and others a
factual video about the management profession.
The students then completed a task requiring persistence in which they were asked to guess
the potential performance of employees based on provided profiles, and were told that making
10 correct assessments in a row would lead to a win. However, the software was programmed
such that it was nearly impossible to achieve 10 consecutive correct answers. Participants were
allowed to quit the task at any point. Students who had watched the Mr. Bean video ended up
spending significantly more time working on the task, making twice as many predictions as the
other two groups.
Cheng and Wang then replicated these results in a second study, during which they had
participants complete long multiplication questions by hand. Again, participants who watched the
humorous video spent significantly more time working on this tedious task and completed more
questions correctly than did the students in either of the other groups.
“Although humour has been found to help relieve stress and facilitate social relationships, the
traditional view of task performance implies that individuals should avoid things such as humour
that may distract them from the accomplishment of task goals,’ Cheng and Wang conclude. ‘We
suggest that humour is not only enjoyable but more importantly, energising.’
45
```

[Original question page](assets/c2638785b33d897b54f9dffb151c00448f0fab597cbcf96cf099b082d6129d79.jpg)

<!-- Source: /api/assets/f575f1f3586b9f0d8db39f682bfa1444134bf764807abb6330faaae3acb95d26.jpg; PDF page 44; full -->

```text
Test 2
Questions 27-31
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-31 on your answer sheet.





46
27 When referring to laughter in the first paragraph, the writer emphasises
A its impact on language.
B its function in human culture.
C its value to scientific research.
D its universality in animal societies.
28 What does the writer suggest about Charley Douglass?
A He understood the importance of enjoying humour in a group setting.
B He believed that TV viewers at home needed to be told when to laugh.
C He wanted his shows to appeal to audiences across the social spectrum.
D He preferred shows where audiences were present in the recording studio.
29 What makes the Santa Cruz study particularly significant?
A the various different types of laughter that were studied
B the similar results produced by a wide range of cultures
C the number of different academic disciplines involved
D the many kinds of people whose laughter was recorded
30 Which of the following happened in the San Diego study?
A Some participants became very upset.
B Participants exchanged roles.
C Participants who had not met before became friends.
D Some participants were unable to laugh.
31 In the fifth paragraph, what did the results of the San Diego study suggest?
A It is clear whether a dominant laugh is produced by a high- or low-status
person.
B Low-status individuals in a position of power will still produce submissive
laughs.
C The submissive laughs of low- and high-status individuals are surprisingly
similar.
D High-status individuals can always be identified by their way of laughing.
```

[Original question page](assets/f575f1f3586b9f0d8db39f682bfa1444134bf764807abb6330faaae3acb95d26.jpg)

<!-- Source: /api/assets/338302c33444f2e800855a7c5ff52ef7bd15f282337327c18883a7bbeb6f82b5.jpg; PDF page 45; full -->

```text
Reading
Questions 32-36
Complete the summary using the list of words, A-H, below.
Write the correct letter, A-H, in boxes 32-36 on your answer sheet.
The benefits of humour
In one study at Australian National University, randomly chosen groups of participants were shown one of three videos, each designed to generate a different kind of (32) __________. When all participants were then given a deliberately frustrating task to do, it was found that those who had watched the (33) __________ video persisted with the task for longer and tried harder to accomplish the task than either of the other two groups.
A second study in which participants were asked to perform a particularly (34) __________ task produced similar results. According to researchers David Cheng and Lu Wang, these findings suggest that humour not only reduces (35) __________ and helps build social connections but it may also have a (36) __________ effect on the body and mind.
A laughter
B relaxing
C boring
D anxiety
E stimulating
F emotion
G enjoyment
H amusing
```

[Original question page](assets/338302c33444f2e800855a7c5ff52ef7bd15f282337327c18883a7bbeb6f82b5.jpg)

<!-- Source: /api/assets/6c3c7222f671fd922ea0e1bda9dec574821f04d278dc7d68245e521359f04ce6.jpg; PDF page 46; full -->

```text
Test 2
Questions 37-40
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 37-40 on your answer sheet, write




48
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
37 Participants in the Santa Cruz study were more accurate at identifying the laughs of
friends than those of strangers.
38 The researchers in the San Diego study were correct in their predictions regarding
the behaviour of the high-status individuals.
39 The participants in the Australian National University study were given a fixed
amount of time to complete the task focusing on employee profiles.
40 Cheng and Wang’s conclusions were in line with established notions regarding task
performance.
>| p. 122
```

[Original question page](assets/6c3c7222f671fd922ea0e1bda9dec574821f04d278dc7d68245e521359f04ce6.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/576e1f8ee97c024e26ba5f6c876a6023a307c06d94030228aa42f0403a05d05f.jpg; PDF page 47; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below shows the number of tourists visiting a particular Caribbean island between 2010 and 2017.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/576e1f8ee97c024e26ba5f6c876a6023a307c06d94030228aa42f0403a05d05f.jpg)

![Original figure](assets/576e1f8ee97c024e26ba5f6c876a6023a307c06d94030228aa42f0403a05d05f.jpg)

### Task 2

<!-- Source: /api/assets/be41595ddf05948f4632a4b6819b3404ea5747222376bfac85f0136ba7e5f040.jpg; PDF page 48; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In the future, nobody will buy printed newspapers or books because they will be able to read everything they want online without paying.

To what extent do you agree or disagree with this statement?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/be41595ddf05948f4632a4b6819b3404ea5747222376bfac85f0136ba7e5f040.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/a5ee386c28605be8b2878b4dd10a91c3c5042a90e48e30f71234e010ce3a5132.jpg; PDF page 49; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Languages
e How many languages can you speak? [Why/Why not?]
e How useful will English be to you in your future? [Why/Why not?]
e What do you remember about learning languages at school? [Why/Why not?]
e What do you think would be the hardest language for you to learn? [Why?]
PART 2
Describe a website that you bought something from.
You should say:
what the website is
what you bought from this website
how satisfied you were with what you bought
and explain what you liked or disliked about using this website.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping online
Example questions:
What kinds of things do people in your country often buy from online shops?
Why do you think online shopping has become so popular nowadays?
What are some possible disadvantages of buying things from online shops?
The culture of consumerism
Example questions:
Why do many people today keep buying things which they do not need?
Do you believe the benefits of a consumer society outweigh the disadvantages?
How possible is it to avoid the culture of consumerism?
```

[Original question page](assets/a5ee386c28605be8b2878b4dd10a91c3c5042a90e48e30f71234e010ce3a5132.jpg)

### Part 2

<!-- Source: /api/assets/a5ee386c28605be8b2878b4dd10a91c3c5042a90e48e30f71234e010ce3a5132.jpg; PDF page 49; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Languages
e How many languages can you speak? [Why/Why not?]
e How useful will English be to you in your future? [Why/Why not?]
e What do you remember about learning languages at school? [Why/Why not?]
e What do you think would be the hardest language for you to learn? [Why?]
PART 2
Describe a website that you bought something from.
You should say:
what the website is
what you bought from this website
how satisfied you were with what you bought
and explain what you liked or disliked about using this website.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping online
Example questions:
What kinds of things do people in your country often buy from online shops?
Why do you think online shopping has become so popular nowadays?
What are some possible disadvantages of buying things from online shops?
The culture of consumerism
Example questions:
Why do many people today keep buying things which they do not need?
Do you believe the benefits of a consumer society outweigh the disadvantages?
How possible is it to avoid the culture of consumerism?
```

[Original question page](assets/a5ee386c28605be8b2878b4dd10a91c3c5042a90e48e30f71234e010ce3a5132.jpg)

### Part 3

<!-- Source: /api/assets/a5ee386c28605be8b2878b4dd10a91c3c5042a90e48e30f71234e010ce3a5132.jpg; PDF page 49; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Languages
e How many languages can you speak? [Why/Why not?]
e How useful will English be to you in your future? [Why/Why not?]
e What do you remember about learning languages at school? [Why/Why not?]
e What do you think would be the hardest language for you to learn? [Why?]
PART 2
Describe a website that you bought something from.
You should say:
what the website is
what you bought from this website
how satisfied you were with what you bought
and explain what you liked or disliked about using this website.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping online
Example questions:
What kinds of things do people in your country often buy from online shops?
Why do you think online shopping has become so popular nowadays?
What are some possible disadvantages of buying things from online shops?
The culture of consumerism
Example questions:
Why do many people today keep buying things which they do not need?
Do you believe the benefits of a consumer society outweigh the disadvantages?
How possible is it to avoid the culture of consumerism?
```

[Original question page](assets/a5ee386c28605be8b2878b4dd10a91c3c5042a90e48e30f71234e010ce3a5132.jpg)
