# 剑雅 17 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 118

TEST 1 LISTENING
1 litter
2 dogs
3 insects
4 butterflies
5 wall
6 island
7 boots
8 beginners
9 spoons
10 35 / thirty five
11 A
12 C
13 B
14 B
15 A
16 D
17 B
18 C
19 D
20 E
21 A
22 B
23 B
24 A
25 C
26 C
27 A
28 E
29 F
30 C
31 puzzle
32 logic
33 confusion
34 meditation
35 stone
36 coins
37 tree
38 breathing
39 paper
40 anxiety
15&16 IN EITHER ORDER: A,D
17&18 IN EITHER ORDER: B,C
19&20 IN EITHER ORDER: D,E
If you score: 1–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. litter

2. dogs

3. insects

4. butterflies

5. wall

6. island

7. boots

8. beginners

9. spoons

10. 35 / thirty five

### Part 2 · source page 118

TEST 1 LISTENING
1 litter
2 dogs
3 insects
4 butterflies
5 wall
6 island
7 boots
8 beginners
9 spoons
10 35 / thirty five
11 A
12 C
13 B
14 B
15 A
16 D
17 B
18 C
19 D
20 E
21 A
22 B
23 B
24 A
25 C
26 C
27 A
28 E
29 F
30 C
31 puzzle
32 logic
33 confusion
34 meditation
35 stone
36 coins
37 tree
38 breathing
39 paper
40 anxiety
15&16 IN EITHER ORDER: A,D
17&18 IN EITHER ORDER: B,C
19&20 IN EITHER ORDER: D,E
If you score: 1–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A

12. C

13. B

14. B

15. A / D

16. A / D

17. B / C

18. B / C

19. D / E

20. D / E

### Part 3 · source page 118

TEST 1 LISTENING
1 litter
2 dogs
3 insects
4 butterflies
5 wall
6 island
7 boots
8 beginners
9 spoons
10 35 / thirty five
11 A
12 C
13 B
14 B
15 A
16 D
17 B
18 C
19 D
20 E
21 A
22 B
23 B
24 A
25 C
26 C
27 A
28 E
29 F
30 C
31 puzzle
32 logic
33 confusion
34 meditation
35 stone
36 coins
37 tree
38 breathing
39 paper
40 anxiety
15&16 IN EITHER ORDER: A,D
17&18 IN EITHER ORDER: B,C
19&20 IN EITHER ORDER: D,E
If you score: 1–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. A

22. B

23. B

24. A

25. C

26. C

27. A

28. E

29. F

30. C

### Part 4 · source page 118

TEST 1 LISTENING
1 litter
2 dogs
3 insects
4 butterflies
5 wall
6 island
7 boots
8 beginners
9 spoons
10 35 / thirty five
11 A
12 C
13 B
14 B
15 A
16 D
17 B
18 C
19 D
20 E
21 A
22 B
23 B
24 A
25 C
26 C
27 A
28 E
29 F
30 C
31 puzzle
32 logic
33 confusion
34 meditation
35 stone
36 coins
37 tree
38 breathing
39 paper
40 anxiety
15&16 IN EITHER ORDER: A,D
17&18 IN EITHER ORDER: B,C
19&20 IN EITHER ORDER: D,E
If you score: 1–15 unlikely;16–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. puzzle

32. logic

33. confusion

34. meditation

35. stone

36. coins

37. tree

38. breathing

39. paper

40. anxiety

## A 类阅读

### Academic Reading · source page 119

TEST 1 READING
1 population
2 suburbs
3 businessmen
4 funding
5 press
6 soil
7 FALSE
8 NOT GIVEN
9 TRUE
10 TRUE
11 FALSE
12 FALSE
13 NOT GIVEN
14 A
15 F
16 E
17 D
18 fortress
19 bullfights
20 opera
21 salt
22 shops
23 C
24 D
25 B
26 E
27 H
28 J
29 F
30 B
31 D
32 NOT GIVEN
33 NO
34 NO
35 YES
36 B
37 C
38 A
39 B
40 D
23&24 IN EITHER ORDER: C,D
25&26 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. population

2. suburbs

3. businessmen

4. funding

5. press

6. soil

7. FALSE

8. NOT GIVEN

9. TRUE

10. TRUE

11. FALSE

12. FALSE

13. NOT GIVEN

14. A

15. F

16. E

17. D

18. fortress

19. bullfights

20. opera

21. salt

22. shops

23. C / D

24. C / D

25. B / E

26. B / E

27. H

28. J

29. F

30. B

31. D

32. NOT GIVEN

33. NO

34. NO

35. YES

36. B

37. C

38. A

39. B

40. D

## A 类写作

### Writing material: c17-t1-w-1

North up. Present factories around central roundabout and eastward road, main road south, river north, farmland beyond river; town west outside site. Plan: all factories replaced by housing and community facilities. New northern road crosses river by bridge to housing on north bank; remaining farmland east. New northwest branch with housing. Existing eastern road extended to school, playground north of eastern road, shops southwest of central roundabout, medical centre southeast. Second smaller roundabout added on southern main road at site entrance. Future residential development, not completed; do not confuse factory hatch with proposed housing pattern.



### Writing material: c17-t1-w-2

Weigh benefits and drawbacks of taking risks in professional and personal life and state comparative judgement. Not a request to endorse reckless behaviour or provide individual investment advice.



## 口语
