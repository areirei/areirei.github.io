# 剑雅 17 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/5a6a1bf9a12aaa3a9e5c1ab26c05b4ef7fa6bb0fef8c019481bb1c58df4a78b2.jpg; PDF page 9; full -->

```text
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Buckworth Conservation Group
Regular activities
Beach
• making sure the beach does not have (1) __________ on it
• no (2) __________
Nature reserve
• maintaining paths
• nesting boxes for birds installed
• next task is taking action to attract (3) __________ to the place
• identifying types of (4) __________
• building a new (5) __________
Forthcoming events
Saturday
• meet at Dunsmore Beach car park
• walk across the sands and reach the (6) __________
• take a picnic
• wear appropriate (7) __________
Woodwork session
• suitable for (8) __________ to participate in
• making (9) __________ out of wood
• 17th, from 10 a.m. to 3 p.m.
• cost of session (no camping): (10) £ __________
```

[Original question page](assets/5a6a1bf9a12aaa3a9e5c1ab26c05b4ef7fa6bb0fef8c019481bb1c58df4a78b2.jpg)

### Part 2

<!-- Source: /api/assets/cd5f42646e88b42ee681777919ab557e1e8a87d5d21286cdbd9223d41df1fa17.jpg; PDF page 10; full -->

```text
Listening
PART 2 Questions 11-20
Questions 11-14
Choose the correct letter, A, B or C. Listening test audio
Boat trip round Tasmania
11. What is the maximum number of people who can stand on each side of the boat?
A 9
B 15
C 18
12 What colour are the tour boats?
A dark red
B jet black
C light green
13 Which lunchbox is suitable for someone who doesn’t eat meat or fish?
A Lunchbox 1
B Lunchbox 2
C Lunchbox 3
14 What should people do with their litter?
A take it home
B hand it to a member of staff
C put it in the bins provided on the boat
11
```

[Original question page](assets/cd5f42646e88b42ee681777919ab557e1e8a87d5d21286cdbd9223d41df1fa17.jpg)

<!-- Source: /api/assets/7e50e23929f590f1a5d8abd60e5fdff56a222069f1c294b274524c764b73dbf7.jpg; PDF page 11; full -->

```text
Questions 15 and 16
Choose TWO letters, A–E.
Which TWO features of the lighthouse does Lou mention?
A why it was built
B who built it
C how long it took to build
D who staffed it
E what it was built with
Questions 17 and 18
Choose TWO letters, A–E.
Which TWO types of creature might come close to the boat?
A sea eagles
B fur seals
C dolphins
D whales
E penguins
Questions 19 and 20
Choose TWO letters, A–E.
Which TWO points does Lou make about the caves?
A Only large tourist boats can visit them.
B The entrances to them are often blocked.
C It is too dangerous for individuals to go near them.
D Someone will explain what is inside them.
E They cannot be reached on foot.
```

[Original question page](assets/7e50e23929f590f1a5d8abd60e5fdff56a222069f1c294b274524c764b73dbf7.jpg)

### Part 3

<!-- Source: /api/assets/13bfe04153816efcb729015063e91066a219fe61bacc72590f4168550c81c59b.jpg; PDF page 12; full -->

```text
PART 3 Questions 21-30
Questions 21-26
Choose the correct letter, A, B or C.






Listening
Listening test audio
Work experience for veterinary science students
21 What problem did both Diana and Tim have when arranging their work experience?
A making initial contact with suitable farms
B organising transport to and from the farm
C finding a placement for the required length of time
22 Tim was pleased to be able to help
A a lamb that had a broken leg.
B a sheep that was having difficulty giving birth.
C a newly born lamb that was having trouble feeding.
23 Diana says the sheep on her farm
A were of various different varieties.
B were mainly reared for their meat.
C had better quality wool than sheep on the hills.
24 What did the students learn about adding supplements to chicken feed?
A These should only be given if specially needed.
B It is worth paying extra for the most effective ones.
C The amount given at one time should be limited.
25 What happened when Diana was working with dairy cows?
A She identified some cows incorrectly.
B She accidentally threw some milk away.
C She made a mistake when storing milk.
26 What did both farmers mention about vets and farming?
A Vets are failing to cope with some aspects of animal health.
B There needs to be a fundamental change in the training of vets.
C Some jobs could be done by the farmer rather than by a vet.
13
```

[Original question page](assets/13bfe04153816efcb729015063e91066a219fe61bacc72590f4168550c81c59b.jpg)

<!-- Source: /api/assets/b379e4769f31e0d848c987c6d15325bb4feac4692d59d6c82bd543b54d6e3170.jpg; PDF page 13; full -->

```text
Questions 27–30
What opinion do the students give about each of the following modules on their veterinary science course?
Choose FOUR answers from the box and write the correct letter, A–F, next to questions 27–30.
Opinions
A Tim found this easier than expected.
B Tim thought this was not very clearly organised.
C Diana may do some further study on this.
D They both found the reading required for this was difficult.
E Tim was shocked at something he learned on this module.
F They were both surprised how little is known about some aspects of this.
Modules on Veterinary Science course
27 Medical terminology __________
28 Diet and nutrition __________
29 Animal disease __________
30 Wildlife medication __________
```

[Original question page](assets/b379e4769f31e0d848c987c6d15325bb4feac4692d59d6c82bd543b54d6e3170.jpg)

### Part 4

<!-- Source: /api/assets/c67ee166f454f60b37854c5558e5b54c8d74f60174f2bc1e0ca002555ef997af.jpg; PDF page 14; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Labyrinths
Definition
• a winding spiral path leading to a central area
Labyrinths compared with mazes
• Mazes are a type of (31) __________.
– (32) __________ is needed to navigate through a maze
– the word ‘maze’ is derived from a word meaning a feeling of (33) __________
• Labyrinths represent a journey through life
– they have frequently been used in (34) __________ and prayer
Early examples of the labyrinth spiral
• Ancient carvings on (35) __________ have been found across many cultures
• The Pima, a Native American tribe, wove the symbol on baskets
• Ancient Greeks used the symbol on (36) __________
Walking labyrinths
• The largest surviving example of a turf labyrinth once had a big (37) __________ at its centre
Labyrinths nowadays
• Believed to have a beneficial impact on mental and physical health, e.g., walking a maze can reduce a person’s (38) __________ rate
• Used in medical and health and fitness settings and also prisons
• Popular with patients, visitors and staff in hospitals
– patients who can’t walk can use ‘finger labyrinths’ made from (39) __________
– research has shown that Alzheimer’s sufferers experience less (40) __________
```

[Original question page](assets/c67ee166f454f60b37854c5558e5b54c8d74f60174f2bc1e0ca002555ef997af.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/d08ba829771ec0f33d540d7c98e77d51d3bcb797fd4a069187cc0cbbd6c5953b.jpg; PDF page 15; full -->

```text
Test 1
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The development of the London underground railway
In the first half of the 1800s, London’s population grew at an astonishing rate, and the central
area became increasingly congested. In addition, the expansion of the overground railway
network resulted in more and more passengers arriving in the capital. However, in 1846, a Royal
Commission decided that the railways should not be allowed to enter the City, the capital’s
historic and business centre. The result was that the overground railway stations formed a ring
around the City. The area within consisted of poorly built, overcrowded slums and the streets were
full of horse-drawn traffic. Crossing the City became a nightmare. It could take an hour and a half
to travel 8 km by horse-drawn carriage or bus. Numerous schemes were proposed to resolve these
problems, but few succeeded.
Amongst the most vocal advocates for a solution to London’s traffic problems was Charles
Pearson, who worked as a solicitor for the City of London. He saw both social and economic
advantages in building an underground railway that would link the overground railway stations
together and clear London slums at the same time. His idea was to relocate the poor workers who
lived in the inner-city slums to newly constructed suburbs, and to provide cheap rail travel for
them to get to work. Pearson’s ideas gained support amongst some businessmen and in 1851 he
submitted a plan to Parliament. It was rejected, but coincided with a proposal from another group
for an underground connecting line, which Parliament passed.
The two groups merged and established the Metropolitan Railway Company in August 1854. The
company’s plan was to construct an underground railway line from the Great Western Railway’s
(GWR) station at Paddington to the edge of the City at Farringdon Street — a distance of almost
5 km. The organisation had difficulty in raising the funding for such a radical and expensive
scheme, not least because of the critical articles printed by the press. Objectors argued that the
tunnels would collapse under the weight of traffic overhead, buildings would be shaken and
passengers would be poisoned by the emissions from the train engines. However, Pearson and his
partners persisted.
The GWR, aware that the new line would finally enable them to run trains into the heart of
the City, invested almost £250,000 in the scheme. Eventually, over a five-year period, £1m
was raised. The chosen route ran beneath existing main roads to minimise the expense of
16
```

[Original question page](assets/d08ba829771ec0f33d540d7c98e77d51d3bcb797fd4a069187cc0cbbd6c5953b.jpg)

<!-- Source: /api/assets/682bb2f1e6052f399b2dc95bb5b8c16d41987d808528ff9d4f296933980a3201.jpg; PDF page 16; full -->

```text
Reading
demolishing buildings. Originally scheduled to be completed in 21 months, the construction of
the underground line took three years. It was built just below street level using a technique known
as ‘cut and cover’. A trench about ten metres wide and six metres deep was dug, and the sides
temporarily held up with timber beams. Brick walls were then constructed, and finally a brick
arch was added to create a tunnel. A two-metre-deep layer of soil was laid on top of the tunnel
and the road above rebuilt.
The Metropolitan line, which opened on 10 January 1863, was the world’s first underground
railway. On its first day, almost 40,000 passengers were carried between Paddington and
Farringdon, the journey taking about 18 minutes. By the end of the Metropolitan’s first year of
operation, 9.5 million journeys had been made.
Even as the Metropolitan began operation, the first extensions to the line were being authorised;
these were built over the next five years, reaching Moorgate in the east of London and
Hammersmith in the west. The original plan was to pull the trains with steam locomotives, using
firebricks in the boilers to provide steam, but these engines were never introduced. Instead, the
line used specially designed locomotives that were fitted with water tanks in which steam could
be condensed. However, smoke and fumes remained a problem, even though ventilation shafts
were added to the tunnels.
Despite the extension of the underground railway, by the 1880s, congestion on London’s streets
had become worse. The problem was partly that the existing underground lines formed a circuit
around the centre of London and extended to the suburbs, but did not cross the capital’s centre.
The ‘cut and cover’ method of construction was not an option in this part of the capital. The only
alternative was to tunnel deep underground.
Although the technology to create these tunnels existed, steam locomotives could not be used in
such a confined space. It wasn’t until the development of a reliable electric motor, and a means of
transferring power from the generator to a moving train, that the world’s first deep-level electric
railway, the City & South London, became possible. The line opened in 1890, and ran from the
City to Stockwell, south of the River Thames. The trains were made up of three carriages and
driven by electric engines. The carriages were narrow and had tiny windows just below the roof
because it was thought that passengers would not want to look out at the tunnel walls. The line
was not without its problems, mainly caused by an unreliable power supply. Although the City &
South London Railway was a great technical achievement, it did not make a profit. Then, in 1900,
the Central London Railway, known as the ‘Tuppenny Tube’, began operation using new electric
locomotives. It was very popular and soon afterwards new railways and extensions were added to
the growing tube network. By 1907, the heart of today’s Underground system was in place.
17
```

[Original question page](assets/682bb2f1e6052f399b2dc95bb5b8c16d41987d808528ff9d4f296933980a3201.jpg)

<!-- Source: /api/assets/03a2c16cc2f4486a234b208661f82bfad26d700c964a7ffe36e81c83239bc1b7.jpg; PDF page 17; full -->

```text
Questions 1–6
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–6 on your answer sheet.
The London underground railway
The problem
• The (1) __________ of London increased rapidly between 1800 and 1850
• The streets were full of horse-drawn vehicles
The proposed solution
• Charles Pearson, a solicitor, suggested building an underground railway
• Building the railway would make it possible to move people to better housing in the (2) __________
• A number of (3) __________ agreed with Pearson’s idea
• The company initially had problems getting the (4) __________ needed for the project
• Negative articles about the project appeared in the (5) __________
The construction
• The chosen route did not require many buildings to be pulled down
• The ‘cut and cover’ method was used to construct the tunnels
• With the completion of the brick arch, the tunnel was covered with (6) __________
```

[Original question page](assets/03a2c16cc2f4486a234b208661f82bfad26d700c964a7ffe36e81c83239bc1b7.jpg)

<!-- Source: /api/assets/70cf213f1501b01033c8b635a7b0b0909db8c19956d987601df603eedac79d0d.jpg; PDF page 18; full -->

```text
Reading
Questions 7-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 7-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
7 Other countries had built underground railways before the Metropolitan line
opened.
8 More people than predicted travelled on the Metropolitan line on the first
day.
9 The use of ventilation shafts failed to prevent pollution in the tunnels.
10 A different approach from the ‘cut and cover’ technique was required in London’s
central area.
11 The windows on City & South London trains were at eye level.
12 The City & South London Railway was a financial success.
13 Trains on the ‘Tuppenny Tube’ nearly always ran on time.
>|@ p.120) 19
```

[Original question page](assets/70cf213f1501b01033c8b635a7b0b0909db8c19956d987601df603eedac79d0d.jpg)

<!-- Source: /api/assets/bcf323c49ac4a075fb4d2aa6695883075feae16b0f90e4f16da2fc91f9f9a863.jpg; PDF page 19; full -->

```text
Test 1
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Stadiums: past, present and future
A Stadiums are among the oldest forms of urban architecture: vast stadiums where the public
could watch sporting events were at the centre of western city life as far back as the ancient
Greek and Roman Empires, well before the construction of the great medieval cathedrals and
the grand 19th- and 20th-century railway stations which dominated urban skylines in later eras.
Today, however, stadiums are regarded with growing scepticism. Construction costs can soar
above £1 billion, and stadiums finished for major events such as the Olympic Games or the
FIFA World Cup have notably fallen into disuse and disrepair.
But this need not be the case. History shows that stadiums can drive urban development and
adapt to the culture of every age. Even today, architects and planners are finding new ways
to adapt the mono-functional sports arenas which became emblematic of modernisation
during the 20th century.
B The amphitheatre* of Arles in southwest France, with a capacity of 25,000 spectators,
is perhaps the best example of just how versatile stadiums can be. Built by the Romans in
90 AD, it became a fortress with four towers after the fifth century, and was then
transformed into a village containing more than 200 houses. With the growing interest in
conservation during the 19th century, it was converted back into an arena for the staging of
bullfights, thereby returning the structure to its original use as a venue for public spectacles.
Another example is the imposing arena of Verona in northern Italy, with space for 30,000
spectators, which was built 60 years before the Arles amphitheatre and 40 years before
Rome’s famous Colosseum. It has endured the centuries and is currently considered one of
the world’s prime sites for opera, thanks to its outstanding acoustics.
C The area in the centre of the Italian town of Lucca, known as the Piazza dell’ Anfiteatro,
is yet another impressive example of an amphitheatre becoming absorbed into the fabric
of the city. The site evolved in a similar way to Arles and was progressively filled with
buildings from the Middle Ages until the 19th century, variously used as houses, a salt depot
and a prison. But rather than reverting to an arena, it became a market square, designed
by Romanticist architect Lorenzo Nottolini. Today, the ruins of the amphitheatre remain
embedded in the various shops and residences surrounding the public square.
D There are many similarities between modern stadiums and the ancient amphitheatres
intended for games. But some of the flexibility was lost at the beginning of the 20th century,
as stadiums were developed using new products such as steel and reinforced concrete, and
made use of bright lights for night-time matches.
* amphitheatre: (especially in Greek and Roman architecture) an open circular or oval building with a central space surrounded by tiers of
seats for spectators, for the presentation of dramatic or sporting events
20
```

[Original question page](assets/bcf323c49ac4a075fb4d2aa6695883075feae16b0f90e4f16da2fc91f9f9a863.jpg)

<!-- Source: /api/assets/cea8d42dcfe0149cf83308515bd1cafc1b6f2b3b7cb0586d6418dd37a9790222.jpg; PDF page 20; full -->

```text
Reading
Many such stadiums are situated in suburban areas, designed for sporting use only and
surrounded by parking lots. These factors mean that they may not be as accessible to the
general public, require more energy to run and contribute to urban heat.
E But many of today’s most innovative architects see scope for the stadium to help improve the
city. Among the current strategies, two seem to be having particular success: the stadium as
an urban hub, and as a power plant.
There’s a growing trend for stadiums to be equipped with public spaces and services that
serve a function beyond sport, such as hotels, retail outlets, conference centres, restaurants
and bars, children’s playgrounds and green space. Creating mixed-use developments such as
this reinforces compactness and multi-functionality, making more efficient use of land and
helping to regenerate urban spaces.
This opens the space up to families and a wider cross-section of society, instead of catering
only to sportspeople and supporters. There have been many examples of this in the UK: the
mixed-use facilities at Wembley and Old Trafford have become a blueprint for many other
stadiums in the world.
F The phenomenon of stadiums as power stations has arisen from the idea that energy
problems can be overcome by integrating interconnected buildings by means of a smart grid,
which is an electricity supply network that uses digital communications technology to detect
and react to local changes in usage, without significant energy losses. Stadiums are ideal
for these purposes, because their canopies have a large surface area for fitting photovoltaic
panels and rise high enough (more than 40 metres) to make use of micro wind turbines.
Freiburg Mage Solar Stadium in Germany is the first of a new wave of stadiums as power
plants, which also includes the Amsterdam Arena and the Kaohsiung Stadium. The latter,
inaugurated in 2009, has 8,844 photovoltaic panels producing up to 1.14 GWh of electricity
annually. This reduces the annual output of carbon dioxide by 660 tons and supplies up
to 80 percent of the surrounding area when the stadium is not in use. This is proof that a
stadium can serve its city, and have a decidedly positive impact in terms of reduction of CO₂
emissions.
G Sporting arenas have always been central to the life and culture of cities. In every era, the
stadium has acquired new value and uses: from military fortress to residential village, public
space to theatre and most recently a field for experimentation in advanced engineering.
The stadium of today now brings together multiple functions, thus helping cities to create a
sustainable future.
21
```

[Original question page](assets/cea8d42dcfe0149cf83308515bd1cafc1b6f2b3b7cb0586d6418dd37a9790222.jpg)

<!-- Source: /api/assets/b1a8d8d8956a0f63e4308970449c887d9d92ffb1b5497b2d39063c4152159f6d.jpg; PDF page 21; full -->

```text
Test 1
Questions 14-17
Reading Passage 2 has seven sections, A-G.
Which section contains the following information?
Write the correct letter, A-G, in boxes 14-17 on your answer sheet.
NB You may use any letter more than once.
14 a mention of negative attitudes towards stadium building projects
15 figures demonstrating the environmental benefits of a certain stadium
16 examples of the wide range of facilities available at some new stadiums
17 reference to the disadvantages of the stadiums built during a certain era
Questions 18-22
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 18-22 on your answer sheet.
Roman amphitheatres
The Roman stadiums of Europe have proved very versatile. The amphitheatre of Arles, for example, was converted first into a (18) __________, then into a residential area and finally into an arena where spectators could watch (19) __________. Meanwhile, the arena in Verona, one of the oldest Roman amphitheatres, is famous today as a venue where (20) __________ is performed. The site of Lucca’s amphitheatre has also been used for many purposes over the centuries, including the storage of (21) __________. It is now a market square with (22) __________ and homes incorporated into the remains of the Roman amphitheatre.
```

[Original question page](assets/b1a8d8d8956a0f63e4308970449c887d9d92ffb1b5497b2d39063c4152159f6d.jpg)

<!-- Source: /api/assets/c615156f9b8036cc13082dd527a3a5f7bc9bee23cadc096b0feb9b58d5aedb02.jpg; PDF page 22; full -->

```text
Reading
Questions 23 and 24
Choose TWO letters, A-E.
Write the correct letters in boxes 23 and 24 on your answer sheet.
When comparing twentieth-century stadiums to ancient amphitheatres in Section D,
which TWO negative features does the writer mention?
A They are less imaginatively designed.
B They are less spacious.
C They are in less convenient locations.
D They are less versatile.
E They are made of less durable materials.
Questions 25 and 26
Choose TWO letters, A-E.
Write the correct letters in boxes 25 and 26 on your answer sheet.
Which TWO advantages of modern stadium design does the writer mention?
A offering improved amenities for the enjoyment of sports events
B bringing community life back into the city environment
C facilitating research into solar and wind energy solutions
D enabling local residents to reduce their consumption of electricity
E providing a suitable site for the installation of renewable power generators
```

[Original question page](assets/c615156f9b8036cc13082dd527a3a5f7bc9bee23cadc096b0feb9b58d5aedb02.jpg)

<!-- Source: /api/assets/712c7cdfeeb8b8563cbe8a0ef9af969df9719432774ffe82a0daacd8b5815445.jpg; PDF page 23; full -->

```text
Test 1
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
To catch a king
Anna Keay reviews Charles Spencer’s book about the hunt for King Charles II
during the English Civil War of the seventeenth century
Charles Spencer's latest book, To Catch a
King, tells us the story of the hunt for King
Charles II in the six weeks after his resounding
defeat at the Battle of Worcester in September
1651. And what a story it is. After his father
was executed by the Parliamentarians in 1649,
the young Charles II sacrificed one of the
very principles his father had died for and
did a deal with the Scots, thereby accepting
Presbyterianism* as the national religion in
return for being crowned King of Scots. His
arrival in Edinburgh prompted the English
Parliamentary army to invade Scotland in a
pre-emptive strike. This was followed by a
Scottish invasion of England. The two sides
finally faced one another at Worcester in
the west of England in 1651. After being
comprehensively defeated on the meadows
outside the city by the Parliamentarian army,
the 21-year-old king found himself the subject
of a national manhunt, with a huge sum
offered for his capture. Over the following
six weeks he managed, through a series of
heart-poundingly close escapes, to evade the
Parliamentarians before seeking refuge in
France. For the next nine years, the penniless
and defeated Charles wandered around Europe
with only a small group of loyal supporters.
Years later, after his restoration as king, the
50-year-old Charles II requested a meeting
with the writer and diarist Samuel Pepys. His
intention when asking Pepys to commit his
story to paper was to ensure that this most
extraordinary episode was never forgotten.
Over two three-hour sittings, the king related
to him in great detail his personal recollections
of the six weeks he had spent as a fugitive. As
the king and secretary settled down (a scene
that is surely a gift for a future scriptwriter),
Charles commenced his story: ‘After the battle
was so absolutely lost as to be beyond hope of
recovery, I began to think of the best way of
saving myself.’
One of the joys of Spencer’s book, a result not
least of its use of Charles II’s own narrative
as well as those of his supporters, is just how
close the reader gets to the action. The day-by-
day retelling of the fugitives’ doings provides
delicious details: the cutting of the king’s long
hair with agricultural shears, the use of walnut
leaves to dye his pale skin, and the day Charles
spent lying on a branch of the great oak tree in
Boscobel Wood as the Parliamentary soldiers
scoured the forest floor below. Spencer draws
out both the humour — such as the preposterous
refusal of Charles’s friend Henry Wilmot
to adopt disguise on the grounds that it was
beneath his dignity — and the emotional tension
when the secret of the king’s presence was
cautiously revealed to his supporters.
* Presbyterianism: part of the reformed Protestant religion
```

[Original question page](assets/712c7cdfeeb8b8563cbe8a0ef9af969df9719432774ffe82a0daacd8b5815445.jpg)

<!-- Source: /api/assets/58e105293a262f58ec45bd7578c4117e681e9be053bd21c73f79bd17b4b7825d.jpg; PDF page 24; full -->

```text
Charles’s adventures after losing the Battle of
Worcester hide the uncomfortable truth that
whilst almost everyone in England had been
appalled by the execution of his father, they
had not welcomed the arrival of his son with
the Scots army, but had instead firmly bolted
their doors. This was partly because he rode at
the head of what looked like a foreign invasion
force and partly because, after almost a decade
of civil war, people were desperate to avoid
it beginning again. This makes it all the more
interesting that Charles II himself loved the
story so much ever after. As well as retelling
it to anyone who would listen, causing eye-
rolling among courtiers, he set in train a series
of initiatives to memorialise it. There was to
be a new order of chivalry, the Knights of the
Royal Oak. A series of enormous oil paintings
depicting the episode were produced, including
a two-metre-wide canvas of Boscobel Wood
and a set of six similarly enormous paintings
of the king on the run. In 1660, Charles II
commissioned the artist John Michael Wright
to paint a flying squadron of cherubs* carrying
an oak tree to the heavens on the ceiling of his
bedchamber. It is hard to imagine many other
kings marking the lowest point in their life so
enthusiastically, or indeed pulling off such an
escape in the first place.
Charles Spencer is the perfect person to
pass the story on to a new generation. His
pacey, readable prose steers deftly clear of
modern idioms and elegantly brings to life the
details of the great tale. He has even-handed
sympathy for both the fugitive king and the
fierce republican regime that hunted him,
and he succeeds in his desire to explore far
more of the background of the story than
previous books on the subject have done. Indeed,
the opening third of the book is about how
Charles II found himself at Worcester in the first
place, which for some will be reason alone to
read To Catch a King.
The tantalising question left, in the end, is that
of what it all meant. Would Charles II have
been a different king had these six weeks never
happened? The days and nights spent in hiding
must have affected him in some way. Did the
need to assume disguises, to survive on wit and
charm alone, to use trickery and subterfuge to
escape from tight corners help form him? This
is the one area where the book doesn’t quite hit
the mark. Instead its depiction of Charles II in
his final years as an ineffective, pleasure-loving
monarch doesn’t do justice to the man (neither
is it accurate), or to the complexity of his
character. But this one niggle aside, To Catch a
King is an excellent read, and those who come
to it knowing little of the famous tale will find
they have a treat in store.
25
* cherub: an image of angelic children used in paintings
```

[Original question page](assets/58e105293a262f58ec45bd7578c4117e681e9be053bd21c73f79bd17b4b7825d.jpg)

<!-- Source: /api/assets/37e94ccb0fca48d6f8cfaa02b77fd7d852e8017edfdb988a058c01c3777d8461.jpg; PDF page 25; full -->

```text
Test 1
Questions 27-31
Complete the summary using the list of phrases, A—J, below.
Write the correct letter, A—J, in boxes 27—31 on your answer sheet.
The story behind the hunt for Charles II
Charles II’s father was executed by the Parliamentarian forces in 1649. Charles II then formed a (27) __________ with the Scots, and in order to become King of Scots, he abandoned an important (28) __________ that was held by his father and had contributed to his father’s death. The opposing sides then met outside Worcester in 1651. The battle led to a (29) __________ for the Parliamentarians and Charles had to flee for his life. A (30) __________ was offered for Charles’s capture, but after six weeks spent in hiding, he eventually managed to reach the (31) __________ of continental Europe.
A military innovation
B large reward
C widespread conspiracy
D relative safety
E new government
F decisive victory
G political debate
H strategic alliance
I popular solution
J religious conviction
Questions 32-35
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 32-35 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
32 Charles chose Pepys for the task because he considered him to be trustworthy.
33 Charles’s personal recollection of the escape lacked sufficient detail.
34 Charles indicated to Pepys that he had planned his escape before the battle.
35 The inclusion of Charles’s account is a positive aspect of the book.
26
```

[Original question page](assets/37e94ccb0fca48d6f8cfaa02b77fd7d852e8017edfdb988a058c01c3777d8461.jpg)

<!-- Source: /api/assets/1e9d040fb5dbc1af90c51cce636d2d811222e38729b7a98d7238d163e9a67657.jpg; PDF page 26; full -->

```text
Reading
Questions 36-40
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 36-40 on your answer sheet.





36 What is the reviewer’s main purpose in the first paragraph?
A to describe what happened during the Battle of Worcester
B to give an account of the circumstances leading to Charles II’s escape
C to provide details of the Parliamentarians’ political views
D to compare Charles II’s beliefs with those of his father
37 Why does the reviewer include examples of the fugitives’ behaviour in the third
paragraph?
A to explain how close Charles II came to losing his life
B to suggest that Charles II's supporters were badly prepared
C to illustrate how the events of the six weeks are brought to life
D to argue that certain aspects are not as well known as they should be
38 What point does the reviewer make about Charles II in the fourth paragraph?
A He chose to celebrate what was essentially a defeat.
B He misunderstood the motives of his opponents.
C He aimed to restore people’s faith in the monarchy.
D He was driven by a desire to be popular.
39 What does the reviewer say about Charles Spencer in the fifth paragraph?
A His decision to write the book comes as a surprise.
B He takes an unbiased approach to the subject matter.
C His descriptions of events would be better if they included more detail.
D He chooses language that is suitable for a twenty-first-century audience.
40 When the reviewer says the book ‘doesn’t quite hit the mark’, she is making the
point that
A it overlooks the impact of events on ordinary people.
B it lacks an analysis of prevalent views on monarchy.
C it omits any references to the deceit practised by Charles II during his time
in hiding.
D it fails to address whether Charles II’s experiences had a lasting influence
on him.
310 p.120) 27
```

[Original question page](assets/1e9d040fb5dbc1af90c51cce636d2d811222e38729b7a98d7238d163e9a67657.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/3911c3773e8e8ab1f1e2d7ea3b7909cc4ffd924fc0b3d1f15792f1430eae6df6.jpg; PDF page 27; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The maps below show an industrial area in the town of Norbiton, and planned future development of the site.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/3911c3773e8e8ab1f1e2d7ea3b7909cc4ffd924fc0b3d1f15792f1430eae6df6.jpg)

![Original figure](assets/3911c3773e8e8ab1f1e2d7ea3b7909cc4ffd924fc0b3d1f15792f1430eae6df6.jpg)

### Task 2

<!-- Source: /api/assets/73ff53718a2fe00cc84b8bb2263472c385587c342a5edb7e45bca20eeb0baac9.jpg; PDF page 28; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

It is important for people to take risks, both in their professional lives and their personal lives.

Do you think the advantages of taking risks outweigh the disadvantages?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/73ff53718a2fe00cc84b8bb2263472c385587c342a5edb7e45bca20eeb0baac9.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/c0a1af9af4a0bb9d7022716b335d482840773e82fc26a62fccab0201370c86d9.jpg; PDF page 29; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks you about yourself, your home,
work or studies and other familiar topics.
EXAMPLE
History
What did you study in history lessons when you were at school?
Did you enjoy studying history at school? [Why/Why not?]
How often do you watch TV programmes about history now? [Why/Why not?]
What period in history would you like to learn more about? [Why?]
PART 2
Describe the neighbourhood you lived in when you were a child.
You should say:
where in your town/city the neighbourhood was
what kind of people lived there
what it was like to live in this neighbourhood
and explain whether you would like to live in this neighbourhood in the future.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Neighbours
Example questions:
What sort of things can neighbours do to help each other?
How well do people generally know their neighbours in your country?
How important do you think it is to have good neighbours?
Facilities in cities
Example questions:
Which facilities are most important to people living in cities?
How does shopping in small local shops differ from shopping in large city centre shops?
Do you think that children should always go to the school nearest to where they live?
30
```

[Original question page](assets/c0a1af9af4a0bb9d7022716b335d482840773e82fc26a62fccab0201370c86d9.jpg)

### Part 2

<!-- Source: /api/assets/c0a1af9af4a0bb9d7022716b335d482840773e82fc26a62fccab0201370c86d9.jpg; PDF page 29; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks you about yourself, your home,
work or studies and other familiar topics.
EXAMPLE
History
What did you study in history lessons when you were at school?
Did you enjoy studying history at school? [Why/Why not?]
How often do you watch TV programmes about history now? [Why/Why not?]
What period in history would you like to learn more about? [Why?]
PART 2
Describe the neighbourhood you lived in when you were a child.
You should say:
where in your town/city the neighbourhood was
what kind of people lived there
what it was like to live in this neighbourhood
and explain whether you would like to live in this neighbourhood in the future.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Neighbours
Example questions:
What sort of things can neighbours do to help each other?
How well do people generally know their neighbours in your country?
How important do you think it is to have good neighbours?
Facilities in cities
Example questions:
Which facilities are most important to people living in cities?
How does shopping in small local shops differ from shopping in large city centre shops?
Do you think that children should always go to the school nearest to where they live?
30
```

[Original question page](assets/c0a1af9af4a0bb9d7022716b335d482840773e82fc26a62fccab0201370c86d9.jpg)

### Part 3

<!-- Source: /api/assets/c0a1af9af4a0bb9d7022716b335d482840773e82fc26a62fccab0201370c86d9.jpg; PDF page 29; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks you about yourself, your home,
work or studies and other familiar topics.
EXAMPLE
History
What did you study in history lessons when you were at school?
Did you enjoy studying history at school? [Why/Why not?]
How often do you watch TV programmes about history now? [Why/Why not?]
What period in history would you like to learn more about? [Why?]
PART 2
Describe the neighbourhood you lived in when you were a child.
You should say:
where in your town/city the neighbourhood was
what kind of people lived there
what it was like to live in this neighbourhood
and explain whether you would like to live in this neighbourhood in the future.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Neighbours
Example questions:
What sort of things can neighbours do to help each other?
How well do people generally know their neighbours in your country?
How important do you think it is to have good neighbours?
Facilities in cities
Example questions:
Which facilities are most important to people living in cities?
How does shopping in small local shops differ from shopping in large city centre shops?
Do you think that children should always go to the school nearest to where they live?
30
```

[Original question page](assets/c0a1af9af4a0bb9d7022716b335d482840773e82fc26a62fccab0201370c86d9.jpg)
