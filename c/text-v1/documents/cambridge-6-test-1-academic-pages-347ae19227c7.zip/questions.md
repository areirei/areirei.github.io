# 剑雅 6 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/804b4cbae632737abeb23407615b0332b9cf19cd551b3aa7fdd7a821b6dfed9f.jpg; PDF page 11; full -->

```text
Test 1
LISTENING
SECTION 1 Questions 1-10
Questions 1-4
Complete the notes below.
Write NO MORE THAN THREE WORDS for each answer.
10
Notes on sports club
Example Answer
Name of club: Kingswell
Facilities available: Golf
1 ....................... .
2 .................. ..... .
Classes available: • Kick-boxing
• 3 ....................... .
Additional facility : 4 ........................ (restaurant opening
soon)
```

[Original question page](assets/804b4cbae632737abeb23407615b0332b9cf19cd551b3aa7fdd7a821b6dfed9f.jpg)

<!-- Source: /api/assets/85882d39046dadb5b6e790bdf97d91fe70339b3eee8092b706c81ee042d9679c.jpg; PDF page 12; full -->

```text
Questions 5–8
Complete the table below. Write NO MORE THAN TWO NUMBERS for each answer.
MEMBERSHIP SCHEMES
| Type | Use of facilities | Cost of classes | Times | Joining fee | Annual subscription fee |
| --- | --- | --- | --- | --- | --- |
| GOLD | All | Free | Any time | £250 | (5) £__________ |
| SILVER | All | (6) £__________ | from (7) __________ to __________ | £225 | £300 |
| BRONZE | Restricted | £3 | from 10.30 to 3.30 weekdays only | £50 | (8) £__________ |
Questions 9 and 10
Complete the sentences below. Write ONE WORD ONLY for each answer.
9 To join the centre, you need to book an instructor’s __________.
10 To book a trial session, speak to David __________ (0458 95311).
```

[Original question page](assets/85882d39046dadb5b6e790bdf97d91fe70339b3eee8092b706c81ee042d9679c.jpg)

### Part 2

<!-- Source: /api/assets/525f8015e307a099c36c5b15eda9d4258e58703ca1901714070796e3564d40e9.jpg; PDF page 13; full -->

```text
Test I
SECTION 2 Questions 11-20
Questions 11-16
What change has been made to each part of the theatre?
Choose SIX answers from the box and write the correct letter, A-G. next to questions 11-16.
RIVENDEN CITY THEATRE
A doubled in number
B given separate entrance
C reduced in number
D increased in size
E replaced
F strengthened
G temporarily closed
Part of the theatre
11 box office
12 shop
13 ordinary seats
14 seats for wheelchair users
15 lifts
16 dressing rooms
12
```

[Original question page](assets/525f8015e307a099c36c5b15eda9d4258e58703ca1901714070796e3564d40e9.jpg)

<!-- Source: /api/assets/916e5d38fc9d6dd1015548bfc391c5a63f4d10ed1a03f36246766d5ec35e8ab3.jpg; PDF page 14; full -->

```text
Questions 17–20
Complete the table below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
| Play | Dates | Starting time | Tickets available | Price |
| --- | --- | --- | --- | --- |
| Royal Hunt of the Sun | October 13th to (17) __________ | (18) __________ pm | for (19) __________ and __________ | (20) £__________ |
[Original column heading is printed “Prine”; corrected here to “Price”.]
```

[Original question page](assets/916e5d38fc9d6dd1015548bfc391c5a63f4d10ed1a03f36246766d5ec35e8ab3.jpg)

### Part 3

<!-- Source: /api/assets/3f1acc37f244fce00184e0cb064b6b75e88cca5c4c1836d36213429dd83f7ac3.jpg; PDF page 15; full -->

```text
Test I
SECTION 3 Questions 21-30
Question 21
Choose the correct letter, A, B or C
21 What is Brian going to do before the course starts?
A attend a class
B write a report
C read a book
Questions 22-25
Complete the table below.
Write NO MORE THAN TWO WORDS for each answer.
Refectory inform them 22 ........................ about special dietary
requirements
23 ........................ long waiting list, apply now
Careers advice drop-in centre for information
Fitness centre reduced 24 ........................ for students
Library includes books, journals, equipment room containing
audio-visual materials
Computers ask your 25 ........................ to arrange a password with
the technical support team
14
```

[Original question page](assets/3f1acc37f244fce00184e0cb064b6b75e88cca5c4c1836d36213429dd83f7ac3.jpg)

<!-- Source: /api/assets/2368eb990e887bd826d2430d5ff52186b14a95588498bf967fdb9baba6b9989f.jpg; PDF page 16; full -->

```text
Listening
Questions 26-30
Complete the summary below.
Write NO MORE THAN TWO WORDS for each answer.
Business Centre
The Business Resource Centre contains materials such as books and manuals to
be used for training. It is possible to hire 26 ........................ and 27 ........................ .
There are materials for working on study skills (e.g. 28 ........................ )and other
subjects include finance and 29 ........................ .
30 ........................ membership costs £50 per year.
15
```

[Original question page](assets/2368eb990e887bd826d2430d5ff52186b14a95588498bf967fdb9baba6b9989f.jpg)

### Part 4

<!-- Source: /api/assets/ecb66206c606cb96c5dd1a41eb1eee257fadfb4d3b53c3ed2e2d286000307433.jpg; PDF page 17; full -->

```text
SECTION 4 Questions 31–40
Questions 31–37
Complete the table below. Write NO MORE THAN TWO WORDS for each answer.
Social history of the East End of London
| Period | Situation |
| --- | --- |
| 1st–4th centuries | Produce from the area was used to (31) __________ the people of London. |
| 5th–10th centuries | New technology allowed the production of goods made of (32) __________ and __________. |
| 11th century | Lack of (33) __________ in the East End encouraged the growth of businesses. |
| 16th century | Construction of facilities for the building of (34) __________ stimulated international trade. Agricultural workers came from other parts of (35) __________ to look for work. |
| 17th century | Marshes were drained to provide land that could be (36) __________ on. |
| 19th century | Inhabitants lived in conditions of great (37) __________ with very poor sanitation. |
```

[Original question page](assets/ecb66206c606cb96c5dd1a41eb1eee257fadfb4d3b53c3ed2e2d286000307433.jpg)

<!-- Source: /api/assets/7eed0376b14d68a18fb45249dd97729d3f8f41ae7b7847b6e80278f7b3514ae0.jpg; PDF page 18; full -->

```text
Reading
Questions 38-40
Choose THREE letters, A-G.
Which THREE of the following problems are mentioned in connection with 20th century
housing in the East End?
A unsympathetic landlords
B unclean water
C heating problems
D high rents
E overcrowding
F poor standards of building
G houses catching fire
17
```

[Original question page](assets/7eed0376b14d68a18fb45249dd97729d3f8f41ae7b7847b6e80278f7b3514ae0.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/1855d04e49c6c69a62e02fa74f447e11c367c4552cce43850cec16ba08c05598.jpg; PDF page 19; full -->

```text
Test 1
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage 1
below.
AUSTRALIA'S
SPORTING
SUCCESS
A They play hard, they play often, and they play to win. Australian sports teams win more than
their fair share of titles, demolishing rivals with seeming ease . How do they do it? A big part of
the secret is an extensive and expensive network of sporting academies underpinned by
science and medicine . At the Australian Institute of Sport (AIS), hundreds of youngsters and
pros live and train under the eyes of coaches. Another body, the Australian Sports Commission
(ASC), finances programmes of excellence in a total of 96 sports for thousands of sportsmen
and women. Both provide intensive coaching, training facilities and nutritional advice.
B Inside the academies, science takes centre stage. The AIS employs more than 100 sports
scientists and doctors, and collaborates with scores of others in universities and research
centres . AIS scientists work across a number of sports, applying skills learned in one - such as
building muscle strength in golfers- to others, such as swimming and squash . They are backed
up by technicians who design instruments to collect data from athletes. They all focus on one
aim: winning. 'We can't waste our time looking at ethereal scientific questions that don't help
the coach work with an athlete and improve performance,' says Peter Fricker, chief of
science at AIS.
C A lot of their work comes down to measurement - everything from the exact angle of a
swimmer's dive to the second-by-second power output of a cyclist. This data is used to wring
improvements out of athletes. The focus is on individuals, tweaking performances to squeeze an
extra hundredth of a second here , an extra millimetre there. No gain is too slight to bother
with. It’s the tiny, gradual improvements that add up to world-beating results. To demonstrate
how the system works, Bruce Mason at AIS shows off the prototype of a 3D analysis tool for
studying swimmers. A wire-frame model of a champion swimmer slices through the water, her
arms moving in slow motion. Looking side-on, Mason measures the distance between strokes.
From above, he analyses how her spine swivels. When fully developed, this system will enable
him to build a biomechanical profile for coaches to use to help budding swimmers. Mason's
contribution to sport also includes the development of the SWAN (SWimming ANalysis)
system now used in Australian national competitions. it collects images from digital cameras
18
```

[Original question page](assets/1855d04e49c6c69a62e02fa74f447e11c367c4552cce43850cec16ba08c05598.jpg)

<!-- Source: /api/assets/8f08715dd98b9360b0e1c493934885edd4db51149e15b2f1920ec6472371661f.jpg; PDF page 20; full -->

```text
Reading
running at 50 frames a second and breaks down each part of a swimmer's performance into
factors that can be analysed individually - stroke length, stroke frequency, average duration of
each stroke, velocity, start, lap and finish times, and so on. At the end of each race, SWAN spits
out data on each swimmer.
D Take a look,' says Mason, pulling out a sheet of data. He points out the data on the swimmers in
second and third place, which shows that the one who finished third actually swam faster. So
why did he finish 35 hundredths of a second down? 'His turn times were 44 hundredths of a
second behind the other guy.' says Mason. 'If he can improve on his turns, he can do much
better.' This is the kind of accuracy that AIS scientists' research is bringing to a range of sports.
With the Cooperative Research Centre for Micro Technology in Melbourne, they are
developing unobtrusive sensors that will be embedded in an athlete's clothes or running shoes
to monitor heart rate, sweating, heat production or any other factor that might have an impact
on an athlete's ability to run. There's more to it than simply measuring performance . Fricker gives
the example of athletes who may be down with coughs and colds 11 or 12 times a year. After
years of experimentation, AIS and the University of Newcastle in New South Wales developed
a test that measures how much of the immune-system protein immunoglobulin A is present in
athletes' saliva. If IgA levels suddenly fall below a certain level, training is eased or dropped
altogether. Soon, IgA levels start rising again, and the danger passes. Since the tests were
introduced, AIS athletes in all sports have been remarkably successful at staying healthy.
E Using data is a complex business. Well before a championship, sports scientists and coaches
start to prepare the athlete by developing a 'competition model', based on what they expect
will be the winning times. 'You design the model to make that time,' says Mason. 'A start of this
much, each free-swimming period has to be this fast, with a certain stroke frequency and stroke
length, with turns done in these times .' All the training is then geared towards making the athlete
hit those targets, both overall and for each segment of the race. Techniques like these have
transformed Australia into arguably the world 's most successful sporting nation.
F Of course, there's nothing to stop other countries copying - and many have tried . Some years
ago, the AIS unveiled coolant-lined jackets for endurance athletes. At the Atlanta Olympic
Games in 1996, these sliced as much as two per cent off cyclists' and rowers' times . Now
everyone uses them. The same has happened to the 'altitude tent', developed by AIS to replicate
the effect of altitude training at sea level. But Australia's success story is about more than easily
copied technological fixes, and up to now no nation has replicated its all-encompassing system.
19
```

[Original question page](assets/8f08715dd98b9360b0e1c493934885edd4db51149e15b2f1920ec6472371661f.jpg)

<!-- Source: /api/assets/f8d0149ad16c099fd97895e0723ad7d7d97e5ff80c9b85808a11d46929c23070.jpg; PDF page 21; full -->

```text
Test 1
Questions 1-7
Reading Passage 1 has six paragraphs, A-F.
Which paragraph contains the following information?
Write the correct letter, A-F, in boxes 1-7 on your answer sheet.
NB You may use any letter more than once.
1 a reference to the exchange of expertise between different sports
2 an explanation of how visual imaging is employed in investigations
3 a reason for narrowing the scope of research activity
4 how some AIS ideas have been reproduced
5 how obstacles to optimum achievement can be investigated
6 an overview of the funded support of athletes
7 how performance requirements are calculated before an event
Questions 8-11
Classify the following techniques according to whether the writer states they
A are currently exclusively used by Australians
B will be used in the future by Australians
C are currently used by both Australians and their rivals
Write the correct letter, A, B or C, in boxes 8-11 on your answer sheet.
8 cameras
9 sensors
10 protein tests
11 altitude tents
20
```

[Original question page](assets/f8d0149ad16c099fd97895e0723ad7d7d97e5ff80c9b85808a11d46929c23070.jpg)

<!-- Source: /api/assets/c55b72f097364635352da9ac68b0ef1e7c8b1d42ff43cba260e93777b3b66cb1.jpg; PDF page 22; full -->

```text
Reading
Questions 12 and 13
Answer the questions below.
Choose NO MORE THAN THREE WORDS AND/OR A NUMBER from the passage for
each answer.
Write your answers in boxes 12 and 13 on your answer sheet.
12 What is produced to help an athlete plan their performance in an event?
13 By how much did some cyclists' performance improve at the 1996 Olympic Games?
21
```

[Original question page](assets/c55b72f097364635352da9ac68b0ef1e7c8b1d42ff43cba260e93777b3b66cb1.jpg)

<!-- Source: /api/assets/c7fe971093cec5f52b5a5304808772efc22438baab3fcf10e2f2a72b5474df49.jpg; PDF page 23; full -->

```text
Test I
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26 , which are based on Reading Passage 2
below.
DELIVERING THE GOODS
The vast expansion in international trade owes much to a revolution in the business
of moving freight
A International trade is growing at a startling pace. While the global economy has been expanding
at a bit over 3% a year, the volume of trade has been rising at a compound annual rate of about
twice that. Foreign products, from meat to machinery, play a more important role in almost every
economy in the world, and foreign markets now tempt businesses that never much worried
about sales beyond their nation's borders.
B What lies behind this explosion in international commerce? The general worldwide decline in
trade barriers, such as customs duties and import quotas, is surely one explanation . The
economic opening of countries that have traditionally been minor players is another. But one
force behind the import-export boom has passed all but unnoticed: the rapidly falling cost of
getting goods to market. Theoretically, in the world of trade , shipping costs do not matter.
Goods, once they have been made, are assumed to move instantly and at no cost from
place to place . The real world , however, is full of frictions . Cheap labour may make Chinese
clothing competitive in America, but if delays in shipment tie up working capital and cause
winter coats to arrive in spring , trade may lose its advantages .
C At the turn of the 20th century, agriculture and manufacturing were the two most important
sectors almost everywhere, accounting for about 70% of total output in Germany, Italy and
France, and 40-50% in America , Britain and Japan . International commerce was therefore
dominated by raw materials , such as wheat, wood and iron ore, or processed commodities ,
such as meat and steel. But these sorts of products are heavy and bulky and the cost of
transporting them relatively high.
D Countries still trade disproportionately with their geographic neighbours . Over time, however,
world output has shifted into goods whose worth is unrelated to their size and weight. Today,
it is finished manufactured products that dominate the flow of trade, and, thanks to
technological advances such as lightweight components , manufactured goods themselves
have tended to become lighter and less bulky. As a result, less transportation is required for
every dollar's worth of imports or exports.
22
```

[Original question page](assets/c7fe971093cec5f52b5a5304808772efc22438baab3fcf10e2f2a72b5474df49.jpg)

<!-- Source: /api/assets/f77cf6d601d65324b14b2c669163547a96b7eb4ac4a7cba7dba726e1f74e6689.jpg; PDF page 24; full -->

```text
Reading
E To see how this influences trade, consider the business of making disk drives for computers .
Most of the world's disk-drive manufacturing is concentrated in South-east Asia. This is
possible only because disk drives, while valuable , are small and light and so cost little to
ship. Computer manufacturers in Japan or Texas will not face hugely bigger freight bills if
they import drives from Singapore rather than purchasing them on the domestic market.
Distance therefore poses no obstacle to the globalisation of the disk-drive industry.
F This is even more true of the fast-growing information industries . Films and compact discs
cost little to transport, even by aeroplane . Computer software can be 'exported ' without ever
loading it onto a ship, simply by transmitting it over telephone lines from one country to
another, so freight rates and cargo-handling schedules become insignificant factors in
deciding where to make the product. Businesses can locate based on other considerations,
such as the availability of labour, while worrying less about the cost of delivering their output.
G In many countries deregulation has helped to drive the process along . But, behind the
scenes, a series of technological innovations known broadly as containerisation and inter­
modal transportation has led to swift productivity improvements in cargo-handling . Forty
years ago, the process of exporting or importing involved a great many stages of handling ,
which risked portions of the shipment being damaged or stolen along the way. The invention
of the container crane made it possible to load and unload containers without capsizing the
ship and the adoption of standard container sizes allowed almost any box to be transported
on any ship. By 1967, dual-purpose ships , carrying loose cargo in the hold* and containers
on the deck , were giving way to all-container vessels that moved thousands of boxes at a
time.
H The shipping container transformed ocean shipping into a highly efficient , intensely
competitive business . But getting the cargo to and from the dock was a different story.
National governments , by and large, kept a much firmer hand on truck and railroad tariffs
than on charges for ocean freight. This started changing , however, in the mid-1970s , when
America began to deregulate its transportation industry. First airlines, then road hauliers and
railways, were freed from restrictions on what they could carry, where they could haul it and
what price they could charge . Big productivity gains resulted . Between 1985 and 1996, for
example , America 's freight railways dramatically reduced their employment, trackage , and
their fleets of locomotives- while increasing the amount of cargo they hauled . Europe's
railways have also shown marked , albeit smaller, productivity improvements .
I In America the period of huge productivity gains in transportation may be almost over, but in
most countries the process still has far to go. State ownership of railways and airlines,
regulation of freight rates and toleration of anti-competitive practices , such as
cargo-handling monopolies , all keep the cost of shipping unnecessarily high and deter
international trade . Bringing these barriers down would help the world 's economies grow
even closer.
* hold: ship's storage area below deck
23
```

[Original question page](assets/f77cf6d601d65324b14b2c669163547a96b7eb4ac4a7cba7dba726e1f74e6689.jpg)

<!-- Source: /api/assets/a9cf5a740fe54c6ad60a2783784789474184abb88b5696da64a880573657e15e.jpg; PDF page 25; full -->

```text
Test 1
Questions 14-17
Reading Passage 2 has nine paragraphs , A–I.
Which paragraph contains the following information?
Write the correct letter, A–I, in boxes 14-17 on your answer sheet.
14 a suggestion for improving trade in the future
15 the effects of the introduction of electronic delivery
16 the similar cost involved in transporting a product from abroad or from a local supplier
17 the weakening relationship between the value of goods and the cost of their delivery
Questions 18-22
Do the following statements agree with the information given in Reading Passage 2?
In boxes 18-22 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
18 International trade is increasing at a greater rate than the world economy.
19 Cheap labour guarantees effective trade conditions.
20 Japan imports more meat and steel than France.
21 Most countries continue to prefer to trade with nearby nations.
22 Small computer components are manufactured in Germany.
24
```

[Original question page](assets/a9cf5a740fe54c6ad60a2783784789474184abb88b5696da64a880573657e15e.jpg)

<!-- Source: /api/assets/b90304d7198650f20feaf9979dbd25b5e6d9512749ea5eec7f21cc8102765341.jpg; PDF page 26; full -->

```text
Reading
Questions 23-26
Complete the summary using the list of words, A-K, below.
Write the correct letter, A-K, in boxes 23-26 on your answer sheet.
THE TRANSPORT REVOLUTION
Modern cargo-handling methods have had a significant effect on 23 ........................ as the
business of moving freight around the world becomes increasingly streamlined .
Manufacturers of computers, for instance, are able to import 24 ...................... ..
from overseas , rather than having to rely on a local supplier. The introduction of
25 ..... .............. : .... has meant that bulk cargo can be safely and efficiently moved over long
distances . While international shipping is now efficient, there is still a need for governments to
reduce 26 ....................... : in order to free up the domestic cargo sector.
A tariffs B components C container ships
D output E employees F insurance costs
G trade H freight I fares
J software K international standards
25
```

[Original question page](assets/b90304d7198650f20feaf9979dbd25b5e6d9512749ea5eec7f21cc8102765341.jpg)

<!-- Source: /api/assets/669370fbdbdb8b7a64f7b71e670a37a99e5d723b25a249ec00eaee96791a3bee.jpg; PDF page 27; full -->

```text
Testl
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40. which are based on Reading Passage 3
on the following pages.
Questions 27-32
Reading Passage 3 has seven paragraphs , A-G .
Choose the correct heading for paragraphs B-G from the list of headings below.
Write the correct number, i-ix , in boxes 27- 32 on your answer sheet.
List of Headings
i The reaction of the Inuit community to climate change
ii Understanding of climate change remains limited
iii Alternative sources of essential supplies
iv Respect for Inuit opinion grows
v A healthier choice of food
vi A difficult landscape
vii Negative effects on well-being
viii Alarm caused by unprecedented events in the Arctic
ix The benefits of an easier existence
Example: Paragraph A — viii
27 Paragraph B __________
28 Paragraph C __________
29 Paragraph D __________
30 Paragraph E __________
31 Paragraph F __________
32 Paragraph G __________
```

[Original question page](assets/669370fbdbdb8b7a64f7b71e670a37a99e5d723b25a249ec00eaee96791a3bee.jpg)

<!-- Source: /api/assets/e011e8da7b31f084bfb5515da14e706471c26fce870c9467789c8c0c189c3298.jpg; PDF page 28; full -->

```text
Reading
Climate Change and
the Inuit
The threat posed by climate change in the
Arctic and the problems faced by Canada's
Inuit people ........................................................................................................................................ :
A Unusual incidents are being reported across the Arctic. Inuit families going off on
snowmobiles to prepare their summer hunting camps have found themselves cut off
from home by a sea of mud, following early thaws . There are reports of igloos losing
their insulating properties as the snow drips and refreezes, of lakes draining into the
sea as permafrost melts, and sea ice breaking up earlier than usual, carrying seals
beyond the reach of hunters. Climate change may still be a rather abstract idea
to most of us, but in the Arctic it is already having dramatic effects- if summertime ice
continues to shrink at its present rate, the Arctic Ocean could soon become virtually
ice-free in summer. The knock-on effects are likely to include more warming, cloudier
skies, increased precipitation and higher sea levels. Scientists are increasingly
keen to find out what's going on because they consider the Arctic the 'canary in the
mine ' for global warming- a warning of what's in store for the rest of the world.
B For the Inuit the problem is urgent. They live in precarious balance with one of the
toughest environments on earth. Climate change, whatever its causes, is a direct threat
to their way of life. Nobody knows the Arctic as well as the locals, which is why they are
not content simply to stand back and let outside experts tell them what's happening. In
Canada, where the Inuit people are jealously guarding their hard-won autonomy in the
country's newest territory, Nunavut, they believe their best hope of survival in this
changing environment lies in combining their ancestral knowledge with the best of
modern science. This is a challenge in itself .
C The Canadian Arctic is a vast, treeless polar desert that's covered with snow for most of
the year. Venture into this terrain and you get some idea of the hardships facing anyone
who calls this home. Farming is out of the question and nature offers meagre pickings.
Humans first settled in the Arctic a mere 4,500 years ago, surviving by exploiting sea
mammals and fish . The environment tested them to the limits: sometimes the colonists
were successful, sometimes they failed and vanished. But around a thousand years ago,
one group emerged that was uniquely well adapted to cope with the Arctic
environment . These Thule people moved in from Alaska, bringing kayaks, sleds, dogs,
pottery and iron tools. They are the ancestors of today's Inuit people .
D Life for the descendants of the Thule people is still harsh. Nunavut is 1.9 million square
kilometres of rock and ice, and a handful of islands around the North Pole. It’s currently
home to 2,500 people, all but a handful of them indigenous Inuit . Over the past 40
years, most have abandoned their nomadic ways and settled in the territory's 28 isolated
communities, but they still rely heavily on nature to provide food and clothing.
27
```

[Original question page](assets/e011e8da7b31f084bfb5515da14e706471c26fce870c9467789c8c0c189c3298.jpg)

<!-- Source: /api/assets/a0bde83514c68122fbe866899872cbb59b829545e2b657a40e33f699a64c9938.jpg; PDF page 29; full -->

```text
Test 1
Provisions available in local shops have to be flown into Nunavut on one of the most
costly air networks in the world, or brought by supply ship during the few ice-free weeks
of summer. It would cost a family around £7,000 a year to replace meat they obtained
themselves through hunting with imported meat. Economic opportunities are scarce,
and for many people state benefits are their only income.
E While the Inuit may not actually starve if hunting and trapping are curtailed by climate
change, there has certainly been an impact on people's health. Obesity, heart disease
and diabetes are beginning to appear in a people for whom these have never before
been problems . There has been a crisis of identity as the traditional skills of hunting,
trapping and preparing skins have begun to disappear. In Nunavut's 'igloo and email '
society, where adults who were born in igloos have children who may never have been
out on the land, there's a high incidence of depression .
F With so much at stake, the Inuit are determined to play a key role in teasing out the
mysteries of climate change in the Arctic. Having survived there for centuries, they
believe their wealth of traditional knowledge is vital to the task. And Western scientists
are starting to draw on this wisdom, increasingly referred to as 'Inuit
Qaujimajatuqangit', or IQ. 'In the early days scientists ignored us when they came up
here to study anything. They just figured these people don't know very much so we
won't ask them,' says John Amagoalik, an Inuit leader and politician. 'But in recent years
IQ has had much more credibility and weight.' In fact it is now a requirement for anyone
hoping to get permission to do research that they consult the communities, who are
helping to set the research agenda to reflect their most important concerns. They can
turn down applications from scientists they believe will work against their interests, or
research projects that will impinge too much on their daily lives and traditional activities.
G Some scientists doubt the value of traditional knowledge because the occupation of the
Arctic doesn't go back far enough. Others, however , point out that the first weather
stations in the far north date back just 50 years. There are still huge gaps in our
environmental knowledge, and despite the scientific onslaught, many predictions are no
more than best guesses. IQ could help to bridge the gap and resolve the tremendous
uncertainty about how much of what we're seeing is natural capriciousness and how
much is the consequence of human activity.
28
```

[Original question page](assets/a0bde83514c68122fbe866899872cbb59b829545e2b657a40e33f699a64c9938.jpg)

<!-- Source: /api/assets/2f394a00270598e6f508c5c0e947a58458dbd2da13673b7022616855f9fd0969.jpg; PDF page 30; full -->

```text
Writing
Questions 33-40
Complete the summary of paragraphs C and D below.
Choose NO MORE THAN TWO WORDS from paragraphs C and D for each answer.
Write your answers in boxes 33-40 on your answer sheet.
If you visit the Canadian Arctic, you immediately appreciate the problems faced by
people for whom this is home. It would clearly be impossible for the people to engage in
33 ..................... ... as a means of supporting themselves. For thousands of years they have
had to rely on catching 34 ........................ and 35 ................... ..... as a means of sustenance.
The harsh surroundings saw many who tried to settle there pushed to their limits, although
some were successful. The 36 ............. ........... people were an example of the latter and for
them the environment did not prove unmanageable. For the present inhabitants, life
continues to be a struggle . The territory of Nunavut consists of little more than ice, rock and
a few 37 .......... .......... ..... In recent years, many of them have been obliged to give up their
38 ........................ lifestyle, but they continue to depend mainly on 39 ........................ for
their food and clothes . 40 ........................ produce is particularly expensive.
29
```

[Original question page](assets/2f394a00270598e6f508c5c0e947a58458dbd2da13673b7022616855f9fd0969.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/84eccbc6ea74bf54129064397c1ad12d80f589afce7099efdc6bc22ee06a32b3.jpg; PDF page 31; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph and table below give information about water use worldwide and water consumption in two different countries.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the original figure is retained for the complete plotted data or diagram.]
```

[Original question page](assets/84eccbc6ea74bf54129064397c1ad12d80f589afce7099efdc6bc22ee06a32b3.jpg)

![Original figure](assets/84eccbc6ea74bf54129064397c1ad12d80f589afce7099efdc6bc22ee06a32b3.jpg)

### Task 2

<!-- Source: /api/assets/8de51de42d90f93dc42245d113d617fe9095aaf5065fffc8fb2f3cac0b56bf57.jpg; PDF page 32; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Today, the high sales of popular consumer goods reflect the power of advertising and not the real needs of the society in which they are sold.

To what extent do you agree or disagree?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/8de51de42d90f93dc42245d113d617fe9095aaf5065fffc8fb2f3cac0b56bf57.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/20b1e5a73eec9dc3d755d7a4df5b1d6358802763baa31d7003005cc489bd4a07.jpg; PDF page 33; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics.
EXAMPLE — Dancing
• Do you enjoy dancing? [Why/Why not?]
• Has anyone ever taught you to dance? [Why/Why not?]
• Tell me about any traditional dancing in your country.
• Do you think that traditional dancing will be popular in the future? [Why/Why not?]
PART 2
Describe someone in your family who you like.
You should say: how this person is related to you; what this person looks like; what kind of person he/she is; and explain why you like this person.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics: Family similarities
In what ways can people in a family be similar to each other?
Do you think that daughters are always more similar to mothers than to male relatives?
What about sons and fathers?
In terms of personality, are people more influenced by their family or by their friends? In what ways?
Genetic research
Where can people in your country get information about genetic research?
How do people in your country feel about genetic research?
Should this research be funded by governments or private companies? Why?
```

[Original question page](assets/20b1e5a73eec9dc3d755d7a4df5b1d6358802763baa31d7003005cc489bd4a07.jpg)

### Part 2

<!-- Source: /api/assets/20b1e5a73eec9dc3d755d7a4df5b1d6358802763baa31d7003005cc489bd4a07.jpg; PDF page 33; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics.
EXAMPLE — Dancing
• Do you enjoy dancing? [Why/Why not?]
• Has anyone ever taught you to dance? [Why/Why not?]
• Tell me about any traditional dancing in your country.
• Do you think that traditional dancing will be popular in the future? [Why/Why not?]
PART 2
Describe someone in your family who you like.
You should say: how this person is related to you; what this person looks like; what kind of person he/she is; and explain why you like this person.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics: Family similarities
In what ways can people in a family be similar to each other?
Do you think that daughters are always more similar to mothers than to male relatives?
What about sons and fathers?
In terms of personality, are people more influenced by their family or by their friends? In what ways?
Genetic research
Where can people in your country get information about genetic research?
How do people in your country feel about genetic research?
Should this research be funded by governments or private companies? Why?
```

[Original question page](assets/20b1e5a73eec9dc3d755d7a4df5b1d6358802763baa31d7003005cc489bd4a07.jpg)

### Part 3

<!-- Source: /api/assets/20b1e5a73eec9dc3d755d7a4df5b1d6358802763baa31d7003005cc489bd4a07.jpg; PDF page 33; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics.
EXAMPLE — Dancing
• Do you enjoy dancing? [Why/Why not?]
• Has anyone ever taught you to dance? [Why/Why not?]
• Tell me about any traditional dancing in your country.
• Do you think that traditional dancing will be popular in the future? [Why/Why not?]
PART 2
Describe someone in your family who you like.
You should say: how this person is related to you; what this person looks like; what kind of person he/she is; and explain why you like this person.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics: Family similarities
In what ways can people in a family be similar to each other?
Do you think that daughters are always more similar to mothers than to male relatives?
What about sons and fathers?
In terms of personality, are people more influenced by their family or by their friends? In what ways?
Genetic research
Where can people in your country get information about genetic research?
How do people in your country feel about genetic research?
Should this research be funded by governments or private companies? Why?
```

[Original question page](assets/20b1e5a73eec9dc3d755d7a4df5b1d6358802763baa31d7003005cc489bd4a07.jpg)
