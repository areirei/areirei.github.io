# 剑雅 6 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 152

TEST 1 LISTENING
Section 1, Questions 1–10
1 (a) keep-fit (studio)
2 swimming
3 yoga (classes)
4 (a) salad bar
5 500
6 1
7 10 (am), 4.30 (pm)
8 180
9 assessment
10 Kynchley
Section 2, Questions 11–20
11 B
12 G
13 C
14 A
15 E
16 D
17 (October (the)) 19th
18 7
19 Monday, Thursday
20 18
Section 3, Questions 21–30
21 A
22 in advance
23 nursery
24 annual fee
25 tutor
26–27 IN EITHER ORDER: laptops; printers
28 report writing
29 marketing
30 Individual
Section 4, Questions 31–40
31 feed
32 IN EITHER ORDER: metal; leather
33 restrictions
34 ships
35 England
36 built
37 poverty
38–40 IN ANY ORDER: C; E; F
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. keep-fit / keep-fit studio / a keep-fit / a keep-fit studio

2. swimming

3. yoga / yoga classes

4. salad bar / a salad bar

5. 500

6. 1

7. 10 , 4.30 / 10 , 4:30 / 10 , 4.30 pm / 10 , 4.30pm / 10 , 4:30 pm / 10 , 4:30pm / 10 am, 4.30 / 10 am, 4:30 / 10am, 4.30 / 10am, 4:30 / 10 am, 4.30 pm / 10 am, 4:30 pm / 10am, 4.30pm / 10am, 4:30pm / 10 to 4.30 / 10 to 4:30 / 10 to 4.30 pm / 10 to 4.30pm / 10 to 4:30 pm / 10 to 4:30pm / 10 am to 4.30 / 10 am to 4:30 / 10am to 4.30 / 10am to 4:30 / 10 am to 4.30 pm / 10 am to 4:30 pm / 10am to 4.30pm / 10am to 4:30pm / 10 -4.30 / 10 -4:30 / 10 -4.30 pm / 10 -4.30pm / 10 -4:30 pm / 10 -4:30pm / 10 am-4.30 / 10 am-4:30 / 10am-4.30 / 10am-4:30 / 10 am-4.30 pm / 10 am-4:30 pm / 10am-4.30pm / 10am-4:30pm

8. 180

9. assessment

10. Kynchley

### Part 2 · source page 152

TEST 1 LISTENING
Section 1, Questions 1–10
1 (a) keep-fit (studio)
2 swimming
3 yoga (classes)
4 (a) salad bar
5 500
6 1
7 10 (am), 4.30 (pm)
8 180
9 assessment
10 Kynchley
Section 2, Questions 11–20
11 B
12 G
13 C
14 A
15 E
16 D
17 (October (the)) 19th
18 7
19 Monday, Thursday
20 18
Section 3, Questions 21–30
21 A
22 in advance
23 nursery
24 annual fee
25 tutor
26–27 IN EITHER ORDER: laptops; printers
28 report writing
29 marketing
30 Individual
Section 4, Questions 31–40
31 feed
32 IN EITHER ORDER: metal; leather
33 restrictions
34 ships
35 England
36 built
37 poverty
38–40 IN ANY ORDER: C; E; F
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. B

12. G

13. C

14. A

15. E

16. D

17. 19th / October 19th / October the 19th

18. 7

19. Monday Thursday / Monday, Thursday / Monday and Thursday / Monday & Thursday / Monday; Thursday / Monday/Thursday / Monday,Thursday / Thursday Monday / Thursday, Monday / Thursday and Monday / Thursday & Monday / Thursday; Monday / Thursday/Monday / Thursday,Monday

20. 18

### Part 3 · source page 152

TEST 1 LISTENING
Section 1, Questions 1–10
1 (a) keep-fit (studio)
2 swimming
3 yoga (classes)
4 (a) salad bar
5 500
6 1
7 10 (am), 4.30 (pm)
8 180
9 assessment
10 Kynchley
Section 2, Questions 11–20
11 B
12 G
13 C
14 A
15 E
16 D
17 (October (the)) 19th
18 7
19 Monday, Thursday
20 18
Section 3, Questions 21–30
21 A
22 in advance
23 nursery
24 annual fee
25 tutor
26–27 IN EITHER ORDER: laptops; printers
28 report writing
29 marketing
30 Individual
Section 4, Questions 31–40
31 feed
32 IN EITHER ORDER: metal; leather
33 restrictions
34 ships
35 England
36 built
37 poverty
38–40 IN ANY ORDER: C; E; F
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. A

22. in advance

23. nursery

24. annual fee

25. tutor

26. laptops / printers

27. laptops / printers

28. report writing

29. marketing

30. Individual

### Part 4 · source page 152

TEST 1 LISTENING
Section 1, Questions 1–10
1 (a) keep-fit (studio)
2 swimming
3 yoga (classes)
4 (a) salad bar
5 500
6 1
7 10 (am), 4.30 (pm)
8 180
9 assessment
10 Kynchley
Section 2, Questions 11–20
11 B
12 G
13 C
14 A
15 E
16 D
17 (October (the)) 19th
18 7
19 Monday, Thursday
20 18
Section 3, Questions 21–30
21 A
22 in advance
23 nursery
24 annual fee
25 tutor
26–27 IN EITHER ORDER: laptops; printers
28 report writing
29 marketing
30 Individual
Section 4, Questions 31–40
31 feed
32 IN EITHER ORDER: metal; leather
33 restrictions
34 ships
35 England
36 built
37 poverty
38–40 IN ANY ORDER: C; E; F
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. feed

32. metal leather / metal, leather / metal and leather / metal & leather / metal; leather / metal/leather / metal,leather / leather metal / leather, metal / leather and metal / leather & metal / leather; metal / leather/metal / leather,metal

33. restrictions

34. ships

35. England

36. built

37. poverty

38. C / E / F

39. C / E / F

40. C / E / F

## A 类阅读

### Academic Reading · source page 153

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 B
2 C
3 B
4 F
5 D
6 A
7 E
8 A
9 B
10 A
11 C
12 (a) competition model
13 (by) 2 per cent / %
Reading Passage 2, Questions 14–26
14 I
15 F
16 E
17 D
18 TRUE
19 FALSE
20 NOT GIVEN
21 TRUE
22 NOT GIVEN
23 G
24 B
25 C
26 A
Reading Passage 3, Questions 27–40
27 i
28 vi
29 iii
30 vii
31 iv
32 ii
33 farming
34–35 IN EITHER ORDER: sea mammals; fish
36 Thule
37 islands
38 nomadic
39 nature
40 Imported
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–30: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
31–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. B

2. C

3. B

4. F

5. D

6. A

7. E

8. A

9. B

10. A

11. C

12. competition model / a competition model

13. 2 per cent / 2% / by 2 per cent / by 2% / 2 percent / by 2 percent

14. I

15. F

16. E

17. D

18. TRUE

19. FALSE

20. NOT GIVEN

21. TRUE

22. NOT GIVEN

23. G

24. B

25. C

26. A

27. i

28. vi

29. iii

30. vii

31. iv

32. ii

33. farming

34. sea mammals / fish

35. sea mammals / fish

36. Thule

37. islands

38. nomadic

39. nature

40. Imported

## A 类写作

### Writing material: c6-t1-w-1

Graph: global water use by sector, 1900–2000, cubic kilometres (km³). Agriculture is highest throughout, rising from roughly 500 to 3000 km³; industrial use rises from roughly 100 to 1200; domestic use from a much smaller level to roughly 300. Increases accelerate particularly in the second half of the century; all curve readings are approximate. Table, Brazil and Democratic Republic of Congo in 2000: population 176 million versus 5.2 million; irrigated land 26,500 km² versus 100 km²; water consumption per person 359 m³ versus 8 m³. Keep volume, land area and per-person units distinct. Brazil is higher on every table measure. Do not convert the per-person figures into total national use or invent a daily consumption interval.



### Writing material: c6-t1-w-2

Evaluate the stated explanation of high consumer-goods sales: advertising power versus real needs. A supported qualified position is valid.



## 口语
