# 剑雅 16 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 121

TEST 1 LISTENING
1 egg
2 tower
3 car
4 animals
5 bridge
6 movie / film
7 decorate
8 Wednesdays
9 Fradstone
10 parking
11 C
12 A
13 B
14 C
15 H
16 C
17 G
18 B
19 I
20 A
21 C
22 E
23 B
24 E
25 D
26 C
27 A
28 H
29 F
30 G
31 practical
32 publication
33 choices
34 negative
35 play
36 capitalism
37 depression
38 logic
39 opportunity
40 practice / practise
21&22 IN EITHER ORDER: C,E
23&24 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. egg

2. tower

3. car

4. animals

5. bridge

6. movie / film

7. decorate

8. Wednesdays

9. Fradstone

10. parking

### Part 2 · source page 121

TEST 1 LISTENING
1 egg
2 tower
3 car
4 animals
5 bridge
6 movie / film
7 decorate
8 Wednesdays
9 Fradstone
10 parking
11 C
12 A
13 B
14 C
15 H
16 C
17 G
18 B
19 I
20 A
21 C
22 E
23 B
24 E
25 D
26 C
27 A
28 H
29 F
30 G
31 practical
32 publication
33 choices
34 negative
35 play
36 capitalism
37 depression
38 logic
39 opportunity
40 practice / practise
21&22 IN EITHER ORDER: C,E
23&24 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. C

12. A

13. B

14. C

15. H

16. C

17. G

18. B

19. I

20. A

### Part 3 · source page 121

TEST 1 LISTENING
1 egg
2 tower
3 car
4 animals
5 bridge
6 movie / film
7 decorate
8 Wednesdays
9 Fradstone
10 parking
11 C
12 A
13 B
14 C
15 H
16 C
17 G
18 B
19 I
20 A
21 C
22 E
23 B
24 E
25 D
26 C
27 A
28 H
29 F
30 G
31 practical
32 publication
33 choices
34 negative
35 play
36 capitalism
37 depression
38 logic
39 opportunity
40 practice / practise
21&22 IN EITHER ORDER: C,E
23&24 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. C / E

22. C / E

23. B / E

24. B / E

25. D

26. C

27. A

28. H

29. F

30. G

### Part 4 · source page 121

TEST 1 LISTENING
1 egg
2 tower
3 car
4 animals
5 bridge
6 movie / film
7 decorate
8 Wednesdays
9 Fradstone
10 parking
11 C
12 A
13 B
14 C
15 H
16 C
17 G
18 B
19 I
20 A
21 C
22 E
23 B
24 E
25 D
26 C
27 A
28 H
29 F
30 G
31 practical
32 publication
33 choices
34 negative
35 play
36 capitalism
37 depression
38 logic
39 opportunity
40 practice / practise
21&22 IN EITHER ORDER: C,E
23&24 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. practical

32. publication

33. choices

34. negative

35. play

36. capitalism

37. depression

38. logic

39. opportunity

40. practice / practise

## A 类阅读

### Academic Reading · source page 122

TEST 1 READING
1 FALSE
2 FALSE
3 NOT GIVEN
4 TRUE
5 TRUE
6 FALSE
7 TRUE
8 violent
9 tool
10 meat
11 photographer
12 game
13 frustration
14 iv
15 vii
16 ii
17 v
18 i
19 viii
20 vi
21 city
22 priests
23 trench
24 location
25 B
26 D
27 B
28 D
29 C
30 D
31 G
32 E
33 C
34 F
35 B
36 A
37 C
38 A
39 B
40 C
25&26 IN EITHER ORDER: B,D
If you score: 1–17 unlikely;18–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. FALSE

2. FALSE

3. NOT GIVEN

4. TRUE

5. TRUE

6. FALSE

7. TRUE

8. violent

9. tool

10. meat

11. photographer

12. game

13. frustration

14. iv

15. vii

16. ii

17. v

18. i

19. viii

20. vi

21. city

22. priests

23. trench

24. location

25. B / D

26. B / D

27. B

28. D

29. C

30. D

31. G

32. E

33. C

34. F

35. B

36. A

37. C

38. A

39. B

40. C

## A 类写作

### Writing material: c16-t1-w-1

One unnamed country1920/1940/1960/1980/2000/2019. Approximate appliance ownership percentages: washing machine40/60/70/65/70/75; refrigerator0/55/90/100/100/100; vacuum cleaner30/50/70/90/100/100. Refrigerators universal by1980, vacuums by2000; washing machines rise overall with1980dip and remain lowest finally. Weekly housework HOURS PER HOUSEHOLD roughly50/35/20/15/15/10. Footnote defines housework as washing clothes,preparing meals,cleaning. Both charts different units; no country name or proof of causality supplied. All unlabelled readings approximate.



### Writing material: c16-t1-w-2

Explain reasons for interest in the history of one’s house/building and practical research methods. No evaluation of positive/negative development explicitly required.



## 口语
