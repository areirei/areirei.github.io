# 剑雅 16 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/d0488cf4fb3ecf55e0bc851fd0f0d929a19e7fbd5ef2aa46128c9b6e08208d68.jpg; PDF page 10; full -->

```text
LISTENING
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Children’s Engineering Workshops
Tiny Engineers (ages 4–5)
Activities
• Create a cover for an (1) __________ so they can drop it from a height without breaking it.
• Take part in a competition to build the tallest (2) __________.
• Make a (3) __________ powered by a balloon.
Junior Engineers (ages 6–8)
Activities:
• Build model cars, trucks and (4) __________ and learn how to program them so they can move.
• Take part in a competition to build the longest (5) __________ using card and wood.
• Create a short (6) __________ with special software.
• Build, (7) __________ and program a humanoid robot.
Cost for a five-week block: £50
Held on (8) __________ from 10 am to 11 am
Location
Building 10A, (9) __________ Industrial Estate, Grasford
Plenty of (10) __________ is available.
```

[Original question page](assets/d0488cf4fb3ecf55e0bc851fd0f0d929a19e7fbd5ef2aa46128c9b6e08208d68.jpg)

### Part 2

<!-- Source: /api/assets/be79587f9b8462a8cf5e09b0736fa365af23fc70049056ccfe3cf9347049dc81.jpg; PDF page 11; full -->

```text
Listening
PART 2 Questions 11-20
Questions 11-14
Choose the correct letter, A, B or C.




11 Stevenson’s was founded in
A 1923.
B 1924.
C 1926.
12 Originally, Stevenson’s manufactured goods for
A the healthcare industry.
B the automotive industry.
C the machine tools industry.
13 What does the speaker say about the company premises?
A The company has recently moved.
B The company has no plans to move.
C The company is going to move shortly.
14 The programme for the work experience group includes
A time to do research.
B meetings with a teacher.
C talks by staff.
```

[Original question page](assets/be79587f9b8462a8cf5e09b0736fa365af23fc70049056ccfe3cf9347049dc81.jpg)

<!-- Source: /api/assets/c9a452b46111b0ee3b62d054977578a223088b50c2ad1181db50490774a0ed55.jpg; PDF page 12; full -->

```text
Questions 15–20
Label the map below. Write the correct letter, A–J, next to Questions 15–20.
Plan of Stevenson’s site
[Original A–J site plan retained with factory, reception, main/access roads and open courtyard. Use the plan to answer.]
15 coffee room __________
16 warehouse __________
17 staff canteen __________
18 meeting room __________
19 human resources __________
20 boardroom __________
```

[Original question page](assets/c9a452b46111b0ee3b62d054977578a223088b50c2ad1181db50490774a0ed55.jpg)

![Original figure](assets/c9a452b46111b0ee3b62d054977578a223088b50c2ad1181db50490774a0ed55.jpg)

### Part 3

<!-- Source: /api/assets/889a5dc8c39501daf399c9e555a365bb7046237db347d39db40dda44f743215b.jpg; PDF page 13; full -->

```text
Listening
PART 3 Questions 21-30
Questions 21 and 22
Choose TWO letters, A–E.
Which TWO parts of the introductory stage to their art projects do Jess and Tom agree
were useful?
A the Bird Park visit
B the workshop sessions
C the Natural History Museum visit
D the projects done in previous years
E the handouts with research sources
Questions 23 and 24
Choose TWO letters, A-E.
In which TWO ways do both Jess and Tom decide to change their proposals?
A by giving a rationale for their action plans
B by being less specific about the outcome
C by adding a video diary presentation
D by providing a timeline and a mind map
E by making their notes more evaluative
```

[Original question page](assets/889a5dc8c39501daf399c9e555a365bb7046237db347d39db40dda44f743215b.jpg)

<!-- Source: /api/assets/12fa1d7bd73e4113ea310a381316f3229640ea89c10c6deb7c5e1d657146c924.jpg; PDF page 14; full -->

```text
Questions 25–30
Which personal meaning do the students decide to give to each of the following pictures?
Choose SIX answers from the box and write the correct letter, A–H, next to Questions 25–30.
Personal meanings
A a childhood memory
B hope for the future
C fast movement
D a potential threat
E the power of colour
F the continuity of life
G protection of nature
H a confused attitude to nature
Pictures
25 Falcon (Landseer) __________
26 Fish hawk (Audubon) __________
27 Kingfisher (van Gogh) __________
28 Portrait of William Wells __________
29 Vairumati (Gauguin) __________
30 Portrait of Giovanni de Medici __________
```

[Original question page](assets/12fa1d7bd73e4113ea310a381316f3229640ea89c10c6deb7c5e1d657146c924.jpg)

### Part 4

<!-- Source: /api/assets/574ee89924c94a9b2291af7d38c368b1a9b1a314aac0fa8cb54f9efe8d0ce2bc.jpg; PDF page 15; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Stoicism
Stoicism is still relevant today because of its (31) __________ appeal.
Ancient Stoics
• Stoicism was founded over 2,000 years ago in Greece.
• The Stoics’ ideas are surprisingly well known, despite not being intended for (32) __________.
Stoic principles
• Happiness could be achieved by leading a virtuous life.
• Controlling emotions was essential.
• Epictetus said that external events cannot be controlled but the (33) __________ people make in response can be controlled.
• A Stoic is someone who has a different view on experiences which others would consider as (34) __________.
The influence of Stoicism
• George Washington organised a (35) __________ about Cato to motivate his men.
• The French artist Delacroix was a Stoic.
• Adam Smith’s ideas on (36) __________ were influenced by Stoicism.
• Some of today’s political leaders are inspired by the Stoics.
• Cognitive Behaviour Therapy (CBT)
– the treatment for (37) __________ is based on ideas from Stoicism
– people learn to base their thinking on (38) __________.
• In business, people benefit from Stoicism by identifying obstacles as (39) __________.
Relevance of Stoicism
• It requires a lot of (40) __________ but Stoicism can help people to lead a good life.
• It teaches people that having a strong character is more important than anything else.
```

[Original question page](assets/574ee89924c94a9b2291af7d38c368b1a9b1a314aac0fa8cb54f9efe8d0ce2bc.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/c649f207b77115bf671a66eb12f32702edbfcb4222397400bc78b04c49ba7d6f.jpg; PDF page 16; full -->

```text
Test 1
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Why we need to protect polar bears
Polar bears are being increasingly threatened by the effects of climate change, but their disappearance
could have far-reaching consequences. They are uniquely adapted to the extreme conditions of
the Arctic Circle, where temperatures can reach −40°C. One reason for this is that they have up to
11 centimetres of fat underneath their skin. Humans with comparative levels of adipose tissue would
be considered obese and would be likely to suffer from diabetes and heart disease. Yet the polar bear
experiences no such consequences.
A 2014 study by Shi Ping Liu and colleagues sheds light on this mystery. They compared the genetic
structure of polar bears with that of their closest relatives from a warmer climate, the brown bears.
This allowed them to determine the genes that have allowed polar bears to survive in one of the
toughest environments on Earth. Liu and his colleagues found the polar bears had a gene known as
APoB, which reduces levels of low-density lipoproteins (LDLs) — a form of ‘bad’ cholesterol. In
humans, mutations of this gene are associated with increased risk of heart disease. Polar bears may
therefore be an important study model to understand heart disease in humans.
The genome of the polar bear may also provide the solution for another condition, one that particularly
affects our older generation: osteoporosis. This is a disease where bones show reduced density, usually
caused by insufficient exercise, reduced calcium intake or food starvation. Bone tissue is constantly
being remodelled, meaning that bone is added or removed, depending on nutrient availability and the
stress that the bone is under. Female polar bears, however, undergo extreme conditions during every
pregnancy. Once autumn comes around, these females will dig maternity dens in the snow and will
remain there throughout the winter, both before and after the birth of their cubs. This process results
in about six months of fasting, where the female bears have to keep themselves and their cubs alive,
depleting their own calcium and calorie reserves. Despite this, their bones remain strong and dense.
Physiologists Alanda Lennox and Allen Goodship found an explanation for this paradox in 2008.
They discovered that pregnant bears were able to increase the density of their bones before they
started to build their dens. In addition, six months later, when they finally emerged from the den with
their cubs, there was no evidence of significant loss of bone density. Hibernating brown bears do not
have this capacity and must therefore resort to major bone reformation in the following spring. If the
mechanism of bone remodelling in polar bears can be understood, many bedridden humans, and even
astronauts, could potentially benefit.
16
```

[Original question page](assets/c649f207b77115bf671a66eb12f32702edbfcb4222397400bc78b04c49ba7d6f.jpg)

<!-- Source: /api/assets/f9e7409f8776d9b2af6e977d1b7c860d3760ecff8199785c01837507411c1bac.jpg; PDF page 17; full -->

```text
Reading
The medical benefits of the polar bear for humanity certainly have their importance in our
conservation efforts, but these should not be the only factors taken into consideration. We tend to
want to protect animals we think are intelligent and possess emotions, such as elephants and primates.
Bears, on the other hand, seem to be perceived as stupid and in many cases violent. And yet anecdotal
evidence from the field challenges those assumptions, suggesting for example that polar bears have
good problem-solving abilities. A male bear called GoGo in Tennoji Zoo, Osaka, has even been
observed making use of a tool to manipulate his environment. The bear used a tree branch on multiple
occasions to dislodge a piece of meat hung out of his reach. Problem-solving ability has also been
witnessed in wild polar bears, although not as obviously as with GoGo. A calculated move by a male
bear involved running and jumping onto barrels in an attempt to get to a photographer standing on a
platform four metres high.
In other studies, such as one by Alison Ames in 2008, polar bears showed deliberate and focussed
manipulation. For example, Ames observed bears putting objects in piles and then knocking them over
in what appeared to be a game. The study demonstrates that bears are capable of agile and thought-out
behaviours. These examples suggest bears have greater creativity and problem-solving abilities than
previously thought.
As for emotions, while the evidence is once again anecdotal, many bears have been seen to hit out
at ice and snow — seemingly out of frustration — when they have just missed out on a kill. Moreover,
polar bears can form unusual relationships with other species, including playing with the dogs used
to pull sleds in the Arctic. Remarkably, one hand-raised polar bear called Agee has formed a close
relationship with her owner Mark Dumas to the point where they even swim together. This is even
more astonishing since polar bears are known to actively hunt humans in the wild.
If climate change were to lead to their extinction, this would mean not only the loss of potential
breakthroughs in human medicine, but more importantly, the disappearance of an intelligent,
majestic animal.
17
```

[Original question page](assets/f9e7409f8776d9b2af6e977d1b7c860d3760ecff8199785c01837507411c1bac.jpg)

<!-- Source: /api/assets/7972ca36e6dd604bce38d1be20c48986cf51de9040b0758920171420cc3e9ceb.jpg; PDF page 18; full -->

```text
Test 1
Questions 1-7
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-7 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 Polar bears suffer from various health problems due to the build-up of fat under
their skin.
2 The study done by Liu and his colleagues compared different groups of polar bears.
3 Liu and colleagues were the first researchers to compare polar bears and brown
bears genetically.
4 Polar bears are able to control their levels of ‘bad’ cholesterol by genetic means.
5 Female polar bears are able to survive for about six months without food.
6 It was found that the bones of female polar bears were very weak when they came
out of their dens in spring.
7 The polar bear’s mechanism for increasing bone density could also be used by
people one day.
18
```

[Original question page](assets/7972ca36e6dd604bce38d1be20c48986cf51de9040b0758920171420cc3e9ceb.jpg)

<!-- Source: /api/assets/524888cc9f3a78d759ed1cf546fffd4748065c460cd5edb2fa0041b6856f208c.jpg; PDF page 19; full -->

```text
Questions 8–13
Complete the table below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 8–13 on your answer sheet.
Reasons why polar bears should be protected
People think of bears as unintelligent and (8) __________.
However, this may not be correct. For example:
• In Tennoji Zoo, a bear has been seen using a branch as a (9) __________. This allowed him to knock down some (10) __________.
• A wild polar bear worked out a method of reaching a platform where a (11) __________ was located.
• Polar bears have displayed behaviour such as conscious manipulation of objects and activity similar to a (12) __________.
Bears may also display emotions. For example:
• They may make movements suggesting (13) __________ if disappointed when hunting.
• They may form relationships with other species.
```

[Original question page](assets/524888cc9f3a78d759ed1cf546fffd4748065c460cd5edb2fa0041b6856f208c.jpg)

<!-- Source: /api/assets/ea503e90d7ddabd2fce10eb15cf46922c7dd66dcb21b106b63d11308341c46c0.jpg; PDF page 20; full -->

```text
Test 1
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 on pages 21 and 22.
Questions 14-20
Reading Passage 2 has seven paragraphs, A-G.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i-ix, in boxes 14-20 on your answer sheet.
List of Headings
i The areas and artefacts within the pyramid itself
ii A difficult task for those involved
iii A king who saved his people
iv A single certainty among other less definite facts
v An overview of the external buildings and areas
vi A pyramid design that others copied
vii An idea for changing the design of burial structures
viii An incredible experience despite the few remains
ix The answers to some unexpected questions
14 Paragraph A
15 Paragraph B
16 Paragraph C
17 Paragraph D
18 Paragraph E
19 Paragraph F
20 Paragraph G
20
```

[Original question page](assets/ea503e90d7ddabd2fce10eb15cf46922c7dd66dcb21b106b63d11308341c46c0.jpg)

<!-- Source: /api/assets/e44282d3cc6e2e49dc4f4085835954cc77194871a6366c54db09f261c3acf52f.jpg; PDF page 21; full -->

```text
Reading
The Step Pyramid of Djoser
A The pyramids are the most famous monuments of ancient Egypt and still hold
enormous interest for people in the present day. These grand, impressive tributes to
the memory of the Egyptian kings have become linked with the country even though
other cultures, such as the Chinese and Mayan, also built pyramids. The evolution of
the pyramid form has been written and argued about for centuries. However, there
is no question that, as far as Egypt is concerned, it began with one monument to one
king designed by one brilliant architect: the Step Pyramid of Djoser at Saqqara.
B Djoser was the first king of the Third Dynasty of Egypt and the first to build in
stone. Prior to Djoser’s reign, tombs were rectangular monuments made of dried clay
brick, which covered underground passages where the deceased person was buried.
For reasons which remain unclear, Djoser’s main official, whose name was Imhotep,
conceived of building a taller, more impressive tomb for his king by stacking stone
slabs on top of one another, progressively making them smaller, to form the shape
now known as the Step Pyramid. Djoser is thought to have reigned for 19 years, but
some historians and scholars attribute a much longer time for his rule, owing to the
number and size of the monuments he built.
C The Step Pyramid has been thoroughly examined and investigated over the
last century, and it is now known that the building process went through many
different stages. Historian Marc Van de Mieroop comments on this, writing ‘Much
experimentation was involved, which is especially clear in the construction of the
pyramid in the center of the complex. It had several plans ... before it became the
first Step Pyramid in history, piling six levels on top of one another ... The weight
of the enormous mass was a challenge for the builders, who placed the stones at an
inward incline in order to prevent the monument breaking up.’
D When finally completed, the Step Pyramid rose 62 meters high and was the tallest
structure of its time. The complex in which it was built was the size of a city in
ancient Egypt and included a temple, courtyards, shrines, and living quarters for the
priests. It covered a region of 16 hectares and was surrounded by a wall 10.5 meters
high. The wall had 13 false doors cut into it with only one true entrance cut into the
south-east corner; the entire wall was then ringed by a trench 750 meters long and
40 meters wide. The false doors and the trench were incorporated into the complex
to discourage unwanted visitors. If someone wished to enter, he or she would have
needed to know in advance how to find the location of the true opening in the wall.
Djoser was so proud of his accomplishment that he broke the tradition of having
only his own name on the monument and had Imhotep’s name carved on it as well.
21
```

[Original question page](assets/e44282d3cc6e2e49dc4f4085835954cc77194871a6366c54db09f261c3acf52f.jpg)

<!-- Source: /api/assets/06735d1e232f3a256c6312cd6586ed9103f298ad0c7be67bde5d2e953ca7729b.jpg; PDF page 22; full -->

```text
Test 1

22
E The burial chamber of the tomb, where the king’s body was laid to rest, was dug
beneath the base of the pyramid, surrounded by a vast maze of long tunnels that
had rooms off them to discourage robbers. One of the most mysterious discoveries
found inside the pyramid was a large number of stone vessels. Over 40,000 of
these vessels, of various forms and shapes, were discovered in storerooms off the
pyramid’s underground passages. They are inscribed with the names of rulers from
the First and Second Dynasties of Egypt and made from different kinds of stone.
There is no agreement among scholars and archaeologists on why the vessels
were placed in the tomb of Djoser or what they were supposed to represent. The
archaeologist Jean-Philippe Lauer, who excavated most of the pyramid and complex,
believes they were originally stored and then given a ‘proper burial’ by Djoser in his
pyramid to honor his predecessors. There are other historians, however, who claim
the vessels were dumped into the shafts as yet another attempt to prevent grave
robbers from getting to the king’s burial chamber.
F Unfortunately, all of the precautions and intricate design of the underground network
did not prevent ancient robbers from finding a way in. Djoser’s grave goods, and
even his body, were stolen at some point in the past and all archaeologists found
were a small number of his valuables overlooked by the thieves. There was enough
left throughout the pyramid and its complex, however, to astonish and amaze the
archaeologists who excavated it.
G Egyptologist Miroslav Verner writes, ‘Few monuments hold a place in human
history as significant as that of the Step Pyramid in Saqqara ... It can be said
without exaggeration that this pyramid complex constitutes a milestone in the
evolution of monumental stone architecture in Egypt and in the world as a whole.’
The Step Pyramid was a revolutionary advance in architecture and became the
archetype which all the other great pyramid builders of Egypt would follow.
```

[Original question page](assets/06735d1e232f3a256c6312cd6586ed9103f298ad0c7be67bde5d2e953ca7729b.jpg)

<!-- Source: /api/assets/f3914fbcc3f7db7d75e69e8e5b96df950a62baef19a24968b3bfb8e12cff5f8d.jpg; PDF page 23; full -->

```text
Questions 21–24
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 21–24 on your answer sheet.
The Step Pyramid of Djoser
The complex that includes the Step Pyramid and its surroundings is considered to be as big as an Egyptian (21) __________ of the past. The area outside the pyramid included accommodation that was occupied by (22) __________, along with many other buildings and features.
A wall ran around the outside of the complex and a number of false entrances were built into this. In addition, a long (23) __________ encircled the wall. As a result, any visitors who had not been invited were cleverly prevented from entering the pyramid grounds unless they knew the (24) __________ of the real entrance.
Questions 25–26
Choose TWO letters, A–E. Write the correct letters in boxes 25 and 26 on your answer sheet.
Which TWO of the following points does the writer make about King Djoser?
A Initially he had to be persuaded to build in stone rather than clay.
B There is disagreement concerning the length of his reign.
C He failed to appreciate Imhotep’s part in the design of the Step Pyramid.
D A few of his possessions were still in his tomb when archaeologists found it.
E He criticised the design and construction of other pyramids in Egypt.
```

[Original question page](assets/f3914fbcc3f7db7d75e69e8e5b96df950a62baef19a24968b3bfb8e12cff5f8d.jpg)

<!-- Source: /api/assets/f75d23710622ad94a8e2f08a88409ad650779e3e20894080e9a6f3bcb7991772.jpg; PDF page 24; full -->

```text
Test 1
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
The future of work
According to a leading business consultancy, 3—14% of the global workforce will need to switch
to a different occupation within the next 10-15 years, and all workers will need to adapt as
their occupations evolve alongside increasingly capable machines. Automation — or ‘embodied
artificial intelligence’ (AI) — is one aspect of the disruptive effects of technology on the labour
market. ‘Disembodied AI’, like the algorithms running in our smartphones, is another.
Dr Stella Pachidi from Cambridge Judge Business School believes that some of the most
fundamental changes are happening as a result of the ‘algorithmication’ of jobs that are dependent
on data rather than on production — the so-called knowledge economy. Algorithms are capable of
learning from data to undertake tasks that previously needed human judgement, such as reading
legal contracts, analysing medical scans and gathering market intelligence.
‘In many cases, they can outperform humans,’ says Pachidi. ‘Organisations are attracted to
using algorithms because they want to make choices based on what they consider is “perfect
information”, as well as to reduce costs and enhance productivity.”
‘But these enhancements are not without consequences,’ says Pachidi. ‘If routine cognitive tasks
are taken over by AI, how do professions develop their future experts?’ she asks. ‘One way of
learning about a job is “legitimate peripheral participation” — a novice stands next to experts and
learns by observation. If this isn’t happening, then you need to find new ways to learn.”
Another issue is the extent to which the technology influences or even controls the workforce.
For over two years, Pachidi monitored a telecommunications company. “The way telecoms
salespeople work is through personal and frequent contact with clients, using the benefit of
experience to assess a situation and reach a decision. However, the company had started using
a[n] ... algorithm that defined when account managers should contact certain customers about
which kinds of campaigns and what to offer them.’
The algorithm — usually built by external designers — often becomes the keeper of knowledge,
she explains. In cases like this, Pachidi believes, a short-sighted view begins to creep into
working practices whereby workers learn through the ‘algorithm’s eyes’ and become dependent
on its instructions. Alternative explorations — where experimentation and human instinct lead to
progress and new ideas — are effectively discouraged.
Pachidi and colleagues even observed people developing strategies to make the algorithm work
to their own advantage. ‘We are seeing cases where workers feed the algorithm with false data to
reach their targets,’ she reports.
24
```

[Original question page](assets/f75d23710622ad94a8e2f08a88409ad650779e3e20894080e9a6f3bcb7991772.jpg)

<!-- Source: /api/assets/1d192dc119aaeb7c8abe84faf10085ebad6dd98421cd82237635834174251a58.jpg; PDF page 25; full -->

```text
Reading
It’s scenarios like these that many researchers are working to avoid. Their objective is to make AI
technologies more trustworthy and transparent, so that organisations and individuals understand
how AI decisions are made. In the meantime, says Pachidi, ‘We need to make sure we fully
understand the dilemmas that this new world raises regarding expertise, occupational boundaries
and control.’
Economist Professor Hamish Low believes that the future of work will involve major transitions
across the whole life course for everyone: ‘The traditional trajectory of full-time education
followed by full-time work followed by a pensioned retirement is a thing of the past,’ says Low.
Instead, he envisages a multistage employment life: one where retraining happens across the life
course, and where multiple jobs and no job happen by choice at different stages.
On the subject of job losses, Low believes the predictions are founded on a fallacy: ‘It assumes
that the number of jobs is fixed. If in 30 years, half of 100 jobs are being carried out by robots,
that doesn’t mean we are left with just 50 jobs for humans. The number of jobs will increase: we
would expect there to be 150 jobs.’
Dr Ewan McGaughey, at Cambridge’s Centre for Business Research and King’s College London,
agrees that ‘apocalyptic’ views about the future of work are misguided. ‘It’s the laws that
restrict the supply of capital to the job market, not the advent of new technologies that causes
unemployment.’
His recently published research answers the question of whether automation, AI and robotics will
mean a ‘jobless future’ by looking at the causes of unemployment. ‘History is clear that change
can mean redundancies. But social policies can tackle this through retraining and redeployment.’
He adds: ‘If there is going to be change to jobs as a result of AI and robotics then I'd like to see
governments seizing the opportunity to improve policy to enforce good job security. We can
“reprogramme” the law to prepare for a fairer future of work and leisure.” McGaughey’s findings
are a call to arms to leaders of organisations, governments and banks to pre-empt the coming
changes with bold new policies that guarantee full employment, fair incomes and a thriving
economic democracy.
‘The promises of these new technologies are astounding. They deliver humankind the capacity
to live in a way that nobody could have once imagined,’ he adds. ‘Just as the industrial revolution
brought people past subsistence agriculture, and the corporate revolution enabled mass
production, a third revolution has been pronounced. But it will not only be one of technology. The
next revolution will be social.’
25
```

[Original question page](assets/1d192dc119aaeb7c8abe84faf10085ebad6dd98421cd82237635834174251a58.jpg)

<!-- Source: /api/assets/8d16f7597f80bf1223253dc8ac184f67e4aadd6bfc6077a2c7aae30a58cac3c5.jpg; PDF page 26; full -->

```text
Questions 27–30
Choose the correct letter, A, B, C or D. Write the correct letter in boxes 27–30 on your answer sheet.
27 The first paragraph tells us about
A the kinds of jobs that will be most affected by the growth of AI.
B the extent to which AI will alter the nature of the work that people do.
C the proportion of the world’s labour force who will have jobs in AI in the future.
D the difference between ways that embodied and disembodied AI will impact on workers.
28 According to the second paragraph, what is Stella Pachidi’s view of the ‘knowledge economy’?
A It is having an influence on the number of jobs available.
B It is changing people’s attitudes towards their occupations.
C It is the main reason why the production sector is declining.
D It is a key factor driving current developments in the workplace.
29 What did Pachidi observe at the telecommunications company?
A staff disagreeing with the recommendations of AI
B staff feeling resentful about the intrusion of AI in their work
C staff making sure that AI produces the results that they want
D staff allowing AI to carry out tasks they ought to do themselves
30 In his recently published research, Ewan McGaughey
A challenges the idea that redundancy is a negative thing.
B shows the profound effect of mass unemployment on society.
C highlights some differences between past and future job losses.
D illustrates how changes in the job market can be successfully handled.
```

[Original question page](assets/8d16f7597f80bf1223253dc8ac184f67e4aadd6bfc6077a2c7aae30a58cac3c5.jpg)

<!-- Source: /api/assets/221531d6731b171b1c148203189d766974086d487f0082159f3479856fdce17b.jpg; PDF page 27; full -->

```text
Questions 31–34
Complete the summary using the list of words, A–G, below.
Write the correct letter, A–G, in boxes 31–34 on your answer sheet.
The ‘algorithmication’ of jobs
Stella Pachidi of Cambridge Judge Business School has been focusing on the ‘algorithmication’ of jobs which rely not on production but on (31) __________.
While monitoring a telecommunications company, Pachidi observed a growing (32) __________ on the recommendations made by AI, as workers begin to learn through the ‘algorithm’s eyes’. Meanwhile, staff are deterred from experimenting and using their own (33) __________, and are therefore prevented from achieving innovation.
To avoid the kind of situations which Pachidi observed, researchers are trying to make AI’s decision-making process easier to comprehend, and to increase users’ (34) __________ with regard to the technology.
A pressure
B satisfaction
C intuition
D promotion
E reliance
F confidence
G information
```

[Original question page](assets/221531d6731b171b1c148203189d766974086d487f0082159f3479856fdce17b.jpg)

<!-- Source: /api/assets/c2ba6b981facc90de1805bf1b03335a878c038d1f99df90d7e3bcff1a6245473.jpg; PDF page 28; full -->

```text
Test 1
Questions 35-40
Look at the following statements (Questions 35-40) and the list of people below.
Match each statement with the correct person, A, B or C.
Write the correct letter, A, B or C, in boxes 35-40 on your answer sheet.
NB You may use any letter more than once.
35 Greater levels of automation will not result in lower employment.
36 There are several reasons why AI is appealing to businesses.
37 AI's potential to transform people’s lives has parallels with major cultural shifts
which occurred in previous eras.
38 It is important to be aware of the range of problems that AI causes.
39 People are going to follow a less conventional career path than in the past.
40 Authorities should take measures to ensure that there will be adequately paid work
for everyone.
List of people
A  Stella Pachidi
B Hamish Low
C Ewan McGaughey
28 =>|M p. 122
```

[Original question page](assets/c2ba6b981facc90de1805bf1b03335a878c038d1f99df90d7e3bcff1a6245473.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/b24a240e6c9818f771b12667092c9d125a971093fb077413f8205390d8f0d5f9.jpg; PDF page 29; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show the changes in ownership of electrical appliances and amount of time spent doing housework in households in one country between 1920 and 2019.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/b24a240e6c9818f771b12667092c9d125a971093fb077413f8205390d8f0d5f9.jpg)

![Original figure](assets/b24a240e6c9818f771b12667092c9d125a971093fb077413f8205390d8f0d5f9.jpg)

### Task 2

<!-- Source: /api/assets/8b3c5f2323a93ef2c795274bcb7d90bd1aaf227f87de88c10c496abb1de2ec85.jpg; PDF page 30; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In some countries, more and more people are becoming interested in finding out about the history of the house or building they live in.

What are the reasons for this?

How can people research this?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/8b3c5f2323a93ef2c795274bcb7d90bd1aaf227f87de88c10c496abb1de2ec85.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/df3d1e0089c0c8158e5dc0f0641f3984798dd1bc2ed4bbcedace32ad33d056a4.jpg; PDF page 31; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
People you study/work with
Who do you spend most time studying/working with? [Why?]
What kinds of things do you study/work on with other people? [Why?]
Are there times when you study/work better by yourself? [Why/Why not?]
Is it important to like the people you study/work with? [Why/Why not?]
PART 2
Describe a tourist attraction you enjoyed visiting.
You should say:
what this tourist attraction is
when and why you visited it
what you did there
and explain why you enjoyed visiting this tourist attraction.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Different kinds of tourist attractions
Example questions:
What are the most popular tourist attractions in your country?
How do the types of tourist attractions that younger people like to visit compare with
those that older people like to visit?
Do you agree that some tourist attractions (e.g. national museums/galleries) should be
free to visit?
The importance of international tourism
Example questions:
Why is tourism important to a country?
What are the benefits to individuals of visiting another country as tourists?
How necessary is it for tourists to learn the language of the country they're visiting?
31
```

[Original question page](assets/df3d1e0089c0c8158e5dc0f0641f3984798dd1bc2ed4bbcedace32ad33d056a4.jpg)

### Part 2

<!-- Source: /api/assets/df3d1e0089c0c8158e5dc0f0641f3984798dd1bc2ed4bbcedace32ad33d056a4.jpg; PDF page 31; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
People you study/work with
Who do you spend most time studying/working with? [Why?]
What kinds of things do you study/work on with other people? [Why?]
Are there times when you study/work better by yourself? [Why/Why not?]
Is it important to like the people you study/work with? [Why/Why not?]
PART 2
Describe a tourist attraction you enjoyed visiting.
You should say:
what this tourist attraction is
when and why you visited it
what you did there
and explain why you enjoyed visiting this tourist attraction.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Different kinds of tourist attractions
Example questions:
What are the most popular tourist attractions in your country?
How do the types of tourist attractions that younger people like to visit compare with
those that older people like to visit?
Do you agree that some tourist attractions (e.g. national museums/galleries) should be
free to visit?
The importance of international tourism
Example questions:
Why is tourism important to a country?
What are the benefits to individuals of visiting another country as tourists?
How necessary is it for tourists to learn the language of the country they're visiting?
31
```

[Original question page](assets/df3d1e0089c0c8158e5dc0f0641f3984798dd1bc2ed4bbcedace32ad33d056a4.jpg)

### Part 3

<!-- Source: /api/assets/df3d1e0089c0c8158e5dc0f0641f3984798dd1bc2ed4bbcedace32ad33d056a4.jpg; PDF page 31; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
People you study/work with
Who do you spend most time studying/working with? [Why?]
What kinds of things do you study/work on with other people? [Why?]
Are there times when you study/work better by yourself? [Why/Why not?]
Is it important to like the people you study/work with? [Why/Why not?]
PART 2
Describe a tourist attraction you enjoyed visiting.
You should say:
what this tourist attraction is
when and why you visited it
what you did there
and explain why you enjoyed visiting this tourist attraction.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Different kinds of tourist attractions
Example questions:
What are the most popular tourist attractions in your country?
How do the types of tourist attractions that younger people like to visit compare with
those that older people like to visit?
Do you agree that some tourist attractions (e.g. national museums/galleries) should be
free to visit?
The importance of international tourism
Example questions:
Why is tourism important to a country?
What are the benefits to individuals of visiting another country as tourists?
How necessary is it for tourists to learn the language of the country they're visiting?
31
```

[Original question page](assets/df3d1e0089c0c8158e5dc0f0641f3984798dd1bc2ed4bbcedace32ad33d056a4.jpg)
