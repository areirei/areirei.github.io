# 剑雅 18 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 123

TEST 2 LISTENING
1 training
2 discount
3 taxi
4 service
5 English
6 Wivenhoe
7 equipment
8 9.75
9 deliveries
10 Sunday
11 B
12 E
13 B
14 C
15 G
16 C
17 D
18 B
19 H
20 A
21 C
22 A
23 B
24 B
25 A
26 B
27 D
28 A
29 C
30 F
31 convenient
32 suits
33 tailor
34 profession
35 visible
36 string(s)
37 waist(s)
38 perfume
39 image
40 handbag
11&12 IN EITHER ORDER: B,E
13&14 IN EITHER ORDER: B,C
25&26 IN EITHER ORDER: A,B
If you score: 0–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. training

2. discount

3. taxi

4. service

5. English

6. Wivenhoe

7. equipment

8. 9.75 / 9:75

9. deliveries

10. Sunday

### Part 2 · source page 123

TEST 2 LISTENING
1 training
2 discount
3 taxi
4 service
5 English
6 Wivenhoe
7 equipment
8 9.75
9 deliveries
10 Sunday
11 B
12 E
13 B
14 C
15 G
16 C
17 D
18 B
19 H
20 A
21 C
22 A
23 B
24 B
25 A
26 B
27 D
28 A
29 C
30 F
31 convenient
32 suits
33 tailor
34 profession
35 visible
36 string(s)
37 waist(s)
38 perfume
39 image
40 handbag
11&12 IN EITHER ORDER: B,E
13&14 IN EITHER ORDER: B,C
25&26 IN EITHER ORDER: A,B
If you score: 0–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B / E

12. B / E

13. B / C

14. B / C

15. G

16. C

17. D

18. B

19. H

20. A

### Part 3 · source page 123

TEST 2 LISTENING
1 training
2 discount
3 taxi
4 service
5 English
6 Wivenhoe
7 equipment
8 9.75
9 deliveries
10 Sunday
11 B
12 E
13 B
14 C
15 G
16 C
17 D
18 B
19 H
20 A
21 C
22 A
23 B
24 B
25 A
26 B
27 D
28 A
29 C
30 F
31 convenient
32 suits
33 tailor
34 profession
35 visible
36 string(s)
37 waist(s)
38 perfume
39 image
40 handbag
11&12 IN EITHER ORDER: B,E
13&14 IN EITHER ORDER: B,C
25&26 IN EITHER ORDER: A,B
If you score: 0–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. C

22. A

23. B

24. B

25. A / B

26. A / B

27. D

28. A

29. C

30. F

### Part 4 · source page 123

TEST 2 LISTENING
1 training
2 discount
3 taxi
4 service
5 English
6 Wivenhoe
7 equipment
8 9.75
9 deliveries
10 Sunday
11 B
12 E
13 B
14 C
15 G
16 C
17 D
18 B
19 H
20 A
21 C
22 A
23 B
24 B
25 A
26 B
27 D
28 A
29 C
30 F
31 convenient
32 suits
33 tailor
34 profession
35 visible
36 string(s)
37 waist(s)
38 perfume
39 image
40 handbag
11&12 IN EITHER ORDER: B,E
13&14 IN EITHER ORDER: B,C
25&26 IN EITHER ORDER: A,B
If you score: 0–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. convenient

32. suits

33. tailor

34. profession

35. visible

36. string / strings

37. waist / waists

38. perfume

39. image

40. handbag

## A 类阅读

### Academic Reading · source page 124

TEST 2 READING
1 (deer) antlers
2 (timber) posts
3 tree trunks
4 oxen
5 glaciers
6 druids
7 burial
8 calendar
9 TRUE
10 FALSE
11 FALSE
12 TRUE
13 NOT GIVEN
14 C
15 A
16 B
17 D
18 C
19 D
20 YES
21 NOT GIVEN
22 NO
23 YES
24 C
25 A
26 E
27 NOT GIVEN
28 NOT GIVEN
29 TRUE
30 FALSE
31 TRUE
32 NOT GIVEN
33 FALSE
34 transport
35 staircases
36 engineering
37 rule
38 Roman
39 Paris
40 outwards
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. antlers / deer antlers

2. posts / timber posts

3. tree trunks

4. oxen

5. glaciers

6. druids

7. burial

8. calendar

9. TRUE

10. FALSE

11. FALSE

12. TRUE

13. NOT GIVEN

14. C

15. A

16. B

17. D

18. C

19. D

20. YES

21. NOT GIVEN

22. NO

23. YES

24. C

25. A

26. E

27. NOT GIVEN

28. NOT GIVEN

29. TRUE

30. FALSE

31. TRUE

32. NOT GIVEN

33. FALSE

34. transport

35. staircases

36. engineering

37. rule

38. Roman

39. Paris

40. outwards

## A 类写作

### Writing material: c18-t2-w-1

Number of US households in MILLIONS; annual income bands in dollars:<25,000;25,000–49,999;50,000–74,999;75,000–99,999;100,000or more. Approximate counts by band:2007 25/27/21/14/29;2011 29/30/21/14/28;2015 28/29/21/15/33. Highest-income band largest2007/2015;25–49,999largest2011.75–99,999smallest throughout;middle50–74,999roughly stable. Highest band dips then rises strongly, low bands rise then edge down. These are counts not percentages or average salaries; unlabelled readings approximate. Household totals differ by year.



### Writing material: c18-t2-w-2

Discuss studying additional subjects versus focusing all time on qualification, with own opinion. Not a comparison of university versus vocational education.



## 口语
