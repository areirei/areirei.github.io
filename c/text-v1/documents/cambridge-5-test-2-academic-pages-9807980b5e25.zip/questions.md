# 剑雅 5 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/7e5affbcca26dd09ef3fee2a87be4357a64c6594f4d9f134d56c9e043974e965.jpg; PDF page 33; full -->

```text
LISTENING SECTION1 Questions1–10
Complete the notes below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
LIBRARY INFORMATION
Example: Minimum joining age—18years
For registration,must take two (1) __________ and two forms of I.D.e.g.driving licence,(2) __________.
Cost to join per year(without current student card):(3) £__________
Number of items allowed:(members of public)(4) __________
Loan times:four weeks
Fines start at(5) £__________
Computers can be booked up to(6) __________ hours in advance
Library holds most national papers,all(7) __________,and magazines
Need(8) __________ to use photocopier
Creative Writing class:tutor is John(9) __________;held on(10) __________ evenings
```

[Original question page](assets/7e5affbcca26dd09ef3fee2a87be4357a64c6594f4d9f134d56c9e043974e965.jpg)

### Part 2

<!-- Source: /api/assets/24b49be04cf32345a7ff723c06f99a464e0dd3bc88150be3d072bd65bf76420c.jpg; PDF page 34; full -->

```text
Listening 
SECTION 2 Questions 11-20 
Questions 11-15 
Choose the correct letter,. A, B or C 
BICYCLES FOR THE WORLD 
11 In 1993 Dan Pearman went to Ecuador 
A as a tourist guide. 
B as part of his studies. 
C as a voluntary worker. 
12 Dan's neighbour was successful in business because he 
A employed carpenters from the area . 
B was the most skilled craftsman in the town. 
C found it easy to reach customers . 
13 Dan says the charity relies on 
A getting enough bicycles to send regularly. 
B finding new areas which need the bicycles. 
C charging for the bicycles it sends abroad. 
14 What does Dan say about the town of Rivas? 
A It has received the greatest number of bikes. 
B It has almost as many bikes as Amsterdam. 
C Its economy has been totally transformed. 
15 What problem did the charity face in August 2000? 
A It couldn't meet its overheads. 
B It had to delay sending the bikes. 
C It was criticised in the British media . 
33
```

[Original question page](assets/24b49be04cf32345a7ff723c06f99a464e0dd3bc88150be3d072bd65bf76420c.jpg)

<!-- Source: /api/assets/94f18ef83c4c770dd8567aa366241cab79e01cf01810a237f2c87a05caff82e5.jpg; PDF page 35; full -->

```text
Test 2 
Questions 16 and 17 
Answer the questions below. 
Write NO MORE THAN ONE WORD OR A NUMBER for each answer. 
16 How much money did the charity receive when it won an award? 
17 What is the charity currently hoping to buy? 
Questions 18-20 
Choose THREE letters A-G 
Which THREE things can the general public do to help the charity Pedal Power? 
A organise a bicycle collection 
B repair the donated bikes 
C donate their unwanted tools 
D do voluntary work in its office 
E hold an event to raise money 
F identify areas that need bikes 
G write to the government 
34
```

[Original question page](assets/94f18ef83c4c770dd8567aa366241cab79e01cf01810a237f2c87a05caff82e5.jpg)

### Part 3

<!-- Source: /api/assets/c7d638e658b687a6089c1610cd70198473b46cfc21b955e363b5b69bde51e991.jpg; PDF page 36; full -->

```text
SECTION3 Questions21–30
Complete the table below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
‘Student Life’ video project
Item | Cristina | Ibrahim
Enjoyed |using the camera;going to a British(21) __________|contact with students doing other courses(has asked some to(22) __________ with him)
Most useful language practice |listening to instructions;learning(23) __________ vocabulary|listening to British students’ language because of normal speed;large amount of(24) __________
General usefulness |operating video camera;working with other people:learning about(25) __________;compromising;(26) __________ people who have different views|the importance of(27) __________
Things to do differently in future |decide when to(28) __________ each stage at the beginning;make more effort to(29) __________ with the camera|don’t make the film too(30) __________
```

[Original question page](assets/c7d638e658b687a6089c1610cd70198473b46cfc21b955e363b5b69bde51e991.jpg)

### Part 4

<!-- Source: /api/assets/0abb9debcfdfd2e5f6ba7d9cfd72a6a3a95428457d21c2da43b7767c72166802.jpg; PDF page 37; full -->

```text
Test 2 
SECTION 4 Questions 31-40 
Questions 31-40 
Complete the notes below. 
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer. 
ANTARCTICA 
GEOGRAPHY 
• world 's highest, coldest and windiest continent 
• more than 31 ........................ times as big as the UK 
• most of the area is classified as 32 ....................... . 
RESEARCH STATIONS 
• international teams work together 
• 33 ........................ is integrated with technical support 
• stations contain accommodation, work areas, a kitchen, a 34 ...................... .. and a 
gym 
• supplies were brought to Zero One station by sledge from a 35 ........................ at 
the edge of the ice 15 km away 
• problem of snow build-ups solved by building stations on 36 ............ ............ with 
adjustable legs 
FOOD AND DIET 
• average daily requirement for an adult in Antarctica is approximately 
37 ........................ kilocalories 
• rations for field work prepared by process of freeze-drying 
36
```

[Original question page](assets/0abb9debcfdfd2e5f6ba7d9cfd72a6a3a95428457d21c2da43b7767c72166802.jpg)

<!-- Source: /api/assets/e919bee50f8d1d45ff71b2e5a4caf209362ca2929ec1eb435f4a59370ef5866a.jpg; PDF page 38; full -->

```text
Listening 
RESEARCH 
The most important research focuses on climate change, including 
- measuring changes in the ice-cap (because of effects on sea levels and 
38 ........................ ) 
- monitoring the hole in the ozone layer 
- . analysing air from bubbles in ice to measure 39 ........................ caused by human 
activity 
WORK OPPORTUNITIES 
Many openings for 40 ........................ people including 
- research assistants 
- administrative and technical positions 
37
```

[Original question page](assets/e919bee50f8d1d45ff71b2e5a4caf209362ca2929ec1eb435f4a59370ef5866a.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/a0a5acfbdef6cafe37d5df8ce7ad4423697f7a544836401f2c111f57818c8bba.jpg; PDF page 39; full -->

```text
Test 2



READING



READING PASSAGE 1



You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage 1

below.



BAKELITE



The birth of modern plastics



In 1907, Leo Hendrick Baekeland, a Belgian scientist working in New York, discovered and

patented a revolutionary new synthetic material. His invention, which he named ‘Bakelite’,

was of enormous technological importance, and effectively launched the modern plastics



industry.



The term ‘plastic’ comes from the Greek plassein, meaning ‘to mould’. Some plastics are

derived from natural sources, some are semi-synthetic (the result of chemical action on a

natural substance), and some are entirely synthetic, that is, chemically engineered from the

constituents of coal or oil. Some are ‘thermoplastic’, which means that, like candlewax, they

melt when heated and can then be reshaped. Others are ‘thermosetting’: like eggs, they

cannot revert to their original viscous state, and their shape is thus fixed for ever. Bakelite had

the distinction of being the first totally synthetic thermosetting plastic.



The history of today’s plastics begins with the discovery of a series of semi-synthetic

thermoplastic materials in the mid-nineteenth century. The impetus behind the development

of these early plastics was generated by a number of factors — immense technological

progress in the domain of chemistry, coupled with wider cultural changes, and the pragmatic

need to find acceptable substitutes for dwindling supplies of ‘luxury’ materials such as

tortoiseshell and ivory.



Baekeland's interest in plastics began in 1885 when, as a young chemistry student in

Belgium, he embarked on research into phenolic resins, the group of sticky substances

produced when phenol (carbolic acid) combines with an aldehyde (a volatile fluid similar to

alcohol). He soon abandoned the subject, however, only returning to it some years later. By

1905 he was a wealthy New Yorker, having recently made his fortune with the invention of a

new photographic paper. While Baekeland had been busily amassing dollars, some advances

had been made in the development of plastics. The years 1899 and 1900 had seen the

patenting of the first semi-synthetic thermosetting material that could be manufactured on

an industrial scale. In purely scientific terms, Baekeland’s major contribution to the field is not

so much the actual discovery of the material to which he gave his name, but rather the

method by which a reaction between phenol and formaldehyde could be controlled, thus



38
```

[Original question page](assets/a0a5acfbdef6cafe37d5df8ce7ad4423697f7a544836401f2c111f57818c8bba.jpg)

<!-- Source: /api/assets/69070a90783c7720c01bdba22d4abcfaab5b1e509f0e23384a06e78256cb4480.jpg; PDF page 40; full -->

```text
Reading



making possible its preparation on a commercial basis. On 13 July 1907, Baekeland took out

his famous patent describing this preparation, the essential features of which are still in use

today.



The original patent outlined a three-stage process, in which phenol and formaldehyde



(from wood or coal) were initially combined under vacuum inside a large egg-shaped kettle.

The result was a resin known as Novalak, which became soluble and malleable when heated.

The resin was allowed to cool in shallow trays until it hardened, and then broken up and

ground into powder. Other substances were then introduced: including fillers, such as

woodflour, asbestos or cotton, which increase strength and moisture resistance, catalysts

(substances to speed up the reaction between two chemicals without joining to either) and

hexa, a compound of ammonia and formaldehyde which supplied the additional

formaldehyde necessary to form a thermosetting resin. This resin was then left to cool and

harden, and ground up a second time. The resulting granular powder was raw Bakelite, ready

to be made into a vast range of manufactured objects. In the last stage, the heated Bakelite

was poured into a hollow mould of the required shape and subjected to extreme heat and

pressure, thereby ‘setting’ its form for life.



The design of Bakelite objects, everything from earrings to television sets, was governed to a

large extent by the technical requirements of the moulding process. The object could not be

designed so that it was locked into the mould and therefore difficult to extract. A common

general rule was that objects should taper towards the deepest part of the mould, and if

necessary the product was moulded in separate pieces. Moulds had to be carefully designed

so that the molten Bakelite would flow evenly and completely into the mould. Sharp corners

proved impractical and were thus avoided, giving rise to the smooth, ‘streamlined’ style

popular in the 1930s. The thickness of the walls of the mould was also crucial: thick walls

took longer to cool and harden, a factor which had to be considered by the designer in order

to make the most efficient use of machines.



Baekeland's invention, although treated with disdain in its early years, went on to enjoy an

unparalleled popularity which lasted throughout the first half of the twentieth century. It

became the wonder product of the new world of industrial expansion — ‘the material of a

thousand uses’. Being both non-porous and heat-resistant, Bakelite kitchen goods were

promoted as being germ-free and sterilisable. Electrical manufacturers seized on its insulating

properties, and consumers everywhere relished its dazzling array of shades, delighted that

they were now, at last, no longer restricted to the wood tones and drab browns of the pre-

plastic era. It then fell from favour again during the 1950s, and was despised and destroyed

in vast quantities. Recently, however, it has been experiencing something of a renaissance,

with renewed demand for original Bakelite objects in the collectors’ marketplace, and

museums, societies and dedicated individuals once again appreciating the style and originality

of this innovative material.



39
```

[Original question page](assets/69070a90783c7720c01bdba22d4abcfaab5b1e509f0e23384a06e78256cb4480.jpg)

<!-- Source: /api/assets/f58a1e3a9159cd79e2916f090415b528e675304b7123e8e3c9773b2fe310a432.jpg; PDF page 41; full -->

```text
Test 2 
Questions 1-3 
Complete the summary. 
Choose ONE WORD ONLY from the passage for each answer. 
Write your answers in boxes 1-3 on your answer sheet. 
Some plastics behave in a similar way to 1 ........................ in that they melt under heat 
and can be moulded into new forms . Bakelite was unique because it was the first material 
to be both entirely 2 .................. ...... in origin , and thermosetting . 
There were several reasons for the research into plastics in the nineteenth century , 
among them the great advances that had been made in the field of 3 ....................... . and 
the search for alternatives to natural resources like ivory. 
40
```

[Original question page](assets/f58a1e3a9159cd79e2916f090415b528e675304b7123e8e3c9773b2fe310a432.jpg)

<!-- Source: /api/assets/a9f7685c296758085681d277e32c3515ed1c041a983937ca5ac6b7f21819351c.jpg; PDF page 42; full -->

```text
Questions4–8: Complete the flow-chart. Choose ONE WORD ONLY from the passage for each answer. Write your answers in boxes4–8 on your answer sheet.
The Production of Bakelite—use original flow-chart, with the same direction of arrows:
phenol + formaldehyde → combine under vacuum → stage one resin,called(4) __________ → cool until hardened → break up and grind into powder.
Add(5) __________(e.g.cotton,asbestos),catalysts,and(6) __________ formed from ammonia + formaldehyde.
→ stage two resin → cool until hardened → break up and grind into powder →(7) __________ Bakelite → heat → pour into mould → apply intense heat and(8) __________ → cool until hardened.
```

[Original question page](assets/a9f7685c296758085681d277e32c3515ed1c041a983937ca5ac6b7f21819351c.jpg)

![Original figure](assets/a9f7685c296758085681d277e32c3515ed1c041a983937ca5ac6b7f21819351c.jpg)

<!-- Source: /api/assets/844d673a535a1f3dc0b23431dd495b0868b03322e113f8abe4775fb9b155290a.jpg; PDF page 43; full -->

```text
Test 2 
Questions 9 and 10 
Choose TWO letters A-E. 
Write your answers in boxes 9 and 10 on your answer sheet. 
NB Your answers may be given in either order. 
Which TWO of the following factors influencing the design of Bakelite objects are 
mentioned in the text? 
A the function which the object would serve 
B the ease with which the resin could fill the mould 
C the facility with which the object could be removed from the mould 
D the limitations of the materials used to manufacture the mould 
E the fashionable styles of the period 
Questions 11-13 
Do the following statements agree with the information given in Reading Passage 1? 
In boxes 11-13 on your answer sheet, write 
TRUE 
FALSE 
NOT GIVEN 
if the statement agrees with the information 
if the statement contradicts the information 
if there is no information on this 
11 Modern-day plastic preparation is based on the same principles as that patented 
in 1907. 
12 Bakelite was immediately welcomed as a practical and versatile material. 
13 Bakelite was only available in a limited range of colours. 
42
```

[Original question page](assets/844d673a535a1f3dc0b23431dd495b0868b03322e113f8abe4775fb9b155290a.jpg)

<!-- Source: /api/assets/6c9d170c4918b407ce526cddb44aa3fb2d03a4c8137d92b577756f0282a54e95.jpg; PDF page 44; full -->

```text
Reading



READING PASSAGE 2



You should spend about 20 minutes on Questions 14-27, which are based on Reading Passage 2

below.



What’s so funny?

John McCrone reviews recent research on humour



The joke comes over the headphones: ‘Which side of a dog has the most hair? The left.’

No, not funny. Try again. ‘Which side of a dog has the most hair? The outside.’ Hah! The

punchline is silly yet fitting, tempting a smile, even a laugh. Laughter has always struck

people as deeply mysterious, perhaps pointless. The writer Arthur Koestler dubbed it the

luxury reflex: ‘unique in that it serves no apparent biological purpose’.



Theories about humour have an ancient pedigree. Plato expressed the idea that humour is

simply a delighted feeling of superiority over others. Kant and Freud felt that joke-telling

relies on building up a psychic tension which is safely punctured by the ludicrousness of

the punchline. But most modern humour theorists have settled on some version of

Aristotle's belief that jokes are based on a reaction to or resolution of incongruity, when the

punchline is either a nonsense or, though appearing silly, has a clever second meaning.



Graeme Ritchie, a computational linguist in Edinburgh, studies the linguistic structure of

jokes in order to understand not only humour but language understanding and reasoning

in machines. He says that while there is no single format for jokes, many revolve around a

sudden and surprising conceptual shift. A comedian will present a situation followed by an

unexpected interpretation that is also apt.



So even if a punchline sounds silly, the listener can see there is a clever semantic fit and

that sudden mental ‘Aha!’ is the buzz that makes us laugh. Viewed from this angle, humour

is just a form of creative insight, a sudden leap to a new perspective.



However, there is another type of laughter, the laughter of social appeasement and it is

important to understand this too. Play is a crucial part of development in most young

mammals. Rats produce ultrasonic squeaks to prevent their scuffles turning nasty.

Chimpanzees have a ‘play-face’ - a gaping expression accompanied by a panting ‘ah, ah’

noise. In humans, these signals have mutated into smiles and laughs. Researchers believe

social situations, rather than cognitive events such as jokes, trigger these instinctual

markers of play or appeasement. People laugh on fairground rides or when tickled to flag a

play situation, whether they feel amused or not.



Both social and cognitive types of laughter tap into the same expressive machinery in our

brains, the emotion and motor circuits that produce smiles and excited vocalisations.

However, if cognitive laughter is the product of more general thought processes, it should

result from more expansive brain activity.



43
```

[Original question page](assets/6c9d170c4918b407ce526cddb44aa3fb2d03a4c8137d92b577756f0282a54e95.jpg)

<!-- Source: /api/assets/3198ee67c2c6c768b24f2926f5dbf8fa905e0fd704ae9b84d35c2bdc48f8b38b.jpg; PDF page 45; full -->

```text
Test 2



Psychologist Vinod Goel investigated humour using the new technique of ‘single event’

functional magnetic resonance imaging (fMRI). An MRI scanner uses magnetic fields and

radio waves to track the changes in oxygenated blood that accompany mental activity.

Until recently, MRI scanners needed several minutes of activity and so could not be used to

track rapid thought processes such as comprehending a joke. New developments now

allow half-second ‘snapshots’ of all sorts of reasoning and problem-solving activities.



Although Goel felt being inside a brain scanner was hardly the ideal place for appreciating

a joke, he found evidence that understanding a joke involves a widespread mental shift. His

scans showed that at the beginning of a joke the listener's prefrontal cortex lit up,

particularly the right prefrontal believed to be critical for problem solving. But there was

also activity in the temporal lobes at the side of the head (consistent with attempts to rouse

stored knowledge) and in many other brain areas. Then when the punchline arrived, a new

area sprang to life - the orbital prefrontal cortex. This patch of brain tucked behind the

orbits of the eyes is associated with evaluating information.



Making a rapid emotional assessment of the events of the moment is an extremely

demanding job for the brain, animal or human. Energy and arousal levels may need to be

retuned in the blink of an eye. These abrupt changes will produce either positive or

negative feelings. The orbital cortex, the region that becomes active in Goel’s experiment,

seems the best candidate for the site that feeds such feelings into higher-level thought

processes, with its close connections to the brain’s sub-cortical arousal apparatus and

centres of metabolic control.



All warm-blooded animals make constant tiny adjustments in arousal in response to

external events, but humans, who have developed a much more complicated internal life

as a result of language, respond emotionally not only to their surroundings, but to their

own thoughts. Whenever a sought-for answer snaps into place, there is a shudder of

pleased recognition. Creative discovery being pleasurable, humans have learned to find

ways of milking this natural response. The fact that jokes tap into our general evaluative

machinery explains why the line between funny and disgusting, or funny and frightening,

can be so fine. Whether a joke gives pleasure or pain depends on a person's outlook.



Humour may be a luxury, but the mechanism behind it is no evolutionary accident. As

Peter Derks, a psychologist at William and Mary College in Virginia, says: ‘I like to think of

humour as the distorted mirror of the mind. It’s creative, perceptual, analytical and lingual.

If we can figure out how the mind processes humour, then we’ll have a pretty good handle

on how it works in general.’
```

[Original question page](assets/3198ee67c2c6c768b24f2926f5dbf8fa905e0fd704ae9b84d35c2bdc48f8b38b.jpg)

<!-- Source: /api/assets/02cad41e8828aa98f5fa057442ab48a12de91c3d93b72f4224184876acbf9bae.jpg; PDF page 46; full -->

```text
Reading 
Questions 14-20 
Do the following statements agree with the information given in Reading Passage 2? 
In boxes 14-20 on your answer sheet, write 
TRUE 
FALSE 
NOT GIVEN 
if the statement agrees with the information 
if the statement contradicts the information 
if there is no information on this 
14 Arthur Koestler considered laughter biologically important in several ways. 
15 Plato believed humour to be a sign of above-average intelligence. 
16 Kant believed that a successful joke involves the controlled release of nervous energy. 
17 Current thinking on humour has largely ignored Aristotle's view on the subject. 
18 Graeme Ritchie's work links jokes to artificial intelligence. 
19 Most comedians use personal situations as a source of humour . 
20 Chimpanzees make particular noises when they are playing. 
45
```

[Original question page](assets/02cad41e8828aa98f5fa057442ab48a12de91c3d93b72f4224184876acbf9bae.jpg)

<!-- Source: /api/assets/9bbba5740794aa0053126b22def33191eefa937348bc2ea2c81e1f7070762d25.jpg; PDF page 47; full -->

```text
Test 2 
Questions 21-23 
The diagram below shows the areas of the brain activated by jokes. 
Label the diagram. 
Choose NO MORE THAN TWO WORDS from the passage for each answer. 
Write your answers in boxes 21-23 on your answer sheet. 
46 
Right prefrontal cortex lights 
up - area of brain linked to 
21 ....................... . 
Orbital prefrontal cortex is 
activated - involved with 
23 ......... .............. . 
22 ........................ become 
active too
```

[Original question page](assets/9bbba5740794aa0053126b22def33191eefa937348bc2ea2c81e1f7070762d25.jpg)

![Original figure](assets/9bbba5740794aa0053126b22def33191eefa937348bc2ea2c81e1f7070762d25.jpg)

<!-- Source: /api/assets/c8f4f5cd093c747318fabc7fbc3158ea4cce8d6a4d8bc26aaa71ebbcaa13fa64.jpg; PDF page 48; full -->

```text
Questions 24-27 
Complete each sentence with the correct ending A-G below. 
Write the correct letter A–G in boxes 24-27 on your answer sheet. 
24 One of the brain's most difficult tasks is to 
25 Because of the language they have developed, humans 
26 Individual responses to humour 
27 Peter Derks believes that humour 
A react to their own thoughts. 
B helped create language in humans. 
C respond instantly to whatever is happening. 
D may provide valuable information about the operation of the brain. 
E cope with difficult situations. 
F relate to a person's subjective views. 
G led our ancestors to smile and then laugh. 
Reading 
47
```

[Original question page](assets/c8f4f5cd093c747318fabc7fbc3158ea4cce8d6a4d8bc26aaa71ebbcaa13fa64.jpg)

<!-- Source: /api/assets/18c5d05537a48cb3f6e5d8eb39716953d221fced6467f0b7b87da4bd689f8450.jpg; PDF page 49; full -->

```text
Test 2



READING PASSAGE 3



You should spend about 20 minutes on Questions 28-40, which are based on Reading Passage 3



below.



The Birth of Scientific English



World science is dominated today by a

small number of languages, including

Japanese, German and French, but it is

English which is probably the most popular

global language of science. This is not just

because of the importance of English-

speaking countries such as the USA in

scientific research; the scientists of many

non-English-speaking countries find that

they need to write their research papers in

English to reach a wide international

audience. Given the prominence of

scientific English today, it may seem

surprising that no one really knew how to

write science in English before the



17th century. Before that, Latin was

regarded as the lingua franca¹ for

European intellectuals.



The European Renaissance (c. 14th-16th

century) is sometimes called the ‘revival of

learning’, a time of renewed interest in the

‘lost knowledge’ of classical times. At the

same time, however, scholars also began

to test and extend this knowledge. The

emergent nation states of Europe

developed competitive interests in world

exploration and the development of trade.

Such expansion, which was to take the

English language west to America and east

to India, was supported by scientific

developments such as the discovery of

magnetism (and hence the invention of the

compass), improvements in cartography

and — perhaps the most important scientific



revolution of them all — the new theories of

astronomy and the movement of the Earth

in relation to the planets and stars,

developed by Copernicus (1473-1543).



England was one of the first countries

where scientists adopted and publicised

Copernican ideas with enthusiasm. Some

of these scholars, including two with

interests in language — John Wallis and

John Wilkins — helped found the Royal

Society in 1660 in order to promote

empirical scientific research.



Across Europe similar academies and

societies arose, creating new national

traditions of science. In the initial stages of

the scientific revolution, most publications in

the national languages were popular

works, encyclopaedias, educational

textbooks and translations. Original science

was not done in English until the second

half of the 17th century. For example,

Newton published his mathematical

treatise, known as the Principia, in Latin,

but published his later work on the

properties of light - Opticks - in English.



There were several reasons why original

science continued to be written in Latin.

The first was simply a matter of audience.

Latin was suitable for an international

audience of scholars, whereas English

reached a socially wider, but more local,

audience. Hence, popular science was

written in English.



1 lingua franca: a language which is used for communication between groups of people who speak different



languages



48
```

[Original question page](assets/18c5d05537a48cb3f6e5d8eb39716953d221fced6467f0b7b87da4bd689f8450.jpg)

<!-- Source: /api/assets/b4ecd85876c534d30ec107c4e9344180b9fa02e37cd6ffc6f1678cc87634b923.jpg; PDF page 50; full -->

```text
A second reason for writing in Latin may,

perversely, have been a concern for

secrecy. Open publication had dangers in

putting into the public domain preliminary

ideas which had not yet been fully

exploited by their ‘author’. This growing

concern about intellectual property rights

was a feature of the period — it reflected

both the humanist notion of the individual,

rational scientist who invents and discovers

through private intellectual labour, and the

growing connection between original

science and commercial exploitation. There

was something of a social distinction

between ‘scholars and gentlemen’ who

understood Latin, and men of trade who

lacked a classical education. And in the

mid-17th century it was common practice

for mathematicians to keep their

discoveries and proofs secret, by writing

them in cipher, in obscure languages, or in

private messages deposited in a sealed

box with the Royal Society. Some scientists

might have felt more comfortable with Latin

precisely because its audience, though

international, was socially restricted.

Doctors clung the most keenly to Latin as

an ‘insider language’.



A third reason why the writing of original

science in English was delayed may have

been to do with the linguistic inadequacy

of English in the early modern period.

English was not well equipped to deal with

scientific argument. First, it lacked the

necessary technical vocabulary. Second, it

lacked the grammatical resources required

to represent the world in an objective and

impersonal way, and to discuss the

relations, such as cause and effect, that

might hold between complex and

hypothetical entities.



Reading



Fortunately, several members of the Royal

Society possessed an interest in language

and became engaged in various linguistic

projects. Although a proposal in 1664 to

establish a committee for improving the

English language came to little, the

society’s members did a great deal to

foster the publication of science in English

and to encourage the development of a

suitable writing style. Many members of

the Royal Society also published

monographs in English. One of the first

was by Robert Hooke, the society’s first

curator of experiments, who described his

experiments with microscopes in

Micrographia (1665). This work is largely

narrative in style, based on a transcript of

oral demonstrations and lectures.



In 1665 a new scientific journal,

Philosophical Transactions, was

inaugurated. Perhaps the first international

English-language scientific journal, it

encouraged a new genre of scientific

writing, that of short, focused accounts of

particular experiments.



The 17th century was thus a formative

period in the establishment of scientific

English. In the following century much of

this momentum was lost as German

established itself as the leading European

language of science. It is estimated that by

the end of the 18th century 401 German

scientific journals had been established as

opposed to 96 in France and 50 in

England. However, in the 19th century

scientific English again enjoyed substantial

lexical growth as the industrial revolution

created the need for new technical

vocabulary, and new, specialised,

professional societies were instituted to

promote and publish in the new disciplines.



49
```

[Original question page](assets/b4ecd85876c534d30ec107c4e9344180b9fa02e37cd6ffc6f1678cc87634b923.jpg)

<!-- Source: /api/assets/3ee56fc2a954fdf92129227a6de607aa61a8f063d5b8c3ab0960deea265d318c.jpg; PDF page 51; full -->

```text
Questions28–34: Complete the summary. Choose NO MORE THAN TWO WORDS from the passage for each answer. Write your answers in boxes28–34 on your answer sheet.
In Europe,modern science emerged at the same time as the nation state.At first,the scientific language of choice remained(28) __________.It allowed scientists to communicate with other socially privileged thinkers while protecting their work from unwanted exploitation.Sometimes the desire to protect ideas seems to have been stronger than the desire to communicate them,particularly in the case of mathematicians and(29) __________.In Britain,moreover,scientists worried that English had neither the(30) __________ nor the(31) __________ to express their ideas.This situation only changed after1660when scientists associated with the(32) __________ set about developing English.An early scientific journal fostered a new kind of writing based on short descriptions of specific experiments.Although English was then overtaken by(33) __________,it developed again in the19th century as a direct result of the(34) __________.
Questions35–37: Do the following statements agree with the information given in Reading Passage3?
In boxes35–37 write TRUE if the statement agrees with the information;FALSE if the statement contradicts the information;NOT GIVEN if there is no information on this.
35 There was strong competition between scientists in Renaissance Europe.
36 The most important scientific development of the Renaissance period was the discovery of magnetism.
37 In17th-century Britain,leading thinkers combined their interest in science with an interest in how to express ideas.
```

[Original question page](assets/3ee56fc2a954fdf92129227a6de607aa61a8f063d5b8c3ab0960deea265d318c.jpg)

<!-- Source: /api/assets/79c7b9b8097ff48c2dbf1d4ac9ae694317902552205cc674d62083313611542e.jpg; PDF page 52; full -->

```text
Questions38–40: Complete the table. Choose NO MORE THAN TWO WORDS from the passage for each answer. Write your answers in boxes38–40 on your answer sheet.
Science written in the first half of the17th century
Item | Latin | English
Type of science |Original|(38) __________
Examples |(39) __________|Encyclopaedias
Target audience |International scholars|(40) __________,but socially wider
```

[Original question page](assets/79c7b9b8097ff48c2dbf1d4ac9ae694317902552205cc674d62083313611542e.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/b9e59260b7cf9daf105f1b053dcd72de4bd827c5e3596907658168d998e90147.jpg; PDF page 53; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show the main reasons for study among students of different age groups and the amount of support they received from employers.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/b9e59260b7cf9daf105f1b053dcd72de4bd827c5e3596907658168d998e90147.jpg)

![Original figure](assets/b9e59260b7cf9daf105f1b053dcd72de4bd827c5e3596907658168d998e90147.jpg)

### Task 2

<!-- Source: /api/assets/b72eafd61f67fc28d0ae38bfd45c172f04e4d6104069fc994899799392715518.jpg; PDF page 54; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In some countries young people are encouraged to work or travel for a year between finishing high school and starting university studies.

Discuss the advantages and disadvantages for young people who decide to do this.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/b72eafd61f67fc28d0ae38bfd45c172f04e4d6104069fc994899799392715518.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/fd355fa7878686fd523cc25dd4874b1f0e016fb06da5153b42502bb4703b21b4.jpg; PDF page 55; full -->

```text
Test 2 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics . 
EXAMPLE 
Colour 
• What's your favourite colour? [Why?] 
• Do you like the same colours now as you did when you were younger? (Why/Why not?] 
• What can you learn about a person from the colours they like? 
• Do any colours have a special meaning in your culture? 
PART 2 
Describe a song or a piece of music you 
like. 
You should say: 
what the song or music is 
what kind of song or music it is 
where you first heard it 
and explain why you like it. 
You will have to talk about the topic for one 
to two minutes . 
You have one minute to think about what 
you 're going to say. 
You can make some notes to help you if you 
wish. 

PART 3 
Discussion topics: 
Music and young people 
Example questions : 
What kinds of music are popular with young people in your culture? 
What do you think influences a young person's taste in music? 
How has technology affected the kinds of music popular with young people? 
Music and society 
Example questions : 
Tell me about any traditional music in your culture. 
How important is it for a culture to have musical traditions? 
Why do you think countries have national anthems or songs? 
54
```

[Original question page](assets/fd355fa7878686fd523cc25dd4874b1f0e016fb06da5153b42502bb4703b21b4.jpg)

### Part 2

<!-- Source: /api/assets/fd355fa7878686fd523cc25dd4874b1f0e016fb06da5153b42502bb4703b21b4.jpg; PDF page 55; full -->

```text
Test 2 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics . 
EXAMPLE 
Colour 
• What's your favourite colour? [Why?] 
• Do you like the same colours now as you did when you were younger? (Why/Why not?] 
• What can you learn about a person from the colours they like? 
• Do any colours have a special meaning in your culture? 
PART 2 
Describe a song or a piece of music you 
like. 
You should say: 
what the song or music is 
what kind of song or music it is 
where you first heard it 
and explain why you like it. 
You will have to talk about the topic for one 
to two minutes . 
You have one minute to think about what 
you 're going to say. 
You can make some notes to help you if you 
wish. 

PART 3 
Discussion topics: 
Music and young people 
Example questions : 
What kinds of music are popular with young people in your culture? 
What do you think influences a young person's taste in music? 
How has technology affected the kinds of music popular with young people? 
Music and society 
Example questions : 
Tell me about any traditional music in your culture. 
How important is it for a culture to have musical traditions? 
Why do you think countries have national anthems or songs? 
54
```

[Original question page](assets/fd355fa7878686fd523cc25dd4874b1f0e016fb06da5153b42502bb4703b21b4.jpg)

### Part 3

<!-- Source: /api/assets/fd355fa7878686fd523cc25dd4874b1f0e016fb06da5153b42502bb4703b21b4.jpg; PDF page 55; full -->

```text
Test 2 
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics . 
EXAMPLE 
Colour 
• What's your favourite colour? [Why?] 
• Do you like the same colours now as you did when you were younger? (Why/Why not?] 
• What can you learn about a person from the colours they like? 
• Do any colours have a special meaning in your culture? 
PART 2 
Describe a song or a piece of music you 
like. 
You should say: 
what the song or music is 
what kind of song or music it is 
where you first heard it 
and explain why you like it. 
You will have to talk about the topic for one 
to two minutes . 
You have one minute to think about what 
you 're going to say. 
You can make some notes to help you if you 
wish. 

PART 3 
Discussion topics: 
Music and young people 
Example questions : 
What kinds of music are popular with young people in your culture? 
What do you think influences a young person's taste in music? 
How has technology affected the kinds of music popular with young people? 
Music and society 
Example questions : 
Tell me about any traditional music in your culture. 
How important is it for a culture to have musical traditions? 
Why do you think countries have national anthems or songs? 
54
```

[Original question page](assets/fd355fa7878686fd523cc25dd4874b1f0e016fb06da5153b42502bb4703b21b4.jpg)
