# 剑雅 5 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 155

TEST2 LISTENING
Section1, Questions1–10
1 (passport)photos / (passport)photographs
2 (a)bank statement
3 125(per year)
4 8
5 1.50
6 48
7 local papers / local newspapers
8 (a)card / cards
9 Grantingham
10 Friday
Section2, Questions11–20
11 C
12 C
13 A
14 C
15 A
16 £75,000
17 computers
18–20 IN ANY ORDER: C;E;F
Section3, Questions21–30
21 home / student’s home
22 (have)dinner / come to dinner / go to dinner
23 technical
24 slang
25 cooperating / cooperation
26 persuading
27 editing
28 complete
29 experiment
30 long
Section4, Questions31–40
31 58
32 desert
33 science
34 hospital / small hospital
35 ship
36 platforms
37 3,500
38 currents / ocean currents
39 (the)pollution
40 young
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. photos / passport photos / photographs / passport photographs

2. bank statement / a bank statement

3. 125 / 125 per year

4. 8

5. 1.50 / 1:50

6. 48

7. local papers / local newspapers

8. card / a card / cards

9. Grantingham

10. Friday

### Part 2 · source page 155

TEST2 LISTENING
Section1, Questions1–10
1 (passport)photos / (passport)photographs
2 (a)bank statement
3 125(per year)
4 8
5 1.50
6 48
7 local papers / local newspapers
8 (a)card / cards
9 Grantingham
10 Friday
Section2, Questions11–20
11 C
12 C
13 A
14 C
15 A
16 £75,000
17 computers
18–20 IN ANY ORDER: C;E;F
Section3, Questions21–30
21 home / student’s home
22 (have)dinner / come to dinner / go to dinner
23 technical
24 slang
25 cooperating / cooperation
26 persuading
27 editing
28 complete
29 experiment
30 long
Section4, Questions31–40
31 58
32 desert
33 science
34 hospital / small hospital
35 ship
36 platforms
37 3,500
38 currents / ocean currents
39 (the)pollution
40 young
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. C

12. C

13. A

14. C

15. A

16. £ 75,000 / £ 75000 / £75,000 / £75000

17. computers

18. C / E / F

19. C / E / F

20. C / E / F

### Part 3 · source page 155

TEST2 LISTENING
Section1, Questions1–10
1 (passport)photos / (passport)photographs
2 (a)bank statement
3 125(per year)
4 8
5 1.50
6 48
7 local papers / local newspapers
8 (a)card / cards
9 Grantingham
10 Friday
Section2, Questions11–20
11 C
12 C
13 A
14 C
15 A
16 £75,000
17 computers
18–20 IN ANY ORDER: C;E;F
Section3, Questions21–30
21 home / student’s home
22 (have)dinner / come to dinner / go to dinner
23 technical
24 slang
25 cooperating / cooperation
26 persuading
27 editing
28 complete
29 experiment
30 long
Section4, Questions31–40
31 58
32 desert
33 science
34 hospital / small hospital
35 ship
36 platforms
37 3,500
38 currents / ocean currents
39 (the)pollution
40 young
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. home / student's home

22. dinner / have dinner / come to dinner / go to dinner

23. technical

24. slang

25. cooperating / cooperation

26. persuading

27. editing

28. complete

29. experiment

30. long

### Part 4 · source page 155

TEST2 LISTENING
Section1, Questions1–10
1 (passport)photos / (passport)photographs
2 (a)bank statement
3 125(per year)
4 8
5 1.50
6 48
7 local papers / local newspapers
8 (a)card / cards
9 Grantingham
10 Friday
Section2, Questions11–20
11 C
12 C
13 A
14 C
15 A
16 £75,000
17 computers
18–20 IN ANY ORDER: C;E;F
Section3, Questions21–30
21 home / student’s home
22 (have)dinner / come to dinner / go to dinner
23 technical
24 slang
25 cooperating / cooperation
26 persuading
27 editing
28 complete
29 experiment
30 long
Section4, Questions31–40
31 58
32 desert
33 science
34 hospital / small hospital
35 ship
36 platforms
37 3,500
38 currents / ocean currents
39 (the)pollution
40 young
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. 58

32. desert

33. science

34. hospital / small hospital

35. ship

36. platforms

37. 3,500 / 3500

38. currents / ocean currents

39. pollution / the pollution

40. young

## A 类阅读

### Academic Reading · source page 156

ACADEMIC READING
Reading Passage1, Questions1–13
1 candlewax
2 synthetic
3 chemistry
4 Novalak
5 fillers
6 hexa
7 raw
8 pressure
9 B
10 C
11 TRUE
12 FALSE
13 FALSE
Reading Passage2, Questions14–27
14 FALSE
15 NOT GIVEN
16 TRUE
17 FALSE
18 TRUE
19 NOT GIVEN
20 TRUE
21 problem solving
22 temporal lobes
23 evaluating information
24 C
25 A
26 F
27 D
Reading Passage3, Questions28–40
28 Latin
29 doctors
30–31 IN EITHER ORDER: technical vocabulary;grammatical resources
32 Royal Society
33 German
34 industrial revolution
35 NOT GIVEN
36 FALSE
37 TRUE
38 popular
39 Principia / the Principia / Newton’s Principia / mathematical treatise
40 local / more local / local audience
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. candlewax

2. synthetic

3. chemistry

4. Novalak

5. fillers

6. hexa

7. raw

8. pressure

9. B

10. C

11. TRUE

12. FALSE

13. FALSE

14. FALSE

15. NOT GIVEN

16. TRUE

17. FALSE

18. TRUE

19. NOT GIVEN

20. TRUE

21. problem solving

22. temporal lobes

23. evaluating information

24. C

25. A

26. F

27. D

28. Latin

29. doctors

30. technical vocabulary / grammatical resources

31. technical vocabulary / grammatical resources

32. Royal Society

33. German

34. industrial revolution

35. NOT GIVEN

36. FALSE

37. TRUE

38. popular

39. Principia / the Principia / Newton's Principia / mathematical treatise

40. local / more local / local audience

## A 类写作

### Writing material: c5-t2-w-1

Both original charts and their legends inspected at full resolution. Age categories: under 26, 26–29, 30–39, 40–49, over 49. Top chart percentages: white bars for career; grey for interest. Approximate career/interest readings: under 26 80%/10%; 26–29 70%/15%; 30–39 about 55%/25%; 40–49 40%/40%; over 49 20%/70%. Career motivation falls with age while interest rises, reaching equality in the 40–49 group. Do not require the two reported percentages in each group to total 100%. Lower chart measures employer support defined as time off and help with fees, percentages by the same age categories. Approximate front-face bar readings: 65%,50%,35%,38%,45%. The youngest receive the most support; support reaches its minimum at ages 30–39 and rises again for older groups. The three-dimensional bar tops introduce visual offsets: allow sensible rounded estimates rather than treating back-edge heights as exact values. No country, survey year or number of students is stated.



### Writing material: c5-t2-w-2

Discuss advantages and disadvantages for the YOUNG PEOPLE undertaking a year of work or travel between high school and university. Do not substitute an unrelated career break or require an impact analysis on national economies.



## 口语
