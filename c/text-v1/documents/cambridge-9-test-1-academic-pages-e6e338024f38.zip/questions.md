# 剑雅 9 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/13d1367510bc668b40fc84092d4709b2809573ab037c171f3036204b4a6004ad.jpg; PDF page 2; full -->

```text
SECTION 1 Questions 1–10
Complete the notes below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
JOB ENQUIRY
Example — Work at: a restaurant
Type of work: (1) __________
Number of hours per week: 12 hours
Would need work permit
Work in the: (2) __________ branch
Nearest bus stop: next to (3) __________
Pay: (4) £__________ an hour
Extra benefits:
– a free dinner
– extra pay when you work on (5) __________
– transport home when you work (6) __________
Qualities required:
– (7) __________
– ability to (8) __________
Interview arranged for: Thursday (9) __________ at 6 p.m.
Bring the names of two referees
Ask for: Samira (10) __________
```

[Original question page](assets/13d1367510bc668b40fc84092d4709b2809573ab037c171f3036204b4a6004ad.jpg)

### Part 2

<!-- Source: /api/assets/b05144a64b04d848bada7b466173e59003ae1d1d0dd5667f244c1da00336eb06.jpg; PDF page 3; full -->

```text
SECTION 2 Questions 11–20
Questions 11–16
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
SPORTS WORLD
– a new (11) __________ of an international sports goods company
– located in the shopping centre to the (12) __________ of Bradcaster
– has sports (13) __________ and equipment on floors 1–3
– can get you any item within (14) __________ days
– shop specialises in equipment for (15) __________
– has a special section which just sells (16) __________
```

[Original question page](assets/b05144a64b04d848bada7b466173e59003ae1d1d0dd5667f244c1da00336eb06.jpg)

<!-- Source: /api/assets/42ddc10f859aa9c5f15da58d19e2c3c027929aa4c888cbf51b2599ed371f4ac4.jpg; PDF page 4; full -->

```text
Questions 17 and 18
Choose the correct letter, A, B or C.
17 A champion athlete will be in the shop
A on Saturday morning only.
B all day Saturday.
C for the whole weekend.
18 The first person to answer 20 quiz questions correctly will win
A gym membership.
B a video.
C a calendar.
Questions 19 and 20
Choose TWO letters, A–E.
Which TWO pieces of information does the speaker give about the fitness test?
A You need to reserve a place.
B It is free to account holders.
C You get advice on how to improve your health.
D It takes place in a special clinic.
E It is cheaper this month.
```

[Original question page](assets/42ddc10f859aa9c5f15da58d19e2c3c027929aa4c888cbf51b2599ed371f4ac4.jpg)

### Part 3

<!-- Source: /api/assets/95f5f57f0ad5181e8f5e2a6f09eff0b12ea31894b6dd30a3b8ee342eafca2504.jpg; PDF page 5; full -->

```text
SECTION 3 Questions 21–30
Choose the correct letter, A, B or C.
Course Feedback
21 One reason why Spiros felt happy about his marketing presentation was that
A he was not nervous.
B his style was good.
C the presentation was the best in his group.
22 What surprised Hiroko about the other students’ presentations?
A Their presentations were not interesting.
B They found their presentations stressful.
C They didn’t look at the audience enough.
23 After she gave her presentation, Hiroko felt
A delighted.
B dissatisfied.
C embarrassed.
24 How does Spiros feel about his performance in tutorials?
A not very happy
B really pleased
C fairly confident
25 Why can the other students participate so easily in discussions?
A They are polite to each other.
B They agree to take turns in speaking.
C They know each other well.
26 Why is Hiroko feeling more positive about tutorials now?
A She finds the other students’ opinions more interesting.
B She is making more of a contribution.
C The tutor includes her in the discussion.
27 To help her understand lectures, Hiroko
A consulted reference materials.
B had extra tutorials with her lecturers.
C borrowed lecture notes from other students.
```

[Original question page](assets/95f5f57f0ad5181e8f5e2a6f09eff0b12ea31894b6dd30a3b8ee342eafca2504.jpg)

<!-- Source: /api/assets/2a9ad56569939aeff133608aff163b6a708fac6f98720cbe76489616989d7435.jpg; PDF page 6; full -->

```text
Test 1

28 What does Spiros think of his reading skills?

A He reads faster than he used to.
B It still takes him a long time to read.
C  He tends to struggle with new vocabulary.

29 What is Hiroko’s subject area?

A  environmental studies
B health education
C engineering

30 Hiroko thinks that in the reading classes the students should

A learn more vocabulary.
B read more in their own subject areas.
C  develop better reading strategies.

14
```

[Original question page](assets/2a9ad56569939aeff133608aff163b6a708fac6f98720cbe76489616989d7435.jpg)

### Part 4

<!-- Source: /api/assets/e618aab78af9f00c3eb5706955d375119d093392f86d081271819b4b1d1895f5.jpg; PDF page 7; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write NO MORE THAN TWO WORDS for each answer.
Mass Strandings of Whales and Dolphins
Mass strandings: situations where groups of whales, dolphins, etc. swim onto the beach and die
Common in areas where the (31) __________ can change quickly
Several other theories:
Parasites
e.g. some parasites can affect marine animals’ (32) __________, which they depend on for navigation
Toxins
Poisons from (33) __________ or __________ are commonly consumed by whales
e.g. Cape Cod (1988) – whales were killed by saxitoxin
Accidental Strandings
Animals may follow prey ashore, e.g. Thurston (1995)
Unlikely because the majority of animals were not (34) __________ when they stranded
Human Activity
(35) __________ from military tests are linked to some recent strandings
The Bahamas (2000) stranding was unusual because the whales
– were all (36) __________
– were not in a (37) __________
```

[Original question page](assets/e618aab78af9f00c3eb5706955d375119d093392f86d081271819b4b1d1895f5.jpg)

<!-- Source: /api/assets/20e1df634c318f03a644c83662ccee54198257d00289a749850b8e1578082f90.jpg; PDF page 8; full -->

```text
Group Behaviour
– More strandings in the most (38) __________ species of whales
– 1994 dolphin stranding – only the (39) __________ was ill
Further Reading
Marine Mammals Ashore (Connor) – gives information about stranding (40) __________
```

[Original question page](assets/20e1df634c318f03a644c83662ccee54198257d00289a749850b8e1578082f90.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/52f6f8fe28514f00cc86ac2df33c2760e49814112c7d1b99431346400903b9b7.jpg; PDF page 9; full -->

```text
Reading

READING PASSAGE 1

You should spend about 20 minutes on Questions 1-13, which are based on Reading

Passage 1 below.

William Henry Perkin

The man who invented synthetic dyes

William Henry Perkin was born on
March 12, 1838, in London, England.

As a boy, Perkin’s curiosity prompted
early interests in the arts, sciences,
photography, and engineering. But it was
a chance stumbling upon a run-down,
yet functional, laboratory in his late
grandfather’s home that solidified the
young man’s enthusiasm for chemistry.

As a student at the City of London School,
Perkin became immersed in the study of
chemistry. His talent and devotion to the
subject were perceived by his teacher,
Thomas Hall, who encouraged him to
attend a series of lectures given by the
eminent scientist Michael Faraday at the
Royal Institution. Those speeches fired
the young chemist’s enthusiasm further,
and he later went on to attend the Royal
College of Chemistry, which he succeeded
in entering in 1853, at the age of 15.

At the time of Perkin’s enrolment, the
Royal College of Chemistry was headed
by the noted German chemist August
Wilhelm Hofmann. Perkin’s scientific
gifts soon caught Hofmann’s attention
and, within two years, he became
Hofmann’s youngest assistant. Not long
after that, Perkin made the scientific
breakthrough that would bring him both
fame and fortune.

At the time, quinine was the only viable
medical treatment for malaria. The
drug is derived from the bark of the
cinchona tree, native to South America,
and by 1856 demand for the drug was
surpassing the available supply. Thus,
when Hofmann made some passing
comments about the desirability of a
synthetic substitute for quinine, it was
unsurprising that his star pupil was
moved to take up the challenge.

During his vacation in 1856, Perkin
spent his time in the laboratory on the
top floor of his family’s house. He was
attempting to manufacture quinine

from aniline, an inexpensive and readily
available coal tar waste product. Despite
his best efforts, however, he did not end
up with quinine. Instead, he produced a
mysterious dark sludge. Luckily, Perkin’s
scientific training and nature prompted
him to investigate the substance further.
Incorporating potassium dichromate and
alcohol into the aniline at various stages
of the experimental process, he finally
produced a deep purple solution. And,
proving the truth of the famous scientist
Louis Pasteur’s words ‘chance favours
only the prepared mind’, Perkin saw the
potential of his unexpected find.

17
```

[Original question page](assets/52f6f8fe28514f00cc86ac2df33c2760e49814112c7d1b99431346400903b9b7.jpg)

<!-- Source: /api/assets/e3ed1f9bc1b4b5fdbc93ecd3a7786043ba26ac82ea3ed62089fc8a31e9b61403.jpg; PDF page 10; full -->

```text
Test 1

18

Historically, textile dyes were made

from such natural sources as plants

and animal excretions. Some of these,
such as the glandular mucus of snails,
were difficult to obtain and outrageously
expensive. Indeed, the purple colour
extracted from a snail was once so costly
that in society at the time only the rich
could afford it. Further, natural dyes
tended to be muddy in hue and fade
quickly. It was against this backdrop that
Perkin’s discovery was made.

Perkin quickly grasped that his purple
solution could be used to colour

fabric, thus making it the world’s first
synthetic dye. Realising the importance
of this breakthrough, he lost no time

in patenting it. But perhaps the most
fascinating of all Perkin’s reactions to his
find was his nearly instant recognition
that the new dye had commercial
possibilities.

Perkin originally named his dye Tyrian
Purple, but it later became commonly
known as mauve (from the French for
the plant used to make the colour violet).
He asked advice of Scottish dye works
owner Robert Pullar, who assured him
that manufacturing the dye would be
well worth it if the colour remained
fast (i.e. would not fade) and the cost
was relatively low. So, over the fierce
objections of his mentor Hofmann, he
left college to give birth to the modern
chemical industry.

With the help of his father and brother,
Perkin set up a factory not far from
London. Utilising the cheap and plentiful
coal tar that was an almost unlimited
byproduct of London’s gas street lighting,
the dye works began producing the
world’s first synthetically dyed material
in 1857. The company received a
commercial boost from the Empress
Eugénie of France, when she decided
the new colour flattered her. Very soon,
mauve was the necessary shade for all
the fashionable ladies in that country.
Not to be outdone, England’s Queen
Victoria also appeared in public wearing
a mauve gown, thus making it all the
rage in England as well. The dye was
bold and fast, and the public clamoured
for more. Perkin went back to the
drawing board.

Although Perkin’s fame was achieved
and fortune assured by his first
discovery, the chemist continued

his research. Among other dyes he
developed and introduced were aniline
red (1859) and aniline black (1863) and,
in the late 1860s, Perkin’s green. It is
important to note that Perkin’s synthetic
dye discoveries had outcomes far beyond
the merely decorative. The dyes also
became vital to medical research in
many ways. For instance, they were used
to stain previously invisible microbes and
bacteria, allowing researchers to identify
such bacilli as tuberculosis, cholera,

and anthrax. Artificial dyes continue to
play a crucial role today. And, in what
would have been particularly pleasing to
Perkin, their current use is in the search
for a vaccine against malaria.
```

[Original question page](assets/e3ed1f9bc1b4b5fdbc93ecd3a7786043ba26ac82ea3ed62089fc8a31e9b61403.jpg)

<!-- Source: /api/assets/cd67929b7251a10e1d7bd7f03210f3af21183344b2406b51d2d6409ebdc90ad5.jpg; PDF page 11; full -->

```text
Questions 1–7
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1–7 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 Michael Faraday was the first person to recognise Perkin’s ability as a student of chemistry.
2 Michael Faraday suggested Perkin should enrol in the Royal College of Chemistry.
3 Perkin employed August Wilhelm Hofmann as his assistant.
4 Perkin was still young when he made the discovery that made him rich and famous.
5 The trees from which quinine is derived grow only in South America.
6 Perkin hoped to manufacture a drug from a coal tar waste product.
7 Perkin was inspired by the discoveries of the famous scientist Louis Pasteur.
```

[Original question page](assets/cd67929b7251a10e1d7bd7f03210f3af21183344b2406b51d2d6409ebdc90ad5.jpg)

<!-- Source: /api/assets/4fdcae631ffbfc77770993cfc4afd16fafe36dbeb53f85dcc02ac3e0db6ec16a.jpg; PDF page 12; full -->

```text
Test 1

Questions 8-13

Answer the questions below.

Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 8-13 on your answer sheet.

8 Before Perkin’s discovery, with what group in society was the colour purple
associated?

9 What potential did Perkin immediately understand that his new dye had?

10 What was the name finally used to refer to the first colour Perkin invented?

11 What was the name of the person Perkin consulted before setting up his own dye
works?

12 In what country did Perkin’s newly invented colour first become fashionable?

13 According to the passage, which disease is now being targeted by researchers
using synthetic dyes?

20
```

[Original question page](assets/4fdcae631ffbfc77770993cfc4afd16fafe36dbeb53f85dcc02ac3e0db6ec16a.jpg)

<!-- Source: /api/assets/5e7efd6fbab5c0401185ebc54b0e4fa73a15e0452e2b6e74f6a5c1b0106c953c.jpg; PDF page 13; full -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14–26, which are based on Reading Passage 2 on the following pages.
Questions 14–17
Reading Passage 2 has five paragraphs, A–E.
Choose the correct heading for paragraphs B–E from the list of headings below.
Write the correct number, i–vii, in boxes 14–17 on your answer sheet.
List of Headings
i Seeking the transmission of radio signals from planets
ii Appropriate responses to signals from other civilisations
iii Vast distances to Earth’s closest neighbours
iv Assumptions underlying the search for extra-terrestrial intelligence
v Reasons for the search for extra-terrestrial intelligence
vi Knowledge of extra-terrestrial life forms
vii Likelihood of life on other planets
Example — Paragraph A: v
14 Paragraph B
15 Paragraph C
16 Paragraph D
17 Paragraph E
```

[Original question page](assets/5e7efd6fbab5c0401185ebc54b0e4fa73a15e0452e2b6e74f6a5c1b0106c953c.jpg)

<!-- Source: /api/assets/a2f00c34e44dd3d84087a4923b624fa7173409897b264fdac73f5c052b06fb68.jpg; PDF page 14; full -->

```text
IS THERE ANYBODY OUT THERE?
The Search for Extra-terrestrial Intelligence
Test 1

The question of whether we are alone in the
Universe has haunted humanity for centuries,
but we may now stand poised on the brink of
the answer to that question, as we search for
radio signals from other intelligent civilisations.
This search, often known by the acronym SETI
(search for extra-terrestrial intelligence), is a
difficult one. Although groups around the world
have been searching intermittently for three
decades, it is only now that we have reached
the level of technology where we can make a
determined attempt to search all nearby stars
for any sign of life.

A

The primary reason for the search is basic curiosity - the same curiosity about the natural
world that drives all pure science. We want to know whether we are alone in the Universe.
We want to know whether life evolves naturally if given the right conditions, or whether there
is something very special about the Earth to have fostered the variety of life forms that

we see around us on the planet. The simple detection of a radio signal will be sufficient to
answer this most basic of all questions. In this sense, SETI is another cog in the machinery
of pure science which is continually pushing out the horizon of our knowledge. However,
there are other reasons for being interested in whether life exists elsewhere. For example,
we have had civilisation on Earth for perhaps only a few thousand years, and the threats of
nuclear war and pollution over the last few decades have told us that our survival may be
tenuous. Will we last another two thousand years or will we wipe ourselves out? Since the
lifetime of a planet like ours is several billion years, we can expect that, if other civilisations
do survive in our galaxy, their ages will range from zero to several billion years. Thus any
other civilisation that we hear from is likely to be far older, on average, than ourselves. The
mere existence of such a civilisation will tell us that long-term survival is possible, and gives
us some cause for optimism. It is even possible that the older civilisation may pass on the
benefits of their experience in dealing with threats to survival such as nuclear war and global
pollution, and other threats that we haven't yet discovered.

B

In discussing whether we are alone, most SETI scientists adopt two ground rules. First,
UFOs (Unidentified Flying Objects) are generally ignored since most scientists don’t
consider the evidence for them to be strong enough to bear serious consideration
(although it is also important to keep an open mind in case any really convincing evidence
emerges in the future). Second, we make a very conservative assumption that we are
looking for a life form that is pretty well like us, since if it differs radically from us we may
well not recognise it as a life form, quite apart from whether we are able to communicate

22
```

[Original question page](assets/a2f00c34e44dd3d84087a4923b624fa7173409897b264fdac73f5c052b06fb68.jpg)

<!-- Source: /api/assets/1e2ca7f258e5534ed8bce6c4d92939724954de847af216570d6308b1f6306ff3.jpg; PDF page 15; full -->

```text
with it. In other words, the life form we are looking for may well have two green heads
and seven fingers, but it will nevertheless resemble us in that it should communicate with
its fellows, be interested in the Universe, live on a planet orbiting a star like our Sun, and
perhaps most restrictively, have a chemistry, like us, based on carbon and water.

C

Even when we make these assumptions, our understanding of other life forms is still
severely limited. We do not even know, for example, how many stars have planets, and we
certainly do not know how likely it is that life will arise naturally, given the right conditions.
However, when we look at the 100 billion stars in our galaxy (the Milky Way), and 100
billion galaxies in the observable Universe, it seems inconceivable that at least one of
these planets does not have a life form on it; in fact, the best educated guess we can
make, using the little that we do know about the conditions for carbon-based life, leads us
to estimate that perhaps one in 100,000 stars might have a life-bearing planet orbiting
it. That means that our nearest neighbours are perhaps 100 light years away, which is
almost next door in astronomical terms.

D

An alien civilisation could choose many different ways of sending information across the
galaxy, but many of these either require too much energy, or else are severely attenuated
while traversing the vast distances across the galaxy. It turns out that, for a given amount

of transmitted power, radio waves in the frequency range 1000 to 3000 MHz travel the
greatest distance, and so all searches to date have concentrated on looking for radio waves
in this frequency range. So far there have been a number of searches by various groups
around the world, including Australian searches using the radio telescope at Parkes, New
South Wales. Until now there have not been any detections from the few hundred stars
which have been searched. The scale of the searches has been increased dramatically since
1992, when the US Congress voted NASA $10 million per year for ten years to conduct a
thorough search for extra-terrestrial life. Much of the money in this project is being spent

on developing the special hardware needed to search many frequencies at once. The project
has two parts. One part is a targeted search using the world’s largest radio telescopes, the
American-operated telescope in Arecibo, Puerto Rico and the French telescope in Nancy

in France. This part of the project is searching the nearest 1000 likely stars with high
sensitivity for signals in the frequency range 1000 to 3000 MHz. The other part of the
project is an undirected search which is monitoring all of space with a lower sensitivity, using
the smaller antennas of NASA's Deep Space Network.

E

There is considerable debate over how we should react if we detect a signal from an alien
civilisation. Everybody agrees that we should not reply immediately. Quite apart from the
impracticality of sending a reply over such large distances at short notice, it raises a host
of ethical questions that would have to be addressed by the global community before any
reply could be sent. Would the human race face the culture shock if faced with a superior
and much older civilisation? Luckily, there is no urgency about this. The stars being
searched are hundreds of light years away, so it takes hundreds of years for their signal to
reach us, and a further few hundred years for our reply to reach them. It’s not important,
then, if there’s a delay of a few years, or decades, while the human race debates the
question of whether to reply, and perhaps carefully drafts a reply.

23
```

[Original question page](assets/1e2ca7f258e5534ed8bce6c4d92939724954de847af216570d6308b1f6306ff3.jpg)

<!-- Source: /api/assets/128b30b24adab2018ebbb87eaada1205fca01414a1f4413eed08d5554110a7ca.jpg; PDF page 16; full -->

```text
Test 1

Questions 18-20
Answer the questions below.

Choose NO MORE THAN THREE WORDS AND/OR A NUMBER from the passage for
each answer.

Write your answers in boxes 18-20 on your answer sheet.
18 What is the life expectancy of Earth?

19 What kind of signals from other intelligent civilisations are SETI scientists searching
for?

20 How many stars are the world’s most powerful radio telescopes searching?
Questions 21-26

Do the following statements agree with the views of the writer in Reading Passage 2?
In boxes 21-26 on your answer sheet, write

YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this

21. Alien civilisations may be able to help the human race to overcome serious
problems.

22 SETI scientists are trying to find a life form that resembles humans in many ways.
23 The Americans and Australians have co-operated on joint research projects.

24 So far SETI scientists have picked up radio signals from several stars.

25 The NASA project attracted criticism from some members of Congress.

26 If a signal from outer space is received, it will be important to respond promptly.

24
```

[Original question page](assets/128b30b24adab2018ebbb87eaada1205fca01414a1f4413eed08d5554110a7ca.jpg)

<!-- Source: /api/assets/cdba942e6f123d64d511197deab7b035d14db5f6d315db3621dfa1eb76d0772e.jpg; PDF page 17; full -->

```text
READING PASSAGE 3

Reading

You should spend about 20 minutes on Questions 27-40, which are based on Reading

Passage 3 below.

The history of the tortoise

If you go back far enough, everything lived
in the sea. At various points in evolutionary
history, enterprising individuals within
many different animal groups moved out
onto the land, sometimes even to the
most parched deserts, taking their own
private seawater with them in blood and
cellular fluids. In addition to the reptiles,
birds, mammals and insects which we
see all around us, other groups that have
succeeded out of water include scorpions,
snails, crustaceans such as woodlice and
land crabs, millipedes and centipedes,
spiders and various worms. And we
mustn’t forget the plants, without whose
prior invasion of the land none of the other
migrations could have happened.

Moving from water to land involved
a major redesign of every aspect of life,
including breathing and reproduction.
Nevertheless, a good number of
thoroughgoing land animals later turned
around, abandoned their hard-earned
terrestrial re-tooling, and returned to
the water again. Seals have only gone
part way back. They show us what the
intermediates might have been like, on
the way to extreme cases such as whales
and dugongs. Whales (including the small
whales we call dolphins) and dugongs,
with their close cousins the manatees,
ceased to be land creatures altogether
and reverted to the full marine habits of

their remote ancestors. They don’t even
come ashore to breed. They do, however,
still breathe air, having never developed
anything equivalent to the gills of their
earlier marine incarnation. Turtles went
back to the sea a very long time ago and,
like all vertebrate returnees to the water,
they breathe air. However, they are, in one
respect, less fully given back to the water
than whales or dugongs, for turtles still lay
their eggs on beaches.

There is evidence that all modern
turtles are descended from a terrestrial
ancestor which lived before most of the
dinosaurs. There are two key fossils
called Proganochelys quenstedti and
Palaeochersis talampayensis dating
from early dinosaur times, which appear
to be close to the ancestry of all modern
turtles and tortoises. You might wonder
how we can tell whether fossil animals
lived on land or in water, especially if
only fragments are found. Sometimes
it’s obvious. Ichthyosaurs were reptilian
contemporaries of the dinosaurs, with fins
and streamlined bodies. The fossils look
like dolphins and they surely lived like
dolphins, in the water. With turtles it is a
little less obvious. One way to tell is by
measuring the bones of their forelimbs.

Walter Joyce and Jacques Gauthier,
at Yale University, obtained three
measurements in these particular bones

25
```

[Original question page](assets/cdba942e6f123d64d511197deab7b035d14db5f6d315db3621dfa1eb76d0772e.jpg)

<!-- Source: /api/assets/973fd191eff94ec3517c92e0bf538addb5608bfd25aa10be078dd34a400cf6d2.jpg; PDF page 18; full -->

```text
Test 1

of 71 species of living turtles and tortoises.
They used a kind of triangular graph paper
to plot the three measurements against
one another. All the land tortoise species
formed a tight cluster of points in the upper
part of the triangle; all the water turtles
cluster in the lower part of the triangular
graph. There was no overlap, except when
they added some species that spend time
both in water and on land. Sure enough,
these amphibious species show up on the
triangular graph approximately half way
between the ‘wet cluster’ of sea turtles and
the ‘dry cluster’ of land tortoises. The next
step was to determine where the fossils
fell. The bones of P. quenstedti and P.
talampayensis leave us in no doubt. Their
points on the graph are right in the thick
of the dry cluster. Both these fossils were
dry-land tortoises. They come from the era
before our turtles returned to the water.
You might think, therefore, that modern
land tortoises have probably stayed on
land ever since those early terrestrial
times, as most mammals did after a few of
them went back to the sea. But apparently


not. If you draw out the family tree of

all modern turtles and tortoises, nearly
all the branches are aquatic. Today’s

land tortoises constitute a single branch,
deeply nested among branches consisting
of aquatic turtles. This suggests that
modern land tortoises have not stayed

on land continuously since the time of P.
quenstedti and P. talampayensis. Rather,
their ancestors were among those who
went back to the water, and they then re-
emerged back onto the land in (relatively)
more recent times.

Tortoises therefore represent a
remarkable double return. In common
with all mammals, reptiles and birds, their
remote ancestors were marine fish and
before that various more or less worm-like
creatures stretching back, still in the sea, to
the primeval bacteria. Later ancestors lived
on land and stayed there for a very large
number of generations. Later ancestors still
evolved back into the water and became
sea turtles. And finally they returned yet
again to the land as tortoises, some of
which now live in the driest of deserts.
```

[Original question page](assets/973fd191eff94ec3517c92e0bf538addb5608bfd25aa10be078dd34a400cf6d2.jpg)

<!-- Source: /api/assets/78ed012abaaf709731d819bcf63ecdee7f509ff613aa1bb17a1fb1818c61a713.jpg; PDF page 19; full -->

```text
Questions 27–30
Answer the questions below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 27–30 on your answer sheet.
27 What had to transfer from sea to land before any animals could migrate?
28 Which TWO processes are mentioned as those in which animals had to make big changes as they moved onto land?
29 Which physical feature, possessed by their ancestors, do whales lack?
30 Which animals might ichthyosaurs have resembled?
Questions 31–33
Do the following statements agree with the information given in Reading Passage 3?
In boxes 31–33 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
31 Turtles were among the first group of animals to migrate back to the sea.
32 It is always difficult to determine where an animal lived when its fossilised remains are incomplete.
33 The habitat of ichthyosaurs can be determined by the appearance of their fossilised remains.
```

[Original question page](assets/78ed012abaaf709731d819bcf63ecdee7f509ff613aa1bb17a1fb1818c61a713.jpg)

<!-- Source: /api/assets/343a8e9ffde137aa661028c6bf0445ff01844f2340d6665cba482d592c1b5d23.jpg; PDF page 20; full -->

```text
Questions 34–39
Complete the flow-chart below. Choose NO MORE THAN TWO WORDS AND/OR A NUMBER from the passage for each answer.
Write your answers in boxes 34–39 on your answer sheet.
Method of determining where the ancestors of turtles and tortoises come from
Step 1
71 species of living turtles and tortoises were examined and a total of (34) __________ were taken from the bones of their forelimbs.
↓
Step 2
The data was recorded on a (35) __________ (necessary for comparing the information).
Outcome: Land tortoises were represented by a dense (36) __________ of points towards the top.
Sea turtles were grouped together in the bottom part.
↓
Step 3
The same data was collected from some living (37) __________ species and added to the other results.
Outcome: The points for these species turned out to be positioned about (38) __________ up the triangle between the land tortoises and the sea turtles.
↓
Step 4
Bones of P. quenstedti and P. talampayensis were examined in a similar way and the results added.
Outcome: The position of the points indicated that both these ancient creatures were (39) __________.
```

[Original question page](assets/343a8e9ffde137aa661028c6bf0445ff01844f2340d6665cba482d592c1b5d23.jpg)

<!-- Source: /api/assets/8def21cfdcbc9d8873e54c9e5f0e08410b29f9d7204cdb7253cdf030155ddc1c.jpg; PDF page 21; full -->

```text
Reading

Question 40
Choose the correct letter, A, B, C or D.
Write the correct letter in box 40 on your answer sheet.

According to the writer, the most significant thing about tortoises is that

A they are able to adapt to life in extremely dry environments.

B their original life form was a kind of primeval bacteria.

C they have so much in common with sea turtles.

D they have made the transition from sea to land more than once.

29
```

[Original question page](assets/8def21cfdcbc9d8873e54c9e5f0e08410b29f9d7204cdb7253cdf030155ddc1c.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/57266310a5bcad3f853774107b35ecec8a11e218b67e681ac764449f167766d2.jpg; PDF page 22; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The two maps below show an island, before and after the construction of some tourist facilities.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/57266310a5bcad3f853774107b35ecec8a11e218b67e681ac764449f167766d2.jpg)

![Original figure](assets/57266310a5bcad3f853774107b35ecec8a11e218b67e681ac764449f167766d2.jpg)

### Task 2

<!-- Source: /api/assets/1f6235def2ff12daa7540cdc4dfdf78696af1109731272f580776b844e0d7caa.jpg; PDF page 23; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some experts believe that it is better for children to begin learning a foreign language at primary school rather than secondary school.

Do the advantages of this outweigh the disadvantages?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/1f6235def2ff12daa7540cdc4dfdf78696af1109731272f580776b844e0d7caa.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/01b72d7e036f4697cc7e95931732679a3f5dce1ea97726b6ed145563ebd3cf1c.jpg; PDF page 24; full -->

```text
Test 1

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Games

* What games are popular in your country? [Why?]

* Do you play any games? [Why/Why not?]

* How do people learn to play games in your country?

* Do you think it’s important for people to play games? [Why/Why not?]

PART 2
Describe an open-air or street market which you enjoyed visiting.
You should say:
where the market is
what the market sells
how big the market is
and explain why you enjoyed visiting this market.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping at markets

Example questions:

Do people in your country enjoy going to open-air markets that sell things like food or
clothes or old objects? Which type of market is more popular? Why?

Do you think markets are more suitable places for selling certain types of things? Which
ones? Why do you think this is?

Do you think young people feel the same about shopping at markets as older people?
Why is that?

Shopping in general

Example questions:

What do you think are the advantages of buying things from shops rather than markets?
How does advertising influence what people choose to buy? Is this true for everyone?

Do you think that any recent changes in the way people live have affected general
shopping habits? Why is this?

32
```

[Original question page](assets/01b72d7e036f4697cc7e95931732679a3f5dce1ea97726b6ed145563ebd3cf1c.jpg)

### Part 2

<!-- Source: /api/assets/01b72d7e036f4697cc7e95931732679a3f5dce1ea97726b6ed145563ebd3cf1c.jpg; PDF page 24; full -->

```text
Test 1

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Games

* What games are popular in your country? [Why?]

* Do you play any games? [Why/Why not?]

* How do people learn to play games in your country?

* Do you think it’s important for people to play games? [Why/Why not?]

PART 2
Describe an open-air or street market which you enjoyed visiting.
You should say:
where the market is
what the market sells
how big the market is
and explain why you enjoyed visiting this market.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping at markets

Example questions:

Do people in your country enjoy going to open-air markets that sell things like food or
clothes or old objects? Which type of market is more popular? Why?

Do you think markets are more suitable places for selling certain types of things? Which
ones? Why do you think this is?

Do you think young people feel the same about shopping at markets as older people?
Why is that?

Shopping in general

Example questions:

What do you think are the advantages of buying things from shops rather than markets?
How does advertising influence what people choose to buy? Is this true for everyone?

Do you think that any recent changes in the way people live have affected general
shopping habits? Why is this?

32
```

[Original question page](assets/01b72d7e036f4697cc7e95931732679a3f5dce1ea97726b6ed145563ebd3cf1c.jpg)

### Part 3

<!-- Source: /api/assets/01b72d7e036f4697cc7e95931732679a3f5dce1ea97726b6ed145563ebd3cf1c.jpg; PDF page 24; full -->

```text
Test 1

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE
Games

* What games are popular in your country? [Why?]

* Do you play any games? [Why/Why not?]

* How do people learn to play games in your country?

* Do you think it’s important for people to play games? [Why/Why not?]

PART 2
Describe an open-air or street market which you enjoyed visiting.
You should say:
where the market is
what the market sells
how big the market is
and explain why you enjoyed visiting this market.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Shopping at markets

Example questions:

Do people in your country enjoy going to open-air markets that sell things like food or
clothes or old objects? Which type of market is more popular? Why?

Do you think markets are more suitable places for selling certain types of things? Which
ones? Why do you think this is?

Do you think young people feel the same about shopping at markets as older people?
Why is that?

Shopping in general

Example questions:

What do you think are the advantages of buying things from shops rather than markets?
How does advertising influence what people choose to buy? Is this true for everyone?

Do you think that any recent changes in the way people live have affected general
shopping habits? Why is this?

32
```

[Original question page](assets/01b72d7e036f4697cc7e95931732679a3f5dce1ea97726b6ed145563ebd3cf1c.jpg)
