# 剑雅 9 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 144

TEST 1 LISTENING
1 answer(ing) (the) phone
2 Hillsdunne Road
3 library
4 4.45
5 national holidays
6 after 11 (o’clock)
7 clear voice
8 think quickly
9 22 October
10 Manuja
11 branch
12 west
13 clothing
14 10
15 running
16 bags
17 A
18 A
19 A
20 E
21 B
22 C
23 B
24 A
25 C
26 B
27 A
28 B
29 C
30 B
31 tide / tides
32 hearing / ear / ears
33 plants; animals / fish / fishes [both required, either order, one mark]
34 feeding
35 noise / noises
36 healthy
37 group
38 social
39 leader
40 network / networks
19–20 IN EITHER ORDER: A; E
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. answer phone / answer the phone / answering phone / answering the phone

2. Hillsdunne Road

3. library

4. 4.45 / 4:45

5. national holidays

6. after 11 / after 11 o'clock

7. clear voice

8. think quickly

9. 22 October

10. Manuja

### Part 2 · source page 144

TEST 1 LISTENING
1 answer(ing) (the) phone
2 Hillsdunne Road
3 library
4 4.45
5 national holidays
6 after 11 (o’clock)
7 clear voice
8 think quickly
9 22 October
10 Manuja
11 branch
12 west
13 clothing
14 10
15 running
16 bags
17 A
18 A
19 A
20 E
21 B
22 C
23 B
24 A
25 C
26 B
27 A
28 B
29 C
30 B
31 tide / tides
32 hearing / ear / ears
33 plants; animals / fish / fishes [both required, either order, one mark]
34 feeding
35 noise / noises
36 healthy
37 group
38 social
39 leader
40 network / networks
19–20 IN EITHER ORDER: A; E
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. branch

12. west

13. clothing

14. 10

15. running

16. bags

17. A

18. A

19. A / E

20. A / E

### Part 3 · source page 144

TEST 1 LISTENING
1 answer(ing) (the) phone
2 Hillsdunne Road
3 library
4 4.45
5 national holidays
6 after 11 (o’clock)
7 clear voice
8 think quickly
9 22 October
10 Manuja
11 branch
12 west
13 clothing
14 10
15 running
16 bags
17 A
18 A
19 A
20 E
21 B
22 C
23 B
24 A
25 C
26 B
27 A
28 B
29 C
30 B
31 tide / tides
32 hearing / ear / ears
33 plants; animals / fish / fishes [both required, either order, one mark]
34 feeding
35 noise / noises
36 healthy
37 group
38 social
39 leader
40 network / networks
19–20 IN EITHER ORDER: A; E
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. B

22. C

23. B

24. A

25. C

26. B

27. A

28. B

29. C

30. B

### Part 4 · source page 144

TEST 1 LISTENING
1 answer(ing) (the) phone
2 Hillsdunne Road
3 library
4 4.45
5 national holidays
6 after 11 (o’clock)
7 clear voice
8 think quickly
9 22 October
10 Manuja
11 branch
12 west
13 clothing
14 10
15 running
16 bags
17 A
18 A
19 A
20 E
21 B
22 C
23 B
24 A
25 C
26 B
27 A
28 B
29 C
30 B
31 tide / tides
32 hearing / ear / ears
33 plants; animals / fish / fishes [both required, either order, one mark]
34 feeding
35 noise / noises
36 healthy
37 group
38 social
39 leader
40 network / networks
19–20 IN EITHER ORDER: A; E
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. tide / tides

32. hearing / ear / ears

33. plants animals / plants, animals / plants and animals / plants & animals / plants; animals / plants/animals / plants,animals / animals plants / animals, plants / animals and plants / animals & plants / animals; plants / animals/plants / animals,plants / plants fish / plants, fish / plants and fish / plants & fish / plants; fish / plants/fish / plants,fish / fish plants / fish, plants / fish and plants / fish & plants / fish; plants / fish/plants / fish,plants / plants fishes / plants, fishes / plants and fishes / plants & fishes / plants; fishes / plants/fishes / plants,fishes / fishes plants / fishes, plants / fishes and plants / fishes & plants / fishes; plants / fishes/plants / fishes,plants

34. feeding

35. noise / noises

36. healthy

37. group

38. social

39. leader

40. network / networks

## A 类阅读

### Academic Reading · source page 145

ACADEMIC READING
1 FALSE
2 NOT GIVEN
3 FALSE
4 TRUE
5 NOT GIVEN
6 TRUE
7 NOT GIVEN
8 (the / only) rich
9 commercial (possibilities)
10 mauve (was / is)
11 (Robert) Pullar
12 (in) France
13 malaria (is)
14 iv
15 vii
16 i
17 ii
18 several billion years
19 radio (waves / signals)
20 1000 (stars)
21 YES
22 YES
23 NOT GIVEN
24 NO
25 NOT GIVEN
26 NO
27 plants
28 breathing; reproduction [both required, either order, one mark]
29 gills
30 dolphins
31 NOT GIVEN
32 FALSE
33 TRUE
34 3 measurements
35 (triangular) graph
36 cluster
37 amphibious
38 half way
39 dry-land tortoises
40 D
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. FALSE

2. NOT GIVEN

3. FALSE

4. TRUE

5. NOT GIVEN

6. TRUE

7. NOT GIVEN

8. rich / the rich / only rich

9. commercial / commercial possibilities

10. mauve / mauve was / mauve is

11. Pullar / Robert Pullar

12. France / in France

13. malaria / malaria is

14. iv

15. vii

16. i

17. ii

18. several billion years

19. radio / radio waves / radio signals

20. 1000 / 1000 stars

21. YES

22. YES

23. NOT GIVEN

24. NO

25. NOT GIVEN

26. NO

27. plants

28. breathing reproduction / breathing, reproduction / breathing and reproduction / breathing & reproduction / breathing; reproduction / breathing/reproduction / breathing,reproduction / reproduction breathing / reproduction, breathing / reproduction and breathing / reproduction & breathing / reproduction; breathing / reproduction/breathing / reproduction,breathing

29. gills

30. dolphins

31. NOT GIVEN

32. FALSE

33. TRUE

34. 3 measurements

35. graph / triangular graph

36. cluster

37. amphibious

38. half way

39. dry-land tortoises

40. D

## A 类写作

### Writing material: c9-t1-w-1

Before: an undeveloped island surrounded by sea, beach on the left/west, trees in western and eastern areas. After: reception near the centre, restaurant to its north, accommodation in two groups west and east of reception. Footpaths connect accommodation and lead to the western beach, now labelled swimming. A vehicle track links the southern pier to reception and restaurant. Boats shown at pier. Eastern trees and eastern end largely unchanged. Scale bar 100 metres. No dates or north arrow supplied; relative positions are safe, compass orientation is conventional only. Do not invent a bridge, airport, road to the beach, or facilities on the eastern tip.



### Writing material: c9-t1-w-2

Compare benefits and drawbacks of beginning a foreign language at primary rather than secondary school and give an explicit weighing judgement. Both sides are relevant; no prescribed conclusion.



## 口语
