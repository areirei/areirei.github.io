# 剑雅 7 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 157

TEST 1 LISTENING
Section 1, Questions 1–10
1 (a) taxi / cab
2 city centre / center
3 wait
4 door-to-door
5 reserve (a seat)
6 (the) 17th (of) October
7 12.30
8 Thomson
9 AC 936
10 3303 8450 2045 6837
Section 2, Questions 11–20
11 B
12 A
13 B
14 C
15 C
16 A
17 C
18 A
19 C
20 B
Section 3, Questions 21–30
21 attitude(s)
22 gender / sex
23 creativity / creativeness
24 A
25 B
26 A
27 B
28 culture
29 profit(s)
30 stress / strain
Section 4, Questions 31–40
31 April
32 children
33 repeated
34 human
35 magic
36 distance
37 culture
38 fire(s)
39 touching
40 intact
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. taxi / a taxi / cab

2. city centre / city center

3. wait

4. door-to-door

5. reserve / reserve a seat

6. 17 October / 17th October / 17th of October / the 17 October / the 17th October / the 17th of October

7. 12.30 / 12:30

8. Thomson

9. AC 936 / AC936

10. 3303 8450 2045 6837 / 3303845020456837

### Part 2 · source page 157

TEST 1 LISTENING
Section 1, Questions 1–10
1 (a) taxi / cab
2 city centre / center
3 wait
4 door-to-door
5 reserve (a seat)
6 (the) 17th (of) October
7 12.30
8 Thomson
9 AC 936
10 3303 8450 2045 6837
Section 2, Questions 11–20
11 B
12 A
13 B
14 C
15 C
16 A
17 C
18 A
19 C
20 B
Section 3, Questions 21–30
21 attitude(s)
22 gender / sex
23 creativity / creativeness
24 A
25 B
26 A
27 B
28 culture
29 profit(s)
30 stress / strain
Section 4, Questions 31–40
31 April
32 children
33 repeated
34 human
35 magic
36 distance
37 culture
38 fire(s)
39 touching
40 intact
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. B

12. A

13. B

14. C

15. C

16. A

17. C

18. A

19. C

20. B

### Part 3 · source page 157

TEST 1 LISTENING
Section 1, Questions 1–10
1 (a) taxi / cab
2 city centre / center
3 wait
4 door-to-door
5 reserve (a seat)
6 (the) 17th (of) October
7 12.30
8 Thomson
9 AC 936
10 3303 8450 2045 6837
Section 2, Questions 11–20
11 B
12 A
13 B
14 C
15 C
16 A
17 C
18 A
19 C
20 B
Section 3, Questions 21–30
21 attitude(s)
22 gender / sex
23 creativity / creativeness
24 A
25 B
26 A
27 B
28 culture
29 profit(s)
30 stress / strain
Section 4, Questions 31–40
31 April
32 children
33 repeated
34 human
35 magic
36 distance
37 culture
38 fire(s)
39 touching
40 intact
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. attitude / attitudes

22. gender / sex

23. creativity / creativeness

24. A

25. B

26. A

27. B

28. culture

29. profit / profits

30. stress / strain

### Part 4 · source page 157

TEST 1 LISTENING
Section 1, Questions 1–10
1 (a) taxi / cab
2 city centre / center
3 wait
4 door-to-door
5 reserve (a seat)
6 (the) 17th (of) October
7 12.30
8 Thomson
9 AC 936
10 3303 8450 2045 6837
Section 2, Questions 11–20
11 B
12 A
13 B
14 C
15 C
16 A
17 C
18 A
19 C
20 B
Section 3, Questions 21–30
21 attitude(s)
22 gender / sex
23 creativity / creativeness
24 A
25 B
26 A
27 B
28 culture
29 profit(s)
30 stress / strain
Section 4, Questions 31–40
31 April
32 children
33 repeated
34 human
35 magic
36 distance
37 culture
38 fire(s)
39 touching
40 intact
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. April

32. children

33. repeated

34. human

35. magic

36. distance

37. culture

38. fire / fires

39. touching

40. intact

## A 类阅读

### Academic Reading · source page 158

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 B
2 A
3 A
4 E
5 D
6 phantom
7 echoes / obstacles
8 depth
9 submarines
10 natural selection
11 radio waves / echoes
12 mathematical theories
13 zoologist
Reading Passage 2, Questions 14–26
14 xi
15 vii
16 v
17 i
18 ix
19 ii
20 x
21 NO
22 YES
23 NOT GIVEN
24 NO
25 YES
26 NOT GIVEN
Reading Passage 3, Questions 27–40
27 D
28 A
29 B
30 C
31 FALSE
32 FALSE
33 TRUE
34 NOT GIVEN
35 NOT GIVEN
36 TRUE
37 F
38 H
39 K
40 G
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. B

2. A

3. A

4. E

5. D

6. phantom

7. echoes / obstacles

8. depth

9. submarines

10. natural selection

11. radio waves / echoes

12. mathematical theories

13. zoologist

14. xi

15. vii

16. v

17. i

18. ix

19. ii

20. x

21. NO

22. YES

23. NOT GIVEN

24. NO

25. YES

26. NOT GIVEN

27. D

28. A

29. B

30. C

31. FALSE

32. FALSE

33. TRUE

34. NOT GIVEN

35. NOT GIVEN

36. TRUE

37. F

38. H

39. K

40. G

## A 类写作

### Writing material: c7-t1-w-1

Percentages of national consumer expenditure, 2002. Columns food/drinks/tobacco; clothing/footwear; leisure/education. Ireland 28.91%,6.43%,2.21%; Italy 16.36%,9.00%,3.20%; Spain 18.80%,6.51%,1.98%; Sweden 15.77%,5.40%,3.22%; Turkey 32.14%,6.63%,4.35%. Food/drinks/tobacco is the largest of the three categories in every country, leisure/education the smallest. Turkey is highest in food and leisure; Italy highest in clothing; Sweden lowest in food and clothing; Spain lowest in leisure. These are percentages, not currency or per-person totals. The three selected categories do not sum to the entire national budget.



### Writing material: c7-t1-w-2

Discuss both innate talent and the claim that teaching can develop any child into a good athlete or musician, and give an opinion. Keep the scope on the named abilities rather than an unrelated nature-versus-nurture issue.



## 口语
