# 剑雅 7 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/d14c22fd686da518f77b6f7f9e968a3aa8548b5afadb22cc2e00ade1e719c8c3.jpg; PDF page 15; full -->

```text
LISTENING SECTION 1 Questions 1–10
Questions 1–5
Complete the notes below. Write NO MORE THAN THREE WORDS for each answer.
Transport from Airport to Milton
Example: Distance — 147 miles
Options:
• Car hire — don’t want to drive
• (1) __________ — expensive
• Greyhound bus — $15 single, $27.50 return; direct to the (2) __________; long (3) __________
• Airport Shuttle — (4) __________ service; every 2 hours; $35 single, $65 return; need to (5) __________
```

[Original question page](assets/d14c22fd686da518f77b6f7f9e968a3aa8548b5afadb22cc2e00ade1e719c8c3.jpg)

<!-- Source: /api/assets/4acc696679c07be65ecaa8dda7e5fbb3b19165c6d91da7b806ffda79b251b548.jpg; PDF page 16; full -->

```text
Listening
Questions 6-10
Complete the booking form below.
Write ONE WORD AND/OR A NUMBER for each answer.
AIRPORT SHUTTLE BOOKING FORM
To: Milton
Date: 6 ...................... .. No. of passengers: One
Bus Time: 7 ........................ pm Type of ticket: Single
Name: Janet 8 ............ .......... ..
Flight No: 9 .......... ............ .. From: London Heathrow
Address in Milton: Vacation Motel,
24, Kitchener Street
Fare: $35
Credit Card No: (Visa) 10 .......... ............ ..
11
```

[Original question page](assets/4acc696679c07be65ecaa8dda7e5fbb3b19165c6d91da7b806ffda79b251b548.jpg)

### Part 2

<!-- Source: /api/assets/c3c551da4fda4238e12563ab3de828c6c9c5b0f563c97143802ab87d07fce51c.jpg; PDF page 17; full -->

```text
Test 1
SECTION 2 Questions 11-20
Questions 11-16
Choose the correct letter, A, B or C
11 PS Camping has been organising holidays for
A 15 years.
B 20 years.
C 25 years.
12 The company has most camping sites in
A France.
B Italy.
C Switzerland.
13 Which organised activity can children do every day of the week?
A football
B drama
C model making
14 Some areas of the sites have a 'no noise' rule after
A 9.30 p.m.
B 10.00 p.m.
C 10.30 p.m.
15 The holiday insurance that is offered by PS Camping
A can be charged on an annual basis.
B is included in the price of the holiday.
C must be taken out at the time of booking.
16 Customers who recommend PS Camping to friends will receive
A a free gift.
B an upgrade to a luxury tent.
C a discount.
12
```

[Original question page](assets/c3c551da4fda4238e12563ab3de828c6c9c5b0f563c97143802ab87d07fce51c.jpg)

<!-- Source: /api/assets/e10b1b933fcbd889b734863b53dd3bbbb92207becf93b41829a9e99e06dd47de.jpg; PDF page 18; full -->

```text
Questions 17–20
What does the speaker say about the following items?
Write the correct letter, A, B or C, next to questions 17–20.
A They are provided in all tents.
B They are found in central areas of the campsite.
C They are available on request.
17 barbecues __________
18 toys __________
19 cool boxes __________
20 mops and buckets __________
```

[Original question page](assets/e10b1b933fcbd889b734863b53dd3bbbb92207becf93b41829a9e99e06dd47de.jpg)

### Part 3

<!-- Source: /api/assets/580dca9df8b8ec38d1c63fa3f79f40dd73e1c624457dea935667081125c29527.jpg; PDF page 19; full -->

```text
Test 1
SECTION 3 Questions 21-30
Questions 21-23
Complete the notes below.
Write ONE WORD ONLY for each answer.
14
DIFFERENCES BETWEEN INDIVIDUALS
IN THE WORKPLACE
Individuals bring different:
.• ideas
• 21 ············· ······ ·····
• learning experiences
Work behaviour differences are due to:
• personality
• 22 ....... ............. ... .
Effects of diversity on companies:
Advantage : diversity develops 23 .......... .. ........... .
Disadvantage: diversity can cause conflict
```

[Original question page](assets/580dca9df8b8ec38d1c63fa3f79f40dd73e1c624457dea935667081125c29527.jpg)

<!-- Source: /api/assets/4b5aabf31bdbadf7e786ef6cee2f6437beb51c5002cadbab3f9c3ca47218e045.jpg; PDF page 20; full -->

```text
Listening
Questions 24-27
Choose the correct letter, A, B or C.
24 Janice thinks that employers should encourage workers who are
A potential leaders.
B open to new ideas.
C good at teamwork.
25 Janice suggests that managers may find it difficult to
A form successful groups.
B balance conflicting needs.
C deal with uncooperative workers.
26 Janice believes employers should look for job applicants who
A can think independently.
B will obey the system.
C can solve problems.
27 Janice believes managers should
A demonstrate good behaviour.
B encourage co-operation early on.
C increase financial incentives.
Questions 28-30
Complete the sentences below.
Write ONE WORD ONLY for each answer.
28 All managers need to understand their employees and recognise their company's __________.
29 When managing change, increasing the company's ........................ may be more
important than employee satisfaction.
30 During periods of change, managers may have to cope with increased amounts of
__________.
```

[Original question page](assets/4b5aabf31bdbadf7e786ef6cee2f6437beb51c5002cadbab3f9c3ca47218e045.jpg)

### Part 4

<!-- Source: /api/assets/eeff1b325259596b82c9e5ea8e770e74b6788b0d27f73dda0fc1b058c23efaaf.jpg; PDF page 21; full -->

```text
Test 1
SECTION 4 Questions 31-40
Questions 31-35
Complete the notes below.
Write ONE WORD ONLY for each answer.
SEMINAR ON ROCK ART
Preparation for fieldwork trip to Namibia in 31 ....................... .
Rock art in Namibia may be
• paintings
• engravings
Earliest explanation of engravings of animal footprints
They were used to help 32 ........................ learn about tracking
But:
• Why are the tracks usually 33 ............... ......... ?
• Why are some engravings realistic and others unrealistic?
• Why are the unrealistic animals sometimes half 34 ........................ ?
More recent explanation:
Wise men may have been trying to control wild animals with 35 ........................ .
Comment:
Earlier explanation was due to scholars over-generalising from their experience of a
different culture.
16
```

[Original question page](assets/eeff1b325259596b82c9e5ea8e770e74b6788b0d27f73dda0fc1b058c23efaaf.jpg)

<!-- Source: /api/assets/1f15cdc0a41fb5d4943e9dce265517c0d50401bde7ce638e0f2ed4967d87ef34.jpg; PDF page 22; full -->

```text
Listening
Questions 36-40
Complete the sentences below.
Write ONE WORD ONLY for each answer.
36 If you look at a site from a .................... .... , you reduce visitor pressure.
37 To camp on a site may be disrespectful to people from that ........................ .
38 Undiscovered material may be damaged by ........................ .
39 You should avoid ............... ......... or tracing rock art as it is so fragile.
40 In general, your aim is to leave the site ........................ .
17
```

[Original question page](assets/1f15cdc0a41fb5d4943e9dce265517c0d50401bde7ce638e0f2ed4967d87ef34.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/efb50bfe97192d2ead47f3d6f5e7cd59866cbbe827892d5d855751fe3a449489.jpg; PDF page 23; full -->

```text
Test 1
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage 1
below.
Let’s Go Bats
A Bats have a problem : how to find their way around in the dark. They hunt at night, and cannot
use light to help them find prey and avoid obstacles. You might say that this is a problem of their
own making, one that they could avoid simply by changing their habits and hunting by day. But
the daytime economy is already heavily exploited by other creatures such as birds. Given that
there is a living to be made at night, and given that alternative daytime trades are thoroughly
occupied, natural selection has favoured bats that make a go of the night-hunting trade . It is
probable that the nocturnal trades go way back in the ancestry of all mammals. In the time
when the dinosaurs dominated the daytime economy, our mammalian ancestors probably only
managed to survive at all because they found ways of scraping a living at night. Only after the
mysterious mass extinction of the dinosaurs about 65 million years ago were our ancestors able
to emerge into the daylight in any substantial numbers.
B Bats have an engineering problem : how to find their way and find their prey in the absence of
light. Bats are not the only creatures to face this difficulty today. Obviously the night-flying
insects that they prey on must find their way about somehow. Deep-sea fish and whales have
little or no light by day or by night. Fish and dolphins that live in extremely muddy water cannot
see because, although there is light, it is obstructed and scattered by the dirt in the water. Plenty
of other modern animals make their living in conditions where seeing is difficult or impossible.
C Given the questions of how to manoeuvre in the dark, what solutions might an engineer
consider? The first one that might occur to him is to manufacture light, to use a lantern or a
searchlight. Fireflies and some fish (usually with the help of bacteria) have the power to
manufacture their own light, but the process seems to consume a large amount of energy.
Fireflies use their light for attracting mates. This doesn't require a prohibitive amount of energy:
a male's tiny pinprick of light can be seen by a female from some distance on a dark night, since
her eyes are exposed directly to the light source itself. However, using light to find one's own
way around requires vastly more energy, since the eyes have to detect the tiny fraction of the
light that bounces off each part of the scene. The light source must therefore be immensely
18
```

[Original question page](assets/efb50bfe97192d2ead47f3d6f5e7cd59866cbbe827892d5d855751fe3a449489.jpg)

<!-- Source: /api/assets/25053271b9f8ae25c62218502efb2ed582259cb0d0a77611af1bacdef95bbc8b.jpg; PDF page 24; full -->

```text
Reading
brighter if it is to be used as a headlight to illuminate the path, than if it is to be used as a signal
to others . In any event, whether or not the reason is the energy expense, it seems to be the
case that , with the possible exception of some weird deep-sea fish, no animal apart from man
uses manufactured light to find its way about.
D What else might the engineer think of? Well, blind humans sometimes seem to have an uncanny
sense of obstacles in their path. It has been given the name 'facial vision', because blind people
have reported that it feels a bit like the sense of touch, on the face. One report tells of a totally
blind boy who could ride his tricycle at good speed round the block near his home, using facial
vision. Experiments showed that, in fact, facial vision is nothing to do with touch or the front of
the face, although the sensation may be referred to the front of the face, like the referred pain
in a phantom limb. The sensation of facial vision, it turns out, really goes in through the ears.
Blind people, without even being aware of the fact, are actually using echoes of their own
footsteps and of other sounds, to sense the presence of obstacles. Before this was discovered,
engineers had already built instruments to exploit the principle, for example to measure the
depth of the sea under a ship. After this technique had been invented, it was only a matter of
time before weapons designers adapted it for the detection of submarines. Both sides in the
Second World War relied heavily on these devices, under such codenames as Asdic (British) and
Sonar (American), as well as Radar (American) or RDF (British), which uses radio echoes rather
than sound echoes.
E The Sonar and Radar pioneers didn't know it then, but all the world now knows that bats, or
rather natural selection working on bats, had perfected the system tens of millions of years
earlier; and their 'radar' achieves feats of detection and navigation that would strike an engineer
dumb with admiration . It is technically incorrect to talk about bat 'radar', since they do not use
radio waves. It is sonar. But the underlying mathematical theories of radar and sonar are very
similar, and much of our scientific understanding of the details of what bats are doing has come
from applying radar theory to them. The American zoologist Donald Griffin, who was largely
responsible for the discovery of sonar in bats, coined the term 'echolocation ' to cover both
sonar and radar, whether used by animals or by human instruments .
19
```

[Original question page](assets/25053271b9f8ae25c62218502efb2ed582259cb0d0a77611af1bacdef95bbc8b.jpg)

<!-- Source: /api/assets/ce2daf346e4e2dd00320fc0c6ce04f5d782da2e665e1269f5acf670a8b617be1.jpg; PDF page 25; full -->

```text
Test 1
Questions 1-5
Reading Passage 1 has five paragraphs, A-E.
Which paragraph contains the following information?
Write the correct letter, A-E. in boxes 1-5 on your answer sheet.
NB You may use any letter more than once.
1 examples of wildlife other than bats which do not rely on vision to navigate by
2 how early mammals avoided dying out
3 why bats hunt in the dark
4 how a particular discovery has helped our understanding of bats
5 early military uses of echolocation
Questions 6-9
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 6-9 on your answer sheet.
Facial Vision
Blind people report that so-called 'facial vision' is comparable to the sensation of touch on the
face. In fact, the sensation is more similar to the way in which pain from a 6 ....................... .
arm or leg might be felt. The ability actually comes from perceiving 7 ........................ through
the ears. However, even before this was understood, the principle had been applied in the
design of instruments which calculated the 8 ........................ of the seabed. This was
followed by a wartime application in devices for finding 9 ........................ .
20
```

[Original question page](assets/ce2daf346e4e2dd00320fc0c6ce04f5d782da2e665e1269f5acf670a8b617be1.jpg)

<!-- Source: /api/assets/caf1ababe5291e06e073a664a4c94d1de99deb855feb4f9b2da3de822cc7e1bc.jpg; PDF page 26; full -->

```text
Reading
Questions 10-13
Complete the sentences below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 10-13 on your answer sheet.
10 Long before the invention of radar, ...................... .. had resulted in a sophisticated
radar-like system in bats.
11 Radar is an inaccurate term when referring to bats because ........................ are not used
in their navigation system.
12 Radar and sonar are based on similar ........................ .
13 The word 'echolocation' was first used by someone working as a ........................ .
21
```

[Original question page](assets/caf1ababe5291e06e073a664a4c94d1de99deb855feb4f9b2da3de822cc7e1bc.jpg)

<!-- Source: /api/assets/f271010814131aac48b58472ba1d0733fa12824b26dc52b5a1c9380554aa2811.jpg; PDF page 27; full -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14–26, which are based on Reading Passage 2 on the following pages.
Questions 14–20
Reading Passage 2 has seven paragraphs, A–H.
[Original counting error retained above: the source actually labels eight paragraphs A–H.]
Choose the correct heading for paragraphs A and C–H from the list of headings below.
Write the correct number, i–xi, in boxes 14–20 on your answer sheet.
List of Headings
i Scientists’ call for a revision of policy
ii An explanation for reduced water use
iii How a global challenge was met
iv Irrigation systems fall into disuse
v Environmental effects
vi The financial cost of recent technological improvements
vii The relevance to health
viii Addressing the concern over increasing populations
ix A surprising downward trend in demand for water
x The need to raise standards
xi A description of ancient water supplies
14 Paragraph A __________
Example: Paragraph B — iii
15 Paragraph C __________
16 Paragraph D __________
17 Paragraph E __________
18 Paragraph F __________
19 Paragraph G __________
20 Paragraph H __________
```

[Original question page](assets/f271010814131aac48b58472ba1d0733fa12824b26dc52b5a1c9380554aa2811.jpg)

<!-- Source: /api/assets/ad2e269d8e94f287cb0fce1827f58cdcd683bf5e078885abc8aea4b677efa3b7.jpg; PDF page 28; full -->

```text
Reading
MAKING EVERY DROP COUNT
A The history of human civilisation is entwined with the history of the ways we have
learned to manipulate water resources. As towns gradually expanded , water was
brought from increasingly remote sources , leading to sophisticated engineering
efforts such as dams and aqueducts . At the height of the Roman Empire, nine major
systems , with an innovative layout of pipes and well-built sewers, supplied the
occupants of Rome with as much water per person as is provided in many parts of
the industrial world today.
B During the industrial revolution and population explosion of the 19th and 20th
centuries , the demand for water rose dramatically . Unprecedented construction of
tens of thousands of monumental engineering projects designed to control floods ,
protect clean water supplies, and provide water for irrigation and hydropower
brought great benefits to hundreds of millions of people . Food production has kept
pace with soaring populations mainly because of the expansion of artificial irrigation
systems that make possible the growth of 40 % of the world 's food . Nearly one fifth
of all the electricity generated worldwide is produced by turbines spun by the power
of falling water.
C Yet there is a dark side to this picture : despite our progress, half of the world 's
population still suffers, with water services inferior to those available to the ancient
Greeks and Romans. As the United Nations report on access to water reiterated in
November 2001, more than one billion people lack access to clean drinking water ;
some two and a half billion do not have adequate sanitation services . Preventable
water-related diseases kill an estimated 10,000 to 20,000 children every day, and
the latest evidence suggests that we are falling behind in efforts to solve these
problems .
D The consequences of our water policies extend beyond jeopardising human health.
Tens of millions of people have been forced to move from their homes - often with
little warning or compensation- to make way for the reservoirs behind dams. More
than 20 %of all freshwater fish species are now threatened or endangered because
dams and water withdrawals have destroyed the free-flowing river ecosystems
where they thrive. Certain irrigation practices degrade soil quality and reduce
agricultural productivity. Groundwater aquifers* are being pumped down faster than
they are naturally replenished in parts of India, China, the USA and elsewhere . And
disputes over shared water resources have led to violence and continue to raise
local , national and even international tensions .
• underground stores of water
23
```

[Original question page](assets/ad2e269d8e94f287cb0fce1827f58cdcd683bf5e078885abc8aea4b677efa3b7.jpg)

<!-- Source: /api/assets/74f301be451b35b9e922b509cad64c6ad75857f29ba97c93e360f110d9ee4ba4.jpg; PDF page 29; full -->

```text
Test 1
E At the outset of the new millennium, however, the way resource planners think about
water is beginning to change. The focus is slowly shifting back to the provision of
basic human and environmental needs as top priority- ensuring 'some for all,'
instead of 'more for some'. Some water experts are now demanding that existing
infrastructure be used in smarter ways rather than building new facilities, which is
increasingly considered the option of last, not first, resort. This shift in philosophy
has not been universally accepted, and it comes with strong opposition from some
established water organisations . Nevertheless, it may be the only way to address
successfully the pressing problems of providing everyone with clean water to drink,
adequate water to grow food and a life free from preventable water-related illness.
F Fortunately- and unexpectedly- the demand for water is not rising as rapidly as
some predicted . As a result, the pressure to build new water infrastructures has
diminished over the past two decades . Although population, industrial output and
economic productivity have continued to soar in developed nations, the rate at
which people withdraw water from aquifers, rivers and lakes has slowed . And in a
few parts of the world, demand has actually fallen.
G What explains this remarkable turn of events? Two factors : people have figured out
how to use water more efficiently, and communities are rethinking their priorities for
water use. Throughout the first three-quarters of the 20th century, the quantity of
freshwater consumed per person doubled on average; in the USA, water
withdrawals increased tenfold while the population quadrupled . But since 1980, the
amount of water consumed per person has actually decreased, thanks to a range of
new technologies that help to conserve water in homes and industry. In 1965, for
instance, Japan used approximately 13 million gallons* of water to produce $1
million of commercial output; by 1989 this had dropped to 3:5 million gallons (even
accounting for inflation)- almost a quadrupling of water productivity. In the USA,
water withdrawals have fallen by more than 20 % from their peak in 1980.
H On the other hand, dams, aqueducts and other kinds of infrastructure will still have ·
to be built, particularly in developing countries where basic human needs have not
been met. But such projects must be built to higher specifications and with more
accountability to local people and their environment than in the past. And even in
regions where new projects seem warranted, we must find ways to meet demands
with fewer resources, respecting ecological criteria and to a smaller budget.
• 1 gallon : 4.546 litres
24
```

[Original question page](assets/74f301be451b35b9e922b509cad64c6ad75857f29ba97c93e360f110d9ee4ba4.jpg)

<!-- Source: /api/assets/8a2b6fe28e8d99eaa6d104ccda4308a69172018e84573eca9f4c7da1b2427413.jpg; PDF page 30; full -->

```text
Questions 21~26
Do the following statements agree with the information given in Reading Passage 2?
In boxes 21-26 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
Reading
21 Water use per person is higher in the industrial world than it was in Ancient Rome.
22 Feeding increasing populations is possible due primarily to improved irrigation systems.
23 Modern water systems imitate those of the ancient Greeks and Romans.
24 Industrial growth is increasing the overall demand for water.
25 Modern technologies have led to a reduction in domestic water consumption.
26 In the future, governments should maintain ownership of water infrastructures.
25
```

[Original question page](assets/8a2b6fe28e8d99eaa6d104ccda4308a69172018e84573eca9f4c7da1b2427413.jpg)

<!-- Source: /api/assets/24b921c97a05b112c43a06e1a471e64af335f8236530b0a05298cb52fd39a688.jpg; PDF page 31; full -->

```text
Test 1
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading Passage 3
below.
EDUCATING PSYCHE
Educating Psyche by Bernie Neville is a book which looks at radical new approaches to
learning, describing the effects of emotion, imagination and the unconscious on learning.
One theory discussed in the book is that proposed by George Lozanov, which focuses on
the power of suggestion.
Lozanov's instructional technique is based on the evidence that the connections made in
the brain through unconscious processing (which he calls non-specific mental reactivity)
are more durable than those made through conscious processing. Besides the laboratory
evidence for this, we know from our experience that we often remember what we have
perceived peripherally, long after we have forgotten what we set out to learn. If we think
of a book we studied months or years ago, we will find it easier to recall peripheral
details- the colour, the binding, the typeface, the table at the library where we sat while
studying it- than the content on which we were concentrating. If we think of a lecture
we listened to with great concentration, we will recall the lecturer's appearance and
mannerisms, our place in the auditorium, the failure of the air-conditioning, much more
easily than the ideas we went to learn . Even if these peripheral details are a bit elusive,
they come back readily in hypnosis or when we relive the event imaginatively, as in
psychodrama . The details of the content of the lecture, on the other hand, seem to have
gone forever.
This phenomenon can be partly attributed to the common counterproductive approach to
study (making extreme efforts to memorise, tensing muscles, inducing fatigue), but it also
simply reflects the way the brain functions. Lozanov therefore made indirect instruction
(suggestion) central to his teaching system. In suggestopedia, as he called his method,
consciousness is shifted away from the curriculum to focus on something peripheral. The
curriculum then becomes peripheral and is dealt with by the reserve capacity of the brain.
The suggestopedic approach to foreign language learning provides a good illustration. In
its most recent variant (1980), it consists of the reading of vocabulary and text while the
class is listening to music. The first session is in two parts. In the first part, the music is
classical (Mozart, Beethoven, Brahms) and the teacher reads the text slowly and solemnly,
with attention to the dynamics of the music. The students follow the text in their books.
This is followed by several minutes of silence. In the second part, they listen to baroque
music (Bach, Corelli, Handel) while the teacher reads the text in a normal speaking voice.
During this time they have their books closed. During the whole of this session, their
attention is passive; they listen to the music but make no attempt to learn the material.
Beforehand , the students have been carefully prepared for the language learning
experience. Through meeting with the staff and satisfied students they develop the
expectation that learning will be easy and pleasant and that they will successfully learn
26 .
```

[Original question page](assets/24b921c97a05b112c43a06e1a471e64af335f8236530b0a05298cb52fd39a688.jpg)

<!-- Source: /api/assets/2e297dffb56505ab5737c4a267aa30e2beaf539b98e9a88f9a3e995bbbd02edd.jpg; PDF page 32; full -->

```text
Reading
several hundred words of the foreign language during the class. In a preliminary talk, the
teacher introduces them to the material to be covered, but does not 'teach' it. Likewise,
the students are instructed not to try to learn it during this introduction.
Some hours after the two-part session, there is a follow-up class at which the students are
stimulated to recall the material presented. Once again the approach is indirect. The
students do not focus their attention on trying to remember the vocabulary, but focus on
using the language to communicate (e.g. through games or improvised dramatisations).
Such methods are not unusual in language teaching. What is distinctive in the
suggestopedic method is that they are devoted entirely to assisting recall. The 'learning'
of the material is assumed to be automatic and effortless, accomplished while listening to
music. The teacher's task is to assist the students to apply what they have learned
paraconsciously, and in doing so to make it easily accessible to consciousness. Another
difference from conventional teaching is the evidence that students can regularly learn
1000 new words of a foreign language during a suggestopedic session, as well as
grammar and idiom.
Lozanov experimented with teaching by direct suggestion during sleep, hypnosis and
trance states, but found such procedures unnecessary. Hypnosis, yoga, Silva mind-control,
religious ceremonies and faith healing are all associated with successful suggestion, but
none of their techniques seem to be essential to it. Such rituals may be seen as placebos.
Lozanov acknowledges that the ritual surrounding suggestion in his own system is also a
placebo, but maintains that without such a placebo people are unable or afraid to tap the
reserve capacity of their brains. Like any placebo, it must be dispensed with authority to
be effective. Just as a doctor calls on the full power of autocratic suggestion by insisting
that the patient take precisely this white capsule precisely three times a day before meals,
Lozanov is categoric in insisting that the suggestopedic session be conducted exactly in
the manner designated, by trained and accredited suggestopedic teachers.
While suggestopedia has gained some notoriety through success in the teaching of
modern languages, few teachers are able to emulate the spectacular results of Lozanov
and his associates. We can, perhaps, attribute mediocre results to an inadequate placebo
effect. The students have not developed the appropriate mind set. They are often not
motivated to learn through this method. They do not have enough 'faith'. They do not
see it as 'real teaching', especially as it does not seem to involve the 'work' they have
learned to believe is essential to learning .
27
```

[Original question page](assets/2e297dffb56505ab5737c4a267aa30e2beaf539b98e9a88f9a3e995bbbd02edd.jpg)

<!-- Source: /api/assets/33052bc689b1fd0f079351ac1946aefa50112dcda4e6b350190f66f513331eac.jpg; PDF page 33; full -->

```text
Test 1
Questions 27-30
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-30 on your answer sheet.
27 The book Educating Psyche is mainly concerned with
A the power of suggestion in learning.
B a particular technique for learning based on emotions.
C the effects of emotion on the imagination and the unconscious.
D ways of learning which are not traditional.
28 Lozanov's theory claims that, when we try to remember things,
A unimportant details are the easiest to recall.
B concentrating hard produces the best results.
C the most significant facts are most easily recalled.
D peripheral vision is not important.
29 In this passage, the author uses the examples of a book and a lecture to illustrate that
A both of these are important for developing concentration.
B his theory about methods of learning is valid.
C reading is a better technique for learning than listening.
D we can remember things more easily under hypnosis.
30 Lozanov claims that teachers should train students to
A memorise details of the curriculum.
B develop their own sets of indirect instructions.
C think about something other than the curriculum content.
D avoid overloading the capacity of the brain.
28
```

[Original question page](assets/33052bc689b1fd0f079351ac1946aefa50112dcda4e6b350190f66f513331eac.jpg)

<!-- Source: /api/assets/c836bc14e10e53fafadfd4dfc41daf70fffad648d2261205a30bbb9305bed611.jpg; PDF page 34; full -->

```text
Reading
Questions 31-36
Do the following statements agree with the information given in Reading Passage 3?
In boxes 31-36 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
31 In the example of suggestopedic teaching in the fourth paragraph, the only variable
that changes is the music.
32 Prior to the suggestopedia class, students are made aware that the language experience
will be demanding.
33 In the follow-up class, the teaching activities are similar to those used in conventional
classes.
34 As an indirect benefit , students notice improvements in their memory.
35 Teachers say they prefer suggestopedia to traditional approaches to language teaching.
36 Students in a suggestopedia class retain more new vocabulary than those in ordinary
classes.
Questions 37-40
Complete the summary using the list of words, A-K, below.
Write the correct letter, A-K, in boxes 37-40 on your answer sheet.
Suggestopedia uses a less direct method of suggestion than other techniques such as
hypnosis . However, Lozanov admits that a certain amount of 37 : ........... ............ is necessary
in order to convince students, even if this is just a 38 ........................ . Furthermore , if the
method is to succeed, teachers must follow a set procedure . Although Lozanov's method has
become quite 39 ........................ ' the results of most other teachers using this method have
been 40 ........... ............. .
A spectacular
D authoritarian
G unspectacular
J appropriate
B teaching
E unpopular
H placebo
K well known
C lesson
F ritual
I involved
29
```

[Original question page](assets/c836bc14e10e53fafadfd4dfc41daf70fffad648d2261205a30bbb9305bed611.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/592056f7705121d9e6072ef1aa5ed6d5dd971dce4282573c79f92311bd514d2b.jpg; PDF page 35; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The table below gives information on consumer spending on different items in five different countries in 2002.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the original figure is retained for the complete plotted data or diagram.]
```

[Original question page](assets/592056f7705121d9e6072ef1aa5ed6d5dd971dce4282573c79f92311bd514d2b.jpg)

![Original figure](assets/592056f7705121d9e6072ef1aa5ed6d5dd971dce4282573c79f92311bd514d2b.jpg)

### Task 2

<!-- Source: /api/assets/3996d67834c680e07827aa148bbb7fc062f29c4c491dda20d5a7bed90bd1fcd4.jpg; PDF page 36; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

It is generally believed that some people are born with certain talents, for instance for sport or music, and others are not. However, it is sometimes claimed that any child can be taught to become a good sports person or musician.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/3996d67834c680e07827aa148bbb7fc062f29c4c491dda20d5a7bed90bd1fcd4.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/dbfefe578cc0322423e38e91b02a2cd5fa5761313fc2026633c8caddd26aa691.jpg; PDF page 37; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Keeping in contact with people
• How do you usually contact your friends? [Why?]
• Do you prefer to contact different people in different ways? [Why?]
• Do you find it easy to keep in contact with friends and family? [Why/Why not?]
• In your country, did people in the past keep in contact in the same ways as they do today?
[Why/Why not?]
PART 2
Describe a party that you enjoyed.
You should say:
whose party it was and what it was
celebrating
where the party was held and who went to it
what people did during the party
and explain what you enjoyed about this party.
You will have to talk about the topic for
one to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if
you wish .

PART 3
Discussion topics:
Family parties
Example questions:
What are the main reasons why people organise family parties in your country?
In some places people spend a lot of money on parties that celebrate special family events. Is
this ever true in your country? Do you think this is a good trend or a bad trend?
Are there many differences between family parties and parties given by friends? Why do you
think this is?
National celebrations
Example questions:
What kinds of national celebration do you have in your country?
Who tends to enjoy national celebrations more: young people or old people? Why?
Why do you think some people think that national celebrations are a waste of government
money? Would you agree or disagree with this view? Why?
32
```

[Original question page](assets/dbfefe578cc0322423e38e91b02a2cd5fa5761313fc2026633c8caddd26aa691.jpg)

### Part 2

<!-- Source: /api/assets/dbfefe578cc0322423e38e91b02a2cd5fa5761313fc2026633c8caddd26aa691.jpg; PDF page 37; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Keeping in contact with people
• How do you usually contact your friends? [Why?]
• Do you prefer to contact different people in different ways? [Why?]
• Do you find it easy to keep in contact with friends and family? [Why/Why not?]
• In your country, did people in the past keep in contact in the same ways as they do today?
[Why/Why not?]
PART 2
Describe a party that you enjoyed.
You should say:
whose party it was and what it was
celebrating
where the party was held and who went to it
what people did during the party
and explain what you enjoyed about this party.
You will have to talk about the topic for
one to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if
you wish .

PART 3
Discussion topics:
Family parties
Example questions:
What are the main reasons why people organise family parties in your country?
In some places people spend a lot of money on parties that celebrate special family events. Is
this ever true in your country? Do you think this is a good trend or a bad trend?
Are there many differences between family parties and parties given by friends? Why do you
think this is?
National celebrations
Example questions:
What kinds of national celebration do you have in your country?
Who tends to enjoy national celebrations more: young people or old people? Why?
Why do you think some people think that national celebrations are a waste of government
money? Would you agree or disagree with this view? Why?
32
```

[Original question page](assets/dbfefe578cc0322423e38e91b02a2cd5fa5761313fc2026633c8caddd26aa691.jpg)

### Part 3

<!-- Source: /api/assets/dbfefe578cc0322423e38e91b02a2cd5fa5761313fc2026633c8caddd26aa691.jpg; PDF page 37; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Keeping in contact with people
• How do you usually contact your friends? [Why?]
• Do you prefer to contact different people in different ways? [Why?]
• Do you find it easy to keep in contact with friends and family? [Why/Why not?]
• In your country, did people in the past keep in contact in the same ways as they do today?
[Why/Why not?]
PART 2
Describe a party that you enjoyed.
You should say:
whose party it was and what it was
celebrating
where the party was held and who went to it
what people did during the party
and explain what you enjoyed about this party.
You will have to talk about the topic for
one to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if
you wish .

PART 3
Discussion topics:
Family parties
Example questions:
What are the main reasons why people organise family parties in your country?
In some places people spend a lot of money on parties that celebrate special family events. Is
this ever true in your country? Do you think this is a good trend or a bad trend?
Are there many differences between family parties and parties given by friends? Why do you
think this is?
National celebrations
Example questions:
What kinds of national celebration do you have in your country?
Who tends to enjoy national celebrations more: young people or old people? Why?
Why do you think some people think that national celebrations are a waste of government
money? Would you agree or disagree with this view? Why?
32
```

[Original question page](assets/dbfefe578cc0322423e38e91b02a2cd5fa5761313fc2026633c8caddd26aa691.jpg)
