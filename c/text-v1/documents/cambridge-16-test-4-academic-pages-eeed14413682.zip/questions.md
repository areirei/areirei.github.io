# 剑雅 16 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/94a5740bc249ffcab2486489496239ef93e20cd5804572f87167665b61d4c4d8.jpg; PDF page 76; full -->

```text
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Holiday rental
Owners’ names: Jack Fitzgerald and Shirley Fitzgerald
Granary Cottage
• available for week beginning (1) __________ May
• cost for the week: (2) £ __________
(3) __________ Cottage
• cost for the week: £480
• building was originally a (4) __________
• walk through doors from living room into a (5) __________
• several (6) __________ spaces at the front
• bathroom has a shower
• central heating and stove that burns (7) __________
• views of old (8) __________ from living room
• view of hilltop (9) __________ from the bedroom
Payment
• deposit: £144
• deadline for final payment: end of (10) __________
```

[Original question page](assets/94a5740bc249ffcab2486489496239ef93e20cd5804572f87167665b61d4c4d8.jpg)

### Part 2

<!-- Source: /api/assets/aba392776cf5199ffc84c8381ebd15da73e2d57ddc2a411dd03eb2e37d9be07c.jpg; PDF page 77; full -->

```text
Listening
PART 2 Questions 11-20
Questions 11-14
Choose the correct letter, A, B or C.




Local council report on traffic and highways
11 A survey found people's main concern about traffic in the area was
A cuts to public transport.
B poor maintenance of roads.
C changes in the type of traffic.
12 Which change will shortly be made to the cycle path next to the river?
A It will be widened.
B It will be extended.
C It will be resurfaced.
13 Plans for a pedestrian crossing have been postponed because
A the Post Office has moved.
B the proposed location is unsafe.
C funding is not available at present.
14 On Station Road, notices have been erected
A telling cyclists not to leave their bikes outside the station ticket office.
B asking motorists to switch off engines when waiting at the level crossing.
C warning pedestrians to leave enough time when crossing the railway line.
77
```

[Original question page](assets/aba392776cf5199ffc84c8381ebd15da73e2d57ddc2a411dd03eb2e37d9be07c.jpg)

<!-- Source: /api/assets/cfe8bc94298a6460719c5210943686cdb97170a6abb76608180a4dd989bc5065.jpg; PDF page 78; full -->

```text
Questions 15–20
Label the map below. Write the correct letter, A–I, next to Questions 15–20.
Recreation ground after proposed changes
[Original A–I map retained with river, field, road, community hall, trees and dashed footpath key. Use the map to answer.]
15 New car park __________
16 New cricket pitch __________
17 Children’s playground __________
18 Skateboard ramp __________
19 Pavilion __________
20 Notice board __________
```

[Original question page](assets/cfe8bc94298a6460719c5210943686cdb97170a6abb76608180a4dd989bc5065.jpg)

![Original figure](assets/cfe8bc94298a6460719c5210943686cdb97170a6abb76608180a4dd989bc5065.jpg)

### Part 3

<!-- Source: /api/assets/566e49f85e45a3060baff081255a54eda6d0526bdbdddef39f715ca829159315.jpg; PDF page 79; full -->

```text
PART 3 Questions 21–30
Questions 21–22
Choose TWO letters, A–E.
Which TWO benefits of city bike-sharing schemes do the students agree are the most important?
A reducing noise pollution
B reducing traffic congestion
C improving air quality
D encouraging health and fitness
E making cycling affordable
Questions 23–24
Choose TWO letters, A–E.
Which TWO things do the students think are necessary for successful bike-sharing schemes?
A Bikes should have a GPS system.
B The app should be easy to use.
C Public awareness should be raised.
D Only one scheme should be available.
E There should be a large network of cycle lanes.
```

[Original question page](assets/566e49f85e45a3060baff081255a54eda6d0526bdbdddef39f715ca829159315.jpg)

<!-- Source: /api/assets/cbb7a8f81b933109872e36520e9dc8f229166ac091b9438b403845461c8e2c8c.jpg; PDF page 80; full -->

```text
Questions 25–30
What is the speakers’ opinion of the bike-sharing schemes in each of the following cities?
Choose SIX answers from the box and write the correct letter, A–G, next to Questions 25–30.
Opinion of bike-sharing scheme
A They agree it has been disappointing.
B They think it should be cheaper.
C They are surprised it has been so successful.
D They agree that more investment is required.
E They think the system has been well designed.
F They disagree about the reasons for its success.
G They think it has expanded too quickly.
Cities
25 Amsterdam __________
26 Dublin __________
27 London __________
28 Buenos Aires __________
29 New York __________
30 Sydney __________
```

[Original question page](assets/cbb7a8f81b933109872e36520e9dc8f229166ac091b9438b403845461c8e2c8c.jpg)

### Part 4

<!-- Source: /api/assets/beabcf1894f734964d68d42cd357fe6e6b537a598b559a878fbd2d6e45fde32a.jpg; PDF page 81; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
THE EXTINCTION OF THE DODO BIRD
The dodo was a large flightless bird which used to inhabit the island of Mauritius.
History
• 1507 – Portuguese ships transporting (31) __________ stopped at the island to collect food and water.
• 1638 – The Dutch established a (32) __________ on the island.
• They killed the dodo birds for their meat.
• The last one was killed in 1681.
Description
• The only record we have is written descriptions and pictures (possibly unreliable).
• A Dutch painting suggests the dodo was very (33) __________.
• The only remaining soft tissue is a dried (34) __________.
• Recent studies of a dodo skeleton suggest the birds were capable of rapid (35) __________.
• It’s thought they were able to use their small wings to maintain (36) __________.
• Their (37) __________ was of average size.
• Their sense of (38) __________ enabled them to find food.
Reasons for extinction
• Hunting was probably not the main cause.
• Sailors brought dogs and monkeys.
• (39) __________ also escaped onto the island and ate the birds’ eggs.
• The arrival of farming meant the (40) __________ was destroyed.
```

[Original question page](assets/beabcf1894f734964d68d42cd357fe6e6b537a598b559a878fbd2d6e45fde32a.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/84d48956496cbe329ad2ffa07ac2ed29a345058c2ba7e62319b0864e85a33fe3.jpg; PDF page 82; full -->

```text
Test 4
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Roman tunnels
The Romans, who once controlled areas of Europe, North Africa and
Asia Minor, adopted the construction techniques of other civilizations to
build tunnels in their territories
The Persians, who lived in present-day Iran, were one of the first civilizations to build tunnels
that provided a reliable supply of water to human settlements in dry areas. In the early first
millennium BCE, they introduced the qanat method of tunnel construction, which consisted
of placing posts over a hill in a straight line, to ensure that the tunnel kept to its route, and then
digging vertical shafts down into the ground at regular intervals. Underground, workers removed
the earth from between the ends of the shafts, creating a tunnel. The excavated soil was taken up
to the surface using the shafts, which also provided ventilation during the work. Once the tunnel
was completed, it allowed water to flow from the top of a hillside down towards a canal, which
supplied water for human use. Remarkably, some qanats built by the Persians 2,700 years ago are
still in use today.
They later passed on their knowledge to the Romans, who also used the qanat method to
construct water-supply tunnels for agriculture. Roman qanat tunnels were constructed with
vertical shafts dug at intervals of between 30 and 60 meters. The shafts were equipped with
handholds and footholds to help those climbing in and out of them and were covered with a
wooden or stone lid. To ensure that the shafts were vertical, Romans hung a plumb line from a
rod placed across the top of each shaft and made sure that the weight at the end of it hung in the
center of the shaft. Plumb lines were also used to measure the depth of the shaft and to determine
the slope of the tunnel. The 5.6-kilometer-long Claudius tunnel, built in 41 CE to drain the Fucine
Lake in central Italy, had shafts that were up to 122 meters deep, took 11 years to build and
involved approximately 30,000 workers.
By the 6th century BCE, a second method of tunnel construction appeared called the counter-
excavation method, in which the tunnel was constructed from both ends. It was used to cut
through high mountains when the qanat method was not a practical alternative. This method
required greater planning and advanced knowledge of surveying, mathematics and geometry
as both ends of a tunnel had to meet correctly at the center of the mountain. Adjustments to the
direction of the tunnel also had to be made whenever builders encountered geological problems
or when it deviated from its set path. They constantly checked the tunnel’s advancing direction,
82
```

[Original question page](assets/84d48956496cbe329ad2ffa07ac2ed29a345058c2ba7e62319b0864e85a33fe3.jpg)

<!-- Source: /api/assets/2b6e66ec7e0ba321ede2676f0462eedfe7eb83d052596134b1217db6c3621b33.jpg; PDF page 83; full -->

```text
Reading
for example, by looking back at the light that penetrated through the tunnel mouth, and made
corrections whenever necessary. Large deviations could happen, and they could result in one end
of the tunnel not being usable. An inscription written on the side of a 428-meter tunnel, built by
the Romans as part of the Saldae aqueduct system in modern-day Algeria, describes how the two
teams of builders missed each other in the mountain and how the later construction of a lateral
link between both corridors corrected the initial error.
The Romans dug tunnels for their roads using the counter-excavation method, whenever they
encountered obstacles such as hills or mountains that were too high for roads to pass over.
An example is the 37-meter-long, 6-meter-high, Furlo Pass Tunnel built in Italy in 69-79 CE.
Remarkably, a modern road still uses this tunnel today. Tunnels were also built for mineral
extraction. Miners would locate a mineral vein and then pursue it with shafts and tunnels
underground. Traces of such tunnels used to mine gold can still be found at the Dolaucothi mines
in Wales. When the sole purpose of a tunnel was mineral extraction, construction required less
planning, as the tunnel route was determined by the mineral vein.
Roman tunnel projects were carefully planned and carried out. The length of time it took to
construct a tunnel depended on the method being used and the type of rock being excavated. The
qanat construction method was usually faster than the counter-excavation method as it was more
straightforward. This was because the mountain could be excavated not only from the tunnel
mouths but also from shafts. The type of rock could also influence construction times. When
the rock was hard, the Romans employed a technique called fire quenching which consisted of
heating the rock with fire, and then suddenly cooling it with cold water so that it would crack.
Progress through hard rock could be very slow, and it was not uncommon for tunnels to take
years, if not decades, to be built. Construction marks left on a Roman tunnel in Bologna show that
the rate of advance through solid rock was 30 centimeters per day. In contrast, the rate of advance
of the Claudius tunnel can be calculated at 1.4 meters per day. Most tunnels had inscriptions
showing the names of patrons who ordered construction and sometimes the name of the architect.
For example, the 1.4-kilometer Cevlik tunnel in Turkey, built to divert the floodwater threatening
the harbor of the ancient city of Seleuceia Pieria, had inscriptions on the entrance, still visible
today, that also indicate that the tunnel was started in 69 CE and was completed in 81 CE.
83
```

[Original question page](assets/2b6e66ec7e0ba321ede2676f0462eedfe7eb83d052596134b1217db6c3621b33.jpg)

<!-- Source: /api/assets/fce2df2a54e68b3075053152dcda27506f725bdbf633d9f4331664fdd40bec95.jpg; PDF page 84; full -->

```text
Questions 1–6
Label the diagrams below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–6 on your answer sheet.
The Persian Qanat Method
[Original diagram retained; arrows identify the numbered parts.]
1 __________ to direct the tunnelling
water runs into a (2) __________ used by local people
vertical shafts to remove earth and for (3) __________
Cross-section of a Roman Qanat Shaft
[Original shaft cross-section retained; rod and numbered arrows remain visible.]
4 __________ made of wood or stone
5 __________ attached to the plumb line
handholds and footholds used for (6) __________
```

[Original question page](assets/fce2df2a54e68b3075053152dcda27506f725bdbf633d9f4331664fdd40bec95.jpg)

![Original figure](assets/fce2df2a54e68b3075053152dcda27506f725bdbf633d9f4331664fdd40bec95.jpg)

<!-- Source: /api/assets/ec6e2a42abf7669aec25505d91cf53cfc673d5d55d61877e0231f01c265b2a4c.jpg; PDF page 85; full -->

```text
Reading
Questions 7-10
Do the following statements agree with the information given in Reading Passage 1?
In boxes 7-10 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
7 The counter-excavation method completely replaced the qanat method in the
6th century BCE.
8 Only experienced builders were employed to construct a tunnel using the counter-
excavation method.
9 The information about a problem that occurred during the construction of the
Saldae aqueduct system was found in an ancient book.
10 The mistake made by the builders of the Saldae aqueduct system was that the two
parts of the tunnel failed to meet.
Questions 11-13
Answer the questions below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 11-13 on your answer sheet.
11 What type of mineral were the Dolaucothi mines in Wales built to extract?
12 In addition to the patron, whose name might be carved onto a tunnel?
13 What part of Seleuceia Pieria was the Cevlik tunnel built to protect?
>/@ p.128] 85
```

[Original question page](assets/ec6e2a42abf7669aec25505d91cf53cfc673d5d55d61877e0231f01c265b2a4c.jpg)

<!-- Source: /api/assets/f5ac3d67ec6a4b1b898b0fa896f4077494f99c8a1a98b8d1de450025aa5ad9e4.jpg; PDF page 86; full -->

```text
Test 4
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Changes in reading habits
What are the implications of the way we read today?
Look around on your next plane trip. The iPad is the new pacifier for babies and toddlers. Younger
school-aged children read stories on smartphones; older kids don’t read at all, but hunch over
video games. Parents and other passengers read on tablets or skim a flotilla of email and news
feeds. Unbeknown to most of us, an invisible, game-changing transformation links everyone
in this picture: the neuronal circuit that underlies the brain’s ability to read is subtly, rapidly
changing and this has implications for everyone from the pre-reading toddler to the expert adult.
As work in neurosciences indicates, the acquisition of literacy necessitated a new circuit in our
species’ brain more than 6,000 years ago. That circuit evolved from a very simple mechanism
for decoding basic information, like the number of goats in one’s herd, to the present, highly
elaborated reading brain. My research depicts how the present reading brain enables the
development of some of our most important intellectual and affective processes: internalized
knowledge, analogical reasoning, and inference; perspective-taking and empathy; critical analysis
and the generation of insight. Research surfacing in many parts of the world now cautions that
each of these essential ‘deep reading’ processes may be under threat as we move into digital-
based modes of reading.
This is not a simple, binary issue of print versus digital reading and technological innovation. As
MIT scholar Sherry Turkle has written, we do not err as a society when we innovate but when
we ignore what we disrupt or diminish while innovating. In this hinge moment between print and
digital cultures, society needs to confront what is diminishing in the expert reading circuit, what
our children and older students are not developing, and what we can do about it.
We know from research that the reading circuit is not given to human beings through a genetic
blueprint like vision or language; it needs an environment to develop. Further, it will adapt to that
environment’s requirements — from different writing systems to the characteristics of whatever
medium is used. If the dominant medium advantages processes that are fast, multi-task oriented
and well-suited for large volumes of information, like the current digital medium, so will the
reading circuit. As UCLA psychologist Patricia Greenfield writes, the result is that less attention
and time will be allocated to slower, time-demanding deep reading processes.
Increasing reports from educators and from researchers in psychology and the humanities bear
this out. English literature scholar and teacher Mark Edmundson describes how many college
students actively avoid the classic literature of the 19th and 20th centuries in favour of something
simpler as they no longer have the patience to read longer, denser, more difficult texts. We should
86
```

[Original question page](assets/f5ac3d67ec6a4b1b898b0fa896f4077494f99c8a1a98b8d1de450025aa5ad9e4.jpg)

<!-- Source: /api/assets/e966e8c47e03b0c829e5e53e4b553069f4886124f8d332e8e5813e57d090ab2a.jpg; PDF page 87; full -->

```text
Reading
be less concerned with students’ ‘cognitive impatience’, however, than by what may underlie
it: the potential inability of large numbers of students to read with a level of critical analysis
sufficient to comprehend the complexity of thought and argument found in more demanding texts.
Multiple studies show that digital screen use may be causing a variety of troubling downstream
effects on reading comprehension in older high school and college students. In Stavanger,
Norway, psychologist Anne Mangen and her colleagues studied how high school students
comprehend the same material in different mediums. Mangen’s group asked subjects questions
about a short story whose plot had universal student appeal; half of the students read the story
on a tablet, the other half in paperback. Results indicated that students who read on print were
superior in their comprehension to screen-reading peers, particularly in their ability to sequence
detail and reconstruct the plot in chronological order.
Ziming Liu from San Jose State University has conducted a series of studies which indicate that
the ‘new norm’ in reading is skimming, involving word-spotting and browsing through the text.
Many readers now use a pattern when reading in which they sample the first line and then word-
spot through the rest of the text. When the reading brain skims like this, it reduces time allocated
to deep reading processes. In other words, we don’t have time to grasp complexity, to understand
another's feelings, to perceive beauty, and to create thoughts of the reader’s own.
The possibility that critical analysis, empathy and other deep reading processes could become
the unintended ‘collateral damage’ of our digital culture is not a straightforward binary issue
about print versus digital reading. It is about how we all have begun to read on various mediums
and how that changes not only what we read, but also the purposes for which we read. Nor is it
only about the young. The subtle atrophy of critical analysis and empathy affects us all equally. It
affects our ability to navigate a constant bombardment of information. It incentivizes a retreat to
the most familiar stores of unchecked information, which require and receive no analysis, leaving
us susceptible to false information and irrational ideas.
There’s an old rule in neuroscience that does not alter with age: use it or lose it. It is a very
hopeful principle when applied to critical thought in the reading brain because it implies choice.
The story of the changing reading brain is hardly finished. We possess both the science and the
technology to identify and redress the changes in how we read before they become entrenched. If
we work to understand exactly what we will lose, alongside the extraordinary new capacities that
the digital world has brought us, there is as much reason for excitement as caution.
87
```

[Original question page](assets/e966e8c47e03b0c829e5e53e4b553069f4886124f8d332e8e5813e57d090ab2a.jpg)

<!-- Source: /api/assets/9c13fb97f789607a6afc8278a2bb0d84792039ecd6e3e01034a409a229851254.jpg; PDF page 88; full -->

```text
Test 4
Questions 14-17
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 14-17 on your answer sheet.
14 What is the writer's main point in the first paragraph?
A Our use of technology is having a hidden effect on us.
B Technology can be used to help youngsters to read.
C Travellers should be encouraged to use technology on planes.
D Playing games is a more popular use of technology than reading.
15 What main point does Sherry Turkle make about innovation?
A Technological innovation has led to a reduction in print reading.
B We should pay attention to what might be lost when innovation occurs.
C We should encourage more young people to become involved in innovation.
D There is a difference between developing products and developing ideas.
16 What point is the writer making in the fourth paragraph?
A Humans have an inborn ability to read and write.
B Reading can be done using many different mediums.
C Writing systems make unexpected demands on the brain.
D Some brain circuits adjust to whatever is required of them.
17 According to Mark Edmundson, the attitude of college students
A has changed the way he teaches.
B has influenced what they select to read.
C does not worry him as much as it does others.
D does not match the views of the general public.
```

[Original question page](assets/9c13fb97f789607a6afc8278a2bb0d84792039ecd6e3e01034a409a229851254.jpg)

<!-- Source: /api/assets/e8cd2af54c22f8caebf4e40c1a4ededfe733d0e94fcbc38ab1b387de4791b381.jpg; PDF page 89; full -->

```text
Questions 18–22
Complete the summary using the list of words, A–H, below.
Write the correct letter, A–H, in boxes 18–22 on your answer sheet.
Studies on digital screen use
There have been many studies on digital screen use, showing some (18) __________ trends. Psychologist Anne Mangen gave high-school students a short story to read, half using digital and half using print mediums. Her team then used a question-and-answer technique to find out how (19) __________ each group’s understanding of the plot was. The findings showed a clear pattern in the responses, with those who read screens finding the order of information (20) __________ to recall.
Studies by Ziming Liu show that students are tending to read (21) __________ words and phrases in a text to save time. This approach, she says, gives the reader a superficial understanding of the (22) __________ content of material, leaving no time for thought.
A fast
B isolated
C emotional
D worrying
E many
F hard
G combined
H thorough
Questions 23–26
Do the following statements agree with the views of the writer in Reading Passage 2?
In boxes 23–26 on your answer sheet, write
YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
23 The medium we use to read can affect our choice of reading content.
24 Some age groups are more likely to lose their complex reading skills than others.
25 False information has become more widespread in today’s digital era.
26 We still have opportunities to rectify the problems that technology is presenting.
```

[Original question page](assets/e8cd2af54c22f8caebf4e40c1a4ededfe733d0e94fcbc38ab1b387de4791b381.jpg)

<!-- Source: /api/assets/ba63824d5c7535e714dff47fea06caa819d2bf434089368de5d5b938cfb80aed.jpg; PDF page 90; full -->

```text
Test 4
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 on pages 91 and 92.
Questions 27-32
Reading Passage 3 has six sections, A-F.
Choose the correct heading for each section from the list of headings below.
Write the correct number, i-viii, in boxes 27-32 on your answer sheet.
List of Headings
i An increasing divergence of attitudes towards AI
ii Reasons why we have more faith in human judgement than in AI
iii The superiority of AI projections over those made by humans
iv The process by which AI can help us make good decisions
v The advantages of involving users in AI processes
vi Widespread distrust of an AI innovation
vii Encouraging openness about how AI functions
viii A surprisingly successful AI application
27 Section A
28 Section B
29 Section C
30 Section D
31 Section E
32 Section F
90
```

[Original question page](assets/ba63824d5c7535e714dff47fea06caa819d2bf434089368de5d5b938cfb80aed.jpg)

<!-- Source: /api/assets/576eb23ce75263b42dba8780d71aed97c370d51c1e982f708572e66295e32e44.jpg; PDF page 91; full -->

```text
Reading
Attitudes towards Artificial Intelligence
A Artificial intelligence (AI) can already predict the future. Police forces are using it
to map when and where crime is likely to occur. Doctors can use it to predict when a
patient is most likely to have a heart attack or stroke. Researchers are even trying to
give AI imagination so it can plan for unexpected consequences.
Many decisions in our lives require a good forecast, and AI is almost always better
at forecasting than we are. Yet for all these technological advances, we still seem to
deeply lack confidence in AI predictions. Recent cases show that people don’t like
relying on AI and prefer to trust human experts, even if these experts are wrong.
If we want AI to really benefit people, we need to find a way to get people to trust
it. To do that, we need to understand why people are so reluctant to trust AI in the
first place.
B Take the case of Watson for Oncology, one of technology giant IBM’s
supercomputer programs. Their attempt to promote this program to cancer doctors
was a PR disaster. The AI promised to deliver top-quality recommendations on
the treatment of 12 cancers that accounted for 80% of the world’s cases. But when
doctors first interacted with Watson, they found themselves in a rather difficult
situation. On the one hand, if Watson provided guidance about a treatment that
coincided with their own opinions, physicians did not see much point in Watson’s
recommendations. The supercomputer was simply telling them what they already
knew, and these recommendations did not change the actual treatment.
On the other hand, if Watson generated a recommendation that contradicted the
experts’ opinion, doctors would typically conclude that Watson wasn’t competent.
And the machine wouldn’t be able to explain why its treatment was plausible
because its machine-learning algorithms were simply too complex to be fully
understood by humans. Consequently, this has caused even more suspicion
and disbelief, leading many doctors to ignore the seemingly outlandish AI
recommendations and stick to their own expertise.
C This is just one example of people’s lack of confidence in AI and their reluctance to
accept what AI has to offer. Trust in other people is often based on our understanding
of how others think and having experience of their reliability. This helps create
a psychological feeling of safety. AI, on the other hand, is still fairly new and
unfamiliar to most people. Even if it can be technically explained (and that’s not
always the case), AI’s decision-making process is usually too difficult for most
people to comprehend. And interacting with something we don’t understand can
cause anxiety and give us a sense that we’re losing control.
91
```

[Original question page](assets/576eb23ce75263b42dba8780d71aed97c370d51c1e982f708572e66295e32e44.jpg)

<!-- Source: /api/assets/9ab6f5b9d90e665f82a9a4834b0ad3757a69410e4654158c2601a54229a10a4c.jpg; PDF page 92; full -->

```text
Test 4
92
Many people are also simply not familiar with many instances of AI actually
working, because it often happens in the background. Instead, they are acutely
aware of instances where AI goes wrong. Embarrassing AI failures receive a
disproportionate amount of media attention, emphasising the message that we
cannot rely on technology. Machine learning is not foolproof, in part because the
humans who design it aren’t.
D Feelings about AI run deep. In a recent experiment, people from a range of
backgrounds were given various sci-fi films about AI to watch and then asked
questions about automation in everyday life. It was found that, regardless of whether
the film they watched depicted AI in a positive or negative light, simply watching
a cinematic vision of our technological future polarised the participants’ attitudes.
Optimists became more extreme in their enthusiasm for AI and sceptics became
even more guarded.
This suggests people use relevant evidence about AI in a biased manner to support
their existing attitudes, a deep-rooted human tendency known as “confirmation
bias”. As AI is represented more and more in media and entertainment, it could lead
to a society split between those who benefit from AI and those who reject it. More
pertinently, refusing to accept the advantages offered by AI could place a large group
of people at a serious disadvantage.
E Fortunately, we already have some ideas about how to improve trust in AI. Simply
having previous experience with AI can significantly improve people’s opinions
about the technology, as was found in the study mentioned above. Evidence also
suggests the more you use other technologies such as the internet, the more you
trust them.
Another solution may be to reveal more about the algorithms which AI uses and
the purposes they serve. Several high-profile social media companies and online
marketplaces already release transparency reports about government requests and
surveillance disclosures. A similar practice for AI could help people have a better
understanding of the way algorithmic decisions are made.
F Research suggests that allowing people some control over AI decision-making could
also improve trust and enable AI to learn from human experience. For example,
one study showed that when people were allowed the freedom to slightly modify an
algorithm, they felt more satisfied with its decisions, more likely to believe it was
superior and more likely to use it in the future.
We don’t need to understand the intricate inner workings of AI systems, but if
people are given a degree of responsibility for how they are implemented, they will
be more willing to accept AI into their lives.
```

[Original question page](assets/9ab6f5b9d90e665f82a9a4834b0ad3757a69410e4654158c2601a54229a10a4c.jpg)

<!-- Source: /api/assets/1bacb5ddeb6533ea5cc1e3181327c8cd153002a4dfa976ad19c0314a79ef8238.jpg; PDF page 93; full -->

```text
Questions 33–35
Choose the correct letter, A, B, C or D. Write the correct letter in boxes 33–35 on your answer sheet.
33 What is the writer doing in Section A?
A providing a solution to a concern
B justifying an opinion about an issue
C highlighting the existence of a problem
D explaining the reasons for a phenomenon
34 According to Section C, why might some people be reluctant to accept AI?
A They are afraid it will replace humans in decision-making jobs.
B Its complexity makes them feel that they are at a disadvantage.
C They would rather wait for the technology to be tested over a period of time.
D Misunderstandings about how it works make it seem more challenging than it is.
35 What does the writer say about the media in Section C of the text?
A It leads the public to be mistrustful of AI.
B It devotes an excessive amount of attention to AI.
C Its reports of incidents involving AI are often inaccurate.
D It gives the impression that AI failures are due to designer error.
```

[Original question page](assets/1bacb5ddeb6533ea5cc1e3181327c8cd153002a4dfa976ad19c0314a79ef8238.jpg)

<!-- Source: /api/assets/db1c4e51e5266bf6cba1d107653f001548f0ed8d015bf14687f684e67412f4e9.jpg; PDF page 94; full -->

```text
Test 4
Questions 36-40
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 36-40 on your answer sheet, write





94
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
36 Subjective depictions of AI in sci-fi films make people change their opinions about
automation.
37 Portrayals of AI in media and entertainment are likely to become more positive.
38 Rejection of the possibilities of AI may have a negative effect on many people’s
lives.
39 Familiarity with AI has very little impact on people's attitudes to the technology.
40 AI applications which users are able to modify are more likely to gain consumer
approval.
>/@ p. 128
```

[Original question page](assets/db1c4e51e5266bf6cba1d107653f001548f0ed8d015bf14687f684e67412f4e9.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/bb0cadd6ab5a6b38bf02d4afd5017906193552ffc03814edb09d4c86cf369514.jpg; PDF page 95; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagram below shows the process for recycling plastic bottles.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/bb0cadd6ab5a6b38bf02d4afd5017906193552ffc03814edb09d4c86cf369514.jpg)

![Original figure](assets/bb0cadd6ab5a6b38bf02d4afd5017906193552ffc03814edb09d4c86cf369514.jpg)

### Task 2

<!-- Source: /api/assets/fd8cb085d0f095aad32371c8d2456aaa652651812abd11e45fdafac74deab824.jpg; PDF page 96; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In the future all cars, buses and trucks will be driverless. The only people travelling inside these vehicles will be passengers.

Do you think the advantages of driverless vehicles outweigh the disadvantages?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/fd8cb085d0f095aad32371c8d2456aaa652651812abd11e45fdafac74deab824.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/683979771aa937d3858c6a95534c867a3e7c58e4f23956b465829034609958f7.jpg; PDF page 97; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Fast food
e What kinds of fast food have you tried? [Why/Why not?]
e Do you ever use a microwave to cook food quickly? [Why/Why not?]
e How popular are fast food restaurants where you live? [Why/Why not?]
e When would you go to a fast-food restaurant? [Why/Why not?]
PART 2
Describe some technology (e.g. an app, phone, software program) that you decided to stop using.
You should say:
when and where you got this technology
why you started using this technology
why you decided to stop using it
and explain how you feel about the decision you made.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Computer games
Example questions:
What kinds of computer games do people play in your country?
Why do people enjoy playing computer games?
Do you think that all computer games should have a minimum age for players?
Technology in the classroom
Example questions:
In what ways can technology in the classroom be helpful?
Do you agree that students are often better at using technology than their teachers?
Do you believe that computers will ever replace human teachers?
97
```

[Original question page](assets/683979771aa937d3858c6a95534c867a3e7c58e4f23956b465829034609958f7.jpg)

### Part 2

<!-- Source: /api/assets/683979771aa937d3858c6a95534c867a3e7c58e4f23956b465829034609958f7.jpg; PDF page 97; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Fast food
e What kinds of fast food have you tried? [Why/Why not?]
e Do you ever use a microwave to cook food quickly? [Why/Why not?]
e How popular are fast food restaurants where you live? [Why/Why not?]
e When would you go to a fast-food restaurant? [Why/Why not?]
PART 2
Describe some technology (e.g. an app, phone, software program) that you decided to stop using.
You should say:
when and where you got this technology
why you started using this technology
why you decided to stop using it
and explain how you feel about the decision you made.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Computer games
Example questions:
What kinds of computer games do people play in your country?
Why do people enjoy playing computer games?
Do you think that all computer games should have a minimum age for players?
Technology in the classroom
Example questions:
In what ways can technology in the classroom be helpful?
Do you agree that students are often better at using technology than their teachers?
Do you believe that computers will ever replace human teachers?
97
```

[Original question page](assets/683979771aa937d3858c6a95534c867a3e7c58e4f23956b465829034609958f7.jpg)

### Part 3

<!-- Source: /api/assets/683979771aa937d3858c6a95534c867a3e7c58e4f23956b465829034609958f7.jpg; PDF page 97; full -->

```text
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Fast food
e What kinds of fast food have you tried? [Why/Why not?]
e Do you ever use a microwave to cook food quickly? [Why/Why not?]
e How popular are fast food restaurants where you live? [Why/Why not?]
e When would you go to a fast-food restaurant? [Why/Why not?]
PART 2
Describe some technology (e.g. an app, phone, software program) that you decided to stop using.
You should say:
when and where you got this technology
why you started using this technology
why you decided to stop using it
and explain how you feel about the decision you made.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Computer games
Example questions:
What kinds of computer games do people play in your country?
Why do people enjoy playing computer games?
Do you think that all computer games should have a minimum age for players?
Technology in the classroom
Example questions:
In what ways can technology in the classroom be helpful?
Do you agree that students are often better at using technology than their teachers?
Do you believe that computers will ever replace human teachers?
97
```

[Original question page](assets/683979771aa937d3858c6a95534c867a3e7c58e4f23956b465829034609958f7.jpg)
