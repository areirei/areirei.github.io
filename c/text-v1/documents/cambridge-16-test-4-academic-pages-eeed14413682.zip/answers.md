# 剑雅 16 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 127

TEST 4 LISTENING
1 28th
2 550
3 Chervil
4 garage
5 garden
6 parking
7 wood
8 bridge
9 monument
10 March
11 C
12 A
13 B
14 B
15 C
16 F
17 A
18 I
19 E
20 H
21 B
22 C
23 B
24 C
25 C
26 F
27 D
28 E
29 B
30 A
31 spice(s)
32 colony / settlement
33 fat
34 head
35 movement
36 balance / balancing
37 brain
38 smell
39 rats
40 forest
21&22 IN EITHER ORDER: B,C
23&24 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. 28th

2. 550

3. Chervil

4. garage

5. garden

6. parking

7. wood

8. bridge

9. monument

10. March

### Part 2 · source page 127

TEST 4 LISTENING
1 28th
2 550
3 Chervil
4 garage
5 garden
6 parking
7 wood
8 bridge
9 monument
10 March
11 C
12 A
13 B
14 B
15 C
16 F
17 A
18 I
19 E
20 H
21 B
22 C
23 B
24 C
25 C
26 F
27 D
28 E
29 B
30 A
31 spice(s)
32 colony / settlement
33 fat
34 head
35 movement
36 balance / balancing
37 brain
38 smell
39 rats
40 forest
21&22 IN EITHER ORDER: B,C
23&24 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. C

12. A

13. B

14. B

15. C

16. F

17. A

18. I

19. E

20. H

### Part 3 · source page 127

TEST 4 LISTENING
1 28th
2 550
3 Chervil
4 garage
5 garden
6 parking
7 wood
8 bridge
9 monument
10 March
11 C
12 A
13 B
14 B
15 C
16 F
17 A
18 I
19 E
20 H
21 B
22 C
23 B
24 C
25 C
26 F
27 D
28 E
29 B
30 A
31 spice(s)
32 colony / settlement
33 fat
34 head
35 movement
36 balance / balancing
37 brain
38 smell
39 rats
40 forest
21&22 IN EITHER ORDER: B,C
23&24 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B / C

22. B / C

23. B / C

24. B / C

25. C

26. F

27. D

28. E

29. B

30. A

### Part 4 · source page 127

TEST 4 LISTENING
1 28th
2 550
3 Chervil
4 garage
5 garden
6 parking
7 wood
8 bridge
9 monument
10 March
11 C
12 A
13 B
14 B
15 C
16 F
17 A
18 I
19 E
20 H
21 B
22 C
23 B
24 C
25 C
26 F
27 D
28 E
29 B
30 A
31 spice(s)
32 colony / settlement
33 fat
34 head
35 movement
36 balance / balancing
37 brain
38 smell
39 rats
40 forest
21&22 IN EITHER ORDER: B,C
23&24 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. spice / spices

32. colony / settlement

33. fat

34. head

35. movement

36. balance / balancing

37. brain

38. smell

39. rats

40. forest

## A 类阅读

### Academic Reading · source page 128

TEST 4 READING
1 posts
2 canal
3 ventilation
4 lid
5 weight
6 climbing
7 FALSE
8 NOT GIVEN
9 FALSE
10 TRUE
11 gold
12 (the) architect(’s) (name)
13 (the) harbour / harbor
14 A
15 B
16 D
17 B
18 D
19 H
20 F
21 B
22 C
23 YES
24 NO
25 NOT GIVEN
26 YES
27 iii
28 vi
29 ii
30 i
31 vii
32 v
33 C
34 B
35 A
36 NO
37 NOT GIVEN
38 YES
39 NO
40 YES
If you score: 1–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. posts

2. canal

3. ventilation

4. lid

5. weight

6. climbing

7. FALSE

8. NOT GIVEN

9. FALSE

10. TRUE

11. gold

12. architect / architect name / architect's / architect's name / the architect / the architect name / the architect's / the architect's name

13. harbour / the harbour / harbor / the harbor

14. A

15. B

16. D

17. B

18. D

19. H

20. F

21. B

22. C

23. YES

24. NO

25. NOT GIVEN

26. YES

27. iii

28. vi

29. ii

30. i

31. vii

32. v

33. C

34. B

35. A

36. NO

37. NOT GIVEN

38. YES

39. NO

40. YES

## A 类写作

### Writing material: c16-t4-w-1

Nine numbered stages:1used plastic bottles deposited in recycling bin;2truck collects;3recycling centre sorts acceptable/rejected items;4accepted bottles compressed into blocks;5crushed then washed;6plastic pellets produced;7pellets heated to form raw material;8raw material shown in blocks;9end products including bottles,containers/clothing,bags,pencils. Arrow from bottles back to bin indicates potential cycle. Some items rejected at sorting, not all waste recycled. Do not swap crushing/washing or add unshown temperatures, chemical additives or claim all products repeatedly recycled.



### Writing material: c16-t4-w-2

Weigh advantages/disadvantages of driverless vehicles, covering the proposed transport scenario rather than cars alone by necessity. State comparative judgement; safety benefits or risks must be reasoned, not invented statistical research.



## 口语
