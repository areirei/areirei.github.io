# 剑雅 8 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/c6da2b862503d778c38414c0c3be770a58c8d1966d90efbd19ae65ac467ef3a8.jpg; PDF page 80; full -->

```text
Test 4
LISTENING
SECTION 1 Questions 1-10
Complete the notes below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
West Bay Hotel - details of job
Example Answer
• Newspaper advert for temporary staff
• Vacancies for 1 ....................... .
• Two shifts
• Can choose your 2 ........................ (must be the same each week)
• Pay: £5.50 per hour, including a 3 ....................... .
• A 4 ........................ is provided in the hotel
• Total weekly pay: £231
• Dress: a white shirt and 5 ........................ trousers (not supplied)
a 6 ........................ ( supplied)
• Starting date: 7 ...................... ..
• Call Jane 8 ................. · ....... (Service Manager) before 9 ...................... ..
tomorrow (Tel: 832009)
• She'll require a 10 ....................... .
81
```

[Original question page](assets/c6da2b862503d778c38414c0c3be770a58c8d1966d90efbd19ae65ac467ef3a8.jpg)

### Part 2

<!-- Source: /api/assets/0d07884975ca8c231b46a21b65dc6e6be42ca317eb63cc892b6059a9cbe6df51.jpg; PDF page 81; full -->

```text
Test4
SECTION 2
Questions 11-13
Questions 11-20
Choose the correct letter, A, B or C.
Improvements to Red Hill Suburb
11 Community groups are mainly concerned about
A pedestrian safety.
B traffic jams.
C increased pollution.
12 It has been decided that the overhead power lines will be
A extended.
B buried.
C repaired.
13 The expenses related to the power lines will be paid for by
A the council.
B the power company.
C local businesses.
82
```

[Original question page](assets/0d07884975ca8c231b46a21b65dc6e6be42ca317eb63cc892b6059a9cbe6df51.jpg)

<!-- Source: /api/assets/9da3b4d240249b16d5c2dac27252a9a2659d5110c09010290fa5362473796d4b.jpg; PDF page 82; full -->

```text
Questions 14-20
Label the map below.
Write the correct letter, A-H, next to questions 14-20.
14 trees
15 wider footpaths
16 coloured road surface
17 new sign
18 traffic lights
19 artwork
20 children's playground
Listening
83
Red Hill Improvement Plan
[Original perspective street map retained. Top road: Evelyn Street. Hill Street runs diagonally from left centre towards Evelyn Street; Carberry Street along lower left; Thomas Street across lower centre; Days Road across right centre. A marks the building at the upper end of Hill Street; B near Hill/Evelyn junction; C open space to the right of the large dark-roof building; D at lower-left end of the central terrace near Carberry/Thomas; E at lower-left end of the left terrace; F on Hill Street near its left junction; G at the upper-right end of Thomas Street; H in the central terrace area between Hill and Thomas. Letters remain candidate labels; no answer locations for14–20 supplied.]
```

[Original question page](assets/9da3b4d240249b16d5c2dac27252a9a2659d5110c09010290fa5362473796d4b.jpg)

![Original figure](assets/9da3b4d240249b16d5c2dac27252a9a2659d5110c09010290fa5362473796d4b.jpg)

### Part 3

<!-- Source: /api/assets/6c5f678ef70f95f31e6e71859d17703134c679ff00ade08268bf79c18781cc6a.jpg; PDF page 83; full -->

```text
Test4
SECTION 3
Questions 21 and 22
Questions 21-30
Choose TWO letters, A-E.
In which TWO ways is Dan financing his course?
A He is receiving money from the government.
B His family are willing to help him.
C The college is giving him a small grant.
D His local council is supporting him for a limited period.
E A former employer is providing partial funding.
Questions 23 and 24
Choose TWO letters, A-E.
Which TWO reasons does Jeannie give for deciding to leave some college clubs?
A She is not sufficiently challenged.
B The activity interferes with her studies.
C She does not have enough time.
D The activity is too demanding physically.
E She does not think she is any good at the activity.
Questions 25 and 26
Choose the correct letter, A, B or C.
25 What does Dan say about the seminars on the course?
A The other students do not give him a chance to speak.
B The seminars make him feel inferior to the other students.
C The preparation for seminars takes too much time.
26 What does Jeannie say about the tutorials on the course?
A They are an inefficient way of providing guidance.
B They are more challenging than she had expected.
C They are helping her to develop her study skills.
84
```

[Original question page](assets/6c5f678ef70f95f31e6e71859d17703134c679ff00ade08268bf79c18781cc6a.jpg)

<!-- Source: /api/assets/5dab346344a46fb03cfaa32eeca1802b61f46e50e203db19d4cf91cae9401ee2.jpg; PDF page 84; full -->

```text
Questions 27–30
Complete the flow-chart below. Choose NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
Advice on exam preparation
Make sure you know the exam requirements
↓
Find some past papers
↓
Work out your (27) __________ for revision and write them on a card
↓
Make a (28) __________ and keep it in view
↓
Divide revision into (29) __________ for each day
↓
Write one (30) __________ about each topic
↓
Practise writing some exam answers
```

[Original question page](assets/5dab346344a46fb03cfaa32eeca1802b61f46e50e203db19d4cf91cae9401ee2.jpg)

### Part 4

<!-- Source: /api/assets/896b0fe6a768a7d619aaaddcc9caea97ce180547c48ed915b9a1321a2629650d.jpg; PDF page 85; full -->

```text
Test4
SECTION 4
Questions 31-36
Questions 31-40
Australian Aboriginal Rock Paintings
Which painting styles have the following features?
Write the correct letter, A, B or C, next to questions 31-36.
Painting Styles
A Dynamic
B Yam
C Modern
Features
31 figures revealing bones
32 rounded figures
33 figures with parts missing
34 figures smaller than life size
35 sea creatures
36 plants
86
```

[Original question page](assets/896b0fe6a768a7d619aaaddcc9caea97ce180547c48ed915b9a1321a2629650d.jpg)

<!-- Source: /api/assets/4c443e40794fb56bd934fe3fe01ff670504dc4ff64f9491f1ba3114beeb9d0c4.jpg; PDF page 86; full -->

```text
Questions 37-40
Complete the notes below.
Write NO MORE THAN TWO WORDS for each answer.
Rainbow Serpent Project
Aim of project: to identify the 37 ........................ used as the
basis for the Rainbow Serpent
Yam Period
• environmental changes led to higher 38 ...................... ..
• traditional activities were affected, especially 39 ...................... ..
Rainbow Serpent image
• similar to a sea horse
• unusual because it appeared in inland areas
• symbolises 40 ........................ in Aboriginal culture
Listening
87
[Original Rainbow Serpent illustration retained.]
```

[Original question page](assets/4c443e40794fb56bd934fe3fe01ff670504dc4ff64f9491f1ba3114beeb9d0c4.jpg)

![Original figure](assets/4c443e40794fb56bd934fe3fe01ff670504dc4ff64f9491f1ba3114beeb9d0c4.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/58bdbdac4d30598215d8e2eb027f8d1c2dde6a1bbd3c9bb0e6e5c8039d65285d.jpg; PDF page 87; full -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1–13, which are based on Reading Passage 1 on the following pages.
Questions 1–5
Reading Passage 1 has six sections, A–F.
Choose the correct heading for sections B–F from the list of headings below.
Write the correct number, i–ix, in boxes 1–5 on your answer sheet.
List of Headings
i The influence of Monbusho
ii Helping less successful students
iii The success of compulsory education
iv Research findings concerning achievements in maths
v The typical format of a maths lesson
vi Comparative expenditure on maths education
vii Background to middle-years education in Japan
viii The key to Japanese successes in maths education
ix The role of homework correction
Example — Section A: iv
1 Section B
2 Section C
3 Section D
4 Section E
5 Section F
```

[Original question page](assets/58bdbdac4d30598215d8e2eb027f8d1c2dde6a1bbd3c9bb0e6e5c8039d65285d.jpg)

<!-- Source: /api/assets/8c64fc1312f0d360f13ad036e6ba41600a33f33e79d2cedb00f7e3ed842e3a1a.jpg; PDF page 88; full -->

```text
Reading
LAND OF THE RISING SUM
A Japan has a significantly better record in terms of average mathematical attainment
than England and Wales. Large sample international comparisons of pupils’
attainments since the 1960s have established that not only did Japanese pupils
at age 13 have better scores of average attainment, but there was also a larger
proportion of ‘low’ attainers in England, where, incidentally, the variation in
attainment scores was much greater. The percentage of Gross National Product
spent on education is reasonably similar in the two countries, so how is this higher
and more consistent attainment in maths achieved?
B Lower secondary schools in Japan cover three school years, from the seventh
grade (age 13) to the ninth grade (age 15). Virtually all pupils at this stage attend
state schools: only 3 per cent are in the private sector. Schools are usually modern
in design, set well back from the road and spacious inside. Classrooms are large
and pupils sit at single desks in rows. Lessons last for a standardised 50 minutes
and are always followed by a 10-minute break, which gives the pupils a chance to
let off steam. Teachers begin with a formal address and mutual bowing, and then
concentrate on whole-class teaching.
Classes are large — usually about 40 — and are unstreamed. Pupils stay in the
same class for all lessons throughout the school and develop considerable class
identity and loyalty. Pupils attend the school in their own neighbourhood, which
in theory removes ranking by school. In practice in Tokyo, because of the relative
concentration of schools, there is some competition to get into the ‘better’ school in
a particular area.
C Traditional ways of teaching form the basis of the lesson and the remarkably quiet
classes take their own notes of the points made and the examples demonstrated.
Everyone has their own copy of the textbook supplied by the central education
authority, Monbusho, as part of the concept of free compulsory education up to
the age of 15. These textbooks are, on the whole, small, presumably inexpensive to
produce, but well set out and logically developed. (One teacher was particularly
keen to introduce colour and pictures into maths textbooks: he felt this would make
them more accessible to pupils brought up in a cartoon culture.) Besides approving
textbooks, Monbusho also decides the highly centralised national curriculum and
how it is to be delivered.
D Lessons all follow the same pattern. At the beginning, the pupils put solutions
to the homework on the board, then the teachers comment, correct or elaborate
as necessary. Pupils mark their own homework: this is an important principle in
Japanese schooling as it enables pupils to see where and why they made a mistake,
so that these can be avoided in future. No one minds mistakes or ignorance as long
as you are prepared to learn from them.
```

[Original question page](assets/8c64fc1312f0d360f13ad036e6ba41600a33f33e79d2cedb00f7e3ed842e3a1a.jpg)

<!-- Source: /api/assets/9f658b433c4aafec6c0ca80150777a096e4afd8c530c6c43b2896a5103df28c7.jpg; PDF page 89; full -->

```text
Test 4

After the homework has been discussed, the teacher explains the topic of
the lesson, slowly and with a lot of repetition and elaboration. Examples are
demonstrated on the board; questions from the textbook are worked through
first with the class, and then the class is set questions from the textbook to
do individually. Only rarely are supplementary worksheets distributed in a
maths class. The impression is that the logical nature of the textbooks and their
comprehensive coverage of different types of examples, combined with the relative
homogeneity of the class, renders work sheets unnecessary. At this point, the
teacher would circulate and make sure that all the pupils were coping well.
E It is remarkable that large, mixed-ability classes could be kept together for maths
throughout all their compulsory schooling from 6 to 15. Teachers say that they
give individual help at the end of a lesson or after school, setting extra work if
necessary. In observed lessons, any strugglers would be assisted by the teacher
or quietly seek help from their neighbour. Carefully fostered class identity makes
pupils keen to help each other - anyway, it is in their interests since the class
progresses together.
This scarcely seems adequate help to enable slow learners to keep up. However,
the Japanese attitude towards education runs along the lines of ‘if you work hard
enough, you can do almost anything’. Parents are kept closely informed of their
children’s progress and will play a part in helping their children to keep up with
class, sending them to ‘Juku’ (private evening tuition) if extra help is needed and
encouraging them to work harder. It seems to work, at least for 95 per cent of the
school population.
F So what are the major contributing factors in the success of maths teaching?
Clearly, attitudes are important. Education is valued greatly in Japanese culture;
maths is recognised as an important compulsory subject throughout schooling; and
the emphasis is on hard work coupled with a focus on accuracy.
Other relevant points relate to the supportive attitude of a class towards slower
pupils, the lack of competition within a class, and the positive emphasis on learning
for oneself and improving one’s own standard. And the view of repetitively boring
lessons and learning the facts by heart, which is sometimes quoted in relation
to Japanese classes, may be unfair and unjustified. No poor maths lessons were
observed. They were mainly good and one or two were inspirational.
```

[Original question page](assets/9f658b433c4aafec6c0ca80150777a096e4afd8c530c6c43b2896a5103df28c7.jpg)

<!-- Source: /api/assets/6dd3111a604725064ed6b9d9ca862eb1c8fd53a7d8a7cb39840bfae95ec6552b.jpg; PDF page 90; full -->

```text
Reading
Questions 6-9
Do the following statements agree with the claims of the writer in Reading Passage 1?
In boxes 6-9 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
6 There is a wider range of achievement amongst English pupils studying maths than
amongst their Japanese counterparts.
7 The percentage of Gross National Product spent on education generally reflects the
level of attainment in mathematics.
8 Private schools in Japan are more modern and spacious than state-run lower
secondary schools.
9 Teachers mark homework in Japanese schools.
91
```

[Original question page](assets/6dd3111a604725064ed6b9d9ca862eb1c8fd53a7d8a7cb39840bfae95ec6552b.jpg)

<!-- Source: /api/assets/12555a1fbf183c6f6a5eeefdbbbd3292d9cbca7a2836aa457b2d3b72df0cc94e.jpg; PDF page 91; full -->

```text
Test4
Questions 10-13
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 10-13 on your answer sheet.
10 Maths textbooks in Japanese schools are
A cheap for pupils to buy.
B well organised and adapted to the needs of the pupils.
C written to be used in conjunction with TV programmes.
D not very popular with many Japanese teachers.
11 When a new maths topic is introduced,
A students answer questions on the board.
B students rely entirely on the textbook.
C it is carefully and patiently explained to the students.
D it is usual for students to use extra worksheets.
12 How do schools deal with students who experience difficulties?
A They are given appropriate supplementary tuition.
B They are encouraged to copy from other pupils.
C They are forced to explain their slow progress.
D They are placed in a mixed-ability class.
13 Why do Japanese students tend to achieve relatively high rates of success in
maths?
A It is a compulsory subject in Japan.
B They are used to working without help from others.
C Much effort is made and correct answers are emphasised.
D There is a strong emphasis on repetitive learning.
92
```

[Original question page](assets/12555a1fbf183c6f6a5eeefdbbbd3292d9cbca7a2836aa457b2d3b72df0cc94e.jpg)

<!-- Source: /api/assets/35297094e30fb16c85047b938d7e630d6e174524663d8a878ebdccdb86efdf5f.jpg; PDF page 92; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Biological control of pests
The continuous and reckless use of synthetic chemicals for the control of pests which pose a
threat to agricultural crops and human health is proving to be counter-productive. Apart from
engendering widespread ecological disorders, pesticides have contributed to the emergence of a
new breed of chemical-resistant, highly lethal superbugs.
According to a recent study by the Food and Agriculture Organisation (FAO), more than 300
species of agricultural pests have developed resistance to a wide range of potent chemicals. Not to
be left behind are the disease-spreading pests, about 100 species of which have become immune to
a variety of insecticides now in use.
One glaring disadvantage of pesticides' application is that, while destroying harmful pests, they
also wipe out many useful non-targeted organisms, which keep the growth of the pest population
in check. This results in what agroecologists call the 'treadmill syndrome'. Because of their
tremendous breeding potential and genetic diversity, many pests are known to withstand synthetic
chemicals and bear offspring with a built-in resistance to pesticides.
The havoc that the 'treadmill syndrome' can bring about is well illustrated by what happened
to cotton farmers in Central America. In the early 1940s, basking in the glory of chemical­
based intensive agriculture, the farmers avidly took to pesticides as a sure measure to boost
crop yield. The insecticide was applied eight times a year in the mid-1940s, rising to 28 in a
season in the mid-1950s, following the sudden proliferation of three new varieties of chemical­
resistant pests.
By the mid-1960s, the situation took an alarming turn with the outbreak of four more new pests,
necessitating pesticide spraying to such an extent that 50% of the financial outlay on cotton
production was accounted for by pesticides. In the early 1970s, the spraying frequently reached 70
times a season as the farmers were pushed to the wall by the invasion of genetically stronger insect
species.
Most of the pesticides in the market today remain inadequately tested for properties that cause
cancer and mutations as well as for other adverse effects on health, says a study by United States
environmental agencies. The United States National Resource Defense Council has found that
DDT was the most popular of a long list of dangerous chemicals in use.
In the face of the escalating perils from indiscriminate applications of pesticides, a more effective
and ecologically sound strategy of biological control, involving the selective use of natural enemies
of the pest population, is fast gaining popularity - though, as yet, it is a new field with limited
potential. The advantage of biological control in contrast to other methods is that it provides a
relatively low-cost, perpetual control system with a minimum of detrimental side-effects. When
handled by experts, bio-control is safe, non-polluting and self-dispersing.
93
```

[Original question page](assets/35297094e30fb16c85047b938d7e630d6e174524663d8a878ebdccdb86efdf5f.jpg)

<!-- Source: /api/assets/17d4f5d6d1b9bf94172bc2bd905ad059fd2cfbbc0a4be04c01a83e58c9742164.jpg; PDF page 93; full -->

```text
Test4
The Commonwealth Institute of Biological Control (CIBC) in Bangalore, with its global network
of research laboratories and field stations, is one of the most active, non-commercial research
agencies engaged in pest control by setting natural predators against parasites. CIBC also serves as
a clearing-house for the export and import of biological agents for pest control world-wide.
CIBC successfully used a seed-feeding weevil, native to Mexico, to control the obnoxious
parthenium weed, known to exert devious influence on agriculture and human health in both India
and Australia. Similarly the Hyderabad-based Regional Research Laboratory (RRL), supported
by CIBC, is now trying out an Argentinian weevil for the eradication of water hyacinth, another
dangerous weed, which has become a nuisance in many parts of the world. According to Mrs Kaiser
Jamil of RRL, ‘The Argentinian weevil does not attack any other plant and a pair of adult bugs
could destroy the weed in 4-5 days.' CIBC is also perfecting the technique for breeding parasites
that prey on ‘disapene scale' insects - notorious defoliants of fruit trees in the US and India.
How effectively biological control can be pressed into service is proved by the following examples.
In the late 1960s, when Sri Lanka's flourishing coconut groves were plagued by leaf-mining
hispides, a larval parasite imported from Singapore brought the pest under control. A natural
predator indigenous to India, Neodumetia sangawani, was found useful in controlling the Rhodes
grass-scale insect that was devouring forage grass in many parts of the US. By using Neochetina
bruci, a beetle native to Brazil, scientists at Kerala Agricultural University freed a 12-kilometre­
long canal from the clutches of the weed Salvinia molesta, popularly called ‘African Payal' in
Kerala. About 30,000 hectares of rice fields in Kerala are infested by this weed.
94
```

[Original question page](assets/17d4f5d6d1b9bf94172bc2bd905ad059fd2cfbbc0a4be04c01a83e58c9742164.jpg)

<!-- Source: /api/assets/89897a58d2330c772e77d482f6ed0eaced9738fe56d2b12d274ee542b5848544.jpg; PDF page 94; full -->

```text
Reading
Questions 14-17
Choose the correct letter, A, B, C, or D.
Write the correct letter in boxes 14-17 on your answer sheet.
14 The use of pesticides has contributed to
A a change in the way ecologies are classified by agroecologists.
B an imbalance in many ecologies around the world.
C the prevention of ecological disasters in some parts of the world.
D an increase in the range of ecologies which can be usefully farmed.
15 The Food and Agriculture Organisation has counted more than 300 agricultural
pests which
A are no longer responding to most pesticides in use.
B can be easily controlled through the use of pesticides.
C continue to spread disease in a wide range of crops.
D may be used as part of bio-control's replacement of pesticides.
16 Cotton farmers in Central America began to use pesticides
A because of an intensive government advertising campaign.
B in response to the appearance of new varieties of pest.
C as a result of changes in the seasons and the climate.
D to ensure more cotton was harvested from each crop.
17 By the mid-1960s, cotton farmers in Central America found that pesticides
A were wiping out 50% of the pests plaguing the crops.
B were destroying 50% of the crops they were meant to protect.
C were causing a 50% increase in the number of new pests reported.
D were costing 50% of the total amount they spent on their crops.
95
```

[Original question page](assets/89897a58d2330c772e77d482f6ed0eaced9738fe56d2b12d274ee542b5848544.jpg)

<!-- Source: /api/assets/0e695b84e342b3896328988ae16b8f84c7f554ac697e17ef0bc04061b10f51d7.jpg; PDF page 95; full -->

```text
Test4
Questions 18-21
Do the following statements agree with the claims of the writer in Reading Passage 2?
In boxes 18-21 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
18 Disease-spreading pests respond more quickly to pesticides than agricultural
pests do.
19 A number of pests are now born with an innate immunity to some pesticides.
20 Biological control entails using synthetic chemicals to try and change the genetic
make-up of the pests' offspring.
21 Bio-control is free from danger under certain circumstances.
Questions 22-26
Complete each sentence with the correct ending, A-I, below.
Write the correct letter, A-I, in boxes 22-26 on your answer sheet.
22 Disapene scale insects feed on
23 Neodumetia sangawani ate
24 Leaf-mining hispides blighted
25 An Argentinian weevil may be successful in wiping out
26 Salvinia molesta plagues
A forage grass.
B rice fields.
C coconut trees.
D fruit trees.
E water hyacinth.
F parthenium weed.
G Brazilian beetles.
H grass-scale insects.
I larval parasites.
96
```

[Original question page](assets/0e695b84e342b3896328988ae16b8f84c7f554ac697e17ef0bc04061b10f51d7.jpg)

<!-- Source: /api/assets/c6d2fb369e58a30b7e197bf86dc941a21f3314e00fef88ad27c9edc4d3f4d92c.jpg; PDF page 96; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Collecting Ant Specimens
Collecting ants can be as simple as picking up stray ones and placing them in a glass
jar, or as complicated as completing an exhaustive survey of all species present in an
area and estimating their relative abundances. The exact method used will depend on
the final purpose of the collections. For taxonomy, or classification, long series, from
a single nest, which contain all castes (workers, including majors and minors, and, if
present, queens and males) are desirable, to allow the determination of variation within
species. For ecological studies, the most important factor is collecting identifiable
samples of as many of the different species present as possible. Unfortunately, these
methods are not always compatible. The taxonomist sometimes overlooks whole species
in favour of those groups currently under study, while the ecologist often collects only
a limited number of specimens of each species, thus reducing their value for taxonomic
investigations.
To collect as wide a range of species as possible, several methods must be used. These
include hand collecting, using baits to attract the ants, ground litter sampling, and the use
of pitfall traps. Hand collecting consists of searching for ants everywhere they are likely
to occur. This includes on the ground, under rocks, logs or other objects on the ground,
in rotten wood on the ground or on trees, in vegetation, on tree trunks and under bark.
When possible, collections should be made from nests or foraging columns and at least
20 to 25 individuals collected. This will ensure that all individuals are of the same species,
and so increase their value for detailed studies. Since some species are largely nocturnal,
collecting should not be confined to daytime. Specimens are collected using an aspirator
(often called a pooter), forceps, a fine, moistened paint brush, or fingers, if the ants are
known not to sting. Individual insects are placed in plastic or glass tubes (1.5-3.0 ml
capacity for small ants, 5-8 ml for larger ants) containing 75% to 95% ethanol. Plastic tubes
with secure tops are better than glass because they are lighter, and do not break as easily if
mishandled.
Baits can be used to attract and concentrate foragers. This often increases the number of
individuals collected and attracts species that are otherwise elusive. Sugars and meats or oils
will attract different species and a range should be utilised. These baits can be placed either
on the ground or on the trunks of trees or large shrubs. When placed on the ground, baits
should be situated on small paper cards or other flat, light-coloured surfaces, or in test-tubes
or vials. This makes it easier to spot ants and to capture them before they can escape into
the surrounding leaf litter.
97
```

[Original question page](assets/c6d2fb369e58a30b7e197bf86dc941a21f3314e00fef88ad27c9edc4d3f4d92c.jpg)

<!-- Source: /api/assets/e8a53b2bf0c8e1d6b83a93dd248073fc461ea92ef15d19128723b3bfd182670a.jpg; PDF page 97; full -->

```text
Test4
Many ants are small and forage primarily in the layer of leaves and other debris on the
ground. Collecting these species by hand can be difficult. One of the most successful ways
to collect them is to gather the leaf litter in which they are foraging and extract the ants
from it. This is most commonly done by placing leaf litter on a screen over a large funnel,
often under some heat. As the leaf litter dries from above, ants (and other animals) move
downward and eventually fall out the bottom and are collected in alcohol placed below
the funnel. This method works especially well in rain forests and marshy areas. A method
of improving the catch when using a funnel is to sift the leaf litter through a coarse screen
before placing it above the funnel. This will concentrate the litter and remove larger leaves
and twigs. It will also allow more litter to be sampled when using a limited number of
funnels.
The pitfall trap is another commonly used tool for collecting ants. A pitfall trap can be any
small container placed in the ground with the top level with the surrounding surface and
filled with a preservative. Ants are collected when they fall into the trap while foraging.
The diameter of the traps can vary from about 18 mm to 10 cm and the number used can
vary from a few to several hundred. The size of the traps used is influenced largely by
personal preference (although larger sizes are generally better), while the number will
be determined by the study being undertaken. The preservative used is usually ethylene
glycol or propylene glycol, as alcohol will evaporate quickly and the traps will dry out.
One advantage of pitfall traps is that they can be used to collect over a period of time with
minimal maintenance and intervention. One disadvantage is that some species are not
collected as they either avoid the traps or do not commonly encounter them while foraging.
98
```

[Original question page](assets/e8a53b2bf0c8e1d6b83a93dd248073fc461ea92ef15d19128723b3bfd182670a.jpg)

<!-- Source: /api/assets/9c95c7c1ff471c7c83f62977a547f2a7dcfea28c910c576678b14b489a19d7ce.jpg; PDF page 98; full -->

```text
Reading
Questions 27-30
Do the following statements agree with the information given in Reading Passage 3?
In boxes 27-30 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
27 Taxonomic research involves comparing members of one group of ants.
28 New species of ant are frequently identified by taxonomists.
29 Range is the key criterion for ecological collections.
30 A single collection of ants can generally be used for both taxonomic and ecological
purposes.
Questions 31-36
Classify the following statements as referring to
A hand collecting
B using bait
C sampling ground litter
D using a pitfall trap
Write the correct letter, A, B, C or D, in boxes 31-36 on your answer sheet.
31 It is preferable to take specimens from groups of ants.
32 It is particularly effective for wet habitats.
33 It is a good method for species which are hard to find.
34 Little time and effort is required.
35 Separate containers are used for individual specimens.
36 Non-alcoholic preservative should be used.
99
```

[Original question page](assets/9c95c7c1ff471c7c83f62977a547f2a7dcfea28c910c576678b14b489a19d7ce.jpg)

<!-- Source: /api/assets/683b5aa7df8f538fd085e26a015e72dfa6c647be64544f16b09951c98d5e1395.jpg; PDF page 99; full -->

```text
Questions 37–40
Label the diagram below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 37–40 on your answer sheet.
One method of collecting ants
[Original diagram retained. Above the funnel is a roof-shaped feature pointed to by some (37) __________; (38) __________ points to the leaves/debris atop the funnel; a (39) __________ points to the horizontal dotted line across the mouth of the funnel. Printed label funnel points to the tapering structure below that line. (40) __________ points to liquid in the shallow container under its outlet. No answers supplied.]
```

[Original question page](assets/683b5aa7df8f538fd085e26a015e72dfa6c647be64544f16b09951c98d5e1395.jpg)

![Original figure](assets/683b5aa7df8f538fd085e26a015e72dfa6c647be64544f16b09951c98d5e1395.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/a0eda8fa39e28ae9c87138675f1269d4776ebcbe754f69698e1d9ce8c93d9c8c.jpg; PDF page 100; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below shows the quantities of goods transported in the UK between 1974 and 2002 by four different modes of transport.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/a0eda8fa39e28ae9c87138675f1269d4776ebcbe754f69698e1d9ce8c93d9c8c.jpg)

![Original figure](assets/a0eda8fa39e28ae9c87138675f1269d4776ebcbe754f69698e1d9ce8c93d9c8c.jpg)

### Task 2

<!-- Source: /api/assets/35ee22e7de59dc8d7a6e082c9ed7285b1816494ae522b3c6d93756ba4cfa4234.jpg; PDF page 101; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In some countries the average weight of people is increasing and their levels of health and fitness are decreasing.

What do you think are the causes of these problems and what measures could be taken to solve them?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/35ee22e7de59dc8d7a6e082c9ed7285b1816494ae522b3c6d93756ba4cfa4234.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/27af968b9e7156b88d848b8ee0f3b421b4a976fa1f5fd7a5eb4a97b70f40869c.jpg; PDF page 102; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Television
• How often do you watch television? [Why/Why not?]
• Which television channel do you usually watch? [Why?]
• Do you enjoy the advertisements on television? [Why/Why not?]
• Do you think most programmes on television are good? [Why/Why not?]
PART 2
Describe a friend of your family you remember from your childhood.
You should say:
who the person was
how your family knew this person
how often this person visited your family
and explain why you remember this person.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Friendship
Example questions:
What do you think makes someone a good friend to a whole family?
Do you think we meet different kinds of friend at different stages of our lives? In what
ways are these types of friend different?
How easy is it to make friends with people from a different age group?
Influence of friends
Example questions:
Do you think it is possible to be friends with someone if you never meet them in person?
Is this real friendship?
What kind of influence can friends have on our lives?
How important would you say it is to have friends from different cultures?
103
```

[Original question page](assets/27af968b9e7156b88d848b8ee0f3b421b4a976fa1f5fd7a5eb4a97b70f40869c.jpg)

### Part 2

<!-- Source: /api/assets/27af968b9e7156b88d848b8ee0f3b421b4a976fa1f5fd7a5eb4a97b70f40869c.jpg; PDF page 102; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Television
• How often do you watch television? [Why/Why not?]
• Which television channel do you usually watch? [Why?]
• Do you enjoy the advertisements on television? [Why/Why not?]
• Do you think most programmes on television are good? [Why/Why not?]
PART 2
Describe a friend of your family you remember from your childhood.
You should say:
who the person was
how your family knew this person
how often this person visited your family
and explain why you remember this person.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Friendship
Example questions:
What do you think makes someone a good friend to a whole family?
Do you think we meet different kinds of friend at different stages of our lives? In what
ways are these types of friend different?
How easy is it to make friends with people from a different age group?
Influence of friends
Example questions:
Do you think it is possible to be friends with someone if you never meet them in person?
Is this real friendship?
What kind of influence can friends have on our lives?
How important would you say it is to have friends from different cultures?
103
```

[Original question page](assets/27af968b9e7156b88d848b8ee0f3b421b4a976fa1f5fd7a5eb4a97b70f40869c.jpg)

### Part 3

<!-- Source: /api/assets/27af968b9e7156b88d848b8ee0f3b421b4a976fa1f5fd7a5eb4a97b70f40869c.jpg; PDF page 102; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Television
• How often do you watch television? [Why/Why not?]
• Which television channel do you usually watch? [Why?]
• Do you enjoy the advertisements on television? [Why/Why not?]
• Do you think most programmes on television are good? [Why/Why not?]
PART 2
Describe a friend of your family you remember from your childhood.
You should say:
who the person was
how your family knew this person
how often this person visited your family
and explain why you remember this person.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:
Friendship
Example questions:
What do you think makes someone a good friend to a whole family?
Do you think we meet different kinds of friend at different stages of our lives? In what
ways are these types of friend different?
How easy is it to make friends with people from a different age group?
Influence of friends
Example questions:
Do you think it is possible to be friends with someone if you never meet them in person?
Is this real friendship?
What kind of influence can friends have on our lives?
How important would you say it is to have friends from different cultures?
103
```

[Original question page](assets/27af968b9e7156b88d848b8ee0f3b421b4a976fa1f5fd7a5eb4a97b70f40869c.jpg)
