# 剑雅 8 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 157

TEST 4 LISTENING
1 waiter(s)
2 day off
3 break
4 (free) meal
5 dark (coloured / colored)
6 jacket
7 28 June
8 Urwin
9 12.00 (pm) / noon / mid-day
10 reference
11 A
12 B
13 B
14 C
15 D
16 G
17 B
18 F
19 A
20 E
21 B
22 E
23 A
24 C
25 B
26 C
27 priorities
28 timetable
29 (small) tasks
30 (single) paragraph
31 C
32 B
33 C
34 A
35 B
36 B
37 animal / creature
38 sea / water level(s)
39 hunting
40 creation
21–22 IN EITHER ORDER: B; E
23–24 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. waiter / waiters

2. day off

3. break

4. meal / free meal

5. dark / dark coloured / dark colored

6. jacket

7. 28 June

8. Urwin

9. 12.00 / 12:00 / 12.00 pm / 12.00pm / 12:00 pm / 12:00pm / noon / mid-day

10. reference

### Part 2 · source page 157

TEST 4 LISTENING
1 waiter(s)
2 day off
3 break
4 (free) meal
5 dark (coloured / colored)
6 jacket
7 28 June
8 Urwin
9 12.00 (pm) / noon / mid-day
10 reference
11 A
12 B
13 B
14 C
15 D
16 G
17 B
18 F
19 A
20 E
21 B
22 E
23 A
24 C
25 B
26 C
27 priorities
28 timetable
29 (small) tasks
30 (single) paragraph
31 C
32 B
33 C
34 A
35 B
36 B
37 animal / creature
38 sea / water level(s)
39 hunting
40 creation
21–22 IN EITHER ORDER: B; E
23–24 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. A

12. B

13. B

14. C

15. D

16. G

17. B

18. F

19. A

20. E

### Part 3 · source page 157

TEST 4 LISTENING
1 waiter(s)
2 day off
3 break
4 (free) meal
5 dark (coloured / colored)
6 jacket
7 28 June
8 Urwin
9 12.00 (pm) / noon / mid-day
10 reference
11 A
12 B
13 B
14 C
15 D
16 G
17 B
18 F
19 A
20 E
21 B
22 E
23 A
24 C
25 B
26 C
27 priorities
28 timetable
29 (small) tasks
30 (single) paragraph
31 C
32 B
33 C
34 A
35 B
36 B
37 animal / creature
38 sea / water level(s)
39 hunting
40 creation
21–22 IN EITHER ORDER: B; E
23–24 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. B / E

22. B / E

23. A / C

24. A / C

25. B

26. C

27. priorities

28. timetable

29. tasks / small tasks

30. paragraph / single paragraph

### Part 4 · source page 157

TEST 4 LISTENING
1 waiter(s)
2 day off
3 break
4 (free) meal
5 dark (coloured / colored)
6 jacket
7 28 June
8 Urwin
9 12.00 (pm) / noon / mid-day
10 reference
11 A
12 B
13 B
14 C
15 D
16 G
17 B
18 F
19 A
20 E
21 B
22 E
23 A
24 C
25 B
26 C
27 priorities
28 timetable
29 (small) tasks
30 (single) paragraph
31 C
32 B
33 C
34 A
35 B
36 B
37 animal / creature
38 sea / water level(s)
39 hunting
40 creation
21–22 IN EITHER ORDER: B; E
23–24 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. C

32. B

33. C

34. A

35. B

36. B

37. animal / creature

38. sea level / sea levels / water level / water levels

39. hunting

40. creation

## A 类阅读

### Academic Reading · source page 158

ACADEMIC READING
1 vii
2 i
3 v
4 ii
5 viii
6 YES
7 NO
8 NOT GIVEN
9 NO
10 B
11 C
12 A
13 C
14 B
15 A
16 D
17 D
18 NOT GIVEN
19 YES
20 NO
21 YES
22 D
23 H
24 C
25 E
26 B
27 TRUE
28 NOT GIVEN
29 TRUE
30 FALSE
31 A
32 C
33 B
34 D
35 A
36 D
37 heat
38 leaf litter
39 screen
40 alcohol
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. vii

2. i

3. v

4. ii

5. viii

6. YES

7. NO

8. NOT GIVEN

9. NO

10. B

11. C

12. A

13. C

14. B

15. A

16. D

17. D

18. NOT GIVEN

19. YES

20. NO

21. YES

22. D

23. H

24. C

25. E

26. B

27. TRUE

28. NOT GIVEN

29. TRUE

30. FALSE

31. A

32. C

33. B

34. D

35. A

36. D

37. heat

38. leaf litter

39. screen

40. alcohol

## A 类写作

### Writing material: c8-t4-w-1

Full original graph and legend inspected. UK,1974–2002, MILLION TONNES of goods. Four series: road short dashed, water thick dotted, rail dash-dot, pipeline solid. Approximate endpoints: road70→98; water38–40→65; rail40→41; pipeline4→22. Road remains largest throughout and rises with fluctuations. Water overtakes rail around the late1970s, stays near55–60 for much of the1980s and early1990s, falls toward50 in the late1990s, then rises to65. Rail drops to about30 in the mid1980s, recovers slightly, dips to around27 in the mid1990s, then recovers to near its initial level. Pipeline rises to around22 by the mid1990s then plateaus through2002. Pipeline is smallest throughout. Do not claim all series increase steadily or confuse tonnes with journey counts or money. All unlabelled readings are approximate.



### Writing material: c8-t4-w-2

Discuss causes of the stated weight/health/fitness problems and measures addressing them. No invented medical research or statistical evidence is required.



## 口语
