# 剑雅 5 · Test 1

Text edition · verified

## Listening

### C5-Test 1-Part 1

Listen to the recording and answer the questions in this part.
Answer the questions on the right. The transcript is available below for review.

1. Question 1 — refer to the numbered gap in the question material.
SECTION 1 QUESTION 1- 10

Question 1-4

Complete the notes below.

Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
Dreamtime travel agency

Tour Information

Example Answer

Holiday name Whale Watch Experience

Holiday Length 2 days

Type of transportation [1] ______

Maximum group size [2] ______

Next tour date [3] ______

Hotel name [4] ______

2. Question 2 — refer to the numbered gap in the question material.


3. Question 3 — refer to the numbered gap in the question material.


4. Question 4 — refer to the numbered gap in the question material.


5. Which TWO things are included in the price of the tour? (answer 1 of 2; do not repeat an option)
Questions 5 and 6

Choose TWO letters A-E.

   A. fishing trip
   B. guided bushwalk
   C. reptile park entry
   D. table tennis
   E. tennis
6. Which TWO things are included in the price of the tour? (answer 2 of 2; do not repeat an option)


   A. fishing trip
   B. guided bushwalk
   C. reptile park entry
   D. table tennis
   E. tennis
7. Question 7 — refer to the numbered gap in the question material.
Questions 7-10

Complete the sentences below.

Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
7 The tour costs $ [7] ______ .

8 Bookings must be made no later than [8] ______ days in advance.

9 A [9] ______ deposit is required.

10 The customer’s reference number is [10] ______ .

8. Question 8 — refer to the numbered gap in the question material.


9. Question 9 — refer to the numbered gap in the question material.


10. Question 10 — refer to the numbered gap in the question material.


### C5-Test 1-Part 2

Listen to the recording and answer the questions in this part.
Answer the questions on the right. The transcript is available below for review.

11. Question 11 — refer to the numbered gap in the question material.
Questions 11-19

Complete the table below.

Write NO MORE THAN THREE WORDS for each answer.

| Brand of cot | Good Points | Problems | Verdict |
| --- | --- | --- | --- |
| Baby Safe | Easy to [11] ______ | Did not have any [12] ______; Babies could trap their [13] ______ in the side bar | [14] ______ |
| Choice Cots | Easy to [15] ______ | Side did not drop down; Spaces between the bars were [16] ______ | [17] ______ |
| Mother’s Choice | Base of cot could be moved | Did not have any [18] ______; Pictures could be removed easily | [19] ______ |

12. Question 12 — refer to the numbered gap in the question material.


13. Question 13 — refer to the numbered gap in the question material.


14. Question 14 — refer to the numbered gap in the question material.


15. Question 15 — refer to the numbered gap in the question material.


16. Question 16 — refer to the numbered gap in the question material.


17. Question 17 — refer to the numbered gap in the question material.


18. Question 18 — refer to the numbered gap in the question material.


19. Question 19 — refer to the numbered gap in the question material.


20. Question 20 — refer to the numbered gap in the question material.
Question 20

Complete the notes below.

Write ONE WORD ONLY for the answer.
· Metal should not be rusted or bent
· Edges of cot should not be [20] ______

### C5-Test 1-Part 3

Listen to the recording and answer the questions in this part.
Answer the questions on the right. The transcript is available below for review.

21. Andrew has worked at the hospital for
SECTION 3 Question 21-30

Question 21-23

Choose the correct letter A, B or C.

   A. two years.
   B. three years.
   C. five years.
22. During the course Andrew’s employers will pay


   A. his fees.
   B. his living costs.
   C. his salary.
23. The part-time course lasts for


   A. one whole year.
   B. 18 months.
   C. two years.
24. Choose TWO types of coursework are required each month on the part-time course? (answer 1 of 2; do not repeat an option)
Question 24 and 25

   A. a case study
   B. an essay
   C. a survey
   D. a short report
   E. a study diary
25. Choose TWO types of coursework are required each month on the part-time course? (answer 2 of 2; do not repeat an option)


   A. a case study
   B. an essay
   C. a survey
   D. a short report
   E. a study diary
26. Question 26 — refer to the numbered gap in the question material.
Question 26-30

Complete the summary below.

Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.

Modular Courses; Students study [26] ______ during each module. A module takes [27] ______ and the work is very [28] ______ . To get a Diploma each student has to study [29] ______ and then work on [30] ______ in depth.

27. Question 27 — refer to the numbered gap in the question material.


28. Question 28 — refer to the numbered gap in the question material.


29. Question 29 — refer to the numbered gap in the question material.


30. Question 30 — refer to the numbered gap in the question material.


### C5-Test 1-Part 4

Listen to the recording and answer the questions in this part.
Answer the questions on the right. The transcript is available below for review.

31. Question 31 — refer to the numbered gap in the question material.
SECTION 4 Questions 31-40

Questions 31-35

Complete the sentences below.

Write NO MORE THAN THREE WORDS for each answer.
31 According to George Bernard Shaw, men are supposed to understand [31] ______ , economics and finance.

32 However, women are more prepared to [32] ______ about them.

33 Women tend to save for [33] ______ and a house.

34 Men tend to save for [34] ______ and for retirement.

35 Women who are left alone may have to pay for [35] ______ when they are old.

32. Question 32 — refer to the numbered gap in the question material.


33. Question 33 — refer to the numbered gap in the question material.


34. Question 34 — refer to the numbered gap in the question material.


35. Question 35 — refer to the numbered gap in the question material.


36. Question 36 — refer to the numbered gap in the question material.
Questions 36-40

Complete the summary below.

Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.

Saving for the future; Research indicates that many women only think about their financial future when a [36] ______ occurs. This is the worst time to make decisions. It is best for women to start thinking about pensions when they are in their [37] ______ A good way for women to develop their [38] ______ in dealing with financial affairs would be to attend classes in [39] ______ When investing in stocks and shares, it is suggested that women should put a high proportion of their savings in [40] ______ In such ways, women can have a comfortable, independent retirement.

37. Question 37 — refer to the numbered gap in the question material.


38. Question 38 — refer to the numbered gap in the question material.


39. Question 39 — refer to the numbered gap in the question material.


40. Question 40 — refer to the numbered gap in the question material.


## Academic Reading

### C5-Test 1-Passage 1

Read the passage and answer the questions.
Johnson’s Dictionary

For the century before Johnson’s Dictionary was published in 1775, there had been concern about the state of the English language. There was no standard way of speaking or writing and no agreement as to the best way of bringing some order to the chaos of English spelling. Dr Johnson provided the solution.

There had, of course, been dictionaries in the past, the first of these being a little book of some 120 pages, compiled by a certain Robert Cawdray, published in 1604 under the title A Table Alphabetical’ of hard usual English words’. Like the various dictionaries that came after it during the seventeenth century, Cawdray’s tended to concentrate on ‘scholarly’ words; one function of the dictionary was to enable its student to convey an impression of fine learning.

Beyond the practical need to make order out of chaos, the rise of dictionaries is associated with the rise of the English middle class, who were anxious to define and circumscribe the various worlds to conquer – lexical as well as social and commercial. It is highly appropriate that Dr Samuel Johnson, the very model of an eighteenth-century literary man, as famous in his own time as in ours, should have published his Dictionary at the very beginning of the heyday of the middle class.

Johnson was a poet and critic who raised common sense to the heights of genius. His approach to the problems that had worried writers throughout the late seventeenth and early eighteenth centuries was intensely practical. Up until his time, the task of producing a dictionary on such a large scale had seemed impossible without the establishment of an academy to make decisions about right and wrong usage. Johnson decided he did not need an academy to settle arguments about language; he would do it single-handed. Johnson signed the contract for the Dictionary with the bookseller Robert Dosley at a breakfast held at the Golden Anchor inn near Holborn Bar on 18 June 1764. He was to be paid £1,575 in instalments, and from this he took money to rent 17 Gough Square, in which he set up his ‘dictionary workshop’.

James Boswell, his biographer, described the garret where Johnson worked as ‘fitted up like a counting house’ with a long desk running down the middle at which the copying clerks would work standing up.

Johnson himself was stationed on a rickety chair at an ‘old crazy deal table’ surrounded by a chaos of borrowed books. He was also helped by six assistants, two of whom died whilst the Dictionary was still in preparation.

The work was immense; filling about eighty large notebooks (and without a library to hand). Johnson wrote the definitions of over 40,000 words, and illustrated their many meanings with some 114,000 quotations drawn from English writing on every subject, from the Elizabethans to his own time. He did not expect to achieve complete originality. Working to a deadline, he had to draw on the best of all previous dictionaries, and to make his work one of heroic synthesis. In fact, it was very much more. Unlike his predecessors, Johnson treated English very practically, as a living language, with many different shades of meaning. He adopted his definitions on the principle of English common law – according to precedent. After its publication, his Dictionary was not seriously rivalled for over a century.

After many vicissitudes the Dictionary was finally published on 15 April 1775. It was instantly recognised as a landmark throughout Europe. ‘This very noble work,’ wrote the leading Italian lexicographer, ‘will be a perpetual monument of Fame to the Author; an /honour to his own Country in particular; and a general Benefit to the republic of Letters throughout Europe.’ The fact that Johnson had taken on the Academies of Europe and matched them(everyone knew that forty French academies had taken forty years to produce the first French national dictionary) was cause for much English celebration.

Johnson had worked for nine years, ‘with little assistance of the learned, and without any patronage of the great; not in the soft obscurities of retirement, or under the shelter of academic bowers, but amidst inconvenience and distraction, in sickness and in sorrow’. For all its faults and eccentricities his two-volume work is a masterpiece and a landmark, in his own words, ‘setting the orthography, displaying the analogy, regulating the structures, and ascertaining the significations of English words’. It is the cornerstone of Standard English, an achievement which, in James Boswell’s words, ‘conferred stability on the language of his country.’

The Dictionary, together with his other writing, made Johnson famous and so well esteemed that his friends were able to prevail upon King George III to offer him a pension. From then on, he was to become the Johnson of folklore.

1. Which THREE of the following statements are true of Johnson’s Dictionary? (answer 1 of 3; do not repeat an option)
Questions 1-3

Choose THREE letters A-H.

Write your answers in boxes 1-3 on your answer sheet.

NB Your answers may be given in any order.

   A. It avoided all scholarly words.
   B. It was the only English dictionary in general use for 200 years.
   C. It was famous because of the large number of people involved.
   D. It focused mainly on language from contemporary texts.
   E. There was a time limit for its completion.
   F. It ignored work done by previous dictionary writers.
   G. It took into account subtleties of meaning.
   H. Its definitions were famous for their originality.
2. Which THREE of the following statements are true of Johnson’s Dictionary? (answer 2 of 3; do not repeat an option)


   A. It avoided all scholarly words.
   B. It was the only English dictionary in general use for 200 years.
   C. It was famous because of the large number of people involved.
   D. It focused mainly on language from contemporary texts.
   E. There was a time limit for its completion.
   F. It ignored work done by previous dictionary writers.
   G. It took into account subtleties of meaning.
   H. Its definitions were famous for their originality.
3. Which THREE of the following statements are true of Johnson’s Dictionary? (answer 3 of 3; do not repeat an option)


   A. It avoided all scholarly words.
   B. It was the only English dictionary in general use for 200 years.
   C. It was famous because of the large number of people involved.
   D. It focused mainly on language from contemporary texts.
   E. There was a time limit for its completion.
   F. It ignored work done by previous dictionary writers.
   G. It took into account subtleties of meaning.
   H. Its definitions were famous for their originality.
4. Question 4 — refer to the numbered gap in the question material.
Questions 4-7

Complete the summary.

Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 4-7 on your answer sheet.
In 1764 Dr Johnson accepted the contract to produce a dictionary. Having rented a garret, he took on a number of [4] ______, who stood at a long central desk. Johnson did not have a [5] ______ available to him, but eventually produced definitions of in excess of 40,000 words written down in 80 large notebooks. On publication, the Dictionary was immediately hailed in many European countries as a landmark. According to his biographer, James Boswell, Johnson’s principal achievement was to bring [6] ______ to English language. As a reward for his hard work, he was granted a [7] ______ by the king.

5. Question 5 — refer to the numbered gap in the question material.


6. Question 6 — refer to the numbered gap in the question material.


7. Question 7 — refer to the numbered gap in the question material.


8. The growing importance of the middle classes led to an increased demand for dictionaries.
Questions 8-13

Do the following statements agree with the information given in Reading Passage 1?

In boxes 8-13 on your answer sheet, write

TRUE if the statement agrees with the information

FALSE if the statement contradicts the information

NOT GIVEN if there is no information on this

9. Johnson has become more well known since his death.


10. Johnson had been planning to write a dictionary for several years.


11. Johnson set up an academy to help with the writing of his Dictionary.


12. Johnson only received payment for his Dictionary on its completion.


13. Not all of the assistants survived to see the publication of the Dictionary.


### C5-Test 1-Passage 2

Read the passage and answer the questions.
Nature or Nurture?

A

A few years ago, in one of the most fascinating and disturbing experiments in behavioural psychology, Stanley Milgram of Yale University tested 40 subjects from all walks of life for their willingness to obey instructions given by a ‘leader’ in a situation in which the subjects might feel a personal distaste for the actions they were called upon to perform. Specifically, Milgram told each volunteer ‘teacher-subject’ that the experiment was in the noble cause of education, and was designed to test whether or not punishing pupils for their mistakes would have a positive effect on the pupils’ ability to learn.

B

Milgram’s experimental set-up involved placing the teacher-subject before a panel of thirty switches with labels ranging from ’15 volts of electricity (slight shock)’ to ‘450 volts(danger – severe shock)’ in steps of 15 volts each. The teacher-subject was told that whenever the pupil gave the wrong answer to a question, a shock was to be administered, beginning at the lowest level and increasing in severity with each successive wrong answer. The supposed ‘pupil’ was in reality an actor hired by Milgram to simulate receiving the shocks by emitting a spectrum of groans, screams and writhings together with an assortment of statements and expletives denouncing both the experiment and the experimenter. Milgram told the teacher-subject to ignore the reactions of the pupil, and to administer whatever level of shock was called for, as per the rule governing the experimental situation of the movement.

C

As the experiment unfolded, the pupil would deliberately give the wrong answers to questions posed by the teacher, thereby bringing on various electrical punishments, even up to the danger level of 300 volts and beyond. Many of the teacher-subjects balked at administering the higher levels of punishment, and turned to Milgram with questioning looks and/or complaints about continuing the experiment. In these situations, Milgram calmly explained that the teacher-subject was to ignore the pupil’s cries for mercy and carry on with the experiment. If the subject was still reluctant to proceed, Milgram said that it was important for the sake of the experiment that the procedure be followed through to the end. His final argument was, ‘You have no other choice. You must go on.’ What Milgram was trying to discover was the number of teacher-subjects who would be willing to administer the highest levels of shock, even in the face of strong personal and moral revulsion against the rules and conditions of the experiment.

D

Prior to carrying out the experiment, Milgram explained his idea to a group of 39 psychiatrists and asked them to predict the average percentage of people in an ordinary population who would be willing to administer the highest shock level of 450 volts. The overwhelming consensus was that virtually all the teacher-subjects would refuse to obey the experimenter. The psychiatrists felt that ‘most subjects would not go beyond 150 volts’ and they further anticipated that only four per cent would go up to 300 volts. Furthermore, they thought that only a lunatic fringe of about one in 1,000 would give the highest shock of 450 volts.

E

What were the actual results? Well, over 60 per cent of the teacher-subjects continued to obey Milgram up to the 450-volt limit! In repetitions of the experiment in other countries, the percentage of obedient teacher-subjects was even higher, reaching 85 per cent in one country. How can we possibly account for this vast discrepancy between what calm, rational, knowledgeable people predict in the comfort of their study and what pressured, flustered, but cooperative ‘teachers’ actually do in the laboratory of real life?

F

One’s first inclination might be to argue that there must be some sort of built-in animal aggression instinct that was activated by the experiment, and that Milgram’s teacher-subjects were just following a genetic need to discharge this pent-up primal urge onto the pupil by administering the electrical shock. A modern hard-core sociobiologist might even go so far as to claim that his aggressive instinct evolved as an advantageous trait, having been of survival value to our ancestors in their struggle against the hardships of life on the plains and in the caves, ultimately finding its way into our genetic make-up as a remnant of our ancient animal ways.

G

An alternative to this notion of genetic programming is to see the teachers-subjects action as a result of the social environment under which the experiment was carried out. As Milgram himself pointed out, ‘Most subjects in the experiment see their behavior in a larger context that is benevolent and useful to society – the pursuit of scientific truth. The psychological laboratory has a strong claim to legitimacy and evokes trust and confidence in those who perform there. An action such as shocking a victim, which in isolation appears evil, acquires a completely different meaning when placed in this setting.’

H

Thus, in this explanation the subject merges his unique personality and personal and moral code with that of larger institutional structures, surrendering individual properties like loyalty, self-sacrifice and discipline to the service of malevolent systems of authority.

I

Here we have two radically different explanations for why so many teacher-subjects were willing to forgo their sense of personal responsibility for the sake of an institutional authority figure. The problem for biologists, psychologists and anthropologists is to sort out which of these two polar explanations is more plausible. This, in essence, is the problem of modern sociobiology – to discover the degree to which hard-wired genetic programming dictates, or at least strongly biases, the interaction of animals and humans with their environment, that is, their behaviour. Put another way, sociobiology is concerned with elucidating the biological basis of all behaviour.

14. Question 14 — refer to the numbered gap in the question material.
Reading Passage 2 has nine paragraphs, A-I.

Which paragraph contains the following information?

Write the correct letter A-I in boxes 14-19 on your answer sheet.

14 a biological explanation of the teacher-subjects’ behaviour [14] ______

15 the explanation Milgram gave the teacher-subjects for the experiment [15] ______

16 the identity of the pupils [16] ______

17 the expected statistical outcome [17] ______

18 the general aim of sociobiological study [18] ______

19 the way Milgram persuaded the teacher-subjects to continue [19] ______

   A. Paragraph A
   B. Paragraph B
   C. Paragraph C
   D. Paragraph D
   E. Paragraph E
   F. Paragraph F
   G. Paragraph G
   H. Paragraph H
   I. Paragraph I
15. Question 15 — refer to the numbered gap in the question material.


   A. Paragraph A
   B. Paragraph B
   C. Paragraph C
   D. Paragraph D
   E. Paragraph E
   F. Paragraph F
   G. Paragraph G
   H. Paragraph H
   I. Paragraph I
16. Question 16 — refer to the numbered gap in the question material.


   A. Paragraph A
   B. Paragraph B
   C. Paragraph C
   D. Paragraph D
   E. Paragraph E
   F. Paragraph F
   G. Paragraph G
   H. Paragraph H
   I. Paragraph I
17. Question 17 — refer to the numbered gap in the question material.


   A. Paragraph A
   B. Paragraph B
   C. Paragraph C
   D. Paragraph D
   E. Paragraph E
   F. Paragraph F
   G. Paragraph G
   H. Paragraph H
   I. Paragraph I
18. Question 18 — refer to the numbered gap in the question material.


   A. Paragraph A
   B. Paragraph B
   C. Paragraph C
   D. Paragraph D
   E. Paragraph E
   F. Paragraph F
   G. Paragraph G
   H. Paragraph H
   I. Paragraph I
19. Question 19 — refer to the numbered gap in the question material.


   A. Paragraph A
   B. Paragraph B
   C. Paragraph C
   D. Paragraph D
   E. Paragraph E
   F. Paragraph F
   G. Paragraph G
   H. Paragraph H
   I. Paragraph I
20. The teacher-subjects were told that they were testing whether
Questions 20-22

Choose the correct letter A, B, C or D.

Write your answers in boxes 20-22 on your answer sheet.

   A. a 450-volt shock was dangerous.
   B. punishment helps learning.
   C. the pupils were honest.
   D. they were suited to teaching.
21. The teacher-subjects were instructed to


   A. stop when a pupil asked them to.
   B. denounce pupils who made mistakes.
   C. reduce the shock level after a correct answer.
   D. give punishment according to a rule.
22. Before the experiment took place the psychiatrists


   A. believed that a shock of 150 volts was too dangerous.
   B. failed to agree on how the teacher-subjects would respond to instructions.
   C. underestimated the teacher-subjects' willingness to comply with experimental procedure.
   D. thought that many of the teacher-subjects would administer a shock of 450 volts.
23. Several of the subjects were psychology students at Yale University.
Questions 23-26

Do the following statements agree with the information given in Reading Passage 2?

In boxes 23-26 on your answer sheet, write

TRUE if the statement agrees with the information

FALSE if the statement contradicts the information

NOT GIVEN if there is no information on this

24. Some people may believe that the teacher-subjects’ behaviour could be explained as a positive survival mechanism.


25. In a sociological explanation, personal values are more powerful than authority.


26. Milgram’s experiment solves an important question in sociobiology.


### C5-Test 1-Passage 3

Read the passage and answer the questions.
The Truth about the Environment

For many environmentalists, the world seems to be getting worse. They have developed a hit-list of our main fears: that natural resources are running out; that the population is ever growing, leaving less and less to eat; that species are becoming extinct in vast numbers, and that the planet's air and water are becoming ever more polluted.

But a quick look at the facts shows a different picture. First, energy and other natural resources have become more abundant, not less so, since the book ‘The Limits to Growth’ was published in 1972 by a group of scientists. Second, more food is now produced per head of the world’s population than at any time in history. Fewer people are starving. Third, although species are indeed becoming extinct, only about 0.7% of them are expected to disappear in the next 50 years, not 25-50%, as has so often been predicted. And finally, most forms of environmental pollution either appear to have been exaggerated, or are transient – associated with the early phases of industrialisation and therefore best cured not by restricting economic growth, but by accelerating it. One form of pollution – the release of greenhouse gases that causes global warming – does appear to be a phenomenon that is going to extend well into our future, but its total impact is unlikely to pose a devastating problem. A bigger problem may well turn out to be an inappropriate response to it.

Yet opinion polls suggest that many people nurture the belief that environmental standards are declining and four factors seem to cause this disjunction between perception and reality.

One is the lopsidedness built into scientific research. Scientific funding goes mainly to areas with many problems. That may be wise policy, but it will also create an impression that many more potential problems exist than is the case.

Secondly, environmental groups need to be noticed by the mass media. They also need to keep the money rolling in. Understandably, perhaps, they sometimes overstate their arguments. In 1997, for example, the World Wide Fund for Nature issued a press release entitled: ‘Two thirds of the world’s forests lost forever’. The truth turns out to be nearer 20%.

Though these groups are run overwhelmingly by selfless folk, they nevertheless share many of the characteristics of other lobby groups. That would matter less if people applied the same degree of scepticism to environmental lobbying as they do to lobby groups in other fields. A trade organization arguing for, say, weaker pollution control is instantly seen as self-interested. Yet a green organization opposing such a weakening is seen as altruistic, even if an impartial view of the controls in question might suggest they are doing more harm than good.

A third source of confusion is the attitude of the media. People are clearly more curious about bad news than good. Newspapers and broadcasters are there to provide what the public wants. That, however, can lead to significant distortions of perception. An example was America’s encounter with El Nino in 1997 and 1998. This climatic phenomenon was accused of wrecking tourism, causing allergies, melting the ski-slopes and causing 22 deaths. However, according to an article in the Bulletin of the American Meteorological Society, the damage it did was estimated at US$4 billion but the benefits amounted to some US$19 billion. These came from higher winter temperatures (which saved an estimated 850 lives, reduced heating costs and diminished spring floods caused by meltwaters).

The fourth factor is poor individual perception. People worry that the endless rise in the amount of stuff everyone throws away will cause the world to run out of places to dispose of waste. Yet, even if America’s trash output continues to rise as it has done in the past, and even if the American population doubles by 2100, all the rubbish America produces through the entire 21st century will still take up only one- 12,000th of the area of the entire United States.

So what of global warming? As we know, carbon dioxide emissions are causing the planet to warm. The best estimates are that the temperatures will rise by 2-3°C in this century, causing considerable problems, at a total cost of US$5,000 billion.

Despite the intuition that something drastic needs to be done about such a costly problem, economic analyses clearly show it will be far more expensive to cut carbon dioxide emissions radically than to pay the costs of adaptation to the increased temperatures. A model by one of the main authors of the United Nations Climate Change Panel shows how an expected temperature increase of 2.1 degrees in 2100 would only be diminished to an increase of 1.9 degrees. Or to put it another way, the temperature increase that the planet would have experienced in 2094 would be postponed to 2100.

So this does not prevent global warming, but merely buys the world six years. Yet the cost of reducing carbon dioxide emissions, for the United States alone, will be higher than the cost of solving the world’s single, most pressing health problem: providing universal access to clean drinking water and sanitation. Such measures would avoid 2 million deaths every year, and prevent half a billion people from becoming seriously ill.

It is crucial that we look at the facts if we want to make the best possible decisions for the future. It may be costly to be overly optimistic – but more costly still to be too pessimistic.

27. Environmentalists take a pessimistic view of the world for a number of reasons.
Questions 27-32

Do the following statements agree with the claims of the writer in Reading Passage 3?

In boxes 27-32 on your answer sheet, write

YES if the statement agrees with the writer’s claims

NO if the statement contradicts the writer’s claims

NOT GIVEN if it is impossible to say what the writer thinks about this

28. Data on the Earth’s natural resources has only been collected since 1972.


29. The number of starving people in the world has increased in recent years.


30. Extinct species are being replaced by new species.


31. Some pollution problems have been correctly linked to industrialization.


32. It would be best to attempt to slow down economic growth.


33. What aspect of scientific research does the writer express concern about in paragraph 4?
Questions 33-37

Choose the correct letter, A, B, C or D.

Write your answers in boxes 33-37 on your answer sheet.

   A. the need to produce results
   B. the lack of financial support
   C. the selection of areas to research
   D. the desire to solve every research problem
34. The writer quotes from the Worldwide Fund for Nature to illustrate how


   A. influential the mass media can be.
   B. effective environmental groups can be.
   C. the mass media can help groups raise funds.
   D. environmental groups can exaggerate their claims.
35. What is the writer’s main point about lobby groups in paragraph 6?


   A. Some are more active than others.
   B. Some are better organized than others.
   C. Some receive more criticism than others.
   D. Some support more important issues than others.
36. The writer suggests that newspapers print items that are intended to


   A. educate readers.
   B. meet their readers' expectations.
   C. encourage feedback from readers.
   D. mislead readers.
37. What does the writer say about America’s waste problem?


   A. It will increase in line with population growth.
   B. It is not as important as we have been led to believe.
   C. It has been reduced through public awareness of the issues.
   D. It is only significant in certain areas of the country.
38. Question 38 — refer to the numbered gap in the question material.
Questions 38-40

Complete the summary with the list of words A-I below.

Write the correct letter A-I in boxes 38-40 on your answer sheet.

GLOBAL WARMING

The writer admits that global warming is a 38 [38] ______ challenge, but says that it will not have a catastrophic impact on our future, if we deal with it in the 39 [39] ______ way. If we try to reduce the levels of greenhouse gases, he believes that it would only have a minimal impact on rising temperatures. He feels it would be better to spend money on the more 40 [40] ______ health problem of providing the world’s population with clean drinking water.

   A. unrealistic
   B. agreed
   C. expensive
   D. right
   E. long-term
   F. usual
   G. surprising
   H. personal
   I. urgent
39. Question 39 — refer to the numbered gap in the question material.


   A. unrealistic
   B. agreed
   C. expensive
   D. right
   E. long-term
   F. usual
   G. surprising
   H. personal
   I. urgent
40. Question 40 — refer to the numbered gap in the question material.


   A. unrealistic
   B. agreed
   C. expensive
   D. right
   E. long-term
   F. usual
   G. surprising
   H. personal
   I. urgent
## Academic Writing

### C5-Test 1-Task 1

Write at least 150 words. Suggested time: 20 minutes.
The graph below shows the proportion of the population aged 65 and over between 1940 and 2040 in three different countries. Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

![Question figure](assets/17b41ba151ded8302a16907a0ad4a0b3ec96665fd6706818c79852305dd4f802.png)

1. The graph below shows the proportion of the population aged 65 and over between 1940 and 2040 in three different countries. Summarise the information by selecting and reporting the main features, and make comparisons where relevant.


### C5-Test 1-Task 2

Write at least 250 words. Suggested time: 40 minutes.
Universities should accept equal numbers of male and female students in every subject. To what extent do you agree or disagree? Give reasons for your answer and include any relevant examples from your own knowledge or experience.

2. Universities should accept equal numbers of male and female students in every subject. To what extent do you agree or disagree? Give reasons for your answer and include any relevant examples from your own knowledge or experience.
