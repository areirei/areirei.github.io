# 剑雅 18 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/658d2ce06003e3206a3dcaaf1e548868b7e8a4356ff351f0fbaa1fe006891c1d.jpg; PDF page 12; full -->

```text
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Transport survey
Name: Sadie Jones
Year of birth: 1991
Postcode: (1) __________
Travelling by bus
Date of bus journey: (2) __________
Reason for trip: shopping and visit to the (3) __________
Travelled by bus because cost of (4) __________ too high
Got on bus at (5) __________ Street
Complaints about bus service: bus today was (6) __________; frequency of buses in the (7) __________
Travelling by car
Goes to the (8) __________ by car
Travelling by bicycle
Dislikes travelling by bike in the city centre because of the (9) __________
Doesn’t own a bike because of a lack of (10) __________
```

[Original question page](assets/658d2ce06003e3206a3dcaaf1e548868b7e8a4356ff351f0fbaa1fe006891c1d.jpg)

### Part 2

<!-- Source: /api/assets/4bba5c2fee40e40198cf3c2605bd66ef44c506886b523667ba2fab1cbee24f07.jpg; PDF page 13; full -->

```text
PART 2 Questions 11-20
Questions 11-13
Choose the correct letter, A, B or C.
Becoming a volunteer for ACE
11 Why does the speaker apologise about the seats?
A  They are too small.
B  There are not enough of them.
C Some of them are very close together.
12 What does the speaker say about the age of volunteers?
A  The age of volunteers is less important than other factors.
B  Young volunteers are less reliable than older ones.
C Most volunteers are about 60 years old.
13 What does the speaker say about training?
A It is continuous.
B It is conducted by a manager.
C It takes place online.
Questions 14 and 15
Choose TWO letters, A-E.
Which TWO issues does the speaker ask the audience to consider before they apply to
be volunteers?
A their financial situation
B their level of commitment
C their work experience
D their ambition
E their availability
```

[Original question page](assets/4bba5c2fee40e40198cf3c2605bd66ef44c506886b523667ba2fab1cbee24f07.jpg)

<!-- Source: /api/assets/1f19246f1df0f4df8c65d16c049d11fefc5c9a97e3bb9831238804bc33cc7ccc.jpg; PDF page 14; full -->

```text
Questions 16–20
What does the speaker suggest would be helpful for each of the following areas of voluntary work?
Choose FIVE answers from the box and write the correct letter, A–G, next to Questions 16–20.
Helpful things volunteers might offer
A experience on stage
B original, new ideas
C parenting skills
D an understanding of food and diet
E retail experience
F a good memory
G a good level of fitness
Area of voluntary work
16 Fundraising __________
17 Litter collection __________
18 ‘Playmates’ __________
19 Story club __________
20 First aid __________
```

[Original question page](assets/1f19246f1df0f4df8c65d16c049d11fefc5c9a97e3bb9831238804bc33cc7ccc.jpg)

### Part 3

<!-- Source: /api/assets/20191cca30a2293f72d3aeff5f3f8cdd756fe0ec720a8766417dfc92355b5dda.jpg; PDF page 15; full -->

```text
PART 3 Questions 21-30
Questions 21-26
Choose the correct letter, A, B or C.






Talk on jobs in fashion design
21 What problem did Chantal have at the start of the talk?
A Her view of the speaker was blocked.
B She was unable to find an empty seat.
C The students next to her were talking.
22 What were Hugo and Chantal surprised to hear about the job market?
A It has become more competitive than it used to be.
B There is more variety in it than they had realised.
C Some areas of it are more exciting than others.
23 Hugo and Chantal agree that the speaker’s message was
A unfair to them at times.
B hard for them to follow.
C critical of the industry.
24 What do Hugo and Chantal criticise about their school careers advice?
A when they received the advice
B how much advice was given
C who gave the advice
25 When discussing their future, Hugo and Chantal disagree on
A which is the best career in fashion.
B when to choose a career in fashion.
C why they would like a career in fashion.
26 How does Hugo feel about being an unpaid assistant?
A He is realistic about the practice.
B He feels the practice is dishonest.
C He thinks others want to change the practice.
```

[Original question page](assets/20191cca30a2293f72d3aeff5f3f8cdd756fe0ec720a8766417dfc92355b5dda.jpg)

<!-- Source: /api/assets/612643cc3b5e0cfcd47ec5cbc2a1831995e8575d6ed994b932d6d88dc60377b3.jpg; PDF page 16; full -->

```text
Questions 27 and 28
Choose TWO letters, A–E.
Which TWO mistakes did the speaker admit she made in her first job?
A being dishonest to her employer
B paying too much attention to how she looked
C expecting to become well known
D trying to earn a lot of money
E openly disliking her client
Questions 29 and 30
Choose TWO letters, A–E.
Which TWO pieces of retail information do Hugo and Chantal agree would be useful?
A the reasons people return fashion items
B how much time people have to shop for clothes
C fashion designs people want but can’t find
D the best time of year for fashion buying
E the most popular fashion sizes
```

[Original question page](assets/612643cc3b5e0cfcd47ec5cbc2a1831995e8575d6ed994b932d6d88dc60377b3.jpg)

### Part 4

<!-- Source: /api/assets/1a3bcd9dfeb93c49f9f2d5470c2d51b25b2b023d02af689447367676511b7e89.jpg; PDF page 17; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Elephant translocation
Reasons for overpopulation at Majete National Park
• strict enforcement of anti-poaching laws
• successful breeding
Problems caused by elephant overpopulation
• greater competition, causing hunger for elephants
• damage to (31) __________ in the park
The translocation process
• a suitable group of elephants from the same (32) __________ was selected
• vets and park staff made use of (33) __________ to help guide the elephants into an open plain
• elephants were immobilised with tranquilisers
– this process had to be completed quickly to reduce (34) __________
– elephants had to be turned on their (35) __________ to avoid damage to their lungs
– elephants’ (36) __________ had to be monitored constantly
– tracking devices were fitted to the matriarchs
– data including the size of their tusks and (37) __________ was taken
• elephants were taken by truck to their new reserve
Advantages of translocation at Nkhotakota Wildlife Park
• (38) __________ opportunities
• a reduction in the number of poachers and (39) __________
• an example of conservation that other parks can follow
• an increase in (40) __________ as a contributor to GDP
```

[Original question page](assets/1a3bcd9dfeb93c49f9f2d5470c2d51b25b2b023d02af689447367676511b7e89.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/c2ce0371f2392a55bc3a210b2c21d55b6a18bfdeac337713306d20638643a6aa.jpg; PDF page 18; full -->

```text
Test 1
| READING |
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Urban farming
In Paris, urban farmers are trying a soil-free approach to agriculture that uses less
space and fewer resources. Could it help cities face the threats to our food supplies?
On top of a striking new exhibition hall in southern Paris, the world’s largest urban rooftop farm
has started to bear fruit. Strawberries that are small, intensely flavoured and resplendently red
sprout abundantly from large plastic tubes. Peer inside and you see the tubes are completely
hollow, the roots of dozens of strawberry plants dangling down inside them. From identical
vertical tubes nearby burst row upon row of lettuces; near those are aromatic herbs, such as basil,
sage and peppermint. Opposite, in narrow, horizontal trays packed not with soil but with coconut
fibre, grow cherry tomatoes, shiny aubergines and brightly coloured chards.
Pascal Hardy, an engineer and sustainable development consultant, began experimenting with
vertical farming and aeroponic growing towers — as the soil-free plastic tubes are known — on
his Paris apartment block roof five years ago. The urban rooftop space above the exhibition hall
is somewhat bigger: 14,000 square metres and almost exactly the size of a couple of football
pitches. Already, the team of young urban farmers who tend it have picked, in one day, 3,000
lettuces and 150 punnets of strawberries. When the remaining two thirds of the vast open area
are in production, 20 staff will harvest up to 1,000 kg of perhaps 35 different varieties of fruit
and vegetables, every day. ‘We’re not ever, obviously, going to feed the whole city this way,’
cautions Hardy. ‘In the urban environment you’re working with very significant practical
constraints, clearly, on what you can do and where. But if enough unused space can be developed
like this, there’s no reason why you shouldn’t eventually target maybe between 5% and 10%
of consumption.’
Perhaps most significantly, however, this is a real-life showcase for the work of Hardy’s
flourishing urban agriculture consultancy, Agripolis, which is currently fielding enquiries from
around the world to design, build and equip a new breed of soil-free inner-city farm. ‘The
method’s advantages are many,’ he says. ‘First, I don’t much like the fact that most of the fruit
and vegetables we eat have been treated with something like 17 different pesticides, or that
the intensive farming techniques that produced them are such huge generators of greenhouse
```

[Original question page](assets/c2ce0371f2392a55bc3a210b2c21d55b6a18bfdeac337713306d20638643a6aa.jpg)

<!-- Source: /api/assets/b525502ce5ab8dbe222e07d8a978f986b34b79f870280f44851a5753fba6c59d.jpg; PDF page 19; full -->

```text
gases. I don’t much like the fact, either, that they’ve travelled an average of 2,000 refrigerated
kilometres to my plate, that their quality is so poor, because the varieties are selected for their
capacity to withstand such substantial journeys, or that 80% of the price I pay goes to wholesalers
and transport companies, not the producers.’
Produce grown using this soil-free method, on the other hand — which relies solely on a small
quantity of water, enriched with organic nutrients, pumped around a closed circuit of pipes,
towers and trays — is ‘produced up here, and sold locally, just down there. It barely travels at all,’
Hardy says. ‘You can select crop varieties for their flavour, not their resistance to the transport
and storage chain, and you can pick them when they’re really at their best, and not before.’ No
soil is exhausted, and the water that gently showers the plants’ roots every 12 minutes is recycled,
so the method uses 90% less water than a classic intensive farm for the same yield.
Urban farming is not, of course, a new phenomenon. Inner-city agriculture is booming from
Shanghai to Detroit and Tokyo to Bangkok. Strawberries are being grown in disused shipping
containers, mushrooms in underground carparks. Aeroponic farming, he says, is ‘virtuous’. The
equipment weighs little, can be installed on almost any flat surface and is cheap to buy: roughly
€100 to €150 per square metre. It is cheap to run, too, consuming a tiny fraction of the electricity
used by some techniques.
Produce grown this way typically sells at prices that, while generally higher than those of classic
intensive agriculture, are lower than soil-based organic growers. There are limits to what farmers
can grow this way, of course, and much of the produce is suited to the summer months. ‘Root
vegetables we cannot do, at least not yet,’ he says. ‘Radishes are OK, but carrots, potatoes, that
kind of thing — the roots are simply too long. Fruit trees are obviously not an option. And beans
tend to take up a lot of space for not much return.’ Nevertheless, urban farming of the kind
being practised in Paris is one part of a bigger and fast-changing picture that is bringing food
production closer to our lives.
```

[Original question page](assets/b525502ce5ab8dbe222e07d8a978f986b34b79f870280f44851a5753fba6c59d.jpg)

<!-- Source: /api/assets/e64be7dc83e02e5887cc13f722df49f9648a79292e4f9d8b53dc1e1cc8de4d52.jpg; PDF page 20; full -->

```text
Questions 1–3
Complete the sentences below. Choose NO MORE THAN TWO WORDS AND/OR A NUMBER from the passage for each answer.
Write your answers in boxes 1–3 on your answer sheet.
Urban farming in Paris
1 Vertical tubes are used to grow strawberries, __________ and herbs.
2 There will eventually be a daily harvest of as much as __________ in weight of fruit and vegetables.
3 It may be possible that the farm’s produce will account for as much as 10% of the city’s __________ overall.
Questions 4–7
Complete the table below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 4–7 on your answer sheet.
Intensive farming versus aeroponic urban farming
| Type | Growth | Selection | Sale |
| --- | --- | --- | --- |
| Intensive farming | wide range of (4) __________ used; techniques pollute air | quality not good; varieties of fruit and vegetables chosen that can survive long (5) __________ | (6) __________ receive very little of overall income |
| Aeroponic urban farming | no soil used; nutrients added to water, which is recycled | produce chosen because of its (7) __________ | |
```

[Original question page](assets/e64be7dc83e02e5887cc13f722df49f9648a79292e4f9d8b53dc1e1cc8de4d52.jpg)

<!-- Source: /api/assets/cc13028d2e1c102d3363048794e834187964927eef3799005e85f877195d5e87.jpg; PDF page 21; full -->

```text
Questions 8-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 8-13 on your answer sheet, write




TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
8 Urban farming can take place above or below ground.
9 Some of the equipment used in aeroponic farming can be made by hand.
10 Urban farming relies more on electricity than some other types of farming.
11 Fruit and vegetables grown on an aeroponic urban farm are cheaper than
traditionally grown organic produce.
12 Most produce can be grown on an aeroponic urban farm at any time of the year.
13 Beans take longer to grow on an urban farm than other vegetables.
```

[Original question page](assets/cc13028d2e1c102d3363048794e834187964927eef3799005e85f877195d5e87.jpg)

<!-- Source: /api/assets/88e6447398b89dae7b47e8760aa9a86c4493bf48a97e2b09044702f38054a6c7.jpg; PDF page 22; full -->

```text
Test 1
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Forest management in Pennsylvania, USA
How managing low-quality wood (also known as low-use wood) for bioenergy can
encourage sustainable forest management
A A tree’s ‘value’ depends on several factors including its species, size, form, condition,
quality, function, and accessibility, and depends on the management goals for a given
forest. The same tree can be valued very differently by each person who looks at it. A large,
straight black cherry tree has high value as timber to be cut into logs or made into furniture,
but for a landowner more interested in wildlife habitat, the real value of that stem (or trunk)
may be the food it provides to animals. Likewise, if the tree suffers from black knot disease,
its value for timber decreases, but to a woodworker interested in making bowls, it brings an
opportunity for a unique and beautiful piece of art.
B In the past, Pennsylvania landowners were solely interested in the value of their trees as
high-quality timber. The norm was to remove the stems of highest quality and leave behind
poorly formed trees that were not as well suited to the site where they grew. This practice,
called ‘high-grading’, has left a legacy of ‘low-use wood’ in the forests. Some people even
call these ‘junk trees’, and they are abundant in Pennsylvania. These trees have lower
economic value for traditional timber markets, compete for growth with higher-value
trees, shade out desirable regeneration and decrease the health of a stand* leaving it more
vulnerable to poor weather and disease. Management that specifically targets low-use wood
can help landowners manage these forest health issues, and wood energy markets help
promote this.
C Wood energy markets can accept less expensive wood material of lower quality than would
be suitable for traditional timber markets. Most wood used for energy in Pennsylvania is
used to produce heat or electricity through combustion. Many schools and hospitals use
wood boiler systems to heat and power their facilities, many homes are primarily heated
with wood, and some coal plants incorporate wood into their coal streams to produce
electricity. Wood can also be gasified for electrical generation and can even be made into
liquid fuels like ethanol and gasoline for lorries and cars. All these products are made
primarily from low-use wood. Several tree- and plant-cutting approaches, which could
greatly improve the long-term quality of a forest, focus strongly or solely on the use of
wood for those markets.
* Stand — An area covered with trees that have common features (e.g. size)
```

[Original question page](assets/88e6447398b89dae7b47e8760aa9a86c4493bf48a97e2b09044702f38054a6c7.jpg)

<!-- Source: /api/assets/08107e655f6639120eac38499585eabe4479cda5f8b977fb9912915b3f739c77.jpg; PDF page 23; full -->

```text
D One such approach is called a Timber Stand Improvement (TSI) Cut. In a TSI Cut, really
poor-quality tree and plant material is cut down to allow more space, light, and other
resources to the highest-valued stems that remain. Removing invasive plants might be
another primary goal of a TSI Cut. The stems that are left behind might then grow in
size and develop more foliage and larger crowns or tops that produce more coverage for
wildlife; they have a better chance to regenerate in a less crowded environment. TSI Cuts
can be tailored to one farmer’s specific management goals for his or her land.
E Another approach that might yield a high amount of low-use wood is a Salvage Cut. With
the many pests and pathogens visiting forests including hemlock wooly adelgid, Asian
longhorned beetle, emerald ash borer, and gypsy moth, to name just a few, it is important
to remember that those working in the forests can help ease these issues through cutting
procedures. These types of cut reduce the number of sick trees and seek to manage the future
spread of a pest problem. They leave vigorous trees that have stayed healthy enough to
survive the outbreak.
F A Shelterwood Cut, which only takes place in a mature forest that has already been thinned
several times, involves removing all the mature trees when other seedlings have become
established. This then allows the forester to decide which tree species are regenerated. It
leaves a young forest where all trees are at a similar point in their growth. It can also be
used to develop a two-tier forest so that there are two harvests and the money that comes in
is spread out over a decade or more.
G Thinnings and dense and dead wood removal for fire prevention also center on the
production of low-use wood. However, it is important to remember that some retention of
what many would classify as low-use wood is very important. The tops of trees that have
been cut down should be left on the site so that their nutrients cycle back into the soil. In
addition, trees with many cavities are extremely important habitats for insect predators like
woodpeckers, bats and small mammals. They help control problem insects and increase the
health and resilience of the forest. It is also important to remember that not all small trees
are low-use. For example, many species like hawthorn provide food for wildlife. Finally,
rare species of trees in a forest should also stay behind as they add to its structural diversity.
```

[Original question page](assets/08107e655f6639120eac38499585eabe4479cda5f8b977fb9912915b3f739c77.jpg)

<!-- Source: /api/assets/b32cdd8b44d0092aff7f7b6253df31a8bcca7ef045e23947179d62fc7110a299.jpg; PDF page 24; full -->

```text
Test 1
Questions 14-18
Reading Passage 2 has seven paragraphs, A-G.
Which paragraph contains the following information?
Write the correct letter, A-G, in boxes 14-18 on your answer sheet.
NB You may use any letter more than once.
14 bad outcomes for a forest when people focus only on its financial reward
15 reference to the aspects of any tree that contribute to its worth
16 mention of the potential use of wood to help run vehicles
17 examples of insects that attack trees
18 an alternative name for trees that produce low-use wood
```

[Original question page](assets/b32cdd8b44d0092aff7f7b6253df31a8bcca7ef045e23947179d62fc7110a299.jpg)

<!-- Source: /api/assets/93c00da2d5e1199b4f414454095d45981b3d332fd23a3f1231e10fd8414144e7.jpg; PDF page 25; full -->

```text
Questions 19-21
Look at the following purposes (Questions 19-21) and the list of timber cuts below.
Match each purpose with the correct timber cut, A, B or C.
Write the correct letter, A, B or C, in boxes 19-21 on your answer sheet.
NB You may use any letter more than once.
19 to remove trees that are diseased
20 to generate income across a number of years
21 to create a forest whose trees are close in age
List of Timber Cuts
A a TSI Cut
B a Salvage Cut
C a Shelterwood Cut
```

[Original question page](assets/93c00da2d5e1199b4f414454095d45981b3d332fd23a3f1231e10fd8414144e7.jpg)

<!-- Source: /api/assets/c74d84c7615917e95a39598e6acece8f3981ddc9f3e1f53630674a3344bf6152.jpg; PDF page 26; full -->

```text
Questions 22–26
Complete the sentences below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 22–26 on your answer sheet.
22 Some dead wood is removed to avoid the possibility of __________.
23 The __________ from the tops of cut trees can help improve soil quality.
24 Some damaged trees should be left, as their __________ provide habitats for a range of creatures.
25 Some trees that are small, such as __________, are a source of food for animals and insects.
26 Any trees that are __________ should be left to grow, as they add to the variety of species in the forest.
```

[Original question page](assets/c74d84c7615917e95a39598e6acece8f3981ddc9f3e1f53630674a3344bf6152.jpg)

<!-- Source: /api/assets/abba2f7549370761f1f6b0b3c9d16637063c0e0c0502d9a8bbea4166696d492b.jpg; PDF page 27; full -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Conquering Earth’s space junk problem
Satellites, rocket shards and collision debris are creating major traffic risks in orbit
around the planet. Researchers are working to reduce these threats
A Last year, commercial companies, military and civil departments and amateurs
sent more than 400 satellites into orbit, over four times the yearly average in
the previous decade. Numbers could rise even more sharply if leading space
companies follow through on plans to deploy hundreds to thousands of large
constellations of satellites to space in the next few years.
All that traffic can lead to disaster. Ten years ago, a US commercial Iridium satellite
smashed into an inactive Russian communications satellite called Cosmos-2251,
creating thousands of new pieces of space shrapnel that now threaten other
satellites in low Earth orbit — the zone stretching up to 2,000 kilometres in altitude.
Altogether, there are roughly 20,000 human-made objects in orbit, from working
satellites to small rocket pieces. And satellite operators can’t steer away from every
potential crash, because each move consumes time and fuel that could otherwise
be used for the spacecraft’s main job.
B Concern about space junk goes back to the beginning of the satellite era, but the
number of objects in orbit is rising so rapidly that researchers are investigating
new ways of attacking the problem. Several teams are trying to improve methods
for assessing what is in orbit, so that satellite operators can work more efficiently
in ever-more-crowded space. Some researchers are now starting to compile a
massive data set that includes the best possible information on where everything is
in orbit. Others are developing taxonomies of space debris — working on measuring
properties such as the shape and size of an object, so that satellite operators know
how much to worry about what's coming their way.
The alternative, many say, is unthinkable. Just a few uncontrolled space crashes
could generate enough debris to set off a runaway cascade of fragments, rendering
near-Earth space unusable. ‘If we go on like this, we will reach a point of no return,’
says Carolin Frueh, an astrodynamical researcher at Purdue University in West
Lafayette, Indiana.
C Even as our ability to monitor space objects increases, so too does the total
number of items in orbit. That means companies, governments and other players in
space are collaborating in new ways to avoid a shared threat. International groups
such as the Inter-Agency Space Debris Coordination Committee have developed
guidelines on space sustainability. Those include inactivating satellites at the
end of their useful life by venting pressurised materials or leftover fuel that might
```

[Original question page](assets/abba2f7549370761f1f6b0b3c9d16637063c0e0c0502d9a8bbea4166696d492b.jpg)

<!-- Source: /api/assets/0ff70ad185f19314e806dba469edff6c646e7e82bc890916d1cd37502b9c783d.jpg; PDF page 28; full -->

```text
Test 1
26
lead to explosions. The intergovernmental groups also advise lowering satellites
deep enough into the atmosphere that they will burn up or disintegrate within 25
years. But so far, only about half of all missions have abided by this 25-year goal,
says Holger Krag, head of the European Space Agency's space-debris office in
Darmstadt, Germany. Operators of the planned large constellations of satellites say
they will be responsible stewards in their enterprises in space, but Krag worries
that problems could increase, despite their best intentions. ‘What happens to those
that fail or go bankrupt?’ he asks. ‘They are probably not going to spend money to
remove their satellites from space.’
D In theory, given the vastness of space, satellite operators should have plenty of
room for all these missions to fly safely without ever nearing another object. So
some scientists are tackling the problem of space junk by trying to find out where
all the debris is to a high degree of precision. That would alleviate the need for
many of the unnecessary manoeuvres that are carried out to avoid potential
collisions. ‘If you knew precisely where everything was, you would almost never
have a problem,’ says Marlon Sorge, a space-debris specialist at the Aerospace
Corporation in El Segundo, California.
E The field is called space traffic management, because it’s similar to managing traffic
on the roads or in the air. Think about a busy day at an airport, says Moriba Jah,
an astrodynamicist at the University of Texas at Austin: planes line up in the sky,
landing and taking off close to one another in a carefully choreographed routine.
Air-traffic controllers know the location of the planes down to one metre in accuracy.
The same can't be said for space debris. Not all objects in orbit are known, and
even those included in databases are not tracked consistently.
F An additional problem is that there is no authoritative catalogue that accurately
lists the orbits of all known space debris. Jah illustrates this with a web-based
database that he has developed. It draws on several sources, such as catalogues
maintained by the US and Russian governments, to visualise where objects are in
space. When he types in an identifier for a particular space object, the database
draws a purple line to designate its orbit. Only this doesn’t quite work for a number
of objects, such as a Russian rocket body designated in the database as object
number 32280. When Jah enters that number, the database draws two purple lines:
the US and Russian sources contain two completely different orbits for the same
object. Jah says that it is almost impossible to tell which is correct, unless a third
source of information made it possible to cross-correlate.
Jah describes himself as a space environmentalist: ‘I want to make space a place
that is safe to operate, that is free and useful for generations to come.’ Until that
happens, he argues, the space community will continue devolving into a tragedy in
which all spaceflight operators are polluting a common resource.
```

[Original question page](assets/0ff70ad185f19314e806dba469edff6c646e7e82bc890916d1cd37502b9c783d.jpg)

<!-- Source: /api/assets/f3d9e48fc688c002b818e6742d09c7998a8526a01af3e0fd8f4e0d4492b227f8.jpg; PDF page 29; full -->

```text
Questions 27-31
Reading Passage 3 has six sections, A-F.
Which section contains the following information?
Write the correct letter, A-F, in boxes 27-31 on your answer sheet.
27 a reference to the cooperation that takes place to try and minimise risk
28 an explanation of a person's aims
29 a description of a major collision that occurred in space
30 a comparison between tracking objects in space and the efficiency of a
transportation system
31 a reference to efforts to classify space junk
Questions 32-35
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 32-35 on your answer sheet.
The Inter-Agency Space Debris Coordination Committee
The committee gives advice on how the (32) __________ of space can be achieved. The committee advises that when satellites are no longer active, any unused (33) __________ or pressurised material that could cause (34) __________ should be removed.
Although operators of large satellite constellations accept that they have obligations as stewards of space, Holger Krag points out that the operators that become (35) __________ are unlikely to prioritise removing their satellites from space.
```

[Original question page](assets/f3d9e48fc688c002b818e6742d09c7998a8526a01af3e0fd8f4e0d4492b227f8.jpg)

<!-- Source: /api/assets/8ca8df77c14e034c964946395e726489355303ab68aeb9d322ae5aa142831672.jpg; PDF page 30; full -->

```text
Test 1
Questions 36-40
Look at the following statements (Questions 36-40) and the list of people below.
Match each statement with the correct person, A, B, C or D.
Write the correct letter, A, B, C or D, in boxes 36-40 on your answer sheet.
NB You may use any letter more than once.
36 Knowing the exact location of space junk would help prevent any possible danger.
37 Space should be available to everyone and should be preserved for the future.
38 A recommendation regarding satellites is widely ignored.
39 There is conflicting information about where some satellites are in space.
40 There is a risk we will not be able to undo the damage that occurs in space.
List of People
A Carolin Frueh
B Holger Krag
C Marlon Sorge
D Moriba Jah
```

[Original question page](assets/8ca8df77c14e034c964946395e726489355303ab68aeb9d322ae5aa142831672.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/3ecd5ca5d95a8ec5356dc513b61909854409d2317076a5fa90e8756e27742e54.jpg; PDF page 31; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below gives information about the percentage of the population in four Asian countries living in cities from 1970 to 2020, with predictions for 2030 and 2040.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

Chart title: Percentage of the population living in cities
Vertical axis: Percentage (%) of total population (0–90, increments of 10).
Horizontal axis: Year (1970, 1980, 1990, 2000, 2010, 2020, 2030, 2040).
Legend: Philippines; Malaysia; Thailand; Indonesia.
Refer to the original figure for the plotted series.
```

[Original question page](assets/3ecd5ca5d95a8ec5356dc513b61909854409d2317076a5fa90e8756e27742e54.jpg)

![Original figure](assets/3ecd5ca5d95a8ec5356dc513b61909854409d2317076a5fa90e8756e27742e54.jpg)

### Task 2

<!-- Source: /api/assets/2b174684badff01bd3ef52c994491cca5a6ce11a3286d5d89ad74e2d685dda34.jpg; PDF page 32; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

The most important aim of science should be to improve people's lives.

To what extent do you agree or disagree with this statement?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/2b174684badff01bd3ef52c994491cca5a6ce11a3286d5d89ad74e2d685dda34.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/37a19d75fa03a0301a30ad3c0746672205c45c1efabcd2450716da4e930e5737.jpg; PDF page 33; full -->

```text
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Paying bills
e What kinds of bills do you have to pay?
e How do you usually pay your bills — in cash or by another method? [Why?]
e Have you ever forgotten to pay a bill? [Why/Why not?]
e Is there anything you could do to make your bills cheaper? [Why/Why not?]
PART 2
Describe some food or drink that you learned to prepare.
You should say:
what food or drink you learned to prepare
when and where you learned to prepare this
how you learned to prepare this
and explain how you felt about learning to prepare this food or drink.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Young people and cooking
Example questions:
What kinds of things can children learn to cook?
Do you think it is important for children to learn to cook?
Do you think young people should learn to cook at home or at school?
Working as a chef
Example questions:
How enjoyable do you think it would be to work as a professional chef?
What skills does a person need to be a great chef?
How much influence do celebrity/TV chefs have on what ordinary people cook?
```

[Original question page](assets/37a19d75fa03a0301a30ad3c0746672205c45c1efabcd2450716da4e930e5737.jpg)

### Part 2

<!-- Source: /api/assets/37a19d75fa03a0301a30ad3c0746672205c45c1efabcd2450716da4e930e5737.jpg; PDF page 33; full -->

```text
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Paying bills
e What kinds of bills do you have to pay?
e How do you usually pay your bills — in cash or by another method? [Why?]
e Have you ever forgotten to pay a bill? [Why/Why not?]
e Is there anything you could do to make your bills cheaper? [Why/Why not?]
PART 2
Describe some food or drink that you learned to prepare.
You should say:
what food or drink you learned to prepare
when and where you learned to prepare this
how you learned to prepare this
and explain how you felt about learning to prepare this food or drink.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Young people and cooking
Example questions:
What kinds of things can children learn to cook?
Do you think it is important for children to learn to cook?
Do you think young people should learn to cook at home or at school?
Working as a chef
Example questions:
How enjoyable do you think it would be to work as a professional chef?
What skills does a person need to be a great chef?
How much influence do celebrity/TV chefs have on what ordinary people cook?
```

[Original question page](assets/37a19d75fa03a0301a30ad3c0746672205c45c1efabcd2450716da4e930e5737.jpg)

### Part 3

<!-- Source: /api/assets/37a19d75fa03a0301a30ad3c0746672205c45c1efabcd2450716da4e930e5737.jpg; PDF page 33; full -->

```text
PART 1
The examiner asks you about yourself, your home, work or studies and other
familiar topics.
EXAMPLE
Paying bills
e What kinds of bills do you have to pay?
e How do you usually pay your bills — in cash or by another method? [Why?]
e Have you ever forgotten to pay a bill? [Why/Why not?]
e Is there anything you could do to make your bills cheaper? [Why/Why not?]
PART 2
Describe some food or drink that you learned to prepare.
You should say:
what food or drink you learned to prepare
when and where you learned to prepare this
how you learned to prepare this
and explain how you felt about learning to prepare this food or drink.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Young people and cooking
Example questions:
What kinds of things can children learn to cook?
Do you think it is important for children to learn to cook?
Do you think young people should learn to cook at home or at school?
Working as a chef
Example questions:
How enjoyable do you think it would be to work as a professional chef?
What skills does a person need to be a great chef?
How much influence do celebrity/TV chefs have on what ordinary people cook?
```

[Original question page](assets/37a19d75fa03a0301a30ad3c0746672205c45c1efabcd2450716da4e930e5737.jpg)
