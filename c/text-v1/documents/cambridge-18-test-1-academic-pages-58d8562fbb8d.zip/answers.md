# 剑雅 18 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 121

TEST 1 LISTENING
1 DW30 7YZ
2 24(th) April
3 dentist
4 parking
5 Claxby
6 late
7 evening
8 supermarket
9 pollution
10 storage
11 C
12 A
13 A
14 B
15 E
16 B
17 G
18 D
19 A
20 F
21 A
22 B
23 A
24 C
25 B
26 A
27 B
28 E
29 A
30 C
31 fences
32 family
33 helicopters
34 stress
35 sides
36 breathing
37 feet
38 employment
39 weapons
40 tourism
14&15 IN EITHER ORDER: B,E
27&28 IN EITHER ORDER: B,E
29&30 IN EITHER ORDER: A,C
If you score: 0–19 unlikely;20–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. DW30 7YZ / DW307YZ

2. 24 April / 24th April

3. dentist

4. parking

5. Claxby

6. late

7. evening

8. supermarket

9. pollution

10. storage

### Part 2 · source page 121

TEST 1 LISTENING
1 DW30 7YZ
2 24(th) April
3 dentist
4 parking
5 Claxby
6 late
7 evening
8 supermarket
9 pollution
10 storage
11 C
12 A
13 A
14 B
15 E
16 B
17 G
18 D
19 A
20 F
21 A
22 B
23 A
24 C
25 B
26 A
27 B
28 E
29 A
30 C
31 fences
32 family
33 helicopters
34 stress
35 sides
36 breathing
37 feet
38 employment
39 weapons
40 tourism
14&15 IN EITHER ORDER: B,E
27&28 IN EITHER ORDER: B,E
29&30 IN EITHER ORDER: A,C
If you score: 0–19 unlikely;20–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. C

12. A

13. A

14. B / E

15. B / E

16. B

17. G

18. D

19. A

20. F

### Part 3 · source page 121

TEST 1 LISTENING
1 DW30 7YZ
2 24(th) April
3 dentist
4 parking
5 Claxby
6 late
7 evening
8 supermarket
9 pollution
10 storage
11 C
12 A
13 A
14 B
15 E
16 B
17 G
18 D
19 A
20 F
21 A
22 B
23 A
24 C
25 B
26 A
27 B
28 E
29 A
30 C
31 fences
32 family
33 helicopters
34 stress
35 sides
36 breathing
37 feet
38 employment
39 weapons
40 tourism
14&15 IN EITHER ORDER: B,E
27&28 IN EITHER ORDER: B,E
29&30 IN EITHER ORDER: A,C
If you score: 0–19 unlikely;20–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. A

22. B

23. A

24. C

25. B

26. A

27. B / E

28. B / E

29. A / C

30. A / C

### Part 4 · source page 121

TEST 1 LISTENING
1 DW30 7YZ
2 24(th) April
3 dentist
4 parking
5 Claxby
6 late
7 evening
8 supermarket
9 pollution
10 storage
11 C
12 A
13 A
14 B
15 E
16 B
17 G
18 D
19 A
20 F
21 A
22 B
23 A
24 C
25 B
26 A
27 B
28 E
29 A
30 C
31 fences
32 family
33 helicopters
34 stress
35 sides
36 breathing
37 feet
38 employment
39 weapons
40 tourism
14&15 IN EITHER ORDER: B,E
27&28 IN EITHER ORDER: B,E
29&30 IN EITHER ORDER: A,C
If you score: 0–19 unlikely;20–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. fences

32. family

33. helicopters

34. stress

35. sides

36. breathing

37. feet

38. employment

39. weapons

40. tourism

## A 类阅读

### Academic Reading · source page 122

TEST 1 READING
1 lettuces
2 1,000 kg
3 (food) consumption
4 pesticides
5 journeys
6 producers
7 flavour / flavor
8 TRUE
9 NOT GIVEN
10 FALSE
11 TRUE
12 FALSE
13 NOT GIVEN
14 B
15 A
16 C
17 E
18 B
19 B
20 C
21 C
22 fire
23 nutrients
24 cavities
25 hawthorn
26 rare
27 C
28 F
29 A
30 E
31 B
32 sustainability
33 fuel
34 explosions
35 bankrupt
36 C
37 D
38 B
39 D
40 A
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. lettuces

2. 1,000 kg / 1000 kg

3. consumption / food consumption

4. pesticides

5. journeys

6. producers

7. flavour / flavor

8. TRUE

9. NOT GIVEN

10. FALSE

11. TRUE

12. FALSE

13. NOT GIVEN

14. B

15. A

16. C

17. E

18. B

19. B

20. C

21. C

22. fire

23. nutrients

24. cavities

25. hawthorn

26. rare

27. C

28. F

29. A

30. E

31. B

32. sustainability

33. fuel

34. explosions

35. bankrupt

36. C

37. D

38. B

39. D

40. A

## A 类写作

### Writing material: c18-t1-w-1

Source: original Cambridge 18 Test 1 Task 1 chart, inspected directly. Line chart: percentage of the total population living in cities; four Asian countries. Horizontal axis: 1970, 1980, 1990, 2000, 2010, 2020, 2030, 2040. Vertical axis: 0 to 90 percent in intervals of 10. The prompt labels 2030 and 2040 as predictions; 1970 to 2020 is historical. All following figures are approximate visual estimates, not exact tabulated values.
Year: 1970 / 1980 / 1990 / 2000 / 2010 / 2020 / 2030 / 2040
Philippines: about 32 / 34 / 48 / 46 / 43 / 46 / 51 / 56 percent.
Malaysia: about 30 / 40 / 45 / 60 / 71 / 76 / 81 / 83 percent.
Thailand: about 18 / 23 / 30 / 30 / 33 / 34 / 41 / 50 percent.
Indonesia: about 14 / 17 / 25 / 30 / 43 / 53 / 61 / 64 percent.
All countries finish higher than they started. Malaysia grows substantially and is highest from 2000 onward; the Philippines briefly leads in 1990, then declines until 2010 before recovering. Indonesia starts lowest, passes Thailand after 2000 and approximately catches the Philippines in 2010; it ranks second thereafter. Thailand is projected to remain lowest in 2040. Tolerate sensible rounded estimates from the plotted lines; do not require the above estimated values verbatim.



### Writing material: c18-t1-w-2





## 口语
