# 剑雅 15 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 121

TEST 3 LISTENING
1 furniture
2 meetings
3 diary
4 detail(s)
5 1 / one year
6 deliveries
7 tidy
8 team
9 heavy
10 customer
11 B
12 A
13 C
14 B
15 C
16 B
17 B
18 D
19 A
20 E
21 page
22 size
23 graphic(s)
24 structure
25 purpose
26 assumption(s)
27 A
28 C
29 C
30 B
31 mud
32 clay
33 metal
34 hair
35 bath(s)
36 disease(s)
37 perfume
38 salt
39 science
40 tax
17&18 IN EITHER ORDER: B,D
19&20 IN EITHER ORDER: A,E
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. furniture

2. meetings

3. diary

4. detail / details

5. 1 year / one year

6. deliveries

7. tidy

8. team

9. heavy

10. customer

### Part 2 · source page 121

TEST 3 LISTENING
1 furniture
2 meetings
3 diary
4 detail(s)
5 1 / one year
6 deliveries
7 tidy
8 team
9 heavy
10 customer
11 B
12 A
13 C
14 B
15 C
16 B
17 B
18 D
19 A
20 E
21 page
22 size
23 graphic(s)
24 structure
25 purpose
26 assumption(s)
27 A
28 C
29 C
30 B
31 mud
32 clay
33 metal
34 hair
35 bath(s)
36 disease(s)
37 perfume
38 salt
39 science
40 tax
17&18 IN EITHER ORDER: B,D
19&20 IN EITHER ORDER: A,E
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B

12. A

13. C

14. B

15. C

16. B

17. B / D

18. B / D

19. A / E

20. A / E

### Part 3 · source page 121

TEST 3 LISTENING
1 furniture
2 meetings
3 diary
4 detail(s)
5 1 / one year
6 deliveries
7 tidy
8 team
9 heavy
10 customer
11 B
12 A
13 C
14 B
15 C
16 B
17 B
18 D
19 A
20 E
21 page
22 size
23 graphic(s)
24 structure
25 purpose
26 assumption(s)
27 A
28 C
29 C
30 B
31 mud
32 clay
33 metal
34 hair
35 bath(s)
36 disease(s)
37 perfume
38 salt
39 science
40 tax
17&18 IN EITHER ORDER: B,D
19&20 IN EITHER ORDER: A,E
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. page

22. size

23. graphic / graphics

24. structure

25. purpose

26. assumption / assumptions

27. A

28. C

29. C

30. B

### Part 4 · source page 121

TEST 3 LISTENING
1 furniture
2 meetings
3 diary
4 detail(s)
5 1 / one year
6 deliveries
7 tidy
8 team
9 heavy
10 customer
11 B
12 A
13 C
14 B
15 C
16 B
17 B
18 D
19 A
20 E
21 page
22 size
23 graphic(s)
24 structure
25 purpose
26 assumption(s)
27 A
28 C
29 C
30 B
31 mud
32 clay
33 metal
34 hair
35 bath(s)
36 disease(s)
37 perfume
38 salt
39 science
40 tax
17&18 IN EITHER ORDER: B,D
19&20 IN EITHER ORDER: A,E
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. mud

32. clay

33. metal

34. hair

35. bath / baths

36. disease / diseases

37. perfume

38. salt

39. science

40. tax

## A 类阅读

### Academic Reading · source page 122

TEST 3 READING
1 TRUE
2 FALSE
3 NOT GIVEN
4 TRUE
5 NOT GIVEN
6 FALSE
7 TRUE
8 resignation
9 materials
10 miners
11 family
12 collectors
13 income
14 iii
15 vi
16 v
17 x
18 iv
19 viii
20 i
21 wheels
22 film
23 filter
24 waste
25 performance
26 servicing
27 C
28 B
29 F
30 A
31 E
32 D
33 F
34 B
35 C
36 G
37 B
38 D
39 A
40 A
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. TRUE

2. FALSE

3. NOT GIVEN

4. TRUE

5. NOT GIVEN

6. FALSE

7. TRUE

8. resignation

9. materials

10. miners

11. family

12. collectors

13. income

14. iii

15. vi

16. v

17. x

18. iv

19. viii

20. i

21. wheels

22. film

23. filter

24. waste

25. performance

26. servicing

27. C

28. B

29. F

30. A

31. E

32. D

33. F

34. B

35. C

36. G

37. B

38. D

39. A

40. A

## A 类写作

### Writing material: c15-t3-w-1

Eight numbered stages:1flour held in storage silos supplied by truck;2flour mixed with water and oil;3rollers make dough sheets;4sheets cut into dough strips;5strips formed into noodle discs;6cooked in oil and dried;7noodles placed in cups with vegetables and spices;8cups labelled and sealed. Linear industrial process from flour storage to packaged noodles. Retain cooking-in-oil PLUS drying, not water boiling. No temperatures, durations, specific vegetables or nutritional facts supplied.



### Writing material: c15-t3-w-2

Discuss persuasive success versus reduced attention due to ubiquity, with opinion. Do not substitute whether advertising is morally good or bad for the effectiveness comparison.



## 口语
