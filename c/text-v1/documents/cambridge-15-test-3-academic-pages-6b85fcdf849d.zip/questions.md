# 剑雅 15 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/2fa47da3607fe8011a656e9efbd29297fc522ee281aae733baed3223ab5402b5.jpg; PDF page 50; full -->

```text
LISTENING
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Employment Agency: Possible Jobs
First Job
Administrative assistant in a company that produces (1) __________ (North London)
Responsibilities
• data entry
• go to (2) __________ and take notes
• general admin
• management of (3) __________
Requirements
• good computer skills including spreadsheets
• good interpersonal skills
• attention to (4) __________
Experience
• need a minimum of (5) __________ of experience of teleconferencing
```

[Original question page](assets/2fa47da3607fe8011a656e9efbd29297fc522ee281aae733baed3223ab5402b5.jpg)

<!-- Source: /api/assets/85a2a75aa005fba1f6b05e34bee430a194167aca5488b14f2dfff18c52c75e1e.jpg; PDF page 51; full -->

```text
Second Job
Warehouse assistant in South London
Responsibilities
• stock management
• managing (6) __________
Requirements
• ability to work with numbers
• good computer skills
• very organised and (7) __________
• good communication skills
• used to working in a (8) __________
• able to cope with items that are (9) __________
Need experience of
• driving in London
• warehouse work
• (10) __________ service
```

[Original question page](assets/85a2a75aa005fba1f6b05e34bee430a194167aca5488b14f2dfff18c52c75e1e.jpg)

### Part 2

<!-- Source: /api/assets/83796917987b58a49e4e0633ee255c216b571aeaec29cda80ad4e41e77ffd1e8.jpg; PDF page 52; full -->

```text
Test 3
PART 2 Questions 11-20
Questions 11-16
Choose the correct letter, A, B or C.






54
Street Play Scheme
11 When did the Street Play Scheme first take place?
A two years ago
B three years ago
C six years ago
12 How often is Beechwood Road closed to traffic now?
A once a week
B on Saturdays and Sundays
C once a month
13 Who is responsible for closing the road?
A a council official
B the police
C local wardens
14 Residents who want to use their cars
A have to park in another street.
B must drive very slowly.
C need permission from a warden.
15 Alice says that Street Play Schemes are most needed in
A wealthy areas.
B quiet suburban areas.
C areas with heavy traffic.
16 What has been the reaction of residents who are not parents?
A Many of them were unhappy at first.
B They like seeing children play in the street.
C They are surprised by the lack of noise.
```

[Original question page](assets/83796917987b58a49e4e0633ee255c216b571aeaec29cda80ad4e41e77ffd1e8.jpg)

<!-- Source: /api/assets/209a6d5c8afc9a510fda73f5500d05f33edf7f6257eb4159f7d810b81669c9de.jpg; PDF page 53; full -->

```text
Questions 17 and 18
Choose TWO letters, A–E.
Which TWO benefits for children does Alice think are the most important?
A increased physical activity
B increased sense of independence
C opportunity to learn new games
D opportunity to be part of a community
E opportunity to make new friends
Questions 19 and 20
Choose TWO letters, A–E.
Which TWO results of the King Street experiment surprised Alice?
A more shoppers
B improved safety
C less air pollution
D more relaxed atmosphere
E less noise pollution
```

[Original question page](assets/209a6d5c8afc9a510fda73f5500d05f33edf7f6257eb4159f7d810b81669c9de.jpg)

### Part 3

<!-- Source: /api/assets/1b21d2ba8c68f4ae8f3c1c5bf3d66605e54f4b64a5428308a5f41b7dd97182c9.jpg; PDF page 54; full -->

```text
PART 3 Questions 21–30
Questions 21–26
Complete the notes below. Write ONE WORD ONLY for each answer.
What Hazel should analyse about items in newspapers:
• what (21) __________ the item is on
• the (22) __________ of the item, including the headline
• any (23) __________ accompanying the item
• the (24) __________ of the item, e.g. what’s made prominent
• the writer’s main (25) __________
• the (26) __________ the writer may make about the reader
Questions 27–30
What does Hazel decide to do about each of the following types of articles?
Write the correct letter, A, B or C, next to Questions 27–30.
A She will definitely look for a suitable article.
B She may look for a suitable article.
C She definitely won’t look for an article.
Types of articles
27 national news item __________
28 editorial __________
29 human interest __________
30 arts __________
```

[Original question page](assets/1b21d2ba8c68f4ae8f3c1c5bf3d66605e54f4b64a5428308a5f41b7dd97182c9.jpg)

### Part 4

<!-- Source: /api/assets/040cb4b6bc47687515b21e2d6d98434266ddcabd6529a4b541f2d6f3fd5033b5.jpg; PDF page 55; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Early history of keeping clean
Prehistoric times:
• water was used to wash off (31) __________
Ancient Babylon:
• soap-like material found in (32) __________ cylinders
Ancient Greece:
• people cleaned themselves with sand and other substances
• used a strigil – scraper made of (33) __________
• washed clothes in streams
Ancient Germany and Gaul:
• used soap to colour their (34) __________
Ancient Rome:
• animal fat, ashes and clay mixed through action of rain, used for washing clothes
• from about 312 BC, water carried to Roman (35) __________ by aqueducts
Europe in Middle Ages:
• decline in bathing contributed to occurrence of (36) __________
• (37) __________ began to be added to soap
Europe from 17th century:
• 1600s: cleanliness and bathing started becoming usual
• 1791: Leblanc invented a way of making soda ash from (38) __________
• early 1800s: Chevreul turned soapmaking into a (39) __________
• from 1800s, there was no longer a (40) __________ on soap
```

[Original question page](assets/040cb4b6bc47687515b21e2d6d98434266ddcabd6529a4b541f2d6f3fd5033b5.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/fbec72faf2a0cec4c129b990bf48c5630944306039245cef2463c460be358e2a.jpg; PDF page 56; full -->

```text
Test 3
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Henry Moore (1898-1986)
The British sculptor Henry Moore was a leading figure
in the 20th-century art world
Henry Moore was born in Castleford, a small town near Leeds in the north of England. He
was the seventh child of Raymond Moore and his wife Mary Baker. He studied at Castleford
Grammar School from 1909 to 1915, where his early interest in art was encouraged by his teacher
Alice Gostick. After leaving school, Moore hoped to become a sculptor, but instead he complied
with his father’s wish that he train as a schoolteacher. He had to abandon his training in 1917
when he was sent to France to fight in the First World War.
After the war, Moore enrolled at the Leeds School of Art, where he studied for two years. In his
first year, he spent most of his time drawing. Although he wanted to study sculpture, no teacher
was appointed until his second year. At the end of that year, he passed the sculpture examination
and was awarded a scholarship to the Royal College of Art in London. In September 1921, he
moved to London and began three years of advanced study in sculpture.
Alongside the instruction he received at the Royal College, Moore visited many of the London
museums, particularly the British Museum, which had a wide-ranging collection of ancient
sculpture. During these visits, he discovered the power and beauty of ancient Egyptian and
African sculpture. As he became increasingly interested in these ‘primitive’ forms of art, he
turned away from European sculptural traditions.
After graduating, Moore spent the first six months of 1925 travelling in France. When he visited
the Trocadero Museum in Paris, he was impressed by a cast of a Mayan* sculpture of the rain
spirit. It was a male reclining figure with its knees drawn up together, and its head at a right angle
to its body. Moore became fascinated with this stone sculpture, which he thought had a power
and originality that no other stone sculpture possessed. He himself started carving a variety of
subjects in stone, including depictions of reclining women, mother-and-child groups, and masks.
Moore’s exceptional talent soon gained recognition, and in 1926 he started work as a sculpture
instructor at the Royal College. In 1933, he became a member of a group of young artists called
Unit One. The aim of the group was to convince the English public of the merits of the emerging
international movement in modern art and architecture.
*Mayan: belonging to an ancient civilisation that inhabited parts of current-day Mexico, Guatemala, Belize, El Salvador and Honduras.
58
```

[Original question page](assets/fbec72faf2a0cec4c129b990bf48c5630944306039245cef2463c460be358e2a.jpg)

<!-- Source: /api/assets/7c20e53649940f84086df39d4ce73ca15e5d58a0646253eff1c455ea403dd40d.jpg; PDF page 57; full -->

```text
Reading
Around this time, Moore moved away from the human figure to experiment with abstract shapes.
In 1931, he held an exhibition at the Leicester Galleries in London. His work was enthusiastically
welcomed by fellow sculptors, but the reviews in the press were extremely negative and turned
Moore into a notorious figure. There were calls for his resignation from the Royal College,
and the following year, when his contract expired, he left to start a sculpture department at the
Chelsea School of Art in London.
Throughout the 1930s, Moore did not show any inclination to please the British public. He
became interested in the paintings of the Spanish artist Pablo Picasso, whose work inspired him
to distort the human body in a radical way. At times, he seemed to abandon the human figure
altogether. The pages of his sketchbooks from this period show his ideas for abstract sculptures
that bore little resemblance to the human form.
In 1940, during the Second World War, Moore stopped teaching at the Chelsea School and moved
to a farmhouse about 20 miles north of London. A shortage of materials forced him to focus
on drawing. He did numerous small sketches of Londoners, later turning these ideas into large
coloured drawings in his studio. In 1942, he returned to Castleford to make a series of sketches of
the miners who worked there.
In 1944, Harlow, a town near London, offered Moore a commission for a sculpture depicting
a family. The resulting work signifies a dramatic change in Moore’s style, away from the
experimentation of the 1930s towards a more natural and humanistic subject matter. He did
dozens of studies in clay for the sculpture, and these were cast in bronze and issued in editions of
seven to nine copies each. In this way, Moore’s work became available to collectors all over the
world. The boost to his income enabled him to take on ambitious projects and start working on
the scale he felt his sculpture demanded.
Critics who had begun to think that Moore had become less revolutionary were proven wrong
by the appearance, in 1950, of the first of Moore’s series of standing figures in bronze, with their
harsh and angular pierced forms and distinct impression of menace. Moore also varied his subject
matter in the 1950s with such works as Warrior with Shield and Falling Warrior. These were rare
examples of Moore’s use of the male figure and owe something to his visit to Greece in 1951,
when he had the opportunity to study ancient works of art.
In his final years, Moore created the Henry Moore Foundation to promote art appreciation and
to display his work. Moore was the first modern English sculptor to achieve international critical
acclaim and he is still regarded as one of the most important sculptors of the 20th century.
59
```

[Original question page](assets/7c20e53649940f84086df39d4ce73ca15e5d58a0646253eff1c455ea403dd40d.jpg)

<!-- Source: /api/assets/180cb330992220874f54b0986eefbc040b9cf9204beeaadfd1f457f6bd12edec.jpg; PDF page 58; full -->

```text
Test 3
Questions 1-7
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-7 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 On leaving school, Moore did what his father wanted him to do.
2 Moore began studying sculpture in his first term at the Leeds School of Art.
3 When Moore started at the Royal College of Art, its reputation for teaching
sculpture was excellent.
4 Moore became aware of ancient sculpture as a result of visiting London museums.
5 The Trocadero Museum's Mayan sculpture attracted a lot of public interest.
6 Moore thought the Mayan sculpture was similar in certain respects to other stone
sculptures.
7 The artists who belonged to Unit One wanted to make modern art and architecture
more popular.
60
```

[Original question page](assets/180cb330992220874f54b0986eefbc040b9cf9204beeaadfd1f457f6bd12edec.jpg)

<!-- Source: /api/assets/eb6258c0bb423cd86c504f061b752e0902e321586cffce4260968a9f19e8f248.jpg; PDF page 59; full -->

```text
Questions 8–13
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 8–13 on your answer sheet.
Moore’s career as an artist
1930s
• Moore’s exhibition at the Leicester Galleries is criticised by the press
• Moore is urged to offer his (8) __________ and leave the Royal College
1940s
• Moore turns to drawing because (9) __________ for sculpting are not readily available
• While visiting his hometown, Moore does some drawings of (10) __________
• Moore is employed to produce a sculpture of a (11) __________
• (12) __________ start to buy Moore’s work
• Moore’s increased (13) __________ makes it possible for him to do more ambitious sculptures
1950s
• Moore’s series of bronze figures marks a further change in his style
```

[Original question page](assets/eb6258c0bb423cd86c504f061b752e0902e321586cffce4260968a9f19e8f248.jpg)

<!-- Source: /api/assets/86e21bc7e59546ae032cef8474a224274db36d7614a5bce2d68203ad2e921325.jpg; PDF page 60; full -->

```text
Test 3
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 on pages 63 and 64.
Questions 14-20
Reading Passage 2 has seven sections, A-G.
Choose the correct heading for each section from the list of headings below.
Write the correct number, i-x, in boxes 14-20 on your answer sheet.
List of Headings
i Getting the finance for production
ii An unexpected benefit
iii From initial inspiration to new product
iv The range of potential customers for the device
v What makes the device different from alternatives
vi Cleaning water from a range of sources
vii Overcoming production difficulties
viii Profit not the primary goal
ix A warm welcome for the device
x The number of people affected by water shortages
14 Section A
15 Section B
16 Section C
17 Section D
18 Section E
19 Section F
20 Section G
62
```

[Original question page](assets/86e21bc7e59546ae032cef8474a224274db36d7614a5bce2d68203ad2e921325.jpg)

<!-- Source: /api/assets/5ae4395cc55085b10a5c73ad93b2cd088d5b72242ac0adeb44fe4580b1d4c0ac.jpg; PDF page 61; full -->

```text
Reading
The Desolenator: producing clean water
A Travelling around Thailand in the 1990s, William Janssen was impressed with the
basic rooftop solar heating systems that were on many homes, where energy from
the sun was absorbed by a plate and then used to heat water for domestic use. Two
decades later Janssen developed that basic idea he saw in Southeast Asia into a
portable device that uses the power from the sun to purify water.
B The Desolenator operates as a mobile desalination unit that can take water from
different places, such as the sea, rivers, boreholes and rain, and purify it for human
consumption. It is particularly valuable in regions where natural groundwater
reserves have been polluted, or where seawater is the only water source available.
Janssen saw that there was a need for a sustainable way to clean water in both the
developing and the developed countries when he moved to the United Arab Emirates
and saw large-scale water processing. ‘I was confronted with the enormous carbon
footprint that the Gulf nations have because of all of the desalination that they do,’
he says.
C The Desolenator can produce 15 litres of drinking water per day, enough to sustain
a family for cooking and drinking. Its main selling point is that unlike standard
desalination techniques, it doesn’t require a generated power supply: just sunlight. It
measures 120cm by 90cm, and is easy to transport, thanks to its two wheels. Water
enters through a pipe, and flows as a thin film between a sheet of double glazing and
the surface of a solar panel, where it is heated by the sun. The warm water flows into
a small boiler (heated by a solar-powered battery) where it is converted to steam.
When the steam cools, it becomes distilled water. The device has a very simple filter
to trap particles, and this can easily be shaken to remove them. There are two tubes
for liquid coming out: one for the waste — salt from seawater, fluoride, etc. — and
another for the distilled water. The performance of the unit is shown on an LCD
screen and transmitted to the company which provides servicing when necessary.
D A recent analysis found that at least two-thirds of the world’s population lives
with severe water scarcity for at least a month every year. Janssen says that by
2030 half of the world’s population will be living with water stress — where the
demand exceeds the supply over a certain period of time. ‘It is really important that
a sustainable solution is brought to the market that is able to help these people,’
he says. Many countries ‘don’t have the money for desalination plants, which are
very expensive to build. They don’t have the money to operate them, they are very
maintenance intensive, and they don’t have the money to buy the diesel to run the
desalination plants, so it is a really bad situation.’
63
```

[Original question page](assets/5ae4395cc55085b10a5c73ad93b2cd088d5b72242ac0adeb44fe4580b1d4c0ac.jpg)

<!-- Source: /api/assets/65f46d54fb1176e9649bdfd6e77459aabb32b39f8afc9ad87a1c6a8561494ac9.jpg; PDF page 62; full -->

```text
Test 3

64
E The device is aimed at a wide variety of users — from homeowners in the developing
world who do not have a constant supply of water to people living off the grid in
rural parts of the US. The first commercial versions of the Desolenator are expected
to be in operation in India early next year, after field tests are carried out. The market
for the self-sufficient devices in developing countries is twofold — those who cannot
afford the money for the device outright and pay through microfinance, and middle-
income homes that can lease their own equipment. ‘People in India don’t pay for a
fridge outright; they pay for it over six months. They would put the Desolenator on
their roof and hook it up to their municipal supply and they would get very reliable
drinking water on a daily basis,’ Janssen says. In the developed world, it is aimed
at niche markets where tap water is unavailable — for camping, on boats, or for the
military, for instance.
F Prices will vary according to where it is bought. In the developing world, the price
will depend on what deal aid organisations can negotiate. In developed countries, it
is likely to come in at $1,000 (£685) a unit, said Janssen. ‘We are a venture with a
social mission. We are aware that the product we have envisioned is mainly finding
application in the developing world and humanitarian sector and that this is the way
we will proceed. We do realise, though, that to be a viable company there is a bottom
line to keep in mind,’ he says.
G The company itself is based at Imperial College London, although Janssen, its chief
executive, still lives in the UAE. It has raised £340,000 in funding so far. Within two
years, he says, the company aims to be selling 1,000 units a month, mainly in the
humanitarian field. They are expected to be sold in areas such as Australia, northern
Chile, Peru, Texas and California.
```

[Original question page](assets/65f46d54fb1176e9649bdfd6e77459aabb32b39f8afc9ad87a1c6a8561494ac9.jpg)

<!-- Source: /api/assets/a56e172a36f06a4c72f6858be112e72fe15547ab636516d4a59cc928cab26d38.jpg; PDF page 63; full -->

```text
Reading
Questions 21-26
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 21-26 on your answer sheet.
How the Desolenator works
The energy required to operate the Desolenator comes from sunlight. The device can be used in different locations, as it has (21) __________. Water is fed into a pipe, and a (22) __________ of water flows over a solar panel. The water then enters a boiler, where it turns into steam. Any particles in the water are caught in a (23) __________. The purified water comes out through one tube, and all types of (24) __________ come out through another. A screen displays the (25) __________ of the device, and transmits the information to the company so that they know when the Desolenator requires (26) __________.
```

[Original question page](assets/a56e172a36f06a4c72f6858be112e72fe15547ab636516d4a59cc928cab26d38.jpg)

<!-- Source: /api/assets/28fe2ed6baf63ac7931cd4bfe60145fbd83c57d9010b9e03ba5f22474c7a6621.jpg; PDF page 64; full -->

```text
Test 3
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Why fairy tales are really scary tales
Some people think that fairy tales are just stories to amuse children, but their
universal and enduring appeal may be due to more serious reasons
People of every culture tell each other fairy tales but the same story often takes a variety of forms
in different parts of the world. In the story of Little Red Riding Hood that European children are
familiar with, a young girl on the way to see her grandmother meets a wolf and tells him where
she is going. The wolf runs on ahead and disposes of the grandmother, then gets into bed dressed
in the grandmother’s clothes to wait for Little Red Riding Hood. You may think you know the
story — but which version? In some versions, the wolf swallows up the grandmother, while in
others it locks her in a cupboard. In some stories Red Riding Hood gets the better of the wolf on
her own, while in others a hunter or a woodcutter hears her cries and comes to her rescue.
The universal appeal of these tales is frequently attributed to the idea that they contain cautionary
messages: in the case of Little Red Riding Hood, to listen to your mother, and avoid talking
to strangers. ‘It might be what we find interesting about this story is that it’s got this survival-
relevant information in it,’ says anthropologist Jamie Tehrani at Durham University in the UK.
But his research suggests otherwise. ‘We have this huge gap in our knowledge about the history
and prehistory of storytelling, despite the fact that we know this genre is an incredibly ancient
one,’ he says. That hasn’t stopped anthropologists, folklorists* and other academics devising
theories to explain the importance of fairy tales in human society. Now Tehrani has found a way
to test these ideas, borrowing a technique from evolutionary biologists.
To work out the evolutionary history, development and relationships among groups of organisms,
biologists compare the characteristics of living species in a process called ‘phylogenetic analysis’.
Tehrani has used the same approach to compare related versions of fairy tales to discover how
they have evolved and which elements have survived longest.
Tehrani’s analysis focused on Little Red Riding Hood in its many forms, which include another
Western fairy tale known as The Wolf and the Kids. Checking for variants of these two tales and
similar stories from Africa, East Asia and other regions, he ended up with 58 stories recorded
from oral traditions. Once his phylogenetic analysis had established that they were indeed related,
he used the same methods to explore how they have developed and altered over time.
First he tested some assumptions about which aspects of the story alter least as it evolves, indicating
their importance. Folklorists believe that what happens in a story is more central to the story
than the characters in it — that visiting a relative, only to be met by a scary animal in disguise, is
*Folklorists: those who study traditional stories
66
```

[Original question page](assets/28fe2ed6baf63ac7931cd4bfe60145fbd83c57d9010b9e03ba5f22474c7a6621.jpg)

<!-- Source: /api/assets/c4dc8f4f837a6415a80673148a06ea3ce1ae5d0e9667fc19cfcc6e095a139875.jpg; PDF page 65; full -->

```text
Reading
more fundamental than whether the visitor is a little girl or three siblings, or the animal is a tiger
instead of a wolf.
However, Tehrani found no significant difference in the rate of evolution of incidents compared
with that of characters. ‘Certain episodes are very stable because they are crucial to the story, but
there are lots of other details that can evolve quite freely,’ he says. Neither did his analysis support
the theory that the central section of a story is the most conserved part. He found no significant
difference in the flexibility of events there compared with the beginning or the end.
But the really big surprise came when he looked at the cautionary elements of the story. ‘Studies
on hunter-gatherer folk tales suggest that these narratives include really important information
about the environment and the possible dangers that may be faced there — stuff that’s relevant
to survival,’ he says. Yet in his analysis such elements were just as flexible as seemingly trivial
details. What, then, is important enough to be reproduced from generation to generation?
The answer, it would appear, is fear — blood-thirsty and gruesome aspects of the story, such as the
eating of the grandmother by the wolf, turned out to be the best preserved of all. Why are these
details retained by generations of storytellers, when other features are not? Tehrani has an idea:
‘In an oral context, a story won’t survive because of one great teller. It also needs to be interesting
when it’s told by someone who’s not necessarily a great storyteller.’ Maybe being swallowed
whole by a wolf, then cut out of its stomach alive is so gripping that it helps the story remain
popular, no matter how badly it’s told.
Jack Zipes at the University of Minnesota, Minneapolis, is unconvinced by Tehrani’s views on
fairy tales. ‘Even if they’re gruesome, they won’t stick unless they matter,’ he says. He believes
the perennial theme of women as victims in stories like Little Red Riding Hood explains why they
continue to feel relevant. But Tehrani points out that although this is often the case in Western
versions, it is not always true elsewhere. In Chinese and Japanese versions, often known as The
Tiger Grandmother, the villain is a woman, and in both Iran and Nigeria, the victim is a boy.
Mathias Clasen at Aarhus University in Denmark isn’t surprised by Tehrani’s findings. ‘Habits
and morals change, but the things that scare us, and the fact that we seek out entertainment that’s
designed to scare us — those are constant,’ he says. Clasen believes that scary stories teach us what
it feels like to be afraid without having to experience real danger, and so build up resistance to
negative emotions.
67
```

[Original question page](assets/c4dc8f4f837a6415a80673148a06ea3ce1ae5d0e9667fc19cfcc6e095a139875.jpg)

<!-- Source: /api/assets/7061f918d78b5533722c5c5bf5ce1979218eae1d449600981ef5ba61d9920395.jpg; PDF page 66; full -->

```text
Test 3
Questions 27-31
Complete each sentence with the correct ending, A-F, below.
Write the correct letter, A-F, in boxes 27-31 on your answer sheet.
27 In fairy tales, details of the plot
28 Tehrani rejects the idea that the useful lessons for life in fairy tales
29 Various theories about the social significance of fairy tales
30 Insights into the development of fairy tales
31 All the fairy tales analysed by Tehrani
A may be provided through methods used in biological research.
B are the reason for their survival.
C show considerable global variation.
D contain animals which transform to become humans.
E were originally spoken rather than written.
F have been developed without factual basis.
```

[Original question page](assets/7061f918d78b5533722c5c5bf5ce1979218eae1d449600981ef5ba61d9920395.jpg)

<!-- Source: /api/assets/d29047b963bacab88b474c2b2eeaf296a0f3c137cb9147d1fe24e582b63bc351.jpg; PDF page 67; full -->

```text
Reading
Questions 32-36
Complete the summary using the list of words, A-I, below.
Write the correct letter, A-I, in boxes 32-36 on your answer sheet.
Phylogenetic analysis of Little Red Riding Hood
Tehrani used techniques from evolutionary biology to find out if (32) __________ existed among 58 stories from around the world. He also wanted to know which aspects of the stories had fewest (33) __________, as he believed these aspects would be the most important ones. Contrary to other beliefs, he found that some (34) __________ that were included in a story tended to change over time, and that the middle of a story seemed no more important than the other parts. He was also surprised that parts of a story which seemed to provide some sort of (35) __________ were unimportant. The aspect that he found most important in a story’s survival was (36) __________.
A ending
B events
C warning
D links
E records
F variations
G horror
H people
I plot
```

[Original question page](assets/d29047b963bacab88b474c2b2eeaf296a0f3c137cb9147d1fe24e582b63bc351.jpg)

<!-- Source: /api/assets/0f1e5ff85c4ff6bbabe0d8caecdd9b733dd75e13ff2fd3cda54b38853e1021c8.jpg; PDF page 68; full -->

```text
Test 3
Questions 37-40
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 37-40 on your answer sheet.
37 What method did Jamie Tehrani use to test his ideas about fairy tales?
A He compared oral and written forms of the same stories.
B He looked at many different forms of the same basic story.
C He looked at unrelated stories from many different countries.
D He contrasted the development of fairy tales with that of living creatures.
38 When discussing Tehrani’s views, Jack Zipes suggests that
A Tehrani ignores key changes in the role of women.
B stories which are too horrific are not always taken seriously.
C Tehrani overemphasises the importance of violence in stories.
D features of stories only survive if they have a deeper significance.
39 Why does Tehrani refer to Chinese and Japanese fairy tales?
A to indicate that Jack Zipes’ theory is incorrect
B to suggest that crime is a global problem
C to imply that all fairy tales have a similar meaning
D to add more evidence for Jack Zipes’ ideas
40 What does Mathias Clasen believe about fairy tales?
A They are a safe way of learning to deal with fear.
B They are a type of entertainment that some people avoid.
C They reflect the changing values of our society.
D They reduce our ability to deal with real-world problems.
70 = =>[@9 p. 124
```

[Original question page](assets/0f1e5ff85c4ff6bbabe0d8caecdd9b733dd75e13ff2fd3cda54b38853e1021c8.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/5055f018a42dd860de3ac26da6beb503317cf91323bab0064f082b451eb80ecd.jpg; PDF page 69; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagram below shows how instant noodles are manufactured.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/5055f018a42dd860de3ac26da6beb503317cf91323bab0064f082b451eb80ecd.jpg)

![Original figure](assets/5055f018a42dd860de3ac26da6beb503317cf91323bab0064f082b451eb80ecd.jpg)

### Task 2

<!-- Source: /api/assets/0e59b77b90380c1a043feb85fe2515ff11fffb517eecd7cc75cad10ab9e348f3.jpg; PDF page 70; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people say that advertising is extremely successful at persuading us to buy things. Other people think that advertising is so common that we no longer pay attention to it.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/0e59b77b90380c1a043feb85fe2515ff11fffb517eecd7cc75cad10ab9e348f3.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/27d62505cba186f4611160ad539dd243ef3232f89df01cf3457a77037b3d4a79.jpg; PDF page 71; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Swimming
Did you learn to swim when you were a child? [Why/Why not?]
How often do you go swimming now? [Why/Why not?]
What places are there for swimming where you live? [Why?]
Do you think it would be more enjoyable to go swimming outdoors or at an indoor
pool? [Why?]
PART 2
Describe a famous business person that you know about.
You should say:
who this person is
what kind of business this person is involved in
what you know about this business person
and explain what you think of this business person.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Famous people today
Example questions:
What kinds of people are most famous in your country today?
Why are there so many stories about famous people in the news?
Do you agree or disagree that many young people today want to be famous?
Advantages of being famous
Example questions:
Do you think it is easy for famous people to earn a lot of money?
Why might famous people enjoy having fans?
In what ways could famous people use their influence to do good things in the world?
73
```

[Original question page](assets/27d62505cba186f4611160ad539dd243ef3232f89df01cf3457a77037b3d4a79.jpg)

### Part 2

<!-- Source: /api/assets/27d62505cba186f4611160ad539dd243ef3232f89df01cf3457a77037b3d4a79.jpg; PDF page 71; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Swimming
Did you learn to swim when you were a child? [Why/Why not?]
How often do you go swimming now? [Why/Why not?]
What places are there for swimming where you live? [Why?]
Do you think it would be more enjoyable to go swimming outdoors or at an indoor
pool? [Why?]
PART 2
Describe a famous business person that you know about.
You should say:
who this person is
what kind of business this person is involved in
what you know about this business person
and explain what you think of this business person.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Famous people today
Example questions:
What kinds of people are most famous in your country today?
Why are there so many stories about famous people in the news?
Do you agree or disagree that many young people today want to be famous?
Advantages of being famous
Example questions:
Do you think it is easy for famous people to earn a lot of money?
Why might famous people enjoy having fans?
In what ways could famous people use their influence to do good things in the world?
73
```

[Original question page](assets/27d62505cba186f4611160ad539dd243ef3232f89df01cf3457a77037b3d4a79.jpg)

### Part 3

<!-- Source: /api/assets/27d62505cba186f4611160ad539dd243ef3232f89df01cf3457a77037b3d4a79.jpg; PDF page 71; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Swimming
Did you learn to swim when you were a child? [Why/Why not?]
How often do you go swimming now? [Why/Why not?]
What places are there for swimming where you live? [Why?]
Do you think it would be more enjoyable to go swimming outdoors or at an indoor
pool? [Why?]
PART 2
Describe a famous business person that you know about.
You should say:
who this person is
what kind of business this person is involved in
what you know about this business person
and explain what you think of this business person.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Famous people today
Example questions:
What kinds of people are most famous in your country today?
Why are there so many stories about famous people in the news?
Do you agree or disagree that many young people today want to be famous?
Advantages of being famous
Example questions:
Do you think it is easy for famous people to earn a lot of money?
Why might famous people enjoy having fans?
In what ways could famous people use their influence to do good things in the world?
73
```

[Original question page](assets/27d62505cba186f4611160ad539dd243ef3232f89df01cf3457a77037b3d4a79.jpg)
