# 剑雅 11 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/8ffeed88ecb27cecc19946cdc6a98f4bc018e4be80917ef713196f5d3eb1e746.jpg; PDF page 56; full -->

```text
Test 3
LISTENING
SECTION 1 Questions 1-10
Questions 1-6
Choose the correct letter, A, B or C.
Free activities in the Burnham area
Example
The caller wants to find out about events on
A 27 June.
B 28 June.
C 29 June. [example answer]
1 The ‘Family Welcome’ event in the
art gallery begins at
A 10 am.
B 10.30 am.
C 2 pm.
2 The film that is now shown in the
'Family Welcome' event is about
A sculpture.
B painting.
C ceramics.
3 When do most of the free concerts
take place?
A in the morning
B at lunchtime
C in the evening
4 Where will the 4 pm concert of Latin
American music take place?
A in a museum
B in a theatre
C in a library
5 The boat race begins at
A Summer Pool.
B Charlesworth Bridge.
C Offord Marina.
6 One of the boat race teams
A won a regional competition
earlier this year.
B has represented the region in a
national competition.
C has won several regional
competitions.
57
```

[Original question page](assets/8ffeed88ecb27cecc19946cdc6a98f4bc018e4be80917ef713196f5d3eb1e746.jpg)

<!-- Source: /api/assets/504260ddf6a0a0ed43ba207c3fb9ae366cc45a457e367ed30b541795625221bd.jpg; PDF page 57; full -->

```text
Questions 7-10
Complete the sentences below.
Write ONE WORD ONLY for each answer.
Paxton Nature Reserve
7 Paxton is a good place for seeing rare ........................................... all year round.
8 This is a particularly good time for seeing certain unusual ........
9 Visitors will be able to learn about .......…........ .... .... ... ... and then collect some.
10 Part of the ..............……............…........ has been made suitable for swimming.
58
```

[Original question page](assets/504260ddf6a0a0ed43ba207c3fb9ae366cc45a457e367ed30b541795625221bd.jpg)

### Part 2

<!-- Source: /api/assets/3ff01ea7db76be5e3e53b6a10bf085966510b7a914305e0c778bdf0245fc04a4.jpg; PDF page 58; full -->

```text
SECTION 2 Questions 11-20
Questions 11-15
Choose the correct letter, A, B or C.
Changes in Barford over the last 50 years
11 In Shona’s opinion, why do fewer people use buses in Barford these days?
A The buses are old and uncomfortable.
B Fares have gone up too much.
C There are not so many bus routes.
12 What change in the road network is known to have benefited the town most?
A the construction of a bypass
B the development of cycle paths
C the banning of cars from certain streets
13 What is the problem affecting shopping in the town centre?
A lack of parking spaces
B lack of major retailers
C lack of restaurants and cafes
14 What does Shona say about medical facilities in Barford?
A There is no hospital.
B New medical practices are planned.
C The number of dentists is too low.
15 The largest number of people are employed in
A manufacturing.
B services.
C education.
59
```

[Original question page](assets/3ff01ea7db76be5e3e53b6a10bf085966510b7a914305e0c778bdf0245fc04a4.jpg)

<!-- Source: /api/assets/93a388a0a7036ebd76f9112a1644bdb96df9b5709c1607870f5d9afc1fbc656a.jpg; PDF page 59; full -->

```text
Questions 16–20
What is planned for each of the following facilities?
Choose FIVE answers from the box and write the correct letter, A–G, next to Questions 16–20.
Plans
A It will move to a new location.
B It will have its opening hours extended.
C It will be refurbished.
D It will be used for a different purpose.
E It will have its opening hours reduced.
F It will have new management.
G It will be expanded.
Facilities
16 railway station car park __________
17 cinema __________
18 indoor market __________
19 library __________
20 nature reserve __________
```

[Original question page](assets/93a388a0a7036ebd76f9112a1644bdb96df9b5709c1607870f5d9afc1fbc656a.jpg)

### Part 3

<!-- Source: /api/assets/7540c5460777a4a101dc04d32f8d2617c7bd76cd3eda2023ed250adb73d575f7.jpg; PDF page 60; full -->

```text
SECTION 3 Questions 21–30
Questions 21–26
Complete the table below. Write ONE WORD ONLY for each answer.
| Subject of drawing | Change to be made |
| --- | --- |
| A (21) __________ surrounded by trees | Add Malcolm and a (22) __________ noticing him |
| People who are (23) __________ outside the forest | Add Malcolm sitting on a tree trunk and (24) __________ |
| Ice-skaters on (25) __________ covered with ice | Add a (26) __________ for each person |
```

[Original question page](assets/7540c5460777a4a101dc04d32f8d2617c7bd76cd3eda2023ed250adb73d575f7.jpg)

<!-- Source: /api/assets/4c992e8aabee18b47b4c4f04668f2439bca3b2373408e2d21006090467e2924d.jpg; PDF page 61; full -->

```text
Questions 27-30
Who is going to write each of the following parts of the report?
Write the correct letter, A-D, next to Questions 27-30.
Parts of the report
A Helen only
B Jeremy only
C both Helen and Jeremy
D neither Helen nor Jeremy
27 how they planned the project
28 how they had ideas for their stories
29 an interpretation of their stories
30 comments on the illustrations
62
```

[Original question page](assets/4c992e8aabee18b47b4c4f04668f2439bca3b2373408e2d21006090467e2924d.jpg)

### Part 4

<!-- Source: /api/assets/f329426e68868e8e246a2b594452e58e4bae97b3aa72aae0f1790b706223d245.jpg; PDF page 62; full -->

```text
SECTION 4 Questions 31-40
Complete the notes below.
Write ONE WORD ONLY for each answer.
ETHNOGRAPHY IN BUSINESS
Ethnography: research which explores human cultures
It can be used in business:
• to investigate customer needs and 31 ..
to help companies develop new designs
Examples of ethnographic research in business
Kitchen equipment
• Researchers found that cooks could not easily see the 32 ....
in measuring cups.
Cell phones
In Uganda, customers paid to use the cell phones of entrepreneurs.
These customers wanted to check the 33 ... …............................... used.
Computer companies
There was a need to develop 34 ...…·……… to improve communication
between system administrators and colleagues.
Hospitals
Nurses needed to access information about 35 ........................................... in different
parts of the hospital.
Airlines
Respondents recorded information about their 36 ................................... while
travelling.
63
```

[Original question page](assets/f329426e68868e8e246a2b594452e58e4bae97b3aa72aae0f1790b706223d245.jpg)

<!-- Source: /api/assets/3dbae56ca4633cbc2ce303c3c78c797bfcac76a4fca8354d64c8b06086e1c1ec.jpg; PDF page 63; full -->

```text
64
Principles of ethnographic research in business
• The researcher does not start off with a hypothesis.
Participants may be selected by criteria such as age, 37 ......... ..........…............. or
product used.
• The participants must feel 38 .... .......... ........... ........... about taking part in the
research.
There is usually direct 39 .....…................................... of the participants.
The interview is guided by the participant.
A lot of time is needed for the 40 ........……………….. of the data.
• Researchers look for a meaningful pattern in the data.
```

[Original question page](assets/3dbae56ca4633cbc2ce303c3c78c797bfcac76a4fca8354d64c8b06086e1c1ec.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/8f0bdc899524af8ecfa7290bc9c12618615ec05e2a1123cee770bf1c0d7ccbc9.jpg; PDF page 64; full -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
THE STORY OF SILK
The history of the world’s most luxurious fabric,
from ancient China to the present day
Silk is a fine, smooth material produced
from the cocoons - soft protective shells
— that are made by mulberry silkworms
(insect larvae). Legend has it that it was
Lei Tzu, wife of the Yellow Emperor,
ruler of China in about 3000 BC, who
discovered silkworms. One account of the
story goes that as she was taking a walk
in her husband's gardens, she discovered
that silkworms were responsible for the
destruction of several mulberry trees. She
collected a number of cocoons and sat
down to have a rest. It just so happened
that while she was sipping some tea, one
of the cocoons that she had collected
landed in the hot tea and started to
unravel into a fine thread. Lei Tzu found
that she could wind this thread around her
fingers. Subsequently, she persuaded her
husband to allow her to rear silkworms
on a grove of mulberry trees. She also
devised a special reel to draw the fibres
from the cocoon into a single thread so
that they would be strong enough to be
woven into fabric. While it is unknown
just how much of this is true, it is certainly
known that silk cultivation has existed in
China for several millennia.
Originally, silkworm farming was solely
restricted to women, and it was they
who were responsible for the growing,
harvesting and weaving. Silk quickly grew
into a symbol of status, and originally,
only royalty were entitled to have clothes
made of silk. The rules were gradually
relaxed over the years until finally during
the Qing Dynasty (1644-1911 AD), even
peasants, the lowest caste, were also
entitled to wear silk. Sometime during the
Han Dynasty (206 BC-220 AD), silk was
so prized that it was also used as a unit of
currency. Government officials were paid
their salary in silk, and farmers paid their
taxes in grain and silk. Silk was also used
as diplomatic gifts by the emperor. Fishing
lines, bowstrings, musical instruments
and paper were all made using silk. The
earliest indication of silk paper being used
was discovered in the tomb of a noble
who is estimated to have died around
168 AD.
Demand for this exotic fabric eventually
created the lucrative trade route now
known as the Silk Road, taking silk
westward and bringing gold, silver and
65
```

[Original question page](assets/8f0bdc899524af8ecfa7290bc9c12618615ec05e2a1123cee770bf1c0d7ccbc9.jpg)

<!-- Source: /api/assets/5f69e5eedb46b07e04ca7f4499dbfd393ff4c8532e48a8151d6075dc5471e0ee.jpg; PDF page 65; full -->

```text
wool to the East. It was named the Silk
Road after its most precious commodity,
which was considered to be worth more
than gold. The Silk Road stretched over
6,000 kilometres from Eastern China to
the Mediterranean Sea, following the
Great Wall of China, climbing the Pamir
mountain range, crossing modern-day
Afghanistan and going on to the Middle
East, with a major trading market in
Damascus. From there, the merchandise
was shipped across the Mediterranean
Sea. Few merchants travelled the entire
route; goods were handled mostly by a
series of middlemen.
With the mulberry silkworm being native
to China, the country was the world’s sole
producer of silk for many hundreds of
years. The secret of silk-making eventually
reached the rest of the world via the
Byzantine Empire, which ruled over the
Mediterranean region of southern Europe,
North Africa and the Middle East during
the period 330-1453 AD. According to
another legend, monks working for the
Byzantine emperor Justinian smuggled
silkworm eggs to Constantinople
(Istanbul in modern-day Turkey) in 550
AD, concealed inside hollow bamboo
walking canes. The Byzantines were as
secretive as the Chinese, however, and
for many centuries the weaving and
trading of silk fabric was a strict imperial
monopoly. Then in the seventh century,
the Arabs conquered Persia, capturing
their magnificent silks in the process.
Silk production thus spread through
Africa, Sicily and Spain as the Arabs
swept through these lands. Andalusia in
southern Spain was Europe’s main silk-
producing centre in the tenth century. By
the thirteenth century, however, Italy had
become Europe’s leader in silk production
and export. Venetian merchants traded
extensively in silk and encouraged silk
growers to settle in Italy. Even now,
silk processed in the province of Como
in northern Italy enjoys an esteemed
reputation.
The nineteenth century and
industrialisation saw the downfall of the
European silk industry. Cheaper Japanese
silk, trade in which was greatly facilitated
by the opening of the Suez Canal, was one
of the many factors driving the trend. Then
in the twentieth century, new manmade
fibres, such as nylon, started to be used in
what had traditionally been silk products,
such as stockings and parachutes. The two
world wars, which interrupted the supply
of raw material from Japan, also stifled the
European silk industry. After the Second
World War, Japan’s silk production was
restored, with improved production and
quality of raw silk. Japan was to remain
the world’s biggest producer of raw silk,
and practically the only major exporter
of raw silk, until the 1970s. However, in
more recent decades, China has gradually
recaptured its position as the world’s
biggest producer and exporter of raw
silk and silk yarn. Today, around 125,000
metric tons of silk are produced in the
world, and almost two thirds of that
production takes place in China.
```

[Original question page](assets/5f69e5eedb46b07e04ca7f4499dbfd393ff4c8532e48a8151d6075dc5471e0ee.jpg)

<!-- Source: /api/assets/084c57b7fb270a390e1dcffb0779dc668a9f877ca4bcb4ca7218da3cd3e4f004.jpg; PDF page 66; full -->

```text
Questions 1-9
Complete the notes below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1-9 on your answer sheet.
THE STORY OF SILK
Early silk production in China
• Around 3000 BC, according to legend:
silkworm cocoon fell into emperor’s wife’s 1
emperor’s wife invented a 2 .... to pull out silk fibres
Only 3 ...................... were allowed to produce silk
Only 4 .... ... . .... were allowed to wear silk
Silk used as a form of 5 ...... .
e.g. farmers' taxes consisted partly of silk
Silk used for many purposes
e.g. evidence found of 6 ......…........…. made from silk around 168 AD
Silk reaches rest of world
Merchants use Silk Road to take silk westward and bring back 7 .... . ............ and
precious metals
550AD: 8 ............…....... hide silkworm eggs in canes and take them to Constantinople
• Silk production spreads across Middle East and Europe
• 20th century: 9 ....... .......... and other manmade fibres cause decline in silk production
67
```

[Original question page](assets/084c57b7fb270a390e1dcffb0779dc668a9f877ca4bcb4ca7218da3cd3e4f004.jpg)

<!-- Source: /api/assets/b8c479472d65951c6381b51430b15d3be882cc7f8be21d94fb9a75c6169ceea0.jpg; PDF page 67; full -->

```text
Questions 10-13
Do the following statements agree with the information in Reading Passage 1?
In boxes 10-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
10 Gold was the most valuable material transported along the Silk Road.
11 Most tradesmen only went along certain sections of the Silk Road.
12 The Byzantines spread the practice of silk production across the West.
13 Silk yarn makes up the majority of silk currently exported from China.
68
```

[Original question page](assets/b8c479472d65951c6381b51430b15d3be882cc7f8be21d94fb9a75c6169ceea0.jpg)

<!-- Source: /api/assets/fadbc16e18ed9501ab01a87be6f82a2b7d495cb42e349bc069b4bda60afce68b.jpg; PDF page 68; full -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Great Migrations
Animal migration, however it is defined,
is far more than just the movement of
animals. It can loosely be described as travel
that takes place at regular intervals — often
in an annual cycle — that may involve many
members of a species, and is rewarded only
after a long journey. It suggests inherited
instinct. The biologist Hugh Dingle has
identified five characteristics that apply, in
varying degrees and combinations, to all
migrations. They are prolonged movements
that carry animals outside familiar habitats;
they tend to be linear, not zigzaggy; they
involve special behaviours concerning
preparation (such as overfeeding) and
arrival; they demand special allocations
of energy. And one more: migrating
animals maintain an intense attentiveness
to the greater mission, which keeps
them undistracted by temptations and
undeterred by challenges that would turn
other animals aside.
An arctic tern, on its 20,000 km flight
from the extreme south of South America
to the Arctic circle, will take no notice
of a nice smelly herring offered from a
bird-watcher's boat along the way. While
local gulls will dive voraciously for such
handouts, the tern flies on. Why? The arctic
tern resists distraction because it is driven
at that moment by an instinctive sense of
something we humans find admirable:
larger purpose. In other words, it is
determined to reach its destination. The
bird senses that it can eat, rest and mate
later. Right now it is totally focused on
the journey; its undivided intent is arrival.
Reaching some gravelly coastline in the
Arctic, upon which other arctic terns have
converged, will serve its larger purpose
as shaped by evolution: finding a place, a
time, and a set of circumstances in which it
can successfully hatch and rear offspring
But migration is a complex issue, and
biologists define it differently, depending
in part on what sorts of animals they study
Joel Berger, of the University of Montana,
who works on the American pronghorn
and other large terrestrial mammals, prefers
what he calls a simple, practical definition
suited to his beasts: ‘movements from
a seasonal home area away to another
home area and back again’. Generally the
reason for such seasonal back-and-forth
movement is to seek resources that aren't
available within a single area year-round.
But daily vertical movements by
zooplankton in the ocean — upward by
night to seek food, downward by day to
escape predators — can also be considered
migration. So can the movement of aphids
when, having depleted the young leaves
on one food plant, their offspring then
fly onward to a different host plant, with
no one aphid ever returning to where it
started.
Dingle is an evolutionary biologist who
studies insects. His definition is more
intricate than Berger's, citing those five
features that distinguish migration from
other forms of movement. They allow
for the fact that, for example, aphids will
69
```

[Original question page](assets/fadbc16e18ed9501ab01a87be6f82a2b7d495cb42e349bc069b4bda60afce68b.jpg)

<!-- Source: /api/assets/b9458f0b796da98579154063b2b7c2d8861b6e53ce41a1619730f6402d410570.jpg; PDF page 69; full -->

```text
become sensitive to blue light (from the
sky) when it’s time for takeoff on their
big journey, and sensitive to yellow light
(reflected from tender young leaves) when
it's appropriate to land. Birds will fatten
themselves with heavy feeding in advance
of a long migrational flight. The value of his
definition, Dingle argues, is that it focuses
attention on what the phenomenon
of wildebeest migration shares with
the phenomenon of the aphids, and
therefore helps guide researchers towards
understanding how evolution has produced
them all.
Human behaviour, however, is having a
detrimental impact on animal migration.
The pronghorn, which resembles an
antelope, though they are unrelated,
is the fastest land mammal of the New
World. One population, which spends the
summer in the mountainous Grand Teton
National Park of the western USA, follows a
narrow route from its summer range in the
mountains, across a river, and down onto
the plains. Here they wait out the frozen
months, feeding mainly on sagebrush
blown clear of snow. These pronghorn are
notable for the invariance of their migration
route and the severity of its constriction
at three bottlenecks. If they can’t pass
through each of the three during their
spring migration, they can’t reach their
bounty of summer grazing; if they can’t
pass through again in autumn, escaping
south onto those windblown plains, they
are likely to die trying to overwinter in the
deep snow. Pronghorn, dependent on
distance vision and speed to keep safe from
predators, traverse high, open shoulders
of land, where they can see and run. At
one of the bottlenecks, forested hills rise to
form a V, leaving a corridor of open ground
only about 150 metres wide, filled with
private homes. Increasing development is
leading toward a crisis for the pronghorn,
threatening to choke off their passageway.
Conservation scientists, along with some
biologists and land managers within the
USA‘s National Park Service and other
agencies, are now working to preserve
migrational behaviours, not just species
and habitats. A National Forest has
recognised the path of the pronghorn,
much of which passes across its land, as a
protected migration corridor. But neither
the Forest Service nor the Park Service
can control what happens on private
land at a bottleneck. And with certain
other migrating species, the challenge is
complicated further — by vastly greater
distances traversed, more jurisdictions,
more borders, more dangers along the way.
We will require wisdom and resoluteness to
ensure that migrating species can continue
their journeying a while longer.
```

[Original question page](assets/b9458f0b796da98579154063b2b7c2d8861b6e53ce41a1619730f6402d410570.jpg)

<!-- Source: /api/assets/aa86a830cdcef7b0f846dfe015e4ac0f4d3c1367801d40d11fa785f53854b54e.jpg; PDF page 70; full -->

```text
Questions 14-18
Do the following statements agree with the information given in Reading Passage 2?
In boxes 14-18 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
14 Local gulls and migrating arctic terns behave in the same way when offered food.
15 Experts' definitions of migration tend to vary according to their area of study.
16 Very few experts agree that the movement of aphids can be considered migration.
17 Aphids’ journeys are affected by changes in the light that they perceive.
18 Dingle’s aim is to distinguish between the migratory behaviours of different species
71
```

[Original question page](assets/aa86a830cdcef7b0f846dfe015e4ac0f4d3c1367801d40d11fa785f53854b54e.jpg)

<!-- Source: /api/assets/80151902dad0bcd04388a48598ab8fff608f19fe1c86abe29fc1ee3df8b48430.jpg; PDF page 71; full -->

```text
Questions 19-22
Complete each sentence with the correct ending, A-G, below.
Write the correct letter, A-G, in boxes 19-22 on your answer sheet.
19 According to Dingle, migratory routes are likely to
20 To prepare for migration, animals are likely to
21 During migration, animals are unlikely to
22 Arctic terns illustrate migrating animals’ ability to
A be discouraged by difficulties.
B travel on open land where they can look
out for predators.
C eat more than they need for immediate
purposes.
D be repeated daily.
E ignore distractions.
F be governed by the availability of water．
G follow a straight line.
Questions 23–26
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 23-26 on your answer sheet.
The migration of pronghorns
Pronghorns rely on their eyesight and 23 ...... .... to avoid predators. One particular
population’s summer habitat is a national park, and their winter home is on
the 24 ..... .... , where they go to avoid the danger presented by the snow at that time
of year. However, their route between these two areas contains three 25 ..........….........
One problem is the construction of new homes in a narrow 26 ...................... of land on the
pronghorns’ route.
72
```

[Original question page](assets/80151902dad0bcd04388a48598ab8fff608f19fe1c86abe29fc1ee3df8b48430.jpg)

<!-- Source: /api/assets/ac612b54509ad16952d9ba880a050da8bbed3afb90c5e9ddc6fe2ae43d13f019.jpg; PDF page 72; full -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Preface to ‘How the other half thinks:
Adventures in mathematical reasoning’
A Occasionally, in some difficult musical compositions, there are beautiful, but easy
parts — parts so simple a beginner could play them. So it is with mathematics as
well. There are some discoveries in advanced mathematics that do not depend on
specialized knowledge, not even on algebra, geometry, or trigonometry. Instead
they may involve, at most, a little arithmetic, such as ‘the sum of two odd numbers
is even’, and common sense. Each of the eight chapters in this book illustrates this
phenomenon. Anyone can understand every step in the reasoning.
The thinking in each chapter uses at most only elementary arithmetic, and
sometimes not even that. Thus all readers will have the chance to participate in a
mathematical experience, to appreciate the beauty of mathematics, and to become
familiar with its logical, yet intuitive, style of thinking.
B One of my purposes in writing this book is to give readers who haven’t had the
opportunity to see and enjoy real mathematics the chance to appreciate the
mathematical way of thinking. I want to reveal not only some of the fascinating
discoveries, but, more importantly, the reasoning behind them.
In that respect, this book differs from most books on mathematics written for the
general public. Some present the lives of colorful mathematicians. Others describe
important applications of mathematics. Yet others go into mathematical procedures,
but assume that the reader is adept in using algebra.
C I hope this book will help bridge that notorious gap that separates the two cultures:
the humanities and the sciences, or should I say the right brain (intuitive) and the
left brain (analytical, numerical). As the chapters will illustrate, mathematics is not
restricted to the analytical and numerical; intuition plays a significant role. The
alleged gap can be narrowed or completely overcome by anyone, in part because
each of us is far from using the full capacity of either side of the brain. To illustrate
our human potential, I cite a structural engineer who is an artist, an electrical
engineer who is an opera singer, an opera singer who published mathematical
research, and a mathematician who publishes short stories.
D Other scientists have written books to explain their fields to non-scientists, but have
necessarily had to omit the mathematics, although it provides the foundation of their
theories. The reader must remain a tantalized spectator rather than an involved
participant, since the appropriate language for describing the details in much of
science is mathematics, whether the subject is expanding universe, subatomic
particles, or chromosomes. Though the broad outline of a scientific theory can be
73
```

[Original question page](assets/ac612b54509ad16952d9ba880a050da8bbed3afb90c5e9ddc6fe2ae43d13f019.jpg)

<!-- Source: /api/assets/af39feb3d0273901c1191a2ce4c759074181cb93afcb4d5be34bd542994d9ce8.jpg; PDF page 73; full -->

```text
sketched intuitively, when a part of the physical universe is finally understood, its
description often looks like a page in a mathematics text.
E Still, the non-mathematical reader can go far in understanding mathematical
reasoning. This book presents the details that illustrate the mathematical style
of thinking, which involves sustained, step-by-step analysis, experiments, and
insights. You will turn these pages much more slowly than when reading a novel
or a newspaper. It may help to have a pencil and paper ready to check claims and
carry out experiments.
F As I wrote, I kept in mind two types of readers: those who enjoyed mathematics
until they were turned off by an unpleasant episode, usually around fifth grade, and
mathematics aficionados, who will find much that is new throughout the book.
This book also serves readers who simply want to sharpen their analytical skills.
Many careers, such as law and medicine, require extended, precise analysis. Each
chapter offers practice in following a sustained and closely argued line of thought.
That mathematics can develop this skill is shown by these two testimonials:
G A physician wrote, ‘The discipline of analytical thought processes [in mathematics]
prepared me extremely well for medical school. In medicine one is faced with a
problem which must be thoroughly analyzed before a solution can be found. The
process is similar to doing mathematics.”
A lawyer made the same point, ‘Although I had no background in law — not even
one political science course — I did well at one of the best law schools. I attribute
much of my success there to having learned, through the study of mathematics,
and, in particular, theorems, how to analyze complicated principles. Lawyers who
have studied mathematics can master the legal principles in a way that most others
cannot.’
I hope you will share my delight in watching as simple, even naive, questions
lead to remarkable solutions and purely theoretical discoveries find unanticipated
applications.
```

[Original question page](assets/af39feb3d0273901c1191a2ce4c759074181cb93afcb4d5be34bd542994d9ce8.jpg)

<!-- Source: /api/assets/98e42724e1778164c6e58de48e4abf7999de19ec8073a7c3faf3eb08a06003bd.jpg; PDF page 74; full -->

```text
Questions 27-34
Reading Passage 3 has seven sections, A-G.
Which section contains the following information?
Write the correct letter, A-G, in boxes 27-34 on your answer sheet.
NB You may use any letter more than once.
27 a reference to books that assume a lack of mathematical knowledge
28 the way in which this is not a typical book about mathematics
29 personal examples of being helped by mathematics
30 examples of people who each had abilities that seemed incompatible
31 mention of different focuses of books about mathematics
32 a contrast between reading this book and reading other kinds of publication
33 a claim that the whole of the book is accessible to everybody
34 a reference to different categories of intended readers of this book
75
```

[Original question page](assets/98e42724e1778164c6e58de48e4abf7999de19ec8073a7c3faf3eb08a06003bd.jpg)

<!-- Source: /api/assets/28f87d3ec518f91a201743e06496940ba2fafb8cf86d77a9049d2a960329b91e.jpg; PDF page 75; full -->

```text
Questions 35-40
Complete the sentences below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 35–40 on your answer sheet.
35 Some areas of both music and mathematics are suitable for someone who is
a ...... .
36 It is sometimes possible to understand advanced mathematics using no more than
a limited knowledge of ...
37 The writer intends to show that mathematics requires ............. ....... thinking, as well as
analytical skills.
38 Some books written by………............ have had to leave out the mathematics that is
central to their theories.
39 The writer advises non-mathematical readers to perform .........…..... while reading
the book.
40 A lawyer found that studying ................ ... helped even more than other areas of
mathematics in the study of law.
76
```

[Original question page](assets/28f87d3ec518f91a201743e06496940ba2fafb8cf86d77a9049d2a960329b91e.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/633dd88d3a5aea7b1abc8855979413a2f6f496a6a9629a5cb45cdd22bd9d8bce.jpg; PDF page 76; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below shows average carbon dioxide (CO₂) emissions per person in the United Kingdom, Sweden, Italy and Portugal between 1967 and 2007.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/633dd88d3a5aea7b1abc8855979413a2f6f496a6a9629a5cb45cdd22bd9d8bce.jpg)

![Original figure](assets/633dd88d3a5aea7b1abc8855979413a2f6f496a6a9629a5cb45cdd22bd9d8bce.jpg)

### Task 2

<!-- Source: /api/assets/1283ba40492305bf1692adb682a30bdacca47730fee16af7f25c74c5ae06e285.jpg; PDF page 77; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people say that the only reason for learning a foreign language is in order to travel to or work in a foreign country. Others say that these are not the only reasons why someone should learn a foreign language.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/1283ba40492305bf1692adb682a30bdacca47730fee16af7f25c74c5ae06e285.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/6b69422492c18b71caf742a40e277c7ef430aa9e49cfe627ff7da6ce03129a03.jpg; PDF page 78; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Photographs
• What type of photos do you like taking? [Why/Why not?]
• What do you do with photos you take? [Why/Why not?]
• When you visit other places, do you take photos or buy postcards? [Why/Why not?]
• Do you like people taking photos of you? [Why/Why not?]
PART 2
Describe a day when you thought the
weather was perfect.
You should say:
where you were on this day
what the weather was like on this day
what you did during the day
and explain why you thought the weather
was perfect on this day.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Types of weather
Example questions:
What types of weather do people in your country dislike most? Why is that?
What jobs can be affected by different weather conditions? Why?
Are there any important festivals in your country that celebrate a season or type of
weather?
Weather forecasts
Example questions:
How important do you think it is for everyone to check what the next day’s weather
will be? Why?
What is the best way to get accurate information about the weather?
How easy or difficult is it to predict the weather in your country? Why is that?
79
```

[Original question page](assets/6b69422492c18b71caf742a40e277c7ef430aa9e49cfe627ff7da6ce03129a03.jpg)

### Part 2

<!-- Source: /api/assets/6b69422492c18b71caf742a40e277c7ef430aa9e49cfe627ff7da6ce03129a03.jpg; PDF page 78; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Photographs
• What type of photos do you like taking? [Why/Why not?]
• What do you do with photos you take? [Why/Why not?]
• When you visit other places, do you take photos or buy postcards? [Why/Why not?]
• Do you like people taking photos of you? [Why/Why not?]
PART 2
Describe a day when you thought the
weather was perfect.
You should say:
where you were on this day
what the weather was like on this day
what you did during the day
and explain why you thought the weather
was perfect on this day.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Types of weather
Example questions:
What types of weather do people in your country dislike most? Why is that?
What jobs can be affected by different weather conditions? Why?
Are there any important festivals in your country that celebrate a season or type of
weather?
Weather forecasts
Example questions:
How important do you think it is for everyone to check what the next day’s weather
will be? Why?
What is the best way to get accurate information about the weather?
How easy or difficult is it to predict the weather in your country? Why is that?
79
```

[Original question page](assets/6b69422492c18b71caf742a40e277c7ef430aa9e49cfe627ff7da6ce03129a03.jpg)

### Part 3

<!-- Source: /api/assets/6b69422492c18b71caf742a40e277c7ef430aa9e49cfe627ff7da6ce03129a03.jpg; PDF page 78; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Photographs
• What type of photos do you like taking? [Why/Why not?]
• What do you do with photos you take? [Why/Why not?]
• When you visit other places, do you take photos or buy postcards? [Why/Why not?]
• Do you like people taking photos of you? [Why/Why not?]
PART 2
Describe a day when you thought the
weather was perfect.
You should say:
where you were on this day
what the weather was like on this day
what you did during the day
and explain why you thought the weather
was perfect on this day.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Types of weather
Example questions:
What types of weather do people in your country dislike most? Why is that?
What jobs can be affected by different weather conditions? Why?
Are there any important festivals in your country that celebrate a season or type of
weather?
Weather forecasts
Example questions:
How important do you think it is for everyone to check what the next day’s weather
will be? Why?
What is the best way to get accurate information about the weather?
How easy or difficult is it to predict the weather in your country? Why is that?
79
```

[Original question page](assets/6b69422492c18b71caf742a40e277c7ef430aa9e49cfe627ff7da6ce03129a03.jpg)
