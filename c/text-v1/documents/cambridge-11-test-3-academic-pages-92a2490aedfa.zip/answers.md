# 剑雅 11 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 127

TEST 3 LISTENING
1 B
2 C
3 B
4 A
5 C
6 A
7 birds
8 flowers
9 mushrooms
10 river
11 C
12 B
13 B
14 A
15 C
16 G
17 A
18 C
19 B
20 F
21 cave
22 tiger
23 dancing
24 crying
25 grass
26 scarf
27 A
28 C
29 D
30 B
31 attitude/attitudes
32 numbers
33 time/minutes
34 software
35 patients
36 emotions/feelings
37 income
38 comfortable
39 observation
40 analysis
If you score: 0–14: unlikely; 15–30: may; 31–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. B

2. C

3. B

4. A

5. C

6. A

7. birds

8. flowers

9. mushrooms

10. river

### Part 2 · source page 127

TEST 3 LISTENING
1 B
2 C
3 B
4 A
5 C
6 A
7 birds
8 flowers
9 mushrooms
10 river
11 C
12 B
13 B
14 A
15 C
16 G
17 A
18 C
19 B
20 F
21 cave
22 tiger
23 dancing
24 crying
25 grass
26 scarf
27 A
28 C
29 D
30 B
31 attitude/attitudes
32 numbers
33 time/minutes
34 software
35 patients
36 emotions/feelings
37 income
38 comfortable
39 observation
40 analysis
If you score: 0–14: unlikely; 15–30: may; 31–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. C

12. B

13. B

14. A

15. C

16. G

17. A

18. C

19. B

20. F

### Part 3 · source page 127

TEST 3 LISTENING
1 B
2 C
3 B
4 A
5 C
6 A
7 birds
8 flowers
9 mushrooms
10 river
11 C
12 B
13 B
14 A
15 C
16 G
17 A
18 C
19 B
20 F
21 cave
22 tiger
23 dancing
24 crying
25 grass
26 scarf
27 A
28 C
29 D
30 B
31 attitude/attitudes
32 numbers
33 time/minutes
34 software
35 patients
36 emotions/feelings
37 income
38 comfortable
39 observation
40 analysis
If you score: 0–14: unlikely; 15–30: may; 31–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. cave

22. tiger

23. dancing

24. crying

25. grass

26. scarf

27. A

28. C

29. D

30. B

### Part 4 · source page 127

TEST 3 LISTENING
1 B
2 C
3 B
4 A
5 C
6 A
7 birds
8 flowers
9 mushrooms
10 river
11 C
12 B
13 B
14 A
15 C
16 G
17 A
18 C
19 B
20 F
21 cave
22 tiger
23 dancing
24 crying
25 grass
26 scarf
27 A
28 C
29 D
30 B
31 attitude/attitudes
32 numbers
33 time/minutes
34 software
35 patients
36 emotions/feelings
37 income
38 comfortable
39 observation
40 analysis
If you score: 0–14: unlikely; 15–30: may; 31–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. attitude / attitudes

32. numbers

33. time / minutes

34. software

35. patients

36. emotions / feelings

37. income

38. comfortable

39. observation

40. analysis

## A 类阅读

### Academic Reading · source page 128

TEST 3 READING
1 tea
2 reel
3 women
4 royalty
5 currency
6 paper
7 wool
8 monks
9 nylon
10 FALSE
11 TRUE
12 FALSE
13 NOT GIVEN
14 FALSE
15 TRUE
16 NOT GIVEN
17 TRUE
18 FALSE
19 G
20 C
21 A
22 E
23 speed
24 plains
25 bottlenecks
26 corridor/passageway
27 D
28 B
29 G
30 C
31 B
32 E
33 A
34 F
35 beginner
36 arithmetic
37 intuitive
38 scientists
39 experiments
40 theorems
If you score: 0–12: unlikely; 13–25: may; 26–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. tea

2. reel

3. women

4. royalty

5. currency

6. paper

7. wool

8. monks

9. nylon

10. FALSE

11. TRUE

12. FALSE

13. NOT GIVEN

14. FALSE

15. TRUE

16. NOT GIVEN

17. TRUE

18. FALSE

19. G

20. C

21. A

22. E

23. speed

24. plains

25. bottlenecks

26. corridor / passageway

27. D

28. B

29. G

30. C

31. B

32. E

33. A

34. F

35. beginner

36. arithmetic

37. intuitive

38. scientists

39. experiments

40. theorems

## A 类写作

### Writing material: c11-t3-w-1

1967,1977,1987,1997,2007; average CO2 emissions per person in METRIC TONNES. Approximate series: UK10.8,10.7,10.0,9.5,8.7; Sweden8.7,10.2,7.0,6.0,5.5; Italy4.2,6.3,6.7,7.7,7.7; Portugal1.1,2.0,3.0,5.2,5.4. UK highest throughout but declines; Sweden peaks1977 then drops, converging with Portugal by2007. Italy and Portugal rise, Italy overtaking Sweden aroundlate1980s. Unlabelled values are approximate. These are per-person averages, not country totals; not kilograms or percentages.



### Writing material: c11-t3-w-2

Discuss travel/work abroad as the only justification versus additional reasons for learning languages; state an opinion. The restrictive ONLY is central, rather than a generic comparison of travel and work.



## 口语
