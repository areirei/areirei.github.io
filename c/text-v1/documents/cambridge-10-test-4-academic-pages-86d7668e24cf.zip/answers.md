# 剑雅 10 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 150

TEST 4 LISTENING
1 Pargetter
2 East
3 library
4 morning/mornings
5 postbox
6 prices
7 glass
8 cooker
9 week
10 fence
11 B
12 B
13 A
14 A
15 C
16 trains
17 dark
18 games
19 guided tour
20 ladder/ladders
21 A
22 E
23 B
24 C
25 D
26 F
27 G
28 B
29 E
30 C
31 C
32 B
33 C
34 metal/metals
35 space
36 memory
37 solar
38 oil
39 waste
40 tests
21 & 22 IN EITHER ORDER: A,E
23 & 24 IN EITHER ORDER: B,C
If you score: 0–11: unlikely to get an acceptable score; improve English before IELTS. 12–27: may get an acceptable score; consider practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

1. Pargetter

2. East

3. library

4. morning / mornings

5. postbox

6. prices

7. glass

8. cooker

9. week

10. fence

### Part 2 · source page 150

TEST 4 LISTENING
1 Pargetter
2 East
3 library
4 morning/mornings
5 postbox
6 prices
7 glass
8 cooker
9 week
10 fence
11 B
12 B
13 A
14 A
15 C
16 trains
17 dark
18 games
19 guided tour
20 ladder/ladders
21 A
22 E
23 B
24 C
25 D
26 F
27 G
28 B
29 E
30 C
31 C
32 B
33 C
34 metal/metals
35 space
36 memory
37 solar
38 oil
39 waste
40 tests
21 & 22 IN EITHER ORDER: A,E
23 & 24 IN EITHER ORDER: B,C
If you score: 0–11: unlikely to get an acceptable score; improve English before IELTS. 12–27: may get an acceptable score; consider practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

11. B

12. B

13. A

14. A

15. C

16. trains

17. dark

18. games

19. guided tour

20. ladder / ladders

### Part 3 · source page 150

TEST 4 LISTENING
1 Pargetter
2 East
3 library
4 morning/mornings
5 postbox
6 prices
7 glass
8 cooker
9 week
10 fence
11 B
12 B
13 A
14 A
15 C
16 trains
17 dark
18 games
19 guided tour
20 ladder/ladders
21 A
22 E
23 B
24 C
25 D
26 F
27 G
28 B
29 E
30 C
31 C
32 B
33 C
34 metal/metals
35 space
36 memory
37 solar
38 oil
39 waste
40 tests
21 & 22 IN EITHER ORDER: A,E
23 & 24 IN EITHER ORDER: B,C
If you score: 0–11: unlikely to get an acceptable score; improve English before IELTS. 12–27: may get an acceptable score; consider practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

21. A / E

22. A / E

23. B / C

24. B / C

25. D

26. F

27. G

28. B

29. E

30. C

### Part 4 · source page 150

TEST 4 LISTENING
1 Pargetter
2 East
3 library
4 morning/mornings
5 postbox
6 prices
7 glass
8 cooker
9 week
10 fence
11 B
12 B
13 A
14 A
15 C
16 trains
17 dark
18 games
19 guided tour
20 ladder/ladders
21 A
22 E
23 B
24 C
25 D
26 F
27 G
28 B
29 E
30 C
31 C
32 B
33 C
34 metal/metals
35 space
36 memory
37 solar
38 oil
39 waste
40 tests
21 & 22 IN EITHER ORDER: A,E
23 & 24 IN EITHER ORDER: B,C
If you score: 0–11: unlikely to get an acceptable score; improve English before IELTS. 12–27: may get an acceptable score; consider practice or lessons. 28–40: likely to get an acceptable score; institutions accept different scores.

31. C

32. B

33. C

34. metal / metals

35. space

36. memory

37. solar

38. oil

39. waste

40. tests

## A 类阅读

### Academic Reading · source page 151

TEST 4 ACADEMIC READING
1 spread
2 10/ten times
3 below
4 fuel
5 seasons
6 homes/housing
7 TRUE
8 FALSE
9 TRUE
10 TRUE
11 NOT GIVEN
12 FALSE
13 FALSE
14 transformation/change
15 young age
16 optimism
17 skills/techniques
18 negative emotions / feelings
19 E
20 C
21 G
22 A
23 E
24 C
25 G
26 H
27 C
28 D
29 C
30 B
31 A
32 F
33 G
34 A
35 B
36 D
37 NOT GIVEN
38 YES
39 NO
40 YES
If you score: 0–11: unlikely to get an acceptable score; improve English before IELTS. 12–28: may get an acceptable score; consider practice or lessons. 29–40: likely to get an acceptable score; institutions accept different scores.

1. spread

2. 10 times / ten times

3. below

4. fuel

5. seasons

6. homes / housing

7. TRUE

8. FALSE

9. TRUE

10. TRUE

11. NOT GIVEN

12. FALSE

13. FALSE

14. transformation / change

15. young age

16. optimism

17. skills / techniques

18. negative emotions / feelings

19. E

20. C

21. G

22. A

23. E

24. C

25. G

26. H

27. C

28. D

29. C

30. B

31. A

32. F

33. G

34. A

35. B

36. D

37. NOT GIVEN

38. YES

39. NO

40. YES

## A 类写作

### Writing material: c10-t4-w-1

Cyclic salmon life stages and migration. Eggs laid among reeds and small stones in slow-moving upper river, approximately5–6months. Fry3–8cm migrate to fast-flowing lower river for approximately4years and grow into smolt12–15cm. Smolt move into open sea for approximately5years, becoming adult salmon70–76cm. Adults return upstream to reproduce and cycle repeats. Lengths are centimetres, durations are approximate. Do not say eggs stay four years, sea stage lasts four years, or adults breed at sea. No exact total lifespan, temperature, diet or mortality data supplied.



### Writing material: c10-t4-w-2

Weigh advantages and disadvantages of charging museum admission and state which outweighs the other. Preserve the focus on fees, not only the general value of museums.



## 口语
