# 剑雅 10 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/ce2af4d0442c2c9eb3f1fa584ae8a3402429f5a9a48e463e786b6c201fbb9cdb.jpg; PDF page 73; full -->

```text
LISTENING
SECTION 1 Questions 1–10
Questions 1–6
Complete the notes below. Write ONE WORD ONLY for each answer.
THORNDYKE’S BUILDERS
Example — Customer heard about Thorndyke’s from a friend
Name: Edith (1) __________
Address: Flat 4, (2) __________ Park Flats
(Behind the (3) __________)
Phone number: 875934
Best time to contact customer: during the (4) __________
Where to park: opposite entrance next to the (5) __________
Needs full quote showing all the jobs and the (6) __________
```

[Original question page](assets/ce2af4d0442c2c9eb3f1fa584ae8a3402429f5a9a48e463e786b6c201fbb9cdb.jpg)

<!-- Source: /api/assets/1c47d64dba26cf12d8c4df1f7c407ef1829bd1f9d8ceec022a97b0ca018c2dd2.jpg; PDF page 74; full -->

```text
Questions 7–10
Complete the table below. Write ONE WORD ONLY for each answer.
| Area | Work to be done | Notes |
| --- | --- | --- |
| Kitchen | Replace the (7) __________ in the door | Fix tomorrow |
| Kitchen | Paint wall above the (8) __________ | Strip paint and plaster approximately one (9) __________ in advance |
| Garden | One (10) __________ needs replacing (end of garden) | |
```

[Original question page](assets/1c47d64dba26cf12d8c4df1f7c407ef1829bd1f9d8ceec022a97b0ca018c2dd2.jpg)

### Part 2

<!-- Source: /api/assets/4fb38cd0f9d42bd9144d41d9881571bdf09ca67cfda4d7c265850cf51edbd866.jpg; PDF page 75; full -->

```text
SECTION 2 Questions 11–20
Test 4
Questions 11-15
Choose the correct letter, A, B or C.
MANHAM PORT
11 Why did a port originally develop at Manham?
A It was safe from enemy attack.
B It was convenient for river transport.
C It had a good position on the sea coast.
12 What caused Manham’s sudden expansion during the Industrial Revolution?
A the improvement in mining techniques
B the increase in demand for metals
C the discovery of tin in the area
13 Why did rocks have to be sent away from Manham to be processed?
A shortage of fuel
B poor transport systems
C lack of skills among local people
14 What happened when the port declined in the twentieth century?
A The workers went away.
B Traditional skills were lost.
C Buildings were used for new purposes.
15 What did the Manham Trust hope to do?
A discover the location of the original port
B provide jobs for the unemployed
C rebuild the port complex

82
```

[Original question page](assets/4fb38cd0f9d42bd9144d41d9881571bdf09ca67cfda4d7c265850cf51edbd866.jpg)

<!-- Source: /api/assets/0464e81bb6ac781758de2f30a7f443f26ccbb40cdfb6ba692d0a596b7c478368.jpg; PDF page 76; full -->

```text
Questions 16–20
Complete the table below. Write NO MORE THAN TWO WORDS for each answer.
Tourist attractions in Manham
| Place | Features and activities | Advice |
| --- | --- | --- |
| copper mine | specially adapted miners’ (16) __________ take visitors into the mountain | the mine is (17) __________ and enclosed — unsuitable for children and animals |
| village school | classrooms and a special exhibition of (18) __________ | a (19) __________ is recommended |
| ‘The George’ (old sailing ship) | the ship’s wheel (was lost but has now been restored) | children shouldn’t use the (20) __________ |
```

[Original question page](assets/0464e81bb6ac781758de2f30a7f443f26ccbb40cdfb6ba692d0a596b7c478368.jpg)

### Part 3

<!-- Source: /api/assets/0ebb712ca66ec995aaeb3f560b3a23d76ebfd972b75683fa56d6e3492271bee2.jpg; PDF page 77; full -->

```text
SECTION 3 Questions 21–30
Test 4
Questions 21 and 22
Choose TWO letters, A-E.
Which TWO skills did Laura improve as a result of her work placement?
A communication
B design
C IT
D marketing
E organisation
Questions 23 and 24
Choose TWO letters, A-E.
Which TWO immediate benefits did the company get from Laura’s work placement?

A updates for its software
B cost savings
C an improved image
D new clients
E a growth in sales
84
```

[Original question page](assets/0ebb712ca66ec995aaeb3f560b3a23d76ebfd972b75683fa56d6e3492271bee2.jpg)

<!-- Source: /api/assets/a7869e0a414b59e6b0795a504d1d2a95de56aaf8a003b528cb131c0f6b138d50.jpg; PDF page 78; full -->

```text
Questions 25–30
What source of information should Tim use at each of the following stages of the work placement?
Choose SIX answers from the box and write the correct letter, A–G, next to questions 25–30.
Sources of information
A company manager
B company’s personnel department
C personal tutor
D psychology department
E mentor
F university careers officer
G internet
Stages of the work placement procedure
25 obtaining booklet __________
26 discussing options __________
27 getting updates __________
28 responding to invitation for interview __________
29 informing about outcome of interview __________
30 requesting a reference __________
```

[Original question page](assets/a7869e0a414b59e6b0795a504d1d2a95de56aaf8a003b528cb131c0f6b138d50.jpg)

### Part 4

<!-- Source: /api/assets/b0f029351c6b332c5bb29724e706c3973c307883990fee5465d2e3b0420b6451.jpg; PDF page 79; full -->

```text
SECTION 4 Questions 31–40
Questions 31–33
Choose the correct letter, A, B or C.
Nanotechnology: technology on a small scale
31 The speaker says that one problem with nanotechnology is that
A it could threaten our way of life.
B it could be used to spy on people.
C it is misunderstood by the public.
32 According to the speaker, some scientists believe that nano-particles
A should be restricted to secure environments.
B should be used with more caution.
C should only be developed for essential products.
33 In the speaker’s opinion, research into nanotechnology
A has yet to win popular support.
B could be seen as unethical.
C ought to be continued.
```

[Original question page](assets/b0f029351c6b332c5bb29724e706c3973c307883990fee5465d2e3b0420b6451.jpg)

<!-- Source: /api/assets/5eedb0587c25f311321916efa17915017c77c9ca891b2dca0dd9bb03dd34921c.jpg; PDF page 80; full -->

```text
Questions 34-40
Complete the notes below.
Listening
Write ONE WORD ONLY for each answer.
Uses of Nanotechnology
Transport
• Nanotechnology could allow the development of stronger 34
................
• Planes would be much lighter in weight.
• 35
...............................travel will be made available to the masses.
Technology
• Computers will be even smaller, faster, and will have a greater
36
................................
• 37 ...............................energy will become more affordable.
The Environment
• Nano-robots could rebuild the ozone layer.
• Pollutants such as 38
.................................
could be removed from water
more easily.
• There will be no 39
..............................
from manufacturing.
Health and Medicine
• New methods of food production could eradicate famine.
• Analysis of medical 40
.................................................
will be speeded up.
• Life expectancy could be increased.

87
```

[Original question page](assets/5eedb0587c25f311321916efa17915017c77c9ca891b2dca0dd9bb03dd34921c.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/31d046d8b0460865fce986d3f35907c7d9734d7d508e0709d0f03d3ffd2e9083.jpg; PDF page 81; full -->

```text
Test 4
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13
’
which are based on
Reading Passage 1  below.
The megafires of California
Drought, housing expansion, and oversupply of tinder make for
bigger, hotter fires in the western United States
Wildfires are becoming an increasing
menace in the western United States,
with Southern California being the
hardest hit area. There’s a reason fire
squads battling more frequent blazes
in Southern California are having such
difficulty containing the flames, despite
better preparedness than ever and
decades of experience fighting fires
fanned by the 'Santa Ana Winds’. The
wildfires themselves, experts say, are
generally hotter, faster, and spread more
erratically than in the past.
Megafires, also called ‘siege fires
’’
are the increasingly frequent blazes that
burn 500,000 acres or more - 10 times
the size of the average forest fire of 20
years ago. Some recent wildfires are
among the biggest ever in California in
terms of acreage burned, according to
state figures and news reports.
One explanation for the trend to
more superhot fires is that the region,
which usually has dry summers, has had
significantly below normal precipitation
in many recent years. Another reason,
experts say, is related to the century-
long policy of the US Forest Service to
stop wildfires as quickly as possible.
The unintentional consequence has
been to halt the natural eradication of
underbrush, now the primary fuel for
megafires.
Three other factors contribute to the
trend, they add. First is climate change,
marked by a 1-degree Fahrenheit rise in
average yearly temperature across the
western states. Second is fire seasons
that on average are 78 days longer
than they were 20 years ago. Third
is increased construction of homes in
wooded areas.
‘We are increasingly building our
homes in fire-prone ecosystems,’  says
Dominik Kulakowski, adjunct professor
of biology at Clark University Graduate
School of Geography in Worcester,
Massachusetts. ‘Doing that in many
of the forests of the western US is like
building homes on the side of an active
volcano.’
In California, where population
growth has averaged more than 600,000
a year for at least a decade, more
residential housing is being built. ‘What
once was open space is now residential
homes providing fuel to make fires
burn with greater intensity,’  says Terry
McHale of the California Department
of Forestry firefighters’ union. ‘With so
88
```

[Original question page](assets/31d046d8b0460865fce986d3f35907c7d9734d7d508e0709d0f03d3ffd2e9083.jpg)

<!-- Source: /api/assets/5b40d291172e5c83673be46139c47150a31bcb71be2a25e110c968f8e1e27175.jpg; PDF page 82; full -->

```text
Reading
much dryness, so many communities
to catch fire, so many fronts to fight, it
becomes an almost incredible job.’
That said, many experts give
California high marks for making
progress on preparedness in recent
years, after some of the largest fires
in state history scorched thousands
of acres, burned thousands of homes,
and killed numerous people. Stung in
the past by criticism of bungling that
allowed fires to spread when they
might have been contained, personnel
are meeting the peculiar challenges of
neighborhood - and canyon- hopping
fires better than previously, observers
say.
State promises to provide more
up-to-date engines, planes, and
helicopters to fight fires have been
fulfilled. Firefighters’ unions that in
the past complained of dilapidated
equipment, old fire engines, and
insufficient blueprints for fire safety are
now praising the state's commitment,
noting that funding for firefighting has
increased, despite huge cuts in many
other programs. ‘We are pleased that
the current state administration has
been very proactive in its support of us,
and [has] come through with budgetary
support of the infrastructure needs we
have long sought,’  says Mr. McHale of
the firefighters’ union.
Besides providing money to upgrade
the fire engines that must traverse
the mammoth state and wind along
serpentine canyon roads, the state has
invested in better command-and-control
facilities as well as in the strategies
to run them. ‘In the fire sieges of
earlier years, we found that other
jurisdictions and states were willing
to offer mutual- aid help, but we were
not able to communicate adequately
with them,’ says Kim Zagaris, chief
of the state’s Office of Emergency
Services Fire and Rescue Branch.
After a commission examined and
revamped communications procedures,
the statewide response ‘has become
far more professional and responsive,’
he says. There is a sense among both
government officials and residents that
the speed, dedication, and coordination
of firefighters from several states and
jurisdictions are resulting in greater
efficiency than in past ‘siege fire’
situations.
In recent years, the Southern
California region has improved building
codes, evacuation procedures, and
procurement of new technology. ‘I
am extraordinarily impressed by the
improvements we have witnessed,’ says
Randy Jacobs, a Southern California-
based lawyer who has had to evacuate
both his home and business to escape
wildfires. ‘Notwithstanding all the
damage that will continue to be caused
by wildfires, we will no longer suffer the
loss of life endured in the past because
of the fire prevention and firefighting
measures that have been put in place,’
he says.
89
```

[Original question page](assets/5b40d291172e5c83673be46139c47150a31bcb71be2a25e110c968f8e1e27175.jpg)

<!-- Source: /api/assets/6b213a55924dc2554c370cf0ba5275552adcd8a04a1e9470c76c81e3a96aba1c.jpg; PDF page 83; full -->

```text
Questions 1–6
Complete the notes below.
Choose ONE WORD AND/OR A NUMBER from the passage for each answer.
Write your answers in boxes 1–6 on your answer sheet.
Wildfires
Characteristics of wildfires and wildfire conditions today compared to the past:
– occurrence: more frequent
– temperature: hotter
– speed: faster
– movement: (1) __________ more unpredictably
– size of fires: (2) __________ greater on average than two decades ago
Reasons wildfires cause more damage today compared to the past:
– rainfall: (3) __________ average
– more brush to act as (4) __________
– increase in yearly temperature
– extended fire (5) __________
– more building of (6) __________ in vulnerable places
```

[Original question page](assets/6b213a55924dc2554c370cf0ba5275552adcd8a04a1e9470c76c81e3a96aba1c.jpg)

<!-- Source: /api/assets/fcbe783a322c1ac462052d59ce5ee4ea951e2a47d85c17e6f88d2d48bac8ab4b.jpg; PDF page 84; full -->

```text
Questions 7— 13
Do the following statements agree with the information given in Reading Passage 1?
Reading
In boxes 7- 13 on your answer sheet， write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
7 The amount of open space in California has diminished over the last ten years.
8 Many experts believe California has made little progress in readying itself to
fight fires.
9 Personnel in the past have been criticised for mishandling fire containment.
10 California has replaced a range of firefighting tools.
11 More firefighters have been hired to improve fire-fighting capacity.
12 Citizens and government groups disapprove of the efforts of different states and
agencies working together.
13 Randy Jacobs believes that loss of life from fires will continue at the same levels,
despite changes made.

91
```

[Original question page](assets/fcbe783a322c1ac462052d59ce5ee4ea951e2a47d85c17e6f88d2d48bac8ab4b.jpg)

<!-- Source: /api/assets/18971d91172ee0d66e5753cb9c6d6c4b449a7ad3540895e1903f03e837a62aad.jpg; PDF page 85; full -->

```text
Test 4
READING PASSAGE 2
You should spend about 20 minutes on Q uestions 14–26, which are based on Reading
Passage 2 below.
Second nature
Your personality isn’t necessarily set in stone. With a little experimentation,
people can reshape their temperaments and inject passion, optimism, joy and
courage into their lives
A Psychologists have long held that a person's character cannot undergo a
transformation in any meaningful way and that the key traits of personality are
determined at a very young age. However, researchers have begun looking more
closely at ways we can change. Positive psychologists have identified 24 qualities
we admire, such as loyalty and kindness, and are studying them to find out why
they come so naturally to some people. What they're discovering is that many of
these qualities amount to habitual behaviour that determines the way we respond
to the world. The good news is that all this can be learned.
Some qualities are less challenging to develop than others, optimism being one of
them. However, developing qualities requires mastering a range of skills which are
diverse and sometimes surprising. For example, to bring more joy and passion into
your life, you must be open to experiencing negative emotions. Cultivating such
qualities will help you realise your full potential.
B 'The
evidence
is good that most
personality
traits can be
altered,’
says Christopher
Peterson, professor of psychology at the University of Michigan, who cites himself
as an example. Inherently introverted, he realised early on that as an academic,
his reticence would prove disastrous in the lecture hall. So he learned to be
more outgoing and to entertain his classes. 'Now my extroverted behaviour is
spontaneous,’ he says.
C David Fajgenbaum had to make a
similar
transition. He was preparing for
university, when he had an accident that put an end to his sports career. On
campus, he quickly found that beyond ordinary counselling, the university had no
services for students who were undergoing physical rehabilitation and suffering
from depression like him. He therefore launched a support group to help others in
similar situations. He took action despite his own pain
—
 a typical response of an
optimist.
D
Suzanne
Segerstrom,
professor
of
psychology
at the University of
Kentucky,
believes that the key to increasing optimism is through cultivating optimistic
behaviour, rather than positive thinking. She recommends you train yourself to pay
attention to good fortune by writing down three positive things that come about
each day. This will help you convince yourself that favourable outcomes actually
happen all the time, making it easier to begin taking action.
92
```

[Original question page](assets/18971d91172ee0d66e5753cb9c6d6c4b449a7ad3540895e1903f03e837a62aad.jpg)

<!-- Source: /api/assets/dd2cb9367cc9e31c7b644b570073e10348f3ac864c6ed90f5ca226ecbe567ea8.jpg; PDF page 86; full -->

```text
Reading
E You can
recognise
a person who is passionate about a pursuit by the way they
are so strongly involved in it. Tanya Streeter's passion is freediving
—
 the sport
of plunging deep into the water without tanks or other breathing equipment.
Beginning in 1998, she set nine world records and can hold her breath for
six minutes. The physical stamina required for this sport is intense but the
psychological demands are even more overwhelming. Streeter learned to untangle
her fears from her judgment of what her body and mind could do. 'In my career
as a competitive freediver, there was a limit to what I could do - but it wasn't
anywhere near what I thought it was,’ she says.
F
Finding
a
pursuit
that
excites
you can improve anyone's
life.
The
secret
about
consuming passions, though, according to psychologist Paul Silvia of the
University of North Carolina, is that 'they require discipline, hard work and ability,
which is why they are so rewarding.’ Psychologist Todd Kashdan has this advice
for those people taking up a new passion: 'As a newcomer, you also have to tolerate
and laugh at your own ignorance. You must be willing to accept the negative
feelings that come your way,’ he says.
G In
2004,
physician-scientist Mauro Zappaterra began
his
PhD
research
at Harvard
Medical School. Unfortunately, he was miserable as his research wasn't compatible
with his curiosity about healing. He finally took a break and during eight months
in Santa Fe, Zappaterra learned about alternative healing techniques not taught
at Harvard. When he got back, he switched labs to study how cerebrospinal fluid
nourishes the developing nervous system. He also vowed to look for the joy in
everything, including failure, as this could help him learn about his research and
himself.
One thing that can hold joy back is a person's concentration on avoiding failure
rather than their looking forward to doing something well. 'Focusing on being safe
might get in the way of your reaching your goals,’ explains Kashdan. For example,
are you hoping to get through a business lunch without embarrassing yourself, or
are you thinking about how fascinating the conversation might be?
H Usually, we think of courage in  physical terms but ordinary life demands
something else. For marketing executive Kenneth Pedeleose, it meant speaking
out against something he thought was ethically wrong. The new manager was
intimidating staff so Pedeleose carefully recorded each instance of bullying and
eventually took the evidence to a senior director, knowing his own job security
would be threatened. Eventually the manager was the one to go. According to
Cynthia Pury, a psychologist at Clemson University, Pedeleose's story proves the
point that courage is not motivated by fearlessness, but by moral obligation. Pury
also believes that people can acquire courage. Many of her students said that faced
with a risky situation, they first tried to calm themselves down, then looked for a
way to mitigate the danger, just as Pedeleose did by documenting his allegations.
Over the long term, picking up a new character trait may help you move toward
being the person you want to be. And in the short term, the effort itself could be
surprisingly rewarding, a kind of internal adventure.
93
```

[Original question page](assets/dd2cb9367cc9e31c7b644b570073e10348f3ac864c6ed90f5ca226ecbe567ea8.jpg)

<!-- Source: /api/assets/e7afe7ea117b5f4a07572606ea6b3c8694427cafe223d8e651171c690635a850.jpg; PDF page 87; full -->

```text
Questions 14~18
Complete the summary below.
Test 4
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 14-18 on your answer sheet.
Psychologists have traditionally believed that a personality 14
...............
was impossible
and that by a 15
.................
a person's character tends to be fixed. This is not true
according to positive psychologists, who say that our personal qualities can be seen
as habitual behaviour. One of the easiest qualities to acquire is 16
.................
However,
regardless of the quality, it is necessary to learn a wide variety of different 17
...............
in order for a new quality to develop; for example, a person must understand and feel
some 18
...............
in order to increase their happiness.

94
```

[Original question page](assets/e7afe7ea117b5f4a07572606ea6b3c8694427cafe223d8e651171c690635a850.jpg)

<!-- Source: /api/assets/13480990c3f0907a5254f36dfece96d2435c87d3a8ea4a6543d3efe2c9932349.jpg; PDF page 88; full -->

```text
Questions 19-22
Look at the following statements (Questions 19-22) and the list of people below.
Reading
Match each statement with the correct person, A-G.
Write the correct letter, A-G, in boxes 19-22 on your answer sheet.
19 People must accept that they do not know much when first trying something new.
20 It is important for people to actively notice when good things happen.
21 Courage can be learned once its origins in a sense of responsibility are understood.
22 It is possible to overcome shyness when faced with the need to speak in public.

List of People
A Christopher Peterson
B David Fajgenbaum
C Suzanne Segerstrom
D Tanya Streeter
E Todd Kashdan
F Kenneth Pedeleose
G Cynthia Pury
95
```

[Original question page](assets/13480990c3f0907a5254f36dfece96d2435c87d3a8ea4a6543d3efe2c9932349.jpg)

<!-- Source: /api/assets/1bfac37ff2f398d6eb180fe819aaa7b15eb80106dbf56d9a3650fd8cc6a7ff25.jpg; PDF page 89; full -->

```text
Questions 23-26
Reading Passage 2 has eight sections, A-H.
Test 4
Which section contains the following information?
Write the correct letter, A-H, in boxes 23-26 on your answer sheet.
23 a mention of how rational thinking enabled someone to achieve physical goals
24 an account of how someone overcame a sad experience
25 a description of how someone decided to rethink their academic career path
26 an example of how someone risked his career out of a sense of duty

96
```

[Original question page](assets/1bfac37ff2f398d6eb180fe819aaa7b15eb80106dbf56d9a3650fd8cc6a7ff25.jpg)

<!-- Source: /api/assets/898bf14ca0075493570e2b911cd58971249b5866c3bb99b5d4cb26a716305656.jpg; PDF page 90; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Q uestions 27-40, which are based on Reading
Passage 3 below.
When evolution runs backwards
Evolution isn’t supposed to run backwards -  yet an increasing number
of examples show that it does and that it can sometimes represent the
future of a species
The description of any animal as an
‘evolutionary throwback’ is controversial.
For the better part of a century, most
biologists have been reluctant to use those
words, mindful of a principle of evolution
that says ‘evolution cannot run backwards’.
But as more and more examples come to
light and modern genetics enters the scene,
that principle is having to be rewritten. Not
only are evolutionary throwbacks possible,
they sometimes play an important role in the
forward march of evolution.
The technical term for an evolutionary
throwback is an ‘atavism’, from the Latin
atavus, meaning forefather. The word has
ugly connotations thanks largely to Cesare
Lombroso, a 19th-century Italian medic who
argued that criminals were born not made
and could be identified by certain physical
features that were throwbacks to a primitive,
sub-human state.
While Lombroso was measuring
criminals, a Belgian palaeontologist called
Louis Dollo was studying fossil records
and coming to the opposite conclusion.
In 1890 he proposed that evolution was
irreversible: that ‘an organism is unable to
return, even partially, to a previous stage
already realised in the ranks of its ancestors’.
Early 20th-century biologists came to a
similar conclusion, though they qualified it
in terms of probability, stating that there is no
reason why evolution cannot run backwards
- it is just very unlikely. And so the idea of
irreversibility in evolution stuck and came to
be known as ‘Dollo’s law’.
If Dollo’s law is right, atavisms should
occur only very rarely, if at all. Yet almost
since the idea took root, exceptions have
been cropping up. In 1919, for example,
a humpback whale with a pair of leg-like
appendages over a metre long, complete
with a full set of limb bones, was caught
off Vancouver Island in Canada. Explorer
Roy Chapman Andrews argued at the time
that the whale must be a throwback to a
land-living ancestor. ‘I  can see no other
explanation,’ he wrote in 1921.
Since then, so many other examples
have been discovered that it no longer
makes sense to say that evolution is as good
as irreversible. And this poses a puzzle:
how can characteristics that disappeared
millions of years ago suddenly reappear?
In 1994, Rudolf Raff and colleagues at
Indiana University in the USA decided
to use genetics to put a number on the
probability of evolution going into reverse.
They reasoned that while some evolutionary
changes involve the loss of genes and are
therefore irreversible, others may be the
result of genes being switched off. If these
97
```

[Original question page](assets/898bf14ca0075493570e2b911cd58971249b5866c3bb99b5d4cb26a716305656.jpg)

<!-- Source: /api/assets/404ee88816cfd0eba57e45638e349957303487313feb08e627549007c590380d.jpg; PDF page 91; full -->

```text
Test 4
silent genes are somehow switched back
on, they argued, long-lost traits could
reappear.
Raff’s team went on to calculate the
likelihood of it happening. Silent genes
accumulate random mutations, they
reasoned, eventually rendering them useless.
So how long can a gene survive in a species
if it is no longer used? The team calculated
that there is a good chance of silent genes
surviving for up to 6 million years in at least
a few individuals in a population, and that
some might survive as long as 10 million
years. In other words, throwbacks are
possible, but only to the relatively recent
evolutionary past.
As a possible example, the team pointed
to the mole salamanders of Mexico and
California. Like most amphibians these
begin life in a juvenile ‘tadpole’ state, then
metamorphose into the adult form -  except
for one species, the axolotl, which famously
lives its entire life as a juvenile. The simplest
explanation for this is that the axolotl lineage
alone lost the ability to metamorphose, while
others retained it. From a detailed analysis
of the salamanders’ family tree, however,
it is clear that the other lineages evolved
from an ancestor that itself had lost the
ability to metamorphose. In other words,
metamorphosis in mole salamanders is an
atavism. The salamander example fits with
Raff’s 10-million-year time frame.
More recently, however, examples have
been reported that break the time limit,
suggesting that silent genes may not be the
whole story. In a paper published last year,
biologist Gunter Wagner of Yale University
reported some work on the evolutionary
history of a group of South American lizards
called Bachia. Many of these have minuscule
limbs; some look more like snakes than
lizards and a few have completely lost the
toes on their hind limbs. Other species,
however, sport up to four toes on their
hind legs. The simplest explanation is that
the toed lineages never lost their toes,
but Wagner begs to differ. According to
his analysis of the Bachia family tree, the
toed species re-evolved toes from toeless
ancestors and, what is more, digit loss
and gain has occurred on more than one
occasion over tens of millions of years.
So what’s going on? One possibility is
that these traits are lost and then simply
reappear, in much the same way that
similar structures can independently arise
in unrelated species, such as the dorsal
fins of sharks and killer whales. Another
more intriguing possibility is that the genetic
information needed to make toes somehow
survived for tens or perhaps hundreds of
millions of years in the lizards and was
reactivated. These atavistic traits provided
an advantage and spread through the
population, effectively reversing evolution.
But if silent genes degrade within 6 to
10 million years, how can long-lost traits
be reactivated over longer timescales? The
answer may lie in the womb. Early embryos
of many species develop ancestral features.
Snake embryos, for example, sprout hind
limb buds. Later in development these
features disappear thanks to developmental
programs that say ‘lose the leg’.  If for any
reason this does not happen, the ancestral
feature may not disappear, leading to an
atavism.
98
```

[Original question page](assets/404ee88816cfd0eba57e45638e349957303487313feb08e627549007c590380d.jpg)

<!-- Source: /api/assets/2764d9977931e10d122a096fcafbeb2eb1872311ca0432f39e09921e0467bea3.jpg; PDF page 92; full -->

```text
Questions 27–31
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27–31 on your answer sheet.
27 When discussing the theory developed by Louis Dollo, the writer says that
A it was immediately referred to as Dollo’s law.
B it supported the possibility of evolutionary throwbacks.
C it was modified by biologists in the early twentieth century.
D it was based on many years of research.
28 The humpback whale caught off Vancouver Island is mentioned because of
A the exceptional size of its body.
B the way it exemplifies Dollo’s law.
C the amount of local controversy it caused.
D the reason given for its unusual features.
29 What is said about ‘silent genes’?
A Their numbers vary according to species.
B Raff disagreed with the use of the term.
C They could lead to the re-emergence of certain characteristics.
D They can have an unlimited life span.
30 The writer mentions the mole salamander because
A it exemplifies what happens in the development of most amphibians.
B it suggests that Raff’s theory is correct.
C it has lost and regained more than one ability.
D its ancestors have become the subject of extensive research.
31 Which of the following does Wagner claim?
A Members of the Bachia lizard family have lost and regained certain features several times.
B Evidence shows that the evolution of the Bachia lizard is due to the environment.
C His research into South American lizards supports Raff’s assertions.
D His findings will apply to other species of South American lizards.
```

[Original question page](assets/2764d9977931e10d122a096fcafbeb2eb1872311ca0432f39e09921e0467bea3.jpg)

<!-- Source: /api/assets/a4d26a9ca73600e024ee9b2a0de0ece00140f9fc885864565cf944fe54d85b0e.jpg; PDF page 93; full -->

```text
Questions 32-36
Complete each sentence with the correct ending
Test 4
Write the correct letter, A–G, in boxes 32-36 on your answer sheet
32 For a long time biologists rejected
33 Opposing views on evolutionary throwbacks are represented by
34 Examples of evolutionary throwbacks have led to
35 The shark and killer whale are mentioned to exemplify
36 One explanation for the findings of Wagner’s research is
A the question of how certain long-lost traits could reappear.
B the occurrence of a particular feature in different species.
C parallels drawn between behaviour and appearance.
D the continued existence of certain genetic information.
E the doubts felt about evolutionary throwbacks.
F the possibility of evolution being reversible.
G Dollo’s findings and the convictions held by Lombroso.
Questions 37- 40
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 37-40 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
37 Wagner was the first person to do research on South American lizards.
38 Wagner believes that Bachia lizards with toes had toeless ancestors.
39 The temporary occurrence of long-lost traits in embryos is rare.
40 Evolutionary throwbacks might be caused by developmental problems in the womb.

,
A-G, below.
100
```

[Original question page](assets/a4d26a9ca73600e024ee9b2a0de0ece00140f9fc885864565cf944fe54d85b0e.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/64812f74d910ae85356bde0744b7828256eccf4d69f8f3710411f12e3cd358b2.jpg; PDF page 94; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagrams below show the life cycle of a species of large fish called the salmon.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/64812f74d910ae85356bde0744b7828256eccf4d69f8f3710411f12e3cd358b2.jpg)

![Original figure](assets/64812f74d910ae85356bde0744b7828256eccf4d69f8f3710411f12e3cd358b2.jpg)

### Task 2

<!-- Source: /api/assets/ea04623d94d084ef61424cea690c40580d355259c0f1f40970235219da8f01d2.jpg; PDF page 95; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Many museums charge for admission while others are free.

Do you think the advantages of charging people for admission to museums outweigh the disadvantages?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/ea04623d94d084ef61424cea690c40580d355259c0f1f40970235219da8f01d2.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/f9bb30d86ca57092628de4849b76a7872eb34375a2f501eee0f4c0c56b4888d9.jpg; PDF page 96; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
School
• Did you go to secondary/high school near to where you lived? [Why/Why not?]
• What did you like about your secondary/high school? [Why?]
• Tell me about anything you didn’t like at your school.
• How do you think your school could be improved? [Why/Why not?]
PART 2
Describe something you don’t have now but
would really like to own in the future.
You should say:
what this thing is
how long you have wanted to own it
where you first saw it
and explain why you would like to own it.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going
to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Owning things
Example questions:
What types of things do young people in your country most want to own today?
Why is this?
Why do some people feel they need to own things?
Do you think that owning lots of things makes people happy? Why?
Salaries for skilled people
Example questions:
Do you think television and films can make people want to get new possessions?
Why do they have this effect?
Are there any benefits to society of people wanting to get new possessions?
Why do you think this is?
Do you think people will consider that having lots of possessions is a sign of success
in the future? Why?


[Source note: the printed Part 3 subheading “Salaries for skilled people” is retained although its questions concern possessions.]
```

[Original question page](assets/f9bb30d86ca57092628de4849b76a7872eb34375a2f501eee0f4c0c56b4888d9.jpg)

### Part 2

<!-- Source: /api/assets/f9bb30d86ca57092628de4849b76a7872eb34375a2f501eee0f4c0c56b4888d9.jpg; PDF page 96; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
School
• Did you go to secondary/high school near to where you lived? [Why/Why not?]
• What did you like about your secondary/high school? [Why?]
• Tell me about anything you didn’t like at your school.
• How do you think your school could be improved? [Why/Why not?]
PART 2
Describe something you don’t have now but
would really like to own in the future.
You should say:
what this thing is
how long you have wanted to own it
where you first saw it
and explain why you would like to own it.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going
to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Owning things
Example questions:
What types of things do young people in your country most want to own today?
Why is this?
Why do some people feel they need to own things?
Do you think that owning lots of things makes people happy? Why?
Salaries for skilled people
Example questions:
Do you think television and films can make people want to get new possessions?
Why do they have this effect?
Are there any benefits to society of people wanting to get new possessions?
Why do you think this is?
Do you think people will consider that having lots of possessions is a sign of success
in the future? Why?


[Source note: the printed Part 3 subheading “Salaries for skilled people” is retained although its questions concern possessions.]
```

[Original question page](assets/f9bb30d86ca57092628de4849b76a7872eb34375a2f501eee0f4c0c56b4888d9.jpg)

### Part 3

<!-- Source: /api/assets/f9bb30d86ca57092628de4849b76a7872eb34375a2f501eee0f4c0c56b4888d9.jpg; PDF page 96; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
School
• Did you go to secondary/high school near to where you lived? [Why/Why not?]
• What did you like about your secondary/high school? [Why?]
• Tell me about anything you didn’t like at your school.
• How do you think your school could be improved? [Why/Why not?]
PART 2
Describe something you don’t have now but
would really like to own in the future.
You should say:
what this thing is
how long you have wanted to own it
where you first saw it
and explain why you would like to own it.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going
to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Owning things
Example questions:
What types of things do young people in your country most want to own today?
Why is this?
Why do some people feel they need to own things?
Do you think that owning lots of things makes people happy? Why?
Salaries for skilled people
Example questions:
Do you think television and films can make people want to get new possessions?
Why do they have this effect?
Are there any benefits to society of people wanting to get new possessions?
Why do you think this is?
Do you think people will consider that having lots of possessions is a sign of success
in the future? Why?


[Source note: the printed Part 3 subheading “Salaries for skilled people” is retained although its questions concern possessions.]
```

[Original question page](assets/f9bb30d86ca57092628de4849b76a7872eb34375a2f501eee0f4c0c56b4888d9.jpg)
