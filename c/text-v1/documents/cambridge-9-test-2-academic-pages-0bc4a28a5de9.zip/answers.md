# 剑雅 9 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 146

TEST 2 LISTENING
1 Bhatt
2 31 March
3 nursing
4 2
5 meat
6 bedsit
7 theatre / theater
8 mature / older
9 town
10 shared
11 trees
12 Friday / Sunday
13 farm
14 C
15 B
16 A
17 A
18 I
19 F
20 E
21 C
22 B
23 B
24 C
25 reading
26 CD
27 workbooks
28 timetable / schedule
29 alarm
30 email / emails
31 central
32 conversation / conversations
33 effectively
34 risk / risks
35 levels
36 description / descriptions
37 technical
38 change
39 responsibility
40 flexible
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. Bhatt

2. 31 March

3. nursing

4. 2

5. meat

6. bedsit

7. theatre / theater

8. mature / older

9. town

10. shared

### Part 2 · source page 146

TEST 2 LISTENING
1 Bhatt
2 31 March
3 nursing
4 2
5 meat
6 bedsit
7 theatre / theater
8 mature / older
9 town
10 shared
11 trees
12 Friday / Sunday
13 farm
14 C
15 B
16 A
17 A
18 I
19 F
20 E
21 C
22 B
23 B
24 C
25 reading
26 CD
27 workbooks
28 timetable / schedule
29 alarm
30 email / emails
31 central
32 conversation / conversations
33 effectively
34 risk / risks
35 levels
36 description / descriptions
37 technical
38 change
39 responsibility
40 flexible
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. trees

12. Friday / Sunday

13. farm

14. C

15. B

16. A

17. A

18. I

19. F

20. E

### Part 3 · source page 146

TEST 2 LISTENING
1 Bhatt
2 31 March
3 nursing
4 2
5 meat
6 bedsit
7 theatre / theater
8 mature / older
9 town
10 shared
11 trees
12 Friday / Sunday
13 farm
14 C
15 B
16 A
17 A
18 I
19 F
20 E
21 C
22 B
23 B
24 C
25 reading
26 CD
27 workbooks
28 timetable / schedule
29 alarm
30 email / emails
31 central
32 conversation / conversations
33 effectively
34 risk / risks
35 levels
36 description / descriptions
37 technical
38 change
39 responsibility
40 flexible
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. C

22. B

23. B

24. C

25. reading

26. CD

27. workbooks

28. timetable / schedule

29. alarm

30. email / emails

### Part 4 · source page 146

TEST 2 LISTENING
1 Bhatt
2 31 March
3 nursing
4 2
5 meat
6 bedsit
7 theatre / theater
8 mature / older
9 town
10 shared
11 trees
12 Friday / Sunday
13 farm
14 C
15 B
16 A
17 A
18 I
19 F
20 E
21 C
22 B
23 B
24 C
25 reading
26 CD
27 workbooks
28 timetable / schedule
29 alarm
30 email / emails
31 central
32 conversation / conversations
33 effectively
34 risk / risks
35 levels
36 description / descriptions
37 technical
38 change
39 responsibility
40 flexible
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. central

32. conversation / conversations

33. effectively

34. risk / risks

35. levels

36. description / descriptions

37. technical

38. change

39. responsibility

40. flexible

## A 类阅读

### Academic Reading · source page 147

ACADEMIC READING
1 H
2 C
3 B
4 I
5 D
6 A
7 two decades
8 crowd (noise)
9 invisible (disabilities / disability)
10 Objective 3
11 A
12 C
13 C
14 F
15 D
16 G
17 E
18 D
19 A
20 B
21 C
22 FALSE
23 FALSE
24 TRUE
25 NOT GIVEN
26 TRUE
27 C
28 B
29 D
30 C
31 B
32 YES
33 YES
34 NOT GIVEN
35 NO
36 NOT GIVEN
37 NO
38 A
39 B
40 C
11–12 IN EITHER ORDER: A; C
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. H

2. C

3. B

4. I

5. D

6. A

7. two decades

8. crowd / crowd noise

9. invisible / invisible disabilities / invisible disability

10. Objective 3

11. A / C

12. A / C

13. C

14. F

15. D

16. G

17. E

18. D

19. A

20. B

21. C

22. FALSE

23. FALSE

24. TRUE

25. NOT GIVEN

26. TRUE

27. C

28. B

29. D

30. C

31. B

32. YES

33. YES

34. NOT GIVEN

35. NO

36. NOT GIVEN

37. NO

38. A

39. B

40. C

## A 类写作

### Writing material: c9-t2-w-1

UK, 1995–2002, BILLIONS OF MINUTES, not number of calls. Local fixed line remains largest: approximately72,79,85,89,90,85,79,72. National/international fixed line rises about37,41,46,48,50,56,61,62. Mobiles (all calls) rises approximately3,5,7,9,12,24,39,45. All readings approximate because bars are not numerically labelled. Local peaks around1999 then returns close to its initial level; other categories increase throughout. Mobiles has fastest proportional growth but remains below both fixed-line categories in2002. Do not call national/international mobile calls or claim local continuously grows.



### Writing material: c9-t2-w-2

Evaluate making unpaid community service compulsory in high school. Distinguish compulsory participation from whether volunteering is useful; any justified degree of agreement is permissible.



## 口语
