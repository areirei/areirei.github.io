# 剑雅 9 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/7be051e4433a60b07813f8dbde7a3a38484a71ae2d42904fa38de19c9a1b6c11.jpg; PDF page 25; full -->

```text
SECTION 1 Questions 1–10
Complete the form below. Write ONE WORD AND/OR A NUMBER for each answer.
Accommodation Form – Student Information
Example — Type of accommodation: hall of residence
Name: Anu (1) __________
Date of birth: (2) __________
Country of origin: India
Course of study: (3) __________
Number of years planned in hall: (4) __________
Preferred catering arrangement: half board
Special dietary requirements: no (5) __________ (red)
Preferred room type: a single (6) __________
Interests: the (7) __________; badminton
```

[Original question page](assets/7be051e4433a60b07813f8dbde7a3a38484a71ae2d42904fa38de19c9a1b6c11.jpg)

<!-- Source: /api/assets/e5e3c8e1161fee9048966090fa4129c34dfe472d9a03edba7db7055734929336.jpg; PDF page 26; full -->

```text
Priorities in choice of hall:
– to be with other students who are (8) __________
– to live outside the (9) __________
– to have a (10) __________ area for socialising
Contact phone number: 667549
```

[Original question page](assets/e5e3c8e1161fee9048966090fa4129c34dfe472d9a03edba7db7055734929336.jpg)

### Part 2

<!-- Source: /api/assets/835e1eb00870918bcf4072361871360359d795d94a30f432f319359f14a37ab8.jpg; PDF page 27; full -->

```text
SECTION 2 Questions 11–20
Questions 11–13
Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
Parks and open spaces
| Name of place | Of particular interest | Open |
| --- | --- | --- |
| Halland Common | source of River Ouse | 24 hours |
| Holt Island | many different (11) __________ | between (12) __________ and __________ |
| Longfield Country Park | reconstruction of a 2,000-year-old (13) __________ with activities for children | daylight hours |
Questions 14–16
Choose the correct letter, A, B or C.
Longfield Park
14 As part of Monday’s activity, visitors will
A prepare food with herbs.
B meet a well-known herbalist.
C dye cloth with herbs.
15 For the activity on Wednesday,
A only group bookings are accepted.
B visitors should book in advance.
C attendance is free.
16 For the activity on Saturday, visitors should
A come in suitable clothing.
B make sure they are able to stay for the whole day.
C tell the rangers before the event what they wish to do.
```

[Original question page](assets/835e1eb00870918bcf4072361871360359d795d94a30f432f319359f14a37ab8.jpg)

<!-- Source: /api/assets/42e9e77db297debf19723107396e387f86fcef95fd70ab5589cd03978de5da5b.jpg; PDF page 28; full -->

```text
Questions 17–20
Label the map below. Write the correct letter, A–I, next to questions 17–20.
Hinchingbrooke Park
[Original map retained; compass north up. Lake at northwest; West gate on west side below centre; East gate at northeast; Refreshments beside southern path to east of central roundabout. A at northwest tip of lake; B southwest of lake; C south of lake near its east half; D east end of lake/northern path; E west open area between lake and west-gate path; F inside central roundabout; G large eastern open area; H southwest corner below West gate; I south of path east of Refreshments. No answers supplied.]
17 bird hide __________
18 dog-walking area __________
19 flower garden __________
20 wooded area __________
```

[Original question page](assets/42e9e77db297debf19723107396e387f86fcef95fd70ab5589cd03978de5da5b.jpg)

![Original figure](assets/42e9e77db297debf19723107396e387f86fcef95fd70ab5589cd03978de5da5b.jpg)

### Part 3

<!-- Source: /api/assets/6ca66b0a6f62d93e1ab21661da46360295396c22323db83f05f7d42cf321941d.jpg; PDF page 29; full -->

```text
SECTION 3 Questions 21–30
Questions 21–24
Choose the correct letter, A, B or C.
Self-Access Centre
21 Students want to keep the Self-Access Centre because
A they enjoy the variety of equipment.
B they like being able to work on their own.
C it is an important part of their studies.
22 Some teachers would prefer to
A close the Self-Access Centre.
B move the Self-Access Centre elsewhere.
C restrict access to the Self-Access Centre.
23 The students’ main concern about using the library would be
A the size of the library.
B difficulty in getting help.
C the lack of materials.
24 The Director of Studies is concerned about
A the cost of upgrading the centre.
B the lack of space in the centre.
C the difficulty in supervising the centre.
```

[Original question page](assets/6ca66b0a6f62d93e1ab21661da46360295396c22323db83f05f7d42cf321941d.jpg)

<!-- Source: /api/assets/b1e1857782e95b262550a962d9915bb6a7f52cdd22d5a5f5ac590f6878826764.jpg; PDF page 30; full -->

```text
Questions 25–30
Complete the notes below. Write NO MORE THAN TWO WORDS for each answer.
Necessary improvements to the existing Self-Access Centre
Equipment
Replace computers to create more space.
Resources
The level of the (25) __________ materials, in particular, should be more clearly shown.
Update the (26) __________ collection.
Buy some (27) __________ and divide them up.
Use of the room
Speak to the teachers and organise a (28) __________ for supervising the centre.
Install an (29) __________.
Restrict personal use of (30) __________ on computers.
```

[Original question page](assets/b1e1857782e95b262550a962d9915bb6a7f52cdd22d5a5f5ac590f6878826764.jpg)

### Part 4

<!-- Source: /api/assets/6af71a122f6020a52864f532d53fcb244fb5c9c50641a9db95e3a3ab4fd8c975.jpg; PDF page 31; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Business Cultures
Power culture
Characteristics of organisation:
– small
– (31) __________ power source
– few rules and procedures
– communication by (32) __________
Advantage: can act quickly
Disadvantage: might not act (33) __________
Suitable employee:
– not afraid of (34) __________
– doesn’t need job security
Role culture
Characteristics of organisation:
– large, many (35) __________
– specialised departments
– rules and procedure, e.g. job (36) __________ and rules for discipline
```

[Original question page](assets/6af71a122f6020a52864f532d53fcb244fb5c9c50641a9db95e3a3ab4fd8c975.jpg)

<!-- Source: /api/assets/c6a8a11ebfd78f5b751d11d9ab6e7281bb61232493991b49322507a24945fe58.jpg; PDF page 32; full -->

```text
Role culture (continued)
Advantages:
– economies of scale
– successful when (37) __________ ability is important
Disadvantages:
– slow to see when (38) __________ is needed
– slow to react
Suitable employee:
– values security
– doesn’t want (39) __________
Task culture
Characteristics of organisation:
– project orientated
– in competitive market or making product with short life
– a lot of delegation
Advantage: (40) __________
Disadvantages: no economies of scale or special expertise
Suitable employee: likes to work in groups
```

[Original question page](assets/c6a8a11ebfd78f5b751d11d9ab6e7281bb61232493991b49322507a24945fe58.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/ed6089399ae70f7aaeefaac11841b04c3d0198b97c96d3bd56849f3f3813f346.jpg; PDF page 33; full -->

```text
Reading

READING

READING PASSAGE 1

You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.

A

Hearing impairment or other auditory function deficit in young children can have a major impact
on their development of speech and communication, resulting in a detrimental effect on their
ability to learn at school. This is likely to have major consequences for the individual and the
population as a whole. The New Zealand Ministry of Health has found from research carried out
over two decades that 6-10% of children in that country are affected by hearing loss.

B A preliminary study in New Zealand has shown that classroom noise presents a major
concern for teachers and pupils. Modern teaching practices, the organisation of desks

in the classroom, poor classroom acoustics, and mechanical means of ventilation such as
air-conditioning units all contribute to the number of children unable to comprehend the
teacher's voice. Education researchers Nelson and Soli have also suggested that recent
trends in learning often involve collaborative interaction of multiple minds and tools as much
as individual possession of information. This all amounts to heightened activity and noise
levels, which have the potential to be particularly serious for children experiencing auditory
function deficit. Noise in classrooms can only exacerbate their difficulty in comprehending
and processing verbal communication with other children and instructions from the teacher.

C Children with auditory function deficit are potentially failing to learn to their maximum
potential because of noise levels generated in classrooms. The effects of noise on the ability
of children to learn effectively in typical classroom environments are now the subject of
increasing concern. The International Institute of Noise Control Engineering

(I-INCE), on the advice of the World Health Organization, has established an international
working party, which includes New Zealand, to evaluate noise and reverberation control for
school rooms.

D While the detrimental effects of noise in classroom situations are not limited to children
experiencing disability, those with a disability that affects their processing of speech and
verbal communication could be extremely vulnerable. The auditory function deficits in
question include hearing impairment, autistic spectrum disorders (ASD) and attention deficit
disorders (ADD/ADHD).

E Autism is considered a neurological and genetic life-long disorder that causes discrepancies
in the way information is processed. This disorder is characterised by interlinking problems
with social imagination, social communication and social interaction. According to Janzen,
this affects the ability to understand and relate in typical ways to people, understand events
and objects in the environment, and understand or respond to sensory stimuli. Autism does
not allow learning or thinking in the same ways as in children who are developing normally.
```

[Original question page](assets/ed6089399ae70f7aaeefaac11841b04c3d0198b97c96d3bd56849f3f3813f346.jpg)

<!-- Source: /api/assets/c143932d16c6c47d2b1e7e9d152e4e82cb81ce89d743f81f7b04366f8e54dbae.jpg; PDF page 34; full -->

```text
Test 2

42

Autistic spectrum disorders often result in major difficulties in comprehending verbal
information and speech processing. Those experiencing these disorders often find sounds
such as crowd noise and the noise generated by machinery painful and distressing. This is
difficult to scientifically quantify as such extra-sensory stimuli vary greatly from one autistic
individual to another. But a child who finds any type of noise in their classroom or learning
space intrusive is likely to be adversely affected in their ability to process information.

F The attention deficit disorders are indicative of neurological and genetic disorders and are
characterised by difficulties with sustaining attention, effort and persistence, organisation
skills and disinhibition. Children experiencing these disorders find it difficult to screen out
unimportant information, and focus on everything in the environment rather than attending
to a single activity. Background noise in the classroom becomes a major distraction, which
can affect their ability to concentrate.

G Children experiencing an auditory function deficit can often find speech and communication
very difficult to isolate and process when set against high levels of background noise.

These levels come from outside activities that penetrate the classroom structure, from
teaching activities, and other noise generated inside, which can be exacerbated by room
reverberation. Strategies are needed to obtain the optimum classroom construction and
perhaps a change in classroom culture and methods of teaching. In particular, the effects

of noisy classrooms and activities on those experiencing disabilities in the form of auditory
function deficit need thorough investigation. It is probable that many undiagnosed children
exist in the education system with ‘invisible’ disabilities. Their needs are less likely to be met
than those of children with known disabilities.

H The New Zealand Government has developed a New Zealand Disability Strategy and has
embarked on a wide-ranging consultation process. The strategy recognises that people
experiencing disability face significant barriers in achieving a full quality of life in areas such
as attitude, education, employment and access to services. Objective 3 of the New Zealand
Disability Strategy is to ‘Provide the Best Education for Disabled People’ by improving
education so that all children, youth learners and adult learners will have equal opportunities
to learn and develop within their already existing local school. For a successful education,
the learning environment is vitally significant, so any effort to improve this is likely to be of
great benefit to all children, but especially to those with auditory function disabilities.

I A number of countries are already in the process of formulating their own standards for
the control and reduction of classroom noise. New Zealand will probably follow their
example. The literature to date on noise in school rooms appears to focus on the effects on
schoolchildren in general, their teachers and the hearing impaired. Only limited attention
appears to have been given to those students experiencing the other disabilities involving
auditory function deficit. It is imperative that the needs of these children are taken into
account in the setting of appropriate international standards to be promulgated in future.
```

[Original question page](assets/c143932d16c6c47d2b1e7e9d152e4e82cb81ce89d743f81f7b04366f8e54dbae.jpg)

<!-- Source: /api/assets/03b1bbb70b35169030c5cde9c210c74de4d830cfa60a26f9cb584917e586cbb6.jpg; PDF page 35; full -->

```text
Questions 1–6
Reading Passage 1 has nine sections, A–I.
Which section contains the following information?
Write the correct letter, A–I, in boxes 1–6 on your answer sheet.
1 an account of a national policy initiative
2 a description of a global team effort
3 a hypothesis as to one reason behind the growth in classroom noise
4 a demand for suitable worldwide regulations
5 a list of medical conditions which place some children more at risk from noise than others
6 the estimated proportion of children in New Zealand with auditory problems
Questions 7–10
Answer the questions below. Choose NO MORE THAN TWO WORDS AND/OR A NUMBER from the passage for each answer.
Write your answers in boxes 7–10 on your answer sheet.
7 For what period of time has hearing loss in schoolchildren been studied in New Zealand?
8 In addition to machinery noise, what other type of noise can upset children with autism?
9 What term is used to describe the hearing problems of schoolchildren which have not been diagnosed?
10 What part of the New Zealand Disability Strategy aims to give schoolchildren equal opportunity?
```

[Original question page](assets/03b1bbb70b35169030c5cde9c210c74de4d830cfa60a26f9cb584917e586cbb6.jpg)

<!-- Source: /api/assets/9fc01a1ee7885f948708a925651269aa2f49f5b9ca51a0c870d3f4640fe99e37.jpg; PDF page 36; full -->

```text
Questions 11 and 12
Choose TWO letters, A–F. Write the correct letters in boxes 11 and 12 on your answer sheet.
The list below includes factors contributing to classroom noise.
Which TWO are mentioned by the writer of the passage?
A current teaching methods
B echoing corridors
C cooling systems
D large class sizes
E loud-voiced teachers
F playground games
Question 13
Choose the correct letter, A, B, C or D. Write the correct letter in box 13 on your answer sheet.
What is the writer’s overall purpose in writing this article?
A to compare different methods of dealing with auditory problems
B to provide solutions for overly noisy learning environments
C to increase awareness of the situation of children with auditory problems
D to promote New Zealand as a model for other countries to follow
```

[Original question page](assets/9fc01a1ee7885f948708a925651269aa2f49f5b9ca51a0c870d3f4640fe99e37.jpg)

<!-- Source: /api/assets/7d64fda1093a3d61861d83a33966441b4836a50d6bc1af1ee7a9368c64d4bdfa.jpg; PDF page 37; full -->

```text
Reading

READING PASSAGE 2

You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.

Venus in transit

June 2004 saw the first passage, known as a ‘transit’,
of the planet Venus across the face of the Sun in

122 years. Transits have helped shape our view of
the whole Universe, as Heather Cooper and Nigel
Henbest explain

A On 8 June 2004, more than half the population of the world were treated to a rare
astronomical event. For over six hours, the planet Venus steadily inched its way over the
surface of the Sun. This ‘transit’ of Venus was the first since 6 December 1882. On that
occasion, the American astronomer Professor Simon Newcomb led a party to South
Africa to observe the event. They were based at a girls’ school, where — it is alleged - the
combined forces of three schoolmistresses outperformed the professionals with the
accuracy of their observations.

B For centuries, transits of Venus have drawn explorers and astronomers alike to the
four corners of the globe. And you can put it all down to the extraordinary polymath
Edmond Halley. In November 1677, Halley observed a transit of the innermost planet,
Mercury, from the desolate island of St Helena in the South Pacific. He realised that,
from different latitudes, the passage of the planet across the Sun's disc would appear to
differ. By timing the transit from two widely-separated locations, teams of astronomers
could calculate the parallax angle - the apparent difference in position of an
astronomical body due to a difference in the observer’s position. Calculating this angle
would allow astronomers to measure what was then the ultimate goal: the distance of
the Earth from the Sun. This distance is known as the ‘astronomical unit’ or AU.

C Halley was aware that the AU was one of the most fundamental of all astronomical
measurements. Johannes Kepler, in the early 17th century, had shown that the
distances of the planets from the Sun governed their orbital speeds, which were easily
measurable. But no-one had found a way to calculate accurate distances to the planets
from the Earth. The goal was to measure the AU; then, knowing the orbital speeds of
all the other planets round the Sun, the scale of the Solar System would fall into place.
However, Halley realised that Mercury was so far away that its parallax angle would be
very difficult to determine. As Venus was closer to the Earth, its parallax angle would be
larger, and Halley worked out that by using Venus it would be possible to measure the

45
```

[Original question page](assets/7d64fda1093a3d61861d83a33966441b4836a50d6bc1af1ee7a9368c64d4bdfa.jpg)

<!-- Source: /api/assets/cc3aa05a2110001e023276c56c9c7a30c84b90b1cdf0c0594b4a38543d529dd3.jpg; PDF page 38; full -->

```text
Test 2

46

Sun's distance to 1 part in 500. But there was a problem: transits of Venus, unlike those
of Mercury, are rare, occurring in pairs roughly eight years apart every hundred or so
years. Nevertheless, he accurately predicted that Venus would cross the face of the Sun
in both 1761 and 1769 — though he didn’t survive to see either.

D Inspired by Halley’s suggestion of a way to pin down the scale of the Solar System,
teams of British and French astronomers set out on expeditions to places as diverse as
India and Siberia. But things weren't helped by Britain and France being at war. The
person who deserves most sympathy is the French astronomer Guillaume Le Gentil.
He was thwarted by the fact that the British were besieging his observation site at
Pondicherry in India. Fleeing on a French warship crossing the Indian Ocean, Le Gentil
saw a wonderful transit — but the ship’s pitching and rolling ruled out any attempt at
making accurate observations. Undaunted, he remained south of the equator, keeping
himself busy by studying the islands of Mauritius and Madagascar before setting off
to observe the next transit in the Philippines. Ironically after travelling nearly 50,000
kilometres, his view was clouded out at the last moment, a very dispiriting experience.

E While the early transit timings were as precise as instruments would allow, the
measurements were dogged by the ‘black drop’ effect. When Venus begins to cross the
Sun’s disc, it looks smeared not circular - which makes it difficult to establish timings.
This is due to diffraction of light. The second problem is that Venus exhibits a halo of
light when it is seen just outside the Sun’s disc. While this showed astronomers that
Venus was surrounded by a thick layer of gases refracting sunlight around it, both
effects made it impossible to obtain accurate timings.

F But astronomers laboured hard to analyse the results of these expeditions to observe
Venus transits. Johann Franz Encke, Director of the Berlin Observatory, finally
determined a value for the AU based on all these parallax measurements:

153,340,000 km. Reasonably accurate for the time, that is quite close to today’s value of
149,597,870 km, determined by radar, which has now superseded transits and all other
methods in accuracy. The AU is a cosmic measuring rod, and the basis of how we scale
the Universe today. The parallax principle can be extended to measure the distances to
the stars. If we look at a star in January - when Earth is at one point in its orbit - it will
seem to be in a different position from where it appears six months later. Knowing the
width of Earth's orbit, the parallax shift lets astronomers calculate the distance.

G June 2004’s transit of Venus was thus more of an astronomical spectacle than a
scientifically important event. But such transits have paved the way for what might
prove to be one of the most vital breakthroughs in the cosmos - detecting Earth-sized
planets orbiting other stars.
```

[Original question page](assets/cc3aa05a2110001e023276c56c9c7a30c84b90b1cdf0c0594b4a38543d529dd3.jpg)

<!-- Source: /api/assets/acff469199829862bad01f6e513170843139b3bad4ba6dcf17a812a5ec14af94.jpg; PDF page 39; full -->

```text
Questions 14–17
Reading Passage 2 has seven paragraphs, A–G.
Which paragraph contains the following information?
Write the correct letter, A–G, in boxes 14–17 on your answer sheet.
14 examples of different ways in which the parallax principle has been applied
15 a description of an event which prevented a transit observation
16 a statement about potential future discoveries leading on from transit observations
17 a description of physical states connected with Venus which early astronomical instruments failed to overcome
Questions 18–21
Look at the following statements (Questions 18–21) and the list of people below.
Match each statement with the correct person, A, B, C or D.
Write the correct letter, A, B, C or D, in boxes 18–21 on your answer sheet.
18 He calculated the distance of the Sun from the Earth based on observations of Venus with a fair degree of accuracy.
19 He understood that the distance of the Sun from the Earth could be worked out by comparing observations of a transit.
20 He realised that the time taken by a planet to go round the Sun depends on its distance from the Sun.
21 He witnessed a Venus transit but was unable to make any calculations.
List of People
A Edmond Halley
B Johannes Kepler
C Guillaume Le Gentil
D Johann Franz Encke
```

[Original question page](assets/acff469199829862bad01f6e513170843139b3bad4ba6dcf17a812a5ec14af94.jpg)

<!-- Source: /api/assets/3398b6f58180dcc424d9c9dd50908911be21707fd446716f54ac8c11ef844452.jpg; PDF page 40; full -->

```text
Test 2

Questions 22-26
Do the following statements agree with the information given in Reading Passage 2?
In boxes 22-26 on your answer sheet, write

TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
22 Halley observed one transit of the planet Venus.
23 Le Gentil managed to observe a second Venus transit.
24 The shape of Venus appears distorted when it starts to pass in front of the Sun.
25 Early astronomers suspected that the atmosphere on Venus was toxic.

26 The parallax principle allows astronomers to work out how far away distant stars
are from the Earth.

48
```

[Original question page](assets/3398b6f58180dcc424d9c9dd50908911be21707fd446716f54ac8c11ef844452.jpg)

<!-- Source: /api/assets/6c3ed3f7490254103232fa1cd197cdaede12d8912947bccbebb3f69d80ba3ebd.jpg; PDF page 41; full -->

```text
Reading

READING PASSAGE 3

You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.

A neuroscientist reveals
how to think differently

In the last decade a revolution has occurred in the way that scientists think about the brain.
We now know that the decisions humans make can be traced to the firing patterns of neurons
in specific parts of the brain. These discoveries have led to the field known as neuroeconomics,
which studies the brain’s secrets to success in an economic environment that demands
innovation and being able to do things differently from competitors. A brain that can do this is
an iconoclastic one. Briefly, an iconoclast is a person who does something that others say can’t
be done.

This definition implies that iconoclasts are different from other people, but more precisely, it
is their brains that are different in three distinct ways: perception, fear response, and social
intelligence. Each of these three functions utilizes a different circuit in the brain. Naysayers
might suggest that the brain is irrelevant, that thinking in an original, even revolutionary,

way is more a matter of personality than brain function. But the field of neuroeconomics was
born out of the realization that the physical workings of the brain place limitations on the way
we make decisions. By understanding these constraints, we begin to understand why some
people march to a different drumbeat.

The first thing to realize is that the brain suffers from limited resources. It has a fixed energy
budget, about the same as a 40 watt light bulb, so it has evolved to work as efficiently as
possible. This is where most people are impeded from being an iconoclast. For example, when
confronted with information streaming from the eyes, the brain will interpret this information
in the quickest way possible. Thus it will draw on both past experience and any other source
of information, such as what other people say, to make sense of what it is seeing. This happens
all the time. The brain takes shortcuts that work so well we are hardly ever aware of them.

We think our perceptions of the world are real, but they are only biological and electrical
rumblings. Perception is not simply a product of what your eyes or ears transmit to your brain.
More than the physical reality of photons or sound waves, perception is a product of the brain.

Perception is central to iconoclasm. Iconoclasts see things differently to other people. Their
brains do not fall into efficiency pitfalls as much as the average person's brain. Iconoclasts, either
because they were born that way or through learning, have found ways to work around the
perceptual shortcuts that plague most people. Perception is not something that is hardwired

49
```

[Original question page](assets/6c3ed3f7490254103232fa1cd197cdaede12d8912947bccbebb3f69d80ba3ebd.jpg)

<!-- Source: /api/assets/6dac6681082e76732c02085e265c8951bddffef8f0f457f8f14ac67de5d07c04.jpg; PDF page 42; full -->

```text
Test 2

into the brain. It is a learned process, which is both a curse and an opportunity for change. The
brain faces the fundamental problem of interpreting physical stimuli from the senses. Everything
the brain sees, hears, or touches has multiple interpretations. The one that is ultimately chosen

is simply the brain's best theory. In technical terms, these conjectures have their basis in the
statistical likelihood of one interpretation over another and are heavily influenced by past
experience and, importantly for potential iconoclasts, what other people say.

The best way to see things differently to other people is to bombard the brain with things
it has never encountered before. Novelty releases the perceptual process from the chains
of past experience and forces the brain to make new judgments. Successful iconoclasts
have an extraordinary willingness to be exposed to what is fresh and different. Observation
of iconoclasts shows that they embrace novelty while most people avoid things that are
different.

The problem with novelty, however, is that it tends to trigger the brain's fear system. Fear

is a major impediment to thinking like an iconoclast and stops the average person in his
tracks. There are many types of fear, but the two that inhibit iconoclastic thinking and people
generally find difficult to deal with are fear of uncertainty and fear of public ridicule. These may
seem like trivial phobias. But fear of public speaking, which everyone must do from time to
time, afflicts one-third of the population. This makes it too common to be considered a mental
disorder. It is simply a common variant of human nature, one which iconoclasts do not let
inhibit their reactions.

Finally, to be successful iconoclasts, individuals must sell their ideas to other people. This

is where social intelligence comes in. Social intelligence is the ability to understand and
manage people in a business setting. In the last decade there has been an explosion of
knowledge about the social brain and how the brain works when groups coordinate decision
making. Neuroscience has revealed which brain circuits are responsible for functions like
understanding what other people think, empathy, fairness, and social identity. These brain
regions play key roles in whether people convince others of their ideas. Perception is
important in social cognition too. The perception of someone's enthusiasm, or reputation,
can make or break a deal. Understanding how perception becomes intertwined with social
decision making shows why successful iconoclasts are so rare.

Iconoclasts create new opportunities in every area from artistic expression to technology to
business. They supply creativity and innovation not easily accomplished by committees. Rules
aren't important to them. Iconoclasts face alienation and failure, but can also be a major asset
to any organization. It is crucial for success in any field to understand how the iconoclastic
mind works.

50
```

[Original question page](assets/6dac6681082e76732c02085e265c8951bddffef8f0f457f8f14ac67de5d07c04.jpg)

<!-- Source: /api/assets/6e86fe561ecd99d73bd52d9e913a8dba50edf6fe49e66315683cd4ff2cbd9281.jpg; PDF page 43; full -->

```text
Questions 27–31
Choose the correct letter, A, B, C or D. Write the correct letter in boxes 27–31 on your answer sheet.
27 Neuroeconomics is a field of study which seeks to
A cause a change in how scientists understand brain chemistry.
B understand how good decisions are made in the brain.
C understand how the brain is linked to achievement in competitive fields.
D trace the specific firing patterns of neurons in different areas of the brain.
28 According to the writer, iconoclasts are distinctive because
A they create unusual brain circuits.
B their brains function differently.
C their personalities are distinctive.
D they make decisions easily.
29 According to the writer, the brain works efficiently because
A it uses the eyes quickly.
B it interprets data logically.
C it generates its own energy.
D it relies on previous events.
30 The writer says that perception is
A a combination of photons and sound waves.
B a reliable product of what your senses transmit.
C a result of brain processes.
D a process we are usually conscious of.
31 According to the writer, an iconoclastic thinker
A centralises perceptual thinking in one part of the brain.
B avoids cognitive traps.
C has a brain that is hardwired for learning.
D has more opportunities than the average person.
```

[Original question page](assets/6e86fe561ecd99d73bd52d9e913a8dba50edf6fe49e66315683cd4ff2cbd9281.jpg)

<!-- Source: /api/assets/ca2b62c0e778eda3aafc7d26fb116d09c4dc7cb0c82e19902f0bb14c861b42b2.jpg; PDF page 44; full -->

```text
Questions 32–37
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 32–37 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
32 Exposure to different events forces the brain to think differently.
33 Iconoclasts are unusually receptive to new experiences.
34 Most people are too shy to try different things.
35 If you think in an iconoclastic way, you can easily overcome fear.
36 When concern about embarrassment matters less, other fears become irrelevant.
37 Fear of public speaking is a psychological illness.
Questions 38–40
Complete each sentence with the correct ending, A–E, below.
Write the correct letter, A–E, in boxes 38–40 on your answer sheet.
38 Thinking like a successful iconoclast is demanding because it
39 The concept of the social brain is useful to iconoclasts because it
40 Iconoclasts are generally an asset because their way of thinking
A requires both perceptual and social intelligence skills.
B focuses on how groups decide on an action.
C works in many fields, both artistic and scientific.
D leaves one open to criticism and rejection.
E involves understanding how organisations manage people.
```

[Original question page](assets/ca2b62c0e778eda3aafc7d26fb116d09c4dc7cb0c82e19902f0bb14c861b42b2.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/73f77423fd60225ab1c408cd00fc3cef22d353784bc1b0d8371574ec772686a3.jpg; PDF page 45; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows the total number of minutes (in billions) of telephone calls in the UK, divided into three categories, from 1995–2002.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/73f77423fd60225ab1c408cd00fc3cef22d353784bc1b0d8371574ec772686a3.jpg)

![Original figure](assets/73f77423fd60225ab1c408cd00fc3cef22d353784bc1b0d8371574ec772686a3.jpg)

### Task 2

<!-- Source: /api/assets/b66cea9c0041f1e2207192eba007c8cc8bcf87cab0d6e573fdf2f889dfec45a5.jpg; PDF page 46; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that unpaid community service should be a compulsory part of high school programmes (for example working for a charity, improving the neighbourhood or teaching sports to younger children).

To what extent do you agree or disagree?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/b66cea9c0041f1e2207192eba007c8cc8bcf87cab0d6e573fdf2f889dfec45a5.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/85c5e2f48df29ef4ebbe4017e475e8f290e6d7f3e8680b8ab90380cca73c1884.jpg; PDF page 47; full -->

```text
Speaking

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE

Giving gifts

When do people give gifts or presents in your country?

Do you ever take a gift when you visit someone in their home? [Why/Why not?]
When did you last receive a gift? [What was it?]

Do you enjoy looking for gifts for people? [Why/Why not?]

PART 2
Describe something you did that was new or exciting.
You should say:
what you did
where and when you did this
who you shared the activity with
and explain why this activity was new or exciting for you.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:

Doing new things

Example questions:

Why do you think some people like doing new things?

What problems can people have when they try new activities for the first time?
Do you think it’s best to do new things on your own or with other people? Why?

Learning new things

Example questions:
What kinds of things do children learn to do when they are very young? How important
are these things?
Do you think children and adults learn to do new things in the same way? How is their
learning style different?
Some people say that it is more important to be able to learn new things now than it was
in the past. Do you agree or disagree with that? Why?

55
```

[Original question page](assets/85c5e2f48df29ef4ebbe4017e475e8f290e6d7f3e8680b8ab90380cca73c1884.jpg)

### Part 2

<!-- Source: /api/assets/85c5e2f48df29ef4ebbe4017e475e8f290e6d7f3e8680b8ab90380cca73c1884.jpg; PDF page 47; full -->

```text
Speaking

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE

Giving gifts

When do people give gifts or presents in your country?

Do you ever take a gift when you visit someone in their home? [Why/Why not?]
When did you last receive a gift? [What was it?]

Do you enjoy looking for gifts for people? [Why/Why not?]

PART 2
Describe something you did that was new or exciting.
You should say:
what you did
where and when you did this
who you shared the activity with
and explain why this activity was new or exciting for you.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:

Doing new things

Example questions:

Why do you think some people like doing new things?

What problems can people have when they try new activities for the first time?
Do you think it’s best to do new things on your own or with other people? Why?

Learning new things

Example questions:
What kinds of things do children learn to do when they are very young? How important
are these things?
Do you think children and adults learn to do new things in the same way? How is their
learning style different?
Some people say that it is more important to be able to learn new things now than it was
in the past. Do you agree or disagree with that? Why?

55
```

[Original question page](assets/85c5e2f48df29ef4ebbe4017e475e8f290e6d7f3e8680b8ab90380cca73c1884.jpg)

### Part 3

<!-- Source: /api/assets/85c5e2f48df29ef4ebbe4017e475e8f290e6d7f3e8680b8ab90380cca73c1884.jpg; PDF page 47; full -->

```text
Speaking

PART 1

The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.

EXAMPLE

Giving gifts

When do people give gifts or presents in your country?

Do you ever take a gift when you visit someone in their home? [Why/Why not?]
When did you last receive a gift? [What was it?]

Do you enjoy looking for gifts for people? [Why/Why not?]

PART 2
Describe something you did that was new or exciting.
You should say:
what you did
where and when you did this
who you shared the activity with
and explain why this activity was new or exciting for you.
You will have to talk about the topic for one to two minutes.
You have one minute to think about what you are going to say.
You can make some notes to help you if you wish.
PART 3
Discussion topics:

Doing new things

Example questions:

Why do you think some people like doing new things?

What problems can people have when they try new activities for the first time?
Do you think it’s best to do new things on your own or with other people? Why?

Learning new things

Example questions:
What kinds of things do children learn to do when they are very young? How important
are these things?
Do you think children and adults learn to do new things in the same way? How is their
learning style different?
Some people say that it is more important to be able to learn new things now than it was
in the past. Do you agree or disagree with that? Why?

55
```

[Original question page](assets/85c5e2f48df29ef4ebbe4017e475e8f290e6d7f3e8680b8ab90380cca73c1884.jpg)
