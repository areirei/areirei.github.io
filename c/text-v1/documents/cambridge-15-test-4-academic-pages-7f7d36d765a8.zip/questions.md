# 剑雅 15 · Test 4

Text edition · verified

> Academic Reading: PDF page 88 full: C15T4 reading Q27–31 instructions print A–J, but the original list contains only A–I; no J option is supplied. All actual answers are in A–I.

## 听力

### Part 1

<!-- Source: /api/assets/b606b9a18497cc66afd9ef05de51267a509af0c652c5e30c64b4fe094665db38.jpg; PDF page 72; full -->

```text
LISTENING
PART 1 Questions 1–10
Complete the form below. Write ONE WORD AND/OR A NUMBER for each answer.
Customer Satisfaction Survey
Customer details
Name: Sophie Bird
Occupation: (1) __________
Reason for travel today: (2) __________
Journey information
Name of station returning to: (3) __________
Type of ticket purchased: standard (4) __________ ticket
Cost of ticket: (5) £ __________
When ticket was purchased: yesterday
Where ticket was bought: (6) __________
Satisfaction with journey
Most satisfied with: the wifi
Least satisfied with: the (7) __________ this morning
Satisfaction with station facilities
Most satisfied with: how much (8) __________ was provided
Least satisfied with: lack of seats, particularly on the (9) __________
Neither satisfied nor dissatisfied with: the (10) __________ available
```

[Original question page](assets/b606b9a18497cc66afd9ef05de51267a509af0c652c5e30c64b4fe094665db38.jpg)

### Part 2

<!-- Source: /api/assets/4d673880ea660515121884fd3873210cf444c14c0a3aae1b0da37ef61f2461b7.jpg; PDF page 73; full -->

```text
PART 2 Questions 11–20
Questions 11–16
Label the map below. Write the correct letter, A–H, next to Questions 11–16.
Croft Valley Park
[Original map retained with north/south gates, old museum, adventure playground, lake, glass houses and A–H labels. Use the map to answer.]
11 café __________
12 toilets __________
13 formal gardens __________
14 outdoor gym __________
15 skateboard ramp __________
16 wild flowers __________
```

[Original question page](assets/4d673880ea660515121884fd3873210cf444c14c0a3aae1b0da37ef61f2461b7.jpg)

![Original figure](assets/4d673880ea660515121884fd3873210cf444c14c0a3aae1b0da37ef61f2461b7.jpg)

<!-- Source: /api/assets/3b8defc1dd1dd33c169a1726b3baf22ffe97f1bbb5b208a714b48ef581be8a91.jpg; PDF page 74; full -->

```text
Questions 17 and 18
Choose TWO letters, A–E.
What does the speaker say about the adventure playground?
A Children must be supervised.
B It costs more in winter.
C Some activities are only for younger children.
D No payment is required.
E It was recently expanded.
Questions 19 and 20
Choose TWO letters, A–E.
What does the speaker say about the glass houses?
A They are closed at weekends.
B Volunteers are needed to work there.
C They were badly damaged by fire.
D More money is needed to repair some of the glass.
E Visitors can see palm trees from tropical regions.
```

[Original question page](assets/3b8defc1dd1dd33c169a1726b3baf22ffe97f1bbb5b208a714b48ef581be8a91.jpg)

### Part 3

<!-- Source: /api/assets/fbd83aec9f72d79c57f87c2da2db912929d8b4fddccd5b1d9450d1eeff61175f.jpg; PDF page 75; full -->

```text
Listening
PART 3 Questions 21-30
Questions 21-24
Choose the correct letter, A, B or C.




Presentation about refrigeration
21 What did Annie discover from reading about icehouses?
A why they were first created
B how the ice was kept frozen
C where they were located
22 What point does Annie make about refrigeration in ancient Rome?
A It became a commercial business.
B It used snow from nearby.
C It took a long time to become popular.
23 In connection with modern refrigerators, both Annie and Jack are worried about
A the complexity of the technology.
B the fact that some are disposed of irresponsibly.
C the large number that quickly break down.
24 What do Jack and Annie agree regarding domestic fridges?
A They are generally good value for money.
B There are plenty of useful variations.
C They are more useful than other domestic appliances.
77
```

[Original question page](assets/fbd83aec9f72d79c57f87c2da2db912929d8b4fddccd5b1d9450d1eeff61175f.jpg)

<!-- Source: /api/assets/269a18f7c2225a57ef3b18ba695acf2ecfdc0a8b92f71e3f0eaed8ba2d5e2509.jpg; PDF page 76; full -->

```text
Test 4
Questions 25-30
Who is going to do research into each topic?
Write the correct letter, A, B or C, next to Questions 25-30.
People
A Annie
B Jack
C both Annie and Jack
Topics
25 the goods that are refrigerated
26 the effects on health
27 the impact on food producers
28 the impact on cities
29 refrigerated transport
30 domestic fridges
78 => |@ p.125 p.115
```

[Original question page](assets/269a18f7c2225a57ef3b18ba695acf2ecfdc0a8b92f71e3f0eaed8ba2d5e2509.jpg)

### Part 4

<!-- Source: /api/assets/75f18ade14adb9697143b621bac4f72c892a68b2d8c184c017a4ffb229310fac.jpg; PDF page 77; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
How the Industrial Revolution affected life in Britain
19th century
• For the first time, people’s possessions were used to measure Britain’s (31) __________.
• Developments in production of goods and in (32) __________ greatly changed lives.
MAIN AREAS OF CHANGE
Manufacturing
• The Industrial Revolution would not have happened without the new types of (33) __________ that were used then.
• The leading industry was (34) __________ (its products became widely available).
• New (35) __________ made factories necessary and so more people moved into towns.
Transport
• The railways took the place of canals.
• Because of the new transport:
– greater access to (36) __________ made people more aware of what they could buy in shops.
– when shopping, people were not limited to buying (37) __________ goods.
Retailing
• The first department stores were opened.
• The displays of goods were more visible:
– inside stores because of better (38) __________.
– outside stores, because (39) __________ were bigger.
• (40) __________ that was persuasive became much more common.
```

[Original question page](assets/75f18ade14adb9697143b621bac4f72c892a68b2d8c184c017a4ffb229310fac.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/f928980a133defc3ba1726b07cfdae6ad9339e47ae12903277a5809251a2cc32.jpg; PDF page 78; full -->

```text
Test 4
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The return of the huarango
The arid valleys of southern Peru are welcoming
the return of a native plant
The south coast of Peru is a narrow, 2,000-kilometre-long strip of desert squeezed between the
Andes and the Pacific Ocean. It is also one of the most fragile ecosystems on Earth. It hardly ever
rains there, and the only year-round source of water is located tens of metres below the surface.
This is why the huarango tree is so suited to life there: it has the longest roots of any tree in the
world. They stretch down 50-80 metres and, as well as sucking up water for the tree, they bring it
into the higher subsoil, creating a water source for other plant life.
Dr David Beresford-Jones, archaeobotanist at Cambridge University, has been studying the role
of the huarango tree in landscape change in the Lower Ica Valley in southern Peru. He believes
the huarango was key to the ancient people’s diet and, because it could reach deep water sources,
it allowed local people to withstand years of drought when their other crops failed. But over the
centuries huarango trees were gradually replaced with crops. Cutting down native woodland leads
to erosion, as there is nothing to keep the soil in place. So when the huarangos go, the land turns
into a desert. Nothing grows at all in the Lower Ica Valley now.
For centuries the huarango tree was vital to the people of the neighbouring Middle Ica Valley
too. They grew vegetables under it and ate products made from its seed pods. Its leaves and bark
were used for herbal remedies, while its branches were used for charcoal for cooking and heating,
and its trunk was used to build houses. But now it is disappearing rapidly. The majority of the
huarango forests in the valley have already been cleared for fuel and agriculture — initially, these
were smallholdings, but now they’re huge farms producing crops for the international market.
“Of the forests that were here 1,000 years ago, 99 per cent have already gone,’ says botanist Oliver
Whaley from Kew Gardens in London, who, together with ethnobotanist Dr William Milliken,
is running a pioneering project to protect and restore the rapidly disappearing habitat. In order
to succeed, Whaley needs to get the local people on board, and that has meant overcoming local
prejudices. ‘Increasingly aspirational communities think that if you plant food trees in your home
or street, it shows you are poor, and still need to grow your own food,’ he says. In order to stop
the Middle Ica Valley going the same way as the Lower Ica Valley, Whaley is encouraging locals
to love the huarangos again. ‘It’s a process of cultural resuscitation,’ he says. He has already set
up a huarango festival to reinstate a sense of pride in their eco-heritage, and has helped local
schoolchildren plant thousands of trees.
80
```

[Original question page](assets/f928980a133defc3ba1726b07cfdae6ad9339e47ae12903277a5809251a2cc32.jpg)

<!-- Source: /api/assets/75c12f1b68d7da3538a91a3eb6e180cdb8a2e455a4875ba5ef13861856b349a1.jpg; PDF page 79; full -->

```text
Reading
‘In order to get people interested in habitat restoration, you need to plant a tree that is useful to
them,’ says Whaley. So, he has been working with local families to attempt to create a sustainable
income from the huarangos by turning their products into foodstuffs. ‘Boil up the beans and you
get this thick brown syrup like molasses. You can also use it in drinks, soups or stews.’ The pods
can be ground into flour to make cakes, and the seeds roasted into a sweet, chocolatey ‘coffee’.
“It’s packed full of vitamins and minerals,’ Whaley says.
And some farmers are already planting huarangos. Alberto Benevides, owner of Ica Valley’s only
certified organic farm, which Whaley helped set up, has been planting the tree for 13 years. He
produces syrup and flour, and sells these products at an organic farmers’ market in Lima. His
farm is relatively small and doesn’t yet provide him with enough to live on, but he hopes this
will change. ‘The organic market is growing rapidly in Peru,’ Benevides says. ‘I am investing in
the future.’
But even if Whaley can convince the local people to fall in love with the huarango again, there is
still the threat of the larger farms. Some of these cut across the forests and break up the corridors
that allow the essential movement of mammals, birds and pollen up and down the narrow forest
strip. In the hope of counteracting this, he’s persuading farmers to let him plant forest corridors
on their land. He believes the extra woodland will also benefit the farms by reducing their water
usage through a lowering of evaporation and providing a refuge for bio-control insects.
‘If we can record biodiversity and see how it all works, then we’re in a good position to move
on from there. Desert habitats can reduce down to very little,’ Whaley explains. ‘It’s not like a
rainforest that needs to have this huge expanse. Life has always been confined to corridors and
islands here. If you just have a few trees left, the population can grow up quickly because it’s
used to exploiting water when it arrives.’ He sees his project as a model that has the potential to
be rolled out across other arid areas around the world. ‘If we can do it here, in the most fragile
system on Earth, then that’s a real message of hope for lots of places, including Africa, where
there is drought and they just can’t afford to wait for rain.’
81
```

[Original question page](assets/75c12f1b68d7da3538a91a3eb6e180cdb8a2e455a4875ba5ef13861856b349a1.jpg)

<!-- Source: /api/assets/82ebc00d07800d245a29f12af6e7b78b96fcd9fdc1c9937c431e18cdb23ae897.jpg; PDF page 80; full -->

```text
Questions 1–5
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–5 on your answer sheet.
The importance of the huarango tree
– its roots can extend as far as 80 metres into the soil
– can access (1) __________ deep below the surface
– was a crucial part of local inhabitants’ (2) __________ a long time ago
– helped people to survive periods of (3) __________
– prevents (4) __________ of the soil
– prevents land from becoming a (5) __________
Questions 6–8
Complete the table below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 6–8 on your answer sheet.
Traditional uses of the huarango tree
| Part of tree | Traditional use |
| --- | --- |
| (6) __________ | fuel |
| (7) __________ and __________ | medicine |
| (8) __________ | construction |
```

[Original question page](assets/82ebc00d07800d245a29f12af6e7b78b96fcd9fdc1c9937c431e18cdb23ae897.jpg)

<!-- Source: /api/assets/f584ad11731e94afa73c41e301ea436b77dc9a2c8810fd57417dbea67909a1bb.jpg; PDF page 81; full -->

```text
Reading
Questions 9-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 9-13 on your answer sheet, write




TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
9 Local families have told Whaley about some traditional uses of huarango products.
10 Farmer Alberto Benevides is now making a good profit from growing huarangos.
11 Whaley needs the co-operation of farmers to help preserve the area's wildlife.
12 For Whaley’s project to succeed, it needs to be extended over a very large area.
13 Whaley has plans to go to Africa to set up a similar project.
>|O p. 126 83
```

[Original question page](assets/f584ad11731e94afa73c41e301ea436b77dc9a2c8810fd57417dbea67909a1bb.jpg)

<!-- Source: /api/assets/f17e849c8fe08d1c297b3f5ce43d7e6f4c92cdca58017004998ea0023b969abf.jpg; PDF page 82; full -->

```text
Test 4
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Silbo Gomero — the whistle ‘language’ of
the Canary Islands
La Gomera is one of the Canary Islands situated in the Atlantic Ocean off the northwest coast
of Africa. This small volcanic island is mountainous, with steep rocky slopes and deep, wooded
ravines, rising to 1,487 metres at its highest peak. It is also home to the best known of the world’s
whistle ‘languages’, a means of transmitting information over long distances which is perfectly
adapted to the extreme terrain of the island.
This ‘language’, known as ‘Silbo’ or ‘Silbo Gomero’ — from the Spanish word for ‘whistle’ —
is now shedding light on the language-processing abilities of the human brain, according to
scientists. Researchers say that Silbo activates parts of the brain normally associated with spoken
language, suggesting that the brain is remarkably flexible in its ability to interpret sounds as
language.
‘Science has developed the idea of brain areas that are dedicated to language, and we are starting
to understand the scope of signals that can be recognised as language,’ says David Corina,
co-author of a recent study and associate professor of psychology at the University of Washington
in Seattle.
Silbo is a substitute for Spanish, with individual words recoded into whistles which have high-
and low-frequency tones. A whistler — or silbador — puts a finger in his or her mouth to increase
the whistle’s pitch, while the other hand can be cupped to adjust the direction of the sound. ‘There
is much more ambiguity in the whistled signal than in the spoken signal,’ explains lead researcher
Manuel Carreiras, psychology professor at the University of La Laguna on the Canary island of
Tenerife. Because whistled ‘words’ can be hard to distinguish, silbadores rely on repetition, as
well as awareness of context, to make themselves understood.
The silbadores of Gomera are traditionally shepherds and other isolated mountain folk, and
their novel means of staying in touch allows them to communicate over distances of up to
10 kilometres. Carreiras explains that silbadores are able to pass a surprising amount of
information via their whistles. ‘In daily life they use whistles to communicate short commands,
but any Spanish sentence could be whistled.’ Silbo has proved particularly useful when fires have
occurred on the island and rapid communication across large areas has been vital.
84
```

[Original question page](assets/f17e849c8fe08d1c297b3f5ce43d7e6f4c92cdca58017004998ea0023b969abf.jpg)

<!-- Source: /api/assets/8a82ce877d47285d944e04ef4b91f5c0f4aaf3f3acae09f74dc1a68306990d49.jpg; PDF page 83; full -->

```text
Reading
The study team used neuroimaging equipment to contrast the brain activity of silbadores while
listening to whistled and spoken Spanish. Results showed the left temporal lobe of the brain,
which is usually associated with spoken language, was engaged during the processing of Silbo.
The researchers found that other key regions in the brain’s frontal lobe also responded to the
whistles, including those activated in response to sign language among deaf people. When the
experiments were repeated with non-whistlers, however, activation was observed in all areas of
the brain.
“Our results provide more evidence about the flexibility of human capacity for language in a
variety of forms,’ Corina says. ‘These data suggest that left-hemisphere language regions are
uniquely adapted for communicative purposes, independent of the modality of signal. The non-
Silbo speakers were not recognising Silbo as a language. They had nothing to grab onto, so
multiple areas of their brains were activated.’
Carreiras says the origins of Silbo Gomero remain obscure, but that indigenous Canary Islanders,
who were of North African origin, already had a whistled language when Spain conquered the
volcanic islands in the 15th century. Whistled languages survive today in Papua New Guinea,
Mexico, Vietnam, Guyana, China, Nepal, Senegal, and a few mountainous pockets in southern
Europe. There are thought to be as many as 70 whistled languages still in use, though only 12
have been described and studied scientifically. This form of communication is an adaptation
found among cultures where people are often isolated from each other, according to Julien
Meyer, a researcher at the Institute of Human Sciences in Lyon, France. ‘They are mostly used in
mountains or dense forests,’ he says. ‘Whistled languages are quite clearly defined and represent
an original adaptation of the spoken language for the needs of isolated human groups.’
But with modern communication technology now widely available, researchers say whistled
languages like Silbo are threatened with extinction. With dwindling numbers of Gomera islanders
still fluent in the language, Canaries’ authorities are taking steps to try to ensure its survival.
Since 1999, Silbo Gomero has been taught in all of the island’s elementary schools. In addition,
locals are seeking assistance from the United Nations Educational, Scientific and Cultural
Organization (UNESCO). ‘The local authorities are trying to get an award from the organisation
to declare [Silbo Gomero] as something that should be preserved for humanity,’ Carreiras adds.
85
```

[Original question page](assets/8a82ce877d47285d944e04ef4b91f5c0f4aaf3f3acae09f74dc1a68306990d49.jpg)

<!-- Source: /api/assets/0bc10c4639388d2d2a8d76234ea9bafa975bbba07317d9c27fb9585f5162c58a.jpg; PDF page 84; full -->

```text
Test 4
Questions 14-19
Do the following statements agree with the information given in Reading Passage 2?
In boxes 14-19 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
14 La Gomera is the most mountainous of all the Canary Islands.
15  Silbo is only appropriate for short and simple messages.
16 In the brain—activity study, silbadores and non-whistlers produced different results.
17 The Spanish introduced Silbo to the islands in the 15th century.
18 There is precise data available regarding all of the whistle languages in
existence today.
19 The children of Gomera now learn Silbo.
86
```

[Original question page](assets/0bc10c4639388d2d2a8d76234ea9bafa975bbba07317d9c27fb9585f5162c58a.jpg)

<!-- Source: /api/assets/4a961086d48714e50af04972cc93ed2afe5f78986ffe8b695e62a975e1b7ca12.jpg; PDF page 85; full -->

```text
Questions 20–26
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 20–26 on your answer sheet.
Silbo Gomero
How Silbo is produced
• high- and low-frequency tones represent different sounds in Spanish (20) __________
• pitch of whistle is controlled using silbador’s (21) __________
• (22) __________ is changed with a cupped hand
How Silbo is used
• has long been used by shepherds and people living in secluded locations
• in everyday use for the transmission of brief (23) __________
• can relay essential information quickly, e.g. to inform people about (24) __________
The future of Silbo
• future under threat because of new (25) __________
• Canaries’ authorities hoping to receive a UNESCO (26) __________ to help preserve it
```

[Original question page](assets/4a961086d48714e50af04972cc93ed2afe5f78986ffe8b695e62a975e1b7ca12.jpg)

<!-- Source: /api/assets/787c12256f388684e6b6228be7af6c2a4d0d4c1b5d342e8996ff31caf4eb49ac.jpg; PDF page 86; full -->

```text
Test 4
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Environmental practices of big businesses
The environmental practices of big businesses are shaped by a fundamental fact that for many of
us offends our sense of justice. Depending on the circumstances, a business may maximize the
amount of money it makes, at least in the short term, by damaging the environment and hurting
people. That is still the case today for fishermen in an unmanaged fishery without quotas, and for
international logging companies with short-term leases on tropical rainforest land in places with
corrupt officials and unsophisticated landowners. When government regulation is effective, and
when the public is environmentally aware, environmentally clean big businesses may out-compete
dirty ones, but the reverse is likely to be true if government regulation is ineffective and if the
public doesn’t care.
It is easy for the rest of us to blame a business for helping itself by hurting other people.
But blaming alone is unlikely to produce change. It ignores the fact that businesses are not
charities but profit-making companies, and that publicly owned companies with shareholders
are under obligation to those shareholders to maximize profits, provided that they do so by
legal means. US laws make a company’s directors legally liable for something termed “breach
of fiduciary responsibility’ if they knowingly manage a company in a way that reduces profits.
The car manufacturer Henry Ford was in fact successfully sued by shareholders in 1919 for
raising the minimum wage of his workers to $5 per day: the courts declared that, while Ford’s
humanitarian sentiments about his employees were nice, his business existed to make profits for
its stockholders.
Our blaming of businesses also ignores the ultimate responsibility of the public for creating the
conditions that let a business profit through destructive environmental policies. In the long run, it
is the public, either directly or through its politicians, that has the power to make such destructive
policies unprofitable and illegal, and to make sustainable environmental policies profitable.
The public can do that by suing businesses for harming them, as happened after the Exxon Valdez
disaster, in which over 40,000 m³ of oil were spilled off the coast of Alaska. The public may also
make their opinion felt by preferring to buy sustainably harvested products; by making employees
of companies with poor track records feel ashamed of their company and complain to their own
management; by preferring their governments to award valuable contracts to businesses with a
good environmental track record; and by pressing their governments to pass and enforce laws and
regulations requiring good environmental practices.
88
```

[Original question page](assets/787c12256f388684e6b6228be7af6c2a4d0d4c1b5d342e8996ff31caf4eb49ac.jpg)

<!-- Source: /api/assets/b665fc46ce19ee1999adf4ad7ab3a23b9701c5569aace01cdc0830a054f86296.jpg; PDF page 87; full -->

```text
Reading
In turn, big businesses can exert powerful pressure on any suppliers that might ignore public
or government pressure. For instance, after the US public became concerned about the spread
of a disease known as BSE, which was transmitted to humans through infected meat, the US
government’s Food and Drug Administration introduced rules demanding that the meat industry
abandon practices associated with the risk of the disease spreading. But for five years the meat
packers refused to follow these, claiming that they would be too expensive to obey. However,
when a major fast-food company then made the same demands after customer purchases of its
hamburgers plummeted, the meat industry complied within weeks. The public’s task is therefore
to identify which links in the supply chain are sensitive to public pressure: for instance, fast-food
chains or jewelry stores, but not meat packers or gold miners.
Some readers may be disappointed or outraged that I place the ultimate responsibility for business
practices harming the public on the public itself. I also believe that the public must accept the
necessity for higher prices for products to cover the added costs, if any, of sound environmental
practices. My views may seem to ignore the belief that businesses should act in accordance with
moral principles even if this leads to a reduction in their profits. But I think we have to recognize
that, throughout human history, in all politically complex human societies, government regulation
has arisen precisely because it was found that not only did moral principles need to be made
explicit, they also needed to be enforced.
To me, the conclusion that the public has the ultimate responsibility for the behavior of even the
biggest businesses is empowering and hopeful, rather than disappointing. My conclusion is not a
moralistic one about who is right or wrong, admirable or selfish, a good guy or a bad guy. In the
past, businesses have changed when the public came to expect and require different behavior, to
reward businesses for behavior that the public wanted, and to make things difficult for businesses
practicing behaviors that the public didn’t want. I predict that in the future, just as in the past,
changes in public attitudes will be essential for changes in businesses’ environmental practices.
89
```

[Original question page](assets/b665fc46ce19ee1999adf4ad7ab3a23b9701c5569aace01cdc0830a054f86296.jpg)

<!-- Source: /api/assets/0e239d2a5e07c76e3c0b077c8fc86e2ba1781584d11842cb3ef346c8aac6699f.jpg; PDF page 88; full -->

```text
Questions 27–31
Complete the summary using the list of words, A–J, below.
Write the correct letter, A–J, in boxes 27–31 on your answer sheet.
Big businesses
Many big businesses today are prepared to harm people and the environment in order to make money, and they appear to have no (27) __________. Lack of (28) __________ by governments and lack of public (29) __________ can lead to environmental problems such as (30) __________ or the destruction of (31) __________.
A funding
B trees
C rare species
D moral standards
E control
F involvement
G flooding
H overfishing
I worker support
[Source note: the instruction prints A–J, but the supplied source lists only A–I. No J option is supplied or invented.]
```

[Original question page](assets/0e239d2a5e07c76e3c0b077c8fc86e2ba1781584d11842cb3ef346c8aac6699f.jpg)

<!-- Source: /api/assets/bcdd0e08027ec58c179c74d2c95d90f82023e2084853082c754bd5f04c036326.jpg; PDF page 89; full -->

```text
Reading
Questions 32-34
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 32-34 on your answer sheet.
32 The main idea of the third paragraph is that environmental damage
A requires political action if it is to be stopped.
B is the result of ignorance on the part of the public.
C could be prevented by the action of ordinary people.
D canonly be stopped by educating business leaders.
33 In the fourth paragraph, the writer describes ways in which the public can
A reduce their own individual impact on the environment.
B learn more about the impact of business on the environment.
C raise awareness of the effects of specific environmental disasters.
D influence the environmental policies of businesses and governments.
34 What pressure was exerted by big business in the case of the disease BSE?
A Meat packers stopped supplying hamburgers to fast-food chains.
B A fast-food company forced their meat suppliers to follow the law.
C Meat packers persuaded the government to reduce their expenses.
D A fast-food company encouraged the government to introduce legislation.
91
```

[Original question page](assets/bcdd0e08027ec58c179c74d2c95d90f82023e2084853082c754bd5f04c036326.jpg)

<!-- Source: /api/assets/754b9294b328ab47836cae9c1c39acd8e11a8523ffb787fb277940014eae0dd2.jpg; PDF page 90; full -->

```text
Test 4
Questions 35-39
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 35-39 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
35 The public should be prepared to fund good environmental practices.
36 There is a contrast between the moral principles of different businesses.
37 It is important to make a clear distinction between acceptable and unacceptable
behaviour.
38 The public have successfully influenced businesses in the past.
39 In the future, businesses will show more concern for the environment.
Question 40
Choose the correct letter, A, B, C or D.
Write the correct letter in box 40 on your answer sheet.
40 What would be the best subheading for this passage?
A Will the world survive the threat caused by big businesses?
B How can big businesses be encouraged to be less driven by profit?
C What environmental dangers are caused by the greed of businesses?
D Are big businesses to blame for the damage they cause the environment?
92 >|@ p. 126
```

[Original question page](assets/754b9294b328ab47836cae9c1c39acd8e11a8523ffb787fb277940014eae0dd2.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/66df53873397150178cb678d78eed1e2c3d1ad47790bbaab45c15692717d4eb2.jpg; PDF page 91; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows what Anthropology graduates from one university did after finishing their undergraduate degree course. The table shows the salaries of the anthropologists in work after five years.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/66df53873397150178cb678d78eed1e2c3d1ad47790bbaab45c15692717d4eb2.jpg)

![Original figure](assets/66df53873397150178cb678d78eed1e2c3d1ad47790bbaab45c15692717d4eb2.jpg)

### Task 2

<!-- Source: /api/assets/8e7882b2569cb8cf6a58cdae19602169d0085f38b9102183a02422ef90a13ced.jpg; PDF page 92; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In some cultures, children are often told that they can achieve anything if they try hard enough.

What are the advantages and disadvantages of giving children this message?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/8e7882b2569cb8cf6a58cdae19602169d0085f38b9102183a02422ef90a13ced.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/4ac9eb5b5ccea7408a1f49bb411f51579de51b89236f37981c1f1ae7aff8addc.jpg; PDF page 93; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Jewellery
e How often do you wear jewellery? [Why/Why not?]
¢ What type of jewellery do you like best? [Why/Why not?]
e When do people like to give jewellery in your country [Why?]
e Have you ever given jewellery to someone as a gift? [Why/Why not?]
PART 2
Describe an interesting TV programme you watched about a science topic.
You should say:
what science topic this TV programme was about
when you saw this TV programme
what you learnt from this TV programme about a science topic
and explain why you found this TV programme interesting.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Science and the public
Example questions:
How interested are most people in your country in science?
Why do you think children today might be better at science than their parents?
How do you suggest the public can learn more about scientific developments?
Scientific discoveries
Example questions:
What do you think are the most important scientific discoveries in the last 100 years?
Do you agree or disagree that there are no more major scientific discoveries left to make?
Who should pay for scientific research — governments or private companies? 95
```

[Original question page](assets/4ac9eb5b5ccea7408a1f49bb411f51579de51b89236f37981c1f1ae7aff8addc.jpg)

### Part 2

<!-- Source: /api/assets/4ac9eb5b5ccea7408a1f49bb411f51579de51b89236f37981c1f1ae7aff8addc.jpg; PDF page 93; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Jewellery
e How often do you wear jewellery? [Why/Why not?]
¢ What type of jewellery do you like best? [Why/Why not?]
e When do people like to give jewellery in your country [Why?]
e Have you ever given jewellery to someone as a gift? [Why/Why not?]
PART 2
Describe an interesting TV programme you watched about a science topic.
You should say:
what science topic this TV programme was about
when you saw this TV programme
what you learnt from this TV programme about a science topic
and explain why you found this TV programme interesting.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Science and the public
Example questions:
How interested are most people in your country in science?
Why do you think children today might be better at science than their parents?
How do you suggest the public can learn more about scientific developments?
Scientific discoveries
Example questions:
What do you think are the most important scientific discoveries in the last 100 years?
Do you agree or disagree that there are no more major scientific discoveries left to make?
Who should pay for scientific research — governments or private companies? 95
```

[Original question page](assets/4ac9eb5b5ccea7408a1f49bb411f51579de51b89236f37981c1f1ae7aff8addc.jpg)

### Part 3

<!-- Source: /api/assets/4ac9eb5b5ccea7408a1f49bb411f51579de51b89236f37981c1f1ae7aff8addc.jpg; PDF page 93; full -->

```text
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Jewellery
e How often do you wear jewellery? [Why/Why not?]
¢ What type of jewellery do you like best? [Why/Why not?]
e When do people like to give jewellery in your country [Why?]
e Have you ever given jewellery to someone as a gift? [Why/Why not?]
PART 2
Describe an interesting TV programme you watched about a science topic.
You should say:
what science topic this TV programme was about
when you saw this TV programme
what you learnt from this TV programme about a science topic
and explain why you found this TV programme interesting.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Science and the public
Example questions:
How interested are most people in your country in science?
Why do you think children today might be better at science than their parents?
How do you suggest the public can learn more about scientific developments?
Scientific discoveries
Example questions:
What do you think are the most important scientific discoveries in the last 100 years?
Do you agree or disagree that there are no more major scientific discoveries left to make?
Who should pay for scientific research — governments or private companies? 95
```

[Original question page](assets/4ac9eb5b5ccea7408a1f49bb411f51579de51b89236f37981c1f1ae7aff8addc.jpg)
