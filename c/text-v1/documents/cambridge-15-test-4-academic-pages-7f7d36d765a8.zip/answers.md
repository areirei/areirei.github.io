# 剑雅 15 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 123

TEST 4 LISTENING
1 journalist
2 shopping
3 Staunfirth
4 return
5 23.70
6 online
7 delay
8 information
9 platform(s)
10 parking
11 D
12 C
13 G
14 H
15 A
16 E
17 A
18 D
19 A
20 C
21 B
22 A
23 B
24 A
25 A
26 A
27 B
28 B
29 A
30 C
31 wealth
32 technology
33 power
34 textile(s)
35 machines
36 newspapers
37 local
38 lighting
39 windows
40 advertising
17&18 IN EITHER ORDER: A,D
19&20 IN EITHER ORDER: A,C
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. journalist

2. shopping

3. Staunfirth

4. return

5. 23.70 / 23:70

6. online

7. delay

8. information

9. platform / platforms

10. parking

### Part 2 · source page 123

TEST 4 LISTENING
1 journalist
2 shopping
3 Staunfirth
4 return
5 23.70
6 online
7 delay
8 information
9 platform(s)
10 parking
11 D
12 C
13 G
14 H
15 A
16 E
17 A
18 D
19 A
20 C
21 B
22 A
23 B
24 A
25 A
26 A
27 B
28 B
29 A
30 C
31 wealth
32 technology
33 power
34 textile(s)
35 machines
36 newspapers
37 local
38 lighting
39 windows
40 advertising
17&18 IN EITHER ORDER: A,D
19&20 IN EITHER ORDER: A,C
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. D

12. C

13. G

14. H

15. A

16. E

17. A / D

18. A / D

19. A / C

20. A / C

### Part 3 · source page 123

TEST 4 LISTENING
1 journalist
2 shopping
3 Staunfirth
4 return
5 23.70
6 online
7 delay
8 information
9 platform(s)
10 parking
11 D
12 C
13 G
14 H
15 A
16 E
17 A
18 D
19 A
20 C
21 B
22 A
23 B
24 A
25 A
26 A
27 B
28 B
29 A
30 C
31 wealth
32 technology
33 power
34 textile(s)
35 machines
36 newspapers
37 local
38 lighting
39 windows
40 advertising
17&18 IN EITHER ORDER: A,D
19&20 IN EITHER ORDER: A,C
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B

22. A

23. B

24. A

25. A

26. A

27. B

28. B

29. A

30. C

### Part 4 · source page 123

TEST 4 LISTENING
1 journalist
2 shopping
3 Staunfirth
4 return
5 23.70
6 online
7 delay
8 information
9 platform(s)
10 parking
11 D
12 C
13 G
14 H
15 A
16 E
17 A
18 D
19 A
20 C
21 B
22 A
23 B
24 A
25 A
26 A
27 B
28 B
29 A
30 C
31 wealth
32 technology
33 power
34 textile(s)
35 machines
36 newspapers
37 local
38 lighting
39 windows
40 advertising
17&18 IN EITHER ORDER: A,D
19&20 IN EITHER ORDER: A,C
If you score: 0–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. wealth

32. technology

33. power

34. textile / textiles

35. machines

36. newspapers

37. local

38. lighting

39. windows

40. Advertising

## A 类阅读

### Academic Reading · source page 124

TEST 4 READING
1 water
2 diet
3 drought
4 erosion
5 desert
6 (its / huarango / the) branches
7 leaves (and) bark
8 (its / huarango / the) trunk
9 NOT GIVEN
10 FALSE
11 TRUE
12 FALSE
13 NOT GIVEN
14 NOT GIVEN
15 FALSE
16 TRUE
17 FALSE
18 FALSE
19 TRUE
20 words
21 finger
22 direction
23 commands
24 fires
25 technology
26 award
27 D
28 E
29 F
30 H
31 B
32 C
33 D
34 B
35 YES
36 NOT GIVEN
37 NO
38 YES
39 NOT GIVEN
40 D
7 IN EITHER ORDER (BOTH REQUIRED FOR ONE MARK): leaves (and) bark
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. water

2. diet

3. drought

4. erosion

5. desert

6. branches / its branches / huarango branches / the branches

7. leaves bark / leaves, bark / leaves and bark / leaves & bark / leaves; bark / leaves/bark / leaves,bark / bark leaves / bark, leaves / bark and leaves / bark & leaves / bark; leaves / bark/leaves / bark,leaves

8. trunk / its trunk / huarango trunk / the trunk

9. NOT GIVEN

10. FALSE

11. TRUE

12. FALSE

13. NOT GIVEN

14. NOT GIVEN

15. FALSE

16. TRUE

17. FALSE

18. FALSE

19. TRUE

20. words

21. finger

22. direction

23. commands

24. fires

25. technology

26. award

27. D

28. E

29. F

30. H

31. B

32. C

33. D

34. B

35. YES

36. NOT GIVEN

37. NO

38. YES

39. NOT GIVEN

40. D

## A 类写作

### Writing material: c15-t4-w-1

ONE university Anthropology graduates: full-time work52%,part-time15%,part-time work plus postgraduate study5%,full-time postgraduate study8%,unemployed12%,not known8%. Salary table AFTER FIVE YEARS of work, bands$25,000–49,999/$50,000–74,999/$75,000–99,999/$100,000+: freelance consultants5/15/40/40%; government sector5/15/30/50%; private companies10/35/25/30%. Rows each100%; not percentages of all initial graduates. Government has highest top-band share50%; freelancers/government each80%earn at least75k versus55%private. No year or employer group sizes supplied; do not infer counts.



### Writing material: c15-t4-w-2

Discuss both advantages and disadvantages of giving children this message. Unlike an outweigh task, no explicit weighing judgement required; retain the absolute anything claim.



## 口语
