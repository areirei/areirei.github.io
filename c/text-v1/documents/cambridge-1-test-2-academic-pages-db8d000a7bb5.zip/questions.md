# 剑雅 1 · Test 2

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/4a48829d32f4428b5c5dd51de201d87406a01b784d5af6dcc443e96c12de066d.jpg; PDF page 40; full -->

```text
Practice Test 2 — LISTENING
SECTION 1 Questions 1–10
Complete the notes. Use NO MORE THAN THREE WORDS for each answer.
KATE
Her first impressions of the town | Quiet [Example]
Type of accommodation | (1) __________
Her feelings about the accommodation | (2) __________
Her feelings about the other students | (3) __________
Name of course | Environmental Studies
Difficulties experienced on the course | (4) __________
Suggestions for improving the course | (5) __________
LUKI
First type of accommodation | (6) __________
Problem with the first accommodation | (7) __________
Second type of accommodation | (8) __________
Name of course | (9) __________
Comments about the course | Computer room busy
Suggestions for improving the course | (10) __________
```

[Original question page](assets/4a48829d32f4428b5c5dd51de201d87406a01b784d5af6dcc443e96c12de066d.jpg)

### Part 2

<!-- Source: /api/assets/3337665542cfc5acc6063c1e6668695f7391367f6a9d429b194dbe8f4d2aede1.jpg; PDF page 41; full -->

```text
35
SECTION 2    Questions 11-20
Complete the notes below. Use NO MORE THAN  THREE WORDS for each  answer.
There are many kinds of bicycles available:
racing
touring
(11) ..............................................
ordinary
They vary in price and (12) ................................................ .
Prices range from $50.00 to (13) ......................................... .
Single speed cycles are suitable for (14) ................................ .
Three speed cycles are suitable for (15) ................................. .
Five and ten speed cycles are suitable for longer distances, hills
and (16) ............................................. .
Ten speed bikes are better because they are (17) ............................ in
price but (18) ...................................... .
Buying a cycle is like (19) ................................. .
The size of the bicycle is determined by the size of
 the (20) ............................................. .
Listening
```

[Original question page](assets/3337665542cfc5acc6063c1e6668695f7391367f6a9d429b194dbe8f4d2aede1.jpg)

![Original figure](assets/3337665542cfc5acc6063c1e6668695f7391367f6a9d429b194dbe8f4d2aede1.jpg)

### Part 3

<!-- Source: /api/assets/d2c612f0dafae5eeea9377b61bd665447cee3271d0ebe88e000fc449a598af5b.jpg; PDF page 42; full -->

```text
36
Practice Test 2
SECTION 3     Questions 21-32
Questions 21-24
Circle the correct answer.
21 At first Fiona thinks that Martin’s tutorial topic is
A inappropriate.
B dull.
C interesting.
D fascinating.
22 According to Martin, the banana
A has only recently been cultivated.
B   is economical to grow.
C   is good for your health.
D   is his favourite food.
23 Fiona listens to Martin because she
A wants to know more about bananas.
B has nothing else to do today.
C is interested in the economy of Australia.
D wants to help Martin.
24 According to Martin, bananas were introduced into Australia from
A India.
B England.
C China.
D Africa.
```

[Original question page](assets/d2c612f0dafae5eeea9377b61bd665447cee3271d0ebe88e000fc449a598af5b.jpg)

<!-- Source: /api/assets/2c1c5997a84786764669374d52d9c366edba7c58d56ab1261179cd4b48318b39.jpg; PDF page 43; full -->

```text
37
Listening
Questions 25-30
Complete Martin’s notes Use NO MORE THAN THREE WORDS for each answer.
Commercially grown
banana plant
Each banana tree produces
(25) .......................................................
of bananas.
On modern plantations in tropical
conditions a tree can bear fruit after
(26) ............................................ .
Banana trees prefer to grow (27) .........................................  and they require
rich soil and (28) ..................................... . The fruit is often protected by
(29) ............................................... .
Ripe bananas emit a gas which helps other (30) .......................................... .
Questions 31 and 32
Circle the TWO correct boxes.
Consumption of Australian bananas
A Europe
B Asia
C New Zealand
D Australia
E Other
```

[Original question page](assets/2c1c5997a84786764669374d52d9c366edba7c58d56ab1261179cd4b48318b39.jpg)

![Original figure](assets/2c1c5997a84786764669374d52d9c366edba7c58d56ab1261179cd4b48318b39.jpg)

### Part 4

<!-- Source: /api/assets/3709b9950d5c2c71731e1d00568bde3cdf5a29db5caec09153cf6734c5ea0032.jpg; PDF page 44; full -->

```text
Practice Test 2
SECTION 4 Questions 33–41
Questions 33–35
Circle the correct answer.
According to the first speaker:
33 The focus of the lecture series is on
A organising work and study.
B maintaining a healthy lifestyle.
C coping with homesickness.
D settling in at university.
34 The lecture will be given by
A the president of the Union.
B the campus doctor.
C a sports celebrity.
D a health expert.
According to the second speaker:
35 This week’s lecture is on
A campus food.
B dieting.
C sensible eating.
D saving money.
Questions 36–39
Complete the notes. Write NO MORE THAN THREE WORDS for each answer.
A balanced diet
A balanced diet will give you enough vitamins for normal daily living.
Vitamins in food can be lost through (36) __________.
Types of vitamins:
(a) Fat soluble vitamins are stored by the body.
(b) Water soluble vitamins — not stored, so you need a (37) __________.
Getting enough vitamins
Eat (38) __________ of foods.
Buy plenty of vegetables and store them in (39) __________.
```

[Original question page](assets/3709b9950d5c2c71731e1d00568bde3cdf5a29db5caec09153cf6734c5ea0032.jpg)

<!-- Source: /api/assets/3fce5aa0d1d42d74727f016828b31943b6540d0b84da75ed6fe60ddccde5bfc9.jpg; PDF page 45; full -->

```text
Listening
Questions 40–41
Complete the diagram by writing NO MORE THAN THREE WORDS in the boxes provided.
Food pyramid (original diagram retained below):
Top tier: Try to avoid [Example] — sugar, salt and butter
Middle tier: (40) __________ — milk, lean meat, fish, nuts, eggs
Bottom tier: (41) __________ — bread, vegetables and fruit
```

[Original question page](assets/3fce5aa0d1d42d74727f016828b31943b6540d0b84da75ed6fe60ddccde5bfc9.jpg)

![Original figure](assets/3fce5aa0d1d42d74727f016828b31943b6540d0b84da75ed6fe60ddccde5bfc9.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/5c251bce3f923498de2bdee9b2f1ae7f9b40a4b424159fcf0d55a04e5c3a6aa3.jpg; PDF page 46; full -->

```text
40
Practice Test 2
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-12 which are based on Reading Passage 1
below.
Right and left-handedness in humans
Why do humans, virtually alone among all
animal species, display a distinct left or
right-handedness? Not even our closest
relatives among the apes possess such
decided lateral asymmetry, as psychologists
call it. Yet about 90 per cent of every human
population that has ever lived appears to
have been right-handed. Professor Bryan
Turner at Deakin University has studied the
research literature on left-handedness and
found that handedness goes with sidedness.
So nine out of ten people are right-handed
and eight are right-footed. He noted that this
distinctive asymmetry in the human
population is itself systematic. “Humans
think in categories: black and white, up and
down, left and right. It’s a system of signs
that enables us to categorise phenomena that
are essentially ambiguous.’
Research has shown that there is a genetic
or inherited element to handedness. But
while left-handedness tends to run in
families, neither left nor right handers will
automatically produce off-spring with the
same handedness; in fact about 6 per cent
of children with two right-handed parents
will be left-handed. However, among two
left-handed parents, perhaps 40 per cent of
the children will also be left-handed. With
one right and one left-handed parent, 15 to
20 per cent of the offspring will be left-
handed. Even among identical twins who
have exactly the same genes, one in six pairs
will differ in their handedness.
What then makes people left-handed if it is
not simply genetic? Other factors must be
at work and researchers have turned to the
brain for clues. In the 1860s the French
surgeon and anthropologist, Dr Paul Broca,
made the remarkable finding that patients
who had lost their powers of speech as a
result of a stroke (a blood clot in the brain)
had paralysis of the right half of their body.
He noted that since the left hemisphere of
the brain controls the right half of the body,
and vice versa, the brain damage must have
been in the brain’s left hemisphere.
Psychologists now believe that among
right-handed people, probably 95 per cent
have their language centre in the left
hemisphere, while 5 per cent have right-
sided language. Left-handers, however, do
not show the reverse pattern but instead a
majority also have their language in the left
hemisphere. Some 30 per cent have right
hemisphere language.
Dr Brinkman, a brain researcher at the
Australian National University in Canberra,
has suggested that evolution of speech went
with right-handed preference. According to
Brinkman, as the brain evolved, one side
```

[Original question page](assets/5c251bce3f923498de2bdee9b2f1ae7f9b40a4b424159fcf0d55a04e5c3a6aa3.jpg)

<!-- Source: /api/assets/e5ef0f2455a402288a3ee5eb00baacafebebeaf1f1974477ddfe1e5471329678.jpg; PDF page 47; full -->

```text
41
Reading
became specialised for fine control of
movement (necessary for producing speech)
and along with this evolution came right-
hand preference. According to Brinkman,
most left-handers have left hemisphere
dominance but also some capacity in the
right hemisphere. She has observed that if a
left-handed person is brain-damaged in the
left hemisphere, the recovery of speech is
quite often better and this is explained by
the fact that left-handers have a more
bilateral speech function.
In her studies of macaque monkeys,
Brinkman has noticed that primates
(monkeys) seem to learn a hand preference
from their mother in the first year of life but
this could be one hand or the other. In
humans, however, the specialisation in
(unction of the two hemispheres results in
anatomical differences: areas that are
involved with the production of speech are
usually larger on the left side than on the
right. Since monkeys have not acquired the
art of speech, one would not expect to see
such a variation but Brinkman claims to have
discovered a trend in monkeys towards the
asymmetry that is evident in the human
brain.
Two American researchers, Geschwind and
Galaburda, studied the brains of human
embryos and discovered that the left-right
asymmetry exists before birth. But as the
brain develops, a number of things can affect
it. Every brain is initially female in its
organisation and it only becomes a male
brain when the male foetus begins to secrete
hormones. Geschwind and Galaburda knew
that different parts of the brain mature at
different rates; the right hemisphere
develops first, then the left. Moreover, a
girl’s brain develops somewhat faster than
that of a boy. So, if something happens to
the brain’s development during pregnancy,
it is more likely to be affected in a male
and the hemisphere more likely to be
involved is the left. The brain may become
less lateralised and this in turn could result
in left-handedness and the development of
certain superior skills that have their origins
in the left hemisphere such as logic,
rationality and abstraction. It should be no
surprise then that among mathematicians
and architects, left-handers tend to be more
common and there are more left-handed
males than females.
The results of this research may be some
consolation to left-handers who have for
centuries lived in a world designed to suit
right-handed people. However, what is
alarming, according to Mr. Charles Moore,
a writer and journalist, is the way the word
“right” reinforces its own virtue.
Subliminally he says, language tells people
to think that anything on the right can be
trusted while anything on the left is
dangerous or even sinister. We speak of left-
handed compliments and according to
Moore, “it is no coincidence that left-
handed children, forced to use their right
hand, often develop a stammer as they are
robbed of their freedom of speech”.
However, as more research is undertaken
on the causes of left-handedness, attitudes
towards left-handed people are gradually
changing for the better. Indeed when the
champion tennis player Ivan Lendl was
asked what the single thing was that he
would choose in order to improve his game,
he said he would like to become a left-
hander.
Geoff  Maslen
```

[Original question page](assets/e5ef0f2455a402288a3ee5eb00baacafebebeaf1f1974477ddfe1e5471329678.jpg)

<!-- Source: /api/assets/cae0f187bf1bb11af963f3ba9ba789d1dc5f526b4026b55a8633b5bcbf06f484.jpg; PDF page 48; full -->

```text
42
Practice Test 2
Questions 1-7
Use the information in the text to match the people (listed A-E) with the opinions (listed
1-7) below. Write the appropriate letter (A-E) in boxes 1-7 on your answer sheet. Some
people match more than one opinion.
People:
A Dr Broca
B Dr Brinkman
C Geschwind and Galaburda
D Charles Moore
E Professor Turner

1 Human beings started to show a preference for right-handedness when they first
developed language.
2 Society is prejudiced against left-handed people.
3 Boys are more likely to be left-handed.
4 After a stroke, left-handed people recover their speech more quickly than right-
handed people.
5 People who suffer strokes on the left side of the brain usually lose their power of
speech.
6 The two sides of the brain develop different functions before birth.
7 Asymmetry is a common feature of the human body.
Example Answer
Monkeys do not show a species specific preference for
left or right-handedness. B
```

[Original question page](assets/cae0f187bf1bb11af963f3ba9ba789d1dc5f526b4026b55a8633b5bcbf06f484.jpg)

<!-- Source: /api/assets/7837ef11d2b888b87efc72de2ed1f46c31decd3bae62488f3d1d25f4665e12c9.jpg; PDF page 49; full -->

```text
Reading
Questions 8–10
Using the information in the passage, complete the table below. Write your answers in boxes 8–10 on your answer sheet.
Parents | Percentage of children left-handed
One parent left-handed, one parent right-handed | (8) __________
Both parents left-handed | (9) __________
Both parents right-handed | (10) __________

Questions 11–12
Choose the appropriate letters A-D and write them in boxes 11 and 12 on your answer sheet.
11 A study of monkeys has shown that
A monkeys are not usually right-handed.
B monkeys display a capacity for speech.
C monkey brains are smaller than human brains.
D monkey brains are asymmetric.
12 According to the writer, left-handed people
A will often develop a stammer.
B have undergone hardship for years.
C are untrustworthy.
D are good tennis players.

```

[Original question page](assets/7837ef11d2b888b87efc72de2ed1f46c31decd3bae62488f3d1d25f4665e12c9.jpg)

<!-- Source: /api/assets/549ce91205f8219bcbad1432a469395c4ec781202c549edb03798a35b7be111b.jpg; PDF page 50; full -->

```text
44
Practice Test 2
READING PASSAGE 2
You should spend about 20 minutes on Questions 13-27 which are based on Reading Passage
2 below.
MIGRATORY BEEKEEPING
Taking Wing
To eke out a full-time living from their
honeybees, about half the nation’s 2,000
commercial beekeepers pull up stakes
each spring, migrating north to find more
flowers for their bees. Besides turning
floral nectar into honey, these
hardworking insects also pollinate crops
for farmers -for a fee. As autumn
approaches, the beekeepers pack up their
hives and go south, scrambling for
pollination contracts in hot spots like
California’s fertile Central Valley.
Of the 2,000 commercial beekeepers in the
United States about half migrate This pays
off in two ways Moving north in the summer
and south in the winter lets bees work a longer
blooming season, making more honey — and
money — for their keepers. Second,
beekeepers can carry their hives to farmers
who need bees to pollinate their crops. Every
spring a migratory beekeeper in California
may move up to 160 million bees to
```

[Original question page](assets/549ce91205f8219bcbad1432a469395c4ec781202c549edb03798a35b7be111b.jpg)

![Original figure](assets/549ce91205f8219bcbad1432a469395c4ec781202c549edb03798a35b7be111b.jpg)

<!-- Source: /api/assets/31a714fb1547ada6ffd27b19ed1a841f225fd00e6f32b0e4314a9939a85b551e.jpg; PDF page 51; full -->

```text
45
Reading
flowering fields in Minnesota and every
winter his family may haul the hives back to
California, where farmers will rent the bees
to pollinate almond and cherry trees.
Migratory beekeeping is nothing new. The
ancient Egyptians moved clay hives,
probably on rafts, down the Nile to follow
the bloom and nectar flow as it moved toward
Cairo. In the 1880s North American
beekeepers experimented with the same idea,
moving bees on barges along the Mississippi
and on waterways in Florida, but their lighter,
wooden hives kept falling into the water.
Other keepers tried the railroad and horse-
drawn wagons, but that didn’t prove practical.
Not until the 1920s when cars and trucks
became affordable and roads improved, did
migratory beekeeping begin to catch on.
For the Californian beekeeper, the pollination
season begins in February. At this time, the
beehives are in particular demand by farmers
who have almond groves; they need two
hives an acre. For the three-week long bloom,
beekeepers can hire out their hives for $32
each. It’s a bonanza for the bees too. Most
people consider almond honey too bitter to
eat so the bees get to keep it for themselves.
By early March it is time to move the bees.
It can take up to seven nights to pack the
4,000 or so hives that a beekeeper may own.
These are not moved in the middle of the day
because too many of the bees would end up
homeless. But at night, the hives are stacked
onto wooden pallets, back-to-back in sets of
four, and lifted onto a truck. It is not necessary
to wear gloves or a beekeeper’s veil because
the hives are not being opened and the bees
should remain relatively quiet. Just in case
some are still lively, bees can be pacified with
a few puffs of smoke blown into each hive’s
narrow entrance.
In their new location, the beekeeper will pay
the farmer to allow his bees to feed in such
places as orange groves. The honey produced
here is fragrant and sweet and can be sold by
the beekeepers. To encourage the bees to
produce as much honey as possible during
this period, the beekeepers open the hives
and stack extra boxes called supers on top.
These temporary hive extensions contain
frames of empty comb for the bees to fill
with honey. In the brood chamber below, the
bees will stash honey to eat later. To prevent
the queen from crawling up to the top and
laying eggs, a screen can be inserted
between the brood chamber and the supers.
Three weeks later the honey can be gathered.
Foul smelling chemicals are often used to
irritate the bees and drive them down into
the hive’s bottom boxes, leaving the honey-
filled supers more or less bee free. These
can then be pulled off the hive. They are
heavy with honey and may weigh up to 90
pounds each. The supers are taken to a
warehouse. In the extracting room, the
frames are lifted out and lowered into an
“uncapper” where rotating blades shave
away the wax that covers each cell. The
uncapped frames are put in a carousel that
sits on the bottom of a large stainless steel
drum. The carousel is filled to capacity with
72 frames. A switch is flipped and the frames
begin to whirl at 300 revolutions per minute;
centrifugal force throws the honey out of
the combs. Finally the honey is poured into
barrels for shipment.
After this, approximately a quarter of the
hives weakened by disease, mites, or an
ageing or dead queen, will have to be
replaced. To create new colonies, a healthy
double hive, teeming with bees, can be
separated into two boxes. One half will hold
the queen and a young, already mated queen
can be put in the other half, to make two
hives from one. By the time the flowers
bloom, the new queens will be laying eggs,
filling each hive with young worker bees.
The beekeeper’s family will then migrate
with them to their summer location.
Adapted from “America's Beekeepers:
Hives for Hire” by Alan Mairson,
National Geographic.
```

[Original question page](assets/31a714fb1547ada6ffd27b19ed1a841f225fd00e6f32b0e4314a9939a85b551e.jpg)

<!-- Source: /api/assets/78b475628c8a05212adfbb9a9d2b791713723dbda0ec3ab683aab3f1d54996c8.jpg; PDF page 52; full -->

```text
Practice Test 2
Questions 13–19
The flow chart below outlines the movements of the migratory beekeeper as described in Reading Passage 2.
Complete the flow chart. Choose your answers from the box at the bottom of the page and write your answers in boxes 13–19 on your answer sheet.
BEEKEEPER MOVEMENTS
Example: In February, Californian farmers hire bees to help pollinate almond trees. [Answer: pollinate]
↓
In March, beekeepers (13) __________ for migration at night when the hives are (14) __________ and the bees are generally tranquil. A little (15) __________ can ensure that this is the case.
↓
They transport their hives to orange groves where farmers (16) __________ beekeepers for placing them on their land. Here the bees make honey.
↓
After three weeks, the supers can be taken to a warehouse where (17) __________ are used to remove the wax and extract the honey from the (18) __________.
↓
After the honey collection, the old hives are rejected. Good double hives are (19) __________ and re-queened and the beekeeper transports them to their summer base.
List of Words/Phrases (original row order)
smoke | chemicals | pay
barrels | protection | charge
set off | light | split
pollinate | machines | supers
combs | screen | prepare
full | empty | queens
```

[Original question page](assets/78b475628c8a05212adfbb9a9d2b791713723dbda0ec3ab683aab3f1d54996c8.jpg)

<!-- Source: /api/assets/55ffe571f670ed003c2752e5061f59c1f1584eaa5ff41d6358259550eb047d69.jpg; PDF page 53; full -->

```text
47
Reading
Questions 20-23
Label the diagram below Choose ONE OR TWO WORDS from the Reading Passage for
each answer Write your answers in boxes 20-23 on your answer sheet.
A BEEHIVE
[Label positions (20), (21), (22), (23) are shown on the retained original diagram; do not replace labels with answers.]
Questions 24-27
Do the following statements agree with the information given in Reading Passage 2? In boxes
24-27 write.
YES if the statement agrees with the information given
NO if the statement contradicts the information given
NOT GIVEN if there is no information about this
24  The Egyptians keep bees on the banks of the Nile.
25  First attempts at migratory beekeeping in America were unsuccessful.
26  Bees keep honey for themselves in the bottom of the hive.
27  The honey is spun to make it liquid.
```

[Original question page](assets/55ffe571f670ed003c2752e5061f59c1f1584eaa5ff41d6358259550eb047d69.jpg)

![Original figure](assets/55ffe571f670ed003c2752e5061f59c1f1584eaa5ff41d6358259550eb047d69.jpg)

<!-- Source: /api/assets/d256217cf02e87f0040bb5d3a0f66620bed05dcad4a1469e0119cea507c36835.jpg; PDF page 54; full -->

```text
48
Practice Test 2
READING PASSAGE 3
You should spend about 20 minutes on Questions 28-41 which are based on Reading Passage
3 below.
TOURISM
A Tourism, holidaymaking and travel are these
days more significant social phenomena
than most commentators have considered
On the face of it there could not be a more
trivial subject for a book And indeed since
social scientists have had considerable
difficulty explaining weightier topics such as
work or politics it might be thought that they
would have great difficulties in accounting
for more trivial phenomena such as
holidaymaking However there are
interesting parallels with the study of
deviance This involves the investigation of
bizarre and idiosyncratic social practices
which happen to be defined as deviant in
some societies but not necessarily in others
The assumption is that the investigation of
deviance can reveal interesting and
significant aspects of normal societies It
could be said that a similar analysis can be
applied to tourism
B Tourism is a leisure activity which
presupposes its opposite namely regulated
and organised work It is one manifestation
of how work and leisure are organised as
separate and regulated spheres of social
practice in modern societies Indeed acting
as a tourist is one of the defining
characteristics of being modern’ and the
popular concept of tourism is that it is
organised within particular places and
occurs for regularised periods of time Tourist
relationships arise from a movement of
people to and their stay in various
destinations This necessarily involves some
movement that is the journey and a period
of stay in a new place or places The journey
and the stay are by definition outside the
normal places of residence and work and
are of a short term and temporary nature
and there is a clear intention to return
“home within a relatively short period of time
C  A substantial proportion of the population of
modern societies engages in such tourist
practices new socialised forms of provision
have developed in order to cope with the
mass character of the gazes of tourists as
opposed to the individual character of
travel Places are chosen to be visited and
be gazed upon because there is an
anticipation especially through
daydreaming and fantasy of intense
pleasures, either on a different scale or
involving different senses from those
customarily encountered Such anticipation
is constructed and sustained through a
variety of non-tourist practices such as
films TV literature, magazines records and
videos which construct and reinforce this
daydreaming
D Tourists tend to visit features of landscape
and townscape which separate them off
from everyday experience Such aspects
are viewed because they are taken to be in
some sense out of the ordinary The
viewing of these tourist sights often
involves different forms of social patterning
with a much greater sensitivity to visual
elements of landscape or townscape than
is normally found in everyday life People
linger over these sights in a way that they
would not normally do in their home
environment and the vision is objectified or
captured through photographs postcards
films and so on which enable the memory
to be endlessly reproduced and recaptured
E One of the earliest dissertations on the
subject of tourism is Boorstins analysis of
the pseudo event (1964) where he argues
that contemporary Americans cannot
experience reality directly but thrive on
pseudo events Isolated from the host
environment and the local people the
mass tourist travels in guided groups and
finds pleasure in inauthentic contrived
attractions gullibly enjoying the pseudo
events and disregarding the real world
outside Over time the images generated
of different tourist sights come to
constitute a closed self-perpetuating
system of illusions which provide the
tourist with the basis for selecting and
```

[Original question page](assets/d256217cf02e87f0040bb5d3a0f66620bed05dcad4a1469e0119cea507c36835.jpg)

<!-- Source: /api/assets/36f1083cad133fb65f8f4c65e30e703cd1fd13022c82fff4b3cb99638d051bdc.jpg; PDF page 55; full -->

```text
49
Reading
evaluating potential places to visit Such
visits are made says Boorstin, within the
environmental bubble of the familiar
American style hotel which insulates the
tourist from the strangeness of the host
environment
F To service the burgeoning tourist industry,
an array of professionals has developed
who attempt to reproduce ever-new objects
for the tourist to look at These objects or
places are located in a complex and
changing hierarchy This depends upon the
interplay between, on the one hand,
competition between interests involved in
the provision of such objects and, on the
other hand changing class, gender, and
generational distinctions of taste within the
potential population of visitors It has been
said that to be a tourist is one of the
characteristics of the modern experience
Not to go away is like not possessing a car
or a nice house Travel is a marker of status
in modern societies and is also thought to
be necessary for good health The role of
the professional, therefore, is to cater for
the needs and tastes of the tourists in
accordance with their class and overall
expectations
Questions 28-32
Reading Passage 3 has 6 paragraphs (A-F) Choose the most suitable heading for each
paragraph from the list of headings below Write the appropriate numbers (i-ix) in boxes 28–32 on your answer sheet Paragraph D has been done for you as an example.
NB There are more headings than paragraphs so you will not use all of them You may use any
heading more than once.
List of Headings
i The politics of tourism
ii The cost of tourism
iii Justifying the study of tourism
iv Tourism contrasted with travel
v The essence of modern tourism
vi Tourism versus leisure
vii The artificiality of modern tourism
viii The role of modern tour guides
ix Creating an alternative to the everyday experience
28 Paragraph A
29 Paragraph B
30 Paragraph C
Example Answer
Paragraph D ix
31 Paragraph E
32 Paragraph F
```

[Original question page](assets/36f1083cad133fb65f8f4c65e30e703cd1fd13022c82fff4b3cb99638d051bdc.jpg)

<!-- Source: /api/assets/0dc148fd0a11a3397b2db42e5bae5a0b50990f975e0389545de22c118af4e808.jpg; PDF page 56; full -->

```text
50
Practice Test 2
Example Answer
People who can’t afford to travel watch films and TV .      NOT GIVEN
Questions 33-37
Do the following statements agree with the views of the writer in Reading Passage 3? In
boxes 33-37 write
YES if the statement agrees with the writer
 NO  if the statement contradicts the writer
NOT GIVEN  if it is impossible to say what the writer thinks about this
33 Tourism is a trivial subject.
34 An analysis of deviance can act as a model for the analysis of tourism.
35 Tourists usually choose to travel overseas.
36 Tourists focus more on places they visit than those at home.
37 Tour operators try to cheat tourists.
Questions 38-41
Chose one phrase (A-H) from the list of phrases to complete each key point below. Write the
appropriate letters (A-H) in boxes 38-41 on your answer sheet.
The information in the completed sentences should be an accurate summary of points made
by the writer.
NB There are more phrases A-H than sentences so you will not use them all. You may use any
phrase more than once.
38 Our concept of tourism arises from ...
39 The media can be used to enhance ...
40 People view tourist landscapes in a different way from ...
41 Group tours encourage participants to look at ...
List of Phrases
A local people and their environment.
B the expectations of tourists.
C the phenomena of holidaymaking.
D the distinction we make between work and leisure.
E the individual character of travel.
F places seen in everyday life.
G photographs which recapture our holidays.
H sights designed specially for tourists.
```

[Original question page](assets/0dc148fd0a11a3397b2db42e5bae5a0b50990f975e0389545de22c118af4e808.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/39f88cdb10950efcd091c6759fc4507bee44257f829ef20a03908dfde2326f79.jpg; PDF page 57; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagram below shows how the Australian Bureau of Meteorology collects up-to-the-minute information on the weather in order to produce reliable forecasts.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

The original figure is retained for the plotted values, labels, arrows and spatial layout.
```

[Original question page](assets/39f88cdb10950efcd091c6759fc4507bee44257f829ef20a03908dfde2326f79.jpg)

![Original figure](assets/39f88cdb10950efcd091c6759fc4507bee44257f829ef20a03908dfde2326f79.jpg)

### Task 2

<!-- Source: /api/assets/9470f0268633cd20d73dc7258f9b5f2a09978f2565b71549271e4a4772d33c3b.jpg; PDF page 58; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic.

Should wealthy nations be required to share their wealth among poorer nations by providing such things as food and education? Or is it the responsibility of the governments of poorer nations to look after their citizens themselves?

You should write at least 250 words.

Use your own ideas, knowledge and experience and support your arguments with examples and with relevant evidence.
```

[Original question page](assets/9470f0268633cd20d73dc7258f9b5f2a09978f2565b71549271e4a4772d33c3b.jpg)

## 口语

### 原书口语任务

<!-- Source: /api/assets/df30c83089adee6f76000a7b2b52e43d1f17ab4ff324de0b9f4c7c06dfac36cd.png; PDF page 59; full -->

```text
53
SPEAKING
Speaking
CANDIDATE’S CUE CARD   Task 2
ASKING FOR AN EXTENSION
You have to give in a piece of work to your lecturer next Wednesday.
You need two more weeks to prepare the assignment because you have
had difficulty obtaining the reference books. Your examiner is your
lecturer. Find out if you can have an extension.
Ask the examiner about: regulations regarding late work
possibility of having more time
different sources for books/information
assistance with writing for overseas students
```

[Original question page](assets/df30c83089adee6f76000a7b2b52e43d1f17ab4ff324de0b9f4c7c06dfac36cd.png)
