# 剑雅 1 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 140

134
Practice Test 2
PRACTICE TEST 2
LISTENING KEYS
Section 1
1 student accommodation/hostel
2 awful food
3 not friendly//kept to themselves (do not
accept “lonely”)
4 lecturers (too) busy
5 regular meetings//meetings with
lecturers//fortnightly meetings
6 family//homestay
7 lot of noise//children made noise//difficult
to study
8 student house
9 (Bachelor of) Computing
10 reserve computer time
Section 2
11 mountain
12 quality
13 $2,000
14 short/casual rides
15 town riding//shopping
16 serious touring
17 similar//almost the same
18 better quality (components)
19 buying clothes
20 frame
Section 3
21 B
22 C
23 D
24 B
25 one bunch
26 15 months
27 uphill//on hillsides
28 lots of/plenty of water
29 plastic bags
30 bananas/ones (to) ripen
31 C
32 D
Section 4
33 B
34 D
35 C
36 cooking
37 (regular) daily intake
38 (a) variety
39 the dark//the fridge//a cool place//a dark
place
40 eat in moderation//not too much
41 eat lots//eat most
Questions 31–32: C and D in either order.


1. student accommodation / hostel

2. awful food

3. not friendly / kept to themselves

4. lecturers busy / lecturers too busy

5. regular meetings / meetings with lecturers / fortnightly meetings

6. family / homestay

7. lot of noise / children made noise / difficult to study

8. student house

9. Computing / Bachelor of Computing

10. reserve computer time

### Part 2 · source page 140

134
Practice Test 2
PRACTICE TEST 2
LISTENING KEYS
Section 1
1 student accommodation/hostel
2 awful food
3 not friendly//kept to themselves (do not
accept “lonely”)
4 lecturers (too) busy
5 regular meetings//meetings with
lecturers//fortnightly meetings
6 family//homestay
7 lot of noise//children made noise//difficult
to study
8 student house
9 (Bachelor of) Computing
10 reserve computer time
Section 2
11 mountain
12 quality
13 $2,000
14 short/casual rides
15 town riding//shopping
16 serious touring
17 similar//almost the same
18 better quality (components)
19 buying clothes
20 frame
Section 3
21 B
22 C
23 D
24 B
25 one bunch
26 15 months
27 uphill//on hillsides
28 lots of/plenty of water
29 plastic bags
30 bananas/ones (to) ripen
31 C
32 D
Section 4
33 B
34 D
35 C
36 cooking
37 (regular) daily intake
38 (a) variety
39 the dark//the fridge//a cool place//a dark
place
40 eat in moderation//not too much
41 eat lots//eat most
Questions 31–32: C and D in either order.


11. mountain

12. quality

13. $ 2,000 / $ 2000 / $2,000 / $2000

14. short rides / casual rides

15. town riding / shopping

16. serious touring

17. similar / almost the same

18. better quality / better quality components

19. buying clothes

20. frame

### Part 3 · source page 140

134
Practice Test 2
PRACTICE TEST 2
LISTENING KEYS
Section 1
1 student accommodation/hostel
2 awful food
3 not friendly//kept to themselves (do not
accept “lonely”)
4 lecturers (too) busy
5 regular meetings//meetings with
lecturers//fortnightly meetings
6 family//homestay
7 lot of noise//children made noise//difficult
to study
8 student house
9 (Bachelor of) Computing
10 reserve computer time
Section 2
11 mountain
12 quality
13 $2,000
14 short/casual rides
15 town riding//shopping
16 serious touring
17 similar//almost the same
18 better quality (components)
19 buying clothes
20 frame
Section 3
21 B
22 C
23 D
24 B
25 one bunch
26 15 months
27 uphill//on hillsides
28 lots of/plenty of water
29 plastic bags
30 bananas/ones (to) ripen
31 C
32 D
Section 4
33 B
34 D
35 C
36 cooking
37 (regular) daily intake
38 (a) variety
39 the dark//the fridge//a cool place//a dark
place
40 eat in moderation//not too much
41 eat lots//eat most
Questions 31–32: C and D in either order.


21. B

22. C

23. D

24. B

25. one bunch

26. 15 months

27. uphill / on hillsides

28. lots of water / plenty of water

29. plastic bags

30. bananas ripen / bananas to ripen / ones ripen / ones to ripen

31. C / D

32. C / D

### Part 4 · source page 140

134
Practice Test 2
PRACTICE TEST 2
LISTENING KEYS
Section 1
1 student accommodation/hostel
2 awful food
3 not friendly//kept to themselves (do not
accept “lonely”)
4 lecturers (too) busy
5 regular meetings//meetings with
lecturers//fortnightly meetings
6 family//homestay
7 lot of noise//children made noise//difficult
to study
8 student house
9 (Bachelor of) Computing
10 reserve computer time
Section 2
11 mountain
12 quality
13 $2,000
14 short/casual rides
15 town riding//shopping
16 serious touring
17 similar//almost the same
18 better quality (components)
19 buying clothes
20 frame
Section 3
21 B
22 C
23 D
24 B
25 one bunch
26 15 months
27 uphill//on hillsides
28 lots of/plenty of water
29 plastic bags
30 bananas/ones (to) ripen
31 C
32 D
Section 4
33 B
34 D
35 C
36 cooking
37 (regular) daily intake
38 (a) variety
39 the dark//the fridge//a cool place//a dark
place
40 eat in moderation//not too much
41 eat lots//eat most
Questions 31–32: C and D in either order.


33. B

34. D

35. C

36. cooking

37. daily intake / regular daily intake

38. variety / a variety

39. the dark / the fridge / a cool place / a dark place

40. eat in moderation / not too much

41. eat lots / eat most

## A 类阅读

### Academic Reading · source page 141

135
Answer keys
READING
READING PASSAGE 1 Right and left-handedness in humans
Questions 1-7
Suggested approach
• Read the task rubric carefully. You have to
match the opinions with the people who express
them in the text.
• Read through the list of opinions to familiarise
yourself with it.
• In this case it is probably best to skim through
the text looking for names as these are easy to
identify. So skim through the text until you
come to the first name: Professor Turner.
• The text states in the first paragraph that
Professor Turner has studied left-handedness. It
goes on to say that he noted a “distinctive
asymmetry” in the human population.
• Skim through the list of opinions again Number
7 states “Asymmetry is a common feature of
the human body”. So the answer to question 7
is E.
• Continue this procedure with the rest of the
text. Note that the opinions in the questions are
expressed differently from the text. This is
known as “paraphrasing”. It means that you
will have to match the meaning rather than the
exact words
Questions 8-12
Questions Task Skills tested
1-7 Matching (people to
opinions)
• skimming/scanning for information
• understanding gist and paraphrase
8-10 Completing a table • skimming for factual information
11-12 Multiple choice • skimming/scanning for information
• identifying main and supporting points
• understanding paraphrase
• making inferences


Question | Answer | Location (where supplied)
1 | B | “… evolution of speech went with right-handed preference.”
2 | D | gist of final paragraph
3 | C | “… there are more left-handed males than females.”
4 | B | “… if a left handed person is brain damaged in the left hemisphere the recovery of speech is quite often better …”
5 | A | 3rd and 4th sentences of paragraph3
6 | C | “… discovered that the left-right asymmetry exists before birth.”
7 | E | “He noted that this distinctive asymmetry in the human population is itself systematic.”
8 | 15–20%
9 | 40%
10 | 6%
11 | D
12 | B

### Academic Reading · source page 142

136
Practice Test 2
READING PASSAGE 2 Migratory beekeeping
Questions 13-19
Suggested approach
• Read the task rubric carefully. You have to
complete the flow chart of the movements of a
migratory beekeeper.
• Read through the flow chart to familiarise
yourself with it.
• Scan the text and note the section that
discusses the beekeepers’ movements. In this
case, the information is scattered throughout
the text, so it is important to have a good idea
of what you are looking for.
• Go back to the first box in the flow chart. Note
that this box focuses on the start of migration.
• Re-skim the text until you come to this
information. It is cued in the fourth paragraph:
“By early March …”
• The flow chart will express the movements
differently from the text. This is called
“paraphrasing”. The fourth paragraph is all
about the beekeepers’ preparations. So the
answer to item 13 is “prepare”.
• Go on to item 14. Remember that you will not
use all the words in the box, and although
some of the words in the box may seem to fit
in the gaps, they have an incorrect meaning.
Your summary must be an accurate reflection
of what is stated in the passage.
Questions 20-27
Questions Task Skills tested
13-19 Completing a flow
chart
• following a sequence of events
• scanning/skimming for information
• understanding gist and paraphrase
20-23 Labelling a diagram • skimming for factual information
• understanding description and relationships
24-27 Yes, No, Not Given • skimming for factual information
• understanding gist and paraphrase


Question | Answer | Location (where supplied)
13 | prepare | gist of paragraph4
14 | full | “These are not moved in the middle of the day because too many of the bees would end up homeless.”
15 | smoke | “… bees can be pacified with a few puffs of smoke …”
16 | charge | “… the beekeeper will pay the farmer to allow his bees to feed …”
17 | machines | paraphrase of “uncapper” and “carousel”
18 | combs | “… centrifugal force throws the honey out of the combs.”
19 | split | “… a healthy double hive can be separated into two boxes.”
20 | (hexagonal) cells // comb
21 | frames (of comb)
22 | screen
23 | brood chamber
24 | NOT GIVEN
25 | YES
26 | YES
27 | NO

### Academic Reading · source page 143

137
Answer keys
READING PASSAGE 3 Tourism
Questions 28-37
Questions 38-41
Suggested approach
• Read the task rubric carefully. By choosing the
correct phrase A-H, you will make summary
points of the information given in the passage.
• It is obviously best to work from the questions
as these are the start of each sentence.
• Read through item 38.
• Read through the list of phrases to familiarise
yourself with them.
• Skim through the passage looking for key
words that indicate that the information in
question 38 is going to be discussed. For item
38, this occurs in paragraph B. In the middle of
the paragraph you read: “… the
popular concept of tourism is that …’. But to
understand the entire point you will have to
read the whole paragraph and take the gist. This
is best summarised in the second sentence of
the paragraph: “It is one manifestation of how
work and leisure are organised as separate and
regulated spheres of social practice in “modern”
societies.’ So the answer to question 38 is D.
• Go on to item 39 and repeat this procedure.


Question | Answer
28 | iii
29 | v
30 | iv
31 | vii
32 | viii
33 | NO
34 | YES
35 | NOT GIVEN
36 | YES
37 | NOT GIVEN
Question | Answer | Location of answer in text
38 | D | “It is one manifestation of how work and leisure are organised as separate and regulated spheres …”
39 | B | “Such anticipation is constructed and sustained through a variety of non tourist practices, such as film TV …”
40 | F | “The viewing of these tourist sites often involves … a much greater sensitivity to visual elements of landscape or townscape than is normally found in daily life.”
41 | H | “… the mass tourist travels in guided groups and finds pleasure in inauthentic, contrived attractions …”

Questions Task Skills tested

28-32 Paragraph headings • detailed reading
• identifying main ideas/themes/topics
• understanding gist
33-37 Yes, No, Not Given • skimming for detailed information
• understanding paraphrase and gist
• identifying attitude and opinion
38-41 Matching phrases • skimming/scanning for detail
• understanding paraphrase and gist
• making inferences

1. B

2. D

3. C

4. B

5. A

6. C

7. E

8. 15-20 per cent / 15-20 percent / 15-20%

9. 40 per cent / 40 percent / 40%

10. 6 per cent / 6 percent / 6%

11. D

12. B

13. prepare

14. full

15. smoke

16. charge

17. machines

18. combs

19. split

20. cells / hexagonal cells / comb

21. frames / frames of comb

22. screen

23. brood chamber

24. NOT GIVEN

25. YES

26. YES

27. NO

28. iii

29. v

30. iv

31. vii

32. viii

33. NO

34. YES

35. NOT GIVEN

36. YES

37. NOT GIVEN

38. D

39. B

40. F

41. H

## A 类写作

### Writing material: c1-t2-w-1

Original process diagram inspected at full resolution. Four labelled phases: incoming information; analysis and forecasting; preparing the broadcast; broadcast. Three incoming sources are satellite, radar and drifting buoy. The satellite supplies a satellite photo and also contributes to a synoptic chart; radar supplies a radar screen and also contributes to the synoptic chart; the drifting buoy contributes to the synoptic chart. These three analysis products (satellite photo, radar screen, synoptic chart) feed the computer used for preparing the broadcast. Three final delivery channels are a TV newsreader, radio and a recorded announcement represented by a telephone. Several parallel routes converge at broadcast preparation; it is not one exclusively linear sequence. No dates, durations, temperatures or accuracy percentages are supplied.



### Writing material: c1-t2-w-2

Older argument prompt presents two contrasting responsibilities. Discuss and justify a position on wealthy countries sharing resources and poorer governments looking after citizens; do not add an instruction requiring a particular stance.



## 口语

### 原书口语任务 · reference on source page 59

INTERVIEWER’S NOTES
ASKING FOR AN EXTENSION
The student is seeking extra time for an assignment.
• The student may need to write a letter.
• The student has had plenty of time to prepare the work and should not
really need two more weeks.
• Provide some idea about where he/she may get hold of the books.
• Offer advice about the “Learning Assistance Centre” on the campus which
helps students with essay writing.
After some resistance, agree to an extension of one week.

[Complete original page](assets/b02bfb821b1d537fcc9215a3a5b11c07cbe42d4eb1633feb5c0891edcf50e5de.jpg)
