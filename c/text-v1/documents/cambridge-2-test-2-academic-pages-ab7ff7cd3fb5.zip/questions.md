# 剑雅 2 · Test 2

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source question pages missing; answer slots retained.

> Part 4: source audio not supplied.

> Academic Reading: PDF page 17 R: The source hotel-article sentence ends after temporarily; missing continuation is not supplied.

## 听力

### Part 1

<!-- Source: /api/assets/f097d5815870fec5cea7a97ba62d78994a251623e65860c4ed9d86a3c6e3e121.jpg; PDF page 14; L -->

```text
Test2
SECTION 1 Questions 1-10
Questions 1 and 2
Circle the correct letters A-C.
Example
Gavin moved into his apartment...
A two days ago.
(B) two weeks ago.
C two months ago.
1 Gavin's apartment is located on the ...
A ground floor.
B second floor.
C third floor.
2 The monthly rent for Gavin's apartment is ...
A $615.
B $650.
C $655.
Questions 3-6
Complete the table below.
Write NO MORE THAN THREE WORDS for each answer.
ITEM | VALUE
(3) __________ | $450
(4) __________ | $1,150
Watches | $2,000
CDs and (5) __________ | $400
Total annual cost of insurance (6) $ __________
```

[Original question page](assets/f097d5815870fec5cea7a97ba62d78994a251623e65860c4ed9d86a3c6e3e121.jpg)

<!-- Source: /api/assets/f561232736b968093c36d93ead6b755f773fc3985a3bdb58332635ec0b4d8072.jpg; PDF page 14; R -->

```text
Complete the form below.
WRITE NO MORE THAN THREE WORDS for each answer.
INSURANCE
APPLICATION FORM
Name: Mr Gavin (7)
Address: (8) Biggins Street
(9)
Date of Birth: 12th November 1960
Telephone: Home: 9872 4555
Nationality: (10)
```

[Original question page](assets/f561232736b968093c36d93ead6b755f773fc3985a3bdb58332635ec0b4d8072.jpg)

![Original figure](assets/f561232736b968093c36d93ead6b755f773fc3985a3bdb58332635ec0b4d8072.jpg)

### Part 2

<!-- Source: /api/assets/f805961c1781e223273ea4254373ab27dd61bcb1be5de9499946c6e5d95b7671.jpg; PDF page 15; L -->

```text
SECTION 2 Questions 11-20
Question 11
Circle the correct letter A-D.
Smith House was originally built as ...
A a residential college.
B a family house.
C a university.
D an office block.
Questions 12-14
Complete the explanation of the room number.
Write NO MORE THAN THREE WORDS for each answer.
Original room-number diagram retained: N 2 34.
N → (12) __________ wing
2 → (13) __________
34 → personal (14) __________
Questions 15–17
Complete the sentences below. Write NO MORE THAN THREE WORDS for each answer.
Students need a front door key between (15) __________ AND __________.
In an emergency, students should use (16) __________.
Fees also cover some (17) __________ charges.
```

[Original question page](assets/f805961c1781e223273ea4254373ab27dd61bcb1be5de9499946c6e5d95b7671.jpg)

![Original figure](assets/f805961c1781e223273ea4254373ab27dd61bcb1be5de9499946c6e5d95b7671.jpg)

<!-- Source: /api/assets/ce8201602bd0eb4cabe25e521a35317d8b1a0cc42ccbffc52c7977c6c2dab0b0.jpg; PDF page 15; R -->

```text
Questions 18-20
Complete the notice below.
Write NO MORE THAN THREE WORDS for each answer.
• No noise after 9 pm.
• Smoking only allowed on (18)
• No changes can be made to (19)
If you have any questions, ask the (20)
```

[Original question page](assets/ce8201602bd0eb4cabe25e521a35317d8b1a0cc42ccbffc52c7977c6c2dab0b0.jpg)

### Part 3

<!-- Source: /api/assets/138c210cb83de068dc3685c18b77e50e7667c6a77779b8b07e3d31511d5de2c2.jpg; PDF page 16; L -->

```text
SECTION 3 Questions 21–30
Questions 21–25
Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
Forms of media | Examples
Print | books; (21) __________
Pictures | (22) __________
Audio (listening) | CDs; (23) __________
Audio-visual | film; (24) __________; videos
Electronic | (25) __________
```

[Original question page](assets/138c210cb83de068dc3685c18b77e50e7667c6a77779b8b07e3d31511d5de2c2.jpg)

<!-- Source: /api/assets/1730ad7c6e586434806c13cd2484d246be16ed2bb250379137a120de235ad161.jpg; PDF page 16; R -->

```text
Write the appropriate letters A-C against questions 26-30.
According to the speakers, in which situation are the following media most useful?
A individual children
B five or six children
C whole class
Answer
26 tapes
27 computers
28 videos
29 books
30 wall maps
```

[Original question page](assets/1730ad7c6e586434806c13cd2484d246be16ed2bb250379137a120de235ad161.jpg)

### Part 4

用户提供的 PDF 缺少此部分题页，暂不能完成本部分。保留原书题号，未编造题干。 本目录未提供此部分听力音频。


31. 第 31 题 · 题干与选项见原页


32. 第 32 题 · 题干与选项见原页


33. 第 33 题 · 题干与选项见原页


34. 第 34 题 · 题干与选项见原页


35. 第 35 题 · 题干与选项见原页


36. 第 36 题 · 题干与选项见原页


37. 第 37 题 · 题干与选项见原页


38. 第 38 题 · 题干与选项见原页


39. 第 39 题 · 题干与选项见原页


40. 第 40 题 · 题干与选项见原页


## A 类阅读

### Academic Reading

<!-- Source: /api/assets/450fb2a5431f97c08be4692f54116cf1a19e008f24076275e11d9a3c6e7859ec.jpg; PDF page 17; L -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1–13 which are based on Reading Passage 1 below.
IMPLEMENTING THE CYCLE OF SUCCESS: A CASE STUDY
Within Australia, Australian Hotels Inc 
(AHI) operates nine hotels and employs over 
2000 permanent full-time staff, 300 
permanent part-time employees and 100 
casual staff. One of its latest ventures, the 
Sydney Airport hotel (SAH), opened in 
March 1995. The hotel is the closest to 
Sydney Airport and is designed to provide 
the best available accommodation, food and 
beverage and meeting facilities in Sydney's 
southern suburbs. Similar to many 
international hotel chains, however, AHI has 
experienced difficulties in Australia in 
providing long-term profits for hotel owners, 
as a result of the country's high labour-cost 
structure. In order to develop an 
economically viable hotel organisation 
model, AHI decided to implement some new 
policies and practices at SAH. 
The first of the initiatives was an 
organisational structure with only three 
levels of management - compared to the 
traditional seven. Partly as a result of this 
change, there are 25 per cent fewer 
management positions, enabling a 
significant saving. This change also has 
other implications. Communication, both up 
and down the organisation, has greatly 
improved. Decision-making has been forced 
down in many cases to front-line employees. 
As a result, guest requests are usually met 
without reference to a supervisor, improving 
both customer and employee satisfaction. 
The hotel also recognised that it would 
need a different approach to selecting

employees who would fit in with its new
policies. In its advertisements, the hotel
stated a preference for people with some
'service' experience in order to minimise
traditional work practices being introduced
into the hotel. Over 7000 applicants filled in
application forms for the 120 jobs initially
offered at SAH. The balance of the positions
at the hotel (30 management and 40 shift
leader positions) were predominantly filled
by transfers from other AHI properties.
A series of tests and interviews were
conducted with potential employees, which
eventually left 280 applicants competing for
the 120 advertised positions. After the final
interview, potential recruits were divided
into three categories. Category A was for
applicants exhibiting strong leadership
qualities, Category C was for applicants
perceived to be followers, and Category B
was for applicants with both leader and
follower qualities. Department heads and
shift leaders then composed prospective
teams using a combination of people from
all three categories. Once suitable teams
were formed, offers of employment were
made to team members.
Another major initiative by SAH was to
adopt a totally multi-skilled workforce.
Although there may be some limitations
with highly technical jobs such as cooking
or maintenance, wherever possible,
employees at SAH are able to work in a
wide variety of positions. A multi-skilled
workforce provides far greater management
```

[Original question page](assets/450fb2a5431f97c08be4692f54116cf1a19e008f24076275e11d9a3c6e7859ec.jpg)

<!-- Source: /api/assets/5fa9734d4b5444ab28c1e4bdcd4407ecb5bbdf6ea5f040266f51a0bb4b18252b.jpg; PDF page 17; R -->

```text
flexibility during peak and quiet times to
transfer employees to needed positions. For
example, when office staff are away on
holidays during quiet periods of the year,
employees in either food or beverage or
housekeeping departments can temporarily
[Source limitation: this sentence ends here in the supplied PDF. No missing continuation has been invented.]
The most crucial way, however, of
improving the labour cost structure at SAH
was to find better, more productive ways of
providing customer service. SAH
management concluded this would first
require a process of 'benchmarking'. The
prime objective of the benchmarking process
was to compare a range of service delivery
processes across a range of criteria using
teams made up of employees from different
departments within the hotel which
interacted with each other. This process
resulted in performance measures that
greatly enhanced SAH's ability to
improve productivity and quality.
The front office team discovered through
this project that a high proportion of AHI
Club member reservations were incomplete.
As a result, the service provided to these
guests was below the standard promised to
them as part of their membership agreement.
Reducing the number of incomplete
reservations greatly improved
guest perceptions of service.

In addition, a program modelled on an
earlier project called 'Take Charge' was
implemented. Essentially, Take Charge
provides an effective feedback loop from
both customers and employees. Customer
comments, both positive and negative, are
recorded by staff. These are collated
regularly to identify opportunities for
improvement. Just as importantly,
employees are requested to note down their
own suggestions for improvement. (AHI has
set an expectation that employees will
submit at least three suggestions for every
one they receive from a customer.)
Employee feedback is reviewed daily and
suggestions are implemented within 48
hours, if possible, or a valid reason is given
for non-implementation. If suggestions
require analysis or data collection, the Take
Charge team has 30 days in which to address
the issue and come up with
recommendations.
Although quantitative evidence of AHI's
initiatives at SAH are limited at present,
anecdotal evidence clearly suggests that
these practices are working. Indeed AHI is
progressively rolling out these initiatives in
other hotels in Australia, whilst numerous
overseas visitors have come to see how the
program works.

This article has been adapted and condensed from the article by R. Carter (1996), 'Implementing the cycle of
success: A case study of the Sheraton Pacific Division', Asia Pacific Journal of Human Resources, 34(3): 111-23.
Names and other details have been changed and report findings may have been given a different emphasis from
the original. We are grateful to the author and Asia Pacific Journal of Human Resources for allowing us to use the
material in this way.

```

[Original question page](assets/5fa9734d4b5444ab28c1e4bdcd4407ecb5bbdf6ea5f040266f51a0bb4b18252b.jpg)

<!-- Source: /api/assets/782ee4164b697e6c713774a11af12a5bc8327a18a6b748157441a8d6b40036b4.jpg; PDF page 18; L -->

```text
Questions 1-5
Choose the appropriate letters A-D and write them in boxes 1-5 on your answer sheet.
1 The high costs of running AHI's hotels are related to their ...
A management.
B size.
C staff.
D policies.
2 SAH's new organisational structure requires ...
A 75% of the old management positions.
B 25% of the old management positions.
C 25% more management positions.
D 5% fewer management positions.
3 The SAH's approach to organisational structure required changing practices in ..
A industrial relations.
B firing staff.
C hiring staff.
D marketing.
4 The total number of jobs advertised at the SAH was ...
A 70.
B 120.
C 170.
D 280.
5 Categories A, B and C were used to select...
A front office staff.
B new teams.
C department heads.
D new managers.
```

[Original question page](assets/782ee4164b697e6c713774a11af12a5bc8327a18a6b748157441a8d6b40036b4.jpg)

<!-- Source: /api/assets/ee03ea0c110ed1302fc7deb71127fe89bc02d8402cf1bdf4d17aec21fe31037c.jpg; PDF page 18; R -->

```text
Questions 6-13
Complete the following summary of the last four paragraphs of Reading Passage 1 using ONE
OR TWO words from the Reading Passage for each answer.
Write your answers in boxes 6-13 on your answer sheet.
WHAT THEY DID AT SAH
Teams of employees were selected from different hotel departments to
participate in a ... (6) ... exercise.
The information collected was used to compare ... (7) ... processes
which, in turn, led to the development of ... (8) ... that would be used
to increase the hotel's capacity to improve ... (9) ... as well as quality.
Also, an older program known as ... (10) ... was introduced at SAH. In
this program,... (11) ... is sought from customers and staff. Wherever
possible ... (12) ... suggestions are implemented within 48 hours. Other
suggestions are investigated for their feasibility for a period of up to
...(13)... .
```

[Original question page](assets/ee03ea0c110ed1302fc7deb71127fe89bc02d8402cf1bdf4d17aec21fe31037c.jpg)

<!-- Source: /api/assets/fb73d916f778a60cf3fd5be20355d50e1f18e2812fd2a1f1e4a064ab4c3b1ad7.jpg; PDF page 19; L -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14–26 which are based on Reading Passage 2 below.
The discovery that language can be a 
barrier to communication is quickly 
made by all who travel, study, govern or 
sell. Whether the activity is tourism, 
research, government, policing, business, 
or data dissemination, the lack of a 
common language can severely impede 
progress or can halt it altogether. 
'Common language' here usually means 
a foreign language, but the same point 
applies in principle to any encounter 
with unfamiliar dialects or styles within a 
single language. 'They don't talk the 
same language' has a major metaphorical 
meaning alongside its literal one. 
Although communication problems of 
this kind must happen thousands of 
times each day, very few become public 
knowledge. Publicity comes only when a 
failure to communicate has major 
consequences, such as strikes, lost orders, 
legal problems, or fatal accidents - even, 
at times, war. One reported instance of 
communication failure took place in 
1970, when several Americans ate a 
species of poisonous mushroom. No 
remedy was known, and two of the 
people died within days. A radio report 
of the case was heard by a chemist who 
knew of a treatment that had been 
successfully used in 1959 and published 
in 1963. Why had the American doctors 
not heard of it seven years later? 
Presumably because the report of the 
treatment had been published only in 
journals written in European languages 
other than English. 
Several comparable cases have been 
reported. But isolated examples do not

give an impression of the size of the
problem — something that can come only
from studies of the use or avoidance of
foreign-language materials and contacts
in different communicative situations. In
the English-speaking scientific world, for
example, surveys of books and
documents consulted in libraries and
other information agencies have shown
that very little foreign-language material
is ever consulted. Library requests in the
field of science and technology showed
that only 13 per cent were for foreign-
language periodicals. Studies of the
sources cited in publications lead to a
similar conclusion: the use of foreign-
language sources is often found to be as
low as 10 per cent.
The language barrier presents itself in
stark form to firms who wish to market
their products in other countries. British
industry, in particular, has in recent
decades often been criticised for its
linguistic insularity — for its assumption
that foreign buyers will be happy to
communicate in English, and that
awareness of other languages is not
therefore a priority. In the 1960s, over
two-thirds of British firms dealing with
 non-English-speaking customers were
using English for outgoing
correspondence; many had their sales
literature only in English; and as many as
40 per cent employed no-one able to
communicate in the customers'
languages. A similar problem was
identified in other English-speaking
countries, notably the USA, Australia
and New Zealand. And non-English-
```

[Original question page](assets/fb73d916f778a60cf3fd5be20355d50e1f18e2812fd2a1f1e4a064ab4c3b1ad7.jpg)

<!-- Source: /api/assets/9a34382aab21c650be97e71a46500a518b87a12e297c9b13340fb99f72218576.jpg; PDF page 19; R -->

```text
speaking countries were by no means
exempt - although the widespread use of
English as an alternative language made
them less open to the charge of
insularity.
The criticism and publicity given to
this problem since the 1960s seems to
have greatly improved the situation.
industrial training schemes have
promoted an increase in linguistic and
cultural awareness. Many firms now have
their own translation services; to take just
one example in Britain, Rowntree
Mackintosh now publish their
documents in six languages (English,
French, German, Dutch, Italian and
Xhosa). Some firms run part-time
language courses in the languages of the
countries with which they are most
involved; some produce their own
technical glossaries, to ensure
consistency when material is being
translated. It is now much more readily
appreciated that marketing efforts can be
delayed, damaged, or disrupted by a
failure to take account of the linguistic
needs of the customer.
The changes in awareness have been
most marked in English-speaking
countries, where the realisation has
gradually dawned that by no means
everyone in the world knows English
well enough to negotiate in it. This is
especially a problem when English is not
an official language of public
administration, as in most parts of the
Far East, Russia, Eastern Europe, the
Arab world, Latin America and French-speaking Africa. Even in cases where
foreign customers can speak English
quite well, it is often forgotten that they
may not be able to understand it to the
required level - bearing in mind the
regional and social variation which
permeates speech and which can cause
major problems of listening
comprehension. In securing
understanding, how 'we' speak to 'them'
is just as important, it appears, as how
'they' speak to 'us'.
```

[Original question page](assets/9a34382aab21c650be97e71a46500a518b87a12e297c9b13340fb99f72218576.jpg)

<!-- Source: /api/assets/cc7027fc08a7205107ef93cbc952d8976196dc9e8311d400cf0ee107dc78e78f.jpg; PDF page 20; L -->

```text
Questions 14-17
Complete each of the following statements (Questions 14-17) with words taken from Reading
Passage 2.
Write NO MORE THAN THREE WORDS for each answer.
Write your answers in boxes 14-17 on your answer sheet.
14 Language problems may come to the attention of the public when they have __________, such as fatal accidents or social problems.
15 Evidence of the extent of the language barrier has been gained from __________ of materials used by scientists such as books and
periodicals.
16 An example of British linguistic insularity is the use of English for materials such as __________.
17 An example of a part of the world where people may have difficulty in negotiating
English is __________.
Questions 18-20
Choose the appropriate letters A-D and write them in boxes 18-20 on your answer sheet.
18 According to the passage, 'They don't talk the same language' (paragraph 1), can refer
to problems in ...
A . understanding metaphor.
B learning foreign languages.
C understanding dialect or style.
D dealing with technological change.
19 The case of the poisonous mushrooms (paragraph 2) suggests that American doctors .
A should pay more attention to radio reports.
B only read medical articles if they are in English.
C are sometimes unwilling to try foreign treatments.
D do not always communicate effectively with their patients.
20 According to the writer, the linguistic insularity of British businesses ...
A later spread to other countries.
B had a negative effect on their business.
C is not as bad now as it used to be in the past.
D made non-English-speaking companies turn to other markets.
```

[Original question page](assets/cc7027fc08a7205107ef93cbc952d8976196dc9e8311d400cf0ee107dc78e78f.jpg)

<!-- Source: /api/assets/cb2694d0274ae7f86918b052e295466fded66862a9478d488069061d794a56d8.jpg; PDF page 20; R -->

```text
Questions 21-24
LIST the four main ways in which British companies have tried to solve the problem of the
language barrier since the 1960s.
WRITE NO MORE THAN THREE WORDS for each answer.
Write your answers in boxes 21-24 on your answer sheet.
21
22 __________
23 __________ [answer line omitted on original; restored from the explicit four-answer requirement21–24]
24 __________
Questions 25 and 26
Choose the appropriate letters A-D and write them in boxes 25 and 26 on your answer sheet.
25 According to the writer, English-speaking people need to be aware that...
A some foreigners have never met an English-speaking person.
B many foreigners have no desire to learn English.
C foreign languages may pose a greater problem in the future.
D English-speaking foreigners may have difficulty understanding English.
26 A suitable title for this passage would be ...
A Overcoming the language barrier
B How to survive an English-speaking world
C Global understanding - the key to personal progress
D The need for a common language
```

[Original question page](assets/cb2694d0274ae7f86918b052e295466fded66862a9478d488069061d794a56d8.jpg)

<!-- Source: /api/assets/f6306777448d74635b23a1c2c3ff443026f3f37c787dac76d4a18829245e126e.jpg; PDF page 21; L -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40 which are based on Reading Passage 3
on the following pages.
Questions 27-30
Reading Passage 3 has seven paragraphs A-G.
From the list of headings below choose the most suitable headings for paragraphs B-E.
Write the appropriate numbers (i-viii) in boxes 27-30 on your answer sheet.
NB There are more headings than paragraphs, so you will not use them all.
List of Headings
i A truly international environment
ii Once a port city, always a port city
iii Good ports make huge profits
iv How the port changes a city's
infrastructure
v Reasons for the decline of ports
vi Relative significance of trade and service
industry
vii Ports and harbours
viii The demands of the oil industry
Example Answer
Paragraph A vii
27 Paragraph B
28 Paragraph C
29 Paragraph D
30 Paragraph E
```

[Original question page](assets/f6306777448d74635b23a1c2c3ff443026f3f37c787dac76d4a18829245e126e.jpg)

<!-- Source: /api/assets/bb8d5b9a2eeec7bb6714ddb5c7526a26735bf699e2c3f12d388f4bc75f7dac16.jpg; PDF page 21; R -->

```text
What Is a Port City?
The port city provides a fascinating and rich understanding of the movement of people
and goods around the world. We understand a port as a centre of land-sea exchange,
and as a major source of livelihood and a major force for cultural mixing. But do ports
all produce a range of common urban characteristics which justify classifying port cities
together under a single generic label? Do they have enough in common to warrant
distinguishing them from other kinds of cities ?
A A port must be distinguished from a harbour. They are two very different things. Most
ports have poor harbours, and many fine harbours see few ships. Harbour is a physical
concept, a shelter for ships; port is an economic concept, a centre of land-sea
exchange which requires good access to a hinterland even more than a sea-linked
foreland. It is landward access, which is productive of goods for export and which
demands imports, that is critical. Poor harbours can be improved with breakwaters and
dredging if there is a demand for a port. Madras and Colombo are examples of
harbours expensively improved by enlarging, dredging and building breakwaters.
B Port cities become industrial, financial and service centres and political capitals
because of their water connections and the urban concentration which arises there and
later draws to it railways, highways and air routes. Water transport means cheap access,
the chief basis of all port cities. Many of the world's biggest cities, for example,
London, New York, Shanghai, Istanbul, Buenos Aires, Tokyo, Jakarta, Calcutta,
Philadelphia and San Francisco began as ports - that is, with land-sea exchange as
their major function - but they have since grown disproportionately in other respects
so that their port functions are no longer dominant. They remain different kinds of
places from non-port cities and their port functions account for that difference.
C Port functions, more than anything else, make a city cosmopolitan. A port city is open
to the world. In it races, cultures, and ideas, as well as goods from a variety of places,
jostle, mix and enrich each other and the life of the city. The smell of the sea and the
harbour, the sound of boat whistles or the moving tides are symbols of their multiple
links with a wide world, samples of which are present in microcosm within their own
urban areas.
D Sea ports have been transformed by the advent of powered vessels, whose size and
draught have increased. Many formerly important ports have become economically
and physically less accessible as a result. By-passed by most of their former enriching
flow of exchange, they have become cultural and economic backwaters or have
acquired the character of museums of the past. Examples of these are Charleston,
Salem, Bristol, Plymouth, Surat, Galle, Melaka, Soochow, and a long list of earlier
prominent port cities in Southeast Asia, Africa and Latin America.
```

[Original question page](assets/bb8d5b9a2eeec7bb6714ddb5c7526a26735bf699e2c3f12d388f4bc75f7dac16.jpg)

<!-- Source: /api/assets/25c47c6f2183a85ef2cf17c69645e9fe0b9e27d6b2607a3f2da3d6b1aa06a3c8.jpg; PDF page 22; L -->

```text
E Much domestic port trade has not been recorded. What evidence we have suggests
that domestic trade was greater at all periods than external trade. Shanghai, for
example, did most of its trade with other Chinese ports and inland cities. Calcutta
traded mainly with other parts of India and so on. Most of any city's population is
engaged in providing goods and services for the city itself. Trade outside the city is its
basic function. But each basic worker requires food, housing, clothing and other such
services. Estimates of the ratio of basic to service workers range from 1:4 to 1:8.
F No city can be simply a port but must be involved in a variety of other activities. The
port function of the city draws to it raw materials and distributes them in many other
forms. Ports take advantage of the need for breaking up the bulk material where water
and land transport meet and where loading and unloading costs can be minimised by
refining raw materials or turning them into finished goods. The major examples here are
oil refining and ore refining, which are commonly located at ports. It is not easy to
draw a line around what is and is not a port function. All ports handle, unload, sort,
alter, process, repack, and reship most of what they receive. A city may still be
regarded as a port city when it becomes involved in a great range of functions not
immediately involved with ships or docks.
G Cities which began as ports retain the chief commercial and administrative centre of
the city close to the waterfront. The centre of New York is in lower Manhattan between
two river mouths, the City of London is on the Thames, Shanghai along the Bund. This
proximity to water is also true of Boston, Philadelphia, Bombay, Calcutta, Madras,
Singapore, Bangkok, Hong Kong and Yokohama, where the commercial, financial, and
administrative centres are still grouped around their harbours even though each city has
expanded into a metropolis. Even a casual visitor cannot mistake them as anything but
port cities.
```

[Original question page](assets/25c47c6f2183a85ef2cf17c69645e9fe0b9e27d6b2607a3f2da3d6b1aa06a3c8.jpg)

<!-- Source: /api/assets/436b4d9d5f9dcb36da88b97f72281a723bda0d9a9552e1754e319dd957c08203.jpg; PDF page 22; R -->

```text
Look at the following descriptions (Questions 31-34) of some port cities mentioned in Reading
Match the pairs of cities (A-H) listed below; with the descriptions.
Match the appropriate letters A-H in boxes 31-34 on your answer sheet.
NB There are more pairs of port cities than descriptions, so you will not use them all.
31 required considerable harbour development
32 began as ports but other facilities later dominated
33 lost their prominence when large ships could not be accommodated
34 maintain their business centres near the port waterfront
A Bombay and Buenos Aires
B Hong Kong and Salem
C Istanbul and Jakarta
D Madras and Colombo
E New York and Bristol
F Plymouth and Melaka
G Singapore and Yokohama
H Surat and London
```

[Original question page](assets/436b4d9d5f9dcb36da88b97f72281a723bda0d9a9552e1754e319dd957c08203.jpg)

<!-- Source: /api/assets/ae5a5e2cb2d17222428f53dbf28259f4523a8dbe1451c23d78c4ad277b6d80fc.jpg; PDF page 23; L -->

```text
Questions 35-40
Do the following statements agree with the information given in Reading Passage 3?
In boxes 35-40 on your answer sheet write
YES if the statement agrees with the information
NO if the statement contradicts the information
NOT GIVEN if there is no information on this in the passage
35 Cities cease to be port cities when other functions dominate.
36 In the past, many port cities did more trade within their own country than with
overseas ports.
37 Most people in a port city are engaged in international trade and finance.
38 Ports attract many subsidiary and independent industries.
39 Ports have to establish a common language of trade.
40 Ports often have river connections.
```

[Original question page](assets/ae5a5e2cb2d17222428f53dbf28259f4523a8dbe1451c23d78c4ad277b6d80fc.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/bc91ecdfb56f1c2327a25566fe3319b5c6e698a4a74c54a7cf290730c41522a9.jpg; PDF page 23; R -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows the amount of leisure time enjoyed by men and women of different employment status.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

See the retained original figure for the full table or chart.
```

[Original question page](assets/bc91ecdfb56f1c2327a25566fe3319b5c6e698a4a74c54a7cf290730c41522a9.jpg)

![Original figure](assets/bc91ecdfb56f1c2327a25566fe3319b5c6e698a4a74c54a7cf290730c41522a9.jpg)

### Task 2

<!-- Source: /api/assets/e0fda18c74065577b2ceba646536cf384e3d57bc3da6a572a49e037cb65dcca1.jpg; PDF page 24; L -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic:

"Prevention is better than cure."

Out of a country's health budget, a large proportion should be diverted from treatment to spending on health education and preventative measures.

To what extent do you agree or disagree with this statement?

You should write at least 250 words.

You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.
```

[Original question page](assets/e0fda18c74065577b2ceba646536cf384e3d57bc3da6a572a49e037cb65dcca1.jpg)

## 口语

### 原书口语任务

<!-- Source: /api/assets/d48116a34342f44bfd364a2c7be16ec19b39b13612c73e70255ee15ece5c39c9.png; PDF page 24; R -->

```text
Task:
The candidate is to find out as much information as possible about a concert.
CONCERT
Find out as much as possible about a concert your examiner has been to recently.
Ask the examiner about: the type of concert
the location
the cost
transport to and from the concert
the audience
the length of the concert
his/her opinion of the concert
```

[Original question page](assets/d48116a34342f44bfd364a2c7be16ec19b39b13612c73e70255ee15ece5c39c9.png)
