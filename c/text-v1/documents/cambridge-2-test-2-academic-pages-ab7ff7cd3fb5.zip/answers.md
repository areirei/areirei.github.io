# 剑雅 2 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 72

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are slated in the Key.)
0-16
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
17-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 B
2 A
3 fridge/refrigerator
4 stereo (system)
5 books
6 ($/dollars) 184 NOT per month/monthly
7 Murray
8 16C
9 South Hills
10 English // British
Section 2, Questions 11-20
11 B
12 north // N
13 (2nd/second) floor (number)
14 room (number)
15 8 pm (and 7 am)
16 (the) fire/emergency doors
17 laundry // washing
18 (the) balconies ACCEPT balconys
19 meal times
20 (elected) floor senior(s)
Section 3, Questions 21-30
21 newspaper(s)
22 map(s)
23 radio(s)
24 television//TV
25 computer(s)
26 B
27 B
28 C
29 A
30 B
Section 4, Questions 31-40
31 A
32 training
33 technology ACCEPT tecknology/teknology
34 cool (and) wet (both for one mark)
35 wool (and) timber (both for one mark)
36 fertile soil(s)/land/earth/ground
37 (high quality) vegetables/vegs
38 warm (and) wet (both for one mark)
39 800 // eight hundred
40 B

1. B

2. A

3. fridge / refrigerator

4. stereo / stereo system

5. books

6. 184 / $ 184 / $184 / dollars184

7. Murray

8. 16C

9. South Hills

10. English / British

### Part 2 · source page 72

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are slated in the Key.)
0-16
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
17-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 B
2 A
3 fridge/refrigerator
4 stereo (system)
5 books
6 ($/dollars) 184 NOT per month/monthly
7 Murray
8 16C
9 South Hills
10 English // British
Section 2, Questions 11-20
11 B
12 north // N
13 (2nd/second) floor (number)
14 room (number)
15 8 pm (and 7 am)
16 (the) fire/emergency doors
17 laundry // washing
18 (the) balconies ACCEPT balconys
19 meal times
20 (elected) floor senior(s)
Section 3, Questions 21-30
21 newspaper(s)
22 map(s)
23 radio(s)
24 television//TV
25 computer(s)
26 B
27 B
28 C
29 A
30 B
Section 4, Questions 31-40
31 A
32 training
33 technology ACCEPT tecknology/teknology
34 cool (and) wet (both for one mark)
35 wool (and) timber (both for one mark)
36 fertile soil(s)/land/earth/ground
37 (high quality) vegetables/vegs
38 warm (and) wet (both for one mark)
39 800 // eight hundred
40 B

11. B

12. north / N

13. floor / floor number / 2nd floor / 2nd floor number / second floor / second floor number

14. room / room number

15. 8 pm / 8pm / 8 pm and 7 am / 8pm and 7am

16. fire doors / the fire doors / emergency doors / the emergency doors

17. laundry / washing

18. balconies / the balconies / balconys / the balconys

19. meal times

20. floor senior / floor seniors / elected floor senior / elected floor seniors

### Part 3 · source page 72

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are slated in the Key.)
0-16
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
17-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 B
2 A
3 fridge/refrigerator
4 stereo (system)
5 books
6 ($/dollars) 184 NOT per month/monthly
7 Murray
8 16C
9 South Hills
10 English // British
Section 2, Questions 11-20
11 B
12 north // N
13 (2nd/second) floor (number)
14 room (number)
15 8 pm (and 7 am)
16 (the) fire/emergency doors
17 laundry // washing
18 (the) balconies ACCEPT balconys
19 meal times
20 (elected) floor senior(s)
Section 3, Questions 21-30
21 newspaper(s)
22 map(s)
23 radio(s)
24 television//TV
25 computer(s)
26 B
27 B
28 C
29 A
30 B
Section 4, Questions 31-40
31 A
32 training
33 technology ACCEPT tecknology/teknology
34 cool (and) wet (both for one mark)
35 wool (and) timber (both for one mark)
36 fertile soil(s)/land/earth/ground
37 (high quality) vegetables/vegs
38 warm (and) wet (both for one mark)
39 800 // eight hundred
40 B

21. newspaper / newspapers

22. map / maps

23. radio / radios

24. television / TV

25. computer / computers

26. B

27. B

28. C

29. A

30. B

### Part 4 · source page 72

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are slated in the Key.)
0-16
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
17-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 B
2 A
3 fridge/refrigerator
4 stereo (system)
5 books
6 ($/dollars) 184 NOT per month/monthly
7 Murray
8 16C
9 South Hills
10 English // British
Section 2, Questions 11-20
11 B
12 north // N
13 (2nd/second) floor (number)
14 room (number)
15 8 pm (and 7 am)
16 (the) fire/emergency doors
17 laundry // washing
18 (the) balconies ACCEPT balconys
19 meal times
20 (elected) floor senior(s)
Section 3, Questions 21-30
21 newspaper(s)
22 map(s)
23 radio(s)
24 television//TV
25 computer(s)
26 B
27 B
28 C
29 A
30 B
Section 4, Questions 31-40
31 A
32 training
33 technology ACCEPT tecknology/teknology
34 cool (and) wet (both for one mark)
35 wool (and) timber (both for one mark)
36 fertile soil(s)/land/earth/ground
37 (high quality) vegetables/vegs
38 warm (and) wet (both for one mark)
39 800 // eight hundred
40 B

31. A

32. training

33. technology / tecknology / teknology

34. cool wet / cool, wet / cool and wet / cool & wet / cool; wet / cool/wet / cool,wet / wet cool / wet, cool / wet and cool / wet & cool / wet; cool / wet/cool / wet,cool

35. wool timber / wool, timber / wool and timber / wool & timber / wool; timber / wool/timber / wool,timber / timber wool / timber, wool / timber and wool / timber & wool / timber; wool / timber/wool / timber,wool

36. fertile soil / fertile soils / land / earth / ground

37. vegetables / high quality vegetables / vegs

38. warm wet / warm, wet / warm and wet / warm & wet / warm; wet / warm/wet / warm,wet / wet warm / wet, warm / wet and warm / wet & warm / wet; warm / wet/warm / wet,warm

39. 800 / eight hundred

40. B

## A 类阅读

### Academic Reading · source page 72

ACADEMIC READING
Each question correctly answered scores 1 mark.
Reading Passage 1, Questions 1-13
1 C
2 A
3 C
4 B
5 B
6 benchmarking
7 (a range of) service delivery
8 (performance) measures
9 productivity
10 (') Take Charge (')
11 feedback
12 employee(s') // staff
13 30 days
Reading Passage 2, Questions 14-26
14 major consequences
15 surveys
16 sales literature
17 Eastern Europe // Far East // Russia // Arab
world // Latin America // French-speaking
Africa
18 C
19 B
If you score...
0-14
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
15-22
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
23-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
20 C
21–24 (in any order):
• (industrial) training (schemes)
• translation services
• (part-time) language courses
• (technical) glossaries
25 D
26 A
Reading Passage 3, Questions 27-40
27 ii
28 i
29 v
30 vi
31 D
32 C
33 F
34 G
35 NO
36 YES
37 NO
38 YES
39 NOT GIVEN
40 YES

1. C

2. A

3. C

4. B

5. B

6. benchmarking

7. service delivery / a range of service delivery

8. measures / performance measures

9. productivity

10. Take Charge / Take Charge' / 'Take Charge / 'Take Charge'

11. feedback

12. employee / employees' / staff

13. 30 days

14. major consequences

15. surveys

16. sales literature

17. Eastern Europe / Far East / Russia / Arab world / Latin America / French-speaking Africa

18. C

19. B

20. C

21. training / training schemes / industrial training / industrial training schemes / translation services / language courses / part-time language courses / glossaries / technical glossaries

22. training / training schemes / industrial training / industrial training schemes / translation services / language courses / part-time language courses / glossaries / technical glossaries

23. training / training schemes / industrial training / industrial training schemes / translation services / language courses / part-time language courses / glossaries / technical glossaries

24. training / training schemes / industrial training / industrial training schemes / translation services / language courses / part-time language courses / glossaries / technical glossaries

25. D

26. A

27. ii

28. i

29. v

30. vi

31. D

32. C

33. F

34. G

35. NO

36. YES

37. NO

38. YES

39. NOT GIVEN

40. YES

## A 类写作

### Writing material: c2-t2-w-1

Original grouped bar chart inspected. Title: Leisure time in a typical week: by sex and employment status, 1998–99. Vertical axis: hours of leisure time, 0–100. Categories employed full time, employed part time, unemployed, retired, housewives. Dark bars are males, light bars females. Values are approximate visual estimates: full-time employed men about 47 hours and women about 38; part-time employed women about 40, with no male bar supplied; unemployed men about 85 and women about 75; retired men about 85 and women about 75; housewives about 50 hours, with no male bar supplied. Unemployed and retired groups have the most leisure; full-time workers have less. Men have more leisure in the three directly comparable groups. Absent male bars are not evidence of zero leisure or no men in those employment categories.



### Writing material: c2-t2-w-2

Opinion task: respond to the stated claim and justify the chosen position; no particular stance is required.



## 口语

### 原书口语任务 · reference on source page 24

Information for the Examiner:
the type of concert rock/folk/jazz/classical
the location city stadium
the cost $55/£25
transport to and from the concert bus (hard to park car)
the audience 500-1,000 people, lots of audience
participation
the length of the concert 3 hours
his/her opinion of the concert really enjoyed it

[Complete original page](assets/0640e8ea943686042ec36e806b57a195655aca3f675d7d30ae94272c0c68fdac.jpg)
