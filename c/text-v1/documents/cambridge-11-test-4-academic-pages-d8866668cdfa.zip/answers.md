# 剑雅 11 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 129

TEST 4 LISTENING
1 secondary
2 flute
3 cinema
4 concert
5 market
6 Bythwaite
7 actor
8 A
9 B
10 C
11 E
12 D
13 G
14 B
15 C
16 A
17 F
18 H
19 C
20 B
21 B
22 D
23 A
24 B
25 B
26 E
27 C
28 A
29 A
30 C
31 dry
32 hard
33 sugar/sugars
34 roots
35 moist/damp/wet
36 variety
37 cattle
38 gardens/gardening
39 grasses
40 payment/payments / money
21&22 IN EITHER ORDER: B,D
23&24 IN EITHER ORDER: A,B
25&26 IN EITHER ORDER: B,E
If you score: 0–14 unlikely, 15–28 may, 29–40 likely to get an acceptable score. Improve English or consider practice/lessons; institutions accept different scores.

1. secondary

2. flute

3. cinema

4. concert

5. market

6. Bythwaite

7. actor

8. A

9. B

10. C

### Part 2 · source page 129

TEST 4 LISTENING
1 secondary
2 flute
3 cinema
4 concert
5 market
6 Bythwaite
7 actor
8 A
9 B
10 C
11 E
12 D
13 G
14 B
15 C
16 A
17 F
18 H
19 C
20 B
21 B
22 D
23 A
24 B
25 B
26 E
27 C
28 A
29 A
30 C
31 dry
32 hard
33 sugar/sugars
34 roots
35 moist/damp/wet
36 variety
37 cattle
38 gardens/gardening
39 grasses
40 payment/payments / money
21&22 IN EITHER ORDER: B,D
23&24 IN EITHER ORDER: A,B
25&26 IN EITHER ORDER: B,E
If you score: 0–14 unlikely, 15–28 may, 29–40 likely to get an acceptable score. Improve English or consider practice/lessons; institutions accept different scores.

11. E

12. D

13. G

14. B

15. C

16. A

17. F

18. H

19. C

20. B

### Part 3 · source page 129

TEST 4 LISTENING
1 secondary
2 flute
3 cinema
4 concert
5 market
6 Bythwaite
7 actor
8 A
9 B
10 C
11 E
12 D
13 G
14 B
15 C
16 A
17 F
18 H
19 C
20 B
21 B
22 D
23 A
24 B
25 B
26 E
27 C
28 A
29 A
30 C
31 dry
32 hard
33 sugar/sugars
34 roots
35 moist/damp/wet
36 variety
37 cattle
38 gardens/gardening
39 grasses
40 payment/payments / money
21&22 IN EITHER ORDER: B,D
23&24 IN EITHER ORDER: A,B
25&26 IN EITHER ORDER: B,E
If you score: 0–14 unlikely, 15–28 may, 29–40 likely to get an acceptable score. Improve English or consider practice/lessons; institutions accept different scores.

21. B / D

22. B / D

23. A / B

24. A / B

25. B / E

26. B / E

27. C

28. A

29. A

30. C

### Part 4 · source page 129

TEST 4 LISTENING
1 secondary
2 flute
3 cinema
4 concert
5 market
6 Bythwaite
7 actor
8 A
9 B
10 C
11 E
12 D
13 G
14 B
15 C
16 A
17 F
18 H
19 C
20 B
21 B
22 D
23 A
24 B
25 B
26 E
27 C
28 A
29 A
30 C
31 dry
32 hard
33 sugar/sugars
34 roots
35 moist/damp/wet
36 variety
37 cattle
38 gardens/gardening
39 grasses
40 payment/payments / money
21&22 IN EITHER ORDER: B,D
23&24 IN EITHER ORDER: A,B
25&26 IN EITHER ORDER: B,E
If you score: 0–14 unlikely, 15–28 may, 29–40 likely to get an acceptable score. Improve English or consider practice/lessons; institutions accept different scores.

31. dry

32. hard

33. sugar / sugars

34. roots

35. moist / damp / wet

36. variety

37. cattle

38. gardens / gardening

39. grasses

40. payment / payments / money

## A 类阅读

### Academic Reading · source page 130

TEST 4 READING — original printed answer key
1 FALSE
2 NOT GIVEN
3 NOT GIVEN
4 TRUE
5 A
6 C
7 B
8 A
9 A
10 D
11 B
12 E
13 F
14 B
15 A
16 B
17 D
18 C
19 D
20 TRUE
21 TRUE
22 NOT GIVEN
23 TRUE
24 FALSE
25 C
26 A
27 vi
28 iv
29 ii
30 vii
31 i
32 v
33 E
34 G
35 B
36 F
37 NO
38 YES
39 NOT GIVEN
40 YES
If you score: 0–12 unlikely,13–25 may,26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.
SOURCE ERRATUM c11-t4-reading-19-26-20261024: the printed Q19–26 sequence is misnumbered. Verified corrections for future sessions: 19 TRUE;20 TRUE;21 NOT GIVEN;22 TRUE;23 FALSE;24 C;25 A;26 E. Original source page retained for comparison. Existing submitted results and active snapshots are preserved.

1. FALSE

2. NOT GIVEN

3. NOT GIVEN

4. TRUE

5. A

6. C

7. B

8. A

9. A

10. D

11. B

12. E

13. F

14. B

15. A

16. B

17. D

18. C

19. TRUE

20. TRUE

21. NOT GIVEN

22. TRUE

23. FALSE

24. C

25. A

26. E

27. vi

28. iv

29. ii

30. vii

31. i

32. v

33. E

34. G

35. B

36. F

37. NO

38. YES

39. NOT GIVEN

40. YES

## A 类写作

### Writing material: c11-t4-w-1

Visitor counts before/after refurbishment74,000/92,000. Survey percentages before→after: very satisfied15→35; satisfied30→40; dissatisfied40→15; very dissatisfied10→5; no response5→5. Pie pattern legend checked. Combined satisfied45→75%; combined dissatisfied50→20%; visitor number rises18,000. Counts and survey percentages have different denominators; survey sample size not given, so do not multiply survey shares by all visitors as an established count. No dates, costs or causal study provided.



### Writing material: c11-t4-w-2

Discuss economic progress as the most important goal and other progress as equally important, with an opinion. Other goals are not necessarily claimed to be more important; preserve that distinction.



## 口语
