# 剑雅 11 · Test 4

Text edition · verified

> Approved source erratum: reading Q19–26 were misnumbered in the source answer key. Corrected against question types, passage evidence and the accompanying reading analysis. Applies to new sessions only; stored submissions and active snapshots are unchanged.

## 听力

### Part 1

<!-- Source: /api/assets/48ab961bd136c6aa30c76cfd428349e079f603a652283b4904df0682aff6a2a1.jpg; PDF page 79; full -->

```text
SECTION 1 Questions 1–10
Questions 1–7
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
| Event | Cost | Venue | Notes |
| --- | --- | --- | --- |
| Jazz band | Example: Tickets available for £15 | The (1) __________ school | Also appearing: Carolyn Hart (plays the (2) __________) |
| Duck races | £1 per duck | Start behind the (3) __________ | Prize: tickets for (4) __________ held at the end of the festival. Ducks can be bought in the (5) __________ |
| Flower show | Free | (6) __________ Hall | Prizes presented at 5 pm by a well-known (7) __________ |
```

[Original question page](assets/48ab961bd136c6aa30c76cfd428349e079f603a652283b4904df0682aff6a2a1.jpg)

<!-- Source: /api/assets/984f195453d9147628f5733ca5246cd34691066332f1459536ba106a3a1d5c86.jpg; PDF page 80; full -->

```text
Questions 8-10
Who is each play suitable for？
Write the correct letter, A, B or C, next to Questions 8-10.
Plays
A mainly for children
B mainly foradults
C suitable for people of all ages
8 The Mystery of Muldoon
9 Fire and Flood
10 Silly Sailor
```

[Original question page](assets/984f195453d9147628f5733ca5246cd34691066332f1459536ba106a3a1d5c86.jpg)

### Part 2

<!-- Source: /api/assets/0d2757f015e26bfc785f9807a9f3e445cfef952444119ee12f7322cd80d13573.jpg; PDF page 81; full -->

```text
SECTION 2 Questions 11-20
Questions 11-16
What does the speaker say about each of the following collections?
Choose SIX answers from the box and write the correct letter, A-G, next to Questions
11-16.
collections
commen ts
A was given by one person
B was recently publicised in the media
C includes some items given by members of the
public
D includes some items given by the artists
E includes the most popular exhibits in the
museum
F is the largest of its kind in the country
G has had some of its contents relocated
11 20th- and 21st-century paintings
12 19th-century paintings
13 Sculptures
14 ‘Around the world’ exhibition
15 Coins
16 Porcelain and glass
82
```

[Original question page](assets/0d2757f015e26bfc785f9807a9f3e445cfef952444119ee12f7322cd80d13573.jpg)

<!-- Source: /api/assets/7181d2685aaf87ab19c7f9da230d868fc27949fd6f7dd815e2918af6eb1a9089.jpg; PDF page 82; full -->

```text
Questions 17–20
Label the plan below. Write the correct letter, A–H, next to Questions 17–20.
Basement of museum
[Original plan retained: A–H, sitting area, toilets and stairs.]
17 restaurant __________
18 café __________
19 baby-changing facilities __________
20 cloakroom __________
```

[Original question page](assets/7181d2685aaf87ab19c7f9da230d868fc27949fd6f7dd815e2918af6eb1a9089.jpg)

![Original figure](assets/7181d2685aaf87ab19c7f9da230d868fc27949fd6f7dd815e2918af6eb1a9089.jpg)

### Part 3

<!-- Source: /api/assets/09b577e0e95e6c352112ead6af04b9dee69b627608473e1baa5da85999648dac.jpg; PDF page 83; full -->

```text
SECTION 3 Questions 21–30
Questions 21 and 22
Choose TWO letters, A–E.
Which TWO characteristics were shared by the subjects of Joanna’s psychology study?
A They had all won prizes for their music.
B They had all made music recordings.
C They were all under 27 years old.
D They had all toured internationally.
E They all played a string instrument.
Questions 23 and 24
Choose TWO letters, A–E.
Which TWO points does Joanna make about her use of telephone interviews?
A It meant rich data could be collected.
B It allowed the involvement of top performers.
C It led to a stressful atmosphere at times.
D It meant interview times had to be limited.
E It caused some technical problems.
Questions 25 and 26
Choose TWO letters, A–E.
Which TWO topics did Joanna originally intend to investigate in her research?
A regulations concerning concert dress
B audience reactions to the dress of performers
C changes in performer attitudes to concert dress
D how choice of dress relates to performer roles
E links between musical instrument and dress choice
```

[Original question page](assets/09b577e0e95e6c352112ead6af04b9dee69b627608473e1baa5da85999648dac.jpg)

<!-- Source: /api/assets/00a5d355a8f3572651c5dda795db42249ff021aa1e5fff6ce54d705674fb947e.jpg; PDF page 84; full -->

```text
Questions 27-30
Choose the correct letter, A, B or C.
27 Joanna concentrated on women performers because
A women are more influenced by fashion.
B women’s dress has led to more controversy.
C women’s code of dress is less strict than men’s
28 Mike Frost’s article suggests that in popular music, women’s dress is affected by
A their wish to be taken seriously.
B their tendency to copy each other．
C their reaction to the masculine nature of the music.
29 What did Joanna’s subjects say about the audience at a performance?
A The musicians' choice of clothing is linked to respect for the audience.
B The clothing should not distract the audience from the music.
C The audience should make the effort to dress appropriately.
30 According to the speakers, musicians could learn from sports scientists about
A the importance of clothing for physical freedom.
B the part played by clothing in improving performance.
C the way clothing may protect against physical injury.
85
```

[Original question page](assets/00a5d355a8f3572651c5dda795db42249ff021aa1e5fff6ce54d705674fb947e.jpg)

### Part 4

<!-- Source: /api/assets/099a3702b8e0356814faec26e72d2638d4307118afa4623f78d969e3e94ea755.jpg; PDF page 85; full -->

```text
SECTION 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
The use of soil to reduce carbon dioxide (CO2) in the atmosphere
Rattan Lal:
– Claims that 13% of CO2 in the atmosphere could be absorbed by agricultural soils
– Erosion is more likely in soil that is (31) __________
– Lal found soil in Africa that was very (32) __________
– It was suggested that carbon from soil was entering the atmosphere
Soil and carbon:
– plants turn CO2 from the air into carbon-based substances such as (33) __________
– some CO2 moves from the (34) __________ of plants to microbes in the soil
– carbon was lost from the soil when agriculture was invented
Regenerative agriculture:
– uses established practices to make sure soil remains fertile and (35) __________
– e.g. through year-round planting and increasing the (36) __________ of plants that are grown
California study:
– taking place on a big (37) __________ farm
– uses compost made from waste from agriculture and (38) __________
Australia study:
– aims to increase soil carbon by using (39) __________ that are always green
Future developments may include:
– reducing the amount of fertilizer used in farming
– giving farmers (40) __________ for carbon storage, as well as their produce
```

[Original question page](assets/099a3702b8e0356814faec26e72d2638d4307118afa4623f78d969e3e94ea755.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/0ff03d0c8c27f16b93f45ddc82615ec8ed940519634c1acf69dddc3f9fdab1ad.jpg; PDF page 86; full -->

```text
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Research using twins
To biomedical researchers all over the
world, twins offer a precious opportunity
to untangle the influence of genes and
the environment — of nature and nurture.
Because identical twins come from a
single fertilized egg that splits into two,
they share virtually the same genetic
code. Any differences between them —
one twin having younger looking skin, for
example — must be due to environmental
factors such as less time spent in the sun.
Alternatively, by comparing the
experiences of identical twins with
those of fraternal twins, who come from
separate eggs and share on average
half their DNA, researchers can quantify
the extent to which our genes affect our
lives. If identical twins are more similar
to each other with respect to an ailment
than fraternal twins are, then vulnerability
to the disease must be rooted at least in
part in heredity.
These two lines of research — studying
the differences between identical twins
to pinpoint the influence of environment,
and comparing identical twins with
fraternal ones to measure the role
of inheritance — have been crucial to
understanding the interplay of nature and
nurture in determining our personalities,
behavior, and vulnerability to disease.
The idea of using twins to measure the
influence of heredity dates back to 1875,
when the English scientist Francis Galton
first suggested the approach (and coined
the phrase ‘nature and nurture’). But
twin studies took a surprising twist in
the 1980s, with the arrival of studies into
identical twins who had been separated
at birth and reunited as adults. Over two
decades 137 sets of twins eventually
visited Thomas Bouchard's lab in what
became known as the Minnesota Study of
Twins Reared Apart. Numerous tests were
carried out on the twins, and they were
each asked more than 15,000 questions.
Bouchard and his colleagues used this
mountain of data to identify how far
twins were affected by their genetic
makeup. The key to their approach was
a statistical concept called heritability.
In broad terms, the heritability of a trait
measures the extent to which differences
among members of a population can be
explained by differences in their genetics.
And wherever Bouchard and other
scientists looked, it seemed, they found
the invisible hand of genetic influence
helping to shape our lives.
Lately, however, twin studies have helped
lead scientists to a radical new conclusion:
that nature and nurture are not the only
87
```

[Original question page](assets/0ff03d0c8c27f16b93f45ddc82615ec8ed940519634c1acf69dddc3f9fdab1ad.jpg)

<!-- Source: /api/assets/fd0d6f28c34416f02845828dba393e3244bfe35fe040a03cfb7fb2d18d5ebaf3.jpg; PDF page 87; full -->

```text
elemental forces at work. According to a
recent field called epigenetics, there is a
third factor also in play, one that in some
cases serves as a bridge between the
environment and our genes, and in others
operates on its own to shape who we are.
Epigenetic processes are chemical
reactions tied to neither nature nor
nurture but representing what researchers
have called a ‘third component’. These
reactions influence how our genetic
code is expressed: how each gene is
strengthened or weakened, even turned
on or off, to build our bones, brains and
all the other parts of our bodies.
If you think of our DNA as an immense
piano keyboard and our genes as the keys
—each key symbolizing a segment of DNA
responsible for a particular note, or trait,
and all the keys combining to make us
who we are — then epigenetic processes
determine when and how each key can be
struck, changing the tune being played.
One way the study of epigenetics is
revolutionizing our understanding of
biology is by revealing a mechanism by
which the environment directly impacts on
genes. Studies of animals, for example,
have shown that when a rat experiences
stress during pregnancy, it can cause
epigenetic changes in a fetus that lead to
behavioral problems as the rodent grows
up. Other epigenetic processes appear to
occur randomly, while others are normal,
such as those that guide embryonic cells
as they become heart, brain, or liver cells,
for example.
Geneticist Danielle Reed has worked with
many twins over the years and thought
deeply about what twin studies have
taught us. ‘It's very clear when you look
at twins that much of what they share
is hardwired,’ she says. ‘Many things
about them are absolutely the same and
unalterable. But it’s also clear, when you
get to know them, that other things about
them are different. Epigenetics is the
origin of a lot of those differences, in my
view.
Reed credits Thomas Bouchard’s work for
today’s surge in twin studies. ‘He was the
trailblazer,’ she says. ‘We forget that 50
years ago things like heart disease were
thought to be caused entirely by lifestyle.
Schizophrenia was thought to be due
to poor mothering. Twin studies have
allowed us to be more reflective about
what people are actually born with and
what's caused by experience.’
Having said that, Reed adds, the latest
work in epigenetics promises to take our
understanding even further. ‘What I like
to say is that nature writes some things in
pencil and some things in pen,’ she says.
‘Things written in pen you can’t change.
That's DNA. But things written in pencil
you can. That's epigenetics. Now that
we're actually able to look at the DNA
and see where the pencil writings are, it’s
sort of a whole new world.’
```

[Original question page](assets/fd0d6f28c34416f02845828dba393e3244bfe35fe040a03cfb7fb2d18d5ebaf3.jpg)

<!-- Source: /api/assets/d72ab434e0d1283a9f775be6c1a2fead30efabc0ca29cf8e7841c1a4f13d58b2.jpg; PDF page 88; full -->

```text
Questions 1-4
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-4 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 There may be genetic causes for the differences in how young the skin of identical
twins looks.
2 Twins are at greater risk of developing certain illnesses than non-twins.
3 Bouchard advertised in newspapers for twins who had been separated at birth.
4 Epigenetic processes are different from both genetic and environmental processes.
Questions 5–9
Look at the following statements (Questions 5-9) and the list of researchers below.
Match each statement with the correct researcher, A, B or C.
Write the correct letter, A, B or C, in boxes 5-9 on your answer sheet.
NB You may use any letter more than once.
List of Researchers
A Francis Galton
B Thomas Bouchard
C Danielle Reed
5 invented a term used to distinguish two factors affecting human characteristics
6 expressed the view that the study of epigenetics will increase our knowledge
7 developed a mathematical method of measuring genetic influences
8 pioneered research into genetics using twins
9 carried out research into twins who had lived apart
89
```

[Original question page](assets/d72ab434e0d1283a9f775be6c1a2fead30efabc0ca29cf8e7841c1a4f13d58b2.jpg)

<!-- Source: /api/assets/ba1d2aa24c07d3820713d6b79a6e1dedbc2c8c097afff6d4f78172555ec3376f.jpg; PDF page 89; full -->

```text
Questions 10-13
Complete the summary using the list of words, A-F, below.
Write the correct letter, A-F, in boxes 10-13 on your answer sheet.
Epigenetic processes
In epigenetic processes, 10 .... .... ..... . .. influence the activity of our genes, for example
in creating our internal 11 ... . .... . …... . The study of epigenetic processes is uncovering
a way in which our genes can be affected by our 12 .................... One example is that
if a pregnant rat suffers stress, the new-born rat may later show problems in its
13 ...
90
A nurture
D chemicals
B organs
E environment
C code
F behaviour/behavior
```

[Original question page](assets/ba1d2aa24c07d3820713d6b79a6e1dedbc2c8c097afff6d4f78172555ec3376f.jpg)

<!-- Source: /api/assets/b391d2ffe957dfc8f0c4843e3bcb525a478abcaef76a557bc0679ccd55998f3a.jpg; PDF page 90; full -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
An Introduction to Film Sound
Though we might think of film as an
essentially visual experience, we really
cannot afford to underestimate the
importance of film sound. A meaningful
sound track is often as complicated as
the image on the screen, and is ultimately
just as much the responsibility of the
director. The entire sound track consists
of three essential ingredients: the human
voice, sound effects and music. These
three tracks must be mixed and balanced
so as to produce the necessary emphases
which in turn create desired effects.
Topics which essentially refer to the
three previously mentioned tracks are
discussed below. They include dialogue,
synchronous and asynchronous sound
effects, and music.
Let us start with dialogue. As is the case
with stage drama, dialogue serves to
tell the story and expresses feelings and
motivations of characters as well. Often
with film characterization the audience
perceives little or no difference between
the character and the actor. Thus, for
example, the actor Humphrey Bogart is
the character Sam Spade; film personality
and life personality seem to merge.
Perhaps this is because the very texture of
a performer’s voice supplies an element
of character.
When voice textures fit the performer’s
physiognomy and gestures, a whole
and very realistic persona emerges. The
viewer sees not an actor working at his
craft, but another human being struggling
with life. It is interesting to note that how
dialogue is used and the very amount of
dialogue used varies widely among films.
For example, in the highly successful
science-fiction film 2001, little dialogue
was evident, and most of it was banal
and of little intrinsic interest. In this
way the film-maker was able to portray
what Thomas Sobochack and Vivian
Sobochack call, in An Introduction to Film,
the ‘inadequacy of human responses
when compared with the magnificent
technology created by man and the visual
beauties of the universe’.
The comedy Bringing Up Baby, on the
other hand, presents practically non-stop
dialogue delivered at breakneck speed.
This use of dialogue underscores not
only the dizzy quality of the character
played by Katherine Hepburn, but also
the absurdity of the film itself and thus its
humor. The audience is bounced from gag
to gag and conversation to conversation;
there is no time for audience reflection.
The audience is caught up in a whirlwind
of activity in simply managing to follow
the plot. This film presents pure escapism
— largely due to its frenetic dialogue.
Synchronous sound effects are those
sounds which are synchronized or
91
```

[Original question page](assets/b391d2ffe957dfc8f0c4843e3bcb525a478abcaef76a557bc0679ccd55998f3a.jpg)

<!-- Source: /api/assets/c590fb3dbe3969502e2b94a4b17e69b32eb1b60b97baf902853b383ea39fd56f.jpg; PDF page 91; full -->

```text
matched with what is viewed. For
example, if the film portrays a character
playing the piano, the sounds of the
piano are projected. Synchronous sounds
contribute to the realism of film and also
help to create a particular atmosphere.
For example, the ‘click’ of a door being
opened may simply serve to convince
the audience that the image portrayed
is real, and the audience may only
subconsciously note the expected sound.
However, if the ‘click’ of an opening
door is part of an ominous action such
as a burglary, the sound mixer may call
attention to the ‘click’ with an increase in
volume; this helps to engage the audience
in a moment of suspense.
Asynchronous sound effects, on the other
hand, are not matched with a visible
source of the sound on screen. Such
sounds are included so as to provide an
appropriate emotional nuance, and they
may also add to the realism of the film.
For example, a film-maker might opt
to include the background sound of an
ambulance’s siren while the foreground
sound and image portrays an arguing
couple. The asynchronous ambulance
siren underscores the psychic injury
incurred in the argument; at the same
time the noise of the siren adds to the
realism of the film by acknowledging the
film’s city setting.
We are probably all familiar with
background music in films, which has
become so ubiquitous as to be noticeable
in its absence. We are aware that it is used
to add emotion and rhythm. Usually not
meant to be noticeable, it often provides
a tone or an emotional attitude toward
the story and/or the characters depicted.
In addition, background music often
foreshadows a change in mood. For
example, dissonant music may be used in
film to indicate an approaching (but not
yet visible) menace or disaster.
Background music may aid viewer
understanding by linking scenes. For
example, a particular musical theme
associated with an individual character
or situation may be repeated at various
points in a film in order to remind the
audience of salient motifs or ideas.
Film sound comprises conventions and
innovations. We have come to expect an
acceleration of music during car chases
and creaky doors in horror films. Yet, it
is important to note as well that sound
is often brilliantly conceived. The effects
of sound are often largely subtle and
often are noted by only our subconscious
minds. We need to foster an awareness of
film sound as well as film space so as to
truly appreciate an art form that sprang
to life during the twentieth century — the
modern film.
```

[Original question page](assets/c590fb3dbe3969502e2b94a4b17e69b32eb1b60b97baf902853b383ea39fd56f.jpg)

<!-- Source: /api/assets/0f7fd02f56a6deb1d25eaa26068862df21db9601351e4f7e885cde39330b090c.jpg; PDF page 92; full -->

```text
Questions 14-18
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 14-18 on your answer sheet.
14 In the first paragraph, the writer makes a point that
A the director should plan the sound track at an early stage in filming.
B it would be wrong to overlook the contribution of sound to the artistry of films.
C the music industry can have a beneficial influence on sound in film.
D it is important for those working on the sound in a film to have sole
responsibility for it.
15 One reason that the writer refers to Humphrey Bogart is to exemplify
A the importance of the actor and the character appearing to have similar
personalities.
B the audience’s wish that actors are visually appropriate for theirroles.
C the value of the actor having had similar feelings to the character.
D the audience’s preference for dialogue to be as authentic as possible.
16 In the third paragraph, the writer suggests that
A audiences are likely to be critical of film dialogue that does not reflect their own
experience.
B film dialogue that appears to be dull may have a specific purpose.
C filmmakers vary considerably in the skill with which they handle dialogue.
D the most successful films are those with dialogue of a high quality.
17 What does the writer suggest about Bringing Up Baby?
A The plot suffers from the filmmaker’s wish to focus on humorous dialogue.
B The dialogue helps to make it one of the best comedy films ever produced.
C There is a mismatch between the speed of the dialogue and the speed of
actions.
D The nature of the dialogue emphasises key elements of the film.
18 The writer refers to the 'click’ of a door to make the point that realistic sounds
A are often used to give the audience a false impression of events in the film.
B may be interpreted in different ways by different members of the audience.
C may be modified in Order to manipulate the audience’s response to the film.
D tend to be more significant in films presenting realistic situations.
93
```

[Original question page](assets/0f7fd02f56a6deb1d25eaa26068862df21db9601351e4f7e885cde39330b090c.jpg)

<!-- Source: /api/assets/0b5a8001b6adf1a9594c663a37fafef6e3c8635bef88150f5fe9f596ace86bb7.jpg; PDF page 93; full -->

```text
Questions 19-23
Do the following statements agree with the information given in Reading Passage 2?
In boxes 19-23 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
19 Audiences are likely to be surprised if a film lacks background music.
20 Background music may anticipate a development in a film.
21 Background music has more effect on some people than on others.
22 Background music may help the audience to make certain connections within
the film.
23 Audiences tend to be aware of how the background music is affecting them.
94
```

[Original question page](assets/0b5a8001b6adf1a9594c663a37fafef6e3c8635bef88150f5fe9f596ace86bb7.jpg)

<!-- Source: /api/assets/e7e25b299ab88eb9f908c6a6b82489b53fbab2ef7c3c4218bac6bb3684ffb6ba.jpg; PDF page 94; full -->

```text
Questions 24-26
Complete each sentence with the correct ending, A-E, below.
Write the correct letter, A-E, in boxes 24-26 on your answer sheet.
24 The audience’s response to different parts of a film can be controlled
25 The feelings and motivations of characters become clear
26 A character seems to be a real person rather than an actor
A when the audience listens to the dialogue.
B if the film reflects the audience’s own concerns.
C if voice, sound and music are combined appropriately.
D when the director is aware of how the audience will respond.
E when the actor's appearance, voice and moves are
consistent with each other.
95
```

[Original question page](assets/e7e25b299ab88eb9f908c6a6b82489b53fbab2ef7c3c4218bac6bb3684ffb6ba.jpg)

<!-- Source: /api/assets/8daca3e0ab0796dc01842a3fc28fa8b03432a80e02cb82f361d0374d0aaa643b.jpg; PDF page 95; full -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 on the following pages.
Questions 27-32
Reading Passage 3 has six paragraphs, A-F.
Choose the correct heading for paragraphs A-F from the list of headings below.
Write the correct number, i-vii, in boxes 27-32 on your answer sheet.
List of Headings
i Differences between languages highlight their impressiveness
ii The way in which a few sounds are organised to convey a huge
range of meaning
iii Why the sounds used in different languages are not identical
iv Apparently incompatible characteristics of language
v Even silence can be meaningful
vi Why language is the most important invention of all
vii The universal ability to use language
27 Paragraph A
28 Paragraph B
29 Paragraph C
30 Paragraph D
31 Paragraph E
32. Paragraph F
96
```

[Original question page](assets/8daca3e0ab0796dc01842a3fc28fa8b03432a80e02cb82f361d0374d0aaa643b.jpg)

<!-- Source: /api/assets/b2ec79c74c72f5200772ba17fe74bd86fa39e4d3f83144ac03e7072b945077d9.jpg; PDF page 96; full -->

```text
‘This Marvellous Invention’
A Of all mankind’s manifold creations, language must take pride of place. Other inventions -
the wheel, agriculture, sliced bread - may have transformed our material existence, but the
advent of language is what made us human. Compared to language, all other inventions pale
in significance, since everything we have ever achieved depends on language and originates
from it. Without language, we could never have embarked on our ascent to unparalleled
power over all other animals, and even over nature itself.
B But language is foremost not just because it came first. In its own right it is a tool of
extraordinary sophistication, yet based on an idea of ingenious simplicity: ‘this marvellous
invention of composing out of twenty-five or thirty sounds that infinite variety of
expressions which, whilst having in themselves no likeness to what is in our mind, allow
us to disclose to others its whole secret, and to make known to those who cannot penetrate
it all that we imagine, and all the various stirrings of our soul.’ This was how, in 1660,
the renowned French grammarians of the Port-Royal abbey near Versailles distilled the
essence of language, and no one since has celebrated more eloquently the magnitude of its
achievement. Even so, there is just one flaw in all these hymns of praise, for the homage to
language's unique accomplishment conceals a simple yet critical incongruity. Language is
mankind’s greatest invention - except, of course, that it was never invented. This apparent
paradox is at the core of our fascination with language, and it holds many of its secrets.
C Language often seems so skillfully drafted that one can hardly imagine it as anything other
than the perfected handiwork of a master craftsman. How else could this instrument
make so much out of barely three dozen measly morsels of sound? In themselves, these
configurations of mouth ~ p,f-b,v,t,d,k,g,sh,a,e and so on — amount to nothing more than a
few haphazard spits and splutters, random noises with no meaning, no ability to express,
no power to explain. But run them through the cogs and wheels of the language machine,
let it arrange them in some very special orders, and there is nothing that these meaningless
streams of air cannot do: from sighing the interminable boredom of existence to unravelling
the fundamental order of the universe.
D The most extraordinary thing about language, however, is that one doesn't have to be a
genius to set its wheels in motion. The language machine allows just about everybody -
from pre-modern foragers in the subtropical savannah, to post-modern philosophers in the
suburban sprawl - to tie these meaningless sounds together into an infinite variety of subtle
senses, and all apparently without the slightest exertion. Yet it is precisely this deceptive ease
which makes language a victim of its own success, since in everyday life its triumphs are
usually taken for granted. The wheels of language run so smoothly that one rarely bothers to
stop and think about all the resourcefulness and expertise that must have gone into making
it tick. Language conceals art.
97
```

[Original question page](assets/b2ec79c74c72f5200772ba17fe74bd86fa39e4d3f83144ac03e7072b945077d9.jpg)

<!-- Source: /api/assets/7c97a6c12b5e473b1521054efc56ee337fb2dfaae17503b754df330d212ebe68.jpg; PDF page 97; full -->

```text
E Often, it is only the estrangement of foreign tongues, with their many exotic and outlandish
features, that brings home the wonder of language’s design. One of the showiest stunts that
some languages can pull off is an ability to build up words of breath-breaking length, and
thus express in one word what English takes a whole sentence to say. The Turkish word
şehirliliştiremediklerimizdensiniz, to take one example, means nothing less than ‘you are
one of those whom we can't turn into a town-dweller’ (In case you were wondering, this
monstrosity really is one word, not merely many different words squashed together - most of
its components cannot even stand up on their own.)
F And if that sounds like some one-off freak, then consider Sumerian, the language spoken
on the banks of the Euphrates some 5,000 years ago by the people who invented writing
and thus enabled the documentation of history. A Sumerian word like munintuma’a (‘when
he had made it suitable for her’) might seem rather trim compared to the Turkish colossus
above. What is so impressive about it, however, is not its lengthiness but rather the reverse
~ the thrifty compactness of its construction. The word is made up of different slots, each
corresponding to a particular portion of meaning. This sleek design allows single sounds
to convey useful information, and in fact even the absence of a sound has been enlisted to
express something specific. If you were to ask which bit in the Sumerian word corresponds
to the pronoun ‘it’ in the English translation ‘when he had made it suitable for her, then the
answer would have to be nothing. Mind you, a very particular kind of nothing: the nothing
that stands in the empty slot in the middle. The technology is so fine-tuned then that even a
non-sound, when carefully placed in a particular position, has been invested with a specific
function. Who could possibly have come up with such a nifty contraption?
```

[Original question page](assets/7c97a6c12b5e473b1521054efc56ee337fb2dfaae17503b754df330d212ebe68.jpg)

<!-- Source: /api/assets/06e1ee6fb404771dc4141b53abea12ea06c01b73745ce6e390661194d19ddc28.jpg; PDF page 98; full -->

```text
Questions 33-36
Complete the summary using the list of words, A-G, below.
Write the correct letter, A-G, in boxes 33-36 on your answer sheet.
The importance of language
The wheel is one invention that has had a major impact on 33 .. ... ..... aspects of
life, but no impact has been as 34 ... ... as that of language. Language is very
35 .........…......…，yet composed of just a small number of sounds.
Language appears to be 36 ..... ………to use. However, its sophistication is often
overlooked.
A difficult
D admired
G fundamental
Questions 37-40
B complex
E material
C original
F easy
Do the following statements agree with the views of the writer in Reading Passage 3?
In boxes 37-40 on your answer sheet, write
YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
37 Human beings might have achieved their present position without language.
38 The Port-Royal grammarians did justice to the nature of language.
39 A complex idea can be explained more clearly in a sentence than in a single word.
40 The Sumerians were responsible for starting the recording of events.
99
```

[Original question page](assets/06e1ee6fb404771dc4141b53abea12ea06c01b73745ce6e390661194d19ddc28.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/164ecec41d49dbb558a20f8f20a2dd8fc14a8241f36c30a89e08134901a4edbf.jpg; PDF page 99; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The table below shows the numbers of visitors to Ashdown Museum during the year before and the year after it was refurbished. The charts show the result of surveys asking visitors how satisfied they were with their visit, during the same two periods.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/164ecec41d49dbb558a20f8f20a2dd8fc14a8241f36c30a89e08134901a4edbf.jpg)

![Original figure](assets/164ecec41d49dbb558a20f8f20a2dd8fc14a8241f36c30a89e08134901a4edbf.jpg)

### Task 2

<!-- Source: /api/assets/ec7c23237105c5ab90d45df7bd732fb5fbd9700a4b6a659a987a79a313f09322.jpg; PDF page 100; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Many governments think that economic progress is their most important goal. Some people, however, think that other types of progress are equally important for a country.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/ec7c23237105c5ab90d45df7bd732fb5fbd9700a4b6a659a987a79a313f09322.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/012147acad68c70b79352ff2e8b08dd6c19aa092ee698b1082b24ea3616df421.jpg; PDF page 101; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies
and other familiar topics.
EXAMPLE
Names
How did your parents choose your name(s)? 
• Does your name have any special meaning?
Is your name common or unusual in your country?
If you could change your name, would you? [Why/Why not?]
PART 2
Describe a TV documentary you watched
that was particularly interesting.
You should say:
what the documentary was about
why you decided to watch it
what you learnt during the documentary
and explain why the TV documentary was
particularly interesting.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Different types of TV programmes
Example questions:
What are the most popular kinds of TV programmes in your country? Why is this?
Do you think there are too many game shows on TV nowadays? Why?
Do you think TV is the main way for people to get the news in your country？What other
ways are there?
TV advertising
Example questions:
What types of products are advertised most often on TV?
Do you think that people pay attention to adverts on TV? Why do you think that is?
How important are regulations on TV advertising?
102
```

[Original question page](assets/012147acad68c70b79352ff2e8b08dd6c19aa092ee698b1082b24ea3616df421.jpg)

### Part 2

<!-- Source: /api/assets/012147acad68c70b79352ff2e8b08dd6c19aa092ee698b1082b24ea3616df421.jpg; PDF page 101; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies
and other familiar topics.
EXAMPLE
Names
How did your parents choose your name(s)? 
• Does your name have any special meaning?
Is your name common or unusual in your country?
If you could change your name, would you? [Why/Why not?]
PART 2
Describe a TV documentary you watched
that was particularly interesting.
You should say:
what the documentary was about
why you decided to watch it
what you learnt during the documentary
and explain why the TV documentary was
particularly interesting.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Different types of TV programmes
Example questions:
What are the most popular kinds of TV programmes in your country? Why is this?
Do you think there are too many game shows on TV nowadays? Why?
Do you think TV is the main way for people to get the news in your country？What other
ways are there?
TV advertising
Example questions:
What types of products are advertised most often on TV?
Do you think that people pay attention to adverts on TV? Why do you think that is?
How important are regulations on TV advertising?
102
```

[Original question page](assets/012147acad68c70b79352ff2e8b08dd6c19aa092ee698b1082b24ea3616df421.jpg)

### Part 3

<!-- Source: /api/assets/012147acad68c70b79352ff2e8b08dd6c19aa092ee698b1082b24ea3616df421.jpg; PDF page 101; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies
and other familiar topics.
EXAMPLE
Names
How did your parents choose your name(s)? 
• Does your name have any special meaning?
Is your name common or unusual in your country?
If you could change your name, would you? [Why/Why not?]
PART 2
Describe a TV documentary you watched
that was particularly interesting.
You should say:
what the documentary was about
why you decided to watch it
what you learnt during the documentary
and explain why the TV documentary was
particularly interesting.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.
PART 3
Discussion topics:
Different types of TV programmes
Example questions:
What are the most popular kinds of TV programmes in your country? Why is this?
Do you think there are too many game shows on TV nowadays? Why?
Do you think TV is the main way for people to get the news in your country？What other
ways are there?
TV advertising
Example questions:
What types of products are advertised most often on TV?
Do you think that people pay attention to adverts on TV? Why do you think that is?
How important are regulations on TV advertising?
102
```

[Original question page](assets/012147acad68c70b79352ff2e8b08dd6c19aa092ee698b1082b24ea3616df421.jpg)
