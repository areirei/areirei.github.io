# 剑雅 7 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 161

TEST 3 LISTENING
Section 1, Questions 1–10
1 business
2 third
3 Sport(s) Centre
4 (a) cleaner
5 Library
6 International House
7 B659
8 (an) office assistant
9 answer (the) phone
10 11.30
Section 2, Questions 11–20
11 B
12 C
13 A
14 C
15 B
16 A
17 forest
18 temple
19 waterfall
20 village
Section 3, Questions 21–30
21 cigar
22 13 (different) countries
23 activated
24 50 km(s)
25 temperature
26 A
27 C
28 A
29 B
30 C
Section 4, Questions 31–40
31 B
32 B
33 A
34 C
35 business
36 kitchen
37 world
38 escape
39 baby
40 chocolate
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. business

2. third

3. Sport Centre / Sports Centre

4. cleaner / a cleaner

5. Library

6. International House

7. B659

8. office assistant / an office assistant

9. answer phone / answer the phone

10. 11.30 / 11:30

### Part 2 · source page 161

TEST 3 LISTENING
Section 1, Questions 1–10
1 business
2 third
3 Sport(s) Centre
4 (a) cleaner
5 Library
6 International House
7 B659
8 (an) office assistant
9 answer (the) phone
10 11.30
Section 2, Questions 11–20
11 B
12 C
13 A
14 C
15 B
16 A
17 forest
18 temple
19 waterfall
20 village
Section 3, Questions 21–30
21 cigar
22 13 (different) countries
23 activated
24 50 km(s)
25 temperature
26 A
27 C
28 A
29 B
30 C
Section 4, Questions 31–40
31 B
32 B
33 A
34 C
35 business
36 kitchen
37 world
38 escape
39 baby
40 chocolate
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. B

12. C

13. A

14. C

15. B

16. A

17. forest

18. temple

19. waterfall

20. village

### Part 3 · source page 161

TEST 3 LISTENING
Section 1, Questions 1–10
1 business
2 third
3 Sport(s) Centre
4 (a) cleaner
5 Library
6 International House
7 B659
8 (an) office assistant
9 answer (the) phone
10 11.30
Section 2, Questions 11–20
11 B
12 C
13 A
14 C
15 B
16 A
17 forest
18 temple
19 waterfall
20 village
Section 3, Questions 21–30
21 cigar
22 13 (different) countries
23 activated
24 50 km(s)
25 temperature
26 A
27 C
28 A
29 B
30 C
Section 4, Questions 31–40
31 B
32 B
33 A
34 C
35 business
36 kitchen
37 world
38 escape
39 baby
40 chocolate
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. cigar

22. 13 countries / 13 different countries

23. activated

24. 50 km / 50 kms

25. temperature

26. A

27. C

28. A

29. B

30. C

### Part 4 · source page 161

TEST 3 LISTENING
Section 1, Questions 1–10
1 business
2 third
3 Sport(s) Centre
4 (a) cleaner
5 Library
6 International House
7 B659
8 (an) office assistant
9 answer (the) phone
10 11.30
Section 2, Questions 11–20
11 B
12 C
13 A
14 C
15 B
16 A
17 forest
18 temple
19 waterfall
20 village
Section 3, Questions 21–30
21 cigar
22 13 (different) countries
23 activated
24 50 km(s)
25 temperature
26 A
27 C
28 A
29 B
30 C
Section 4, Questions 31–40
31 B
32 B
33 A
34 C
35 business
36 kitchen
37 world
38 escape
39 baby
40 chocolate
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. B

32. B

33. A

34. C

35. business

36. kitchen

37. world

38. escape

39. baby

40. chocolate

## A 类阅读

### Academic Reading · source page 162

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 FALSE
2 TRUE
3 NOT GIVEN
4 TRUE
5 FALSE
6 NOT GIVEN
7 C
8 M
9 F
10 D
11 N
12 O
13 E
Reading Passage 2, Questions 14–26
14 iv
15 vii
16 x
17 i
18 vi
19 ii
20 E
21 D
22 C
23 B
24 A
25 A
26 A
Reading Passage 3, Questions 27–40
27 NOT GIVEN
28 FALSE
29 TRUE
30 FALSE
31 FALSE
32 FALSE
33 TRUE
34 J
35 A
36 E
37 B
38 G
39 D
40 B
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–30: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
31–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. FALSE

2. TRUE

3. NOT GIVEN

4. TRUE

5. FALSE

6. NOT GIVEN

7. C

8. M

9. F

10. D

11. N

12. O

13. E

14. iv

15. vii

16. x

17. i

18. vi

19. ii

20. E

21. D

22. C

23. B

24. A

25. A

26. A

27. NOT GIVEN

28. FALSE

29. TRUE

30. FALSE

31. FALSE

32. FALSE

33. TRUE

34. J

35. A

36. E

37. B

38. G

39. D

40. B

## A 类写作

### Writing material: c7-t3-w-1

Original bars and legend inspected at full resolution. Percent change FROM 1989 prices; two period averages, 1990–1995 and 1996–2002. Approximate first/second period values: New York (USA) −5%/+5%; Madrid (Spain) +1.5%/+4%; Tokyo (Japan) −7.5%/−5%; Frankfurt (Germany) +2%/+1.5%; London (UK) −7.5%/+11.5–12%. London has the biggest swing and highest later-period increase; Tokyo is below the baseline in both periods and is the only negative city in the later period. Frankfurt is above baseline in both but with a slightly smaller later increase. Negative bars mean below 1989, not necessarily a fall between the two periods. Do not report each bar as a single-year change or give absolute house prices.



### Writing material: c7-t3-w-2

Answer both contributing factors and how realistic universal job satisfaction is. The second question concerns ALL workers; listing factors alone does not address it.



## 口语
