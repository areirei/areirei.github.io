# 剑雅 7 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/ceabf4b0fba90f59fc03bac164b11dbe04da084ca1a0191e94b8c50b03e120e7.jpg; PDF page 61; full -->

```text
Test 3
LISTENING
SECTION 1 Questions 1-10
Questions 1 and 2
Complete the notes below.
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Example
Type of job required:
Student is studying 1 ....................... .
Answer
Part-time
Student is in the 2 ........................ year of the course.
Questions 3-5
Complete the table below.
Write NO MORE THAN TWO WORDS for each answer.
| Position Available | Where | Problem |
| --- | --- | --- |
| Receptionist | in the (3) __________ | evening lectures |
| (4) __________ | in the Child Care Centre | too early |
| Clerical Assistant | in the (5) __________ | evening lectures |
```

[Original question page](assets/ceabf4b0fba90f59fc03bac164b11dbe04da084ca1a0191e94b8c50b03e120e7.jpg)

<!-- Source: /api/assets/89517283be3e6a7d573c8559d818d45cd256a579c20144712aac483dfb83b4ac.jpg; PDF page 62; full -->

```text
Questions 6-10
Complete the form below.
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
STUDENT DETAILS
Name: Anita Newman
Address: 6 ........................
Room No. 7 ............... ...... ...
Other skills: Speaks some Japanese
Position available: 8 ....................... . at the English
Language Centre
Duties: Respond to enquiries and
9 ........................
Time of interview: Friday at 10 ........... ............. a.m.
Listening
57
```

[Original question page](assets/89517283be3e6a7d573c8559d818d45cd256a579c20144712aac483dfb83b4ac.jpg)

### Part 2

<!-- Source: /api/assets/0e3056dccdab580636cb6b65a35565b58643aa488445c2b24dda677d653f9ffc.jpg; PDF page 63; full -->

```text
Test 3
SECTION 2 Questions 11-20
Questions 11-16
Choose the correct letter, A, B or C
SPONSORED WALKING HOLIDAY
11 On the holiday, you will be walking for
A 6 days.
B 8 days.
C 10 days.
12 What proportion of the sponsorship money goes to charity?
[Original three pie options retained. Shaded area = Money going to charity: A approximately one-third; B one-half; C approximately two-thirds.]
13 Each walker's sponsorship money goes to one
A student.
B teacher.
C school.
14 When you start the trek you must be
A interested in getting fit.
B already quite fit.
C already very fit.
15 As you walk you will carry
A all of your belongings.
B some of your belongings.
C none of your belongings.
16 The Semira Region has a long tradition of
A making carpets.
B weaving blankets.
C carving wood.
```

[Original question page](assets/0e3056dccdab580636cb6b65a35565b58643aa488445c2b24dda677d653f9ffc.jpg)

![Original figure](assets/0e3056dccdab580636cb6b65a35565b58643aa488445c2b24dda677d653f9ffc.jpg)

<!-- Source: /api/assets/8c8b414fd9596d1e9fb7cdcb1a793b48f90d146d4f1e01b0977d824e09e4b9ea.jpg; PDF page 64; full -->

```text
Questions 17–20
Complete the form below. Write ONE WORD ONLY for each answer.
ITINERARY
| Day | Activity |
| --- | --- |
| Day 1 | arrive in Kishba |
| Day 2 | rest day |
| Day 3 | spend all day in a (17) __________ |
| Day 4 | visit a school |
| Day 5 | rest day |
| Day 6 | see a (18) __________ with old carvings |
| Day 7 | rest day |
| Day 8 | swim in a (19) __________ |
| Day 9 | visit a (20) __________ |
| Day 10 | depart from Kishba |
```

[Original question page](assets/8c8b414fd9596d1e9fb7cdcb1a793b48f90d146d4f1e01b0977d824e09e4b9ea.jpg)

### Part 3

<!-- Source: /api/assets/6222241fe08ee907ec6787516b5f860c9078bf5a68c717938c261cb05c856db3.jpg; PDF page 65; full -->

```text
Test 3
SECTION 3 Questions 21-30
Questions 21 and 22
Complete the notes below.
Write ONE WORD AND/OR A NUMBER for each answer.
OCEAN RESEARCH
The Robotic Float Project
o Float is shaped like a 21 ....................... .
o Scientists from 22 ........................ have worked on the project so far
60
```

[Original question page](assets/6222241fe08ee907ec6787516b5f860c9078bf5a68c717938c261cb05c856db3.jpg)

<!-- Source: /api/assets/ef08835d73b02669f813ddd16f837b5bdd2bb0912da78bf64bcb59d01a738128.jpg; PDF page 66; full -->

```text
Questions 23–25
Complete the diagram below. Write ONE WORD AND/OR A NUMBER for each answer.
THE OPERATIONAL CYCLE
[Original diagram retained. Boat at left drops a float into ocean. Float dropped into ocean and (23) __________ by satellite. Dotted arrows show it descending, travelling horizontally underwater then ascending. Average distance travelled: (24) __________. Float records changes in salinity and (25) __________. Surface transmissions from both drawn float positions point up to Global Satellite; satellite sends information to Meteorological station, where information is analysed.]
```

[Original question page](assets/ef08835d73b02669f813ddd16f837b5bdd2bb0912da78bf64bcb59d01a738128.jpg)

![Original figure](assets/ef08835d73b02669f813ddd16f837b5bdd2bb0912da78bf64bcb59d01a738128.jpg)

<!-- Source: /api/assets/898f6e7ffbf6036d324c83621329a29c446ecd6f1fb61cfb14989db8ac034de4.jpg; PDF page 67; full -->

```text
Test 3
Questions 26-30
In what time period can data from the float projects help with the following things?
Write the correct letter, A, B or C, next to questions 26-30.
A At present
B In the near future
C In the long-term future
26 understanding of El Niño
27 understanding of climate change
28 naval rescues
29 sustainable fishing practices
30 crop selection
62
```

[Original question page](assets/898f6e7ffbf6036d324c83621329a29c446ecd6f1fb61cfb14989db8ac034de4.jpg)

### Part 4

<!-- Source: /api/assets/c8644a2bc56bf27355e212e8d7911bf26acafef84248af01100d4f9537efba8f.jpg; PDF page 68; full -->

```text
Listening
SECTION 4 Questions 31-40
Questions 31-34
Choose the correct letter, A, B or C
Hotels and the tourist industry
31 According to the speaker, how might a guest feel when staying in a luxury hotel?
A impressed with the facilities
B depressed by the experience
C concerned at the high costs
32 According to recent research, luxury hotels overlook the need to
A provide for the demands of important guests.
B create a comfortable environment.
C offer an individual and personal welcome.
33 The company focused their research on
A a wide variety of hotels.
B large, luxury hotel chains.
C exotic holiday hotels.
34 What is the impact of the outside environment on a hotel guest?
A It has a considerable effect.
B It has a very limited effect.
C It has no effect whatsoever.
63
```

[Original question page](assets/c8644a2bc56bf27355e212e8d7911bf26acafef84248af01100d4f9537efba8f.jpg)

<!-- Source: /api/assets/80b519af9dcfe2e9dcb5712e1f53ca1e252f8e3e80ea576df67b7dbc44f11cf5.jpg; PDF page 69; full -->

```text
Test 3
Questions 35-40
Complete the notes below.
Write ONE WORD ONLY for each answer.
A company providing luxury serviced apartments aims to:
• cater specifically for 35 .................. ...... travellers
• provide a stylish 36 ........................ for guests to use
• set a trend throughout the 37 ........................ which becomes permanent
Traditional holiday hotels attract people by:
• offering the chance to 38 ........................ their ordinary routine life
• making sure that they are cared for in all respects- like a 39 ....................... .
• leaving small treats in their rooms- e.g. cosmetics or 40 ....................... .
64
```

[Original question page](assets/80b519af9dcfe2e9dcb5712e1f53ca1e252f8e3e80ea576df67b7dbc44f11cf5.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/78cad8db243e06bd2c19b6a38b24ab8e9cad089d91c699e0e7fc9126ff35c931.jpg; PDF page 70; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13 , which are based on Reading Passage 1
below.
Ant Intelligence
When we think of intelligent
members of the animal
kingdom, the creatures that
spring immediately to mind
are apes and monkeys. But
in fact the social lives of
some members of the insect
kingdom are sufficiently
complex to suggest more
than a hint of intelligence.
Among these, the world of the ant has come
in for considerable scrutiny lately, and the
idea that ants demonstrate sparks of
cognition has certainly not been rejected by
those involved in these investigations.
Ants store food, repel attackers and use
chemical signals to contact one another in
case of attack. Such chemical
communication can be compared to the
human use of visual and auditory channels
(as in religious chants, advertising images
and jingles, political slogans and martial
music) to arouse and propagate moods and
attitudes. The biologist Lewis Thomas wrote,
'Ants are so much like human beings as to
be an embarrassment. They farm fungi, raise
aphids* as livestock, launch armies to war,
use chemical sprays to alarm and confuse
enemies, capture slaves, engage in child
labour, exchange information ceaselessly.
They do everything but watch television. '
However, in ants there is no
cultural transmission -
everything must be encoded
in the genes - whereas in
humans the opposite is
true. Only basic instincts are
carried in the genes of a
newborn baby, other skills
being learned from others in
the community as the child
grows up. It may seem that this cultural
continuity gives us a huge advantage over
ants. They have never mastered fire nor
progressed. Their fungus farming and aphid
herding crafts are sophisticated when
compared to the agricultural skills of
humans five thousand years ago but have
been totally overtaken by modern human
agribusiness.
Or have they? The farming methods of ants
are at least sustainable . They do not ruin
environments or use enormous amounts of
energy. Moreover, recent evidence suggests
that the crop farming of ants may be more
sophisticated and adaptable than was
thought.
Ants were farmers fifty million years before
humans were. Ants can't digest the cellulose
in leaves- but some fungi can. The ants
therefore cultivate these fungi in their nests,
bringing them leaves to feed on, and then
65
* aphids: small insects of a different species from ants
```

[Original question page](assets/78cad8db243e06bd2c19b6a38b24ab8e9cad089d91c699e0e7fc9126ff35c931.jpg)

<!-- Source: /api/assets/566c22df034555a4385b7b30968e2b7b8f37dd85aab1c6e7bea4f774e23044bf.jpg; PDF page 71; full -->

```text
Test 3
use them as a source of food. Farmer ants
secrete antibiotics to control other fungi that
might act as 'weeds', and spread waste to
fertilise the crop.
It was once thought that the fungus that
ants cultivate was a single type that they
had propagated, essentially unchanged from
the distant past. Not so. Ulrich Mueller of
Maryland and his colleagues genetically
screened 862 different types of fungi taken
from ants' nests. These turned out to be
highly diverse: it seems that ants are
continually domesticating new species. Even
more impressively, DNA analysis of the fungi
suggests that the ants improve or modify the
fungi by regularly swapping and sharing
strains with neighbouring ant colonies.
Whereas prehistoric man had no exposure to
urban lifestyles- the forcing house of
intelligence -the evidence suggests that
ants have lived in urban settings for close on
a hundred million years, developing and
maintaining underground cities of
specialised chambers and tunnels.
When we survey Mexico City, Tokyo, Los
Angeles, we are amazed at what has been
accomplished by humans. Yet Hoelldobler
and Wilson's magnificent work for ant lovers,
The Ants, describes a supercolony of the ant
Formica yessensis on the Ishikari Coast of
Hokkaido. This 'megalopolis' was reported to
be composed of 360 million workers and a
million queens living in 4,500
interconnected nests across a territory of
2.7 square kilometres.
Such enduring and intricately meshed levels
of technical achievement outstrip by far
anything achieved by our distant ancestors.
We hail as masterpieces the cave paintings
in southern France and elsewhere, dating
back some 20,000 years. Ant societies
66
existed in something like their present form
more than seventy million years ago. Beside
this, prehistoric man looks technologically
primitive. Is this then some kind of
intelligence, albeit of a different kind?
Research conducted at Oxford, Sussex and
Zurich Universities has shown that when
desert ants return from a foraging trip, they
navigate by integrating bearings and
distances, which they continuously update in
their heads. They combine the evidence of
visual landmarks with a mental library of
local directions, all within a framework which
is consulted and updated. So ants can learn
too.
And in a twelve-year programme of work,
Ryabko and Reznikova have found evidence
that ants can transmit very complex
messages. Scouts who had located food in a
maze returned to mobilise their foraging
teams. They engaged in contact sessions, at
the end of which the scout was removed in
order to observe what her team might do.
Often the foragers proceeded to the exact
spot in the maze where the food had been.
Elaborate precautions were taken to prevent
the foraging team using odour clues.
Discussion now centres on whether the route
through the maze is communicated ·as a 'left­
right' sequence of turns or as a 'compass
bearing and distance' message.
During the course of this exhaustive study,
Reznikova has grown so attached to her
laboratory ants that she feels she knows
them as individuals - even without the paint
spots used to mark them. It’s no surprise
that Edward Wilson, in his essay, 'In the
company of ants', advises readers who ask
what to do with the ants in their kitchen to:
'Watch where you step. Be careful of little
lives.'
```

[Original question page](assets/566c22df034555a4385b7b30968e2b7b8f37dd85aab1c6e7bea4f774e23044bf.jpg)

<!-- Source: /api/assets/a5d1c94013e9c4fe3c0a13f387b981cb96fe2fdeddb651614d7f63c07f33dac7.jpg; PDF page 72; full -->

```text
Reading
Questions 1–6
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-6 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
1 Ants use the same channels of communication as humans do.
2 City life is one factor that encourages the development of intelligence.
3 Ants can build large cities more quickly than humans do.
4 Some ants can find their way by making calculations based on distance and position.
5 In one experiment, foraging teams were able to use their sense of smell to find food.
6 The essay, 'In the company of ants', explores ant communication.
67
```

[Original question page](assets/a5d1c94013e9c4fe3c0a13f387b981cb96fe2fdeddb651614d7f63c07f33dac7.jpg)

<!-- Source: /api/assets/5b6bab83fa89718f01e2d906592006435e1f73a02c5b0be5a69c2e4f82dd3a95.jpg; PDF page 73; full -->

```text
Test 3
Questions 7-13
Complete the summary using the list of words, A–O, below.
Write the correct letter, A–O, in boxes 7-13 on your answer sheet.
68
Ants as farmers
Ants have sophisticated methods of farming, including herding livestock and growing
crops, which are in many ways similar to those used in human agriculture. The ants
cultivate a large number of different species of edible fungi which convert
7 .. .. .. .. .. .. .. .. .. .. .. .. into a form which they can digest. They use their own natural
8 ........................ as weed-killers and also use unwanted materials as 9 ........................ .
Genetic analysis shows they constantly upgrade these fungi by developing new species
and by 10 ........................ species with neighbouring ant colonies. In fact, the farming
methods of ants could be said to be more advanced than human agribusiness, since they
use 11 ........................ methods, they do not affect the 12 ........................ and do not
waste 13 ........................ .
A aphids B agricultural C cellulose D exchanging
E energy F fertilizers G food H fungi
I growing J interbreeding K natural L other species
M secretions N sustainable O environment
```

[Original question page](assets/5b6bab83fa89718f01e2d906592006435e1f73a02c5b0be5a69c2e4f82dd3a95.jpg)

<!-- Source: /api/assets/e67610b4007d0ecf02dfb15ae938af4677adcdfb08c243c73e6502d1b2a0a288.jpg; PDF page 74; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26 , which are based on Reading Passage 2
on the following pages .
Questions 14-19
Reading Passage 2 has seven sections, A-G.
Choose the correct headings for sections A-F from the list of headings below.
Write the correct number, i-x, in boxes 14-19 on your answer sheet.
List of Headings
i The results of the research into blood-variants
ii Dental evidence
iii Greenberg's analysis of the dental and linguistic evidence
iv Developments in the methods used to study early population
movements
v Indian migration from Canada to the U.S.A.
vi Further genetic evidence relating to the three-wave theory
vii Long-standing questions about prehistoric migration to America
viii Conflicting views of the three-wave theory, based on non-genetic
evidence
ix Questions about the causes of prehistoric migration to America
x How analysis of blood-variants measures the closeness of the
relationship between different populations
14 Section A __________
15 Section B __________
16 Section C __________
17 Section D __________
18 Section E __________
19 Section F __________
Example Answer
Section G viii
69
```

[Original question page](assets/e67610b4007d0ecf02dfb15ae938af4677adcdfb08c243c73e6502d1b2a0a288.jpg)

<!-- Source: /api/assets/e5b7b8281783aa571fa4855f3243a40c8c981eab252705ab33f8df14daef1304.jpg; PDF page 75; full -->

```text
Test3
Population movements and genetics
A Study of the origins and distribution of
human populations used to be based on
archaeological and fossil evidence . A
number of techniques developed since
the 1950s, however, have placed the
study of these subjects on a sounder and
more objective footing . The best
information on early population
movements is now being obtained from
the 'archaeology of the living body', the
clues to be found in genetic material.
B Recent work on the problem of when
people first entered the Americas is an
example of the value of these new
techniques . North-east Asia and Siberia
have long been accepted as the
launching ground for the first human
colonisers of the New World 1. But was
there one major wave of migration across
the Bering Strait into the Americas, or
several? And when did this event, or
events, take place? In recent years, new
clues have come from research into
genetics, including the distribution of
genetic markers in modern Native
Americans 2.
C An important project, led by the
biological anthropologist Robert Williams,
focused on the variants (called Gm
allotypes) of one particular protein­
immunoglobin G- found in the fluid
portion of human blood . All proteins
'drift', or produce variants, over the
generations, and members of an
interbreeding human population will
share a set of such variants. Thus, by
comparing the Gm allotypes of two
different populations (e.g. two Indian
tribes), one can establish their genetic
'distance', which itself can be calibrated
to give an indication of the length of time
since these populations last interbred.
D Williams and his colleagues sampled the
blood of over 5,000 American Indians in
western North America during a twenty­
year period. They found that their Gm
allotypes could be divided into two
groups, one of which also corresponded
to the genetic typing of Central and South
American Indians . Other tests showed
that the Inuit (or Eskimo) and Aleut 3
formed a third group . From this evidence
it was deduced that there had been three
major waves of migration across the
Bering Strait. The first, Paleo-Indian, wave
more than 15,000 years ago was
ancestral to all Central and South
American Indians . The second wave,
about 14,000-12,000 years ago,
brought Na-Dene hunters, ancestors of
the Navajo and Apache (who only
migrated south from Canada about 600
or 700 years ago) . The third wave,
perhaps 10,000 or 9,000 years ago, saw
the migration from North-east Asia of
groups ancestral to the modern Eskimo
and Aleut.
E How far does other research support
these conclusions? Geneticist Douglas
Wallace has studied mitochondrial DNA⁴
in blood samples from three widely
separated Native American groups : Pima­
Papago Indians in Arizona, Maya Indians
on the Yucatán peninsula, Mexico, and
1 New World : the American continent, as opposed to the so-called Old World of Europe, Asia and Africa
2 modern Native American: an American descended from the groups that were native to America
3 Inuit and Aleut : two of the ethnic groups native to the northern regions of North America (i.e. northern Canada and Greenland)
4 DNA: the substance in which genetic information is stored
70
```

[Original question page](assets/e5b7b8281783aa571fa4855f3243a40c8c981eab252705ab33f8df14daef1304.jpg)

<!-- Source: /api/assets/2a65074e6a6823fe1d670db6957aa33e37397e92f5641847a2937d0505d4538f.jpg; PDF page 76; full -->

```text
Ticuna Indians in the Upper Amazon
region of Brazil. As would have been
predicted by Robert Williams's work, all
three groups appear to be descended
from the same ancestral (Paleo-Indian)
population.
F There are two other kinds of research that
have thrown some light on the origins of
the Native American population; they
involve the study of teeth and of
languages. The biological anthropologist
Christy Turner is an expert in the analysis
of changing physical characteristics in
human teeth. He argues that tooth
crowns and roots5 have a high genetic
component, minimally affected by
environmental and other factors. Studies
carried out by Turner of many thousands
of New and Old World specimens, both
ancient and modern, suggest that the
majority of prehistoric Americans are
linked to Northern Asian populations by
crown and root traits such as incisor-6
shoveling (a scooping out on one or both
surfaces of the tooth), single-rooted
upper first premolars 6 and triple-rooted
lower first molars 6.
According to Turner, this ties in with the
idea of a single Paleo-Indian migration
out of North Asia, which he sets at before
14,000 years ago by calibrating rates of
dental micro-evolution. Tooth analyses
also suggest that there were two later
migrations of Na -Denes and Eskimo­
Aleut.
G The linguist Joseph Greenberg has, since
the 1950s, argued that all Native
American languages belong to a single
'Amerind' family, except for Na-Dene and
Eskimo-Aleut- a view that gives credence
to the idea of three main migrations.
Greenberg is in a minority among fellow
linguists, most of whom favour the notion
of a great many waves of migration to
account for the more than 1,000
languages spoken at one time by
American Indians . But there is no doubt
that the new genetic and dental evidence
provides strong backing for Greenberg' s
view. Dates given for the migrations
should nevertheless be treated with
caution, except where supported by hard
archaeological evidence.
71
5 crown / root : parts of the tooth
6 incisor / premolar / molar: kinds of teeth
```

[Original question page](assets/2a65074e6a6823fe1d670db6957aa33e37397e92f5641847a2937d0505d4538f.jpg)

<!-- Source: /api/assets/7e9232e1ca4325f5b05c4d1a40957ac3844daa83ce840c4ab04fe5dfca945e83.jpg; PDF page 77; full -->

```text
Test 3
Questions 20 and 21
The discussion of Williams's research indicates the periods at which early people are thought
to have migrated along certain routes. There are six routes, A-F, marked on the map below.
Complete the table below.
Write the correct letter, A-F, in boxes 20 and 21 on your answer sheet.
Route Period (number of years ago)
20 ........................ 15,000 or more
21 ........................ 600 to 700
Early Population Movement to the Americas
72
[Original Early Population Movement to the Americas map retained with six route arrows A–F. Map labels: Asia,Bering Strait,Alaska,Canada,U.S.A.,Greenland,Central America,South America. Use the original arrow paths to answer20–21; no route answers inserted.]
```

[Original question page](assets/7e9232e1ca4325f5b05c4d1a40957ac3844daa83ce840c4ab04fe5dfca945e83.jpg)

![Original figure](assets/7e9232e1ca4325f5b05c4d1a40957ac3844daa83ce840c4ab04fe5dfca945e83.jpg)

<!-- Source: /api/assets/f83b7a0f1d85f71daedb893dc44605896170904cbf2eae628504ed4bd279e788.jpg; PDF page 78; full -->

```text
Reading
Questions 22-25
Reading Passage 2 refers to the three-wave theory of early migration to the Americas. It also
suggests in which of these three waves the ancestors of various groups of modern native
Americans first reached the continent.
Classify the groups named in the table below as originating from
A the first wave
B the second wave
C the third wave
Write the correct letter, A, B or C, in boxes 22-25 on your answer sheet.
Name of group Wave number
Inuit 22 ························
Apache 23 ........................
Pima-Papago 24 ........ ....... .........
Ticuna 25 ........................
Question 26
Choose the correct letter, A, B, C or D.
Write the correct letter in box 26 on your answer sheet.
Christy Turner's research involved the examination of
A teeth from both prehistoric and modern Americans and Asians.
B thousands of people who live in either the New or the Old World .
C dental specimens from the majority of prehistoric Americans .
D the eating habits of American and Asian populations.
73
```

[Original question page](assets/f83b7a0f1d85f71daedb893dc44605896170904cbf2eae628504ed4bd279e788.jpg)

<!-- Source: /api/assets/43b4d4359e73e6a94dcbb7f2f032e12de4390d32abc27ba9add4a432cf8da17b.jpg; PDF page 79; full -->

```text
Test 3
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40 , which are based on Reading Passage 3
below.
74
Forests are one of the main elements of our natural heritage.
The decline of Europe's forests over the last decade and a half
has led to an increasing awareness and understanding of the
serious imbalances which threaten them. European countries
are becoming increasingly concerned by major threats to
European forests, threats which know no frontiers other than
those of geography or climate: air pollution, soil deterioration,
the increasing number of forest fires and sometimes even the
mismanagement of our woodland and forest heritage. There
has been a growing awareness of the need for countries to get
together to co-ordinate their policies. In December 1990, Strasbourg hosted the first Ministerial
Conference on the protection of Europe's forests. The conference brought together 31 countries from
both Western and Eastern Europe. The topics discussed included the co-ordinated study of the
destruction of forests, as well as how to combat forest fires and the extension of European research
programs on the forest ecosystem. The preparatory work for the conference had been undertaken at
two meetings of experts. Their initial task was to decide which of the many forest problems of
concern to Europe involved the largest number of countries and might be the subject of joint action.
Those confined to particular geographical areas, such as countries bordering the Mediterranean or
the Nordic countries therefore had to be discarded. However, this does not mean that in future they
will be ignored.
As a whole, European countries see forests as performing a triple function: biological, economic and
recreational. The first is to act as a 'green lung' for our planet; by means of photosynthesis, forests
produce oxygen through the transformation of solar energy, thus fulfilling what for humans is the
essential role of an immense, non-polluting power plant. At the same time, forests provide raw
materials for human activities through their constantly renewed production of wood. Finally, they
offer those condemned to spend five days a week in an urban environment an unrivalled area of
freedom to unwind and take part in a range of leisure activities, such as hunting, riding and hiking.
The economic importance of forests has been understood since the dawn of man - wood was the
first fuel. The other aspects have been recognised only for a few centuries but they are becoming
more and more important. Hence, there is a real concern throughout Europe about the damage to
the forest environment which threatens these three basic roles.
The myth of the 'natural' forest has survived, yet there are effectively no remaining 'primary' forests
in Europe. All European forests are artificial, having been adapted and exploited by man for
thousands of years. This means that a forest policy is vital, that it must transcend national frontiers
and generations of people, and that it must allow for the inevitable changes that take place in the
forests, in needs, and hence in policy. The Strasbourg conference was one of the first events on such
a scale to reach this conclusion. A general declaration was made that 'a central place in any
ecologically coherent forest policy must be given to continuity over time and to the possible effects
of unforeseen events, to ensure that the full potential of these forests is maintained'.
```

[Original question page](assets/43b4d4359e73e6a94dcbb7f2f032e12de4390d32abc27ba9add4a432cf8da17b.jpg)

<!-- Source: /api/assets/c7ef09a5b4c5ca44613a8367d278e35b2d40c2e62b1bb8388590643db46bf08c.jpg; PDF page 80; full -->

```text
Reading
That general declaration was accompanied by six detailed resolutions to assist national policy­
making. The first proposes the extension and systematisation of surveillance sites to monitor forest
decline. Forest decline is still poorly understood but leads to the loss of a high proportion of a tree's
needles or leaves. The entire continent and the majority of species are now affected: between 30%
and 50% of the tree population. The condition appears to result from the cumulative effect of a
number of factors, with atmospheric pollutants the principal culprits. Compounds of nitrogen and
sulphur dioxide should be particularly closely watched. However, their effects are probably
accentuated by climatic factors, such as drought and hard winters, or soil imbalances such as soil
acidification, which damages the roots. The second resolution concentrates on the need to preserve
the genetic diversity of European forests. The aim is to reverse the decline in the number of tree
species or at least to preserve the 'genetic material' of all of them. Although forest fires do not affect
all of Europe to the same extent, the amount of damage caused the experts to propose as the third
resolution that the Strasbourg conference consider the establishment of a European databank on
the subject. All information used in the development of national preventative policies would become
generally available. The subject of the fourth resolution discussed by the ministers was mountain
forests. In Europe, it is undoubtedly the mountain ecosystem which has changed most rapidly and is
most at risk. A thinly scattered permanent population and development of leisure activities,
particularly skiing, have resulted in significant long-term changes to the local ecosystems. Proposed
developments include a preferential research program on mountain forests. The fifth resolution
relaunched the European research network on the physiology of trees, called Eurosilva. Eurosilva
should support joint European research on tree diseases and their physiological and biochemical
aspects. Each country concerned could increase the number of scholarships and other financial
support for doctoral theses and research projects in this area. Finally, the conference established the
framework for a European research network on forest ecosystems. This would also involve
harmonising activities in individual countries as well as identifying a number of priority research
topics relating to the protection of forests. The Strasbourg conference's main concern was to provide
for the future. This was the initial motivation, one now shared by all 31 participants representing 31
European countries. Their final text commits them to on-going discussion between government
representatives with responsibility for forests.
75
```

[Original question page](assets/c7ef09a5b4c5ca44613a8367d278e35b2d40c2e62b1bb8388590643db46bf08c.jpg)

<!-- Source: /api/assets/ac785b477f138f1cfb9fc4d2651a4cf30498898878fe9f526432986b2c6309ac.jpg; PDF page 81; full -->

```text
Test 3
Questions 27-33
Do the following statements agree with the information given in Reading Passage 3?
In boxes 27-33 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
27 Forest problems of Mediterranean countries are to be discussed at the next meeting of
experts.
28 Problems in Nordic countries were excluded because they are outside the European
Economic Community.
29 Forests are a renewable source of raw material.
30 The biological functions of forests were recognised only in the twentieth century.
31 Natural forests still exist in parts of Europe.
32 Forest policy should be limited by national boundaries.
33 The Strasbourg conference decided that a forest policy must allow for the possibility of
change.
76
```

[Original question page](assets/ac785b477f138f1cfb9fc4d2651a4cf30498898878fe9f526432986b2c6309ac.jpg)

<!-- Source: /api/assets/049e78e085a123543b4a3d03d9ff6f70be4e436d0524c7b8f3f507c6d835657a.jpg; PDF page 82; full -->

```text
Reading
Questions 34-39
Look at the following statements issued by the conference.
Which six of the following statements, A-J, refer to the resolutions that were issued?
Match the statements with the appropriate resolutions (Questions 34- 39 ).
Write the correct letter, A-J, in boxes 34-39 on your answer sheet.
A All kinds of species of trees should be preserved.
B Fragile mountain forests should be given priority in research programs.
C The surviving natural forests of Europe do not need priority treatment.
D Research is to be better co-ordinated throughout Europe.
E Information on forest fires should be collected and shared .
F Loss of leaves from trees should be more extensively and carefully
monitored .
G Resources should be allocated to research into tree diseases.
H Skiing should be encouraged in thinly populated areas.
I Soil imbalances such as acidification should be treated with compounds of
nitrogen and sulphur .
J Information is to be systematically gathered on any decline in the condition
of forests.
34 Resolution 1 __________
35 Resolution 2 __________
36 Resolution 3 __________
37 Resolution 4 __________
38 Resolution 5 __________
39 Resolution 6 __________
Question 40
Choose the correct letter, A, B, C or D.
Write the correct letter in box 40 on your answer sheet.
40 What is the best title for Reading Passage 3?
A The biological, economic and recreational role of forests
B Plans to protect the forests of Europe
C The priority of European research into ecosystems
D Proposals for a world-wide policy on forest management
77
```

[Original question page](assets/049e78e085a123543b4a3d03d9ff6f70be4e436d0524c7b8f3f507c6d835657a.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/062d546ef9f59f6ee3cb7ac436163d9679bf39be1747041763e601ca3e080cdd.jpg; PDF page 83; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows information about changes in average house prices in five different cities between 1990 and 2002 compared with the average house prices in 1989.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the original figure is retained for the complete plotted data or diagram.]
```

[Original question page](assets/062d546ef9f59f6ee3cb7ac436163d9679bf39be1747041763e601ca3e080cdd.jpg)

![Original figure](assets/062d546ef9f59f6ee3cb7ac436163d9679bf39be1747041763e601ca3e080cdd.jpg)

### Task 2

<!-- Source: /api/assets/5327482ca62d0b025bee08305ec024aba4860f0ecdd1c28cae138643b597655c.jpg; PDF page 84; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

As most people spend a major part of their adult life at work, job satisfaction is an important element of individual wellbeing.

What factors contribute to job satisfaction?

How realistic is the expectation of job satisfaction for all workers?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/5327482ca62d0b025bee08305ec024aba4860f0ecdd1c28cae138643b597655c.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/2a4e64d4cb97a9c3e35e673ee97922b56a7aa435e86c74bafe10ead56623eacf.jpg; PDF page 85; full -->

```text
Test 3
I
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home , work or studies and other
familiar topics.
EXAMPLE
Cold weather
• Have you ever been in very cold weather? [When?]
• How often is the weather cold where you come from?
• Are some parts of your country colder than others? [Why?]
• Would you prefer to live in a hot place or a cold place? [Why?]
PART 2
Describe a competition (e.g. TV, college/work or
sports competition) that you took part in.
You should say:
what kind of competition it was and how you
found out about it
what you had to do
what the prizes were
and explain why you chose to take part in this
competition.
You will have to talk about the topic
for one to two minutes.
You have one minute to think about
what you are going to say.
You can make some notes to help you
if you wish.

PART 3
Discussion topics:
Competitions in school
Example questions:
Why do you think some school teachers use competitions as class activities?
Do you think it is a good thing to give prizes to children who do well at school? Why?
Would you say that schools for young children have become more or less competitive since
you were that age? Why?
Sporting competitions
Example questions:
What are the advantages and disadvantages of intensive training for young sportspeople?
Some people think that competition leads to a better performance from sports stars . Others
think it just makes players feel insecure. What is your opinion?
Do you think that it is possible to become too competitive in sport? In what way?
80
```

[Original question page](assets/2a4e64d4cb97a9c3e35e673ee97922b56a7aa435e86c74bafe10ead56623eacf.jpg)

### Part 2

<!-- Source: /api/assets/2a4e64d4cb97a9c3e35e673ee97922b56a7aa435e86c74bafe10ead56623eacf.jpg; PDF page 85; full -->

```text
Test 3
I
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home , work or studies and other
familiar topics.
EXAMPLE
Cold weather
• Have you ever been in very cold weather? [When?]
• How often is the weather cold where you come from?
• Are some parts of your country colder than others? [Why?]
• Would you prefer to live in a hot place or a cold place? [Why?]
PART 2
Describe a competition (e.g. TV, college/work or
sports competition) that you took part in.
You should say:
what kind of competition it was and how you
found out about it
what you had to do
what the prizes were
and explain why you chose to take part in this
competition.
You will have to talk about the topic
for one to two minutes.
You have one minute to think about
what you are going to say.
You can make some notes to help you
if you wish.

PART 3
Discussion topics:
Competitions in school
Example questions:
Why do you think some school teachers use competitions as class activities?
Do you think it is a good thing to give prizes to children who do well at school? Why?
Would you say that schools for young children have become more or less competitive since
you were that age? Why?
Sporting competitions
Example questions:
What are the advantages and disadvantages of intensive training for young sportspeople?
Some people think that competition leads to a better performance from sports stars . Others
think it just makes players feel insecure. What is your opinion?
Do you think that it is possible to become too competitive in sport? In what way?
80
```

[Original question page](assets/2a4e64d4cb97a9c3e35e673ee97922b56a7aa435e86c74bafe10ead56623eacf.jpg)

### Part 3

<!-- Source: /api/assets/2a4e64d4cb97a9c3e35e673ee97922b56a7aa435e86c74bafe10ead56623eacf.jpg; PDF page 85; full -->

```text
Test 3
I
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home , work or studies and other
familiar topics.
EXAMPLE
Cold weather
• Have you ever been in very cold weather? [When?]
• How often is the weather cold where you come from?
• Are some parts of your country colder than others? [Why?]
• Would you prefer to live in a hot place or a cold place? [Why?]
PART 2
Describe a competition (e.g. TV, college/work or
sports competition) that you took part in.
You should say:
what kind of competition it was and how you
found out about it
what you had to do
what the prizes were
and explain why you chose to take part in this
competition.
You will have to talk about the topic
for one to two minutes.
You have one minute to think about
what you are going to say.
You can make some notes to help you
if you wish.

PART 3
Discussion topics:
Competitions in school
Example questions:
Why do you think some school teachers use competitions as class activities?
Do you think it is a good thing to give prizes to children who do well at school? Why?
Would you say that schools for young children have become more or less competitive since
you were that age? Why?
Sporting competitions
Example questions:
What are the advantages and disadvantages of intensive training for young sportspeople?
Some people think that competition leads to a better performance from sports stars . Others
think it just makes players feel insecure. What is your opinion?
Do you think that it is possible to become too competitive in sport? In what way?
80
```

[Original question page](assets/2a4e64d4cb97a9c3e35e673ee97922b56a7aa435e86c74bafe10ead56623eacf.jpg)
