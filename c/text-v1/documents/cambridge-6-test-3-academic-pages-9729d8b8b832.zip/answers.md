# 剑雅 6 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 156

TEST 3 LISTENING
Section 1, Questions 1–10
1 Select
2 27.01.1973
3 15 Riverside
4 2 weeks
5 616295
6 engineer
7 mother
8 2,000
9 month
10 internet
Section 2, Questions 11–20
11 C
12 A
13 C
14 H
15 F
16 B
17 D
18 field
19 footbridge
20 viewpoint
Section 3, Questions 21–30
21 entertainment industry
22 telephone interviews
23 30 / thirty
24 male and female
25 jazz
26 classical
27 concerts
28 department stores
29 club
30 opera house
Section 4, Questions 31–40
31 C
32 A
33 A
34 B
35 people
36 IN EITHER ORDER: water; sand
37 Scotland
38 outside
39 local
40 tops
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. Select

2. 27.01.1973

3. 15 Riverside

4. 2 weeks

5. 616295

6. engineer

7. mother

8. 2,000 / 2000

9. month

10. internet

### Part 2 · source page 156

TEST 3 LISTENING
Section 1, Questions 1–10
1 Select
2 27.01.1973
3 15 Riverside
4 2 weeks
5 616295
6 engineer
7 mother
8 2,000
9 month
10 internet
Section 2, Questions 11–20
11 C
12 A
13 C
14 H
15 F
16 B
17 D
18 field
19 footbridge
20 viewpoint
Section 3, Questions 21–30
21 entertainment industry
22 telephone interviews
23 30 / thirty
24 male and female
25 jazz
26 classical
27 concerts
28 department stores
29 club
30 opera house
Section 4, Questions 31–40
31 C
32 A
33 A
34 B
35 people
36 IN EITHER ORDER: water; sand
37 Scotland
38 outside
39 local
40 tops
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. C

12. A

13. C

14. H

15. F

16. B

17. D

18. field

19. footbridge

20. viewpoint

### Part 3 · source page 156

TEST 3 LISTENING
Section 1, Questions 1–10
1 Select
2 27.01.1973
3 15 Riverside
4 2 weeks
5 616295
6 engineer
7 mother
8 2,000
9 month
10 internet
Section 2, Questions 11–20
11 C
12 A
13 C
14 H
15 F
16 B
17 D
18 field
19 footbridge
20 viewpoint
Section 3, Questions 21–30
21 entertainment industry
22 telephone interviews
23 30 / thirty
24 male and female
25 jazz
26 classical
27 concerts
28 department stores
29 club
30 opera house
Section 4, Questions 31–40
31 C
32 A
33 A
34 B
35 people
36 IN EITHER ORDER: water; sand
37 Scotland
38 outside
39 local
40 tops
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. entertainment industry

22. telephone interviews

23. 30 / thirty

24. male female / male, female / male and female / male & female / male; female / male/female / male,female / female male / female, male / female and male / female & male / female; male / female/male / female,male

25. jazz

26. classical

27. concerts

28. department stores

29. club

30. opera house

### Part 4 · source page 156

TEST 3 LISTENING
Section 1, Questions 1–10
1 Select
2 27.01.1973
3 15 Riverside
4 2 weeks
5 616295
6 engineer
7 mother
8 2,000
9 month
10 internet
Section 2, Questions 11–20
11 C
12 A
13 C
14 H
15 F
16 B
17 D
18 field
19 footbridge
20 viewpoint
Section 3, Questions 21–30
21 entertainment industry
22 telephone interviews
23 30 / thirty
24 male and female
25 jazz
26 classical
27 concerts
28 department stores
29 club
30 opera house
Section 4, Questions 31–40
31 C
32 A
33 A
34 B
35 people
36 IN EITHER ORDER: water; sand
37 Scotland
38 outside
39 local
40 tops
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. C

32. A

33. A

34. B

35. people

36. water sand / water, sand / water and sand / water & sand / water; sand / water/sand / water,sand / sand water / sand, water / sand and water / sand & water / sand; water / sand/water / sand,water

37. Scotland

38. outside

39. local

40. tops

## A 类阅读

### Academic Reading · source page 157

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 A
2 I
3 J
4 E
5 G
6 YES
7 NOT GIVEN
8 NOT GIVEN
9 NO
10 B
11 C
12 D
13 D
Reading Passage 2, Questions 14–27
14 vii
15 iii
16 ii
17 iv
18 i
19 NO
20 NOT GIVEN
21 NO
22 YES
23 NOT GIVEN
24 YES
25 B
26 C
27 A
Reading Passage 3, Questions 28–40
28 NO
29 YES
30 YES
31 NOT GIVEN
32 YES
33 A
34 B
35 C
36 A
37 B
38 glucose
39 free radicals
40 preservation
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. A

2. I

3. J

4. E

5. G

6. YES

7. NOT GIVEN

8. NOT GIVEN

9. NO

10. B

11. C

12. D

13. D

14. vii

15. iii

16. ii

17. iv

18. i

19. NO

20. NOT GIVEN

21. NO

22. YES

23. NOT GIVEN

24. YES

25. B

26. C

27. A

28. NO

29. YES

30. YES

31. NOT GIVEN

32. YES

33. A

34. B

35. C

36. A

37. B

38. glucose

39. free radicals

40. preservation

## A 类写作

### Writing material: c6-t3-w-1

Full original diagrams inspected. Biological cycle: eggs hatch after 10 days into silkworm larvae; larvae feed on mulberry leaves for 4–6 weeks, then produce silk thread and form cocoons over 3–8 days. After 16 days in the cocoon, a moth emerges and the cycle returns to egg laying. The diagram has numbered egg, larva, silk-thread and cocoon stages, with the moth also shown; do not impose an invented fixed stage count. Cloth production: select cocoons, boil them in water, unwind 300–900 metres of thread, twist the thread and weave cloth. Dotted arrows show dyeing can occur at the twisted-thread stage or after weaving; do not insist it happens twice or only after weaving. The life cycle is cyclical, while manufacturing is sequential. No boiling temperature or manufacturing durations are stated.



### Writing material: c6-t3-w-2

Address both visitors adapting to local customs and hosts welcoming cultural differences, then justify an opinion. Do not replace customs with a different question solely about laws.



## 口语
