# 剑雅 6 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/c4a44e7a0e97ec59a0d712f0d323c6163ec928683ea20d561eb33ac777033586.jpg; PDF page 56; full -->

```text
LISTENING SECTION 1 Questions 1–10
Complete the form below. Write ONE WORD AND/OR A NUMBER for each answer.
OPENING A BANK ACCOUNT
Example: Application for a Current bank account
Type of current account: The (1) ‘__________’ account
Full name of applicant: Pieter Henes
Date of birth: (2) __________
Joint account holder(s): No
Current address: (3) __________ Exeter
Time at current address: (4) __________
Previous address: Rielsdorf 2, Utrecht, Holland
Telephone: work (5) __________; home 796431
```

[Original question page](assets/c4a44e7a0e97ec59a0d712f0d323c6163ec928683ea20d561eb33ac777033586.jpg)

<!-- Source: /api/assets/7d6ffd7d0e0068a6c6d9ca2eb523d5208f5471ddb6b05781bda2373a0843fd71.jpg; PDF page 57; full -->

```text
Test 3
Occupation: 6 ....................... .
Identity (security): Name of his 7 ........................ : Siti
Opening sum: 8 € ...................... ..
to be transferred from Fransen Bank, Utrecht
Statements: Every 9 ...................... ..
Requests: Supply information about the bank's
10 ........................ service
56
```

[Original question page](assets/7d6ffd7d0e0068a6c6d9ca2eb523d5208f5471ddb6b05781bda2373a0843fd71.jpg)

### Part 2

<!-- Source: /api/assets/28491c316578e2b6c954a0a601d2adf63aab8122f317982740bda27587b92575.jpg; PDF page 58; full -->

```text
SECTION 2 Questions 11-20
Questions 11-13
Choose the correct letter, A, B or C
THE HISTORY OF ROSEWOOD HOUSE
11 When the writer Sebastian George first saw Rosewood House, he
A thought he might rent it.
B felt it was too expensive for him.
C was unsure whether to buy it.
12 Before buying the house, George had
A experienced severe family problems.
B struggled to become a successful author.
C suffered a serious illness.
13 According to the speaker, George viewed Rosewood House as
A a rich source of material for his books.
B a way to escape from his work.
C a typical building of the region.
Listening
57
```

[Original question page](assets/28491c316578e2b6c954a0a601d2adf63aab8122f317982740bda27587b92575.jpg)

<!-- Source: /api/assets/732ae517399347978ba544d54c1e2fb8d5942e542fcfa4e72adc582014274b32.jpg; PDF page 59; full -->

```text
Test 3
Questions 14-17
Label the map below.
Write the correct letter, A-J, next to questions 14- 17.
ROSEWOOD HOUSE AND GARDENS
[Original map retained. Information Centre at bottom with a winding path upwards to HOUSE. Label A above HOUSE; B,C,D in a row to the right of HOUSE; E left and F right of the upper path; G and H successively lower on its left; I on lower right; J on bottom left. Arrows on the path point from Information Centre towards HOUSE. Labels and geometry are not replaced by answers.]
14 Pear Alley ............
15 Mulberry Garden ............
16 Shop ............
17 Tea Room ............
Questions 18-20
Complete the sentences below.
Write ONE WORD ONLY for each answer.
RIVER WALK
18 You can walk through the ........................ that goes along the river bank.
19 You can go over the ........................ and then into a wooded area.
20 On your way back, you could also go up to the ........................ .
58
```

[Original question page](assets/732ae517399347978ba544d54c1e2fb8d5942e542fcfa4e72adc582014274b32.jpg)

![Original figure](assets/732ae517399347978ba544d54c1e2fb8d5942e542fcfa4e72adc582014274b32.jpg)

### Part 3

<!-- Source: /api/assets/b82392e6a533cb7da01f8f037b710a86fa151dc5a959065640121b63f0c1305e.jpg; PDF page 60; full -->

```text
SECTION 3 Questions 21-30
Questions 21-24
Complete the sentences below.
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
MARKETING ASSIGNMENT
Listening
21 For their assignment, the students must investigate one part of the ........................ .
22 The method the students must use to collect data is ........................ .
23 In total , the students must interview ......................... people.
24 Jack thinks the music preferences of ............ ............ listeners are similar.
59
```

[Original question page](assets/b82392e6a533cb7da01f8f037b710a86fa151dc5a959065640121b63f0c1305e.jpg)

<!-- Source: /api/assets/00c904eb682545ee392b2ed3fd3422166908d8f07b22b1e0c81cedebd3d4eabf.jpg; PDF page 61; full -->

```text
Test 3
Questions 25-30
Complete the notes below.
Write NO MORE THAN TWO WORDS for each answer.
Marketing Survey: Music Preferences
Age group of interviewee
• 25 or under
• 45 or over
Music preferences
• Pop
• 25 ...................... ..
• Folk
• Easy listening
• 26 ...... ................ ..
Medium for listening to music
• Radio
• CD
• TV
• 27 ........ ............ .. ..
Source of music
• Music shops
• 28 ...................... ..
• Internet
Places for listening to music
• Disco
• Pub
• 29 ........ .... .......... ..
• Concert hall
• 30 ...................... ..
60
```

[Original question page](assets/00c904eb682545ee392b2ed3fd3422166908d8f07b22b1e0c81cedebd3d4eabf.jpg)

### Part 4

<!-- Source: /api/assets/05edd831108f2e86cdb3f94711b0400685dd427d57eda0da9939ea54bef837ae.jpg; PDF page 62; full -->

```text
Listening
SECTION 4 Questions 31-40
Questions 31-34
Choose the correct letter, A, B or C
IRELAND IN THE NEOLITHIC PERIOD
Ireland
England
31 According to the speaker, it is not clear
A when the farming economy was introduced to Ireland.
B why people began to farm in Ireland .
C where the early Irish farmers came from.
32 What point does the speaker make about breeding animals in Neolithic Ireland?
A Their numbers must have been above a certain level.
B They were under threat from wild animals.
C Some species died out during this period.
33 What does the speaker say about the transportation of animals?
A Livestock would have limited the distance the farmers could sail.
B Neolithic boats were too primitive to have been used.
C Probably only a few breeding animals were imported.
34 What is the main evidence for cereal crops in Neolithic Ireland?
A the remains of burnt grain in pots
B the marks left on pots by grains
C the patterns painted on the surface of pots
61
[Original reference map retained, labelling Ireland, Scotland and England.]
```

[Original question page](assets/05edd831108f2e86cdb3f94711b0400685dd427d57eda0da9939ea54bef837ae.jpg)

![Original figure](assets/05edd831108f2e86cdb3f94711b0400685dd427d57eda0da9939ea54bef837ae.jpg)

<!-- Source: /api/assets/e667c3d00ea39fdfbfa978f73fc4afd063c7a5c6634364e408069d494a963fc8.jpg; PDF page 63; full -->

```text
Test 3
Questions 35-40
Complete the sentences below.
Write NO MORE THAN TWO WORDS for each answer.
STONE TOOLS
35 Ploughs could either have been pulled by ............ ............ or by cattle.
The farmers needed homes which were permanent dwellings.
36 In the final stages of axe-making , ........................ and ........................ were necessary
for grinding and polishing.
37 Irish axes were exported from Ireland to ....... ............. .... and England .
POTTERY MAKING
• The colonisers used clay to make pots.
38 The ........................ of the pots was often polished to make them watertight.
39 Clay from ........................ areas was generally used.
40 Decoration was only put around the ................ ........ of the earliest pots.
62
```

[Original question page](assets/e667c3d00ea39fdfbfa978f73fc4afd063c7a5c6634364e408069d494a963fc8.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/d7e7fcf57dfb76d395c9de9926deae8a1c6a44e4bf3bcd320d3e1e8e04b65597.jpg; PDF page 64; full -->

```text
Reading



READING



READING PASSAGE 1



You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage I

below.



A The Lumière Brothers opened their



Cinematographe, at 14 Boulevard des

Capucines in Paris, to 100 paying customers

over 100 years ago, on December 8, 1895.

Before the eyes of the stunned, thrilled

audience, photographs came to life and

moved across a flat screen.



B So ordinary and routine has this become to

us that it takes a determined leap of the

imagination to grasp the impact of those first

moving images. But it is worth trying, for to

understand the initial shock of those images

is to understand the extraordinary power

and magic of cinema, the unique, hypnotic

quality that has made film the most dynamic,

effective art form of the 20th century.



C One of the Lumière Brothers’ earliest films

was a 30-second piece which showed a

section of a railway platform flooded with

sunshine. A train appears and heads straight

for the camera. And that is all that happens.

Yet the Russian director Andrei Tarkovsky,

one of the greatest of all film artists,

described the film as a ‘work of genius’. ‘As

the train approached,’ wrote Tarkovsky,

‘panic started in the theatre: people jumped

and ran away. That was the moment when

cinema was born. The frightened audience

could not accept that they were watching a

mere picture. Pictures were still, only reality

moved; this must, therefore, be reality. In

their confusion, they feared that a real train

was about to crush them.’



D Early cinema audiences often experienced

the same confusion. In time, the idea of film became familiar, the magic was accepted —



but it never stopped being magic. Film has

never lost its unique power to embrace its

audiences and transport them to a different

world. For Tarkovsky, the key to that magic

was the way in which cinema created a

dynamic image of the real flow of events. A

still picture could only imply the existence of

time, while time in a novel passed at the

whim of the reader. But in cinema, the real,

objective flow of time was captured.



E One effect of this realism was to educate the

world about itself. For cinema makes the

world smaller. Long before people travelled

to America or anywhere else, they knew

what other places looked like; they knew how

other people worked and lived.

Overwhelmingly, the lives recorded — at least

in film fiction - have been American. From

the earliest days of the industry, Hollywood

has dominated the world film market.

American imagery - the cars, the cities, the

cowboys — became the primary imagery of

film. Film carried American life and values

around the globe.



F And, thanks to film, future generations will

know the 20th century more intimately than

any other period. We can only imagine what

life was like in the 14th century or in classical

Greece. But the life of the modern world has

been recorded on film in massive,

encyclopaedic detail. We shall be known

better than any preceding generations.



G The ‘star’ was another natural consequence

of cinema. The cinema star was effectively



63
```

[Original question page](assets/d7e7fcf57dfb76d395c9de9926deae8a1c6a44e4bf3bcd320d3e1e8e04b65597.jpg)

<!-- Source: /api/assets/ab5ee521f873308639c2322827a0fa156a71ce734d47926b6b93bd03d1c8c034.jpg; PDF page 65; full -->

```text
Test 3



born in 1910. Film personalities have such

an immediate presence that, inevitably, they

become super-real. Because we watch them

so closely and because everybody in the



world seems to know who they are, they



appear more real to us than we do ourselves.



The star as magnified human self is one of

cinema's most strange and enduring

legacies.



H Cinema has also given a new lease of life to

the idea of the story. When the Lumière

Brothers and other pioneers began showing

off this new invention, it was by no means

obvious how it would be used. All that

mattered at first was the wonder of

movement. Indeed, some said that, once this

novelty had worn off, cinema would fade

away. It was no more than a passing

gimmick, a fairground attraction.



I Cinema might, for example, have become

primarily a documentary form. Or it might



have developed like television - as a strange,

noisy transfer of music, information and

narrative. But what happened was that it

became, overwhelmingly, a medium for

telling stories. Originally these were

conceived as short stories — early producers

doubted the ability of audiences to

concentrate for more than the length of a

reel. Then, in 1912, an Italian 2-hour film

was hugely successful, and Hollywood settled

upon the novel-length narrative that remains

the dominant cinematic convention of today.



J And it has all happened so quickly. Almost

unbelievably, it is a mere 100 years since

that train arrived and the audience screamed

and fled, convinced by the dangerous reality

of what they saw, and, perhaps, suddenly

aware that the world could never be the

same again — that, maybe, it could be better,

brighter, more astonishing, more real than

reality.
```

[Original question page](assets/ab5ee521f873308639c2322827a0fa156a71ce734d47926b6b93bd03d1c8c034.jpg)

<!-- Source: /api/assets/b8dc875b7bd0e908319a73a958d046bbd54c588f21aa68354ca5c9467cf6cc17.jpg; PDF page 66; full -->

```text
Questions 1-5
Reading Passage 1 has ten paragraphs, A-J.
Which paragraph contains the following information?
Write the correct letter, A-J, in boxes 1-5 on your answer sheet.
1 the location of the first cinema
2 how cinema came to focus on stories
3 the speed with which cinema has changed
4 how cinema teaches us about other cultures
5 the attraction of actors in films
Questions 6-9
Do the following statements agree with the views of the writer in Reading Passage 1?
In boxes 6- 9 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the views of the writer
if the statement contradicts the views of the writer
if it is impossible to say what the writer thinks about this
6 It is important to understand how the first audiences reacted to the cinema.
Reading
7 The Lumiere Brothers ' film about the train was one of the greatest films ever made.
8 Cinema presents a biased view of other countries.
9 Storylines were important in very early cinema.
65
```

[Original question page](assets/b8dc875b7bd0e908319a73a958d046bbd54c588f21aa68354ca5c9467cf6cc17.jpg)

<!-- Source: /api/assets/ecf63fed949da5b1e7ab91db40c765cfbf9226ae30751c427f965dc301869a36.jpg; PDF page 67; full -->

```text
Test 3
Questions 10-13
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 10-13 on your answer sheet.
10 The writer refers to the film of the train in order to demonstrate
A the simplicity of early films.
B the impact of early films.
C how short early films were.
D how imaginative early films were.
11 In Tarkovsky's opinion , the attraction of the cinema is that it
A aims to impress its audience.
B tells stories better than books.
C illustrates the passing of time.
D describes familiar events.
12 When cinema first began , people thought that
A it would always tell stories.
B it should be used in fairgrounds.
C its audiences were unappreciative.
D its future was uncertain.
13 What is the best title for this passage?
66
A The rise of the cinema star
B Cinema and novels compared .
C The domination of Hollywood
D The power of the big screen
```

[Original question page](assets/ecf63fed949da5b1e7ab91db40c765cfbf9226ae30751c427f965dc301869a36.jpg)

<!-- Source: /api/assets/1ab4d66e2fbc52812336db91b19baf3f4f635674d5f3b8be2dbe0db8cbc55648.jpg; PDF page 68; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-27 , which are based on Reading Passage 2
on the following pages.
Questions 14-18
Reading Passage 2 contains six Key Points.
Choose the correct heading for Key Points TWO to SIX from the list of headings below.
Write the correct number, i-viii, in boxes 14- 18 on your answer sheet.
List of Headings
i Ensure the reward system is fair
ii Match rewards to individuals
iii Ensure targets are realistic
iv Link rewards to achievement
v Encourage managers to take more responsibility
vi Recognise changes in employees' performance over time
vii Establish targets and give feedback
viii Ensure employees are suited to their jobs
Example Answer
Key Point One viii
14 Key Point Two
15 Key Point Three
16 Key Point Four
17 Key Point Five
18 Key Point Six
67
```

[Original question page](assets/1ab4d66e2fbc52812336db91b19baf3f4f635674d5f3b8be2dbe0db8cbc55648.jpg)

<!-- Source: /api/assets/e5ffe23b3c06003f0afc7d89fa5b40b051a1e8693798aa363cd312533f279469.jpg; PDF page 69; full -->

```text
Test 3
Motivating Employees under
Adverse Conditions .
THE CHALLENGE
It is a great deal easier to motivate employees in a growing organisation than a declining
one. When organisations are expanding and adding personnel, promotional opportunities,
pay rises, and the excitement of being associated with a dynamic organisation create
feelings of optimism . Management is able to use the growth to entice and encourage
employees. When an organisation is shrinking, the best and most mobile workers are prone
to leave voluntarily. Unfortunately, they are the ones the organisation can least afford to lose
-those with the highest skills and experience. The minor employees remain because their job
options are limited.
Morale also suffers during decline . People fear they may be the next to be made
redundant . Productivity often suffers, as employees spend their time sharing rumours and
providing one another with moral support rather than focusing on their jobs. For those whose
jobs are secure, pay increases are rarely possible. Pay cuts, unheard of during times of
growth, may even be imposed. The challenge to management is how to motivate employees
under such retrenchment conditions . The ways of meeting this challenge can be broadly
divided into six Key Points, which are outlined below.
KEY POINT ONE
There is an abundance of evidence to support the motivational benefits that result from
carefully matching people to jobs. For example, if the job is running a small business or an
autonomous unit within a larger business, high achievers should be sought. However, if the
job to be filled is a managerial post in a large bureaucratic organisation, a candidate who
has a high need for power and a low need for affiliation should be selected. Accordingly,
high achievers should not be put into jobs that are inconsistent with their needs. High
achievers will do best when the job provides moderately challenging goals and where there
is independence and feedback. However, it should be remembered that not everybody is
motivated by jobs that are high in independence, variety and responsibility .
KEY POINT TWO
The literature on goal-setting theory suggests that managers should ensure that all employees
have specific goals and receive comments on how well they are doing in those goals. For
those with high achievement needs, typically a minority in any organisation, the existence of
external goals is less important because high achievers are already internally motivated . The
next factor to be determined is whether the goals should be assigned by a manager or
collectively set in conjunction with the employees. The answer to that depends on perceptions
of goal acceptance and the organisation's culture. If resistance to goals is expected, the use
of participation in goal-setting should increase acceptance. If participation is inconsistent with
68
```

[Original question page](assets/e5ffe23b3c06003f0afc7d89fa5b40b051a1e8693798aa363cd312533f279469.jpg)

<!-- Source: /api/assets/3667a1b175ea03f6e4c4fda2d92d2b7d82519fe59faf1bb7b6f9b111766b3b11.jpg; PDF page 70; full -->

```text
Reading
the culture, however, goals should be assigned. If participation and the culture are
incongruous, employees are likely to perceive the participation process as manipulative and
be negatively affected by it.
KEY POINT THREE
Regardless of whether goals are achievable or well within management's perceptions of the
employee's ability, if employees see them as unachievable they will reduce their effort .
Managers must be sure, therefore, that employees feel confident that their efforts can lead to
performance goals. For managers, this means that employees must have the capability of
doing the job and must regard the appraisal process as valid.
KEY POINT FOUR
Since employees have different needs, what acts as a reinforcement for one may not for
another. Managers could use their knowledge of each employee to personalise the rewards
over which they have control. Some of the more obvious rewards that managers allocate
include pay, promotions, autonomy, job scope and depth, and the opportunity to participate
in goal-setting and decision-making .
KEY POINT FIVE
Managers need to make rewards contingent on performance . To reward factors other than
performance will only reinforce those other factors. Key rewards such as pay increases and
promotions or advancements should be allocated for the attainment of the employee's specific
goals. Consistent with maximising the impact of rewards, managers should look for ways to
increase their visibility . Eliminating the secrecy surrounding pay by openly communicating
everyone's remuneration, publicising performance bonuses and allocating annual salary
increases in a lump sum rather than spreading them out over an entire year are examples of
actions that will make rewards more visible and potentially more motivating .
KEY POINT SIX
The way rewards are distributed should be transparent so that employees perceive that
rewards or outcomes are equitable and equal to the inputs given. On a simplistic level,
experience, abilities, effort and other obvious inputs should explain differences in pay,
responsibility and other obvious outcomes. The problem, however, is complicated by the
existence of dozens of inputs and outcomes and by the fact that employee groups place
different degrees of importance on them. For instance, a study comparing clerical and
production workers identified nearly twenty inputs and outcomes. The clerical workers
considered factors such as quality of work performed and job knowledge near the top of
their list, but these were at the bottom of the production workers' list. Similarly, production
workers thought that the most important inputs were intelligence and personal involvement
with task accomplishment, two factors that were quite low in the importance ratings of the
clerks. There were also important, though less dramatic, differences on the outcome side. For
example, production workers rated advancement very highly, whereas clerical workers rated
advancement in the lower third of their list. Such findings suggest that one person's equity is
another's inequity, so an ideal should probably weigh different inputs and outcomes
according to employee group.
69
```

[Original question page](assets/3667a1b175ea03f6e4c4fda2d92d2b7d82519fe59faf1bb7b6f9b111766b3b11.jpg)

<!-- Source: /api/assets/3d63bcb6b8338a834b861feb71549d34e9f09cee171a918588c7fe62f9046bf3.jpg; PDF page 71; full -->

```text
Test 3
Questions 19-24
Do the following statements agree with the views of the writer in Reading Passage 2?
In boxes 19- 24 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the views of the writer
if the statement contradicts the views of the writer
if it is impossible to say what the writer thinks about this
19 A shrinking organisation tends to lose its less skilled employees rather than its more
skilled employees.
20 It is easier to manage a small business than a large business.
21 High achievers are well suited to team work.
22 Some employees can feel manipulated when asked to participate in goal-setting.
23 The staff appraisal process should be designed by employees.
24 Employees ' earnings should be disclosed to everyone within the organisation.
Questions 25-27
Look at the following groups of workers (Questions 25- 27) and the list of descriptions below.
Match each group with the correct description, A-E.
Write the correct letter, A-E, in boxes 25- 27 on your answer sheet.
25 high achievers
26 clerical workers
27 production workers
70
List of Descriptions
A They judge promotion to be important.
B They have less need of external goals.
C They think that the quality of their work is important.
D They resist goals which are imposed.
E They have limited job options.
```

[Original question page](assets/3d63bcb6b8338a834b861feb71549d34e9f09cee171a918588c7fe62f9046bf3.jpg)

<!-- Source: /api/assets/afac0d3acb06609a2bf0caa57b696aa1f9ff0c808ade99fa323ae554ff6848b2.jpg; PDF page 72; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 28-40 , which are based on Reading Passage 3
below.
The Search for the Anti-aging Pill
In government laboratories and elsewhere, scientists are seeking a drug able to prolong
life and youthful vigor. Studies of caloric restriction are showing the way
As researchers on aging noted recently, no treatment on the market today has been proved to
slow human aging- the build-up of molecular and cellular damage that increases vulnerability to ·
infirmity as we grow older . But one intervention, consumption of a low-calorie * yet nutritionally
balanced diet, works incredibly well in a broad range of animals, increasing longevity and
prolonging good health. Those findings suggest that caloric restriction could delay aging and
increase longevity in humans, too.
Unfortunately, for maximum benefit, people would probably have to reduce their caloric
intake by roughly thirty per cent , equivalent to dropping from 2,500 calories a day to 1,750 . Few
mortals could stick to that harsh a regimen, especially for years on end. But what if someone
could create a pill that mimicked the physiological effects of eating less without actually forcing
people to eat less? Could such a 'caloric-restriction mimetic', as we call it, enable people to stay
healthy longer, postponing age-related disorders (such as diabetes, arteriosclerosis , heart disease
and cancer) until very late in life? Scientists first posed this question in the mid-1990s, after
researchers came upon a chemical agent that in rodents seemed to reproduce many of caloric
restriction's benefits. No compound that would safely achieve the same feat in people has been
found yet, but the search has been informative and has fanned hope that caloric- restriction (CR)
mimetics can indeed be developed eventually .
The benefits of caloric restriction
The hunt for CR mimetics grew out of a desire to better understand caloric restriction 's many
effects on the body. Scientists first recognized the value of the practice more than 60 years ago,
when they found that rats fed a low-calorie diet lived longer on average than free-feeding rats
and also had a reduced incidence of conditions that become increasingly common in old age.
What is more, some of the treated animals survived longer than the oldest-living animals in the
control group, which means that the maximum lifespan (the oldest attainable age), not merely
the normal lifespan, increased. Various interventions, such as infection-fighting drugs, can
increase a population's average survival time, but only approaches that slow the body 's rate of
aging will increase the maximum lifespan.
The rat findings have been replicated many times and extended to creatures ranging from
yeast to fruit flies, worms, fish, spiders, mice and hamsters. Until fairly recently, the studies were
limited to short-lived creatures genetically distant from humans . But caloric-restriction projects
underway in two species more closely related to humans - rhesus and squirrel monkeys - have
made scientists optimistic that CR mimetics could help people .
* calorie: a measure of the energy value of food
71
```

[Original question page](assets/afac0d3acb06609a2bf0caa57b696aa1f9ff0c808ade99fa323ae554ff6848b2.jpg)

<!-- Source: /api/assets/bce40ce2ad70651f939b25d083cd2bc2600080859f2503e532c34b8b28333dec.jpg; PDF page 73; full -->

```text
Test 3
The monkey projects demonstrate that, compared with control animals that eat normally,
caloric-restricted monkeys have lower body temperatures and levels of the pancreatic hormone
insulin, and they retain more youthful levels of certain hormones that tend to fall with age.
The caloric-restricted animals also look better on indicators of risk for age-related diseases .
For example, they have lower blood pressure and triglyceride levels (signifying a decreased
likelihood of heart disease), and they have more normal blood glucose levels (pointing to a
reduced risk for diabetes, which is marked by unusually high blood glucose levels). Further, it has
recently been shown that rhesus monkeys kept on caloric-restricted diets for an extended time
(nearly 15 years) have less chronic disease. They and the other monkeys must be followed still
longer, however, to know whether low-calorie intake can increase both average and maximum
lifespans in monkeys. Unlike the multitude of elixirs being touted as the latest anti-aging cure, CR
mimetics would alter fundamental processes that underlie aging. We aim to develop compounds
that fool cells into activating maintenance and repair.
How a prototype caloric-restriction mimetic works
The best-studied candidate for a caloric-restriction mimetic, 2DG (2-deoxy-D-glucose), works
by interfering with the way cells process glucose . It has proved toxic at some doses in animals
and so cannot be used in humans . But it has demonstrated that chemicals can replicate the
effects of caloric restriction; the trick is finding the right one.
Cells use the glucose from food to generate ATP (adenosine triphosphate), the molecule that
powers many activities in the body. By limiting food intake, caloric restriction minimizes the
amount of glucose entering cells and decreases ATP generation. When 2DG is administered to
animals that eat normally, glucose reaches cells in abundance but the drug prevents most of it
from being processed and thus reduces ATP synthesis. Researchers have proposed several
explanations for why interruption of glucose processing and ATP production might retard aging.
One possibility relates to the ATP-making machinery's emission of free radicals, which are
thought to contribute to aging and to such age-related diseases as cancer by damaging cells.
Reduced operation of the machinery should limit their production and thereby constrain the
damage. Another hypothesis suggests that decreased processing of glucose could indicate to
cells that food is scarce (even if it isn't) and induce them to shift into an anti-aging mode that
emphasizes preservation of the organism over such 'luxuries ' as growth and reproduction .
72
```

[Original question page](assets/bce40ce2ad70651f939b25d083cd2bc2600080859f2503e532c34b8b28333dec.jpg)

<!-- Source: /api/assets/cb22620bcfdc1aec6af6f803c2cbf2aa3cf46d69f98cc5ee6c59f2077bfcbd9c.jpg; PDF page 74; full -->

```text
Reading
Questions 28-32
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 28-32 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
28 Studies show drugs available today can delay the process of growing old.
29 There is scientific evidence that eating fewer calories may extend human life.
30 Not many people are likely to find a caloric-restricted diet attractive.
31 Diet-related diseases are common in older people.
32 In experiments, rats who ate what they wanted led shorter lives than rats on a low­
calorie diet.
Questions 33-37
Classify the following descriptions as relating to
A caloric-restricted monkeys
B control monkeys
C neither caloric-restricted monkeys nor control monkeys
Write the correct letter, A, B or C, in boxes 33-37 on your answer sheet.
33 Monkeys were less likely to become diabetic.
34 Monkeys experienced more chronic disease.
35 Monkeys have been shown to experience a longer than average life span.
36 Monkeys enjoyed a reduced chance of heart disease.
37 Monkeys produced greater quantities of insulin.
73
```

[Original question page](assets/cb22620bcfdc1aec6af6f803c2cbf2aa3cf46d69f98cc5ee6c59f2077bfcbd9c.jpg)

<!-- Source: /api/assets/5a0f998e0c59b82dd63113c41119f7b4df56c8758ad330252862605fb625ffb0.jpg; PDF page 75; full -->

```text
Questions 38–40
Complete the flow-chart below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 38–40 on your answer sheet.
How a caloric-restriction mimetic works
CR mimetic → less (38) __________ is processed → production of ATP is decreased
Then two branches:
Theory 1: cells less damaged by disease because fewer (39) __________ are emitted.
Theory 2: cells focus on (40) __________ because food is in short supply.
```

[Original question page](assets/5a0f998e0c59b82dd63113c41119f7b4df56c8758ad330252862605fb625ffb0.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/67672f160013bec880a82b12f0b254515103da78d7cd52f516536929d6fb5400.jpg; PDF page 76; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagrams below show the life cycle of the silkworm and the stages in the production of silk cloth.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the original figure is retained for the complete plotted data or diagram.]
```

[Original question page](assets/67672f160013bec880a82b12f0b254515103da78d7cd52f516536929d6fb5400.jpg)

![Original figure](assets/67672f160013bec880a82b12f0b254515103da78d7cd52f516536929d6fb5400.jpg)

### Task 2

<!-- Source: /api/assets/e812c0bcc34779989bdbf0493ecfcc10607257a0cc918cb5127b8b032f65d4e5.jpg; PDF page 77; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that visitors to other countries should follow local customs and behaviour. Others disagree and think that the host country should welcome cultural differences.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/e812c0bcc34779989bdbf0493ecfcc10607257a0cc918cb5127b8b032f65d4e5.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/54fd728ebfed22b4c5e03497f63c5e335a71d26b446c164372d986f1291dd24a.jpg; PDF page 78; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself , his/her home , work or studies and other
familiar topics.
EXAMPLE
Traffic where you live
• How do most people travel to work where you live?
• What traffic problems are there in your area? [Why?]
• How do traffic problems affect you?
• How would you reduce the traffic problems in your area?
PART 2
Describe a game or sport you enjoy playing.
You should say: what kind of game or sport it is; who you play it with; where you play it; and explain why you enjoy playing it.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Children's games
Example questions:
How have games changed from the time when you were a child ?
Do you think this has been a positive change? Why?
Why do you think children like playing games?
Games and competition
Example questions:
Do you think competitive games are good or bad for children? In what ways?
How can games sometimes help to unite people?
Why is competition often seen as important in today's society?
77
```

[Original question page](assets/54fd728ebfed22b4c5e03497f63c5e335a71d26b446c164372d986f1291dd24a.jpg)

### Part 2

<!-- Source: /api/assets/54fd728ebfed22b4c5e03497f63c5e335a71d26b446c164372d986f1291dd24a.jpg; PDF page 78; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself , his/her home , work or studies and other
familiar topics.
EXAMPLE
Traffic where you live
• How do most people travel to work where you live?
• What traffic problems are there in your area? [Why?]
• How do traffic problems affect you?
• How would you reduce the traffic problems in your area?
PART 2
Describe a game or sport you enjoy playing.
You should say: what kind of game or sport it is; who you play it with; where you play it; and explain why you enjoy playing it.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Children's games
Example questions:
How have games changed from the time when you were a child ?
Do you think this has been a positive change? Why?
Why do you think children like playing games?
Games and competition
Example questions:
Do you think competitive games are good or bad for children? In what ways?
How can games sometimes help to unite people?
Why is competition often seen as important in today's society?
77
```

[Original question page](assets/54fd728ebfed22b4c5e03497f63c5e335a71d26b446c164372d986f1291dd24a.jpg)

### Part 3

<!-- Source: /api/assets/54fd728ebfed22b4c5e03497f63c5e335a71d26b446c164372d986f1291dd24a.jpg; PDF page 78; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself , his/her home , work or studies and other
familiar topics.
EXAMPLE
Traffic where you live
• How do most people travel to work where you live?
• What traffic problems are there in your area? [Why?]
• How do traffic problems affect you?
• How would you reduce the traffic problems in your area?
PART 2
Describe a game or sport you enjoy playing.
You should say: what kind of game or sport it is; who you play it with; where you play it; and explain why you enjoy playing it.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Children's games
Example questions:
How have games changed from the time when you were a child ?
Do you think this has been a positive change? Why?
Why do you think children like playing games?
Games and competition
Example questions:
Do you think competitive games are good or bad for children? In what ways?
How can games sometimes help to unite people?
Why is competition often seen as important in today's society?
77
```

[Original question page](assets/54fd728ebfed22b4c5e03497f63c5e335a71d26b446c164372d986f1291dd24a.jpg)
