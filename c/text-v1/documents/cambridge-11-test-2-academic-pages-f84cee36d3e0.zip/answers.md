# 剑雅 11 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 125

TEST 2 LISTENING
1 hostel
2 Buckleigh
3 PE9 7QT
4 waiter
5 politics
6 cycling
7 cinema
8 disabled
9 4.30 (pm) / half past four
10 07788 136711
11 A
12 B
13 B
14 D
15 C
16 E
17 G
18 D
19 B
20 F
21 A
22 A
23 C
24 B
25 B
26 B
27 A
28 D
29 C
30 E
31 social
32 factory
33 canal
34 bridge
35 box
36 screen
37 rubber
38 curved
39 curtains
40 international
11&12 IN EITHER ORDER: A,B
13&14 IN EITHER ORDER: B,D
15&16 IN EITHER ORDER: C,E
27&28 IN EITHER ORDER: A,D
29&30 IN EITHER ORDER: C,E
If you score: 0–14: unlikely; 15–28: may; 29–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. hostel

2. Buckleigh

3. PE9 7QT / PE97QT

4. waiter

5. politics

6. cycling

7. cinema

8. disabled

9. 4.30 / 4:30 / 4.30 pm / 4.30pm / 4:30 pm / 4:30pm / half past four

10. 07788 136711 / 07788136711

### Part 2 · source page 125

TEST 2 LISTENING
1 hostel
2 Buckleigh
3 PE9 7QT
4 waiter
5 politics
6 cycling
7 cinema
8 disabled
9 4.30 (pm) / half past four
10 07788 136711
11 A
12 B
13 B
14 D
15 C
16 E
17 G
18 D
19 B
20 F
21 A
22 A
23 C
24 B
25 B
26 B
27 A
28 D
29 C
30 E
31 social
32 factory
33 canal
34 bridge
35 box
36 screen
37 rubber
38 curved
39 curtains
40 international
11&12 IN EITHER ORDER: A,B
13&14 IN EITHER ORDER: B,D
15&16 IN EITHER ORDER: C,E
27&28 IN EITHER ORDER: A,D
29&30 IN EITHER ORDER: C,E
If you score: 0–14: unlikely; 15–28: may; 29–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A / B

12. A / B

13. B / D

14. B / D

15. C / E

16. C / E

17. G

18. D

19. B

20. F

### Part 3 · source page 125

TEST 2 LISTENING
1 hostel
2 Buckleigh
3 PE9 7QT
4 waiter
5 politics
6 cycling
7 cinema
8 disabled
9 4.30 (pm) / half past four
10 07788 136711
11 A
12 B
13 B
14 D
15 C
16 E
17 G
18 D
19 B
20 F
21 A
22 A
23 C
24 B
25 B
26 B
27 A
28 D
29 C
30 E
31 social
32 factory
33 canal
34 bridge
35 box
36 screen
37 rubber
38 curved
39 curtains
40 international
11&12 IN EITHER ORDER: A,B
13&14 IN EITHER ORDER: B,D
15&16 IN EITHER ORDER: C,E
27&28 IN EITHER ORDER: A,D
29&30 IN EITHER ORDER: C,E
If you score: 0–14: unlikely; 15–28: may; 29–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. A

22. A

23. C

24. B

25. B

26. B

27. A / D

28. A / D

29. C / E

30. C / E

### Part 4 · source page 125

TEST 2 LISTENING
1 hostel
2 Buckleigh
3 PE9 7QT
4 waiter
5 politics
6 cycling
7 cinema
8 disabled
9 4.30 (pm) / half past four
10 07788 136711
11 A
12 B
13 B
14 D
15 C
16 E
17 G
18 D
19 B
20 F
21 A
22 A
23 C
24 B
25 B
26 B
27 A
28 D
29 C
30 E
31 social
32 factory
33 canal
34 bridge
35 box
36 screen
37 rubber
38 curved
39 curtains
40 international
11&12 IN EITHER ORDER: A,B
13&14 IN EITHER ORDER: B,D
15&16 IN EITHER ORDER: C,E
27&28 IN EITHER ORDER: A,D
29&30 IN EITHER ORDER: C,E
If you score: 0–14: unlikely; 15–28: may; 29–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. social

32. factory

33. canal

34. bridge

35. box

36. screen

37. rubber

38. curved

39. curtains

40. international

## A 类阅读

### Academic Reading · source page 126

TEST 2 READING
1 TRUE
2 NOT GIVEN
3 TRUE
4 FALSE
5 C
6 B
7 G
8 A
9 (lifting) frame
10 hydraulic jacks
11 stabbing guides
12 (lifting) cradle
13 air bags
14 ii
15 ix
16 viii
17 i
18 iv
19 vii
20 vi
21 farming
22 canoes
23 birds
24 wood
25 B
26 C
27 C
28 D
29 B
30 A
31 C
32 B
33 H
34 NOT GIVEN
35 YES
36 NO
37 NO
38 YES
39 NOT GIVEN
40 A
25&26 IN EITHER ORDER: B,C
If you score: 0–11: unlikely; 12–24: may; 25–40: likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. TRUE

2. NOT GIVEN

3. TRUE

4. FALSE

5. C

6. B

7. G

8. A

9. frame / lifting frame

10. hydraulic jacks

11. stabbing guides

12. cradle / lifting cradle

13. air bags

14. ii

15. ix

16. viii

17. i

18. iv

19. vii

20. vi

21. farming

22. canoes

23. birds

24. wood

25. B / C

26. B / C

27. C

28. D

29. B

30. A

31. C

32. B

33. H

34. NOT GIVEN

35. YES

36. NO

37. NO

38. YES

39. NOT GIVEN

40. A

## A 类写作

### Writing material: c11-t2-w-1

British students at ONE university in England,2000→2010. No other language20→10%; French only15→10%; German only10→10%; Spanish only30→35%; another language15→20%; two other languages10→15%. Legend and slice patterns checked. Spanish largest category in both years, multilingual shares rise, English-only share halves. Each pie totals100%. English is baseline, not an additional language. Do not generalise to all British students or combine another language with two other languages as identical categories.



### Writing material: c11-t2-w-2

Evaluate how far laws are needed to increase household recycling, including the claim that legislation is the only way. Other measures may support the position but a generic environment discussion is insufficient.



## 口语
