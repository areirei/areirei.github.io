# 剑雅 11 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/586c2662c5b272d713cf8860f65af23b1d18c53b74e0b75b28d8c0938c0f397e.jpg; PDF page 32; full -->

```text
SECTION 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Enquiry about joining Youth Council
Example — Name: Roger Brown
Age: 18
Currently staying in a (1) __________ during the week
Postal address: (2) 17, __________ Street, Stamford, Lincs
Postcode: (3) __________
Occupation: student and part-time job as a (4) __________
Studying (5) __________ (major subject) and history (minor subject)
Hobbies: does a lot of (6) __________, and is interested in the (7) __________
```

[Original question page](assets/586c2662c5b272d713cf8860f65af23b1d18c53b74e0b75b28d8c0938c0f397e.jpg)

<!-- Source: /api/assets/913c0389939c7a49addece9d43987d950ce2cccd3f8ad928aafe74ecedfca00e.jpg; PDF page 33; full -->

```text
On Youth Council, wants to work with young people who are (8) __________
Will come to talk to the Elections Officer next Monday at (9) __________ pm
Mobile number: (10) __________
```

[Original question page](assets/913c0389939c7a49addece9d43987d950ce2cccd3f8ad928aafe74ecedfca00e.jpg)

### Part 2

<!-- Source: /api/assets/91ebf900c5ab85e58368db471f5d48466ab57999113a492e4c11655e93623b84.jpg; PDF page 34; full -->

```text
SECTION 2 Questions 11–20
New staff at theatre
Questions 11 and 12
Choose TWO letters, A–E.
Which TWO changes have been made so far during the refurbishment of the theatre?
A Some rooms now have a different use.
B A different type of seating has been installed.
C An elevator has been installed.
D The outside of the building has been repaired.
E Extra seats have been added.
Questions 13 and 14
Choose TWO letters, A–E.
Which TWO facilities does the theatre currently offer to the public?
A rooms for hire
B backstage tours
C hire of costumes
D a bookshop
E a café
Questions 15 and 16
Choose TWO letters, A–E.
Which TWO workshops does the theatre currently offer?
A sound
B acting
C making puppets
D make-up
E lighting
```

[Original question page](assets/91ebf900c5ab85e58368db471f5d48466ab57999113a492e4c11655e93623b84.jpg)

<!-- Source: /api/assets/6b02fcccddf2423e2c076acf765cb449053b32d86456700a2fd5abb0670c6726.jpg; PDF page 35; full -->

```text
Questions 17–20
Label the plan below. Write the correct letter, A–G, next to Questions 17–20.
Ground floor plan of theatre
[Original plan retained, with A–G, water cooler, double doors, foyer, two entrances and road. Use the plan for positions.]
17 box office __________
18 theatre manager’s office __________
19 lighting box __________
20 artistic director’s office __________
```

[Original question page](assets/6b02fcccddf2423e2c076acf765cb449053b32d86456700a2fd5abb0670c6726.jpg)

![Original figure](assets/6b02fcccddf2423e2c076acf765cb449053b32d86456700a2fd5abb0670c6726.jpg)

### Part 3

<!-- Source: /api/assets/6a1adcc7843223882f5c8705fbf8b9f935198e92e149f9209072fd4842d9eb82.jpg; PDF page 36; full -->

```text
SECTION 3 Questions 21-30
Questions 21-26
Choose the correct letter, A, B or C.
Rocky Bay field trip
21 What do the students agree should be included in their aims?
A factors affecting where organisms live
B the need to preserve endangered species
C techniques for classifying different organisms
22 What equipment did they forget to take on the Field Trip?
A string
B a compass
C a ruler
23 In Helen’s procedure section, Colin suggests a change in
A the order in which information is given.
B the way the information is divided up.
C the amount of information provided.
24 What do they say about the method they used to measure wave speed?
A It provided accurate results.
B It was simple to carry out.
C It required special equipment.
25 What mistake did Helen make when first drawing the map?
A She chose the wrong scale.
B She stood in the wrong place.
C She did it at the wrong time.
26 What do they decide to do next with their map?
A scan it onto a computer
B check it using photographs
C add information from the internet
37
```

[Original question page](assets/6a1adcc7843223882f5c8705fbf8b9f935198e92e149f9209072fd4842d9eb82.jpg)

<!-- Source: /api/assets/8de3b6935873d6e515e8f0b2756c4d97dd244ecc35e456df4a2ca7e607a88f96.jpg; PDF page 37; full -->

```text
Questions 27 and 28
Choose TWO letters, A–E.
Which TWO problems affecting organisms in the splash zone are mentioned?
A lack of water
B strong winds
C lack of food
D high temperatures
E large waves
Questions 29 and 30
Choose TWO letters, A–E.
Which TWO reasons for possible error will they include in their report?
A inaccurate records of the habitat of organisms
B influence on behaviour of organisms by observer
C incorrect identification of some organisms
D making generalisations from a small sample
E missing some organisms when counting
```

[Original question page](assets/8de3b6935873d6e515e8f0b2756c4d97dd244ecc35e456df4a2ca7e607a88f96.jpg)

### Part 4

<!-- Source: /api/assets/22f9213835114b2fde4fdb6503b02f2108dbdebaf56448606fdcbbe21de9ab41.jpg; PDF page 38; full -->

```text
SECTION 4 Questions 31-40
Complete the notes below.
Write ONE WORD ONLY for each answer.
DESIGNING A PUBLIC BUILDING:
THE TAYLOR CONCERT HALL
Introduction
The designer of a public building may need to consider the building’s
• function
physical and 31...........…·…......….........context
• symbolic meaning
Location and concept of the Concert Hall
On the site of a disused 32 ............. ..
Beside a 33
The design is based on the concept of a mystery
39
```

[Original question page](assets/22f9213835114b2fde4fdb6503b02f2108dbdebaf56448606fdcbbe21de9ab41.jpg)

<!-- Source: /api/assets/f6fe175cadf3458d4f2a1b9edf6cef9559ebb7c155778a47af3806d051b75881.jpg; PDF page 39; full -->

```text
40
Building design
It’s approached by a 34 __________ for pedestrians
The building is the shape of a 35 ............. .
One exterior wall acts as a large 36 ...
In the auditorium:
the floor is built on huge pads made of 37 ...... .
the walls are made of local wood and are 38 ....…........………... in shape
• ceiling panels and 39 ........................................... on walls allow adjustment of
acoustics
Evaluation
Some critics say the 40 ................................. style of the building is inappropriate
```

[Original question page](assets/f6fe175cadf3458d4f2a1b9edf6cef9559ebb7c155778a47af3806d051b75881.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/ff5b98fd0af2e865af8d0dc58bfe4ce639360461285990faf5383aafb2fc9055.jpg; PDF page 40; full -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Raising the Mary Rose
How a sixteenth-century warship was recovered from the seabed
On 19 July 1545, English and French
fleets were engaged in a sea battle off
the coast of southern England in the
area of water called the Solent, between
Portsmouth and the Isle of Wight. Among
the English vessels was a warship by the
name of Mary Rose. Built in Portsmouth
some 35 years earlier, she had had a long
and successful fighting career, and was
a favourite of King Henry VIII. Accounts
of what happened to the ship vary: while
witnesses agree that she was not hit
by the French, some maintain that she
was outdated, overladen and sailing too
low in the water, others that she was
mishandled by undisciplined crew. What
is undisputed, however, is that the Mary
Rose sank into the Solent that day, taking
at least 500 men with her. After the battle,
attempts were made to recover the ship,
but these failed.
The Mary Rose came to rest on the
seabed, lying on her starboard (right) side
at an angle of approximately 60 degrees.
The hull (the body of the ship) acted as
a trap for the sand and mud carried by
Solent currents. As a result, the starboard
side filled rapidly, leaving the exposed
port (left) side to be eroded by marine
organisms and mechanical degradation.
Because of the way the ship sank, nearly
all of the starboard half survived intact.
During the seventeenth and eighteenth
centuries, the entire site became covered
with a layer of hard grey clay, which
minimised further erosion.
Then, on 16 June 1836, some fishermen
in the Solent found that their equipment
was caught on an underwater obstruction,
which turned out to be the Mary Rose.
Diver John Deane happened to be
exploring another sunken ship nearby,
and the fishermen approached him,
asking him to free their gear. Deane dived
down, and found the equipment caught
on a timber protruding slightly from the
seabed. Exploring further, he uncovered
several other timbers and a bronze
gun. Deane continued diving on the
site intermittently until 1840, recovering
several more guns, two bows, various
timbers, part of a pump and various other
small finds.
The Mary Rose then faded into obscurity
for another hundred years. But in 1965,
military historian and amateur diver
Alexander McKee, in conjunction with the
British Sub-Aqua Club, initiated a project
called ‘Solent Ships’. While on paper
this was a plan to examine a number of
known wrecks in the Solent, what McKee
41
```

[Original question page](assets/ff5b98fd0af2e865af8d0dc58bfe4ce639360461285990faf5383aafb2fc9055.jpg)

<!-- Source: /api/assets/495df134a44450fb3df2d08e3f4bdd197842fdf3f695a5965a7f21f8589b7b51.jpg; PDF page 41; full -->

```text
really hoped for was to find the Mary
Rose. Ordinary search techniques proved
unsatisfactory, so McKee entered into
collaboration with Harold E. Edgerton,
professor of electrical engineering at the
Massachusetts Institute of Technology.
In 1967, Edgerton’s side-scan sonar
systems revealed a large, unusually
shaped object, which McKee believed
was the Mary Rose.
Further excavations revealed stray
pieces of timber and an iron gun. But
the climax to the operation came when,
on 5 May 1971, part of the ship’s frame
was uncovered. McKee and his team
now knew for certain that they had found
the wreck, but were as yet unaware
that it also housed a treasure trove of
beautifully preserved artefacts. Interest
in the project grew, and in 1979, The
Mary Rose Trust was formed, with Prince
Charles as its President and Dr Margaret
Rule its Archaeological Director. The
decision whether or not to salvage the
wreck was not an easy one, although
an excavation in 1978 had shown that it
might be possible to raise the hull. While
the original aim was to raise the hull if at
all feasible, the operation was not given
the go-ahead until January 1982, when all
the necessary information was available.
An important factor in trying to salvage
the Mary Rose was that the remaining
hull was an open shell. This led to an
important decision being taken: namely to
carry out the lifting operation in three very
distinct stages. The hull was attached to
a lifting frame via a network of bolts and
lifting wires. The problem of the hull being
sucked back downwards into the mud was
overcome by using 12 hydraulic jacks.
These raised it a few centimetres over a
period of several days, as the lifting frame
rose slowly up its four legs. It was only
when the hull was hanging freely from
the lifting frame, clear of the seabed and
the suction effect of the surrounding mud,
that the salvage operation progressed to
the second stage. In this stage, the lifting
frame was fixed to a hook attached to a
crane, and the hull was lifted completely
clear of the seabed and transferred
underwater into the lifting cradle. This
required precise positioning to locate the
legs into the ‘stabbing guides’ of the lifting
cradle. The lifting cradle was designed
to fit the hull using archaeological survey
drawings, and was fitted with air bags to
provide additional cushioning for the hull’s
delicate timber framework. The third and
final stage was to lift the entire structure
into the air, by which time the hull was
also supported from below. Finally, on 11
October 1982, millions of people around
the world held their breath as the timber
skeleton of the Mary Rose was lifted clear
of the water, ready to be returned home to
Portsmouth.
```

[Original question page](assets/495df134a44450fb3df2d08e3f4bdd197842fdf3f695a5965a7f21f8589b7b51.jpg)

<!-- Source: /api/assets/f78b081afffddae3fc020d47f326f85f1d5466f237ede41225a64145fe02a909.jpg; PDF page 42; full -->

```text
Questions 1-4
Do the following statements agree with the information given in Reading Passage 1?
In boxes 1-4 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
1 There is some doubt about what caused the Mary Rose to sink.
2 The Mary Rose was the only ship to sink in the battle of 19 July 1545.
3 Most of one side of the Mary Rose lay undamaged unde r the sea.
4 Alexander McKee knew that the wreck would contain many valuable
historical objects.
Questions 5–8
Look at the following statements (Questions 5–8) and the list of dates below.
Match each statement with the correct date, A–G.
Write the correct letter， A-G, in boxes 5–8 on your answer sheet.
5 A search fortheMary Rose was launched.
6 One person’s exploration of the Mary Rose site stopped.
7 It was agreed that the hull of the Mary Rose should be raised.
8 The site of the Mary Rose was found by chance.
List of Dates
A 1836
B 1840
C 1965
D 1967
E 1971
F 1979
G 1982
43
```

[Original question page](assets/f78b081afffddae3fc020d47f326f85f1d5466f237ede41225a64145fe02a909.jpg)

<!-- Source: /api/assets/b4a0b1eddce525e5703958fd51a19ea85870a08e38be230bec079b76207bb959.jpg; PDF page 43; full -->

```text
Questions 9–13
Label the diagram below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 9–13 on your answer sheet.
Raising the hull of the Mary Rose: Stages one and two
[Original two-stage diagrams retained: legs, hull of ship, crane and hook.]
(9) __________ attached to hull by wires
(10) __________ to prevent hull being sucked into mud
legs are placed into (11) __________
hull is lowered into (12) __________
(13) __________ used as extra protection for the hull
```

[Original question page](assets/b4a0b1eddce525e5703958fd51a19ea85870a08e38be230bec079b76207bb959.jpg)

![Original figure](assets/b4a0b1eddce525e5703958fd51a19ea85870a08e38be230bec079b76207bb959.jpg)

<!-- Source: /api/assets/ed37500c452a687b56c37992cccc4d3d6171c0fd1d8fec20247306a3025e1cb9.jpg; PDF page 44; full -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14–26, which are based on Reading Passage 2 on the following pages.
Questions 14–20
Reading Passage 2 has seven paragraphs, A–G.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i–ix, in boxes 14–20 on your answer sheet.
List of Headings
i Evidence of innovative environment management practices
ii An undisputed answer to a question about the moai
iii The future of the moai statues
iv A theory which supports a local belief
v The future of Easter Island
vi Two opposing views about the Rapanui people
vii Destruction outside the inhabitants’ control
viii How the statues made a situation worse
ix Diminishing food resources
14 Paragraph A
15 Paragraph B
16 Paragraph C
17 Paragraph D
18 Paragraph E
19 Paragraph F
20 Paragraph G
```

[Original question page](assets/ed37500c452a687b56c37992cccc4d3d6171c0fd1d8fec20247306a3025e1cb9.jpg)

<!-- Source: /api/assets/9d5e00bbe28525c20c3e22a9ec579fd9790a58a74d9931cca3bbd6c4674bbb5f.jpg; PDF page 45; full -->

```text
What destroyed the civilisation of Easter Island?
A Easter Island, or Rapu Nui as it is known locally, is home to several hundred
ancient human statues — the moai. After this remote Pacific island was settled by
the Polynesians, it remained isolated for centuries. All the energy and resources
that went into the moai — some of which are ten metres tall and weigh over 7,000
kilos — came from the island itself. Yet when Dutch explorers landed in 1722, they
met a Stone Age culture. The moai were carved with stone tools, then transported
for many kilometres, without the use of animals or wheels, to massive stone
platforms. The identity of the moai builders was in doubt until well into the twentieth
century. Thor Heyerdahl, the Norwegian ethnographer and adventurer, thought the
statues had been created by pre-Inca peoples from Peru. Bestselling Swiss author
Erich von Daniken believed they were built by stranded extraterrestrials. Modern
science — linguistic, archaeological and genetic evidence — has definitively proved
the moai builders were Polynesians, but not how they moved their creations.
Local folklore maintains that the statues walked, while researchers have tended to
assume the ancestors dragged the statues somehow, using ropes and logs.
B When the Europeans arrived, Rapa Nui was grassland, with only a few scrawny
trees. In the 1970s and 1980s, though, researchers found pollen preserved in
lake sediments, which proved the island had been covered in lush palm forests for
thousands of years. Only after the Polynesians arrived did those forests disappear.
US scientist Jared Diamond believes that the Rapanui people — descendants of
Polynesian settlers — wrecked their own environment. They had unfortunately
settled on an extremely fragile island — dry, cool, and too remote to be properly
fertilised by windblown volcanic ash. When the islanders cleared the forests for
firewood and farming, the forests didn’t grow back. As trees became scarce and
they could no longer construct wooden canoes for fishing, they ate birds. Soil
erosion decreased their crop yields. Before Europeans arrived, the Rapanui had
descended into civil war and cannibalism, he maintains. The collapse of their
isolated civilisation, Diamond writes, is a ‘worst-case scenario for what may lie
ahead of us in our own future’
C The moai, he thinks, accelerated the self-destruction. Diamond interprets them
as power displays by rival chieftains who, trapped on a remote little island, lacked
other ways of asserting their dominance. They competed by building ever bigger
figures. Diamond thinks they laid the moai on wooden sledges, hauled over log
rails, but that required both a lot of wood and a lot of people. To feed the people,
even more land had to be cleared. When the wood was gone and civil war began,
the islanders began toppling the moai. By the nineteenth century none were
standing.
```

[Original question page](assets/9d5e00bbe28525c20c3e22a9ec579fd9790a58a74d9931cca3bbd6c4674bbb5f.jpg)

<!-- Source: /api/assets/406b067d4d48571495255db4d71a561115a033ade06db11e52029bfa993846e7.jpg; PDF page 46; full -->

```text
D Archaeologists Terry Hunt of the University of Hawaii and Carl Lipo of California
State University agree that Easter Island lost its lush forests and that it was an
‘ecological catastrophe’ — but they believe the islanders themselves weren't to
blame. And the moai certainly weren't. Archaeological excavations indicate that the
Rapanui went to heroic efforts to protect the resources of their wind-lashed, infertile
fields. They built thousands of circular stone windbreaks and gardened inside them,
and used broken volcanic rocks to keep the soil moist. In short, Hunt and Lipo
argue, the prehistoric Rapanui were pioneers of sustainable farming.
E Hunt and Lipo contend that moai-building was an activity that helped keep the
peace between islanders. They also believe that moving the moai required few
people and no wood, because they were walked upright. On that issue, Hunt and
Lipo say, archaeological evidence backs up Rapanui folklore. Recent experiments
indicate that as few as 18 people could, with three strong ropes and a bit of
practice, easily manoeuvre a 1,000 kg moai replica a few hundred metres. The
figures’ fat bellies tilted them forward, and a D-shaped base allowed handlers to roll
and rock them side to side.
F Moreover, Hunt and Lipo are convinced that the settlers were not wholly
responsible for the loss of the island's trees. Archaeological finds of nuts from the
extinct Easter Island palm show tiny grooves, made by the teeth of Polynesian
rats. The rats arrived along with the settlers, and in just a few years, Hunt and Lipo
calculate, they would have overrun the island. They would have prevented the
reseeding of the slow-growing palm trees and thereby doomed Rapa Nui’s forest,
even without the settlers’ campaign of deforestation. No doubt the rats ate birds’
eggs too. Hunt and Lipo also see no evidence that Rapanui civilisation collapsed
when the palm forest did. They think its population grew rapidly and then remained
more or less stable until the arrival of the Europeans, who introduced deadly
diseases to which islanders had no immunity. Then in the nineteenth century slave
traders decimated the population, which shrivelled to 111 people by 1877.
G Hunt and Lipo’s vision, therefore, is one of an island populated by peaceful and
ingenious moai builders and careful stewards of the land, rather than by reckless
destroyers ruining their own environment and society. ‘Rather than a case of abject
failure, Rapu Nui is an unlikely story of success’, they claim. Whichever is the case,
there are surely some valuable lessons which the world at large can learn from the
story of Rapa Nui.
47
```

[Original question page](assets/406b067d4d48571495255db4d71a561115a033ade06db11e52029bfa993846e7.jpg)

<!-- Source: /api/assets/1c7c691807ab3147d16c6d679e8f108b3aa709171175c31ad3245028fe046611.jpg; PDF page 47; full -->

```text
Questions 21-24
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 21-24 on your answer sheet.
Jared Diamond ’s View
Diamond believes that the Polynesian settlers on Rapa Nui destroyed its forests, cutting
down its trees for fuel and clearing land for 21 ........….......... . Twentieth-century discoveries
of pollen prove that Rapu Nui had once been covered in palm forests, which had turned
into grassland by the time the Europeans arrived on the island. When the islanders were
no longer able to build the 22 .... ..... . .. they needed to go fishing, they began using the
island’s 23 ..... .... . .. as a food source, according to Diamond. Diamond also claims that
the moai were built to show the power of the island’s chieftains, and that the methods of
transporting the statues needed not only a great number of people, but also a great deal
of 24 ..............…
Questions 25 and 26
Choose TWO letters, A-E.
Write the correct letters in boxes 25 and 26 on your answer sheet.
On what points do Hunt and Lipo disagree with Diamond?
A the period when the moai were created
B how the moai were transported
C the impact of the moai on Rapanui society
D how the moai were carved
E the origins of the people who made the moai
```

[Original question page](assets/1c7c691807ab3147d16c6d679e8f108b3aa709171175c31ad3245028fe046611.jpg)

<!-- Source: /api/assets/c291304f05b81b0dc1ff48fdf1512ad9d42513b4fdd55b95758c9d1e05840d21.jpg; PDF page 48; full -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Neuroaesthetics
An emerging discipline called neuroaesthetics is seeking to bring scientific objectivity to
the study of art, and has already given us a better understanding of many masterpieces.
The blurred imagery of Impressionist paintings seems to stimulate the brain’s amygdala, for
instance. Since the amygdala plays a crucial role in our feelings, that finding might explain why
many people find these pieces so moving.
Could the same approach also shed light on abstract twentieth-century pieces, from
Mondrian’s geometrical blocks of colour, to Pollock's seemingly haphazard arrangements
of splashed paint on canvas? Sceptics believe that people claim to like such works simply
because they are famous. We certainly do have an inclination to follow the crowd. When
asked to make simple perceptual decisions such as matching a shape to its rotated image, for
example, people often choose a definitively wrong answer if they see others doing the same.
It is easy to imagine that this mentality would have even more impact on a fuzzy concept like
art appreciation, where there is no right or wrong answer.
Angelina Hawley-Dolan, of Boston College, Massachusetts, responded to this debate by
asking volunteers to view pairs of paintings - either the creations of famous abstract artists or
the doodles of infants, chimps and elephants. They then had to judge which they preferred.
A third of the paintings were given no captions, while many were labelled incorrectly -
volunteers might think they were viewing a chimp’s messy brushstrokes when they were
actually seeing an acclaimed masterpiece. In each set of trials, volunteers generally preferred
the work of renowned artists, even when they believed it was by an animal or a child. It seems
that the viewer can sense the artist's vision in paintings, even if they can’t explain why.
Robert Pepperell, an artist based at Cardiff University, creates ambiguous works that
are neither entirely abstract nor clearly representational. In one study, Pepperell and his
collaborators asked volunteers to decide how ‘powerful’ they considered an artwork to be,
and whether they saw anything familiar in the piece. The longer they took to answer these
questions, the more highly they rated the piece under scrutiny, and the greater their neural
activity. It would seem that the brain sees these images as puzzles, and the harder it is to
decipher the meaning, the more rewarding is the moment of recognition.
49
```

[Original question page](assets/c291304f05b81b0dc1ff48fdf1512ad9d42513b4fdd55b95758c9d1e05840d21.jpg)

<!-- Source: /api/assets/13c484ed9120cae4ebfdd4a2c1ca208599c1700843e5d9d5db51bd6deb1e0d62.jpg; PDF page 49; full -->

```text
And what about artists such as Mondrian, whose paintings consist exclusively of horizontal
and vertical lines encasing blocks of colour? Mondrian’s works are deceptively simple, but
eye-tracking studies confirm that they are meticulously composed, and that simply rotating a
piece radically changes the way we view it. With the originals, volunteers’ eyes tended to stay
longer on certain places in the image, but with the altered versions they would flit across a
piece more rapidly. As a result, the volunteers considered the altered versions less pleasurable
when they later rated the work.
In a similar study, Oshin Vartanian of Toronto University asked volunteers to compare original
paintings with ones which he had altered by moving objects around within the frame. He
found that almost everyone preferred the original, whether it was a Van Gogh still life or
an abstract by Miró. Vartanian also found that changing the composition of the paintings
reduced activation in those brain areas linked with meaning and interpretation.
In another experiment, Alex Forsythe of the University of Liverpool analysed the visual
intricacy of different pieces of art, and her results suggest that many artists use a key level of
detail to please the brain. Too little and the work is boring, but too much results in a kind of
‘perceptual overload’, according to Forsythe. What's more, appealing pieces both abstract and
representational, show signs of ‘fractals’- repeated motifs recurring in different scales. Fractals
are common throughout nature, for example in the shapes of mountain peaks or the branches
of trees. It is possible that our visual system, which evolved in the great outdoors, finds it
easier to process such patterns.
It is also intriguing that the brain appears to process movement when we see a handwritten
letter, as if we are replaying the writer's moment of creation. This has led some to wonder
whether Pollock's works feel so dynamic because the brain reconstructs the energetic actions
the artist used as he painted. This may be down to our brain's ‘mirror neurons’, which are
known to mimic others’ actions. The hypothesis will need to be thoroughly tested, however. It
might even be the case that we could use neuroaesthetic studies to understand the longevity
of some pieces of artwork. While the fashions of the time might shape what is currently
popular, works that are best adapted to our visual system may be the most likely to linger
once the trends of previous generations have been forgotten.
It’s still early days for the field of neuroaesthetics - and these studies are probably only a taste
of what is to come. It would, however, be foolish to reduce art appreciation to a set of scientific
laws. We shouldn't underestimate the importance of the style of a particular artist, their place
in history and the artistic environment of their time. Abstract art offers both a challenge and
the freedom to play with different interpretations. In some ways, it’s not so different to science,
where we are constantly looking for systems and decoding meaning so that we can view and
appreciate the world in a new way.
50
```

[Original question page](assets/13c484ed9120cae4ebfdd4a2c1ca208599c1700843e5d9d5db51bd6deb1e0d62.jpg)

<!-- Source: /api/assets/1aed74a7e041bde1c317e612d6951ef9b2cbd6e4c5923974febd59bd9fd643c4.jpg; PDF page 50; full -->

```text
Questions 27-30
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-30 on your answer sheet.
27 In the second paragraph, the writer refers to a shape-matching test in order to
illustrate
A the subjective nature of art appreciation.
B the reliance of modern art on abstract forms.
C our tendency to be influenced by the opinions of others.
D a common problem encountered when processing visual data.
28 Angelina Hawley-Dolan’s findings indicate that people
A mostly favour works of art which they know well.
B hold fixed ideas about what makes a good work of art.
C are often misled by their initial expectations of a work of art.
D have the ability to perceive the intention behind works of art.
29 Results of studies involving Robert Pepperell’s pieces suggest that people
A can appreciate a painting without fully understanding it.
B find it satisfying to work out what a painting represents.
C vary widely in the time they spend looking at paintings.
D generally prefer representational art to abstract art.
30 What do the experiments described in the fifth paragraph suggest about the
paintings of Mondrian?
A They are more carefully put together than they appear.
B They can be interpreted in a number of different ways.
C They challenge our assumptions about shape and colour.
D They are easier to appreciate than many other abstract works.
51
```

[Original question page](assets/1aed74a7e041bde1c317e612d6951ef9b2cbd6e4c5923974febd59bd9fd643c4.jpg)

<!-- Source: /api/assets/5b0e2329937266f5d07e397630c6aec3352fc20ca284723808534bda4ebce160.jpg; PDF page 51; full -->

```text
Questions 31–33
Complete the summary using the list of words, A-H, below.
Write the correct letters, A-H, in boxes 31-33 on your answer sheet.
Art and the Brain
The discipline of neuroaesthetics aims to bring scientific objectivity to the study of
art. Neurological studies of the brain, for example, demonstrate the impact which
Impressionist paintings have on our 31 ...... .....“. Alex Forsythe of the University of
Liverpool believes many artists give their works the precise degree of 32 .... ...... ...... which
most appeals to the viewer’s brain. She also observes that pleasing works of art often
contain certain repeated 33 ...................... which occur frequently in the natural world.
52
A interpretation
D movements
G concern
B complexity
E skill
H images
C emotions
F layout
```

[Original question page](assets/5b0e2329937266f5d07e397630c6aec3352fc20ca284723808534bda4ebce160.jpg)

<!-- Source: /api/assets/53accf6817b4ae464310c9ab50a5ea482f59a965186cb4b90824b8fb9c16b58e.jpg; PDF page 52; full -->

```text
Questions 34-39
Do the following statements agree with the views of the writer in Reading Passage 3?
In boxes 34-39 on your answer sheet, write
YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if there is no information on this
34 Forsythe ’s findings contradicted previous beliefs on the function of fractals ’ in art.
35 Certain ideas regarding the link between 'mirror neurons’ and art appreciation
require further verification.
36 People’s taste in paintings depends entirely on the current artistic trends of the
period.
37 Scientists should seek to define the precise rules which govern people’s reactions
to works of art.
38 Art appreciation should always involve taking into consideration the cultu ral context
in which an artist worked.
39 It is easier to find meaning in the field of science than in that of art
Question 40
Choose the correct letter, A, B, C or D.
Write the correct letter in box 40 on your answer sheet.
40 What would be the most appropriate subtitle for the article?
A Some scientific insights into how the brain responds to abstract art
B Recent studies focusing on the neural activity of abstract artists
C A comparison of the neurological bases of abstract and representational art
D How brain research has altered public opinion about abstract art
53
```

[Original question page](assets/53accf6817b4ae464310c9ab50a5ea482f59a965186cb4b90824b8fb9c16b58e.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/981b0cdb39e32530e07bbf1f08bb0f563f7d36fecdbe9c26c5ea873787a3990a.jpg; PDF page 53; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below show the proportions of British students at one university in England who were able to speak other languages in addition to English, in 2000 and 2010.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/981b0cdb39e32530e07bbf1f08bb0f563f7d36fecdbe9c26c5ea873787a3990a.jpg)

![Original figure](assets/981b0cdb39e32530e07bbf1f08bb0f563f7d36fecdbe9c26c5ea873787a3990a.jpg)

### Task 2

<!-- Source: /api/assets/e441e1a651b8f6650b2dd1335b27f660b79e599ecdf494ac17e2eae468fcc8c0.jpg; PDF page 54; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people claim that not enough of the waste from homes is recycled. They say that the only way to increase recycling is for governments to make it a legal requirement.

To what extent do you think laws are needed to make people recycle more of their waste?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/e441e1a651b8f6650b2dd1335b27f660b79e599ecdf494ac17e2eae468fcc8c0.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/51b5b646df5012d46843364a40f5edcb03304dd69e58677e9415631186624377.jpg; PDF page 55; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics.
EXAMPLE
Friends
– How often do you go out with friends? [Why/Why not?]
– Tell me about your best friend at school.
– How friendly are you with your neighbours? [Why/Why not?]
– Which is more important to you, friends or family? [Why?]
PART 2
Describe a writer you would like to meet.
You should say:
– who the writer is
– what you know about this writer already
– what you would like to find out about him/her
and explain why you would like to meet this writer.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Reading and children
Example questions:
What kinds of book are most popular with children in your country? Why do you think that is?
Why do you think some children do not read books very often?
How do you think children can be encouraged to read more?
Reading for different purposes
Example questions:
Are there any occasions when reading at speed is a useful skill to have? What are they?
Are there any jobs where people need to read a lot? What are they?
Do you think that reading novels is more interesting than reading factual books? Why is that?
```

[Original question page](assets/51b5b646df5012d46843364a40f5edcb03304dd69e58677e9415631186624377.jpg)

### Part 2

<!-- Source: /api/assets/51b5b646df5012d46843364a40f5edcb03304dd69e58677e9415631186624377.jpg; PDF page 55; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics.
EXAMPLE
Friends
– How often do you go out with friends? [Why/Why not?]
– Tell me about your best friend at school.
– How friendly are you with your neighbours? [Why/Why not?]
– Which is more important to you, friends or family? [Why?]
PART 2
Describe a writer you would like to meet.
You should say:
– who the writer is
– what you know about this writer already
– what you would like to find out about him/her
and explain why you would like to meet this writer.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Reading and children
Example questions:
What kinds of book are most popular with children in your country? Why do you think that is?
Why do you think some children do not read books very often?
How do you think children can be encouraged to read more?
Reading for different purposes
Example questions:
Are there any occasions when reading at speed is a useful skill to have? What are they?
Are there any jobs where people need to read a lot? What are they?
Do you think that reading novels is more interesting than reading factual books? Why is that?
```

[Original question page](assets/51b5b646df5012d46843364a40f5edcb03304dd69e58677e9415631186624377.jpg)

### Part 3

<!-- Source: /api/assets/51b5b646df5012d46843364a40f5edcb03304dd69e58677e9415631186624377.jpg; PDF page 55; full -->

```text
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other familiar topics.
EXAMPLE
Friends
– How often do you go out with friends? [Why/Why not?]
– Tell me about your best friend at school.
– How friendly are you with your neighbours? [Why/Why not?]
– Which is more important to you, friends or family? [Why?]
PART 2
Describe a writer you would like to meet.
You should say:
– who the writer is
– what you know about this writer already
– what you would like to find out about him/her
and explain why you would like to meet this writer.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Reading and children
Example questions:
What kinds of book are most popular with children in your country? Why do you think that is?
Why do you think some children do not read books very often?
How do you think children can be encouraged to read more?
Reading for different purposes
Example questions:
Are there any occasions when reading at speed is a useful skill to have? What are they?
Are there any jobs where people need to read a lot? What are they?
Do you think that reading novels is more interesting than reading factual books? Why is that?
```

[Original question page](assets/51b5b646df5012d46843364a40f5edcb03304dd69e58677e9415631186624377.jpg)
