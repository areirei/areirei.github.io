# 剑雅 8 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 153

TEST 2 LISTENING
Section 1, Questions 1–10
1 Milperra
2 First Class Movers
3 28 November
4 screen
5 bathroom
6 door
7 140
8 leg
9 plates
10 60
Section 2, Questions 11–20
11 B
12 (the) Forest
13 Fish Farm(s)
14 Market Garden
15 C
16 A
17 C
18 B
19 C
20 A
Section 3, Questions 21–30
21 A
22 B
23 C
24 A
25 insects
26 feeding / eating
27 laboratory
28 water
29 wings
30 reliable / accurate
Section 4, Questions 31–40
31 B
32 B
33 A
34 A
35 C
36 C
37 B
38 F
39 D
40 C
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. Milperra

2. First Class Movers

3. 28 November

4. screen

5. bathroom

6. door

7. 140

8. leg

9. plates

10. 60

### Part 2 · source page 153

TEST 2 LISTENING
Section 1, Questions 1–10
1 Milperra
2 First Class Movers
3 28 November
4 screen
5 bathroom
6 door
7 140
8 leg
9 plates
10 60
Section 2, Questions 11–20
11 B
12 (the) Forest
13 Fish Farm(s)
14 Market Garden
15 C
16 A
17 C
18 B
19 C
20 A
Section 3, Questions 21–30
21 A
22 B
23 C
24 A
25 insects
26 feeding / eating
27 laboratory
28 water
29 wings
30 reliable / accurate
Section 4, Questions 31–40
31 B
32 B
33 A
34 A
35 C
36 C
37 B
38 F
39 D
40 C
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. B

12. Forest / the Forest

13. Fish Farm / Fish Farms

14. Market Garden

15. C

16. A

17. C

18. B

19. C

20. A

### Part 3 · source page 153

TEST 2 LISTENING
Section 1, Questions 1–10
1 Milperra
2 First Class Movers
3 28 November
4 screen
5 bathroom
6 door
7 140
8 leg
9 plates
10 60
Section 2, Questions 11–20
11 B
12 (the) Forest
13 Fish Farm(s)
14 Market Garden
15 C
16 A
17 C
18 B
19 C
20 A
Section 3, Questions 21–30
21 A
22 B
23 C
24 A
25 insects
26 feeding / eating
27 laboratory
28 water
29 wings
30 reliable / accurate
Section 4, Questions 31–40
31 B
32 B
33 A
34 A
35 C
36 C
37 B
38 F
39 D
40 C
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. A

22. B

23. C

24. A

25. insects

26. feeding / eating

27. laboratory

28. water

29. wings

30. reliable / accurate

### Part 4 · source page 153

TEST 2 LISTENING
Section 1, Questions 1–10
1 Milperra
2 First Class Movers
3 28 November
4 screen
5 bathroom
6 door
7 140
8 leg
9 plates
10 60
Section 2, Questions 11–20
11 B
12 (the) Forest
13 Fish Farm(s)
14 Market Garden
15 C
16 A
17 C
18 B
19 C
20 A
Section 3, Questions 21–30
21 A
22 B
23 C
24 A
25 insects
26 feeding / eating
27 laboratory
28 water
29 wings
30 reliable / accurate
Section 4, Questions 31–40
31 B
32 B
33 A
34 A
35 C
36 C
37 B
38 F
39 D
40 C
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. B

32. B

33. A

34. A

35. C

36. C

37. B

38. F

39. D

40. C

## A 类阅读

### Academic Reading · source page 154

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 spinning
2 (perfectly) unblemished
3 labour / labor-intensive
4 thickness
5 marked
6 (molten) glass
7 (molten) tin / metal
8 rollers
9 TRUE
10 NOT GIVEN
11 FALSE
12 TRUE
13 TRUE
Reading Passage 2, Questions 14–26
14 ii
15 vii
16 ix
17 iv
18–19 IN EITHER ORDER: C; B
20 A
21 H
22 G
23 C
24 C
25 A
26 B
Reading Passage 3, Questions 27–40
27 viii
28 ii
29 vi
30 i
31 iii
32 v
33 C
34 A
35 C
36 D
37 clothing
38 vocabulary
39 chemicals
40 cultures
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. spinning

2. unblemished / perfectly unblemished

3. labour-intensive / labor-intensive

4. thickness

5. marked

6. glass / molten glass

7. tin / molten tin / metal

8. rollers

9. TRUE

10. NOT GIVEN

11. FALSE

12. TRUE

13. TRUE

14. ii

15. vii

16. ix

17. iv

18. C / B

19. C / B

20. A

21. H

22. G

23. C

24. C

25. A

26. B

27. viii

28. ii

29. vi

30. i

31. iii

32. v

33. C

34. A

35. C

36. D

37. clothing

38. vocabulary

39. chemicals

40. cultures

## A 类写作

### Writing material: c8-t2-w-1

Percentages of annual spending at ONE UK school, 1981/1991/2001. Teachers' salaries40/50/45%; other workers' salaries28/22/15%; resources such as books15/20/9%; furniture and equipment15/5/23%; insurance2/3/8%. Each year totals100%. Teachers' salaries remain the largest share; insurance the smallest, despite quadrupling its share. Other workers' salaries decline steadily. Resources rise then fall; furniture/equipment falls sharply then rises to its highest share in 2001. Actual budget totals are not supplied, so a fall in percentage does not establish a fall in absolute money spent.



### Writing material: c8-t2-w-2

Two explicit requirements: explain how technology changes the TYPES of relationships people form, and evaluate the development as positive or negative. Do not only list advantages and disadvantages without answering the first question. A justified qualified evaluation is acceptable.



## 口语
