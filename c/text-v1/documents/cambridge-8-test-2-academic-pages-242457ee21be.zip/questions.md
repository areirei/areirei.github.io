# 剑雅 8 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/8c64c7f542f8b5c518930398b248c8e81869157ff55dc6ff17c399744d9e3cd6.jpg; PDF page 32; full -->

```text
SECTION 1 Questions 1–10
Questions 1–3
Complete the form below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
TOTAL INSURANCE INCIDENT REPORT
Example — Name: Michael Alexander
Address: 24 Manly Street, (1) __________, Sydney
Shipping agent: (2) __________
Place of origin: China
Date of arrival: (3) __________
Reference number: 601 ACK
```

[Original question page](assets/8c64c7f542f8b5c518930398b248c8e81869157ff55dc6ff17c399744d9e3cd6.jpg)

<!-- Source: /api/assets/ed253974406ea3b7f1db0617151d1452dd3a73bcb0ff5c5783d5cc915e9b8b70.jpg; PDF page 33; full -->

```text
Questions 4–10
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
| Item | Damage | Cost to repair / replace |
| --- | --- | --- |
| Television | The (4) __________ needs to be replaced | not known |
| The (5) __________ cabinet | The (6) __________ of the cabinet is damaged | (7) $__________ |
| Dining room table | A (8) __________ is split | $200 |
| Set of china | Six (9) __________ were broken | about (10) $__________ in total |
```

[Original question page](assets/ed253974406ea3b7f1db0617151d1452dd3a73bcb0ff5c5783d5cc915e9b8b70.jpg)

### Part 2

<!-- Source: /api/assets/ce36822d0f2dceb6270f25036d26d6323f70e060e21c3edbdb939f005bb371ef.jpg; PDF page 34; full -->

```text
SECTION 2 Questions 11-20
Question 11
Choose the correct letter, A, B or C.
11 According to the speaker, the main purposes of the park are
A education and entertainment.
B research and education.
C research and entertainment.
Questions 12-14
Label the plan below.
Write NO MORE THAN TWO WORDS for each answer.
Agricultural Park
[Original map retained. Compass: north up, east right. Entrance / YOU ARE HERE points east into the Reception Block on the west edge. Rare Breeds Section is northwest; Grazing Area north-centre; (12) __________ Area northeast; Experimental Crops Area inside the looped path in the centre; Lake is south of that, with two small rectangular features indicated by The (13) __________; Marsh lies on the east side below area12; (14) __________ Area southeast beneath the Marsh. Labels describe printed locations without supplying answers.]
```

[Original question page](assets/ce36822d0f2dceb6270f25036d26d6323f70e060e21c3edbdb939f005bb371ef.jpg)

![Original figure](assets/ce36822d0f2dceb6270f25036d26d6323f70e060e21c3edbdb939f005bb371ef.jpg)

<!-- Source: /api/assets/f30061cf5937994c2f019b30bd9124dbf8d0af49d829ab70147af47c40871834.jpg; PDF page 35; full -->

```text
Test2
Questions 15-20
Choose the correct letter, A, B or C.
15 When are the experimental areas closed to the public?
A all the year round
B almost all the year
C a short time every year
16 How can you move around the park?
A by tram, walking or bicycle
B by solar car or bicycle
C by bicycle, walking or bus
17 The rare breed animals kept in the park include
A hens and horses.
B goats and cows.
C goats and hens.
18 What is the main purpose of having the Rare Breeds Section?
A to save unusual animals
B to keep a variety of breeds
C to educate the public
19 What can you see in the park at the present time?
A the arrival of wild birds
B fruit tree blossom
C a demonstration of fishing
20 The shop contains books about
A animals.
B local traditions.
C the history of the park.
36
```

[Original question page](assets/f30061cf5937994c2f019b30bd9124dbf8d0af49d829ab70147af47c40871834.jpg)

### Part 3

<!-- Source: /api/assets/46cd80c5b005e5e1ac15e7f85892d0d6bc62b3e92a80f87f96a10fe74c830724.jpg; PDF page 36; full -->

```text
SECTION 3
Questions 21-24
Questions 21-30
Choose the correct letter, A, B or C.
Honey Bees in Australia
21 Where in Australia have Asian honey bees been found in the past?
A Queensland
B New South Wales
C several states
22 A problem with Asian honey bees is that they
A attack native bees.
B carry parasites.
C damage crops.
23 What point is made about Australian bees?
A Their honey varies in quality.
B Their size stops them from pollinating some flowers.
C They are sold to customers abroad.
24 Grant Freeman says that if Asian honey bees got into Australia,
A the country's economy would be affected.
B they could be used in the study of allergies.
C certain areas of agriculture would benefit.
Listening
37
```

[Original question page](assets/46cd80c5b005e5e1ac15e7f85892d0d6bc62b3e92a80f87f96a10fe74c830724.jpg)

<!-- Source: /api/assets/a7ba4fda563b7b98d1382cb95264a92c319be87489c79c293eb94ced50151420.jpg; PDF page 37; full -->

```text
Test2
Questions 25-30
Complete the summary below.
Write ONE WORD ONLY for each answer.
Looking for Asian honey bees
Birds called Rainbow Bee Eaters eat only 25 ....................... , and cough up small
bits of skeleton and other products in a pellet.
Researchers go to the locations the bee eaters like to use for 26 ....................... .
They collect the pellets and take them to a 27 ....................... for analysis.
Here 28 ....................... is used to soften them, and the researchers look for the
29 ....................... of Asian bees in the pellets.
The benefit of this research is that the result is more 30 ....................... than
searching for live Asian bees.
38
```

[Original question page](assets/a7ba4fda563b7b98d1382cb95264a92c319be87489c79c293eb94ced50151420.jpg)

### Part 4

<!-- Source: /api/assets/e46dbbe0259e3b57a81ed833f57a647b98f7f0d6ac53ff38ef320c561f8fc246.jpg; PDF page 38; full -->

```text
SECTION 4
Questions 31-36
Questions 31-40
Choose the correct letter, A, B or C.
Research on questions about doctors
31 In order to set up her research programme, Shona got
A advice from personal friends in other countries.
B help from students in other countries.
C information from her tutor's contacts in other countries.
32 What types of people were included in the research?
A young people in their first job
B men who were working
C women who were unemployed
33 Shona says that in her questionnaire her aim was
A to get a wide range of data.
B to limit people's responses.
C to guide people through interviews.
34 What do Shona's initial results show about medical services in Britain?
A Current concerns are misrepresented by the press.
B Financial issues are critical to the government.
C Reforms within hospitals have been unsuccessful.
35 Shona needs to do further research in order to
A present the government with her findings.
B decide the level of extra funding needed.
C identify the preferences of the public.
36 Shona has learnt from the research project that
A it is important to plan projects carefully.
B people do not like answering questions.
C colleagues do not always agree.
Listening
39
```

[Original question page](assets/e46dbbe0259e3b57a81ed833f57a647b98f7f0d6ac53ff38ef320c561f8fc246.jpg)

<!-- Source: /api/assets/8b7c901e0afec3c0ea862941a65f80653aed5bc4ea09d7124f8014c0460cdaa6.jpg; PDF page 39; full -->

```text
Test2
Questions 37–40
Which statement applies to each of the following people who were interviewed by Shona?
Choose FOUR answers from the box and write the correct letter, A-F, next to questions
37-40.
A gave false data
B decided to stop participating
C refused to tell Shona about their job
D kept changing their mind about participating
E became very angry with Shona
F was worried about confidentiality
People interviewed by Shona
37 a person interviewed in the street
38 an undergraduate at the university
39 a colleague in her department
40 a tutor in a foreign university
40
```

[Original question page](assets/8b7c901e0afec3c0ea862941a65f80653aed5bc4ea09d7124f8014c0460cdaa6.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/dc913ceea5ffc1eacae29de1702e06e617a459a7237db01008276380db3243a7.jpg; PDF page 40; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Sheet glass manufacture:
the float process
Glass, which has been made since the time of the Mesopotamians and Egyptians, is little more
than a mixture of sand, soda ash and lime. When heated to about 1500 degrees Celsius (°C)
this becomes a molten mass that hardens when slowly cooled. The first successful method
for making clear, flat glass involved spinning. This method was very effective as the glass
had not touched any surfaces between being soft and becoming hard, so it stayed perfectly
unblemished, with a 'fire finish'. However, the process took a long time and was labour
intensive.
Nevertheless, demand for flat glass was very high and glassmakers across the world were
looking for a method of making it continuously. The first continuous ribbon process involved
squeezing molten glass through two hot rollers, similar to an old mangle. This allowed glass of
virtually any thickness to be made non-stop, but the rollers would leave both sides of the glass
marked, and these would then need to be ground and polished. This part of the process rubbed
away around 20 per cent of the glass, and the machines were very expensive.
The float process for making flat glass was invented by Alistair Pilkington. This process
allows the manufacture of clear, tinted and coated glass for buildings, and clear and tinted
glass for vehicles. Pilkington had been experimenting with improving the melting process,
and in 1952 he had the idea of using a bed of molten metal to form the flat glass, eliminating
altogether the need for rollers within the float bath. The metal had to melt at a temperature
less than the hardening point of glass (about 600°C), but could not boil at a temperature
below the temperature of the molten glass (about 1500°C). The best metal for the job was
tin.
The rest of the concept relied on gravity, which guaranteed that the surface of the molten
metal was perfectly flat and horizontal. Consequently, when pouring molten glass onto the
molten tin, the underside of the glass would also be perfectly flat. If the glass were kept hot
enough, it would flow over the molten tin until the top surface was also flat, horizontal and
perfectly parallel to the bottom surface. Once the glass cooled to 604°C or less it was too
hard to mark and could be transported out of the cooling zone by rollers. The glass settled to
a thickness of six millimetres because of surface tension interactions between the glass and
the tin. By fortunate coincidence, 60 per cent of the flat glass market at that time was for six­
millimetre glass.
41
```

[Original question page](assets/dc913ceea5ffc1eacae29de1702e06e617a459a7237db01008276380db3243a7.jpg)

<!-- Source: /api/assets/78ec7de232b9867a828390e6ff81edba6f6c7cc44271a2d8ab35a636a303fa6b.jpg; PDF page 41; full -->

```text
Test2
Pilkington built a pilot plant in 1953 and by 1955 he had convinced his company to build a
full-scale plant. However, it took 14 months of non-stop production, costing the company
£100,000 a month, before the plant produced any usable glass. Furthermore, once they
succeeded in making marketable flat glass, the machine was turned off for a service to prepare
it for years of continuous production. When it started up again it took another four months to
get the process right again. They finally succeeded in 1959 and there are now float plants all
over the world, with each able to produce around 1000 tons of glass every day, non-stop for
around 15 years.
Float plants today make glass of near optical quality. Several processes - melting, refining,
homogenising - take place simultaneously in the 2000 tonnes of molten glass in the furnace.
They occur in separate zones in a complex glass flow driven by high temperatures. It adds up
to a continuous melting process, lasting as long as 50 hours, that delivers glass smoothly and
continuously to the float bath, and from there to a coating zone and finally a heat treatment
zone, where stresses formed during cooling are relieved.
The principle of float glass is unchanged since the 1950s. However, the product has changed
dramatically, from a single thickness of 6.8 mm to a range from sub-millimetre to 25 mm,
from a ribbon frequently marred by inclusions and bubbles to almost optical perfection. To
ensure the highest quality, inspection takes place at every stage. Occasionally, a bubble is not
removed during refining, a sand grain refuses to melt, a tremor in the tin puts ripples into
the glass ribbon. Automated on-line inspection does two things. Firstly, it reveals process
faults upstream that can be corrected. Inspection technology allows more than 100 million
measurements a second to be made across the ribbon, locating flaws the unaided eye would be
unable to see. Secondly, it enables computers downstream to steer cutters around flaws.
Float glass is sold by the square metre, and at the final stage computers translate customer
requirements into patterns of cuts designed to minimise waste.
42
```

[Original question page](assets/78ec7de232b9867a828390e6ff81edba6f6c7cc44271a2d8ab35a636a303fa6b.jpg)

<!-- Source: /api/assets/b898e22415c45e5eb0b3586a366f38cf6425b6c67bf3c39a02136a72f1df88d4.jpg; PDF page 42; full -->

```text
Questions 1–8
Complete the table and diagram below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 1–8 on your answer sheet.
Early methods of producing flat glass
| Method | Advantages | Disadvantages |
| --- | --- | --- |
| (1) __________ | Glass remained (2) __________ | Slow; (3) __________ |
| Ribbon | Could produce glass sheets of varying (4) __________; Non-stop process | Glass was (5) __________; 20% of glass rubbed away; Machines were expensive |
Pilkington’s float process
[Original cross-section diagram retained. Flow left to right: inlet into melting zone, followed by cooling zone. Label (6) __________ points to upper flowing layer in melting zone; (7) __________ points to lower shaded layer; (8) __________ has two arrows to the upper and lower circular objects at the outlet after the cooling zone. No answers supplied.]
```

[Original question page](assets/b898e22415c45e5eb0b3586a366f38cf6425b6c67bf3c39a02136a72f1df88d4.jpg)

![Original figure](assets/b898e22415c45e5eb0b3586a366f38cf6425b6c67bf3c39a02136a72f1df88d4.jpg)

<!-- Source: /api/assets/6495e6de480aa10aeb639df396029c3aa9220893523857e65aaf2c2ff976f7fd.jpg; PDF page 43; full -->

```text
Test2
Questions 9-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 9-13 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
9 The metal used in the float process had to have specific properties.
10 Pilkington invested some of his own money in his float plant.
11 Pilkington's first full-scale plant was an instant commercial success.
12 The process invented by Pilkington has now been improved.
13 Computers are better than humans at detecting faults in glass.
44
```

[Original question page](assets/6495e6de480aa10aeb639df396029c3aa9220893523857e65aaf2c2ff976f7fd.jpg)

<!-- Source: /api/assets/4893594014b10ae0c3874c88c496216402a973dbe8490d759306a0aac131ca50.jpg; PDF page 44; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 on the following pages.
Questions 14-17
Reading Passage 2 has six paragraphs, A-F.
Choose the correct heading for paragraphs B and D-F from the list of headings below.
Write the correct number, i-ix, in boxes 14-17 on your answer sheet.
List of Headings
i Predicting climatic changes
ii The relevance of the Little Ice Age today
iii How cities contribute to climate change
iv Human impact on the climate
v How past climatic conditions can be determined
vi A growing need for weather records
vii A study covering a thousand years
viii People have always responded to climate change
ix Enough food at last
Example Answer
Paragraph A viii
14 Paragraph B
Example Answer
Paragraph C v
15 Paragraph D
16 Paragraph E
17 Paragraph F
45
```

[Original question page](assets/4893594014b10ae0c3874c88c496216402a973dbe8490d759306a0aac131ca50.jpg)

<!-- Source: /api/assets/956fdf68d9d6090c08ebd097a3c7c81bc60c65519e6170a29ac6560d9e375464.jpg; PDF page 45; full -->

```text
Test2
THE LITTLE ICE AGE
A This book will provide a detailed examination of the Little Ice Age and other climatic
shifts, but, before I embark on that, let me provide a historical context. We tend to
think of climate as opposed to weather - as something unchanging, yet humanity
has been at the mercy of climate change for its entire existence, with at least eight
glacial episodes in the past 730,000 years. Our ancestors adapted to the universal
but irregular global warming since the end of the last great Ice Age, around 10,000
years ago, with dazzling opportunism. They developed strategies for surviving
harsh drought cycles, decades of heavy rainfall or unaccustomed cold; adopted
agriculture and stock-raising, which revolutionised human life; and founded the
world's first pre-industrial civilisations in Egypt, Mesopotamia and the Americas.
But the price of sudden climate change, in famine, disease and suffering, was often
high.
B The Little Ice Age lasted from roughly 1300 until the middle of the nineteenth
century. Only two centuries ago, Europe experienced a cycle of bitterly cold
winters; mountain glaciers in the Swiss Alps were the lowest in recorded memory,
and pack ice surrounded Iceland for much of the year. The climatic events of the
Little Ice Age did more than help shape the modern world. They are the deeply
important context for the current unprecedented global warming. The Little Ice Age
was far from a deep freeze, however; rather an irregular seesaw of rapid climatic
shifts, few lasting more than a quarter-century, driven by complex and still little
understood interactions between the atmosphere and the ocean. The seesaw
brought cycles of intensely cold winters and easterly winds, then switched abruptly
to years of heavy spring and early summer rains, mild winters, and frequent Atlantic
storms, or to periods of droughts, light northeasterly winds, and summer heat
waves.
C Reconstructing the climate changes of the past is extremely difficult, because
systematic weather observations began only a few centuries ago, in Europe and
North America. Records from India and tropical Africa are even more recent.
For the time before records began, we have only 'proxy records' reconstructed
largely from tree rings and ice cores, supplemented by a few incomplete written
accounts. We now have hundreds of tree-ring records from throughout the
northern hemisphere, and many from south of the equator, too, amplified with a
growing body of temperature data from ice cores drilled in Antarctica, Greenland,
the Peruvian Andes, and other locations. We are close to a knowledge of annual
summer and winter temperature variations over much of the northern hemisphere
going back 600 years.
```

[Original question page](assets/956fdf68d9d6090c08ebd097a3c7c81bc60c65519e6170a29ac6560d9e375464.jpg)

<!-- Source: /api/assets/ec7c957e3fb135c9b74ac3866b9470642d8ac961d53f5b36feb2b375df63a77e.jpg; PDF page 46; full -->

```text
Reading
D This book is a narrative history of climatic shifts during the past ten centuries, and
some of the ways in which people in Europe adapted to them. Part One describes
the Medieval Warm Period, roughly 900 to 1200. During these three centuries,
Norse voyagers from Northern Europe explored northern seas, settled Greenland,
and visited North America. It was not a time of uniform warmth, for then, as always
since the Great Ice Age, there were constant shifts in rainfall and temperature.
Mean European temperatures were about the same as today, perhaps slightly
cooler.
E It is known that the Little Ice Age cooling began in Greenland and the Arctic in
about 1200. As the Arctic ice pack spread southward, Norse voyages to the west
were rerouted into the open Atlantic, then ended altogether. Storminess increased
in the North Atlantic and North Sea. Colder, much wetter weather descended on
Europe between 1315 and 1319, when thousands perished in a continent-wide
famine. By 1400, the weather had become decidedly more unpredictable and
stormier, with sudden shifts and lower temperatures that culminated in the cold
decades of the late sixteenth century. Fish were a vital commodity in growing
towns and cities, where food supplies were a constant concern. Dried cod and
herring were already the staples of the European fish trade, but changes in water
temperatures forced fishing fleets to work further offshore. The Basques, Dutch,
and English developed the first offshore fishing boats adapted to a colder and
stormier Atlantic. A gradual agricultural revolution in northern Europe stemmed
from concerns over food supplies at a time of rising populations. The revolution
involved intensive commercial farming and the growing of animal fodder on land
not previously used for crops. The increased productivity from farmland made
some countries self-sufficient in grain and livestock and offered effective protection
against famine.
F Global temperatures began to rise slowly after 1850, with the beginning of the
Modern Warm Period. There was a vast migration from Europe by land-hungry
farmers and others, to which the famine caused by the Irish potato blight
contributed, to North America, Australia, New Zealand, and southern Africa.
Millions of hectares of forest and woodland fell before the newcomers' axes
between 1850 and 1890, as intensive European farming methods expanded
across the world. The unprecedented land clearance released vast quantities of
carbon dioxide into the atmosphere, triggering for the first time humanly caused
global warming. Temperatures climbed more rapidly in the twentieth century as
the use of fossil fuels proliferated and greenhouse gas levels continued to soar.
The rise has been even steeper since the early 1980s. The Little Ice Age has given
way to a new climatic regime, marked by prolonged and steady warming. At the
same time, extreme weather events like Category 5 hurricanes are becoming more
frequent.
47
```

[Original question page](assets/ec7c957e3fb135c9b74ac3866b9470642d8ac961d53f5b36feb2b375df63a77e.jpg)

<!-- Source: /api/assets/b2d462bcf46ac6630baee4a4d3f5f239fcb978656723c7c305975620e8c0439f.jpg; PDF page 47; full -->

```text
Test2
Questions 18-22
Complete the summary using the list of words, A-I, below.
Write the correct letter, A-I, in boxes 18-22 on your answer sheet.
Weather during the Little Ice Age
Documentation of past weather conditions is limited: our main sources of knowledge
of conditions in the distant past are 18 ....................... and 19 ........................ We
can deduce that the Little Ice Age was a time of 20 ....................... , rather than of
consistent freezing. Within it there were some periods of very cold winters, others of
21 ....................... and heavy rain, and yet others that saw 22 ....................... with no
rain at all.
A climatic shifts B ice cores C tree rings
D glaciers E interactions F weather observations
G heat waves H storms I written accounts
Questions 23-26
Classify the following events as occurring during the
A Medieval Warm Period
B Little Ice Age
C Modern Warm Period
Write the correct letter, A, B or C, in boxes 23-26 on your answer sheet.
23 Many Europeans started farming abroad.
24 The cutting down of trees began to affect the climate.
25 Europeans discovered other lands.
26 Changes took place in fishing patterns.
48
```

[Original question page](assets/b2d462bcf46ac6630baee4a4d3f5f239fcb978656723c7c305975620e8c0439f.jpg)

<!-- Source: /api/assets/e624aad3ce0661ddad77887edf9df62cf86381c137e8163a71b6fd833321fcdf.jpg; PDF page 48; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 on the following pages.
Questions 27-32
Reading Passage 3 has six paragraphs, A-F.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i-viii, in boxes 27-32 on your answer sheet.
27 Paragraph A
28 Paragraph B
29 Paragraph C
30 Paragraph D
31 Paragraph E
32 Paragraph F
List of Headings
i The difficulties of talking about smells
ii The role of smell in personal relationships
iii Future studies into smell
iv The relationship between the brain and the
nose
v The interpretation of smells as a factor in
defining groups
vi Why our sense of smell is not appreciated
vii Smell is our superior sense
viii The relationship between smell and feelings
49
```

[Original question page](assets/e624aad3ce0661ddad77887edf9df62cf86381c137e8163a71b6fd833321fcdf.jpg)

<!-- Source: /api/assets/0f66255c436fe844d3abd48a19c0a374c34ce47d94834b41b349b9939199fcb3.jpg; PDF page 49; full -->

```text
Test2
The meaning and power of smell
The sense of smell, or olfaction, is powerful. Odours affect us on a physical,
psychological and social level. For the most part, however, we breathe in the aromas
which surround us without being consciously aware of their importance to us. It is
only when the faculty of smell is impaired for some reason that we begin to realise the
essential role the sense of smell plays in our sense of well-being
A A survey conducted by Anthony Synnott at Montreal's Concordia University asked
participants to comment on how important smell was to them in their lives. It
became apparent that smell can evoke strong emotional responses. A scent
associated with a good experience can bring a rush of joy, while a foul odour or one
associated with a bad memory may make us grimace with disgust. Respondents
to the survey noted that many of their olfactory likes and dislikes were based on
emotional associations. Such associations can be powerful enough so that odours
that we would generally label unpleasant become agreeable, and those that we
would generally consider fragrant become disagreeable for particular individuals.
The perception of smell, therefore, consists not only of the sensation of the odours
themselves, but of the experiences and emotions associated with them.
B Odours are also essential cues in social bonding. One respondent to the survey
believed that there is no true emotional bonding without touching and smelling a
loved one. In fact, infants recognise the odours of their mothers soon after birth
and adults can often identify their children or spouses by scent. In one well-known
test, women and men were able to distinguish by smell alone clothing worn by their
marriage partners from similar clothing worn by other people. Most of the subjects
would probably never have given much thought to odour as a cue for identifying
family members before being involved in the test, but as the experiment revealed,
even when not consciously considered, smells register.
C In spite of its importance to our emotional and sensory lives, smell is probably
the most undervalued sense in many cultures. The reason often given for the low
regard in which smell is held is that, in comparison with its importance among
animals, the human sense of smell is feeble and undeveloped. While it is true that
the olfactory powers of humans are nothing like as fine as those possessed by
certain animals, they are still remarkably acute. Our noses are able to recognise
thousands of smells, and to perceive odours which are present only in extremely
small quantities.
D Smell, however, is a highly elusive phenomenon. Odours, unlike colours, for
instance, cannot be named in many languages because the specific vocabulary
simply doesn't exist. 'It smells like ... ,' we have to say when describing an odour,
struggling to express our olfactory experience. Nor can odours be recorded:
there is no effective way to either capture or store them over time. In the realm
of olfaction, we must make do with descriptions and recollections. This has
implications for olfactory research.
```

[Original question page](assets/0f66255c436fe844d3abd48a19c0a374c34ce47d94834b41b349b9939199fcb3.jpg)

<!-- Source: /api/assets/b1923a61816dc460fb4fb3889267a64fa3019624a0c7f490ff32507072826a88.jpg; PDF page 50; full -->

```text
Reading
E Most of the research on smell undertaken to date has been of a physical scientific
nature. Significant advances have been made in the understanding of the biological
and chemical nature of olfaction, but many fundamental questions have yet to be
answered. Researchers have still to decide whether smell is one sense or two - one
responding to odours proper and the other registering odourless chemicals in the
air. Other unanswered questions are whether the nose is the only part of the body
affected by odours, and how smells can be measured objectively given the non­
physical components. Questions like these mean that interest in the psychology of
smell is inevitably set to play an increasingly important role for researchers.
F However, smell is not simply a biological and psychological phenomenon. Smell
is cultural, hence it is a social and historical phenomenon. Odours are invested
with cultural values: smells that are considered to be offensive in some cultures
may be perfectly acceptable in others. Therefore, our sense of smell is a means
of, and model for, interacting with the world. Different smells can provide us with
intimate and emotionally charged experiences and the value that we attach to these
experiences is interiorised by the members of society in a deeply personal way.
Importantly, our commonly held feelings about smells can help distinguish us from
other cultures. The study of the cultural history of smell is, therefore, in a very real
sense, an investigation into the essence of human culture.
Questions 33-36
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 33-36 on your answer sheet.
33 According to the introduction, we become aware of the importance of smell when
A we discover a new smell.
B we experience a powerful smell.
C our ability to smell is damaged.
D we are surrounded by odours.
34 The experiment described in paragraph B
A shows how we make use of smell without realising it.
B demonstrates that family members have a similar smell.
C proves that a sense of smell is learnt.
D compares the sense of smell in males and females.
51
```

[Original question page](assets/b1923a61816dc460fb4fb3889267a64fa3019624a0c7f490ff32507072826a88.jpg)

<!-- Source: /api/assets/bcaa68217110f9c6e87c8eee5f08d485af93b8c08d93899bdd1c535e69832c5d.jpg; PDF page 51; full -->

```text
Test2
35 What is the writer doing in paragraph C?
A supporting other research
B making a proposal
C rejecting a common belief
D describing limitations
36 What does the writer suggest about the study of smell in the atmosphere in
paragraph E?
A The measurement of smell is becoming more accurate.
B Researchers believe smell is a purely physical reaction.
C Most smells are inoffensive.
D Smell is yet to be defined.
Questions 37-40
Complete the sentences below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 37-40 on your answer sheet.
37 Tests have shown that odours can help people recognise the ...................... ..
belonging to their husbands and wives.
38 Certain linguistic groups may have difficulty describing smell because they lack the
appropriate ........................ .
39 The sense of smell may involve response to ........................ which do not smell, in
addition to obvious odours.
40 Odours regarded as unpleasant in certain .................... · .... are not regarded as
unpleasant in others.
52
```

[Original question page](assets/bcaa68217110f9c6e87c8eee5f08d485af93b8c08d93899bdd1c535e69832c5d.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/32df726d96ca3e53910e80cfb670383693d1b66c6a2eabee76e82e1390dd229d.jpg; PDF page 52; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The three pie charts below show the changes in annual spending by a particular UK school in 1981, 1991 and 2001.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/32df726d96ca3e53910e80cfb670383693d1b66c6a2eabee76e82e1390dd229d.jpg)

![Original figure](assets/32df726d96ca3e53910e80cfb670383693d1b66c6a2eabee76e82e1390dd229d.jpg)

### Task 2

<!-- Source: /api/assets/f9db8ffba795190c732545e481ff67274e3dc1ebed494fb38da42bd4ad3a58c5.jpg; PDF page 53; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Nowadays the way many people interact with each other has changed because of technology.

In what ways has technology affected the types of relationships people make?

Has this become a positive or negative development?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/f9db8ffba795190c732545e481ff67274e3dc1ebed494fb38da42bd4ad3a58c5.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/4fd174a85c17d033db11be7201cbaa15fc67a6328e8c55e51ec3910c6c393dce.jpg; PDF page 54; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Newspapers and Magazines
• Which magazines and newspapers do you read? [Why?]
• What kinds of article are you most interested in? [Why?]
• Have you ever read a newspaper or magazine in a foreign language? [When/Why?]
• Do you think reading a newspaper or magazine in a foreign language is a good way to
learn the language? [Why/Why not?]
PART 2
Describe a restaurant that you enjoyed going to.
You should say:
where the restaurant was
why you chose this restaurant
what type of food you ate in this restaurant and
explain why you enjoyed eating in this restaurant.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to
say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Restaurants
Example questions:
Why do you think people go to restaurants when they want to celebrate something?
Which are more popular in your country: fast food restaurants or traditional restaurants?
Why do you think that is?
Some people say that food in an expensive restaurant is always better than food in a
cheap restaurant - would you agree?
Producing food
Example questions:
Do you think there will be a greater choice of food available in shops in the future, or will
there be less choice?
What effects has modern technology had on the way food is produced?
How important is it for a country to be able to grow all the food it needs, without
importing any from other countries?
55
```

[Original question page](assets/4fd174a85c17d033db11be7201cbaa15fc67a6328e8c55e51ec3910c6c393dce.jpg)

### Part 2

<!-- Source: /api/assets/4fd174a85c17d033db11be7201cbaa15fc67a6328e8c55e51ec3910c6c393dce.jpg; PDF page 54; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Newspapers and Magazines
• Which magazines and newspapers do you read? [Why?]
• What kinds of article are you most interested in? [Why?]
• Have you ever read a newspaper or magazine in a foreign language? [When/Why?]
• Do you think reading a newspaper or magazine in a foreign language is a good way to
learn the language? [Why/Why not?]
PART 2
Describe a restaurant that you enjoyed going to.
You should say:
where the restaurant was
why you chose this restaurant
what type of food you ate in this restaurant and
explain why you enjoyed eating in this restaurant.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to
say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Restaurants
Example questions:
Why do you think people go to restaurants when they want to celebrate something?
Which are more popular in your country: fast food restaurants or traditional restaurants?
Why do you think that is?
Some people say that food in an expensive restaurant is always better than food in a
cheap restaurant - would you agree?
Producing food
Example questions:
Do you think there will be a greater choice of food available in shops in the future, or will
there be less choice?
What effects has modern technology had on the way food is produced?
How important is it for a country to be able to grow all the food it needs, without
importing any from other countries?
55
```

[Original question page](assets/4fd174a85c17d033db11be7201cbaa15fc67a6328e8c55e51ec3910c6c393dce.jpg)

### Part 3

<!-- Source: /api/assets/4fd174a85c17d033db11be7201cbaa15fc67a6328e8c55e51ec3910c6c393dce.jpg; PDF page 54; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Newspapers and Magazines
• Which magazines and newspapers do you read? [Why?]
• What kinds of article are you most interested in? [Why?]
• Have you ever read a newspaper or magazine in a foreign language? [When/Why?]
• Do you think reading a newspaper or magazine in a foreign language is a good way to
learn the language? [Why/Why not?]
PART 2
Describe a restaurant that you enjoyed going to.
You should say:
where the restaurant was
why you chose this restaurant
what type of food you ate in this restaurant and
explain why you enjoyed eating in this restaurant.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to
say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Restaurants
Example questions:
Why do you think people go to restaurants when they want to celebrate something?
Which are more popular in your country: fast food restaurants or traditional restaurants?
Why do you think that is?
Some people say that food in an expensive restaurant is always better than food in a
cheap restaurant - would you agree?
Producing food
Example questions:
Do you think there will be a greater choice of food available in shops in the future, or will
there be less choice?
What effects has modern technology had on the way food is produced?
How important is it for a country to be able to grow all the food it needs, without
importing any from other countries?
55
```

[Original question page](assets/4fd174a85c17d033db11be7201cbaa15fc67a6328e8c55e51ec3910c6c393dce.jpg)
