# 剑雅 17 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 122

TEST 3 LISTENING
1 family
2 fit
3 hotels
4 Carrowniskey
5 week
6 bay
7 September
8 19 / nineteen
9 30 / thirty
10 boots
11 B
12 E
13 C
14 C
15 A
16 E
17 D
18 G
19 F
20 C
21 B
22 A
23 A
24 B
25 C
26 A
27 D
28 B
29 F
30 H
31 mud
32 feathers
33 shape
34 moon
35 neck
36 evidence
37 destinations
38 oceans
39 recovery
40 atlas
11&12 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. family

2. fit

3. hotels

4. Carrowniskey

5. week

6. bay

7. September

8. 19 / nineteen

9. 30 / thirty

10. boots

### Part 2 · source page 122

TEST 3 LISTENING
1 family
2 fit
3 hotels
4 Carrowniskey
5 week
6 bay
7 September
8 19 / nineteen
9 30 / thirty
10 boots
11 B
12 E
13 C
14 C
15 A
16 E
17 D
18 G
19 F
20 C
21 B
22 A
23 A
24 B
25 C
26 A
27 D
28 B
29 F
30 H
31 mud
32 feathers
33 shape
34 moon
35 neck
36 evidence
37 destinations
38 oceans
39 recovery
40 atlas
11&12 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B / E

12. B / E

13. C

14. C

15. A

16. E

17. D

18. G

19. F

20. C

### Part 3 · source page 122

TEST 3 LISTENING
1 family
2 fit
3 hotels
4 Carrowniskey
5 week
6 bay
7 September
8 19 / nineteen
9 30 / thirty
10 boots
11 B
12 E
13 C
14 C
15 A
16 E
17 D
18 G
19 F
20 C
21 B
22 A
23 A
24 B
25 C
26 A
27 D
28 B
29 F
30 H
31 mud
32 feathers
33 shape
34 moon
35 neck
36 evidence
37 destinations
38 oceans
39 recovery
40 atlas
11&12 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. B

22. A

23. A

24. B

25. C

26. A

27. D

28. B

29. F

30. H

### Part 4 · source page 122

TEST 3 LISTENING
1 family
2 fit
3 hotels
4 Carrowniskey
5 week
6 bay
7 September
8 19 / nineteen
9 30 / thirty
10 boots
11 B
12 E
13 C
14 C
15 A
16 E
17 D
18 G
19 F
20 C
21 B
22 A
23 A
24 B
25 C
26 A
27 D
28 B
29 F
30 H
31 mud
32 feathers
33 shape
34 moon
35 neck
36 evidence
37 destinations
38 oceans
39 recovery
40 atlas
11&12 IN EITHER ORDER: B,E
If you score: 1–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. mud

32. feathers

33. shape

34. moon

35. neck

36. evidence

37. destinations

38. oceans

39. recovery

40. atlas

## A 类阅读

### Academic Reading · source page 123

TEST 3 READING
1 carnivorous
2 scent
3 pouch
4 fossil
5 habitat
6 TRUE
7 FALSE
8 NOT GIVEN
9 FALSE
10 NOT GIVEN
11 FALSE
12 TRUE
13 NOT GIVEN
14 F
15 G
16 A
17 H
18 B
19 E
20 C
21 B
22 C
23 solid
24 (Sumatran) orangutan / orang-utan
25 carbon stocks
26 biodiversity
27 D
28 B
29 C
30 D
31 C
32 NO
33 YES
34 NOT GIVEN
35 NO
36 H
37 D
38 I
39 B
40 F
21&22 IN EITHER ORDER: B,C
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. carnivorous

2. scent

3. pouch

4. fossil

5. habitat

6. TRUE

7. FALSE

8. NOT GIVEN

9. FALSE

10. NOT GIVEN

11. FALSE

12. TRUE

13. NOT GIVEN

14. F

15. G

16. A

17. H

18. B

19. E

20. C

21. B / C

22. B / C

23. solid

24. orangutan / Sumatran orangutan / orang-utan / Sumatran orang-utan

25. carbon stocks

26. biodiversity

27. D

28. B

29. C

30. D

31. C

32. NO

33. YES

34. NOT GIVEN

35. NO

36. H

37. D

38. I

39. B

40. F

## A 类写作

### Writing material: c17-t3-w-1

Percentage of weekly income,1968→2018; approximate unlabelled bars: food35→17%; housing10→19; fuel/power6→4; clothing/footwear10→5; household goods8→8; personal goods8→4; transport8→14; leisure9→22. Food largest1968; leisure largest2018,followed housing. Housing,transport,leisure shares rise; food,fuel,clothing,personal fall; household goods roughly unchanged. Different years may have different incomes, so shares alone do not establish absolute cash changes. Country unnamed; not daily or monthly spending.



### Writing material: c17-t3-w-2

Discuss obligation to work in country of training versus freedom to work abroad, with opinion. Training country need not be birthplace; do not impose that assumption.



## 口语
