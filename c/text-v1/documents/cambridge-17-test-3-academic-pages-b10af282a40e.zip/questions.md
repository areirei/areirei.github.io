# 剑雅 17 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/f062729b9b9b420385e243a963f2eee2baf8cae174077b5ec55d2c719abfedd5.jpg; PDF page 52; full -->

```text
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Advice on surfing holidays
Jack’s advice
• Recommends surfing for (1) __________ holidays in the summer
• Need to be quite (2) __________
Irish surfing locations
• County Clare
– Lahinch has some good quality (3) __________ and surf schools
– There are famous cliffs nearby
• County Mayo
– Good surf school at (4) __________ beach
– Surf camp lasts for one (5) __________
– Can also explore the local (6) __________ by kayak
Weather
• Best month to go: (7) __________
• Average temperature in summer: approx. (8) __________ degrees
Costs
• Equipment
– Wetsuit and surfboard: (9) __________ euros per day
– Also advisable to hire (10) __________ for warmth
```

[Original question page](assets/f062729b9b9b420385e243a963f2eee2baf8cae174077b5ec55d2c719abfedd5.jpg)

### Part 2

<!-- Source: /api/assets/0a7332469d4ceb68e2ddb6fa435d8a24f19e8f9b099768d0b941271a4d886744.jpg; PDF page 53; full -->

```text
Test 3
PART 2 Questions 11-20
Questions 11 and 12
Listening test audio
Choose TWO letters, A-E.
Which TWO facts are given about the school’s extended hours childcare service?
It started recently.
More children attend after school than before school.
An average of 50 children attend in the mornings.
Achild cannot attend both the before and after school sessions.
The maximum number of children who can attend is 70.
moogwp>
Questions 13-15
Choose the correct letter, A, B or C.
13 How much does childcare cost for a complete afternoon session per child?
A £3.50
B £5.70
C £7.20
14 What does the manager say about food?
A Children with allergies should bring their own food.
B_ Children may bring healthy snacks with them.
C_ Children are given a proper meal at 5 p.m.
15 What is different about arrangements in the school holidays?
A Children from other schools can attend.
B= Older children can attend.
C_ Agreater number of children can attend.
54
```

[Original question page](assets/0a7332469d4ceb68e2ddb6fa435d8a24f19e8f9b099768d0b941271a4d886744.jpg)

<!-- Source: /api/assets/ddb0efb9a47df4a7618c64971c2b251448a4bb581cea02d5f2fd25d28442b26c.jpg; PDF page 54; full -->

```text
Questions 16–20
What information is given about each of the following activities on offer?
Choose FIVE answers from the box and write the correct letter, A–G, next to Questions 16–20.
Information
A has limited availability
B is no longer available
C is for over 8s only
D requires help from parents
E involves an additional fee
F is a new activity
G was requested by children
Activities
16 Spanish __________
17 Music __________
18 Painting __________
19 Yoga __________
20 Cooking __________
```

[Original question page](assets/ddb0efb9a47df4a7618c64971c2b251448a4bb581cea02d5f2fd25d28442b26c.jpg)

### Part 3

<!-- Source: /api/assets/8824fe753790a86e904c78f3197f4d32c934bb5b7e692d5f43b90ca2f0bb4a64.jpg; PDF page 55; full -->

```text
Test 3
PART 3 Questions 21-30
Questions 21-24
Choose the correct letter, A, B or C.
21
22
23
24
56
Listening test audio
Holly’s Work Placement Tutorial
Holly has chosen the Orion Stadium placement because
A _ itinvolves children.
B _ itis outdoors.
C _ it sounds like fun.
Which aspect of safety does Dr Green emphasise most?
A _ ensuring children stay in the stadium
B_ checking the equipment children will use
C removing obstacles in changing rooms
What does Dr Green say about the spectators?
A They can be hard to manage.
B_ They make useful volunteers.
C_ They shouldn’t take photographs.
What has affected the schedule in the past?
A _ bad weather
Bs aninjury
C extra time
```

[Original question page](assets/8824fe753790a86e904c78f3197f4d32c934bb5b7e692d5f43b90ca2f0bb4a64.jpg)

<!-- Source: /api/assets/0b313cfc3584a1df42823f96e8f0e465bcb2dca7663e802d2dfd1c32b626be42.jpg; PDF page 56; full -->

```text
Questions 25–30
What do Holly and her tutor agree is an important aspect of each of the following events management skills?
Choose SIX answers from the box and write the correct letter, A–H, next to Questions 25–30.
Important aspects
A being flexible
B focusing on details
C having a smart appearance
D hiding your emotions
E relying on experts
F trusting your own views
G doing one thing at a time
H thinking of the future
Events management skills
25 Communication __________
26 Organisation __________
27 Time management __________
28 Creativity __________
29 Leadership __________
30 Networking __________
```

[Original question page](assets/0b313cfc3584a1df42823f96e8f0e465bcb2dca7663e802d2dfd1c32b626be42.jpg)

### Part 4

<!-- Source: /api/assets/cab1b2adb2c973d4bd2eed46b72ae2e526d3d06c0f65a3ff344b089cf2803567.jpg; PDF page 57; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Bird Migration Theory
Most birds are believed to migrate seasonally.
Hibernation theory
• It was believed that birds hibernated underwater or buried themselves in (31) __________.
• This theory was later disproved by experiments on caged birds.
Transmutation theory
• Aristotle believed birds changed from one species into another in summer and winter.
– In autumn he observed that redstarts experience the loss of (32) __________ and thought they then turned into robins.
– Aristotle’s assumptions were logical because the two species of birds had a similar (33) __________.
17th century
• Charles Morton popularised the idea that birds fly to the (34) __________ in winter.
Scientific developments
• In 1822, a stork was killed in Germany which had an African spear in its (35) __________.
– previously there had been no (36) __________ that storks migrate to Africa
• Little was known about the (37) __________ and journeys of migrating birds until the practice of ringing was established.
– It was thought large birds carried small birds on some journeys because they were considered incapable of travelling across huge (38) __________.
– Ringing depended on what is called the (39) ‘__________’ of dead birds.
• In 1931, the first (40) __________ to show the migration of European birds was printed.
```

[Original question page](assets/cab1b2adb2c973d4bd2eed46b72ae2e526d3d06c0f65a3ff344b089cf2803567.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/84558c93318017833396ea401b30e38b52041d2453d1383c321e5eb220ddcd0e.jpg; PDF page 58; full -->

```text
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The thylacine
The extinct thylacine, also known as the Tasmanian tiger, was a marsupial* that bore a superficial
resemblance to a dog. Its most distinguishing feature was the 13—19 dark brown stripes over its
back, beginning at the rear of the body and extending onto the tail. The thylacine’s average nose-
to-tail length for adult males was 162.6 cm, compared to 153.7 cm for females.
The thylacine appeared to occupy most types of terrain except dense rainforest, with open
eucalyptus forest thought to be its prime habitat. In terms of feeding, it was exclusively
carnivorous, and its stomach was muscular with an ability to distend so that it could eat large
amounts of food at one time, probably an adaptation to compensate for long periods when
hunting was unsuccessful and food scarce. The thylacine was not a fast runner and probably
caught its prey by exhausting it during a long pursuit. During long-distance chases, thylacines
were likely to have relied more on scent than any other sense. They emerged to hunt during the
evening, night and early morning and tended to retreat to the hills and forest for shelter during the
day. Despite the common name ‘tiger’, the thylacine had a shy, nervous temperament. Although
mainly nocturnal, it was sighted moving during the day and some individuals were even recorded
basking in the sun.
The thylacine had an extended breeding season from winter to spring, with indications that
some breeding took place throughout the year. The thylacine, like all marsupials, was tiny and
hairless when born. Newborns crawled into the pouch on the belly of their mother, and attached
themselves to one of the four teats, remaining there for up to three months. When old enough to
leave the pouch, the young stayed in a lair such as a deep rocky cave, well-hidden nest or hollow
log, whilst the mother hunted.
Approximately 4,000 years ago, the thylacine was widespread throughout New Guinea and most
of mainland Australia, as well as the island of Tasmania. The most recent, well-dated occurrence
of a thylacine on the mainland is a carbon-dated fossil from Murray Cave in Western Australia,
which is around 3,100 years old. Its extinction coincided closely with the arrival of wild dogs
called dingoes in Australia and a similar predator in New Guinea. Dingoes never reached
Tasmania, and most scientists see this as the main reason for the thylacine’s survival there.
*marsupial: a mammal, such as a kangaroo, whose young are born incompletely developed and are typically carried and suckled in a
pouch on the mother’s belly
59
```

[Original question page](assets/84558c93318017833396ea401b30e38b52041d2453d1383c321e5eb220ddcd0e.jpg)

<!-- Source: /api/assets/497fe6c34904a141f09282823b87d7aae0131bf0622c12ba10fe1dfbcb15104f.jpg; PDF page 59; full -->

```text
Test 3
The dramatic decline of the thylacine in Tasmania, which began in the 1830s and continued for
a century, is generally attributed to the relentless efforts of sheep farmers and bounty hunters**
with shotguns. While this determined campaign undoubtedly played a large part, it is likely that
various other factors also contributed to the decline and eventual extinction of the species. These
include competition with wild dogs introduced by European settlers, loss of habitat along with
the disappearance of prey species, and a distemper-like disease which may also have affected
the thylacine.
There was only one successful attempt to breed a thylacine in captivity, at Melbourne Zoo in
899. This was despite the large numbers that went through some zoos, particularly London Zoo
and Tasmania’s Hobart Zoo. The famous naturalist John Gould foresaw the thylacine’s demise
when he published his Mammals of Australia between 1848 and 1863, writing, ‘The numbers of
this singular animal will speedily diminish, extermination will have its full sway, and it will then,
ike the wolf of England and Scotland, be recorded as an animal of the past.’
However, there seems to have been little public pressure to preserve the thylacine, nor was much
concern expressed by scientists at the decline of this species in the decades that followed. A
notable exception was T.T. Flynn, Professor of Biology at the University of Tasmania. In 1914,
he was sufficiently concerned about the scarcity of the thylacine to suggest that some should be
captured and placed on a small island. But it was not until 1929, with the species on the very edge
of extinction, that Tasmania’s Animals and Birds Protection Board passed a motion protecting
thylacines only for the month of December, which was thought to be their prime breeding season.
The last known wild thylacine to be killed was shot by a farmer in the north-east of Tasmania
in 1930, leaving just captive specimens. Official protection of the species by the Tasmanian
government was introduced in July 1936, 59 days before the last known individual died in Hobart
Zoo on 7th September, 1936.
There have been numerous expeditions and searches for the thylacine over the years, none of
which has produced definitive evidence that thylacines still exist. The species was declared extinct
by the Tasmanian government in 1986.
** bounty hunters: people who are paid a reward for killing a wild animal
60
```

[Original question page](assets/497fe6c34904a141f09282823b87d7aae0131bf0622c12ba10fe1dfbcb15104f.jpg)

<!-- Source: /api/assets/a25ad6e09cf5b99b6133ed3c76b574c4bbc761e2e403b91cf3059cec7003d459.jpg; PDF page 60; full -->

```text
Questions 1–5
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–5 on your answer sheet.
The thylacine
Appearance and behaviour
• looked rather like a dog
• had a series of stripes along its body and tail
• ate an entirely (1) __________ diet
• probably depended mainly on (2) __________ when hunting
• young spent first months of life inside its mother’s (3) __________
Decline and extinction
• last evidence in mainland Australia is a 3,100-year-old (4) __________
• probably went extinct in mainland Australia due to competition from dingoes and humans
• reduction in (5) __________ and available sources of food were partly responsible for decline in Tasmania
```

[Original question page](assets/a25ad6e09cf5b99b6133ed3c76b574c4bbc761e2e403b91cf3059cec7003d459.jpg)

<!-- Source: /api/assets/bd6690fc1566c0b77695c08636f8c58baff15e5d9bcf6f4061ea3720ac9a7ff7.jpg; PDF page 61; full -->

```text
Test 3
Questions 6-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 6-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
Significant numbers of thylacines were killed by humans from the 1830s onwards.
Several thylacines were born in zoos during the late 1800s.
John Gould’s prediction about the thylacine surprised some biologists.
oon
In the early 1900s, many scientists became worried about the possible extinction of
the thylacine.
10 T.T. Flynn’s proposal to rehome captive thylacines on an island proved to be
impractical.
11 There were still reasonable numbers of thylacines in existence when a piece of
legislation protecting the species during their breeding season was passed.
12 From 1930 to 1936, the only known living thylacines were all in captivity.
13 Attempts to find living thylacines are now rarely made.
62 (0 p. 124
```

[Original question page](assets/bd6690fc1566c0b77695c08636f8c58baff15e5d9bcf6f4061ea3720ac9a7ff7.jpg)

<!-- Source: /api/assets/f8514ee4e254c78749b7775b77fa6d477b4c570e8451a20c61e23819fe678812.jpg; PDF page 62; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Palm oil
A Palm oil is an edible oil derived from the fruit of the African oil palm tree, and is currently
the most consumed vegetable oil in the world. It’s almost certainly in the soap we wash with
in the morning, the sandwich we have for lunch, and the biscuits we snack on during the
day. Why is palm oil so attractive for manufacturers? Primarily because its unique properties
— such as remaining solid at room temperature — make it an ideal ingredient for long-term
preservation, allowing many packaged foods on supermarket shelves to have ‘best before’
dates of months, even years, into the future.
B- Many farmers have seized the opportunity to maximise the planting of oil palm trees.
Between 1990 and 2012, the global land area devoted to growing oil palm trees grew from
6 to 17 million hectares, now accounting for around ten percent of total cropland in the
entire world. From a mere two million tonnes of palm oil being produced annually globally
50 years ago, there are now around 60 million tonnes produced every single year, a figure
looking likely to double or even triple by the middle of the century.
C However, there are multiple reasons why conservationists cite the rapid spread of oil palm
plantations as a major concern. There are countless news stories of deforestation, habitat
destruction and dwindling species populations, all as a direct result of land clearing to
establish oil palm tree monoculture on an industrial scale, particularly in Malaysia and
Indonesia. Endangered species — most famously the Sumatran orangutan, but also rhinos,
elephants, tigers, and numerous other fauna — have suffered from the unstoppable spread of
oil palm plantations.
D ‘Palm oil is surely one of the greatest threats to global biodiversity,’ declares Dr Farnon
Ellwood of the University of the West of England, Bristol. “Palm oil is replacing rainforest,
and rainforest is where all the species are. That’s a problem.’ This has led to some radical
questions among environmentalists, such as whether consumers should try to boycott palm
oil entirely.
Meanwhile Bhavani Shankar, Professor at London’s School of Oriental and African Studies,
argues, ‘It’s easy to say that palm oil is the enemy and we should be against it. It makes for
amore dramatic story, and it’s very intuitive. But given the complexity of the argument, I
think a much more nuanced story is closer to the truth.’
63
```

[Original question page](assets/f8514ee4e254c78749b7775b77fa6d477b4c570e8451a20c61e23819fe678812.jpg)

<!-- Source: /api/assets/30b48a90a7dd2ecfb44c33374b925f1b14de7d4500e1ffac99856d7c151f8996.jpg; PDF page 63; full -->

```text
Test 3
64
One response to the boycott movement has been the argument for the vital role palm
oil plays in lifting many millions of people in the developing world out of poverty. Is it
desirable to have palm oil boycotted, replaced, eliminated from the global supply chain,
given how many low-income people in developing countries depend on it for their
livelihoods? How best to strike a utilitarian balance between these competing factors has
become a serious bone of contention.
Even the deforestation argument isn’t as straightforward as it seems. Oil palm plantations
produce at least four and potentially up to ten times more oil per hectare than soybean,
rapeseed, sunflower or other competing oils. That immensely high yield — which is
predominantly what makes it so profitable — is potentially also an ecological benefit. If ten
times more palm oil can be produced from a patch of land than any competing oil, then ten
times more land would need to be cleared in order to produce the same volume of oil from
that competitor.
As for the question of carbon emissions, the issue really depends on what oil palm trees are
replacing. Crops vary in the degree to which they sequester carbon — in other words, the
amount of carbon they capture from the atmosphere and store within the plant. The more
carbon a plant sequesters, the more it reduces the effect of climate change. As Shankar
explains: ‘[Palm oil production] actually sequesters more carbon in some ways than other
alternatives. [...] Of course, if you’re cutting down virgin forest it’s terrible — that’s what’s
happening in Indonesia and Malaysia, it’s been allowed to get out of hand. But if it’s
replacing rice, for example, it might actually sequester more carbon.’
The industry is now regulated by a group called the Roundtable on Sustainable Palm Oil
(RSPO), consisting of palm growers, retailers, product manufacturers, and other interested
parties. Over the past decade or so, an agreement has gradually been reached regarding
standards that producers of palm oil have to meet in order for their product to be regarded
as officially ‘sustainable’. The RSPO insists upon no virgin forest clearing, transparency and
regular assessment of carbon stocks, among other criteria. Only once these requirements are
fully satisfied is the oil allowed to be sold as certified sustainable palm oil (CSPO). Recent
figures show that the RSPO now certifies around 12 million tonnes of palm oil annually,
equivalent to roughly 21 percent of the world’s total palm oil production.
There is even hope that oil palm plantations might not need to be such sterile monocultures,
or ‘green deserts’, as Ellwood describes them. New research at Ellwood’s lab hints at one
plant which might make all the difference. The bird’s nest fern (Asplenium nidus) grows on
trees in an epiphytic fashion (meaning it’s dependent on the tree only for support, not for
nutrients), and is native to many tropical regions, where as a keystone species it performs a
vital ecological role. Ellwood believes that reintroducing the bird’s nest fern into oil palm
plantations could potentially allow these areas to recover their biodiversity, providing a
home for all manner of species, from fungi and bacteria, to invertebrates such as insects,
amphibians, reptiles and even mammals.
```

[Original question page](assets/30b48a90a7dd2ecfb44c33374b925f1b14de7d4500e1ffac99856d7c151f8996.jpg)

<!-- Source: /api/assets/1038b7c4aa9e0eeaec356c805e47247a9c180367a0811b9e04325a97cff011f6.jpg; PDF page 64; full -->

```text
Reading
Questions 14-20
Reading Passage 2 has eight sections, A-H.
Which section contains the following information?
Write the correct letter, A-H, in boxes 14-20 on your answer sheet.
14
15
16
17
18
19
20
examples of a range of potential environmental advantages of oil palm tree
cultivation
description of an organisation which controls the environmental impact of palm oil
production
examples of the widespread global use of palm oil
reference to a particular species which could benefit the ecosystem of oil palm
plantations
figures illustrating the rapid expansion of the palm oil industry
an economic justification for not opposing the palm oil industry
examples of creatures badly affected by the establishment of oil palm plantations
Questions 21 and 22
Choose TWO letters, A-E.
Write the correct letters in boxes 21 and 22 on your answer sheet.
Which TWO statements are made about the Roundtable on Sustainable Palm
Oil (RSPO)?
A __ Its membership has grown steadily over the course of the last decade.
B__ It demands that certified producers be open and honest about their practices.
C It took several years to establish its set of criteria for sustainable palm oil
certification.
D Its regulations regarding sustainability are stricter than those governing other
industries.
E It was formed at the request of environmentalists concerned about the loss of
virgin forests.
65
```

[Original question page](assets/1038b7c4aa9e0eeaec356c805e47247a9c180367a0811b9e04325a97cff011f6.jpg)

<!-- Source: /api/assets/d16dc75f82fdb29295033d08a244f1a7e302b6793345bb69e7aef4e0f18600bb.jpg; PDF page 65; full -->

```text
Questions 23–26
Complete the sentences below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 23–26 on your answer sheet.
23 One advantage of palm oil for manufacturers is that it stays __________ even when not refrigerated.
24 The __________ is the best known of the animals suffering habitat loss as a result of the spread of oil palm plantations.
25 As one of their criteria for the certification of sustainable palm oil, the RSPO insists that growers check __________ on a routine basis.
26 Ellwood and his researchers are looking into whether the bird’s nest fern could restore __________ in areas where oil palm trees are grown.
```

[Original question page](assets/d16dc75f82fdb29295033d08a244f1a7e302b6793345bb69e7aef4e0f18600bb.jpg)

<!-- Source: /api/assets/531c19ce715c2361dc40e4d9e8f22fddaf3a1dfca9e2b94230e280cca87ea190.jpg; PDF page 66; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27—40, which are based on Reading
Passage 3 below.
Building the Skyline: The Birth and Growth of Manhattan’s
Skyscrapers
Katharine L. Shester reviews a book by Jason Barr about the development of
New York City
In Building the Skyline, Jason Barr takes the reader through a detailed history of New York
City. The book combines geology, history, economics, and a lot of data to explain why business
clusters developed where they did and how the early decisions of workers and firms shaped
the skyline we see today. Building the Skyline is organized into two distinct parts. The first is
primarily historical and addresses New York’s settlement and growth from 1609 to 1900; the
second deals primarily with the 20th century and is a compilation of chapters commenting
on different aspects of New York’s urban development. The tone and organization of the book
changes somewhat between the first and second parts, as the latter chapters incorporate aspects of
Barr’s related research papers.
Barr begins chapter one by taking the reader on a ‘helicopter time-machine’ ride — giving a
fascinating account of how the New York landscape in 1609 might have looked from the sky. He
then moves on to a subterranean walking tour of the city, indicating the location of rock and water
below the subsoil, before taking the reader back to the surface. His love of the city comes through
as he describes various fun facts about the location of the New York residence of early 19th-century
vice-president Aaron Burr as well as a number of legends about the city.
Chapters two and three take the reader up to the Civil War (1861-1865), with chapter two
focusing on the early development of land and the implementation of a grid system in 1811.
Chapter three focuses on land use before the Civil War. Both chapters are informative and well
researched and set the stage for the economic analysis that comes later in the book. I would
have liked Barr to expand upon his claim that existing tenements* prevented skyscrapers in
certain neighborhoods because ‘likely no skyscraper developer was interested in performing the
necessary “slum clearance”’. Later in the book, Barr makes the claim that the depth of bedrock**
was not a limiting factor for developers, as foundation costs were a small fraction of the cost of
development. At first glance, it is not obvious why slum clearance would be limiting, while more
expensive foundations would not.
*a tenement: a multi-occupancy building of any sort, but particularly a run-down apartment building or slum building
** bedrock: the solid, hard rock in the ground that lies under a loose layer of soil
67
```

[Original question page](assets/531c19ce715c2361dc40e4d9e8f22fddaf3a1dfca9e2b94230e280cca87ea190.jpg)

<!-- Source: /api/assets/754bdb95d458fe52a1a8dd6a868a2593e02b56d5520b1fe67f42a5d401cbb5ab.jpg; PDF page 67; full -->

```text
Test 3
Chapter four focuses on immigration and the location of neighborhoods and tenements in the
late 19th century. Barr identifies four primary immigrant enclaves and analyzes their locations
in terms of the amenities available in the area. Most of these enclaves were located on the least
valuable land, between the industries located on the waterfront and the wealthy neighborhoods
bordering Central Park.
Part two of the book begins with a discussion of the economics of skyscraper height. In chapter
five, Barr distinguishes between engineering height, economic height, and developer height —
where engineering height is the tallest building that can be safely made at a given time, economic
height is the height that is most efficient from society’s point of view, and developer height is the
actual height chosen by the developer, who is attempting to maximize return on investment.
Chapter five also has an interesting discussion of the technological advances that led to the
construction of skyscrapers. For example, the introduction of iron and steel skeletal frames made
thick, load-bearing walls unnecessary, expanding the usable square footage of buildings and
increasing the use of windows and availability of natural light. Chapter six then presents data on
building height throughout the 20th century and uses regression analysis to ‘predict’ building
construction. While less technical than the research paper on which the chapter is based, it is
probably more technical than would be preferred by a general audience.
Chapter seven tackles the ‘bedrock myth’, the assumption that the absence of bedrock close to the
surface between Downtown and Midtown New York is the reason for skyscrapers not being built
between the two urban centers. Rather, Barr argues that while deeper bedrock does increase foundation
costs, these costs were neither prohibitively high nor were they large compared to the overall cost
of building a skyscraper. What I enjoyed the most about this chapter was Barr’s discussion of how
foundations are actually built. He describes the use of caissons, which enable workers to dig down
for considerable distances, often below the water table, until they reach bedrock. Barr’s thorough
technological history discusses not only how caissons work, but also the dangers involved. While this
chapter references empirical research papers, it is a relatively easy read.
Chapters eight and nine focus on the birth of Midtown and the building boom of the 1920s.
Chapter eight contains lengthy discussions of urban economic theory that may serve as a
distraction to readers primarily interested in New York. However, they would be well-suited for
undergraduates learning about the economics of cities. In the next chapter, Barr considers two of
the primary explanations for the building boom of the 1920s — the first being exuberance, and
the second being financing. He uses data to assess the viability of these two explanations and
finds that supply and demand factors explain much of the development of the 1920s; though it
enabled the boom, cheap credit was not, he argues, the primary cause.
In the final chapter (chapter 10), Barr discusses another of his empirical papers that estimates
Manhattan land values from the mid-19th century to the present day. The data work that went into
these estimations is particularly impressive. Toward the end of the chapter, Barr assesses ‘whether
skyscrapers are a cause or an effect of high land values’. He finds that changes in land values
predict future building height, but the reverse is not true. The book ends with an epilogue, in
which Barr discusses the impact of climate change on the city and makes policy suggestions for
New York going forward.
68
```

[Original question page](assets/754bdb95d458fe52a1a8dd6a868a2593e02b56d5520b1fe67f42a5d401cbb5ab.jpg)

<!-- Source: /api/assets/a67e417b4889e4db11a29231fe8bee6949096450184138812db69712333e940b.jpg; PDF page 68; full -->

```text
Reading
Questions 27-31
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-31 on your answer sheet.
27
28
29
30
31
What point does Shester make about Barr’s book in the first paragraph?
A _Itgives a highly original explanation for urban development.
B_ Elements of Barr’s research papers are incorporated throughout the book.
C Other books that are available on the subject have taken a different approach.
D It covers a range of factors that affected the development of New York.
How does Shester respond to the information in the book about tenements?
A _ She describes the reasons for Barr’s interest.
B_ She indicates a potential problem with Barr’s analysis.
C She compares Barr’s conclusion with that of other writers.
D She provides details about the sources Barr used for his research.
What does Shester say about chapter six of the book?
A __Itcontains conflicting data.
B__ It focuses too much on possible trends.
C itis too specialised for most readers.
D It draws on research that is out of date.
What does Shester suggest about the chapters focusing on the 1920s building
boom?
A __ The information should have been organised differently.
B_ More facts are needed about the way construction was financed.
C_ The explanation that is given for the building boom is unlikely.
D Some parts will have limited appeal to certain people.
What impresses Shester the most about the chapter on land values?
A _ the broad time period that is covered
B the interesting questions that Barr asks
C the nature of the research into the topic
D the recommendations Barr makes for the future
69
```

[Original question page](assets/a67e417b4889e4db11a29231fe8bee6949096450184138812db69712333e940b.jpg)

<!-- Source: /api/assets/6e10331d23d0a43943b04201e7a0cda7cd65305193783969a2894ce3687cb509.jpg; PDF page 69; full -->

```text
Test 3
Questions 32-35
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 32-35 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
32 The description in the first chapter of how New York probably looked from the air in
the early 1600s lacks interest.
33 Chapters two and three prepare the reader well for material yet to come.
34 The biggest problem for many nineteenth-century New York immigrant
neighbourhoods was a lack of amenities.
35 In the nineteenth century, New York’s immigrant neighbourhoods tended to
concentrate around the harbour.
70
```

[Original question page](assets/6e10331d23d0a43943b04201e7a0cda7cd65305193783969a2894ce3687cb509.jpg)

<!-- Source: /api/assets/ad73e0bd91512e51f7cfd8c8881080c1083a4f6d2283e82d70bf169aa00ed6bb.jpg; PDF page 70; full -->

```text
Questions 36–40
Complete the summary using the list of phrases, A–J, below.
Write the correct letter, A–J, in boxes 36–40 on your answer sheet.
The bedrock myth
In chapter seven, Barr indicates how the lack of bedrock close to the surface does not explain why skyscrapers are absent from (36) __________. He points out that although the cost of foundations increases when bedrock is deep below the surface, this cannot be regarded as (37) __________, especially when compared to (38) __________.
A particularly enjoyable part of the chapter was Barr’s account of how foundations are built. He describes not only how (39) __________ are made possible by the use of caissons, but he also discusses their (40) __________. The chapter is well researched but relatively easy to understand.
A development plans
B deep excavations
C great distance
D excessive expense
E impossible tasks
F associated risks
G water level
H specific areas
I total expenditure
J construction guidelines
```

[Original question page](assets/ad73e0bd91512e51f7cfd8c8881080c1083a4f6d2283e82d70bf169aa00ed6bb.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/77254a458352453e90a682ad9fdc5081093d870789ddb4049ad3d50e1442291d.jpg; PDF page 71; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below gives information about how families in one country spent their weekly income in 1968 and in 2018.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/77254a458352453e90a682ad9fdc5081093d870789ddb4049ad3d50e1442291d.jpg)

![Original figure](assets/77254a458352453e90a682ad9fdc5081093d870789ddb4049ad3d50e1442291d.jpg)

### Task 2

<!-- Source: /api/assets/f12b41cdf4a791c6aeb1d937660ebff7fb7cbb38bcf7dce2d7a8caa316e8b54c.jpg; PDF page 72; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that professionals, such as doctors and engineers, should be required to work in the country where they did their training. Others believe they should be free to work in another country if they wish.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/f12b41cdf4a791c6aeb1d937660ebff7fb7cbb38bcf7dce2d7a8caa316e8b54c.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/ddb20d10c977faf96d4dedde0fb32babbefed3584fc960cf889ce126918d32e0.jpg; PDF page 73; full -->

```text
Test 3
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Drinks
What do you like to drink with your dinner? [Why?]
Do you drink a lot of water every day? [Why/Why not?]
Do you prefer drinking tea or coffee? [Why?]
If people visit you in your home, what do you usually offer them to drink?
[Why/Why not?]
PART 2
Describe a monument (e.g., a statue or sculpture) that you like.
You should say:
what this monument is
where this monument is
what it looks like
and explain why you like this monument.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Public monuments
Example questions:
What kinds of monuments do tourists in your country enjoy visiting?
Why do you think there are often statues of famous people in public places?
Do you agree that old monuments and buildings should always be preserved?
Architecture
Example questions:
Why is architecture such a popular university subject?
In what ways has the design of homes changed in recent years?
To what extent does the design of buildings affect people’s moods?
74
```

[Original question page](assets/ddb20d10c977faf96d4dedde0fb32babbefed3584fc960cf889ce126918d32e0.jpg)

### Part 2

<!-- Source: /api/assets/ddb20d10c977faf96d4dedde0fb32babbefed3584fc960cf889ce126918d32e0.jpg; PDF page 73; full -->

```text
Test 3
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Drinks
What do you like to drink with your dinner? [Why?]
Do you drink a lot of water every day? [Why/Why not?]
Do you prefer drinking tea or coffee? [Why?]
If people visit you in your home, what do you usually offer them to drink?
[Why/Why not?]
PART 2
Describe a monument (e.g., a statue or sculpture) that you like.
You should say:
what this monument is
where this monument is
what it looks like
and explain why you like this monument.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Public monuments
Example questions:
What kinds of monuments do tourists in your country enjoy visiting?
Why do you think there are often statues of famous people in public places?
Do you agree that old monuments and buildings should always be preserved?
Architecture
Example questions:
Why is architecture such a popular university subject?
In what ways has the design of homes changed in recent years?
To what extent does the design of buildings affect people’s moods?
74
```

[Original question page](assets/ddb20d10c977faf96d4dedde0fb32babbefed3584fc960cf889ce126918d32e0.jpg)

### Part 3

<!-- Source: /api/assets/ddb20d10c977faf96d4dedde0fb32babbefed3584fc960cf889ce126918d32e0.jpg; PDF page 73; full -->

```text
Test 3
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Drinks
What do you like to drink with your dinner? [Why?]
Do you drink a lot of water every day? [Why/Why not?]
Do you prefer drinking tea or coffee? [Why?]
If people visit you in your home, what do you usually offer them to drink?
[Why/Why not?]
PART 2
Describe a monument (e.g., a statue or sculpture) that you like.
You should say:
what this monument is
where this monument is
what it looks like
and explain why you like this monument.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Public monuments
Example questions:
What kinds of monuments do tourists in your country enjoy visiting?
Why do you think there are often statues of famous people in public places?
Do you agree that old monuments and buildings should always be preserved?
Architecture
Example questions:
Why is architecture such a popular university subject?
In what ways has the design of homes changed in recent years?
To what extent does the design of buildings affect people’s moods?
74
```

[Original question page](assets/ddb20d10c977faf96d4dedde0fb32babbefed3584fc960cf889ce126918d32e0.jpg)
