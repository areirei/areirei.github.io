# 剑雅 4 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/364e383476d0ef0db646d9d0535a944acf3f3e1d81246f93a9bbb88640048998.jpg; PDF page 11; full -->

```text
LISTENING SECTION1 Questions1–10
Questions1–4: Complete the notes below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
NOTES ON SOCIAL PROGRAMME
Example: Number of trips per month—5
Visit places which have: historical interest; good (1) __________; (2) __________.
Cost: between £5.00 and £15.00 per person.
Note: special trips organised for groups of (3) __________ people.
Time: departure—8.30a.m.; return—6.00p.m.
To reserve a seat: sign name on the (4) __________ 3days in advance.
```

[Original question page](assets/364e383476d0ef0db646d9d0535a944acf3f3e1d81246f93a9bbb88640048998.jpg)

<!-- Source: /api/assets/d8adcefbb84c5a031530220c520eefd3f07ab5c5f9b6836a5c623a9bd6b57e83.jpg; PDF page 12; full -->

```text
Questions5–10
Complete the table below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
WEEKEND TRIPS
Place | Date | Number of seats | Optional extra
St Ives | (5) __________ |16|Hepworth Museum
London |16th February|45|(6) __________
(7) __________ |3rd March|18|S.S. Great Britain
Salisbury |18th March|50|Stonehenge
Bath |23rd March|16|(8) __________
For further information: Read the (9) __________ or see Social Assistant: Jane (10) __________.
```

[Original question page](assets/d8adcefbb84c5a031530220c520eefd3f07ab5c5f9b6836a5c623a9bd6b57e83.jpg)

### Part 2

<!-- Source: /api/assets/d428278396c09df8940e56d9c360fc938562103dbe2eb149b45cd2cb428883ae.jpg; PDF page 13; full -->

```text
SECTION 2 Questions 11-20 
Questions 11-13 
Complete the sentences below. 
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer. 
RIVERSIDE INDUSTRIAL VILLAGE 
11 Riverside Village was a good place to start an industry because it had water, raw 
materials and fuels such as ........................ and ... .. .... ............... . 
12 The metal industry was established at Riverside Village by .................. ...... who lived 
in the area. 
13 There were over .... .................... water-powered mills in the area in the eighteenth 
century. 
12
```

[Original question page](assets/d428278396c09df8940e56d9c360fc938562103dbe2eb149b45cd2cb428883ae.jpg)

<!-- Source: /api/assets/9a7fbc292ec66fb32dbb3327745d4128c3139dbf35b9651142656e55c3678dce.jpg; PDF page 14; full -->

```text
Questions14–20
Label the plan below. Write NO MORE THAN TWO WORDS for each answer.
Use the original site plan: (14) __________ Road runs along the bottom; entrance points into the car park.
Beside the entrance: The (16) __________ to the left; The (15) __________ to the right; Toilets farther right.
Left of the yard, beside the river: The (20) __________ for the workers; The (19) __________ farther up; then The Grinding Shop.
Top: The Engine Room, then The (17) __________ to its right.
Right of the yard: The (18) __________ above The Stables and The Works Office.
```

[Original question page](assets/9a7fbc292ec66fb32dbb3327745d4128c3139dbf35b9651142656e55c3678dce.jpg)

![Original figure](assets/9a7fbc292ec66fb32dbb3327745d4128c3139dbf35b9651142656e55c3678dce.jpg)

### Part 3

<!-- Source: /api/assets/b6df3173c0ed964cb936f3c0c827a9a7d112b327178a1c2dd5d7a6e6b92c5906.jpg; PDF page 15; full -->

```text
SECTION3 Questions21–30
Questions21 and22: Choose the correct letter,A,B or C.
Example: Melanie could not borrow any books from the library because
A the librarian was out.
B she didn’t have time to look.
C the books had already been borrowed. [Example answer C]
21 Melanie says she has not started the assignment because
A she was doing work for another course.
B it was a really big assignment.
C she hasn’t spent time in the library.
22 The lecturer says that reasonable excuses for extensions are
A planning problems.
B problems with assignment deadlines.
C personal illness or accident.
```

[Original question page](assets/b6df3173c0ed964cb936f3c0c827a9a7d112b327178a1c2dd5d7a6e6b92c5906.jpg)

<!-- Source: /api/assets/7f76ddd8ef7fb2c62845aa43c8afa944fa946effbe0bd9b6307ac8d2e8b714e2.jpg; PDF page 16; full -->

```text
Questions23–27
What recommendations does Dr Johnson make about the journal articles?
Choose your answers from the box and write the letters A–G next to questions23–27.
A must read
B useful
C limited value
D read first section
E read research methods
F read conclusion
G don’t read
Example: Anderson and Hawker—A
Jackson:(23) __________
Roberts:(24) __________
Morris:(25) __________
Cooper:(26) __________
Forster:(27) __________
```

[Original question page](assets/7f76ddd8ef7fb2c62845aa43c8afa944fa946effbe0bd9b6307ac8d2e8b714e2.jpg)

<!-- Source: /api/assets/8c8c9bb7c93091090d88dcf5f4a2fd3a6f10adc25c25b422dc48fb1b8753c073.jpg; PDF page 17; full -->

```text
Questions28–30
Label the chart below. Choose your answers from the box below and write the letters A–H next to questions28–30.
Population studies—Reasons for changing accommodation
Use the original chart with six bars and vertical scale0–100 in10-unit intervals.
Bar1: label C; height90
Bar2: label(28) __________; height80
Bar3: label E; height approximately55
Bar4: label(29) __________; height70
Bar5: label G; height30
Bar6: label(30) __________; height90
Possible reasons: A uncooperative landlord; B environment; C space; D noisy neighbours; E near city; F work location; G transport; H rent.
```

[Original question page](assets/8c8c9bb7c93091090d88dcf5f4a2fd3a6f10adc25c25b422dc48fb1b8753c073.jpg)

![Original figure](assets/8c8c9bb7c93091090d88dcf5f4a2fd3a6f10adc25c25b422dc48fb1b8753c073.jpg)

### Part 4

<!-- Source: /api/assets/c371e60787a6590df59e52c1c94bb128595acf92dd6ab7496e94529f9230b960.jpg; PDF page 18; full -->

```text
SECTION4 Questions31–40
Complete the notes below. Write NO MORE THAN TWO WORDS for each answer.
THE URBAN LANDSCAPE
Two areas of focus:
• the effect of vegetation on the urban climate
• ways of planning our (31) __________ better
Large-scale impact of trees:
• they can make cities more or less (32) __________
• in summer they can make cities cooler
• they can make inland cities more (33) __________
Local impact of trees: they can make local areas more (34) __________; cooler; more humid; less windy; less (35) __________.
Comparing trees and buildings
Temperature regulation: trees evaporate water through their (36) __________; building surfaces may reach high temperatures.
Wind force: tall buildings cause more wind at (37) __________ level; trees (38) __________ the wind force.
Noise: trees have a small effect on traffic noise; (39) __________ frequency noise passes through trees.
Important points to consider: trees require a lot of sunlight, water and (40) __________ to grow.
```

[Original question page](assets/c371e60787a6590df59e52c1c94bb128595acf92dd6ab7496e94529f9230b960.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/ff8cbfebcc1c07dbc57264dc7d0f4c4aa28a492986239b0bb3786e52ba81d2f1.jpg; PDF page 19; full -->

```text
READING



READING PASSAGE 1



You should spend about 20 minutes on Questions 1-14 which are based on Reading Passage 1

below.



Adults and children are frequently confronted with

statements about the alarming rate of loss of tropical

rainforests. For example, one graphic illustration to

which children might readily relate is the estimate that

rainforests are being destroyed at a rate equivalent to one

thousand football fields every forty minutes — about the

duration of a normal classroom period. In the face of the

frequent and often vivid media coverage, it is likely that

children will have formed ideas about rainforests — what

and where they are, why they are important, what endangers them — independent of any formal tuition. It is also

possible that some of these ideas will be mistaken.



Many studies have shown that children harbour misconceptions about ‘pure’, curriculum science. These misconceptions do not remain isolated but become incorporated into a multifaceted, but organised, conceptual framework, making it and the

component ideas, some of which are erroneous, more robust but also accessible to

modification. These ideas may be developed by children absorbing ideas through the

popular media. Sometimes this information may be erroneous. It seems schools may

not be providing an opportunity for children to re-express their ideas and so have them

tested and refined by teachers and their peers.



Despite the extensive coverage in the popular media of the destruction of rainforests,

little formal information is available about children’s ideas in this area. The aim of the

present study is to start to provide such information, to help teachers design their educational strategies to build upon correct ideas and to displace misconceptions and to

plan programmes in environmental studies in their schools.



The study surveys children’s scientific knowledge and attitudes to rainforests.

Secondary school children were asked to complete a questionnaire containing five

open-form questions. The most frequent responses to the first question were descriptions which are self-evident from the term ‘rainforest’. Some children described them

as damp, wet or hot. The second question concerned the geographical location of rainforests. The commonest responses were continents or countries: Africa (given by 43%

of children), South America (30%), Brazil (25%). Some children also gave more

general locations, such as being near the Equator.



18
```

[Original question page](assets/ff8cbfebcc1c07dbc57264dc7d0f4c4aa28a492986239b0bb3786e52ba81d2f1.jpg)

<!-- Source: /api/assets/52fe08d2d090e74b363bda48ae9f9a1ff3defb05a6976dd92f052180a897ed16.jpg; PDF page 20; full -->

```text
Responses to question three concerned the importance of rainforests. The dominant idea, raised by 64% of the pupils, was that rainforests provide animals with habitats. Fewer students responded that rainforests provide plant habitats, and even fewer

mentioned the indigenous populations of rainforests. More girls (70%) than boys

(60%) raised the idea of rainforest as animal habitats.



Similarly, but at a lower level, more girls (13%) than boys (5%) said that rainforests

provided human habitats. These observations are generally consistent with our previous studies of pupils’ views about the use and conservation of rainforests, in which

girls were shown to be more sympathetic to animals and expressed views which seem

to place an intrinsic value on non-human animal life.



The fourth question concerned the causes of the destruction of rainforests. Perhaps

encouragingly, more than half of the pupils (59%) identified that it is human activities

which are destroying rainforests, some personalising the responsibility by the use of

terms such as ‘we are’. About 18% of the pupils referred specifically to logging activity.



One misconception, expressed by some 10% of the pupils, was that acid rain is

responsible for rainforest destruction; a similar proportion said that pollution is

destroying rainforests. Here, children are confusing rainforest destruction with

damage to the forests of Western Europe by these factors. While two fifths of the students provided the information that the rainforests provide oxygen, in some cases this

response also embraced the misconception that rainforest destruction would reduce

atmospheric oxygen, making the atmosphere incompatible with human life on Earth.



In answer to the final question about the importance of rainforest conservation, the

majority of children simply said that we need rainforests to survive. Only a few of the

pupils (6%) mentioned that rainforest destruction may contribute to global warming.

This is surprising considering the high level of media coverage on this issue. Some

children expressed the idea that the conservation of rainforests is not important.



The results of this study suggest that certain ideas predominate in the thinking of

children about rainforests. Pupils’ responses indicate some misconceptions in basic

scientific knowledge of rainforests’ ecosystems such as their ideas about rainforests as

habitats for animals, plants and humans and the relationship between climatic change

and destruction of rainforests.



Pupils did not volunteer ideas that suggested that they appreciated the complexity of

causes of rainforest destruction. In other words, they gave no indication of an appreciation of either the range of ways in which rainforests are important or the complex

social, economic and political factors which drive the activities which are destroying

the rainforests. One encouragement is that the results of similar studies about other

environmental issues suggest that older children seem to acquire the ability to appreciate, value and evaluate conflicting views. Environmental education offers an arena in

which these skills can be developed, which is essential for these children as future decision-makers.



19
```

[Original question page](assets/52fe08d2d090e74b363bda48ae9f9a1ff3defb05a6976dd92f052180a897ed16.jpg)

<!-- Source: /api/assets/b813ad986e5c47329f8f2385903c7dd561480a00ebee6f7dcb7056de0e39fde2.jpg; PDF page 21; full -->

```text
Questions 1-8 
Do the following statements agree with the information given in Reading Passage 1? 
In boxes 1-8 on your answer sheet write 
TRUE if the statement agrees with the information 
FALSE if the statement contradicts the information 
NOT GIVEN if there is no information on this 
1 The plight of the rainforests has largely been ignored by the media. 
2 Children only accept opinions on rainforests that they encounter in their classrooms. 
3 It has been suggested that children hold mistaken views about the 'pure' science that 
they study at school. 
4 The fact that children's ideas about science form part of a larger framework of ideas 
means that it is easier to change them. 
5 The study involved asking children a number of yes/no questions such as 'Are there any 
rainforests in Africa?' 
6 Girls are more likely than boys to hold mistaken views about the rainforests' 
destruction. 
7 The study reported here follows on from a series of studies that have looked at 
children's understanding of rainforests. 
8 A second study has been planned to investigate primary school children's ideas about 
rainforests. 
20
```

[Original question page](assets/b813ad986e5c47329f8f2385903c7dd561480a00ebee6f7dcb7056de0e39fde2.jpg)

<!-- Source: /api/assets/a429e54e5a919acaca7a50f8841fb31c72ee5b0eefa4c210b112fb4d59d0c33a.jpg; PDF page 22; full -->

```text
Questions 9-13 
The box below gives a list of responses A-P to the questionnaire discussed in Reading 
Passage 1. 
Answer the following questions by choosing the correct responses A-P. 
Write your answers in boxes 9-13 on your answer sheet. 
9 What was the children's most frequent response when asked where the rainforests were? 
10 What was the most common response to the question about the importance of the 
rainforests? 
11 What did most children give as the reason for the loss of the rainforests? 
12 Why did most children think it important for the rainforests to be protected? 
13 Which of the responses is cited as unexpectedly uncommon, given the amount of time 
spent on the issue by the newspapers and television? 
A There is a complicated combination of reasons for the loss of the 
rainforests. 
B The rainforests are being destroyed by the same things that are 
destroying the forests of Western Europe. 
C Rainforests are located near the Equator. 
D Brazil is home to the rainforests. 
E Without rainforests some animals would have nowhere to live. 
F Rainforests are important habitats for a lot of plants. 
G People are responsible for the loss of the rainforests. 
H The rainforests are a source of oxygen. 
I Rainforests are of consequence for a number of different reasons. 
J As the rainforests are destroyed, the world gets warmer. 
K Without rainforests there would not be enough oxygen in the air. 
L There are people for whom the rainforests are home. 
M Rainforests are found in Africa. 
N Rainforests are not really important to human life. 
O The destruction of the rainforests is the direct result of logging 
activity. 
P Humans depend on the rainforests for their continuing existence. 
21
```

[Original question page](assets/a429e54e5a919acaca7a50f8841fb31c72ee5b0eefa4c210b112fb4d59d0c33a.jpg)

<!-- Source: /api/assets/045a2e6ef4cffc6ead0d3393c9206eee0e76668f0ea1b0dd761dc8b610370328.jpg; PDF page 23; full -->

```text
Question 14 
Choose the correct letter, A, B, C, D or E. 
Write your answer in box 14 on your answer sheet. 
Which of the following is the most suitable title for Reading Passage 1? 
22 
A The development of a programme in environmental studies within a 
science curriculum 
B Children's ideas about the rainforests and the implications for course 
design 
C The extent to which children have been misled by the media 
concerning the rainforests 
D How to collect, collate and describe the ideas of secondary school 
children 
E The importance of the rainforests and the reasons for their 
destruction
```

[Original question page](assets/045a2e6ef4cffc6ead0d3393c9206eee0e76668f0ea1b0dd761dc8b610370328.jpg)

<!-- Source: /api/assets/c01a0b149eee68257d8e0e6c6f8d9666bb60b7144bd5d4ac8a45e5928bb9a871.jpg; PDF page 24; full -->

```text
READING PASSAGE 2



You should spend about 20 minutes on Questions 15-26 which are based on Reading Passage 2

below.



What Do Whales Feel?



An examination of the functioning of the senses in cetaceans, the

group of mammals comprising whales, dolphins and porpoises



Some of the senses that we and other terrestrial mammals take for granted are either

reduced or absent in cetaceans or fail to function well in water. For example, it appears

from their brain structure that toothed species are unable to smell. Baleen species,

on the other hand, appear to have some related brain structures but it is not known

whether these are functional. It has been speculated that, as the blowholes evolved

and migrated to the top of the head, the neural pathways serving sense of smell may

have been nearly all sacrificed. Similarly, although at least some cetaceans have taste

buds, the nerves serving these have degenerated or are rudimentary.



The sense of touch has sometimes been described as weak too, but this view is probably mistaken. Trainers of captive dolphins and small whales often remark on their

animals’ responsiveness to being touched or rubbed, and both captive and freeranging cetacean individuals of all species (particularly adults and calves, or members

of the same subgroup) appear to make frequent contact. This contact may help to

maintain order within a group, and stroking or touching are part of the courtship ritual

in most species. The area around the blowhole is also particularly sensitive and

captive animals often object strongly to being touched there.



23
```

[Original question page](assets/c01a0b149eee68257d8e0e6c6f8d9666bb60b7144bd5d4ac8a45e5928bb9a871.jpg)

<!-- Source: /api/assets/526ea054e6724d5c1a62362618b19b0d58913b783386925476f72496b6257504.jpg; PDF page 25; full -->

```text
The sense of vision is developed to different degrees in different species. Baleen

species studied at close quarters underwater — specifically a grey whale calf in captivity for a year, and free-ranging right whales and humpback whales studied and filmed

off Argentina and Hawaii — have obviously tracked objects with vision underwater, and

they can apparently see moderately well both in water and in air. However, the position of the eyes so restricts the field of vision in baleen whales that they probably do

not have stereoscopic vision.



On the other hand, the position of the eyes in most dolphins and porpoises suggests

that they have stereoscopic vision forward and downward. Eye position in freshwater

dolphins, which often swim on their side or upside down while feeding, suggests that

what vision they have is stereoscopic forward and upward. By comparison, the bottlenose dolphin has extremely keen vision in water. Judging from the way it watches

and tracks airborne flying fish, it can apparently see fairly well through the air—water

interface as well. And although preliminary experimental evidence suggests that their

in-air vision is poor, the accuracy with which dolphins leap high to take small fish out

of a trainer's hand provides anecdotal evidence to the contrary.



Such variation can no doubt be explained with reference to the habitats in which individual species have developed. For example, vision is obviously more useful to species

inhabiting clear open waters than to those living in turbid rivers and flooded plains. The

South American boutu and Chinese beiji, for instance, appear to have very limited

vision, and the Indian susus are blind, their eyes reduced to slits that probably allow

them to sense only the direction and intensity of light.



Although the senses of taste and smell appear to have deteriorated, and vision in

water appears to be uncertain, such weaknesses are more than compensated for by

cetaceans’ well-developed acoustic sense. Most species are highly vocal, although

they vary in the range of sounds they produce, and many forage for food using echolocation’. Large baleen whales primarily use the lower frequencies and are often limited

in their repertoire. Notable exceptions are the nearly song-like choruses of bowhead

whales in summer and the complex, haunting utterances of the humpback whales.

Toothed species in general employ more of the frequency spectrum, and produce a

wider variety of sounds, than baleen species (though the sperm whale apparently produces a monotonous series of high-energy clicks and little else). Some of the more

complicated sounds are clearly communicative, although what role they may play in

the social life and ‘culture’ of cetaceans has been more the subject of wild speculation than of solid science.



1. echolocation: the perception of objects by means of sound wave echoes.



24
```

[Original question page](assets/526ea054e6724d5c1a62362618b19b0d58913b783386925476f72496b6257504.jpg)

<!-- Source: /api/assets/c16663deb69a79a59a7fa254c553b3e9c564125fd6e590ab9063bfc4b8ac2330.jpg; PDF page 26; full -->

```text
Questions15–21: Complete the table below.
Choose NO MORE THAN THREE WORDS from Reading Passage2 for each answer. Write your answers in boxes15–21 on your answer sheet.
SENSE | SPECIES | ABILITY | COMMENTS
Smell |toothed|no|evidence from brain structure
Smell |baleen|not certain|related brain structures are present
Taste |some types|poor|nerves linked to their (15) __________ are underdeveloped
Touch |all|yes|region around the blowhole very sensitive
Vision |(16) __________|yes|probably do not have stereoscopic vision
Vision |dolphins, porpoises|yes|probably have stereoscopic vision (17) __________ and __________
Vision |(18) __________|yes|probably have stereoscopic vision forward and upward
Vision |bottlenose dolphins|yes|exceptional in (19) __________ and good in air–water interface
Vision |boutu and beiji|poor|have limited vision
Vision |Indian susus|no|probably only sense direction and intensity of light
Hearing |most large baleen|yes|usually use (20) __________; repertoire limited
Hearing |(21) __________ whales and __________ whales|yes|song-like
Hearing |toothed|yes|use more of frequency spectrum; have wider repertoire
```

[Original question page](assets/c16663deb69a79a59a7fa254c553b3e9c564125fd6e590ab9063bfc4b8ac2330.jpg)

<!-- Source: /api/assets/c0a2d6dd4b2298680710479c8b41f0aaf8aeffc80e7889779becabee7fa2487a.jpg; PDF page 27; full -->

```text
Questions 22-26 
Answer the questions below using NO MORE THAN THREE WORDS from the passage for 
each answer. 
Write your answers in boxes 22-26 on your answer sheet. 
22 Which of the senses is described here as being involved in mating? 
23 Which species swims upside down while eating? 
24 What can bottlenose dolphins follow from under the water? 
25 Which type of habitat is related to good visual ability? 
26 Which of the senses is best developed in cetaceans? 
26
```

[Original question page](assets/c0a2d6dd4b2298680710479c8b41f0aaf8aeffc80e7889779becabee7fa2487a.jpg)

<!-- Source: /api/assets/3038bfef7b03afdb916d88ba96a707fefc603148c43986db3ccd4c68566ea43e.jpg; PDF page 28; full -->

```text
READING PASSAGE 3 
You should spend about 20 minutes on Questions 27-40 which are based on Reading Passage 3 
below. 
Visual Symbols and the Blind 
Part 1 
From a number of recent studies, it has become clear that blind people can appreciate 
the use of outlines and perspectives to describe the arrangement of objects and other 
surfaces in space. But pictures are more than literal representations. 
This fact was drawn to my attention dramatically when a blind 
woman in one of my investigations decided on her own initiative to 
draw a wheel as it was spinning. To show this motion, she traced a 
curve inside the circle (Fig. 1). I was taken aback. Lines of motion, 
such as the one she used, are a very recent invention in the history 
of illustration. Indeed, as art scholar David Kunzle notes, Wilhelm 
Busch, a trend-setting nineteenth-century cartoonist, used virtually 
no motion lines in his popular figures until about 1877. Fig. 1 
When I asked several other blind study subjects to draw a spinning wheel, one partic­
ularly clever rendition appeared repeatedly: several subjects showed the wheel's 
spokes as curved lines. When asked about these curves, they all described them as 
metaphorical ways of suggesting motion. Majority rule would argue that this device 
somehow indicated motion very well. But was it a better indicator than, say, broken 
or wavy lines- or any other kind of line, for that matter? The answer was not clear. So 
I decided to test whether various lines of motion were apt ways of showing movement 
or if they were merely idiosyncratic marks. Moreover, I wanted to discover whether 
there were differences in how the blind and the sighted interpreted lines of motion. 
To search out these answers, I created raised-line drawings of five different wheels, 
depicting spokes with lines that curved, bent, waved, dashed and extended beyond 
the perimeter of the wheel. I then asked eighteen blind volunteers to feel the wheels 
and assign one of the following motions to each wheel: wobbling, spinning fast, spin­
ning steadily, jerking or braking. My control group consisted of eighteen sighted 
undergraduates from the University of Toronto . 
All but one of the blind subjects assigned distinctive motions to each wheel. Most 
guessed that the curved spokes indicated that the wheel was spinning steadily; the 
wavy spokes, they thought, suggested that the wheel was wobbling; and the bent 
spokes were taken as a sign that the wheel was jerking. Subjects assumed that spokes 
extending beyond the wheel's perimeter signified that the wheel had its brakes on and 
that dashed spokes indicated the wheel was spinning quickly. 
27
```

[Original question page](assets/3038bfef7b03afdb916d88ba96a707fefc603148c43986db3ccd4c68566ea43e.jpg)

![Original figure](assets/3038bfef7b03afdb916d88ba96a707fefc603148c43986db3ccd4c68566ea43e.jpg)

<!-- Source: /api/assets/6fc3784b0d469ddb788c072ea92f98eb3d3dc653d92758eb804ba70b734e12bf.jpg; PDF page 29; full -->

```text
28 
In addition, the favoured description for the sighted was the favoured description for 
the blind in every instance. What is more, the consensus among the sighted was barely 
higher than that among the blind. Because motion devices are unfamiliar to the blind, 
the task I gave them involved some problem solving. Evidently, however, the blind not 
only figured out meanings for each line of motion, but as a group they generally came 
up with the same meaning at least as frequently as did sighted subjects. 
Part 2 
We have found that the blind understand other kinds of visual metaphors as well. One 
blind woman drew a picture of a child inside a heart- choosing that symbol, she said, 
to show that love surrounded the child. With Chang Hong Liu, a doctoral student from 
China, I have begun exploring how well blind people understand the symbolism 
behind shapes such as hearts that do not directly represent their meaning. 
We gave a list of twenty pairs of words to 
sighted subjects and asked them to pick from 
each pair the term that best related to a circle 
and the term that best related to a square. For 
example, we asked: What goes with soft? A 
circle or a square? Which shape goes with 
hard? 
All our subjects deemed the circle soft and the 
square hard. A full 94% ascribed happy to the 
circle, instead of sad. But other pairs revealed 
less agreement: 79% matched fast to slow and 
weak to strong, respectively. And only 51% 
linked deep to circle and shallow to square. 
(See Fig. 2.) When we tested four totally blind 
volunteers using the same list, we found that 
their choices closely resembled those made by 
the sighted subjects. One man, who had been 
blind since birth, scored extremely well. He 
made only one match differing from the con­
sensus, assigning 'far' to square and 'near' to 
circle. In fact, only a small majority of sighted 
subjects- 53% -had paired far and near to the 
opposite partners. Thus, we concluded that the 
blind interpret abstract shapes as sighted 
people do. 
Words associated Agreement 
with circle/square among 
subjects (%) 
SOFT-HARD 100 
MOTHER-FATHER 94 
HAPPY-SAD 94 
GOOD-EVIL 89 
LOVE-HATE 89 
ALIVE-DEAD 87 
BRIGHT-DARK 87 
LIGHT-HEAVY 85 
WARM-COLD 81 
SUMMER-WINTER 81 
WEAK -STRONG 79 
FAST-SLOW 79 
CAT-DOG 74 
SPRING-FALL 74 
QUIET-LOUD 62 
WALKING-STANDING 62 
ODD-EVEN 57 
FAR-NEAR 53 
PLANT-ANIMAL 53 
DEEP-SHALLOW 51 
Fig.2 Subjects were asked which word in each pair fits best with a circle and which with a square. These percentages show the level of consensus among sighted subjects.
```

[Original question page](assets/6fc3784b0d469ddb788c072ea92f98eb3d3dc653d92758eb804ba70b734e12bf.jpg)

<!-- Source: /api/assets/bef057b51a49dda571852337d4e43774bff4af7ae8f6cb611843703006e9822c.jpg; PDF page 30; full -->

```text
Questions 27-29 
Choose the correct letter, A, B, C or D. 
Write your answers in boxes 27-29 on your answer sheet. 
27 In the first paragraph the writer makes the point that blind people 
A may be interested in studying art. 
B can draw outlines of different objects and surfaces. 
C can recognise conventions such as perspective. 
D can draw accurately. 
28 The writer was surprised because the blind woman 
A drew a circle on her own initiative. 
B did not understand what a wheel looked like. 
C included a symbol representing movement. 
D was the first person to use lines of motion. 
29 From the experiment described in Part 1, the writer found that the blind subjects 
A had good understanding of symbols representing movement. 
B could control the movement of wheels very accurately. 
C worked together well as a group in solving problems. 
D got better results than the sighted undergraduates . 
Questions 30-32 
Look at the following diagrams (Questions 30-32), and the list of types of movement below. 
Match each diagram to the type of movement A-E generally assigned to it in the experiment. 
Choose the correct letter A-E and write them in boxes 30-32 on your answer sheet. 
30 31 32 
A steady spinning 
B jerky movement 
c rapid spinning 
D wobbling movement 
E use of brakes 
29
```

[Original question page](assets/bef057b51a49dda571852337d4e43774bff4af7ae8f6cb611843703006e9822c.jpg)

![Original figure](assets/bef057b51a49dda571852337d4e43774bff4af7ae8f6cb611843703006e9822c.jpg)

<!-- Source: /api/assets/7be413f925245ebad84dddad90c211ebd195d8e0f695c6e08d64d077b33c86d7.jpg; PDF page 31; full -->

```text
Questions 33-39 
Complete the summary below using words from the box. 
Write your answers in boxes 33-39 on your answer sheet. 
NB You may use any word more than once. 
In the experiment described in Part 2, a set of word 33 ...... was used to investigate whether 
blind and sighted people perceived the symbolism in abstract 34 ...... in the same way. 
Subjects were asked which word fitted best with a circle and which with a square . From the 
35 .... .. volunteers, everyone thought a circle fitted 'soft' while a square fitted 'hard'. 
However, only 51% of the 36 ...... volunteers assigned a circle to 37 ....... When the test was 
later repeated with 38 ...... volunteers, it was found that they made 39 .. .... choices. 
associations blind deep hard 
hundred identical pairs shapes 
sighted similar shallow soft 
words 
Question 40 
Choose the correct letter, A, B, C or D. 
Write your answer in box 40 on your answer sheet. 
Which of the following statements best summarises the writer's general conclusion? 
A The blind represent some aspects of reality differently from sighted people. 
B The blind comprehend visual metaphors in similar ways to sighted people . 
C The blind may create unusual and effective symbols to represent reality. 
D The blind may be successful artists if given the right training. 
30
```

[Original question page](assets/7be413f925245ebad84dddad90c211ebd195d8e0f695c6e08d64d077b33c86d7.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/fe39b55ab500f6a96ce3c9b9ca9f6c616c3e17f98080c95b8e3e6b95b5ee9b6e.jpg; PDF page 32; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The table below shows the proportion of different categories of families living in poverty in Australia in 1999.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original table or chart is retained below.]
```

[Original question page](assets/fe39b55ab500f6a96ce3c9b9ca9f6c616c3e17f98080c95b8e3e6b95b5ee9b6e.jpg)

![Original figure](assets/fe39b55ab500f6a96ce3c9b9ca9f6c616c3e17f98080c95b8e3e6b95b5ee9b6e.jpg)

### Task 2

<!-- Source: /api/assets/d26ee33022e3a836159a299c7f5af9e6cfc8fa88bf33307519303f17fa1de22d.jpg; PDF page 33; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Compare the advantages and disadvantages of three of the following as media for communicating information. State which you consider to be the most effective.

• comics
• books
• radio
• television
• film
• theatre

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/d26ee33022e3a836159a299c7f5af9e6cfc8fa88bf33307519303f17fa1de22d.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/e62e688b720b5097d5d112a82371f36e1ef60879ca51369f84ab874f2cb4c5f0.jpg; PDF page 34; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics . 
EXAMPLE 
Friends 
• Are your friends mostly your age or different ages? [Why?] 
• Do you usually see your friends during the week or at weekends? [Why?] 
• The last time you saw your friends, what did you do together? 
• In what ways are your friends important to you? 
PART2
Describe an interesting historic place.
You should say: what it is; where it is located; what you can see there now; and explain why this place is interesting.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you’re going to say. You can make some notes to help you if you wish.

PART 3 
Discussion topics: 
Looking after historic places 
Example questions: 
How do people in your country feel about protecting historic buildings? 
Do you think an area can benefit from having an interesting historic place locally? In what 
way? 
What do you think will happen to historic places or buildings in the future? Why? 
The teaching of history at school 
Example questions: 
How were you taught history when you were at school? 
Are there other ways people can learn about history , apart from at school? How? 
Do you think history will still be a school subject in the future? Why? 
33
```

[Original question page](assets/e62e688b720b5097d5d112a82371f36e1ef60879ca51369f84ab874f2cb4c5f0.jpg)

### Part 2

<!-- Source: /api/assets/e62e688b720b5097d5d112a82371f36e1ef60879ca51369f84ab874f2cb4c5f0.jpg; PDF page 34; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics . 
EXAMPLE 
Friends 
• Are your friends mostly your age or different ages? [Why?] 
• Do you usually see your friends during the week or at weekends? [Why?] 
• The last time you saw your friends, what did you do together? 
• In what ways are your friends important to you? 
PART2
Describe an interesting historic place.
You should say: what it is; where it is located; what you can see there now; and explain why this place is interesting.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you’re going to say. You can make some notes to help you if you wish.

PART 3 
Discussion topics: 
Looking after historic places 
Example questions: 
How do people in your country feel about protecting historic buildings? 
Do you think an area can benefit from having an interesting historic place locally? In what 
way? 
What do you think will happen to historic places or buildings in the future? Why? 
The teaching of history at school 
Example questions: 
How were you taught history when you were at school? 
Are there other ways people can learn about history , apart from at school? How? 
Do you think history will still be a school subject in the future? Why? 
33
```

[Original question page](assets/e62e688b720b5097d5d112a82371f36e1ef60879ca51369f84ab874f2cb4c5f0.jpg)

### Part 3

<!-- Source: /api/assets/e62e688b720b5097d5d112a82371f36e1ef60879ca51369f84ab874f2cb4c5f0.jpg; PDF page 34; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself, his/her home, work or studies and other 
familiar topics . 
EXAMPLE 
Friends 
• Are your friends mostly your age or different ages? [Why?] 
• Do you usually see your friends during the week or at weekends? [Why?] 
• The last time you saw your friends, what did you do together? 
• In what ways are your friends important to you? 
PART2
Describe an interesting historic place.
You should say: what it is; where it is located; what you can see there now; and explain why this place is interesting.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you’re going to say. You can make some notes to help you if you wish.

PART 3 
Discussion topics: 
Looking after historic places 
Example questions: 
How do people in your country feel about protecting historic buildings? 
Do you think an area can benefit from having an interesting historic place locally? In what 
way? 
What do you think will happen to historic places or buildings in the future? Why? 
The teaching of history at school 
Example questions: 
How were you taught history when you were at school? 
Are there other ways people can learn about history , apart from at school? How? 
Do you think history will still be a school subject in the future? Why? 
33
```

[Original question page](assets/e62e688b720b5097d5d112a82371f36e1ef60879ca51369f84ab874f2cb4c5f0.jpg)
