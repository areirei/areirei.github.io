# 剑雅 4 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 153

TEST1 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 shopping / variety of shopping
2 guided tours
3 more than12 / over12
4 notice board
5 13th February
6 Tower of London
7 Bristol
8 American Museum
9 student newspaper
10 Yentob
Section2, Questions11–20
11 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: coal; firewood
12 local craftsmen
13 160
14 Woodside
15 Ticket Office
16 Gift Shop
17 (main) Workshop
18 Showroom
19 Café
20 cottages
Section3, Questions21–30
21 A
22 C
23 E
24 B
25 G
26 F
27 C
28 D
29 A
30 B
Section4, Questions31–40
31 cities / environment
32 windy
33 humid
34 shady / shaded
35 dangerous
36 leaves
37 ground
38 considerably reduce / decrease / filter
39 low
40 space / room
If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–30: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
31–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. shopping / variety of shopping

2. guided tours

3. more than 12 / over 12

4. notice board

5. 13 February / 13th February

6. Tower of London

7. Bristol

8. American Museum

9. student newspaper

10. Yentob

### Part 2 · source page 153

TEST1 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 shopping / variety of shopping
2 guided tours
3 more than12 / over12
4 notice board
5 13th February
6 Tower of London
7 Bristol
8 American Museum
9 student newspaper
10 Yentob
Section2, Questions11–20
11 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: coal; firewood
12 local craftsmen
13 160
14 Woodside
15 Ticket Office
16 Gift Shop
17 (main) Workshop
18 Showroom
19 Café
20 cottages
Section3, Questions21–30
21 A
22 C
23 E
24 B
25 G
26 F
27 C
28 D
29 A
30 B
Section4, Questions31–40
31 cities / environment
32 windy
33 humid
34 shady / shaded
35 dangerous
36 leaves
37 ground
38 considerably reduce / decrease / filter
39 low
40 space / room
If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–30: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
31–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. coal firewood / coal, firewood / coal and firewood / coal & firewood / coal; firewood / coal/firewood / coal,firewood / firewood coal / firewood, coal / firewood and coal / firewood & coal / firewood; coal / firewood/coal / firewood,coal

12. local craftsmen

13. 160

14. Woodside

15. Ticket Office

16. Gift Shop

17. Workshop / main Workshop

18. Showroom

19. Café

20. cottages

### Part 3 · source page 153

TEST1 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 shopping / variety of shopping
2 guided tours
3 more than12 / over12
4 notice board
5 13th February
6 Tower of London
7 Bristol
8 American Museum
9 student newspaper
10 Yentob
Section2, Questions11–20
11 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: coal; firewood
12 local craftsmen
13 160
14 Woodside
15 Ticket Office
16 Gift Shop
17 (main) Workshop
18 Showroom
19 Café
20 cottages
Section3, Questions21–30
21 A
22 C
23 E
24 B
25 G
26 F
27 C
28 D
29 A
30 B
Section4, Questions31–40
31 cities / environment
32 windy
33 humid
34 shady / shaded
35 dangerous
36 leaves
37 ground
38 considerably reduce / decrease / filter
39 low
40 space / room
If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–30: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
31–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. A

22. C

23. E

24. B

25. G

26. F

27. C

28. D

29. A

30. B

### Part 4 · source page 153

TEST1 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 shopping / variety of shopping
2 guided tours
3 more than12 / over12
4 notice board
5 13th February
6 Tower of London
7 Bristol
8 American Museum
9 student newspaper
10 Yentob
Section2, Questions11–20
11 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: coal; firewood
12 local craftsmen
13 160
14 Woodside
15 Ticket Office
16 Gift Shop
17 (main) Workshop
18 Showroom
19 Café
20 cottages
Section3, Questions21–30
21 A
22 C
23 E
24 B
25 G
26 F
27 C
28 D
29 A
30 B
Section4, Questions31–40
31 cities / environment
32 windy
33 humid
34 shady / shaded
35 dangerous
36 leaves
37 ground
38 considerably reduce / decrease / filter
39 low
40 space / room
If you score… (original source guidance, not a new scoring rule)
0–14: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–30: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
31–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. cities / environment

32. windy

33. humid

34. shady / shaded

35. dangerous

36. leaves

37. ground

38. considerably reduce / decrease / filter

39. low

40. space / room

## A 类阅读

### Academic Reading · source page 154

ACADEMIC READING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Reading Passage1, Questions1–14
1 FALSE
2 FALSE
3 TRUE
4 TRUE
5 FALSE
6 NOT GIVEN
7 TRUE
8 NOT GIVEN
9 M
10 E
11 G
12 P
13 J
14 B
Reading Passage2, Questions15–26
15 taste buds
16 baleen / the baleen whales
17 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: forward; downward
18 freshwater dolphin(s) / the freshwater dolphin(s)
19 water / the water
20 lower frequencies / the lower frequencies
21 IN EITHER ORDER,BOTH REQUIRED FOR ONE MARK: bowhead; humpback
22 touch / sense of touch
23 freshwater dolphin(s) / the freshwater dolphin(s)
24 airborne flying fish
25 clear water(s) / clear open water(s)
26 acoustic sense / the acoustic sense
Reading Passage3, Questions27–40
27 C
28 C
29 A
30 E
31 C
32 A
33 pairs
34 shapes
35 sighted
36 sighted
37 deep
38 blind
39 similar
40 B
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–26: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
27–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. FALSE

2. FALSE

3. TRUE

4. TRUE

5. FALSE

6. NOT GIVEN

7. TRUE

8. NOT GIVEN

9. M

10. E

11. G

12. P

13. J

14. B

15. taste buds

16. baleen / the baleen whales

17. forward downward / forward, downward / forward and downward / forward & downward / forward; downward / forward/downward / forward,downward / downward forward / downward, forward / downward and forward / downward & forward / downward; forward / downward/forward / downward,forward

18. freshwater dolphin / freshwater dolphins / the freshwater dolphin / the freshwater dolphins

19. water / the water

20. lower frequencies / the lower frequencies

21. bowhead humpback / bowhead, humpback / bowhead and humpback / bowhead & humpback / bowhead; humpback / bowhead/humpback / bowhead,humpback / humpback bowhead / humpback, bowhead / humpback and bowhead / humpback & bowhead / humpback; bowhead / humpback/bowhead / humpback,bowhead

22. touch / sense of touch

23. freshwater dolphin / freshwater dolphins / the freshwater dolphin / the freshwater dolphins

24. airborne flying fish

25. clear water / clear waters / clear open water / clear open waters

26. acoustic sense / the acoustic sense

27. C

28. C

29. A

30. E

31. C

32. A

33. pairs

34. shapes

35. sighted

36. sighted

37. deep

38. blind

39. similar

40. B

## A 类写作

### Writing material: c4-t1-w-1

Original table inspected. Australia, 1999; column heading specifies proportion of PEOPLE from each household type living in poverty, with associated counts in parentheses. Single aged person: 6% (54,000); aged couple: 4% (48,000); single, no children: 19% (359,000); couple, no children: 7% (211,000); sole parent: 21% (232,000); couple with children: 12% (933,000); all households: 11% (1,837,000). These are within-category poverty rates, not shares of all poor people that should sum to 100%. Sole parents have the highest poverty rate, followed by childless singles; aged couples have the lowest rate. Couples with children have the largest absolute number despite a much lower rate than sole parents. Do not equate a higher percentage with a larger absolute count or infer causes or a multi-year trend.



### Writing material: c4-t1-w-2

Choose ANY THREE of the six listed media, compare their advantages and disadvantages, and identify which is considered most effective. The task does not require all six media. Do not penalise a valid selection of three or impose a fixed paragraph count.



## 口语
