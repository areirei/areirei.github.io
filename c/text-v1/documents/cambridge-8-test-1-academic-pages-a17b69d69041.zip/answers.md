# 剑雅 8 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 151

TEST 1 LISTENING
Section 1, Questions 1–10
1 C
2 B
3 48 North Avenue
4 WS6 2YH
5 01674 553242
6 (free) drink(s) / refreshment(s)
7 (the/a) pianist / piano player
8 10.50
9 4
10 50%
Section 2, Questions 11–20
11 1.30
12 25 December / Christmas Day
13 car-park / parking lot
14 45
15 (some) tables
16–18 IN ANY ORDER: C; F; G
19–20 IN EITHER ORDER: B; E
Section 3, Questions 21–30
21 A
22 C
23 A
24 B
25–27 IN ANY ORDER: B; C; F
28 12,000
29 horses
30 caves
Section 4, Questions 31–40
31 surface
32 environment
33 impact(s) / effect(s)
34 urban
35 problems
36 images
37 patterns
38 distortion(s)
39 traffic
40 weather
If you score… (original source guidance, not a new scoring rule)
0–14: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. C

2. B

3. 48 North Avenue

4. WS6 2YH / WS62YH

5. 01674 553242 / 01674553242

6. drink / drinks / free drink / free drinks / refreshment / refreshments

7. pianist / the pianist / a pianist / piano player

8. 10.50 / 10:50

9. 4

10. 50 per cent / 50 percent / 50%

### Part 2 · source page 151

TEST 1 LISTENING
Section 1, Questions 1–10
1 C
2 B
3 48 North Avenue
4 WS6 2YH
5 01674 553242
6 (free) drink(s) / refreshment(s)
7 (the/a) pianist / piano player
8 10.50
9 4
10 50%
Section 2, Questions 11–20
11 1.30
12 25 December / Christmas Day
13 car-park / parking lot
14 45
15 (some) tables
16–18 IN ANY ORDER: C; F; G
19–20 IN EITHER ORDER: B; E
Section 3, Questions 21–30
21 A
22 C
23 A
24 B
25–27 IN ANY ORDER: B; C; F
28 12,000
29 horses
30 caves
Section 4, Questions 31–40
31 surface
32 environment
33 impact(s) / effect(s)
34 urban
35 problems
36 images
37 patterns
38 distortion(s)
39 traffic
40 weather
If you score… (original source guidance, not a new scoring rule)
0–14: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. 1.30 / 1:30

12. 25 December / Christmas Day

13. car-park / parking lot

14. 45

15. tables / some tables

16. C / F / G

17. C / F / G

18. C / F / G

19. B / E

20. B / E

### Part 3 · source page 151

TEST 1 LISTENING
Section 1, Questions 1–10
1 C
2 B
3 48 North Avenue
4 WS6 2YH
5 01674 553242
6 (free) drink(s) / refreshment(s)
7 (the/a) pianist / piano player
8 10.50
9 4
10 50%
Section 2, Questions 11–20
11 1.30
12 25 December / Christmas Day
13 car-park / parking lot
14 45
15 (some) tables
16–18 IN ANY ORDER: C; F; G
19–20 IN EITHER ORDER: B; E
Section 3, Questions 21–30
21 A
22 C
23 A
24 B
25–27 IN ANY ORDER: B; C; F
28 12,000
29 horses
30 caves
Section 4, Questions 31–40
31 surface
32 environment
33 impact(s) / effect(s)
34 urban
35 problems
36 images
37 patterns
38 distortion(s)
39 traffic
40 weather
If you score… (original source guidance, not a new scoring rule)
0–14: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. A

22. C

23. A

24. B

25. B / C / F

26. B / C / F

27. B / C / F

28. 12,000 / 12000

29. horses

30. caves

### Part 4 · source page 151

TEST 1 LISTENING
Section 1, Questions 1–10
1 C
2 B
3 48 North Avenue
4 WS6 2YH
5 01674 553242
6 (free) drink(s) / refreshment(s)
7 (the/a) pianist / piano player
8 10.50
9 4
10 50%
Section 2, Questions 11–20
11 1.30
12 25 December / Christmas Day
13 car-park / parking lot
14 45
15 (some) tables
16–18 IN ANY ORDER: C; F; G
19–20 IN EITHER ORDER: B; E
Section 3, Questions 21–30
21 A
22 C
23 A
24 B
25–27 IN ANY ORDER: B; C; F
28 12,000
29 horses
30 caves
Section 4, Questions 31–40
31 surface
32 environment
33 impact(s) / effect(s)
34 urban
35 problems
36 images
37 patterns
38 distortion(s)
39 traffic
40 weather
If you score… (original source guidance, not a new scoring rule)
0–14: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
15–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. surface

32. environment

33. impact / impacts / effect / effects

34. urban

35. problems

36. images

37. patterns

38. distortion / distortions

39. traffic

40. weather

## A 类阅读

### Academic Reading · source page 152

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 D
2 B
3 F
4 E
5 B
6 F
7 D
8 A
9 (ship’s) anchor / (an/the) anchor
10 (escape) wheel
11 tooth
12 (long) pendulum
13 second
Reading Passage 2, Questions 14–26
14 ii
15 iii
16 v
17 iv
18 viii
19 vii
20 FALSE
21 FALSE
22 NOT GIVEN
23 TRUE
24 TRUE
25 FALSE
26 TRUE
Reading Passage 3, Questions 27–40
27 E
28 B
29 A
30 F
31 sender
32 picture / image
33 receiver
34–35 IN EITHER ORDER: sensory leakage (or); (outright) fraud
36 computers
37 human involvement
38 meta-analysis
39 lack of consistency
40 big / large enough
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. D

2. B

3. F

4. E

5. B

6. F

7. D

8. A

9. anchor / ship's anchor / an anchor / the anchor

10. wheel / escape wheel

11. tooth

12. pendulum / long pendulum

13. second

14. ii

15. iii

16. v

17. iv

18. viii

19. vii

20. FALSE

21. FALSE

22. NOT GIVEN

23. TRUE

24. TRUE

25. FALSE

26. TRUE

27. E

28. B

29. A

30. F

31. sender

32. picture / image

33. receiver

34. sensory leakage / sensory leakage or / fraud / outright fraud

35. sensory leakage / sensory leakage or / fraud / outright fraud

36. computers

37. human involvement

38. meta-analysis

39. lack of consistency

40. big enough / large enough

## A 类写作

### Writing material: c8-t1-w-1

Global causes of land degradation: over-grazing35%, deforestation30%, over-cultivation28%, other7%. These are shares of causes of worldwide degradation, not percentages of all global land damaged. Regional table, percentage of land degraded in the 1990s, columns deforestation/over-cultivation/over-grazing/total: North America0.2/3.3/1.5/5%; Europe9.8/7.7/5.5/23%; Oceania1.7/0/11.3/13%. Oceania footnote: a large group of South Pacific islands including Australia and New Zealand. Europe has the largest overall degraded share, North America the smallest. Main regional causes are deforestation in Europe, over-cultivation in North America, over-grazing in Oceania. Do not sum regional totals as a global share or substitute Australia alone for Oceania.



### Writing material: c8-t1-w-2

Discuss both parents' role and schools' role in teaching children to be good members of society, with an opinion.



## 口语
