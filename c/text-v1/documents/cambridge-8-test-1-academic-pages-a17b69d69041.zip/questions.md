# 剑雅 8 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/c0af95ec22751070e98f7abaa3eab0aace47ba0a9a54965a56bf0c1db2fb7909.jpg; PDF page 9; full -->

```text
Test 1
LISTENING
SECTION 1 Questions 1-10
Questions 1 and 2
Choose the correct letter, A, B or C.
Example
In the library George found
A a book.
B a brochure. [circled example answer]
C a newspaper.
1 In the lobby of the library George saw
A a group playing music.
B a display of instruments.
C a video about the festival.
2 George wants to sit at the back so they can
A see well.
B hear clearly.
C pay less.
10
```

[Original question page](assets/c0af95ec22751070e98f7abaa3eab0aace47ba0a9a54965a56bf0c1db2fb7909.jpg)

<!-- Source: /api/assets/c93c2a93427e94ef43deb9a542db9ae88ea9dbfc6453703fb24bdbd5069f161f.jpg; PDF page 10; full -->

```text
Questions 3–10
Complete the form below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
SUMMER MUSIC FESTIVAL BOOKING FORM
NAME: George O’Neill
ADDRESS: (3) __________, Westsea
POSTCODE: (4) __________
TELEPHONE: (5) __________
| Date | Event | Price per ticket | No. of tickets |
| --- | --- | --- | --- |
| 5 June | Instrumental group — Guitarrini | £7.50 | 2 |
| 17 June | Singer (price includes (6) __________ in the garden) | £6 | 2 |
| 22 June | (7) __________ (Anna Ventura) | £7.00 | 1 |
| 23 June | Spanish Dance & Guitar Concert | (8) £__________ | (9) __________ |
NB Children / Students / Senior Citizens have (10) __________ discount on all tickets.
```

[Original question page](assets/c93c2a93427e94ef43deb9a542db9ae88ea9dbfc6453703fb24bdbd5069f161f.jpg)

### Part 2

<!-- Source: /api/assets/2ac6809c58e6944804560313957ec9daaee8fad7aae53dec16ddc76b914c2744.jpg; PDF page 11; full -->

```text
Test1
SECTION 2
Questions 11-15
Questions 11-20
Complete the sentences below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
The Dinosaur Museum
11 The museum closes at ........................ p.m. on Mondays.
12 The museum is not open on ......................... .
13 School groups are met by tour guides in the ......................... .
14 The whole visit takes 90 minutes, including ......................... minutes for the
guided tour.
15 There are ........................ behind the museum where students can have lunch.
Questions 16-18
Choose THREE letters, A-G.
Which THREE things can students have with them in the museum?
A food
B water
C cameras
D books
E bags
F pens
G worksheets
12
r
```

[Original question page](assets/2ac6809c58e6944804560313957ec9daaee8fad7aae53dec16ddc76b914c2744.jpg)

<!-- Source: /api/assets/69d0d1019df734fd42f478ee68e6bc51290bc8ddffeb0f7b8f06d0a7849c1c46.jpg; PDF page 12; full -->

```text
Questions 19 and 20
Choose TWO letters, A-E.
Which TWO activities can students do after the tour at present?
A build model dinosaurs
B watch films
C draw dinosaurs
D find dinosaur eggs
E play computer games
Listening
13
```

[Original question page](assets/69d0d1019df734fd42f478ee68e6bc51290bc8ddffeb0f7b8f06d0a7849c1c46.jpg)

### Part 3

<!-- Source: /api/assets/768e6d73fccf01890ffb0a89545ac73af805210735f00d4dcb8d8377123e769b.jpg; PDF page 13; full -->

```text
Test 1
SECTION 3
Questions 21-24
Questions 21-30
Choose the correct letter, A, B or C.
Field Trip Proposal
21 The tutor thinks that Sandra's proposal
A should be re-ordered in some parts.
B needs a contents page.
C ought to include more information.
22 The proposal would be easier to follow if Sandra
A inserted subheadings.
B used more paragraphs.
C shortened her sentences.
23 What was the problem with the formatting on Sandra's proposal?
A Separate points were not clearly identified.
B The headings were not always clear.
C Page numbering was not used in an appropriate way.
24 Sandra became interested in visiting the Navajo National Park through
A articles she read.
B movies she saw as a child.
C photographs she found on the internet.
14
```

[Original question page](assets/768e6d73fccf01890ffb0a89545ac73af805210735f00d4dcb8d8377123e769b.jpg)

<!-- Source: /api/assets/56cddf66201987500dae7ebee3e2e741e9d1c9b544192dd7d2e543812c536bf5.jpg; PDF page 14; full -->

```text
Listening
Questions 25-27
Choose THREE letters, A-G.
Which THREE topics does Sandra agree to include in the proposal?
A climate change
B field trip activities
C geographical features
D impact of tourism
E myths and legends
F plant and animal life
G social history
Questions 28-30
Complete the sentences below.
Write ONE WORD AND/OR A NUMBER for each answer.
28 The tribal park covers ......................... hectares.
29 Sandra suggests that they share the ........................ for transport.
30 She says they could also explore the local ......................... .
15
```

[Original question page](assets/56cddf66201987500dae7ebee3e2e741e9d1c9b544192dd7d2e543812c536bf5.jpg)

### Part 4

<!-- Source: /api/assets/7c164cf63d135b0402e8de13af54b3262d0d7b3674d847f6d6e534fee230d291.jpg; PDF page 15; full -->

```text
Test 1
SECTION 4 Questions 31-40
Complete the notes below.
Write ONE WORD ONLY for each answer.
Geography
Studying geography helps us to understand:
• the effects of different processes on the 31 ......................... of the Earth
• the dynamic between 32 .......................... and population
Two main branches of study:
• physical features
• human lifestyles and their 33 ........................ .
Specific study areas: biophysical, topographic, political, social, economic,
historical and 34 ......................... geography, and also cartography
Key point: geography helps us to understand our surroundings and the
associated 35 ...................... ..
What do geographers do?
• find data - e.g. conduct censuses, collect information in the form of
36 ........................ using computer and satellite technology
• analyse data - identify 37 ........................ , e.g. cause and effect
16
```

[Original question page](assets/7c164cf63d135b0402e8de13af54b3262d0d7b3674d847f6d6e534fee230d291.jpg)

<!-- Source: /api/assets/9e2bad4416943c20591a3bfb7af5d0f63159dd3b49ac393cb0b6c550d3973341.jpg; PDF page 16; full -->

```text
Listening
• publish findings in form of:
a) maps
- easy to carry
- can show physical features of large and small areas
- BUT a two-dimensional map will always have some 38 ........................ .
b) aerial photos
- can show vegetation problems, 39 .......................... density, ocean floor etc.
c) Landsat pictures sent to receiving stations
- used for monitoring 40 ......................... conditions etc.
17
```

[Original question page](assets/9e2bad4416943c20591a3bfb7af5d0f63159dd3b49ac393cb0b6c550d3973341.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/ee14ae8333e3ab6cdcb9b9fd4e63265400d49f13a7e9b29eba9210a8441d5980.jpg; PDF page 17; full -->

```text
Test1
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
A Chronicle of Timekeeping
Our conception of time depends on the way we measure it
A According to archaeological evidence, at least 5,000 years ago, and long before the advent
of the Roman Empire, the Babylonians began to measure time, introducing calendars
to co-ordinate communal activities, to plan the shipment of goods and, in particular, to
regulate planting and harvesting. They based their calendars on three natural cycles: the
solar day, marked by the successive periods of light and darkness as the earth rotates on
its axis; the lunar month, following the phases of the moon as it orbits the earth; and
the solar year, defined by the changing seasons that accompany our planet's revolution
around the sun.
B Before the invention of artificial light, the moon had greater social impact. And, for those
living near the equator in particular, its waxing and waning was more conspicuous than
the passing of the seasons. Hence, the calendars that were developed at the lower latitudes
were influenced more by the lunar cycle than by the solar year. In more northern climes,
however, where seasonal agriculture was practised, the solar year became more crucial. As
the Roman Empire expanded northward, it organised its activity chart for the most part
around the solar year.
C Centuries before the Roman Empire, the Egyptians had formulated a municipal calendar
having 12 months of 30 days, with five days added to approximate the solar year. Each
period of ten days was marked by the appearance of special groups of stars called decans.
At the rise of the star Sirius just before sunrise, which occurred around the all-important
annual flooding of the Nile, 12 decans could be seen spanning the heavens. The cosmic
significance the Egyptians placed in the 12 decans led them to develop a system in which
each interval of darkness (and later, each interval of daylight) was divided into a dozen
equal parts. These periods became known as temporal hours because their duration varied
according to the changing length of days and nights with the passing of the seasons.
Summer hours were long, winter ones short; only at the spring and autumn equinoxes
18
```

[Original question page](assets/ee14ae8333e3ab6cdcb9b9fd4e63265400d49f13a7e9b29eba9210a8441d5980.jpg)

<!-- Source: /api/assets/74d19522c4bd79c208db7e6b6da3a778ff1cd932ff77df1ac9643045d212b2c9.jpg; PDF page 18; full -->

```text
Reading
were the hours of daylight and darkness equal. Temporal hours, which were first adopted
by the Greeks and then the Romans, who disseminated them through Europe, remained
in use for more than 2,500 years.
D In order to track temporal hours during the day, inventors created sundials, which indicate
time by the length or direction of the sun's shadow. The sundial's counterpart, the water
clock, was designed to measure temporal hours at night. One of the first water clocks
was a basin with a small hole near the bottom through which the water dripped out. The
falling water level denoted the passing hour as it dipped below hour lines inscribed on the
inner surface. Although these devices performed satisfactorily around the Mediterranean,
they could not always be depended on in the cloudy and often freezing weather of
northern Europe.
E The advent of the mechanical clock meant that although it could be adjusted to maintain
temporal hours, it was naturally suited to keeping equal ones. With these, however, arose
the question of when to begin counting, and so, in the early 14th century, a number of
systems evolved. The schemes that divided the day into 24 equal parts varied according
to the start of the count: Italian hours began at sunset, Babylonian hours at sunrise,
astronomical hours at midday and 'great clock' hours, used for some large public clocks
in Germany, at midnight. Eventually these were superseded by 'small clock', or French,
hours, which split the day into two 12-hour periods commencing at midnight.
F The earliest recorded weight-driven mechanical clock was built in 1283 in Bedfordshire
in England. The revolutionary aspect of this new timekeeper was neither the descending
weight that provided its motive force nor the gear wheels (which had been around for at
least 1,300 years) that transferred the power; it was the part called the escapement. In the
early 1400s came the invention of the coiled spring or fusee which maintained constant
force to the gear wheels of the timekeeper despite the changing tension of its mainspring.
By the 16th century, a pendulum clock had been devised, but the pendulum swung in a
large arc and thus was not very efficient.
G To address this, a variation on the original escapement was invented in 1670, in England.
It was called the anchor escapement, which was a lever-based device shaped like a ship's
anchor. The motion of a pendulum rocks this device so that it catches and then releases
each tooth of the escape wheel, in turn allowing it to turn a precise amount. Unlike
the original form used in early pendulum clocks, the anchor escapement permitted the
pendulum to travel in a very small arc. Moreover, this invention allowed the use of a long
pendulum which could beat once a second and thus led to the development of a new floor­
standing case design, which became known as the grandfather clock.
H Today, highly accurate timekeeping instruments set the beat for most electronic devices.
Nearly all computers contain a quartz-crystal clock to regulate their operation. Moreover,
not only do time signals beamed down from Global Positioning System satellites calibrate
the functions of precision navigation equipment, they do so as well for mobile phones,
instant stock-trading systems and nationwide power-distribution grids. So integral have
these time-based technologies become to day-to-day existence that our dependency on
them is recognised only when they fail to work.
19
```

[Original question page](assets/74d19522c4bd79c208db7e6b6da3a778ff1cd932ff77df1ac9643045d212b2c9.jpg)

<!-- Source: /api/assets/3f011d6efae70d2da4851cb5f9b76c5f8e0ba634b0467c81944ebad546750eba.jpg; PDF page 19; full -->

```text
Test1
Questions 1-4
Reading Passage 1 has eight paragraphs, A-H.
Which paragraph contains the following information?
Write the correct letter, A-H, in boxes 1-4 on your answer sheet.
1 a description of an early timekeeping invention affected by cold temperatures
2 an explanation of the importance of geography in the development of the calendar
in farming communities
3 a description of the origins of the pendulum clock
4 details of the simultaneous efforts of different societies to calculate time using
uniform hours
Questions 5-8
Look at the following events (Questions 5-8) and the list of nationalities below.
Match each event with the correct nationality, A-F.
Write the correct letter, A-F, in boxes 5-8 on your answer sheet.
5 They devised a civil calendar in which the months were equal in length.
6 They divided the day into two equal halves.
7 They developed a new cabinet shape for a type of timekeeper.
8 They created a calendar to organise public events and work schedules.
20
List of Nationalities
A Babylonians
B Egyptians
C Greeks
D English
E Germans
F French
```

[Original question page](assets/3f011d6efae70d2da4851cb5f9b76c5f8e0ba634b0467c81944ebad546750eba.jpg)

<!-- Source: /api/assets/9db555183cfcb7949933ba760312a8e38560f6459b52edf05de935c49c21249d.jpg; PDF page 20; full -->

```text
Questions 9–13
Label the diagram below. Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 9–13 on your answer sheet.
How the 1670 lever-based device worked
[Original mechanism diagram retained. Top label: escapement (resembling (9) __________), arrow pointing to the small lever above the wheel; (10) the __________ bracket around the whole wheel; (11) the __________ arrow pointing to one wheel projection; bracket around long swinging rod/bob: a (12) __________ which beats each (13) __________. Bottom curved arrow labelled small arc.]
```

[Original question page](assets/9db555183cfcb7949933ba760312a8e38560f6459b52edf05de935c49c21249d.jpg)

![Original figure](assets/9db555183cfcb7949933ba760312a8e38560f6459b52edf05de935c49c21249d.jpg)

<!-- Source: /api/assets/4897366261d2c8f96939a91e2bb5c1127946c258d2d3b2b09d77899ebf0f9c7e.jpg; PDF page 21; full -->

```text
Test1
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 on the following pages.
Questions 14-19
Reading Passage 2 has seven paragraphs, A-G.
Choose the correct heading for paragraphs A and C-G from the list below.
Write the correct number, i-x, in boxes 14-19 on your answer sheet.
List of Headings
i Disobeying FAA regulations
ii Aviation disaster prompts action
iii Two coincidental developments
iv Setting altitude zones
v An oversimplified view
vi Controlling pilots' licences
vii Defining airspace categories
viii Setting rules to weather conditions
ix Taking off safely
x First steps towards ATC
14 Paragraph A
Example Answer
Paragraph B X
15 Paragraph C
16 Paragraph D
17 Paragraph E
18 Paragraph F
19 Paragraph G
22
```

[Original question page](assets/4897366261d2c8f96939a91e2bb5c1127946c258d2d3b2b09d77899ebf0f9c7e.jpg)

<!-- Source: /api/assets/ead951bbe2a2b06f591ad4ed47b74d473792dfd1144fab17da498f9d4040d071.jpg; PDF page 22; full -->

```text
Reading
AIR TRAFFIC CONTROL IN THE USA
A An accident that occurred in the skies over the Grand Canyon in 1956 resulted
in the establishment of the Federal Aviation Administration (FAA) to regulate and
oversee the operation of aircraft in the skies over the United States, which were
becoming quite congested. The resulting structure of air traffic control has greatly
increased the safety of flight in the United States, and similar air traffic control
procedures are also in place over much of the rest of the world.
B Rudimentary air traffic control (ATC) existed well before the Grand Canyon disaster.
As early as the 1920s, the earliest air traffic controllers manually guided aircraft in
the vicinity of the airports, using lights and flags, while beacons and flashing lights
were placed along cross-country routes to establish the earliest airways. However,
this purely visual system was useless in bad weather, and, by the 1930s, radio
communication was coming into use for ATC. The first region to have something
approximating today's ATC was New York City, with other major metropolitan areas
following soon after.
C In the 1940s, ATC centres could and did take advantage of the newly developed
radar and improved radio communication brought about by the Second World War,
but the system remained rudimentary. It was only after the creation of the FAA that
full-scale regulation of America's airspace took place, and this was fortuitous, for
the advent of the jet engine suddenly resulted in a large number of very fast planes,
reducing pilots' margin of error and practically demanding some set of rules to
keep everyone well separated and operating safely in the air.
D Many people think that ATC consists of a row of controllers sitting in front of their
radar screens at the nation's airports, telling arriving and departing traffic what to
do. This is a very incomplete part of the picture. The FAA realised that the airspace
over the United States would at any time have many different kinds of planes, flying
for many different purposes, in a variety of weather conditions, and the same kind
of structure was needed to accommodate all of them.
E To meet this challenge, the following elements were put into effect. First, ATC
extends over virtually the entire United States. In general, from 365m above the
ground and higher, the entire country is blanketed by controlled airspace. In
certain areas, mainly near airports, controlled airspace extends down to 215m
above the ground, and, in the immediate vicinity of an airport, all the way down to
the surface. Controlled airspace is that airspace in which FAA regulations apply.
Elsewhere, in uncontrolled airspace, pilots are bound by fewer regulations. In this
way, the recreational pilot who simply wishes to go flying for a while without all the
23
```

[Original question page](assets/ead951bbe2a2b06f591ad4ed47b74d473792dfd1144fab17da498f9d4040d071.jpg)

<!-- Source: /api/assets/631e210f8840d7f042c0be48fb94da689eba080f03b9756011d72c86d9ef019d.jpg; PDF page 23; full -->

```text
Test1
restrictions imposed by the FAA has only to stay in uncontrolled airspace, below
365m, while the pilot who does want the protection afforded by ATC can easily
enter the controlled airspace.
F The FAA then recognised two types of operating environments. In good
meteorological conditions, flying would be permitted under Visual Flight Rules
(VFR), which suggests a strong reliance on visual cues to maintain an acceptable
level of safety. Poor visibility necessitated a set of Instrumental Flight Rules (IFR),
under which the pilot relied on altitude and navigational information provided by the
plane's instrument panel to fly safely. On a clear day, a pilot in controlled airspace
can choose a VFR or IFR flight plan, and the FAA regulations were devised in a way
which accommodates both VFR and IFR operations in the same airspace. However,
a pilot can only choose to fly IFR if they possess an instrument rating which is
above and beyond the basic pilot's license that must also be held.
G Controlled airspace is divided into several different types, designated by letters
24
of the alphabet. Uncontrolled airspace is designated Class F, while controlled
airspace below 5,490m above sea level and not in the vicinity of an airport is Class
E. All airspace above 5,490m is designated Class A. The reason for the division
of Class E and Class A airspace stems from the type of planes operating in them.
Generally, Class E airspace is where one finds general aviation aircraft (few of
which can climb above 5,490m anyway), and commercial turboprop aircraft. Above
5,490m is the realm of the heavy jets, since jet engines operate more efficiently at
higher altitudes. The difference between Class E and A airspace is that in Class
A, all operations are IFR, and pilots must be instrument-rated, that is, skilled and
licensed in aircraft instrumentation. This is because ATC control of the entire
space is essential. Three other types of airspace, Classes D, C and B, govern the
vicinity of airports. These correspond roughly to small municipal, medium-sized
metropolitan and major metropolitan airports respectively, and encompass an
increasingly rigorous set of regulations. For example, all a VFR pilot has to do to
enter Class C airspace is establish two-way radio contact with ATC. No explicit
permission from ATC to enter is needed, although the pilot must continue to obey all
regulations governing VFR flight. To enter Class B airspace, such as on approach
to a major metropolitan airport, an explicit ATC clearance is required. The private
pilot who cruises without permission into this airspace risks losing their license.
```

[Original question page](assets/631e210f8840d7f042c0be48fb94da689eba080f03b9756011d72c86d9ef019d.jpg)

<!-- Source: /api/assets/bf017490dbf58284c40c442da1b7fb3a55a32ce8bc64a3794b167f408956f5a4.jpg; PDF page 24; full -->

```text
Reading
Questions 20-26
Do the following statements agree with the information given in Reading Passage 2?
In boxes 20-26 on your answer sheet, write
TRUE
FALSE
NOT GIVEN
if the statement agrees with the information
if the statement contradicts the information
if there is no information on this
20 The FAA was created as a result of the introduction of the jet engine.
21 Air Traffic Control started after the Grand Canyon crash in 1956.
22 Beacons and flashing lights are still used by ATC today.
23 Some improvements were made in radio communication during World War II.
24 Class F airspace is airspace which is below 365m and not near airports.
25 All aircraft in Class E airspace must use IFR.
26 A pilot entering Class C airspace is flying over an average-sized city.
25
```

[Original question page](assets/bf017490dbf58284c40c442da1b7fb3a55a32ce8bc64a3794b167f408956f5a4.jpg)

<!-- Source: /api/assets/691a84472cfdf32797efec8442254de3df302ceee8cf266cbaab1d1263576c4f.jpg; PDF page 25; full -->

```text
Test1
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
TELEPATHY
Can human beings communicate by thought alone? For more than a
century the issue of telepathy has divided the scientific community, and
even today it still sparks bitter controversy among top academics
Since the 1970s, parapsychologists at leading universities and research institutes around
the world have risked the derision of sceptical colleagues by putting the various claims
for telepathy to the test in dozens of rigorous scientific studies. The results and their
implications are dividing even the researchers who uncovered them.
Some researchers say the results constitute compelling evidence that telepathy is genuine.
Other parapsychologists believe the field is on the brink of collapse, having tried to
produce definitive scientific proof and failed. Sceptics and advocates alike do concur on
one issue, however: that the most impressive evidence so far has come from the so-called
'ganzfeld' experiments, a German term that means 'whole field'. Reports of telepathic
experiences had by people during meditation led parapsychologists to suspect that
telepathy might involve 'signals' passing between people that were so faint that they
were usually swamped by normal brain activity. In this case, such signals might be more
easily detected by those experiencing meditation-like tranquillity in a relaxing 'whole
field' of light, sound and warmth.
The ganzfeld experiment tries to recreate these conditions with participants sitting in
soft reclining chairs in a sealed room, listening to relaxing sounds while their eyes are
covered with special filters letting in only soft pink light. In early ganzfeld experiments,
the telepathy test involved identification of a picture chosen from a random selection
of four taken from a large image bank. The idea was that a person acting as a 'sender'
would attempt to beam the image over to the 'receiver' relaxing in the sealed room.
Once the session was over, this person was asked to identify which of the four images
had been used. Random guessing would give a hit-rate of 25 per cent; if telepathy is real,
however, the hit-rate would be higher. In 1982, the results from the first ganzfeld studies
were analysed by one of its pioneers, the American parapsychologist Charles Honorton.
They pointed to typical hit-rates of better than 30 per cent - a small effect, but one which
statistical tests suggested could not be put down to chance.
The implication was that the ganzfeld method had revealed real evidence for telepathy.
But there was a crucial flaw in this argument one routinely overlooked in more
conventional areas of science. Just because chance had been ruled out as an explanation
did not prove telepathy must exist; there were many other ways of getting positive
26
```

[Original question page](assets/691a84472cfdf32797efec8442254de3df302ceee8cf266cbaab1d1263576c4f.jpg)

<!-- Source: /api/assets/ea166f813cdf8f6bcfe7ae9a3751afa9c419cefe6eb932a1c226503c42a19b2c.jpg; PDF page 26; full -->

```text
Reading
results. These ranged from 'sensory leakage' - where clues about the pictures accidentally
reach the receiver - to outright fraud. In response, the researchers issued a review of all
the ganzfeld studies done up to 1985 to show that 80 per cent had found statistically
significant evidence. However, they also agreed that there were still too many problems·
in the experiments which could lead to positive results, and they drew up a list demanding
new standards for future research.
After this, many researchers switched to autoganzfeld tests an automated variant of the
technique which used computers to perform many of the key tasks such as the random
selection of images. By minimising human involvement, the idea was to minimise the risk
of flawed results. In 1987, results from hundreds of autoganzfeld tests were studied by
Honorton in a 'meta-analysis', a statistical technique for finding the overall results from a
set of studies. Though less compelling than before, the outcome was still impressive.
Yet some parapsychologists remain disturbed by the lack of consistency between
individual ganzfeld studies. Defenders of telepathy point out that demanding impressive
evidence from every study ignores one basic statistical fact: it takes large samples to
detect small effects. If, as current results suggest, telepathy produces hit-rates only
marginally above the 25 per cent expected by chance, it's unlikely to be detected by a
typical ganzfeld study involving around 40 people: the group is just not big enough. Only
when many studies are combined in a meta-analysis will the faint signal of telepathy
really become apparent. And that is what researchers do seem to be finding.
What they are certainly not finding, however, is any change in attitude of mainstream
scientists: most still totally reject the very idea of telepathy. The problem stems at least in
part from the lack of any plausible mechanism for telepathy.
Various theories have been put forward, many focusing on esoteric ideas from theoretical
physics. They include 'quantum entanglement', in which events affecting one group
of atoms instantly affect another group, no matter how far apart they may be. While
physicists have demonstrated entanglement with specially prepared atoms, no-one
knows if it also exists between atoms making up human minds. Answering such questions
would transform parapsychology. This has prompted some researchers to argue that
the future lies not in collecting more evidence for telepathy, but in probing possible
mechanisms. Some work has begun already, with researchers trying to identify people
who are particularly successful in autoganzfeld trials. Early results show that creative and
artistic people do much better than average: in one study at the University of Edinburgh,
musicians achieved a hit-rate of 56 per cent. Perhaps more tests like these will eventually
give the researchers the evidence they are seeking and strengthen the case for the
existence of telepathy.
27
```

[Original question page](assets/ea166f813cdf8f6bcfe7ae9a3751afa9c419cefe6eb932a1c226503c42a19b2c.jpg)

<!-- Source: /api/assets/4ae6dd5c45b425f7d6a7cf95d4628eb921d1d255361afc8da7231a188ed19ea3.jpg; PDF page 27; full -->

```text
Test 1
Questions 27-30
Complete each sentence with the correct ending, A-G, below.
Write the correct letter, A-G, in boxes 27-30 on your answer sheet. ,
27 Researchers with differing attitudes towards telepathy agree on
28 Reports of experiences during meditation indicated
29 Attitudes to parapsychology would alter drastically with
30 Recent autoganzfeld trials suggest that success rates will improve with
A the discovery of a mechanism for telepathy.
B the need to create a suitable environment for telepathy.
C their claims of a high success rate.
D a solution to the problem posed by random guessing.
E the significance of the ganzfeld experiments.
F a more careful selection of subjects.
G a need to keep altering conditions.
28
```

[Original question page](assets/4ae6dd5c45b425f7d6a7cf95d4628eb921d1d255361afc8da7231a188ed19ea3.jpg)

<!-- Source: /api/assets/26ba1d27582135726d2bd287fda478d079cd09e68c6f0508edebbd81c75410b7.jpg; PDF page 28; full -->

```text
Questions 31–40
Complete the table below. Choose NO MORE THAN THREE WORDS from the passage for each answer.
Write your answers in boxes 31–40 on your answer sheet.
Telepathy Experiments
| Name/Date | Description | Result | Flaw |
| --- | --- | --- | --- |
| Ganzfeld studies 1982 | Involved a person acting as a (31) __________, who picked out one (32) __________ from a random selection of four, and a (33) __________, who then tried to identify it. | Hit-rates were higher than with random guessing. | Positive results could be produced by factors such as (34) __________ or (35) __________. |
| Autoganzfeld studies 1987 | (36) __________ were used for key tasks to limit the amount of (37) __________ in carrying out the tests. | The results were then subjected to a (38) __________. | The (39) __________ between different test results was put down to the fact that sample groups were not (40) __________ (as with most ganzfeld studies). |
```

[Original question page](assets/26ba1d27582135726d2bd287fda478d079cd09e68c6f0508edebbd81c75410b7.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/c6364e5c1c042d683cf1a36f52d3af697ab449ad2cf727cb4e72466ab3e52612.jpg; PDF page 29; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The pie chart below shows the main reasons why agricultural land becomes less productive. The table shows how these causes affected three regions of the world during the 1990s.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/c6364e5c1c042d683cf1a36f52d3af697ab449ad2cf727cb4e72466ab3e52612.jpg)

![Original figure](assets/c6364e5c1c042d683cf1a36f52d3af697ab449ad2cf727cb4e72466ab3e52612.jpg)

### Task 2

<!-- Source: /api/assets/e1dc4b6a6349b317dde8ce9980c370723b34aec057072554a7ff4d351a5294e7.jpg; PDF page 30; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people think that parents should teach children how to be good members of society. Others, however, believe that school is the place to learn this.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/e1dc4b6a6349b317dde8ce9980c370723b34aec057072554a7ff4d351a5294e7.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/34c8de372b9191b1eb746880b1362b9bf2cc916582fa70bd9289ad950c1fd62f.jpg; PDF page 31; full -->

```text
Test1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Neighbours
• How well do you know the people who live next door to you?
• How often do you see them? [Why/Why not?]
• What kinds of problem do people sometimes have with their neighbours?
• How do you think neighbours can help each other?
PART 2
Describe a time when you were asked to give
your opinion in a questionnaire or survey
You should say:
what the questionnaire/survey was about
why you were asked to give your opinions
what opinions you gave
and explain how you felt about giving your
opinions in this questionnaire/survey.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Asking questions
Example questions:
What kinds of organisation want to find out about people's opinions?
Do you think that questionnaires or surveys are good ways of finding out people's
opinions?
What reasons might people have for not wanting to give their opinions?
Questionnaires in school
Example questions:
Do you think it would be a good idea for schools to ask students their opinions about
lessons?
What would the advantages for schools be if they asked students their opinions?
Would there be any disadvantages in asking students' opinions?
32
```

[Original question page](assets/34c8de372b9191b1eb746880b1362b9bf2cc916582fa70bd9289ad950c1fd62f.jpg)

### Part 2

<!-- Source: /api/assets/34c8de372b9191b1eb746880b1362b9bf2cc916582fa70bd9289ad950c1fd62f.jpg; PDF page 31; full -->

```text
Test1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Neighbours
• How well do you know the people who live next door to you?
• How often do you see them? [Why/Why not?]
• What kinds of problem do people sometimes have with their neighbours?
• How do you think neighbours can help each other?
PART 2
Describe a time when you were asked to give
your opinion in a questionnaire or survey
You should say:
what the questionnaire/survey was about
why you were asked to give your opinions
what opinions you gave
and explain how you felt about giving your
opinions in this questionnaire/survey.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Asking questions
Example questions:
What kinds of organisation want to find out about people's opinions?
Do you think that questionnaires or surveys are good ways of finding out people's
opinions?
What reasons might people have for not wanting to give their opinions?
Questionnaires in school
Example questions:
Do you think it would be a good idea for schools to ask students their opinions about
lessons?
What would the advantages for schools be if they asked students their opinions?
Would there be any disadvantages in asking students' opinions?
32
```

[Original question page](assets/34c8de372b9191b1eb746880b1362b9bf2cc916582fa70bd9289ad950c1fd62f.jpg)

### Part 3

<!-- Source: /api/assets/34c8de372b9191b1eb746880b1362b9bf2cc916582fa70bd9289ad950c1fd62f.jpg; PDF page 31; full -->

```text
Test1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Neighbours
• How well do you know the people who live next door to you?
• How often do you see them? [Why/Why not?]
• What kinds of problem do people sometimes have with their neighbours?
• How do you think neighbours can help each other?
PART 2
Describe a time when you were asked to give
your opinion in a questionnaire or survey
You should say:
what the questionnaire/survey was about
why you were asked to give your opinions
what opinions you gave
and explain how you felt about giving your
opinions in this questionnaire/survey.
You will have to talk about the
topic for one to two minutes.
You have one minute to think
about what you are going to say.
You can make some notes to
help you if you wish.

PART 3
Discussion topics:
Asking questions
Example questions:
What kinds of organisation want to find out about people's opinions?
Do you think that questionnaires or surveys are good ways of finding out people's
opinions?
What reasons might people have for not wanting to give their opinions?
Questionnaires in school
Example questions:
Do you think it would be a good idea for schools to ask students their opinions about
lessons?
What would the advantages for schools be if they asked students their opinions?
Would there be any disadvantages in asking students' opinions?
32
```

[Original question page](assets/34c8de372b9191b1eb746880b1362b9bf2cc916582fa70bd9289ad950c1fd62f.jpg)
