# 剑雅 6 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/a9e6e2b6da1bd7c7974241bb46e6934c9374ba632063eb0b22a4b8407e4f7e6b.jpg; PDF page 79; full -->

```text
Test 4
LISTENING
SECTION 1 Questions 1-10
Complete the notes below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
Example Answer
Title of conference: Future Directions in Computing
Three day cost: 1 £ .......... ......... .... .
Payment by 2 ........................ or on arrival
Accommodation:
Conference Centre
• 3 £ ... ... ..... .. ...... .. ... per night
• near to conference rooms
Guest House
• 4 £ ... ...... ....... ...... .. per night
• approximately 5 ...... ......... ......... walk from Conference Centre
Further documents to be sent:
• 6 .......... ............ ..
• an application form
Location:
Conference Centre is on 7 .......... .............. Park Road, next to the 8 .................... .... .
Taxi costs 9 £ .... ............... ..... or take bus number 10 ........................ from station .
78
```

[Original question page](assets/a9e6e2b6da1bd7c7974241bb46e6934c9374ba632063eb0b22a4b8407e4f7e6b.jpg)

### Part 2

<!-- Source: /api/assets/97aa66c838cd916f2a3c2ebf10b0aa9fc538a5240348dac8245e46f30a6c5f45.jpg; PDF page 80; full -->

```text
SECTION 2 Questions 11-20
Questions 11-13
Which team will do each of the following jobs?
Choose THREE answers from the box and write the correct letter, A-D, next to
questions 11–13.
Teams
A the blue team
B the yellow team
C the green team
D the red team
11 checking entrance tickets __________
12 preparing refreshments __________
13 directing car-park traffic __________
Listening
79
```

[Original question page](assets/97aa66c838cd916f2a3c2ebf10b0aa9fc538a5240348dac8245e46f30a6c5f45.jpg)

<!-- Source: /api/assets/8663949b40657207f9f341eb5ed428d624a97e0e15d0f6b5943a674d20bf71c3.jpg; PDF page 81; full -->

```text
Questions 14–20
Complete the table below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Travel Expo — Temporary Staff Orientation Programme
| Time | Event | Details |
| --- | --- | --- |
| 9.30 am | Talk by Anne Smith | information about pay; will give out the (14) __________ forms |
| 10.00 am | Talk by Peter Chen | will discuss Conference Centre plan; will explain about arrangements for (15) __________ and fire exits |
| 10.30 am | Coffee Break | go to Staff Canteen on the (16) __________ |
| 11.00 am | Video Presentation | go to (17) __________; video title: (18) __________ |
| 12.00 | Buffet Lunch | go to the (19) __________ on 1st floor |
| 1.00 pm | Meet the (20) __________ | |
| 3.00 pm | Finish | |
```

[Original question page](assets/8663949b40657207f9f341eb5ed428d624a97e0e15d0f6b5943a674d20bf71c3.jpg)

### Part 3

<!-- Source: /api/assets/3369a5ba25aed7e83b26abecd5fc6d121d40ffed735a38d8cb5257c05dc24406.jpg; PDF page 82; full -->

```text
Listening
SECTION 3 Questions 21-30
Questions 21-25
Complete the summary below
Write ONE WORD ONLY for each answer.
The School of Education Libraries
The libraries on both sites provide internet access and have a variety of
21 ..................... materials on education.
The Castle Road library has books on sociology, together with 22 ....................... .
and other resources relevant to the majority of 23 ........................ school subjects.
The Fordham library includes resources for teaching in 24 ........................ education
and special needs.
Current issues of periodicals are available at both libraries, although
25 ........................ issues are only available at Fordham.
Questions 26 and 27
Answer the questions below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
26 Which books cannot be renewed by telephone or email?
27 How much time is allowed to return recalled books?
81
```

[Original question page](assets/3369a5ba25aed7e83b26abecd5fc6d121d40ffed735a38d8cb5257c05dc24406.jpg)

<!-- Source: /api/assets/1980323520432f6ce77cb55940d001a49b4162d5233fcf74ed32c1fbe2997d34.jpg; PDF page 83; full -->

```text
Test4
Questions 28-30
Choose THREE letters, A-G
Which THREE topics do this term's study skills workshops cover?
82
A An introduction to the Internet
B How to carry out research for a dissertation
C Making good use of the whole range of library services
D Planning a dissertation
E Standard requirements when writing a dissertation
F Using the Internet when doing research
G What books and technical resources are available in the library
```

[Original question page](assets/1980323520432f6ce77cb55940d001a49b4162d5233fcf74ed32c1fbe2997d34.jpg)

### Part 4

<!-- Source: /api/assets/0b2f048d85a9564c3d05877b2b8da807c30b4887eeb56d54e9b0be3572bc8302.jpg; PDF page 84; full -->

```text
Listening
SECTION 4 Questions 31-40
Questions 31-34
Choose the correct letter, A, B or C
31 When did Asiatic lions develop as a separate sub-species?
A about 10,000 years ago
B about 100,000 years ago
C about 1,000,000 years ago
32 Pictures of Asiatic lions can be seen on ancient coins from
A Greece.
B The Middle East.
C India.
33 Asiatic lions disappeared from Europe
A 2,500 years ago.
B 2,000 years ago.
C 1,900 years ago.
34 Very few African lions have
A a long mane.
B a coat with varied colours.
C a fold of skin on their stomach.
83
```

[Original question page](assets/0b2f048d85a9564c3d05877b2b8da807c30b4887eeb56d54e9b0be3572bc8302.jpg)

<!-- Source: /api/assets/08420a8109ef6987f667221084fe2139a48d9cfa481cf3d14731ff5313da2f6d.jpg; PDF page 85; full -->

```text
Test 4
Questions 35-40
Complete the sentences below.
Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
THE GIR SANCTUARY
35 The sanctuary has an area of approximately .................... .... square kilometres.
36 One threat to the lions in the sanctuary is ................ ........ .
37 The ancestors of the Gir Sanctuary lions were protected by a ........... .......... ... .
38 A large part of the lions ' ...................... .. consists of animals belonging to local
farmers.
39 The lions sometimes ................... ..... , especially when water is short.
40 In ancient India a man would fight a lion as a test of .............. .......... .
84
```

[Original question page](assets/08420a8109ef6987f667221084fe2139a48d9cfa481cf3d14731ff5313da2f6d.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/a65d19660900923a4c59c1a4551beedfdb231c5b35594580ec07ebf764e105d8.jpg; PDF page 86; full -->

```text
Reading
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage 1
on the following pages.
Questions 1-7
Reading Passage 1 has seven paragraphs , A-G.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i-x , in boxes 1-7 on your answer sheet.
List of Headings
i Not all doctors are persuaded
ii Choosing the best offers
iii Who is responsible for the increase in promotions?
iv Fighting the drug companies
v An example of what doctors expect from drug companies
vi Gifts include financial incentives
vii Research shows that promotion works
viii The high costs of research
ix The positive side of drugs promotion
x Who really pays for doctors ' free gifts?
1 Paragraph A __________
2 Paragraph B __________
3 Paragraph C __________
4 Paragraph D __________
5 Paragraph E __________
6 Paragraph F __________
7 Paragraph G __________
85
```

[Original question page](assets/a65d19660900923a4c59c1a4551beedfdb231c5b35594580ec07ebf764e105d8.jpg)

<!-- Source: /api/assets/dc1a560a9ae50775fc2ac5235afe2a9ab488526fd79702ff94499f1adffb53c3.jpg; PDF page 87; full -->

```text
Doctoring sales
Pharmaceuticals is one of the most profitable industries in North America. But do the drugs industry’s sales and marketing strategies go too far?
Test 4
A A few months ago Kim Schaefer, sales representative of a major global pharmaceutical
company, walked into a medical center in New York to bring information and free
samples of her company's latest products. That day she was lucky- a doctor was
available to see her. 'The last rep offered me a trip to Florida. What do you have?' the
physician asked. He was only half joking.
B What was on offer that day was a pair of tickets for a New York musical. But on any
given day, what Schaefer can offer is typical for today's drugs rep- a car trunk full of
promotional gifts and gadgets, a budget that could buy lunches and dinners for a small
country, hundreds of free drug samples and the freedom to give a physician $200 to
prescribe her new product to the next six patients who fit the drug's profile. And she
also has a few $1,000 honoraria to offer in exchange for doctors' attendance at her
company's next educational lecture.
C Selling pharmaceuticals is a daily exercise in ethical judgement. Salespeople like
Schaefer walk the line between the common practice of buying a prospect's time with
a free meal, and bribing doctors to prescribe their drugs. They work in an industry
highly criticized for its sales and marketing practices, but find themselves in the middle
of the age-old chicken-or-egg question- businesses won't use strategies that don't
work, so are doctors to blame for the escalating extravagance of pharmaceutical
marketing? Or is it the industry's responsibility to decide the boundaries?
D The explosion in the sheer number of salespeople in the field - and the amount of
funding used to promote their causes - forces close examination of the pressures,
influences and relationships between drug reps and doctors. Salespeople provide
much-needed information and education to physicians. In many cases the glossy
brochures, article reprints and prescriptions they deliver are primary sources of drug
education for healthcare givers. With the huge investment the industry has placed in
face-to-face selling, salespeople have essentially become specialists in one drug or
group of drugs- a tremendous advantage in getting the attention of busy doctors in
need of quick information.
E But the sales push rarely stops in the office. The flashy brochures and pamphlets left by
the sales reps are often followed up with meals at expensive restaurants, meetings in
warm and sunny places, and an inundation of promotional gadgets. Rarely do patients
watch a doctor write with a pen that isn't emblazoned with a drug's name, or see a
86
```

[Original question page](assets/dc1a560a9ae50775fc2ac5235afe2a9ab488526fd79702ff94499f1adffb53c3.jpg)

<!-- Source: /api/assets/5318a45f8944ae8db8543b59e9d0812c9af749f17db24b36e8a138a9f7e3e3c1.jpg; PDF page 88; full -->

```text
Reading
nurse use a tablet not bearing a pharmaceutical company 's logo. Millions of dollars are
spent by pharmaceutical companies on promotional products like coffee mugs, shirts ,
umbrellas , and golf balls. Money well spent? It's hard to tell. 'I've been the recipient of
golf balls from one company and I use them , but it doesn't make me prescribe their
medicine ,' says one doctor . 'I tend to think I'm not influenced by what they give me.'
F Free samples of new and expensive drugs might be the single most effective way of
getting doctors and patients to become loyal to a product. Salespeople hand out
hundreds of dollars' worth of samples each week- $7.2 billion worth of them in one
year. Though few comprehensive studies have been conducted , one by the University
of Washington investigated how drug sample availability affected what physicians
prescribe. A total of 131 doctors self-reported their prescribing patterns- the
conclusion was that the availability of samples led them to dispense and prescribe
drugs that differed from their preferred drug choice .
G The bottom line is that pharmaceutical companies as a whole invest more in marketing
than they do in research and development. And patients are the ones who pay - in the
form of sky-rocketing prescription prices- for every pen that' s handed out , every free
theatre ticket, and every steak dinner eaten . In the end the fact remains that
pharmaceutical companies have every right to make a profit and will continue to find
new ways to increase sales. But as the medical world continues to grapple with what’s
acceptable and what's not , it is clear that companies must continue to be heavily
scrutinized for their sales and marketing strategies .
87
```

[Original question page](assets/5318a45f8944ae8db8543b59e9d0812c9af749f17db24b36e8a138a9f7e3e3c1.jpg)

<!-- Source: /api/assets/59a5f4da9dd5e67f103ecec79d1a3bf2022448a2d20a3bf0826c36e969288e53.jpg; PDF page 89; full -->

```text
Test 4
Questions 8-13
Do the following statements agree with the views of the writer in Reading Passage 1?
In boxes 8-13 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the views of the writer
if the statement contradicts the views of the writer
if it is impossible to say what the writer thinks about this
8 Sales representatives like Kim Schaefer work to a very limited budget.
9 Kim Schaefer's marketing technique may be open to criticism on moral grounds.
10 The information provided by drug companies is of little use to doctors.
11 Evidence of drug promotion is clearly visible in the healthcare environment.
12 The drug companies may give free drug samples to patients without doctors '
prescriptions.
13 It is legitimate for drug companies to make money.
88
```

[Original question page](assets/59a5f4da9dd5e67f103ecec79d1a3bf2022448a2d20a3bf0826c36e969288e53.jpg)

<!-- Source: /api/assets/59924f63b09dbafb612b119a4e254689c0e3e8f9646d468a05e85ca4ff0dfc94.jpg; PDF page 90; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26 , which are based on Reading Passage 2
below.
Do literate women make better mothers?
Children in developing countries are healthier and more likely to survive past the age of five
when their mothers can read and write. Experts in public health accepted this idea decades
ago, but until now no one has been able to show that a woman's ability to read in itself
improves her children's chances of survival.
Most literate women learnt to read in primary school , and the fact that a woman has had an
education may simply indicate her family's wealth or that it values its children more highly.
Now a long-term study carried out in Nicaragua has eliminated these factors by showing that
teaching reading to poor adult women, who would otherwise have remained illiterate , has a
direct effect on their children's health and survival.
In 1979 , the government of Nicaragua established a number of social programmes, including
a National Literacy Crusade. By 1985, about 300,000 illiterate adults from all over the
country, many of whom had never attended primary school , had learnt how to read, write and
use numbers.
During this period, researchers from the Liverpool School of Tropical Medicine, the Central
American Institute of Health in Nicaragua, the National Autonomous University of Nicaragua
and the Costa Rican Institute of Health interviewed nearly 3,000 women, some of whom had
learnt to read as children , some during the literacy crusade and some who had never learnt
at all. The women were asked how many children they had given birth to and how many of
them had died in infancy. The research teams also examined the surviving children to find out
how well-nourished they were.
The investigators' findings were striking. In the late 1970s , the infant mortality rate for the
children of illiterate mothers was around 110 deaths per thousand live births. At this point in
their lives, those mothers who later went on to learn to read had a similar level of child
mortality (105/1000). For women educated in primary school, however, the infant mortality
rate was significantly lower, at 80 per thousand.
89
```

[Original question page](assets/59924f63b09dbafb612b119a4e254689c0e3e8f9646d468a05e85ca4ff0dfc94.jpg)

<!-- Source: /api/assets/83eee898939243d1c1bbe9a66ab9ec1c17571643ea7e91023f3a76f287deab50.jpg; PDF page 91; full -->

```text
Test4
In 1985, after the National Literacy Crusade had ended, the infant mortality figures for those
who remained illiterate and for those educated in primary school remained more or less
unchanged. For those women who learnt to read through the campaign, the infant mortality
rate was 84 per thousand, an impressive 21 points lower than for those women who were
still illiterate. The children of the newly-literate mothers were also better nourished than those
of women who could not read.
Why are the children of literate mothers better off? According to Peter Sandiford of the
Liverpool School of Tropical Medicine, no one knows for certain. Child health was not on the
curriculum during the women's lessons, so he and his colleagues are looking at other
factors. They are working with the same group of 3,000 women, to try to find out whether
reading mothers make better use of hospitals and clinics, opt for smaller families, exert more
control at home, learn modern childcare techniques more quickly, or whether they merely
have more respect for themselves and their children.
The Nicaraguan study may have important implications for governments and aid agencies that
need to know where to direct their resources. Sandiford says that there is increasing
evidence that female education, at any age, is 'an important health intervention in its own
right'. The results of the study lend support to the World Bank's recommendation that
education budgets in developing countries should be increased, not just to help their
economies, but also to improve child health.
'We've known for a long time that maternal education is important,' says John Cleland of the
London School of Hygiene and Tropical Medicine. 'But we thought that even if we started
educating girls today, we'd have to wait a generation for the pay-off. The Nicaraguan study
suggests we may be able to bypass that .'
Cleland warns that the Nicaraguan crusade was special in many ways, and similar campaigns
elsewhere might not work as well. It is notoriously difficult to teach adults skills that do not
have an immediate impact on their everyday lives, and many literacy campaigns in other
countries have been much less successful. 'The crusade was part of a larger effort to bring a
better life to the people,' says Cleland. Replicating these conditions in other countries will be
a major challenge for development workers.
90
```

[Original question page](assets/83eee898939243d1c1bbe9a66ab9ec1c17571643ea7e91023f3a76f287deab50.jpg)

<!-- Source: /api/assets/371f0a1f7681c7c0eaef7b0748e4625705bc986c520ff419d69e2e75d26bdc7c.jpg; PDF page 92; full -->

```text
Reading
Questions 14-18
Complete the summary using the list of words, A-J, below.
Write the correct letter, A-J, in boxes 14-18 on your answer sheet.
NB You may use any letter more than once.
The Nicaraguan National Literacy Crusade aimed to teach large numbers of illiterate
14 .......... .............. to read and write. Public health experts have known for many years that
there is a connection between child health and 15 .............. ...... .... . However, it has not
previously been known whether these two factors were directly linked or not. This question
has been investigated by 16 ............ ............ in Nicaragua. As a result, factors such as
17 ...... ......... ..... .... and attitudes to children have been eliminated, and it has been shown
that 18 ........................ can in itself improve infant health and survival.
A child literacy B men and women C an international research team
D medical care E mortality F maternal literacy
G adults and children H paternal literacy I a National Literacy Crusade
J family wealth
91
```

[Original question page](assets/371f0a1f7681c7c0eaef7b0748e4625705bc986c520ff419d69e2e75d26bdc7c.jpg)

<!-- Source: /api/assets/0f4e57be6aab9785a4c79917a0ace0c370c47a55c53c313e8febadb4cc312ed2.jpg; PDF page 93; full -->

```text
Test4
Questions 19-24
Do the following statements agree with the claims of the writer in Reading Passage 2?
In boxes 19-24 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
19 About a thousand of the women interviewed by the researchers had learnt to read when
they were children.
20 Before the National Literacy Crusade, illiterate women had approximately the same
levels of infant mortality as those who had learnt to read in primary school.
21 Before and after the National Literacy Crusade, the child mortality rate for the illiterate
women stayed at about 110 deaths for each thousand live births.
22 The women who had learnt to read through the National Literacy Crusade showed the
greatest change in infant mortality levels.
23 The women who had learnt to read through the National Literacy Crusade had the
lowest rates of child mortality.
24 After the National Literacy Crusade, the children of the women who remained illiterate
were found to be severely malnourished.
Questions 25 and 26
Choose TWO letters, A-E.
Write the correct letters in boxes 25 and 26 on your answer sheet.
Which TWO important implications drawn from the Nicaraguan study are mentioned by the ·
writer of the passage?
92
A It is better to educate mature women than young girls.
B Similar campaigns in other countries would be equally successful.
C The effects of maternal literacy programmes can be seen very quickly.
D Improving child health can quickly affect a country's economy.
E Money spent on female education will improve child health.
```

[Original question page](assets/0f4e57be6aab9785a4c79917a0ace0c370c47a55c53c313e8febadb4cc312ed2.jpg)

<!-- Source: /api/assets/04b32259dcb0edc415b8ba11f6cd07c45ec3b85449d42a3fe788e923cd0d32d2.jpg; PDF page 94; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40 , which are based on Reading Passage 3
on the following pages.
Questions 27-30
Reading Passage 3 has six sections, A-F.
Choose the correct heading for sections A-D from the list of headings below.
Write the correct number, i-vii, in boxes 27-30 on your answer sheet.
List of Headings
i The role of video violence
ii The failure of government policy
iii Reasons for the increased rate of bullying
iv Research into how common bullying is in British schools
v The reaction from schools to enquiries about bullying
vi The effect of bullying on the children involved
vii Developments that have led to a new approach by schools
27 Section A
28 Section B
29 Section C
30 Section D
93
```

[Original question page](assets/04b32259dcb0edc415b8ba11f6cd07c45ec3b85449d42a3fe788e923cd0d32d2.jpg)

<!-- Source: /api/assets/bc1ce59b0663aa98e65b360c7b30fb10d3769ea7fe1e0d4333571386202f1bd8.jpg; PDF page 95; full -->

```text
Test4
Persistent bullying is one of the worst experiences a child can face. How can it be prevented?
Peter Smith, Professor of Psychology at the University of Sheffield, directed the Sheffield
Anti-Bullying Intervention Project, funded by the Department for Education.
Here he reports on his findings.
A Bullying can take a variety of forms, from the verbal- being taunted or called hurtful
names - to the physical - being kicked or shoved - as well as indirect forms, such as
being excluded from social groups . A survey I conducted with Irene Whitney found
that in British primary schools up to a quarter of pupils reported experience of
bullying, which in about one in ten cases was persistent. There was less bullying in
secondary schools, with about one in twenty-five suffering persistent bullying, but
these cases may be particularly recalcitrant.
B Bullying is clearly unpleasant, and can make the child experiencing it feel unworthy
and depressed. In extreme cases it can even lead to suicide, though this is thankfully
rare. Victimised pupils are more likely to experience difficulties with interpersonal
relationships as adults, while children who persistently bully are more likely to grow
up to be physically violent, and convicted of anti-social offences.
C Until recently, not much was known about the topic, and little help was available to
teachers to deal with bullying. Perhaps as a consequence, schools would often deny
the problem. 'There is no bullying at this school' has been a common refrain, almost
certainly untrue. Fortunately more schools are now saying: 'There is not much
bullying here, but when it occurs we have a clear policy for dealing with it.'
D Three factors are involved in this change. First is an awareness of the severity of the
problem. Second, a number of resources to help tackle bullying have become
available in Britain. For example, the Scottish Council for Research in Education
produced a package of materials, Action Against Bullying, circulated to all schools in
England and Wales as well as in Scotland in summer 1992, with a second pack,
Supporting Schools Against Bullying, produced the following year. In Ireland, Guidelines
on Countering Bullying Behaviour in Post-Primary Schools was published in 1993. Third,
there is evidence that these materials work, and that schools can achieve something.
This comes from carefully conducted 'before and after' evaluations of interventions
in schools, monitored by a research team. In Norway, after an intervention campaign
was introduced nationally, an evaluation of forty-two schools suggested that, over a
two-year period, bullying was halved. The Sheffield investigation, which involved
sixteen primary schools and seven secondary schools, found that most schools
succeeded in reducing bullying.
94
```

[Original question page](assets/bc1ce59b0663aa98e65b360c7b30fb10d3769ea7fe1e0d4333571386202f1bd8.jpg)

<!-- Source: /api/assets/1ff97e7bd274050368aa7d1d6bdab374cec2eb0ca05c1fd5d6b2116256847693.jpg; PDF page 96; full -->

```text
Reading
E Evidence suggests that a key step is to develop a policy on bullying, saying clearly
what is meant by bullying, and giving explicit guidelines on what will be done if it
occurs , what records will be kept, who will be informed, what sanctions will be
employed. The policy should be developed through consultation, over a period of
time - not just imposed from the head teacher 's office! Pupils, parents and staff
should feel they have been involved in the policy, which needs to be disseminated and
implemented effectively.
Other actions can be taken to back up the policy. There are ways of dealing with
the topic through the curriculum, using video, drama and literature. These are useful
for raising awareness, and can best be tied in to early phases of development, while
the school is starting to discuss the issue of bullying. They are also useful in renewing
the policy for new pupils, or revising it in the light of experience. But curriculum
work alone may only have short-term effects; it should be an addition to policy work,
not a substitute.
There are also ways of working with individual pupils, or in small groups.
Assertiveness training for pupils who are liable to be victims is worthwhile , and
certain approaches to group bullying such as 'no blame', can be useful in changing the
behaviour of bullying pupils without confronting them directly, although other
sanctions may be needed for those who continue with persistent bullying.
Work in the playground is important , too. One helpful step is to train lunchtime
supervisors to distinguish bullying from playful fighting, and help them break up
conflicts. Another possibility is to improve the playground environment, so that
pupils are less likely to be led into bullying from boredom or frustration.
F With these developments, schools can expect that at least the most serious kinds of
bullying can largely be prevented. The more effort put in and the wider the whole
school involvement, the more substantial the results are likely to be. The reduction
in bullying - and the consequent improvement in pupil happiness - is surely a
worthwhile objective.
95
```

[Original question page](assets/1ff97e7bd274050368aa7d1d6bdab374cec2eb0ca05c1fd5d6b2116256847693.jpg)

<!-- Source: /api/assets/a55e93ae49f7063829d34a454433a6917a5eb516864d316ec76b7af55c336cec.jpg; PDF page 97; full -->

```text
Test4
Questions 31-34
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 31-34 on your answer sheet.
31 A recent survey found that in British secondary schools
A there was more bullying than had previously been the case.
B there was less bullying than in primary schools.
C cases of persistent bullying were very common .
D indirect forms of bullying were particularly difficult to deal with.
32 Children who are bullied
A are twice as likely to commit suicide as the average person.
B find it more difficult to relate to adults.
C are less likely to be violent in later life.
D may have difficulty forming relationships in later life.
33 The writer thinks that the declaration 'There is no bullying at this school'
A is no longer true in many schools.
B was not in fact made by many schools.
C reflected the school's lack of concern.
D reflected a lack of knowledge and resources.
34 What were the findings of research carried out in Norway?
A Bullying declined by 50% after an anti-bullying campaign.
B Twenty-one schools reduced bullying as a result of an anti-bullying campaign.
C Two years is the optimum length for an anti-bullying campaign.
D Bullying is a less serious problem in Norway than in the UK.
96
```

[Original question page](assets/a55e93ae49f7063829d34a454433a6917a5eb516864d316ec76b7af55c336cec.jpg)

<!-- Source: /api/assets/5b7b2671edb7da94262b672d3bf68f3c8c16a289a7bd442dd69137e7f2a566cb.jpg; PDF page 98; full -->

```text
Reading
Questions 35-39
Complete the summary below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 35- 39 on your answer sheet.
What steps should schools take to reduce bullying?
The most important step is for the school authorities to produce a 35 ......... ............... which
makes the school's attitude towards bullying quite clear. It should include detailed
36 ........................ as to how the school and its staff will react if bullying occurs.
In addition , action can be taken through the 37 ........................ . This is particularly useful
in the early part of the process, as a way of raising awareness and encouraging discussion.
On its own, however, it is insufficient to bring about a permanent solution .
Effective work can also be done with individual pupils and small groups. For example,
potential 38 ........................ of bullying can be trained to be more self-confident. Or again,
in dealing with group bullying, a 'no blame' approach, which avoids confronting the offender
too directly, is often effective.
Playground supervision will be more effective if members of staff are trained to recognise
the difference between bullying and mere 39 ........................ .
Question 40
Choose the correct letter, A, B, C or D.
Write the correct letter in box 40 on your answer sheet.
Which of the following is the most suitable title for Reading Passage 3?
A Bullying : what parents can do
B Bullying: are the media to blame?
C Bullying: the link with academic failure
D Bullying: from crisis management to prevention
97
```

[Original question page](assets/5b7b2671edb7da94262b672d3bf68f3c8c16a289a7bd442dd69137e7f2a566cb.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/34e7c1da5841bdf6b31d43c16c5690d2e7b08e28455b61f4a27e9f91d250c809.jpg; PDF page 99; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below give information about USA marriage and divorce rates between 1970 and 2000, and the marital status of adult Americans in two of the years.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the original figure is retained for the complete plotted data or diagram.]
```

[Original question page](assets/34e7c1da5841bdf6b31d43c16c5690d2e7b08e28455b61f4a27e9f91d250c809.jpg)

![Original figure](assets/34e7c1da5841bdf6b31d43c16c5690d2e7b08e28455b61f4a27e9f91d250c809.jpg)

### Task 2

<!-- Source: /api/assets/43aae2188976a173fc6d2cd3c5ac04c1e7ea51f7226652b9b8f5b16bd6176c5b.jpg; PDF page 100; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people prefer to spend their lives doing the same things and avoiding change. Others, however, think that change is always a good thing.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/43aae2188976a173fc6d2cd3c5ac04c1e7ea51f7226652b9b8f5b16bd6176c5b.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/cb191f71d3249c84774bbc15603e368941c7b624b763aa26c456adc6ae53c6e2.jpg; PDF page 101; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Your friends
• Do you prefer to have one particular friend or a group of friends? [Why?]
• What do you like doing most with your friend/s?
• Do you think it's important to keep in contact with friends you knew as a child?
[Why/Why not?]
• What makes a friend into a good friend?
PART 2
Describe an important choice you had to
make in your life.
You should say:
when you had to make this choice
what you had to choose between
whether you made a good choice
and explain how you felt when you were
making this choice.
You will have to talk about the topic for one
to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if you
wish.

PART 3
Discussion topics:
Important choices
Example questions:
What are the typical choices people make at different stages of their lives?
Should important choices be made by parents rather than by young adults?
Why do some people like to discuss choices with other people?
Choices in everyday life
Example questions:
What kind of choices do people have to make in their everyday life?
Why do some people choose to do the same things every day? Are there any disadvantages in
this?
Do you think that people today have more choices to make today than in the past?
lOO
```

[Original question page](assets/cb191f71d3249c84774bbc15603e368941c7b624b763aa26c456adc6ae53c6e2.jpg)

### Part 2

<!-- Source: /api/assets/cb191f71d3249c84774bbc15603e368941c7b624b763aa26c456adc6ae53c6e2.jpg; PDF page 101; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Your friends
• Do you prefer to have one particular friend or a group of friends? [Why?]
• What do you like doing most with your friend/s?
• Do you think it's important to keep in contact with friends you knew as a child?
[Why/Why not?]
• What makes a friend into a good friend?
PART 2
Describe an important choice you had to
make in your life.
You should say:
when you had to make this choice
what you had to choose between
whether you made a good choice
and explain how you felt when you were
making this choice.
You will have to talk about the topic for one
to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if you
wish.

PART 3
Discussion topics:
Important choices
Example questions:
What are the typical choices people make at different stages of their lives?
Should important choices be made by parents rather than by young adults?
Why do some people like to discuss choices with other people?
Choices in everyday life
Example questions:
What kind of choices do people have to make in their everyday life?
Why do some people choose to do the same things every day? Are there any disadvantages in
this?
Do you think that people today have more choices to make today than in the past?
lOO
```

[Original question page](assets/cb191f71d3249c84774bbc15603e368941c7b624b763aa26c456adc6ae53c6e2.jpg)

### Part 3

<!-- Source: /api/assets/cb191f71d3249c84774bbc15603e368941c7b624b763aa26c456adc6ae53c6e2.jpg; PDF page 101; full -->

```text
Test 4
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and other
familiar topics.
EXAMPLE
Your friends
• Do you prefer to have one particular friend or a group of friends? [Why?]
• What do you like doing most with your friend/s?
• Do you think it's important to keep in contact with friends you knew as a child?
[Why/Why not?]
• What makes a friend into a good friend?
PART 2
Describe an important choice you had to
make in your life.
You should say:
when you had to make this choice
what you had to choose between
whether you made a good choice
and explain how you felt when you were
making this choice.
You will have to talk about the topic for one
to two minutes.
You have one minute to think about what
you are going to say.
You can make some notes to help you if you
wish.

PART 3
Discussion topics:
Important choices
Example questions:
What are the typical choices people make at different stages of their lives?
Should important choices be made by parents rather than by young adults?
Why do some people like to discuss choices with other people?
Choices in everyday life
Example questions:
What kind of choices do people have to make in their everyday life?
Why do some people choose to do the same things every day? Are there any disadvantages in
this?
Do you think that people today have more choices to make today than in the past?
lOO
```

[Original question page](assets/cb191f71d3249c84774bbc15603e368941c7b624b763aa26c456adc6ae53c6e2.jpg)
