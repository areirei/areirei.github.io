# 剑雅 6 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 158

TEST 4 LISTENING
Section 1, Questions 1–10
1 75
2 cheque / check
3 15
4 25
5 10 minute(s’) / min(s’)
6 conference pack
7 South
8 library
9 5
10 21A
Section 2, Questions 11–20
11 D
12 A
13 C
14 tax
15 security
16 ground floor
17 lecture room 311
18 Safety at Work
19 Main Hall
20 team leaders
Section 3, Questions 21–30
21 reference
22 textbooks
23 secondary
24 primary
25 back
26 overdue books / ones
27 7 working days
28–30 IN ANY ORDER: C; E; F
Section 4, Questions 31–40
31 B
32 A
33 B
34 C
35 1,450
36 disease
37 (wealthy) prince
38 diet
39 attack humans
40 leadership
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. 75

2. cheque / check

3. 15

4. 25

5. 10 minute / 10 minutes' / 10 min / 10 mins'

6. conference pack

7. South

8. library

9. 5

10. 21A

### Part 2 · source page 158

TEST 4 LISTENING
Section 1, Questions 1–10
1 75
2 cheque / check
3 15
4 25
5 10 minute(s’) / min(s’)
6 conference pack
7 South
8 library
9 5
10 21A
Section 2, Questions 11–20
11 D
12 A
13 C
14 tax
15 security
16 ground floor
17 lecture room 311
18 Safety at Work
19 Main Hall
20 team leaders
Section 3, Questions 21–30
21 reference
22 textbooks
23 secondary
24 primary
25 back
26 overdue books / ones
27 7 working days
28–30 IN ANY ORDER: C; E; F
Section 4, Questions 31–40
31 B
32 A
33 B
34 C
35 1,450
36 disease
37 (wealthy) prince
38 diet
39 attack humans
40 leadership
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. D

12. A

13. C

14. tax

15. security

16. ground floor

17. lecture room 311

18. Safety at Work

19. Main Hall

20. team leaders

### Part 3 · source page 158

TEST 4 LISTENING
Section 1, Questions 1–10
1 75
2 cheque / check
3 15
4 25
5 10 minute(s’) / min(s’)
6 conference pack
7 South
8 library
9 5
10 21A
Section 2, Questions 11–20
11 D
12 A
13 C
14 tax
15 security
16 ground floor
17 lecture room 311
18 Safety at Work
19 Main Hall
20 team leaders
Section 3, Questions 21–30
21 reference
22 textbooks
23 secondary
24 primary
25 back
26 overdue books / ones
27 7 working days
28–30 IN ANY ORDER: C; E; F
Section 4, Questions 31–40
31 B
32 A
33 B
34 C
35 1,450
36 disease
37 (wealthy) prince
38 diet
39 attack humans
40 leadership
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. reference

22. textbooks

23. secondary

24. primary

25. back

26. overdue books / overdue ones

27. 7 working days

28. C / E / F

29. C / E / F

30. C / E / F

### Part 4 · source page 158

TEST 4 LISTENING
Section 1, Questions 1–10
1 75
2 cheque / check
3 15
4 25
5 10 minute(s’) / min(s’)
6 conference pack
7 South
8 library
9 5
10 21A
Section 2, Questions 11–20
11 D
12 A
13 C
14 tax
15 security
16 ground floor
17 lecture room 311
18 Safety at Work
19 Main Hall
20 team leaders
Section 3, Questions 21–30
21 reference
22 textbooks
23 secondary
24 primary
25 back
26 overdue books / ones
27 7 working days
28–30 IN ANY ORDER: C; E; F
Section 4, Questions 31–40
31 B
32 A
33 B
34 C
35 1,450
36 disease
37 (wealthy) prince
38 diet
39 attack humans
40 leadership
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. B

32. A

33. B

34. C

35. 1,450 / 1450

36. disease

37. prince / wealthy prince

38. diet

39. attack humans

40. leadership

## A 类阅读

### Academic Reading · source page 159

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 v
2 vi
3 iii
4 ix
5 i
6 vii
7 x
8 NO
9 YES
10 NO
11 YES
12 NOT GIVEN
13 YES
Reading Passage 2, Questions 14–26
14 B
15 F
16 C
17 J
18 F
19 NOT GIVEN
20 NO
21 YES
22 YES
23 NO
24 NOT GIVEN
25–26 IN EITHER ORDER: C; E
Reading Passage 3, Questions 27–40
27 iv
28 vi
29 v
30 vii
31 B
32 D
33 D
34 A
35 policy
36 (explicit) guidelines
37 (school) curriculum
38 victims
39 playful fighting
40 D
If you score… (original source guidance, not a new scoring rule)
0–12: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. v

2. vi

3. iii

4. ix

5. i

6. vii

7. x

8. NO

9. YES

10. NO

11. YES

12. NOT GIVEN

13. YES

14. B

15. F

16. C

17. J

18. F

19. NOT GIVEN

20. NO

21. YES

22. YES

23. NO

24. NOT GIVEN

25. C / E

26. C / E

27. iv

28. vi

29. v

30. vii

31. B

32. D

33. D

34. A

35. policy

36. guidelines / explicit guidelines

37. curriculum / school curriculum

38. victims

39. playful fighting

40. D

## A 类写作

### Writing material: c6-t4-w-1

Original charts inspected at full resolution. First graph actually plots NUMBERS in millions, despite the prompt using rates: marriages approximately 2.5/2.5/2.3/2.0 million in 1970/1980/1990/2000; divorces approximately 1.0/1.4/1.1/1.0 million. Marriages exceed divorces throughout and decline overall; divorces peak in 1980 then fall. Second graph percentages of adults, 1970/2000: never married about 15%/20%; married 70%/60%; widowed about 8%/5%; divorced about 2%/8%. Married is by far the largest category but declines; never-married and divorced shares increase, widowed decreases. The unlabelled bars are approximate: do not rescale them to force a 100% total or invent additional categories. The first chart is not per-thousand-population marriage rates.



### Writing material: c6-t4-w-2

Discuss both preference for continuity and the claim that change is always good, with an opinion. A nuanced position addressing the word always is valid.



## 口语
