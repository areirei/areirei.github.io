# 剑雅 2 · Test 4

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

> Academic Reading: PDF page 42 R: Reading Q16 options A–D and Q17 stem have truncated right ends in the original PDF; visible fragments are preserved without guessed completions.

## 听力

### Part 1

<!-- Source: /api/assets/4273914d2da72744db2ee554f957c3ba4d207f94606d912ef0996d674347957c.jpg; PDF page 36; L -->

```text
Test 4
SECTION 1 Questions 1-10
Questions 1 and 2
Complete the notes below.
Write NO MORE THAN THREE WORDS for each answer.
MIC HOUSE AGENCY — REPAIRS
Address: Apartment 2, (1) , Newton
Length of lease: one year
Date moved in: (2)
Questions 3-9
Complete the table below.
Write A if the repair will be done immediately.
B if the repair will be done during the following week.
C if the repair will be done in two or more weeks.
Item | Problem | When to be done
washing machine | leaking | shared time cell with cooker: (4) __________
cooker | (3) __________ | same shared time cell(4)
windows | (5) __________ | B
(6) __________ | flickers | (7) __________
(8) __________ | torn | (9) __________
Question 10
Write NO MORE THAN THREE WORDS or A NUMBER for each answer.
Workman to call between (10) __________ and __________.
[The original table’s time cell spans the washing-machine and cooker rows; the source page is retained for comparison.]
```

[Original question page](assets/4273914d2da72744db2ee554f957c3ba4d207f94606d912ef0996d674347957c.jpg)

### Part 2

<!-- Source: /api/assets/9a1414b37001cb039d00f946526c949ec45ac29c6f79f43957bb870bb57e3154.jpg; PDF page 36; R -->

```text
SECTION 2 Questions 11-20
Questions 11 and 12
Circle the correct letters A-C.
11 At Rainforest Lodge there aren't any ...
A telephones or TVs.
B newspapers or TVs.
C telephones or newspapers.
- 12 The guests are told to ...
A carry their luggage to the cabin.
B go straight to the restaurant.
C wait an hour for dinner.
Questions 13-15
Complete the table below.
Write NO MORE THAN THREE WORDS for each answer.
TOUR NAME | DETAILS
Orchid and Fungi | walking tour
Four-Wheel-Drive | tour to the (13) __________
Fishing | to catch lunch
Crocodile Cruise | departs at (14) __________ daily
(15) __________ | departs at sundown
```

[Original question page](assets/9a1414b37001cb039d00f946526c949ec45ac29c6f79f43957bb870bb57e3154.jpg)

<!-- Source: /api/assets/c2e36cd266c4c454f48cdefa9e1b2de38c8c01cc3533037c7039e22f7b4b2625.jpg; PDF page 37; L -->

```text
Questions 16-20
Write NO MORE THAN THREE WORDS for each answer.
What THREE items of. clothing does the speaker recommend for the rainforest?
16
17
18
Which TWO things in the rainforest does the speaker give a warning about?
19
20
```

[Original question page](assets/c2e36cd266c4c454f48cdefa9e1b2de38c8c01cc3533037c7039e22f7b4b2625.jpg)

### Part 3

<!-- Source: /api/assets/2de3ff84afec295fb66429ebc383ca62e4fd4efa2a1bc6a48db491d9ed1c3037.jpg; PDF page 37; R -->

```text
SECTION 3 Questions 21-30
Questions 21-25
Circle the correct letters A-C.
21 These sessions with a counsellor are ...
A compulsory for all students.
B available to any students.
C for science students only.
22 The counsellor says that new students have to ...
A spend more time on the college premises.
B get used to working independently.
C work harder than they did at school.
23 John complains that the resource centre ...
A has limited opening hours.
B has too few resources.
C gets too crowded.
24 The counsellor suggests to John that...
A most other students can cope.
B he needs to study all the time.
C he should be able to fit in some leisure activities.
25 Before being able to help John the counsellor needs to ...
A talk with some of his lecturers.
B consult his tutor.
C get more information from him.
```

[Original question page](assets/2de3ff84afec295fb66429ebc383ca62e4fd4efa2a1bc6a48db491d9ed1c3037.jpg)

<!-- Source: /api/assets/df62d7fdb045c84b4fbada409ee4219fb6e7ccbb5e64d47bb46720552f407689.jpg; PDF page 38; L -->

```text
Questions 26-30
Complete the notes below.
Write NO MORE THAN THREE WORDS for each answer.
WRITING
• Pay careful attention to the question
• Leave time to (26)
LISTENING
• Try to (27) lectures
• Check notes with (28)
READING
• Choose topics of (29)
• Buy a good (30)
```

[Original question page](assets/df62d7fdb045c84b4fbada409ee4219fb6e7ccbb5e64d47bb46720552f407689.jpg)

### Part 4

<!-- Source: /api/assets/e3de0aabc28d55d7fcadaea18a64ff03bf5e457d6937122894a115ab48ba4ca8.jpg; PDF page 38; R -->

```text
SECTION 4 Questions 31-40
Questions 31–35
Circle the correct letters A-C.
31 John was first interested in the subject because of something ...
A he had witnessed.
B he had read about.
C he had experienced.
32 The main research method was ...
A interviews.
B questionnaires.
C observation.
33 Which pie chart shows the proportion of men and women respondents?
Original pie-chart options A/B/C with Men/Women labels are retained below.
34 How many respondents were there?
A 50-100
B 100-150
C 150-200
35 The most common type of road rage incident involved ...
A damage to property.
B personal violence.
C verbal abuse.
```

[Original question page](assets/e3de0aabc28d55d7fcadaea18a64ff03bf5e457d6937122894a115ab48ba4ca8.jpg)

![Original figure](assets/e3de0aabc28d55d7fcadaea18a64ff03bf5e457d6937122894a115ab48ba4ca8.jpg)

<!-- Source: /api/assets/4037128e82d3d727b3f4f49c4aa9b7b61f30d2c9823e036694f9fd8b9b7cf04c.jpg; PDF page 39; L -->

```text
Questions 36–40
Which group gave the following advice?
Tick Column A if it was mainly women.
Tick Column B if it was mainly men.
Tick Column C if it was both men and women.
Example: Don’t stop to ask directions — A [ticked example]
(36) Avoid eye contact with other drivers: A / B / C
(37) Inform someone of your likely arrival time: A / B / C
(38) Ensure car keys are ready when you return to the car: A / B / C
(39) Leave plenty of space when parking: A / B / C
(40) Keep all doors locked: A / B / C
```

[Original question page](assets/4037128e82d3d727b3f4f49c4aa9b7b61f30d2c9823e036694f9fd8b9b7cf04c.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/ebc26b3e3d2fe8791771f4dd0978f36a1aa936f0e230678f6c061760a405c4f4.jpg; PDF page 39; R -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13 which are based on Reading Passage 1
below.
Green Wave Washes Over Mainstream Shopping
Research in Britain has shown that green
consumers' continue to flourish as a
significant group amongst shoppers. This
suggests that politicians who claim
environmentalism is yesterday's issue
may be seriously misjudging the public
mood.
A report from Mintel, the market
research organisation, says that despite
recession and financial pressures, more
people than ever want to buy
environmentally friendly products and a
'green wave' has swept through
consumerism, taking in people
previously untouched by environmental
concerns. The recently published report
also predicts that the process will repeat
itself with 'ethical' concerns, involving
issues such as fair trade with the Third
World and the social record of
businesses. Companies will have to be
more honest and open in response to
this mood.
Mintel's survey, based on nearly 1,000
consumers, found that the proportion
who look for green products and are
prepared to pay more for them has
climbed from 53 per cent in 1990 to
around 60 per cent in 1994. On average,
they will pay 13 per cent more for such
products, although this percentage is
higher among women, managerial and
professional groups and those aged 35
to 44.
Between 1990 and 1994 the
proportion of consumers claiming to be
unaware of or unconcerned about green
issues fell from 18 to 10 per cent but the
number of green spenders among older
people and manual workers has risen
substantially. Regions such as Scotland
have also caught up with the south of
England in their environmental concerns.
According to Mintel, the image of green
consumerism as associated in the past
with the more eccentric members of
society has virtually disappeared. The
consumer research manager for Mintel,
Angela Hughes, said it had become
firmly established as a mainstream
market. She explained that as far as the
average person is concerned
environmentalism has not gone off the
boil'. In fact, it has spread across a much
wider range of consumer groups, ages
and occupations.
Mintel's 1994 survey found that 13 per
cent of consumers are 'very dark green',
nearly always buying environmentally
friendly products, 28 per cent are 'dark
green', trying 'as far as possible' to buy
such products, and 21 per cent are 'pale
green' - tending to buy green products if
they see them. Another 26 per cent are
```

[Original question page](assets/ebc26b3e3d2fe8791771f4dd0978f36a1aa936f0e230678f6c061760a405c4f4.jpg)

<!-- Source: /api/assets/9fd66c770a1ac5c7c46da423b7a279db0303659ece15b3078d7aec380c17b2e4.jpg; PDF page 40; L -->

```text
'armchair greens'; they said they care 
about environmental issues but their 
concern does not affect their spending 
habits. Only 10 per cent say they do not 
care about green issues. 
Four in ten people are 'ethical 
spenders', buying goods which do not, 
for example, involve dealings with 
oppressive regimes. This figure is the 
same as in 1990, although the number of 
'armchair ethicals' has risen from 28 to 
35 per cent and only 22 per cent say they 
are unconcerned now, against 30 per 
cent in 1990. Hughes claims that in the 
twenty-first century, consumers will be 
encouraged to think more about the 
entire history of the products and

services they buy, including the policies
of the companies that provide them and
that this will require a greater degree of
honesty with consumers,
Among green consumers, animal
testing is the top issue - 48 per cent said
they would be deterred from buying a
product it if had been tested on animals -
followed by concerns regarding
irresponsible selling, the ozone layer,
river and sea pollution, forest destruction,
recycling and factory farming. However,
concern for specific issues is lower than
in 1990, suggesting that many
consumers feel that Government and
business have taken on the
environmental agenda.
Questions 1-6
Do the following statements agree with the claims of the writer of Reading Passage 1?
In boxes 1-6 on your answer sheet write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
1 The research findings report commercial rather than political trends.
2 Being financially better off has made shoppers more sensitive to buying 'green'.
3 The majority of shoppers are prepared to pay more for the benefit of the environment
according to the research findings.
4 Consumers' green shopping habits are influenced by Mintel's findings.
5 Mintel have limited their investigation to professional and managerial groups.
6 Mintel undertakes market surveys on an annual basis.
```

[Original question page](assets/9fd66c770a1ac5c7c46da423b7a279db0303659ece15b3078d7aec380c17b2e4.jpg)

<!-- Source: /api/assets/d01d7568419a173568137dc9564ecf0c66fca1edbf5f48b7e40f291e865eddd2.jpg; PDF page 40; R -->

```text
Questions 7-9
Choose the appropriate letters A-D and write them in boxes 7-9 on your answer sheet.
7 Politicians may have 'misjudged the public mood' because ...
A they are pre-occupied with the recession and financial problems.
B there is more widespread interest in the environment agenda than they anticipated.
C consumer spending has increased significantly as a result of 'green' pressure.
D shoppers are displeased with government policies on a range of issues.
8 What is Mintel?
A an environmentalist group
B a business survey organisation
C an academic research team
D a political organisation
9 A consumer expressing concern for environmental issues without actively supporting
such principles is...
A an 'ethical spender'.
B a 'very dark green' spender.
C an 'armchair green'.
D a 'pale green' spender.
```

[Original question page](assets/d01d7568419a173568137dc9564ecf0c66fca1edbf5f48b7e40f291e865eddd2.jpg)

<!-- Source: /api/assets/7730c5fe46194dc47dfa99f1b29f0fdf7ecda386e259498d1416850acc3fe879.jpg; PDF page 41; L -->

```text
Questions 10-13
Complete the summary using words from the box below.
Write your answers in boxes 10-13 on your answer sheet.
NB There are more answers than spaces, so you will not use them all.
The Mintel report suggests that in future companies will be forced to
practise greater ... (10) ... in their dealings because of the increased
awareness amongst... (11)... of ethical issues. This prediction is
supported by the growth in the number of ... (12)... identified in the
most recent survey published. As a consequence, it is felt that
companies will have to think more carefully about their ... (13)....
environmental research armchair ethicals
honesty and openness environmentalists
ethical spenders consumers
politicians political beliefs
social awareness financial constraints
social record
```

[Original question page](assets/7730c5fe46194dc47dfa99f1b29f0fdf7ecda386e259498d1416850acc3fe879.jpg)

<!-- Source: /api/assets/328d4015d257b010335219a28c53463900d7f7582523a486881eee5135280e9e.jpg; PDF page 41; R -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26 which are based on Reading Passage 2
below.
A There is a great concern in Europe and North America about declining
standards of literacy in schools. In Britain, the fact that 30 per cent of 16
year olds have a reading age of 14 or less has helped to prompt massive
educational changes. The development of literacy has far-reaching effects
on general intellectual development and thus anything which impedes the
development of literacy is a serious matter for us all. So the hunt is on for
the cause of the decline in literacy. The search so far has focused on socio-economic factors, or the effectiveness of 'traditional' versus 'modern'
teaching techniques.
B The fruitless search for the cause of the increase in illiteracy is a tragic
example of the saying 'They can't see the wood for the trees'. When
teachers use picture books, they are simply continuing a long-established
tradition that is accepted without question. And for the past two decades,
illustrations in reading primers have become increasingly detailed and
obtrusive, while language has become impoverished — sometimes to the
point of extinction.
C Amazingly, there is virtually no empirical evidence to support the use of
illustrations in teaching reading. On the contrary, a great deal of empirical
evidence shows that pictures interfere in a damaging way with all aspects of
learning to read. Despite this, from North America to the Antipodes, the
first books that many school children receive are totally without text.
D A teacher's main concern is to help young beginner readers to develop not
only the ability to recognise words, but the skills necessary to understand
what these words mean. Even if a child is able to read aloud fluently, he or
she may not be able to understand much of it: this is called 'barking at text'.
The teacher's task of improving comprehension is made harder by
influences outside the classroom. But the adverse effects of such things as
television, video games, or limited language experiences at home, can be
offset by experiencing 'rich' language at school.
E Instead, it is not unusual for a book of 30 or more pages to have only one
sentence full of repetitive phrases. The artwork is often marvellous, but the
pictures make the language redundant, and the children have no need to
imagine anything when they read such books. Looking at a picture actively
prevents children younger than nine from creating a mental image, and can
make it difficult for older children. In order to learn how to comprehend,
they need to practise making their own meaning in response to text. They
need to have their innate powers of imagination trained.
```

[Original question page](assets/328d4015d257b010335219a28c53463900d7f7582523a486881eee5135280e9e.jpg)

<!-- Source: /api/assets/bfc7d38a3225c380c41766e93c51c29b04d3ebf143e9cfe2a10d968c9fdbd2b2.jpg; PDF page 42; L -->

```text
F As they grow older, many children turn aside from books without pictures,
and it is a situation made more serious as our culture becomes more visual.
It is hard to wean children off picture books when pictures have played a
major part throughout their formative reading experiences, and when there
is competition for their attention from so many other sources of
entertainment. The least intelligent are most vulnerable, but tests show that
even intelligent children are being affected. The response of educators has
been to extend the use of pictures in books and to simplify the language,
even at senior levels. The Universities of Oxford and Cambridge recently
held joint conferences to discuss the noticeably rapid decline in literacy
among their undergraduates.
G Pictures are also used to help motivate children to read because they are
beautiful and eye-catching. But motivation to read should be provided by
listening to stories well read, where children imagine in response to the
story. Then, as they start to read, they have this experience to help them
understand the language. If we present pictures to save children the
trouble of developing these creative skills, then I think we are making a
great mistake.
H Academic journals ranging from educational research, psychology, language
learning, psycholinguistics, and so on cite experiments which demonstrate
how detrimental pictures are for beginner readers. Here is a brief selection:
I The research results of the Canadian educationalist Dale Willows were
clear and consistent: pictures affected speed and accuracy and the closer
the pictures were to the words, the slower and more inaccurate the child's
reading became. She claims that when children come to a word they
already know, then the pictures are unnecessary and distracting. If they do
not know a word and look to the picture for a clue to its meaning, they may
well be misled by aspects of the pictures which are not closely related to
the meaning of the word they are trying to understand.
J Jay Samuels, an American psychologist, found that poor readers given no
pictures learnt significantly more words than those learning to read with
books with pictures. He examined the work of other researchers who had
reported problems with the use of pictures and who found that a word
without a picture was superior to a word plus a picture.When children
were given words and pictures, those who seemed to ignore the pictures
and pointed at the words learnt more words than the children who pointed
at the pictures, but they still learnt fewer words than the children who had
no illustrated stimuli at all.
```

[Original question page](assets/bfc7d38a3225c380c41766e93c51c29b04d3ebf143e9cfe2a10d968c9fdbd2b2.jpg)

<!-- Source: /api/assets/0fdb7e9a91bb2b175e187e6f5a6a76d14cc64f7822c58b5ceade884e0277430f.jpg; PDF page 42; R -->

```text
Questions 14-17
Choose the appropriate letters A-D and write them in boxes 1i
14 Readers are said to 'bark' at a text when ...
A they read too loudly.
B there are too many repetitive words.
C they are discouraged from using their imagination.
D they have difficulty assessing its meaning.
15 The text suggests that...
A pictures in books should be less detailed.
B. pictures can slow down reading progress.
C picture books are best used with younger readers.
D pictures make modern books too expensive.
16 University academics are concerned because ...
A young people are showing less interest in higher ed
B students cannot understand modern academic text
C academic books are too childish for their undergra
D there has been a significant change in student litera
17 The youngest readers will quickly develop good reading
A learn to associate the words in a text with pictures.
B are exposed to modern teaching techniques.
C are encouraged to ignore pictures in the text.
D learn the art of telling stories.
[Source limitation: the supplied PDF itself truncates the right ends of Q16optionsA–D and the Q17stem, as well as the answer-box instruction. Both rendered original and independent PDF text extraction confirm the loss. Visible text is preserved; missing endings are not reconstructed.]
```

[Original question page](assets/0fdb7e9a91bb2b175e187e6f5a6a76d14cc64f7822c58b5ceade884e0277430f.jpg)

<!-- Source: /api/assets/732e8fc4cada2e1ad812b206dc1379cd03647d2a8e823d9314d0da5e1cdddf17.jpg; PDF page 43; L -->

```text
Questions 18-21
Do the following statements agree with the information given in Reading Passage 2?
In boxes 18-21 on your answer sheet write
YES if the statement agrees with the information
NO if the statement contradicts the information
NOT GIVEN if there is no information about this in the passage
18 It is traditionally accepted that children's books should contain few pictures.
19 Teachers aim to teach both word recognition and word meaning.
20 Older readers are having difficulty in adjusting to texts without pictures.
21 Literacy has improved as a result of recent academic conferences.
Questions 22-25
Reading Passage 2 has ten paragraphs, A-J. Which paragraphs state the following information?
Write the appropriate letters A-J in boxes 22-25 on your answer sheet.
NB There are more paragraphs than summaries, so you will not use them all.
22 The decline of literacy is seen in groups of differing ages and abilities.
23 Reading methods currently in use go against research findings.
24 Readers able to ignore pictures are claimed to make greater progress.
25 Illustrations in books can give misleading information about word meaning.
Question 26
From the list below choose the most suitable title for the whole of Reading Passage 2.
Write the appropriate letter A-E in box 26 on your answer sheet.
A The global decline in reading levels
B Concern about recent educational developments
C The harm that picture books can cause ,
D Research carried out on children's literature
E An examination of modern reading styles
```

[Original question page](assets/732e8fc4cada2e1ad812b206dc1379cd03647d2a8e823d9314d0da5e1cdddf17.jpg)

<!-- Source: /api/assets/5daabe3dedc6b1e3ff99137cbdf159f2ce0081f7d553f759bcf6d64f506c88be.jpg; PDF page 43; R -->

```text
READING PASSAGE 3
You should spend about 26 minutes on Questions 27-40 which are based on Reading Passage 3
below.
It has been called the Holy
Grail of modern biology.
Costing more than £2 billion,
it is the most ambitious
scientific project since the
Apollo programme that
landed a man on the moon.
And it will take longer to
accomplish than the lunar
missions, for it will not be
complete until early next
century. Even before it is
finished, according to those
involved, this project should
open up new understanding
of, and new treatments for,
many of the ailments that
afflict humanity. As a result of
the Human Genome Project,
there will be new hope of
liberation from the shadows
of cancer, heart disease, auto-immune diseases such as
rheumatoid arthritis, and
some psychiatric illnesses.
The objective of the
Human Genome Project is
simple to state, but audacious
in scope: to map and analyse
every single gene within the
double helix of humanity's
DNA1. The project will reveal
a new human anatomy — not
the bones, muscles and
sinews, but the complete
genetic blueprint for a human
being. Those working on the
Human Genome Project
claim that the new genetical
anatomy will transform
medicine and reduce human
suffering in the twenty-first
century. But others see the
future through a darker glass,
and fear that the project may
open the door to a world
peopled by Frankenstein's
monsters and disfigured by a
new eugenics2.
The genetic inheritance a
baby receives from its parents
at the moment of conception
fixes much of its later
development, determining
characteristics as varied as
whether it will have blue eyes
or suffer from a life-threatening illness such as
cystic fibrosis. The human
genome is the compendium
of all these inherited genetic
instructions. Written out
along the double helix of
DNA are the chemical letters
of the genetic text. It is an
extremely long text, for the
human genome contains
more than 3 billion letters:
On the printed page it would
fill about 7,000 volumes. Yet,
within little more than a
decade, the position of every
letter and its relation to its
neighbours will have been
tracked down, analysed and
recorded.
Considering how many
letters there are in the human
genome, nature is an
excellent proof-reader. But
sometimes there are mistakes.
An error in a single 'word' — a
gene - can give rise to the
crippling condition of cystic
fibrosis, the commonest
genetic disorder among
Caucasians. Errors in the
genetic recipe for
haemoglobin, the protein that
gives blood its characteristic
red colour and which carries
oxygen from the lungs to the
rest of the body, give rise to
the most common single-gene disorder in the world:
thalassaemia. More than 4,000
such single-gene defects are
known to afflict humanity.
The majority of them are
fatal; the majority of the
victims are children.
None of the single-gene
disorders is a disease in the
conventional sense, for which
it would be possible to
```

[Original question page](assets/5daabe3dedc6b1e3ff99137cbdf159f2ce0081f7d553f759bcf6d64f506c88be.jpg)

<!-- Source: /api/assets/703d5012bbe5ff7200c170703bb526849b4d2d931acd5da5ccffcdc2962412cf.jpg; PDF page 44; L -->

```text
administer a curative drug:
the defect is pre-programmed
into every cell of the
sufferer's body. But there is
hope of progress. In 1986,.
American researchers
identified the genetic defect
underlying one type of
muscular dystrophy. In 1989,
a team of American and
Canadian biologists
announced that they had
found the site of the gene
which, when defective, gives
rise to cystic fibrosis. Indeed,
not only had they located the
gene, they had analysed the
sequence of letters within it
and had identified the mistake
responsible for the condition.
At the least, these scientific
advances may offer a way of
screening parents who might
be at risk of transmitting a
single-gene defect to any
children that they conceive.
Foetuses can be tested while
in the womb, and if found
free of the genetic defect, the
parents will be relieved of
worry and stress, knowing
that they will be delivered of
a baby free from the disorder.
In the mid-1980s, the idea
gained currency within the
scientific world that the
techniques which were
successfully deciphering
disorder-related genes could
be applied to a larger project:
if science can learn the
genetic spelling of cystic
fibrosis, why not attempt to
find out how to spell 'human'?
Momentum quickly built up
behind the Human Genome
Project and its objective of
'sequencing' the entire
genome - writing out all the
letters in their correct order.
But the consequences of
the Human Genome Project
go far beyond a narrow focus
on disease. Some of its
supporters have made claims
of great extravagance - that
the Project will bring us to
understand, at the most
fundamental level, what it is
to be human. Yet many
people are concerned that
such an emphasis on
humanity's genetic
constitution may distort our
sense of values, and lead us
to forget that human life is
more than just the expression
of a genetic program written
in the chemistry of DNA.
If properly applied, the
new knowledge generated by
the Human Genome Project
may free humanity from the
terrible scourge of diverse
diseases. But if the new
knowledge is not used wisely,
it also holds the threat of
creating new forms of
discrimination and new
methods of oppression. Many
characteristics, such as height
and intelligence, result not
from the action of genes
alone, but from subtle
interactions between genes
and the environment. What
would be the implications if
humanity were to understand,
with precision, the genetic
constitution which, given the
same environment, will
predispose one person
towards a higher intelligence
than another individual
whose genes were differently
shuffled?
Once before in this
century, the relentless
curiosity of scientific
researchers brought to light
forces of nature in the power
of the atom, the mastery of
which has shaped the destiny
of nations and overshadowed
all our lives. The Human
Genome Project holds the
promise that, ultimately, we
may be able to alter our
genetic inheritance if we so
choose. But there is the
central moral problem: how
can we ensure that when we
choose, we choose correctly?
That such a potential is a
promise and not a threat? We
need only look at the past to
understand the danger.
Glossary
'DNA Deoxyribonucleic acid, molecules responsible for the transference of geneticcharacteristics.
2
 eugenics The science of improving the qualities of the human race, especially the careful selection of
parents.
```

[Original question page](assets/703d5012bbe5ff7200c170703bb526849b4d2d931acd5da5ccffcdc2962412cf.jpg)

<!-- Source: /api/assets/41790677a3216787f47b30d5f1ba5105d5a65379521334941c36ea0f86cd4ce6.jpg; PDF page 44; R -->

```text
Questions 27–32
Complete the sentences below with words taken from Reading Passage3.
Use NO MORE THAN THREE WORDS OR A NUMBER for each answer.
Write your answers in boxes27–32 on your answer sheet.
Example: The passage compares the genetic instructions in DNA to chemical letters.
27 The passage compares the Project in scale to the __________.
28 The possible completion date of the Project is __________.
29 To write out the human genome on paper would require __________ books.
30 A genetic problem cannot be treated with drugs because strictly speaking it is not a __________.
31 Research into genetic defects had its first success in the discovery of the cause of one form of __________.
32 The second success of research into genetic defects was to find the cause of __________.
```

[Original question page](assets/41790677a3216787f47b30d5f1ba5105d5a65379521334941c36ea0f86cd4ce6.jpg)

<!-- Source: /api/assets/498178e4f30eae6585fddeb35c24a2aea8e7fe41f484f98ad5a00eb21d3ed7af.jpg; PDF page 45; L -->

```text
Questions 33-40
Classify the following statements as representing
A the writer's fears about the Human Genome Project
B other people's fears about the Project reported by the writer
C the writer's reporting of facts about the Project
D the writer's reporting of the long-term hopes for the Project
Write the appropriate letters A-D in boxes 33—40 on your answer sheet.
33 The Project will provide a new understanding of major diseases.
34 All the components which make up DNA are to be recorded and studied.
35 Genetic monsters may be created.
36 The correct order and inter-relation of all genetic data in all DNA will be mapped.
37 Parents will no longer worry about giving birth to defective offspring.
38 Being 'human' may be defined solely in terms of describable physical data.
39 People may be discriminated against in new ways.
40 From past experience humans may not use this new knowledge wisely.
```

[Original question page](assets/498178e4f30eae6585fddeb35c24a2aea8e7fe41f484f98ad5a00eb21d3ed7af.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/2e291593211b5e29b0bc60b2c7d83d29d3b48f57edbc5f44f580be6bc79a82ef.jpg; PDF page 45; R -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The table below shows the figures for imprisonment in five countries between 1930 and 1980.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

See the retained original figure for the full table or chart.
```

[Original question page](assets/2e291593211b5e29b0bc60b2c7d83d29d3b48f57edbc5f44f580be6bc79a82ef.jpg)

![Original figure](assets/2e291593211b5e29b0bc60b2c7d83d29d3b48f57edbc5f44f580be6bc79a82ef.jpg)

### Task 2

<!-- Source: /api/assets/a1b1dc6e7f6d00516005f04177a64d7d7783855a196c40f2730dcedcba395818.jpg; PDF page 46; L -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic:

The position of women in society has changed markedly in the last twenty years. Many of the problems young people now experience, such as juvenile delinquency, arise from the fact that many married women now work and are not at home to care for their children.

To what extent do you agree or disagree with this opinion?

You should write at least 250 words.

You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.
```

[Original question page](assets/a1b1dc6e7f6d00516005f04177a64d7d7783855a196c40f2730dcedcba395818.jpg)

## 口语

### 原书口语任务

<!-- Source: /api/assets/1a2e0ec5304f51fd77b9bdedafe4d871bd99be9f312053c2570e2e0996b805a5.png; PDF page 46; R -->

```text
Task:
The candidate is to find out as much information as possible about buying a book.
Candidate's cue card:
BUYING A BOOK
Your teacher recommended a good English language writing book to assist students
with their written work.
Ask the examiner about: the level of the book
the title
the authors
the cost
place of purchase
extras - cassettes, answers
```

[Original question page](assets/1a2e0ec5304f51fd77b9bdedafe4d871bd99be9f312053c2570e2e0996b805a5.png)
