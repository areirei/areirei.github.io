# 剑雅 2 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 74

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are slated in the Key.)
0-18
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
19-26
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
27-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 16 Rose Lane
2 27(th) June or acceptable alternatives
3 door broken // broken door
4 C
5 no locks (on them) // need locks
6 bathroom light
7 A
8 kitchen curtains
9 B
10 1 (pm) (and) 5 (pm)
Section 2, Questions 11-20
11 B
12 C
13 waterfall(s) // water fall(s) // water-fall(s)
14 eleven/11.00//11 (am)
15 Spotlight (tour)
16–18 walking boots; socks; long trousers (in any order)
19–20 (venomous/poisonous) snakes; (certain) plants (in either order)
Section 3, Questions 21-30
21 B
22 B
23 A
24 C
25 C
26 check (over) (your) work/errors // revise
(work)
27 record
28 (a) friend ACCEPT freind
29 general interest NOT interest
30 dictionary
Section 4, Questions 31-40
31 B
32 A
33 A
34 B
35 C
36 B
37 A
38 C
39 B
40 C

1. 16 Rose Lane

2. 27 June / 27th June

3. door broken / broken door

4. C

5. no locks / no locks on them / need locks

6. bathroom light

7. A

8. kitchen curtains

9. B

10. 1 5 / 15 / 1 5 pm / 1 5pm / 1 and 5 / 1 and 5 pm / 1 and 5pm / 1 pm 5 / 1pm 5 / 1 pm 5 pm / 1pm 5pm / 1 pm and 5 / 1pm and 5 / 1 pm and 5 pm / 1pm and 5pm

### Part 2 · source page 74

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are slated in the Key.)
0-18
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
19-26
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
27-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 16 Rose Lane
2 27(th) June or acceptable alternatives
3 door broken // broken door
4 C
5 no locks (on them) // need locks
6 bathroom light
7 A
8 kitchen curtains
9 B
10 1 (pm) (and) 5 (pm)
Section 2, Questions 11-20
11 B
12 C
13 waterfall(s) // water fall(s) // water-fall(s)
14 eleven/11.00//11 (am)
15 Spotlight (tour)
16–18 walking boots; socks; long trousers (in any order)
19–20 (venomous/poisonous) snakes; (certain) plants (in either order)
Section 3, Questions 21-30
21 B
22 B
23 A
24 C
25 C
26 check (over) (your) work/errors // revise
(work)
27 record
28 (a) friend ACCEPT freind
29 general interest NOT interest
30 dictionary
Section 4, Questions 31-40
31 B
32 A
33 A
34 B
35 C
36 B
37 A
38 C
39 B
40 C

11. B

12. C

13. waterfall / waterfalls / water fall / water falls / water-fall / water-falls

14. eleven / 11.00 / 11:00 / 11 / 11 am / 11am

15. Spotlight / Spotlight tour

16. walking boots / socks / long trousers

17. walking boots / socks / long trousers

18. walking boots / socks / long trousers

19. snakes / venomous snakes / poisonous snakes / plants / certain plants

20. snakes / venomous snakes / poisonous snakes / plants / certain plants

### Part 3 · source page 74

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are slated in the Key.)
0-18
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
19-26
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
27-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 16 Rose Lane
2 27(th) June or acceptable alternatives
3 door broken // broken door
4 C
5 no locks (on them) // need locks
6 bathroom light
7 A
8 kitchen curtains
9 B
10 1 (pm) (and) 5 (pm)
Section 2, Questions 11-20
11 B
12 C
13 waterfall(s) // water fall(s) // water-fall(s)
14 eleven/11.00//11 (am)
15 Spotlight (tour)
16–18 walking boots; socks; long trousers (in any order)
19–20 (venomous/poisonous) snakes; (certain) plants (in either order)
Section 3, Questions 21-30
21 B
22 B
23 A
24 C
25 C
26 check (over) (your) work/errors // revise
(work)
27 record
28 (a) friend ACCEPT freind
29 general interest NOT interest
30 dictionary
Section 4, Questions 31-40
31 B
32 A
33 A
34 B
35 C
36 B
37 A
38 C
39 B
40 C

21. B

22. B

23. A

24. C

25. C

26. check work / check your work / check over work / check over your work / check errors / check your errors / check over errors / check over your errors / revise / revise work

27. record

28. friend / a friend / freind / a freind

29. general interest

30. dictionary

### Part 4 · source page 74

LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are slated in the Key.)
0-18
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
19-26
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
27-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 16 Rose Lane
2 27(th) June or acceptable alternatives
3 door broken // broken door
4 C
5 no locks (on them) // need locks
6 bathroom light
7 A
8 kitchen curtains
9 B
10 1 (pm) (and) 5 (pm)
Section 2, Questions 11-20
11 B
12 C
13 waterfall(s) // water fall(s) // water-fall(s)
14 eleven/11.00//11 (am)
15 Spotlight (tour)
16–18 walking boots; socks; long trousers (in any order)
19–20 (venomous/poisonous) snakes; (certain) plants (in either order)
Section 3, Questions 21-30
21 B
22 B
23 A
24 C
25 C
26 check (over) (your) work/errors // revise
(work)
27 record
28 (a) friend ACCEPT freind
29 general interest NOT interest
30 dictionary
Section 4, Questions 31-40
31 B
32 A
33 A
34 B
35 C
36 B
37 A
38 C
39 B
40 C

31. B

32. A

33. A

34. B

35. C

36. B

37. A

38. C

39. B

40. C

## A 类阅读

### Academic Reading · source page 74

0-14
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
15-23
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
24-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
ACADEMIC READING
Each question correctly answered scores 1 mark.
Reading Passage 1, Questions 1-13
1 YES
2 NO
3 YES
4 NOT GIVEN
5 NO
6 NOT GIVEN
7 B
8 B
9 C
10 honesty and openness
11 consumers
12 armchair ethicals
13 social record
Reading Passage 2, Questions 14-26
14 D
15 B
16 D
17 C
18 NO
19 YES
If you score...
20 YES
21 NOT GIVEN
22 F
23 C
24 J
25 I
26 C
Reading Passage 3, Questions 27-40
27 Apollo (space) programme
28 (early) next century
29 7,000
30 disease
31 muscular dystrophy
32 cystic fibrosis
33 D
34 C
35 B
36 C
37 D
38 B
39 A
40 A

1. YES

2. NO

3. YES

4. NOT GIVEN

5. NO

6. NOT GIVEN

7. B

8. B

9. C

10. honesty openness / honesty, openness / honesty and openness / honesty & openness / honesty; openness / honesty/openness / honesty,openness / openness honesty / openness, honesty / openness and honesty / openness & honesty / openness; honesty / openness/honesty / openness,honesty

11. consumers

12. armchair ethicals

13. social record

14. D

15. B

16. D

17. C

18. NO

19. YES

20. YES

21. NOT GIVEN

22. F

23. C

24. J

25. I

26. C

27. Apollo programme / Apollo space programme

28. next century / early next century

29. 7,000 / 7000

30. disease

31. muscular dystrophy

32. cystic fibrosis

33. D

34. C

35. B

36. C

37. D

38. B

39. A

40. A

## A 类写作

### Writing material: c2-t4-w-1

Original grouped bar chart and legend inspected at full resolution. The source prompt calls it a table; the displayed figure is a bar chart. Years 1930,1940,1950,1960,1970,1980; vertical axis in thousands of prisoners, not percentages or imprisonment rates. Legend/bar order: Great Britain, Australia, New Zealand, United States, Canada. Approximate visual readings by year: Great Britain 30/30/45/60/80/85 thousand; Australia 70/50/50/70/80/50; New Zealand 100/55/55/75/80/85; United States 100/130/110/120/95/140; Canada 120/110/115/105/85/90. Tolerate sensible rounded readings of unlabelled bar heights. Great Britain rises from the lowest initial level. Canada declines overall with fluctuations. The US fluctuates but ends highest, around 140,000. Australia and New Zealand end below their respective starting figures. The three non-North-American series are around 80,000 in 1970; they are not exact labelled counts. No population denominators or causes of imprisonment are supplied.



### Writing material: c2-t4-w-2

The source presents a causal opinion for evaluation; it is not an established causal fact. Do not require agreement with its gendered premise. A supported disagreement or qualified position is valid.



## 口语

### 原书口语任务 · reference on source page 46

Information for the Examiner:
the level of the book It is valuable for students preparing for
university entrance and for advanced
learners of English.
the title "Writing Academic English" or another
text you know of
the authors by Walton and Hague
the cost around $40/£20
place of purchase Name a suitable bookshop in the town.
extras - cassettes, answers There is no cassette as it is only a writing
book. It does not provide answers, but
the teacher could help with corrections.

[Complete original page](assets/c5b0fb27d4987bf34676b46e1f152223d9d66d030602222252c6881ca8ff2504.jpg)
