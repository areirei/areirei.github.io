# 剑雅 17 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/b08b33ab399219f02458ff72ebbb25c385e628caf7c549878d834f61fd990723.jpg; PDF page 30; full -->

```text
PART 1 Questions 1–10
Questions 1–7
Complete the notes below. Write ONE WORD ONLY for each answer.
Opportunities for voluntary work in Southoe village
Library
• Help with (1) __________ books (times to be arranged)
• Help needed to keep (2) __________ of books up to date
• Library is in the (3) __________ Room in the village hall
Lunch club
• Help by providing (4) __________
• Help with hobbies such as (5) __________
Help for individuals needed next week
• Taking Mrs Carroll to (6) __________
• Work in the (7) __________ at Mr Selsbury’s house
Questions 8–10
Complete the table below. Write ONE WORD ONLY for each answer.
Village social events
| Date | Event | Location | Help needed |
| --- | --- | --- | --- |
| 19 Oct | (8) __________ | Village hall | providing refreshments |
| 18 Nov | dance | Village hall | checking (9) __________ |
| 31 Dec | New Year’s Eve party | Mountfort Hotel | designing the (10) __________ |
```

[Original question page](assets/b08b33ab399219f02458ff72ebbb25c385e628caf7c549878d834f61fd990723.jpg)

### Part 2

<!-- Source: /api/assets/856dc4c03169885411aa3a0355735e65203c5d4b3b45337740cce08888409266.jpg; PDF page 31; full -->

```text
Test 2
PART 2 Questions 11-20
Questions 11-14
Choose the correct letter, A, B or C.




32
Listening test audio
Oniton Hall
11 Many past owners made changes to
A the gardens.
B the house.
C the farm.
12 Sir Edward Downes built Oniton Hall because he wanted
A a place for discussing politics.
B a place to display his wealth.
C a place for artists and writers.
13 Visitors can learn about the work of servants in the past from
A audio guides.
B photographs.
C people in costume.
14 What is new for children at Oniton Hall?
A clothes for dressing up
B mini tractors
C the adventure playground
```

[Original question page](assets/856dc4c03169885411aa3a0355735e65203c5d4b3b45337740cce08888409266.jpg)

<!-- Source: /api/assets/796c5cef69dfb8427396582a4bb09314e34219224750ffe104c564564d499dc3.jpg; PDF page 32; full -->

```text
Questions 15–20
Which activity is offered at each of the following locations on the farm?
Choose SIX answers from the box and write the correct letter, A–H, next to Questions 15–20.
Activities
A shopping
B watching cows being milked
C seeing old farming equipment
D eating and drinking
E starting a trip
F seeing rare breeds of animals
G helping to look after animals
H using farming tools
Locations on the farm
15 dairy __________
16 large barn __________
17 small barn __________
18 stables __________
19 shed __________
20 parkland __________
```

[Original question page](assets/796c5cef69dfb8427396582a4bb09314e34219224750ffe104c564564d499dc3.jpg)

### Part 3

<!-- Source: /api/assets/d58fac249db0eaebc95269d9aec3d253093871dd8cea7b93c44c30f84e9d18b8.jpg; PDF page 33; full -->

```text
PART 3 Questions 21–30
Questions 21 and 22
Choose TWO letters, A–E.
Which TWO things do the students agree they need to include in their reviews of Romeo and Juliet?
A analysis of the text
B a summary of the plot
C a description of the theatre
D a personal reaction
E a reference to particular scenes
Questions 23–27
Which opinion do the speakers give about each of the following aspects of The Emporium’s production of Romeo and Juliet?
Choose FIVE answers from the box and write the correct letter, A–G, next to Questions 23–27.
Opinions
A They both expected this to be more traditional.
B They both thought this was original.
C They agree this created the right atmosphere.
D They agree this was a major strength.
E They were both disappointed by this.
F They disagree about why this was an issue.
G They disagree about how this could be improved.
Aspects of the production
23 the set __________
24 the lighting __________
25 the costume design __________
26 the music __________
27 the actors’ delivery __________
```

[Original question page](assets/d58fac249db0eaebc95269d9aec3d253093871dd8cea7b93c44c30f84e9d18b8.jpg)

<!-- Source: /api/assets/61093318265a637b6b0efad2fc6a5c22fab65a9b828674a0ed05561e2318dec3.jpg; PDF page 34; full -->

```text
Listening
Questions 28-30
Choose the correct letter, A, B or C.



28 The students think the story of Romeo and Juliet is still relevant for young people
today because
A it illustrates how easily conflict can start.
B it deals with problems that families experience.
C it teaches them about relationships.
29 The students found watching Romeo and Juliet in another language
A frustrating.
B demanding.
C moving.
30 Why do the students think Shakespeare’s plays have such international appeal?
A The stories are exciting.
B There are recognisable characters.
C They can be interpreted in many ways.
>|O p. 121 p.103} 35
```

[Original question page](assets/61093318265a637b6b0efad2fc6a5c22fab65a9b828674a0ed05561e2318dec3.jpg)

### Part 4

<!-- Source: /api/assets/8c2066f26854ab8fd14ea02b243a6098a5443cf88fb9eac676b8c4c3f91434e3.jpg; PDF page 35; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
The impact of digital technology on the Icelandic language
The Icelandic language
• has approximately (31) __________ speakers
• has a (32) __________ that is still growing
• has not changed a lot over the last thousand years
• has its own words for computer-based concepts, such as web browser and (33) __________
Young speakers
• are big users of digital technology, such as (34) __________
• are becoming (35) __________ very quickly
• are having discussions using only English while they are in the (36) __________ at school
• are better able to identify the content of a (37) __________ in English than Icelandic
Technology and internet companies
• write very little in Icelandic because of the small number of speakers and because of how complicated its (38) __________ is
The Icelandic government
• has set up a fund to support the production of more digital content in the language
• believes that Icelandic has a secure future
• is worried that young Icelanders may lose their (39) __________ as Icelanders
• is worried about the consequences of children not being (40) __________ in either Icelandic or English
```

[Original question page](assets/8c2066f26854ab8fd14ea02b243a6098a5443cf88fb9eac676b8c4c3f91434e3.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/d478ba00fe0c8dd8622f52204d68215ec72e7a8e338fb6fe81194855b103d6c8.jpg; PDF page 36; full -->

```text
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
The Dead Sea Scrolls
In late 1946 or early 1947, three Bedouin teenagers were tending their goats and sheep
near the ancient settlement of Qumran, located on the northwest shore of the Dead
Sea in what is now known as the West Bank. One of these young shepherds tossed a
rock into an opening on the side of a cliff and was surprised to hear a shattering sound.
He and his companions later entered the cave and stumbled across a collection of
large clay jars, seven of which contained scrolls with writing on them. The teenagers
took the seven scrolls to a nearby town where they were sold for a small sum to a local
antiquities dealer. Word of the find spread, and Bedouins and archaeologists eventually
unearthed tens of thousands of additional scroll fragments from 10 nearby caves;
together they make up between 800 and 900 manuscripts. It soon became clear that this
was one of the greatest archaeological discoveries ever made.
The origin of the Dead Sea Scrolls, which were written around 2,000 years ago between
150 BCE and 70 CE, is still the subject of scholarly debate even today. According to the
prevailing theory, they are the work of a population that inhabited the area until Roman
troops destroyed the settlement around 70 CE. The area was known as Judea at that
time, and the people are thought to have belonged to a group called the Essenes, a
devout Jewish sect.
The majority of the texts on the Dead Sea Scrolls are in Hebrew, with some fragments
written in an ancient version of its alphabet thought to have fallen out of use in the fifth
century BCE. But there are other languages as well. Some scrolls are in Aramaic, the
language spoken by many inhabitants of the region from the sixth century BCE to the
siege of Jerusalem in 70 CE. In addition, several texts feature translations of the Hebrew
Bible into Greek.
The Dead Sea Scrolls include fragments from every book of the Old Testament of the
Bible except for the Book of Esther. The only entire book of the Hebrew Bible preserved
among the manuscripts from Qumran is Isaiah; this copy, dated to the first century BCE,
is considered the earliest biblical manuscript still in existence. Along with biblical texts,
the scrolls include documents about sectarian regulations and religious writings that do
not appear in the Old Testament.
37
```

[Original question page](assets/d478ba00fe0c8dd8622f52204d68215ec72e7a8e338fb6fe81194855b103d6c8.jpg)

<!-- Source: /api/assets/a9eeb1eb60f91d1291e8134bcce532f7b8fd6189803400b21ad07d20616d3ad7.jpg; PDF page 37; full -->

```text
Test 2
The writing on the Dead Sea Scrolls is mostly in black or occasionally red ink, and
the scrolls themselves are nearly all made of either parchment (animal skin) or an
early form of paper called ‘papyrus’. The only exception is the scroll numbered 3Q15,
which was created out of a combination of copper and tin. Known as the Copper
Scroll, this curious document features letters chiselled onto metal — perhaps, as some
have theorized, to better withstand the passage of time. One of the most intriguing
manuscripts from Qumran, this is a sort of ancient treasure map that lists dozens of gold
and silver caches. Using an unconventional vocabulary and odd spelling, it describes 64
underground hiding places that supposedly contain riches buried for safekeeping. None
of these hoards have been recovered, possibly because the Romans pillaged Judea
during the first century CE. According to various hypotheses, the treasure belonged to
local people, or was rescued from the Second Temple before its destruction or never
existed to begin with.
Some of the Dead Sea Scrolls have been on interesting journeys. In 1948, a Syrian
Orthodox archbishop known as Mar Samuel acquired four of the original seven scrolls
from a Jerusalem shoemaker and part-time antiquity dealer, paying less than $100
for them. He then travelled to the United States and unsuccessfully offered them to a
number of universities, including Yale. Finally, in 1954, he placed an advertisement in
the business newspaper The Wall Street Journal — under the category ‘Miscellaneous
Items for Sale’ — that read: ‘Biblical Manuscripts dating back to at least 200 B.C. are for
sale. This would be an ideal gift to an educational or religious institution by an individual
or group.’ Fortunately, Israeli archaeologist and statesman Yigael Yadin negotiated their
purchase and brought the scrolls back to Jerusalem, where they remain to this day.
In 2017, researchers from the University of Haifa restored and deciphered one of the last
untranslated scrolls. The university's Eshbal Ratson and Jonathan Ben-Dov spent one
year reassembling the 60 fragments that make up the scroll. Deciphered from a band
of coded text on parchment, the find provides insight into the community of people who
wrote it and the 364-day calendar they would have used. The scroll names celebrations
that indicate shifts in seasons and details two yearly religious events known from
another Dead Sea Scroll. Only one more known scroll remains untranslated.
38
```

[Original question page](assets/a9eeb1eb60f91d1291e8134bcce532f7b8fd6189803400b21ad07d20616d3ad7.jpg)

<!-- Source: /api/assets/e395689f6820181e414b15295812acf3b0b541a798b5d1e4e96fb97f7a30fb82.jpg; PDF page 38; full -->

```text
Questions 1–5
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–5 on your answer sheet.
The Dead Sea Scrolls
Discovery
Qumran, 1946/7
• three Bedouin shepherds in their teens were near an opening on side of cliff
• heard a noise of breaking when one teenager threw a (1) __________
• teenagers went into the (2) __________ and found a number of containers made of (3) __________
The scrolls
• date from between 150 BCE and 70 CE
• thought to have been written by group of people known as the (4) __________
• written mainly in the (5) __________ language
• most are on religious topics, written using ink on parchment or papyrus
```

[Original question page](assets/e395689f6820181e414b15295812acf3b0b541a798b5d1e4e96fb97f7a30fb82.jpg)

<!-- Source: /api/assets/fa84149ef2166bcb14ab596933ecca7346d8ebb76462e24dad4ced1a5449d1f5.jpg; PDF page 39; full -->

```text
Test 2
Questions 6-13
Do the following statements agree with the information given in Reading Passage 1?
In boxes 6-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
6 The Bedouin teenagers who found the scrolls were disappointed by how little
money they received for them.
7 There is agreement among academics about the origin of the Dead Sea Scrolls.
8 Most of the books of the Bible written on the scrolls are incomplete.
9 The information on the Copper Scroll is written in an unusual way.
10 Mar Samuel was given some of the scrolls as a gift.
11 In the early 1950s, a number of educational establishments in the US were keen to
buy scrolls from Mar Samuel.
12 The scroll that was pieced together in 2017 contains information about annual
occasions in the Qumran area 2,000 years ago.
13 Academics at the University of Haifa are currently researching how to decipher the
final scroll.
40 >|Q p. 122
```

[Original question page](assets/fa84149ef2166bcb14ab596933ecca7346d8ebb76462e24dad4ced1a5449d1f5.jpg)

<!-- Source: /api/assets/f75f2f22f0f221bd143c8ab7a8bb5b7b18f9f8eb1297cf51da8ef16206fa9f65.jpg; PDF page 40; full -->

```text
Reading
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
A second attempt at domesticating the tomato
A It took at least 3,000 years for humans to learn how to domesticate the wild tomato
and cultivate it for food. Now two separate teams in Brazil and China have done it all
over again in less than three years. And they have done it better in some ways, as
the re-domesticated tomatoes are more nutritious than the ones we eat at present.
This approach relies on the revolutionary CRISPR genome editing technique, in
which changes are deliberately made to the DNA of a living cell, allowing genetic
material to be added, removed or altered. The technique could not only improve
existing crops, but could also be used to turn thousands of wild plants into useful
and appealing foods. In fact, a third team in the US has already begun to do this
with a relative of the tomato called the groundcherry.
This fast-track domestication could help make the world’s food supply healthier and
far more resistant to diseases, such as the rust fungus devastating wheat crops.
‘This could transform what we eat,’ says Jorg Kudla at the University of Munster in
Germany, a member of the Brazilian team. ‘There are 50,000 edible plants in the
world, but 90 percent of our energy comes from just 15 crops.’
‘We can now mimic the known domestication course of major crops like rice, maize,
sorghum or others,’ says Caixia Gao of the Chinese Academy of Sciences in Beijing.
‘Then we might try to domesticate plants that have never been domesticated.’
B Wild tomatoes, which are native to the Andes region in South America, produce
pea-sized fruits. Over many generations, peoples such as the Aztecs and Incas
transformed the plant by selecting and breeding plants with mutations* in their
genetic structure, which resulted in desirable traits such as larger fruit.
But every time a single plant with a mutation is taken from a larger population for
breeding, much genetic diversity is lost. And sometimes the desirable mutations
come with less desirable traits. For instance, the tomato strains grown for
supermarkets have lost much of their flavour.
By comparing the genomes of modern plants to those of their wild relatives,
biologists have been working out what genetic changes occurred as plants were
domesticated. The teams in Brazil and China have now used this knowledge to
reintroduce these changes from scratch while maintaining or even enhancing the
desirable traits of wild strains.
* mutations: changes in an organism's genetic structure that can be passed down to later generations
41
```

[Original question page](assets/f75f2f22f0f221bd143c8ab7a8bb5b7b18f9f8eb1297cf51da8ef16206fa9f65.jpg)

<!-- Source: /api/assets/401e21e744e9ef42fe4aefbb6523b3948637ff9ee283f45ee4f10c8e2ac00dbc.jpg; PDF page 41; full -->

```text
Test 2

42
C Kudla’s team made six changes altogether. For instance, they tripled the size
of fruit by editing a gene called FRUIT WEIGHT, and increased the number of
tomatoes per truss by editing another called MULTIFLORA.
While the historical domestication of tomatoes reduced levels of the red pigment
lycopene — thought to have potential health benefits — the team in Brazil managed
to boost it instead. The wild tomato has twice as much lycopene as cultivated ones;
the newly domesticated one has five times as much.
‘They are quite tasty,’ says Kudla. ‘A little bit strong. And very aromatic.’
The team in China re-domesticated several strains of wild tomatoes with desirable
traits lost in domesticated tomatoes. In this way they managed to create a strain
resistant to a common disease called bacterial spot race, which can devastate
yields. They also created another strain that is more salt tolerant — and has higher
levels of vitamin C.
D Meanwhile, Joyce Van Eck at the Boyce Thompson Institute in New York state
decided to use the same approach to domesticate the groundcherry or goldenberry
(Physalis pruinosa) for the first time. This fruit looks similar to the closely related
Cape gooseberry (Physalis peruviana).
Groundcherries are already sold to a limited extent in the US but they are hard to
produce because the plant has a sprawling growth habit and the small fruits fall
off the branches when ripe. Van Eck’s team has edited the plants to increase fruit
size, make their growth more compact and to stop fruits dropping. ‘There’s potential
for this to be a commercial crop,’ says Van Eck. But she adds that taking the
work further would be expensive because of the need to pay for a licence for the
CRISPR technology and get regulatory approval.
E This approach could boost the use of many obscure plants, says Jonathan Jones
of the Sainsbury Lab in the UK. But it will be hard for new foods to grow so popular
with farmers and consumers that they become new staple crops, he thinks.
The three teams already have their eye on other plants that could be ‘catapulted
into the mainstream’, including foxtail, oat-grass and cowpea. By choosing wild
plants that are drought or heat tolerant, says Gao, we could create crops that will
thrive even as the planet warms.
But Kudla didn’t want to reveal which species were in his team’s sights, because
CRISPR has made the process so easy. ‘Any one with the right skills could go to
their lab and do this.’
```

[Original question page](assets/401e21e744e9ef42fe4aefbb6523b3948637ff9ee283f45ee4f10c8e2ac00dbc.jpg)

<!-- Source: /api/assets/d43f25e553eb0adb34ec9afa02909edfb483ae45d09c92c9d1ffb8c59424bb0c.jpg; PDF page 42; full -->

```text
Reading
Questions 14-18
Reading Passage 2 has five sections, A-E.
Which section contains the following information?
Write the correct letter, A-E, in boxes 14-18 on your answer sheet.
NB You may use any letter more than once.
14 a reference to a type of tomato that can resist a dangerous infection
15 an explanation of how problems can arise from focusing only on a certain type of
tomato plant.
16 a number of examples of plants that are not cultivated at present but could be
useful as food sources
17 a comparison between the early domestication of the tomato and more recent research
18 a personal reaction to the flavour of a tomato that has been genetically edited
Questions 19-23
Look at the following statements (Questions 19-23) and the list of researchers below.
Match each statement with the correct researcher, A—D.
Write the correct letter, A-D, in boxes 19-23 on your answer sheet.
NB You may use any letter more than once.
19 Domestication of certain plants could allow them to adapt to future environmental
challenges.
20 The idea of growing and eating unusual plants may not be accepted on a large scale.
21 It is not advisable for the future direction of certain research to be made public.
22 Present efforts to domesticate one wild fruit are limited by the costs involved.
23 Humans only make use of a small proportion of the plant food available on Earth.
List of Researchers
A Jorg Kudla
B Caixia Gao
C Joyce Van Eck
D Jonathan Jones
```

[Original question page](assets/d43f25e553eb0adb34ec9afa02909edfb483ae45d09c92c9d1ffb8c59424bb0c.jpg)

<!-- Source: /api/assets/8d1752287231683ffc599fc3984cf6c11207e3c5928d6e64110598f95709a7aa.jpg; PDF page 43; full -->

```text
Questions 24–26
Complete the sentences below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 24–26 on your answer sheet.
24 An undesirable trait such as loss of __________ may be caused by a mutation in a tomato gene.
25 By modifying one gene in a tomato plant, researchers made the tomato three times its original __________.
26 A type of tomato which was not badly affected by __________, and was rich in vitamin C, was produced by a team of researchers in China.
```

[Original question page](assets/8d1752287231683ffc599fc3984cf6c11207e3c5928d6e64110598f95709a7aa.jpg)

<!-- Source: /api/assets/86c4e0eb6bc30fff8f1200c6a23a54eb28d6f37e441361e2440f1e44a289f96d.jpg; PDF page 44; full -->

```text
Reading
READING PASSAGE 3
You should spend about 20 minutes on Questions 27—40, which are based on Reading
Passage 3 below.
Insight or evolution?
Two scientists consider the origins of discoveries and other innovative behavior
Scientific discovery is popularly believed to result from the sheer genius of such intellectual
stars as naturalist Charles Darwin and theoretical physicist Albert Einstein. Our view of such
unique contributions to science often disregards the person’s prior experience and the efforts of
their lesser-known predecessors. Conventional wisdom also places great weight on insight in
promoting breakthrough scientific achievements, as if ideas spontaneously pop into someone’s
head — fully formed and functional.
There may be some limited truth to this view. However, we believe that it largely misrepresents
the real nature of scientific discovery, as well as that of creativity and innovation in many other
realms of human endeavor.
Setting aside such greats as Darwin and Einstein — whose monumental contributions are duly
celebrated — we suggest that innovation is more a process of trial and error, where two steps
forward may sometimes come with one step back, as well as one or more steps to the right or
left. This evolutionary view of human innovation undermines the notion of creative genius and
recognizes the cumulative nature of scientific progress.
Consider one unheralded scientist: John Nicholson, a mathematical physicist working in the
1910s who postulated the existence of ‘proto-elements’ in outer space. By combining different
numbers of weights of these proto-elements’ atoms, Nicholson could recover the weights of all
the elements in the then-known periodic table. These successes are all the more noteworthy given
the fact that Nicholson was wrong about the presence of proto-elements: they do not actually
exist. Yet, amid his often fanciful theories and wild speculations, Nicholson also proposed a novel
theory about the structure of atoms. Niels Bohr, the Nobel prize-winning father of modern atomic
theory, jumped off from this interesting idea to conceive his now-famous model of the atom.
What are we to make of this story? One might simply conclude that science is a collective and
cumulative enterprise. That may be true, but there may be a deeper insight to be gleaned. We
propose that science is constantly evolving, much as species of animals do. In biological systems,
organisms may display new characteristics that result from random genetic mutations. In the same
way, random, arbitrary or accidental mutations of ideas may help pave the way for advances in
science. If mutations prove beneficial, then the animal or the scientific theory will continue to
thrive and perhaps reproduce.
45
```

[Original question page](assets/86c4e0eb6bc30fff8f1200c6a23a54eb28d6f37e441361e2440f1e44a289f96d.jpg)

<!-- Source: /api/assets/a177ce3ba047738c6904b6bc7df6fe2e2da373e7841feb9b4d9930ecb2bcf438.jpg; PDF page 45; full -->

```text
Test 2
Support for this evolutionary view of behavioral innovation comes from many domains. Consider
one example of an influential innovation in US horseracing. The so-called ‘acey-deucy’ stirrup
placement, in which the rider’s foot in his left stirrup is placed as much as 25 centimeters lower
than the right, is believed to confer important speed advantages when turning on oval tracks. It
was developed by a relatively unknown jockey named Jackie Westrope. Had Westrope conducted
methodical investigations or examined extensive film records in a shrewd plan to outrun his
rivals? Had he foreseen the speed advantage that would be conferred by riding acey-deucy? No.
He suffered a leg injury, which left him unable to fully bend his left knee. His modification just
happened to coincide with enhanced left-hand turning performance. This led to the rapid and
widespread adoption of riding acey-deucy by many riders, a racing style which continues in
today’s thoroughbred racing.
Plenty of other stories show that fresh advances can arise from error, misadventure, and also
pure serendipity — a happy accident. For example, in the early 1970s, two employees of the
company 3M each had a problem: Spencer Silver had a product — a glue which was only slightly
sticky — and no use for it, while his colleague Art Fry was trying to figure out how to affix
temporary bookmarks in his hymn book without damaging its pages. The solution to both these
problems was the invention of the brilliantly simple yet phenomenally successful Post-It note.
Such examples give lie to the claim that ingenious, designing minds are responsible for human
creativity and invention. Far more banal and mechanical forces may be at work; forces that are
fundamentally connected to the laws of science.
The notions of insight, creativity and genius are often invoked, but they remain vague and of
doubtful scientific utility, especially when one considers the diverse and enduring contributions of
individuals such as Plato, Leonardo da Vinci, Shakespeare, Beethoven, Galileo, Newton, Kepler,
Curie, Pasteur and Edison. These notions merely label rather than explain the evolution of human
innovations. We need another approach, and there is a promising candidate.
The Law of Effect was advanced by psychologist Edward Thorndike in 1898, some 40 years
after Charles Darwin published his groundbreaking work on biological evolution, On the Origin
of Species. This simple law holds that organisms tend to repeat successful behaviors and to
refrain from performing unsuccessful ones. Just like Darwin’s Law of Natural Selection, the Law
of Effect involves an entirely mechanical process of variation and selection, without any end
objective in sight.
Of course, the origin of human innovation demands much further study. In particular, the
provenance of the raw material on which the Law of Effect operates is not as clearly known as
that of the genetic mutations on which the Law of Natural Selection operates. The generation of
novel ideas and behaviors may not be entirely random, but constrained by prior successes and
failures — of the current individual (such as Bohr) or of predecessors (such as Nicholson).
The time seems right for abandoning the naive notions of intelligent design and genius, and for
scientifically exploring the true origins of creative behavior.
46
```

[Original question page](assets/a177ce3ba047738c6904b6bc7df6fe2e2da373e7841feb9b4d9930ecb2bcf438.jpg)

<!-- Source: /api/assets/463265266ed6ae951da1f19521232a0f1b26f44f1b9f40e69a4b62b701e31a73.jpg; PDF page 46; full -->

```text
Reading
Questions 27-31
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-31 on your answer sheet.





27 The purpose of the first paragraph is to
A defend particular ideas.
B compare certain beliefs.
C disprove a widely held view.
D outline a common assumption.
28 What are the writers doing in the second paragraph?
A criticising an opinion
B justifying a standpoint
C explaining an approach
D supporting an argument
29 In the third paragraph, what do the writers suggest about Darwin and Einstein?
A They represent an exception to a general rule.
B Their way of working has been misunderstood.
C They are an ideal which others should aspire to.
D Their achievements deserve greater recognition.
30 John Nicholson is an example of a person whose idea
A established his reputation as an influential scientist.
B was only fully understood at a later point in history.
C laid the foundations for someone else’s breakthrough.
D initially met with scepticism from the scientific community.
31 What is the key point of interest about the ‘acey-deucy’ stirrup placement?
A the simple reason why it was invented
B the enthusiasm with which it was adopted
C the research that went into its development
D the cleverness of the person who first used it
47
```

[Original question page](assets/463265266ed6ae951da1f19521232a0f1b26f44f1b9f40e69a4b62b701e31a73.jpg)

<!-- Source: /api/assets/403ef6ab306a71f56ae5524cdcfc0d6d7d7b9532d7fc1b774718092820754864.jpg; PDF page 47; full -->

```text
Test 2
Questions 32-36
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 32-36 on your answer sheet, write





48
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
32 Acknowledging people such as Plato or da Vinci as geniuses will help us
understand the process by which great minds create new ideas.
33 The Law of Effect was discovered at a time when psychologists were seeking a
scientific reason why creativity occurs.
34 The Law of Effect states that no planning is involved in the behaviour of organisms.
35 The Law of Effect sets out clear explanations about the sources of new ideas and
behaviours.
36 Many scientists are now turning away from the notion of intelligent design
and genius.
```

[Original question page](assets/403ef6ab306a71f56ae5524cdcfc0d6d7d7b9532d7fc1b774718092820754864.jpg)

<!-- Source: /api/assets/977bcef95dc6617e220db70502a45ecc3354360d5a08a9f7aeb1de9cf5099aed.jpg; PDF page 48; full -->

```text
Questions 37–40
Complete the summary using the list of words, A–G, below.
Write the correct letter, A–G, in boxes 37–40 on your answer sheet.
The origins of creative behaviour
The traditional view of scientific discovery is that breakthroughs happen when a single great mind has sudden (37) __________. Although this can occur, it is not often the case. Advances are more likely to be the result of a longer process.
In some cases, this process involves (38) __________, such as Nicholson’s theory about proto-elements. In others, simple necessity may provoke innovation, as with Westrope’s decision to modify the position of his riding stirrups. There is also often an element of (39) __________, for example, the coincidence of ideas that led to the invention of the Post-It note. With both the Law of Natural Selection and the Law of Effect, there may be no clear (40) __________ involved, but merely a process of variation and selection.
A invention
B goals
C compromise
D mistakes
E luck
F inspiration
G experiments
```

[Original question page](assets/977bcef95dc6617e220db70502a45ecc3354360d5a08a9f7aeb1de9cf5099aed.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/30886f15e889111dc276ef09b9ffcd3133a411ecd8386cdfe42a4cd0debc7df9.jpg; PDF page 49; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The table and charts below give information on the police budget for 2017 and 2018 in one area of Britain. The table shows where the money came from and the charts how it was distributed.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/30886f15e889111dc276ef09b9ffcd3133a411ecd8386cdfe42a4cd0debc7df9.jpg)

![Original figure](assets/30886f15e889111dc276ef09b9ffcd3133a411ecd8386cdfe42a4cd0debc7df9.jpg)

### Task 2

<!-- Source: /api/assets/6569005ea2c06ea55a50665ac6e246ed63e2d5296fff35226eddcb363af167f0.jpg; PDF page 50; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some children spend hours every day on their smartphones.

Why is this the case? Do you think this is a positive or a negative development?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/6569005ea2c06ea55a50665ac6e246ed63e2d5296fff35226eddcb363af167f0.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/c51a22aa8b8fd6e824a32868e4c3f40eea367856675b44a0d82049536f698b9f.jpg; PDF page 51; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Reading
Did you have a favourite book when you were a child? [Why/Why not?]
How much reading do you do for your work/studies? [Why/Why not?]
What kinds of books do you read for pleasure? [Why/Why not?]
Do you prefer to read a newspaper or a magazine online, or to buy a copy? [Why?]
PART 2
Describe a big city you would like to visit.
You should say:
which big city you would like to visit
how you would travel there
what you would do there
and explain why you would like to visit this big city.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Visiting cities on holiday
Example questions:
What are the most interesting things to do while visiting cities on holiday?
Why can it be expensive to visit cities on holiday?
Do you think it is better to visit cities alone or in a group with friends?
The growth of cities
Example questions:
Why have cities increased in size in recent years?
What are the challenges created by ever-growing cities?
In what ways do you think cities of the future will be different to cities today?
52
```

[Original question page](assets/c51a22aa8b8fd6e824a32868e4c3f40eea367856675b44a0d82049536f698b9f.jpg)

### Part 2

<!-- Source: /api/assets/c51a22aa8b8fd6e824a32868e4c3f40eea367856675b44a0d82049536f698b9f.jpg; PDF page 51; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Reading
Did you have a favourite book when you were a child? [Why/Why not?]
How much reading do you do for your work/studies? [Why/Why not?]
What kinds of books do you read for pleasure? [Why/Why not?]
Do you prefer to read a newspaper or a magazine online, or to buy a copy? [Why?]
PART 2
Describe a big city you would like to visit.
You should say:
which big city you would like to visit
how you would travel there
what you would do there
and explain why you would like to visit this big city.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Visiting cities on holiday
Example questions:
What are the most interesting things to do while visiting cities on holiday?
Why can it be expensive to visit cities on holiday?
Do you think it is better to visit cities alone or in a group with friends?
The growth of cities
Example questions:
Why have cities increased in size in recent years?
What are the challenges created by ever-growing cities?
In what ways do you think cities of the future will be different to cities today?
52
```

[Original question page](assets/c51a22aa8b8fd6e824a32868e4c3f40eea367856675b44a0d82049536f698b9f.jpg)

### Part 3

<!-- Source: /api/assets/c51a22aa8b8fd6e824a32868e4c3f40eea367856675b44a0d82049536f698b9f.jpg; PDF page 51; full -->

```text
Test 2
SPEAKING
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Reading
Did you have a favourite book when you were a child? [Why/Why not?]
How much reading do you do for your work/studies? [Why/Why not?]
What kinds of books do you read for pleasure? [Why/Why not?]
Do you prefer to read a newspaper or a magazine online, or to buy a copy? [Why?]
PART 2
Describe a big city you would like to visit.
You should say:
which big city you would like to visit
how you would travel there
what you would do there
and explain why you would like to visit this big city.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Visiting cities on holiday
Example questions:
What are the most interesting things to do while visiting cities on holiday?
Why can it be expensive to visit cities on holiday?
Do you think it is better to visit cities alone or in a group with friends?
The growth of cities
Example questions:
Why have cities increased in size in recent years?
What are the challenges created by ever-growing cities?
In what ways do you think cities of the future will be different to cities today?
52
```

[Original question page](assets/c51a22aa8b8fd6e824a32868e4c3f40eea367856675b44a0d82049536f698b9f.jpg)
