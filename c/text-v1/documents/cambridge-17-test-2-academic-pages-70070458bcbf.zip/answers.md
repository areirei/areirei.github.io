# 剑雅 17 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 120

TEST 2 LISTENING
1 collecting
2 records
3 West
4 transport
5 art
6 hospital
7 garden
8 quiz
9 tickets
10 poster
11 B
12 C
13 C
14 B
15 D
16 C
17 G
18 A
19 E
20 F
21 D
22 E
23 D
24 C
25 A
26 E
27 F
28 B
29 C
30 C
31 321,000
32 vocabulary
33 podcast
34 smartphones
35 bilingual
36 playground
37 picture
38 grammar
39 identity
40 fluent
21&22 IN EITHER ORDER: D,E
If you score: 1–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. collecting

2. records

3. West

4. transport

5. art

6. hospital

7. garden

8. quiz

9. tickets

10. poster

### Part 2 · source page 120

TEST 2 LISTENING
1 collecting
2 records
3 West
4 transport
5 art
6 hospital
7 garden
8 quiz
9 tickets
10 poster
11 B
12 C
13 C
14 B
15 D
16 C
17 G
18 A
19 E
20 F
21 D
22 E
23 D
24 C
25 A
26 E
27 F
28 B
29 C
30 C
31 321,000
32 vocabulary
33 podcast
34 smartphones
35 bilingual
36 playground
37 picture
38 grammar
39 identity
40 fluent
21&22 IN EITHER ORDER: D,E
If you score: 1–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B

12. C

13. C

14. B

15. D

16. C

17. G

18. A

19. E

20. F

### Part 3 · source page 120

TEST 2 LISTENING
1 collecting
2 records
3 West
4 transport
5 art
6 hospital
7 garden
8 quiz
9 tickets
10 poster
11 B
12 C
13 C
14 B
15 D
16 C
17 G
18 A
19 E
20 F
21 D
22 E
23 D
24 C
25 A
26 E
27 F
28 B
29 C
30 C
31 321,000
32 vocabulary
33 podcast
34 smartphones
35 bilingual
36 playground
37 picture
38 grammar
39 identity
40 fluent
21&22 IN EITHER ORDER: D,E
If you score: 1–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. D / E

22. D / E

23. D

24. C

25. A

26. E

27. F

28. B

29. C

30. C

### Part 4 · source page 120

TEST 2 LISTENING
1 collecting
2 records
3 West
4 transport
5 art
6 hospital
7 garden
8 quiz
9 tickets
10 poster
11 B
12 C
13 C
14 B
15 D
16 C
17 G
18 A
19 E
20 F
21 D
22 E
23 D
24 C
25 A
26 E
27 F
28 B
29 C
30 C
31 321,000
32 vocabulary
33 podcast
34 smartphones
35 bilingual
36 playground
37 picture
38 grammar
39 identity
40 fluent
21&22 IN EITHER ORDER: D,E
If you score: 1–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. 321,000 / 321000

32. vocabulary

33. podcast

34. smartphones

35. bilingual

36. playground

37. picture

38. grammar

39. identity

40. fluent

## A 类阅读

### Academic Reading · source page 121

TEST 2 READING
1 rock
2 cave
3 clay
4 Essenes
5 Hebrew
6 NOT GIVEN
7 FALSE
8 TRUE
9 TRUE
10 FALSE
11 FALSE
12 TRUE
13 NOT GIVEN
14 C
15 B
16 E
17 A
18 C
19 B
20 D
21 A
22 C
23 A
24 flavour / flavor
25 size
26 salt
27 D
28 A
29 A
30 C
31 A
32 NO
33 NOT GIVEN
34 YES
35 NO
36 NOT GIVEN
37 F
38 D
39 E
40 B
If you score: 1–18 unlikely;19–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. rock

2. cave

3. clay

4. Essenes

5. Hebrew

6. NOT GIVEN

7. FALSE

8. TRUE

9. TRUE

10. FALSE

11. FALSE

12. TRUE

13. NOT GIVEN

14. C

15. B

16. E

17. A

18. C

19. B

20. D

21. A

22. C

23. A

24. flavour / flavor

25. size

26. salt

27. D

28. A

29. A

30. C

31. A

32. NO

33. NOT GIVEN

34. YES

35. NO

36. NOT GIVEN

37. F

38. D

39. E

40. B

## A 类写作

### Writing material: c17-t2-w-1

One area of Britain; budget in £MILLIONS,2017→2018: national government175.5→177.8; local taxes91.2→102.3; other sources(eg grants)38.0→38.5; total304.7→318.6. Spending percentages salaries(officers/staff)75→69%; technology8→14%; buildings/transport17→17%. National government largest source; local taxes largest increase. Salary share falls, technology rises, buildings/transport share unchanged. Because total changes, unchanged17%does not mean unchanged cash amount. Do not equate percentage-point change with proportional percent change or treat this as all Britain.



### Writing material: c17-t2-w-2

Explain why some children use smartphones for hours daily and evaluate the development. Both causes and judgement required; avoid assuming all children behave identically.



## 口语
