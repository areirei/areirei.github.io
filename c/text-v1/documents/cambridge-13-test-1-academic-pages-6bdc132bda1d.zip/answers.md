# 剑雅 13 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 119

TEST 1 LISTENING
1 choose
2 private
3 20 / twenty percent
4 healthy
5 bones
6 lecture
7 Arretsa
8 vegetarian
9 market
10 knife
11 B
12 C
13 B
14 E
15 D
16 B
17 G
18 C
19 H
20 I
21 A
22 C
23 B
24 C
25 B
26 G
27 C
28 H
29 A
30 E
31 crow
32 cliffs
33 speed
34 brain(s)
35 food
36 behaviour(s) / behavior(s)
37 new
38 stress
39 tail(s)
40 permanent
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. choose

2. private

3. 20 percent / 20% / twenty percent

4. healthy

5. bones

6. lecture

7. Arretsa

8. vegetarian

9. market

10. knife

### Part 2 · source page 119

TEST 1 LISTENING
1 choose
2 private
3 20 / twenty percent
4 healthy
5 bones
6 lecture
7 Arretsa
8 vegetarian
9 market
10 knife
11 B
12 C
13 B
14 E
15 D
16 B
17 G
18 C
19 H
20 I
21 A
22 C
23 B
24 C
25 B
26 G
27 C
28 H
29 A
30 E
31 crow
32 cliffs
33 speed
34 brain(s)
35 food
36 behaviour(s) / behavior(s)
37 new
38 stress
39 tail(s)
40 permanent
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B

12. C

13. B

14. E

15. D

16. B

17. G

18. C

19. H

20. I

### Part 3 · source page 119

TEST 1 LISTENING
1 choose
2 private
3 20 / twenty percent
4 healthy
5 bones
6 lecture
7 Arretsa
8 vegetarian
9 market
10 knife
11 B
12 C
13 B
14 E
15 D
16 B
17 G
18 C
19 H
20 I
21 A
22 C
23 B
24 C
25 B
26 G
27 C
28 H
29 A
30 E
31 crow
32 cliffs
33 speed
34 brain(s)
35 food
36 behaviour(s) / behavior(s)
37 new
38 stress
39 tail(s)
40 permanent
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. A

22. C

23. B

24. C

25. B

26. G

27. C

28. H

29. A

30. E

### Part 4 · source page 119

TEST 1 LISTENING
1 choose
2 private
3 20 / twenty percent
4 healthy
5 bones
6 lecture
7 Arretsa
8 vegetarian
9 market
10 knife
11 B
12 C
13 B
14 E
15 D
16 B
17 G
18 C
19 H
20 I
21 A
22 C
23 B
24 C
25 B
26 G
27 C
28 H
29 A
30 E
31 crow
32 cliffs
33 speed
34 brain(s)
35 food
36 behaviour(s) / behavior(s)
37 new
38 stress
39 tail(s)
40 permanent
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. crow

32. cliffs

33. speed

34. brain / brains

35. food

36. behaviour / behaviours / behavior / behaviors

37. new

38. stress

39. tail / tails

40. permanent

## A 类阅读

### Academic Reading · source page 120

TEST 1 READING
1 update
2 environment
3 captain
4 films
5 season
6 accommodation
7 blog
8 FALSE
9 NOT GIVEN
10 FALSE
11 TRUE
12 NOT GIVEN
13 TRUE
14 iv
15 vi
16 i
17 v
18 viii
19 iii
20 E
21 B
22 D
23 A
24 focus
25 pleasure
26 curiosity
27 B
28 C
29 C
30 D
31 A
32 D
33 A
34 E
35 C
36 G
37 B
38 YES
39 NOT GIVEN
40 NO
If you score: 0–16 unlikely;17–25 may;26–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. update

2. environment

3. captain

4. films

5. season

6. accommodation

7. blog

8. FALSE

9. NOT GIVEN

10. FALSE

11. TRUE

12. NOT GIVEN

13. TRUE

14. iv

15. vi

16. i

17. v

18. viii

19. iii

20. E

21. B

22. D

23. A

24. focus

25. pleasure

26. curiosity

27. B

28. C

29. C

30. D

31. A

32. D

33. A

34. E

35. C

36. G

37. B

38. YES

39. NOT GIVEN

40. NO

## A 类写作

### Writing material: c13-t1-w-1

North up. Hospital within Ring Road; Hospital Road runs south to east–west City Road.2007: six bus stops along Hospital Road; combined staff/public car park east of Hospital Road.2010: stops replaced by bus station west of Hospital Road, linked to two new roundabouts at its junctions with Ring Road and City Road. Existing eastern car park becomes staff only; new public car park east of hospital with access from Ring Road. Hospital and surrounding Ring Road remain. Do not relocate hospital, claim bus station east, or give new public parking direct access from City Road.



### Writing material: c13-t1-w-2

Evaluate social and practical problems of living where a foreign language is required. Both categories belong to the claim; no predetermined stance or need to assert every migrant has identical problems.



## 口语
