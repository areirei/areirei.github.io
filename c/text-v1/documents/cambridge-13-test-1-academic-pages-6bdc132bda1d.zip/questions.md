# 剑雅 13 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/e2527a7b80b03317a851963b27c7db6f3fa67b3095bedcf8c81ca4e2cc07f5e5.jpg; PDF page 11; full -->

```text
LISTENING
SECTION 1 Questions 1–10
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
COOKERY CLASSES
| Cookery Class | Focus | Other Information |
| --- | --- | --- |
| Example: The Food Studio | how to (1) __________ and cook with seasonal products | small classes; also offers (2) __________ classes; clients who return get a (3) __________ discount |
| Bond’s Cookery School | food that is (4) __________ | includes recipes to strengthen your (5) __________; they have a free (6) __________ every Thursday |
| The (7) __________ Centre | mainly (8) __________ food | located near the (9) __________; a special course in skills with a (10) __________ is sometimes available |
```

[Original question page](assets/e2527a7b80b03317a851963b27c7db6f3fa67b3095bedcf8c81ca4e2cc07f5e5.jpg)

### Part 2

<!-- Source: /api/assets/bd291798e0e3cd1971333f7c1860aaa811d77cf536bd2c3ea2865d86cd391fb7.jpg; PDF page 12; full -->

```text
SECTION 2 Questions 11–20
Listening
Questions 11-13
Choose the correct letter, A, B or C.
Traffic Changes in Granford
11 Why are changes needed to traffic systems in Granford?
A The number of traffic accidents has risen.
B The amount of traffic on the roads has increased.
C The types of vehicles on the roads have changed.
12 In a survey, local residents particularly complained about
A dangerous driving by parents.
B pollution from trucks and lorries.
C inconvenience from parked cars.
13 According to the speaker, one problem with the new regulations will be
A raising money to pay for them.
B finding a way to make people follow them.
C getting the support of the police.

11
```

[Original question page](assets/bd291798e0e3cd1971333f7c1860aaa811d77cf536bd2c3ea2865d86cd391fb7.jpg)

<!-- Source: /api/assets/8995770196b8b6affa001625582d705e699435424fa23e6529e03b15ea1edc43.jpg; PDF page 13; full -->

```text
Questions 14–20
Label the map below. Write the correct letter, A–I, next to Questions 14–20.
Proposed traffic changes in Granford
[Original map retained with locations A–I, compass, Station Road, High Street, School Road, Bank, Library, Chemist, School and two Supermarkets.]
14 New traffic lights __________
15 Pedestrian crossing __________
16 Parking allowed __________
17 New ‘No Parking’ sign __________
18 New disabled parking spaces __________
19 Widened pavement __________
20 Lorry loading/unloading restrictions __________
```

[Original question page](assets/8995770196b8b6affa001625582d705e699435424fa23e6529e03b15ea1edc43.jpg)

![Original figure](assets/8995770196b8b6affa001625582d705e699435424fa23e6529e03b15ea1edc43.jpg)

### Part 3

<!-- Source: /api/assets/49f2a86bad37b963011f37343fff94f1b9f5e60513c24fec21923997dd2a6bc0.jpg; PDF page 14; full -->

```text
SECTION 3 Questions 21–30
Listening
Questions 21-25
Choose the correct letter, A, B or C.
21 Why is Jack interested in investigating seed germination?
A He may do a module on a related topic later on.
B He wants to have a career in plant science.
C He is thinking of choosing this topic for his dissertation.
22 Jack and Emma agree the main advantage of their present experiment is that it
can be
A described very easily.
B carried out inside the laboratory.
C completed in the time available.
23 What do they decide to check with their tutor?
A whether their aim is appropriate
B whether anyone else has chosen this topic
C whether the assignment contributes to their final grade
24 They agree that Graves' book on seed germination is disappointing because
A it fails to cover recent advances in seed science.
B the content is irrelevant for them.
C its focus is very theoretical.
25 What does Jack say about the article on seed germination by Lee Hall?
A The diagrams of plant development are useful.
B The analysis of seed germination statistics is thorough.
C The findings on seed germination after fires are surprising.

13
```

[Original question page](assets/49f2a86bad37b963011f37343fff94f1b9f5e60513c24fec21923997dd2a6bc0.jpg)

<!-- Source: /api/assets/745351f3dbe3f9cfefa0ecde5f469ffd41d1f62f2fa6764d73bdfbb305125ecb.jpg; PDF page 15; full -->

```text
Questions 26–30
Complete the flow-chart below.
Choose FIVE answers from the box and write the correct letter, A–H, next to Questions 26–30.
A container
B soil
C weight
D condition
E height
F colour
G types
H depths
Stages in the experiment
Select seeds of different (26) __________ and sizes.
↓
Measure and record the (27) __________ and size of each one.
↓
Decide on the (28) __________ to be used.
↓
Use a different (29) __________ for each seed and label it.
↓
After about 3 weeks, record the plant’s (30) __________.
↓
Investigate the findings.
```

[Original question page](assets/745351f3dbe3f9cfefa0ecde5f469ffd41d1f62f2fa6764d73bdfbb305125ecb.jpg)

### Part 4

<!-- Source: /api/assets/d4ee091ccb842814feaba685c0c357258d35a9eed02831ffaeab9006f3f46269.jpg; PDF page 16; full -->

```text
SECTION 4 Questions 31–40
Listening
Complete the notes below.
Write ONE WORD ONLY for each answer.
Effects of urban environments on animals
Introduction
Recent urban developments represent massive environmental changes. It was
previously thought that only a few animals were suitable for city life, e.g.
• the 31....................— because of its general adaptability
• the pigeon - because walls of city buildings are similar to 32....................
In fact, many urban animals are adapting with unusual 33......................
Recent research
• Emilie Snell-Rood studied small urbanised mammal specimens from museums
in Minnesota.
-She found the size of their 34....................had increased.
-She suggests this may be due to the need to locate new sources
of 35....................and to deal with new dangers.
• Catarina Miranda focused on the 36....................of urban and rural
blackbirds.
-She found urban birds were often braver, but were afraid of situations that
were 37......................
• Jonathan Atwell studies how animals respond to urban environments.
- He found that some animals respond to 38....................by producing
lower levels of hormones.
• Sarah Partan's team found urban squirrels use their 39....................to
help them communicate.
Long-term possibilities
Species of animals may develop which are unique to cities. However, some changes
may not be 40......................

15
```

[Original question page](assets/d4ee091ccb842814feaba685c0c357258d35a9eed02831ffaeab9006f3f46269.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/7d299251be04ec31fa0fb1c6365ab3042f550c0d7491d387ba0d2c69343ab565.jpg; PDF page 17; full -->

```text
Test 1
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1—13, which are based on Reading
Passage 1 below.
Case Study: Tourism New Zealand website
New Zealand is a small country of four million inhabitants, a long-haul flight from all the
major tourist-generating markets of the world. Tourism currently makes up 9% of the
country's gross domestic product, and is the country’s largest export sector. Unlike other
export sectors, which make products and then sell them overseas, tourism brings its
customers to New Zealand. The product is the country itself - the people, the places and
the experiences. In 1999, Tourism New Zealand launched a campaign to communicate
a new brand position to the world. The campaign focused on New Zealand's scenic
beauty, exhilarating outdoor activities and authentic Maori culture, and it made New
Zealand one of the strongest national brands in the world.
A key feature of the campaign was the website www.newzealand.com, which provided
potential visitors to New Zealand with a single gateway to everything the destination had
to offer. The heart of the website was a database of tourism services operators, both
those based in New Zealand and those based abroad which offered tourism services to
the country. Any tourism-related business could be listed by filling in a simple form. This
meant that even the smallest bed and breakfast address or specialist activity provider
could gain a web presence with access to an audience of long-haul visitors. In addition,
because participating businesses were able to update the details they gave on a
regular basis, the information provided remained accurate. And to maintain and improve
standards, Tourism New Zealand organised a scheme whereby organisations appearing
on the website underwent an independent evaluation against a set of agreed national
standards of quality. As part of this, the effect of each business on the environment was
considered.
To communicate the New Zealand experience, the site also carried features relating
to famous people and places. One of the most popular was an interview with former
New Zealand All Blacks rugby captain Tana Umaga. Another feature that attracted a
lot of attention was an interactive journey through a number of the locations chosen
for blockbuster films which had made use of New Zealand's stunning scenery as a
backdrop. As the site developed, additional features were added to help independent
travellers devise their own customised itineraries. To make it easier to plan motoring
holidays, the site catalogued the most popular driving routes in the country, highlighting
different routes according to the season and indicating distances and times.
16
```

[Original question page](assets/7d299251be04ec31fa0fb1c6365ab3042f550c0d7491d387ba0d2c69343ab565.jpg)

<!-- Source: /api/assets/4a8ba88c5ef27a0fbdebf31d232aad6883cf0f928cd4429b5bf311ca17d04f3c.jpg; PDF page 18; full -->

```text
Reading
Later, a Travel Planner feature was added, which allowed visitors to click and ‘bookmark’
places or attractions they were interested in, and then view the results on a map. The
Travel Planner offered suggested routes and public transport options between the
chosen locations. There were also links to accommodation in the area. By registering
with the website, users could save their Travel Plan and return to it later, or print it out
to take on the visit. The website also had a ‘Your Words’ section where anyone could
submit a blog of their New Zealand travels for possible inclusion on the website.
The Tourism New Zealand website won two Webby awards for online achievement
and innovation. More importantly perhaps, the growth of tourism to New Zealand was
impressive. Overall tourism expenditure increased by an average of 6.9% per year
between 1999 and 2004. From Britain, visits to New Zealand grew at an average annual
rate of 13% between 2002 and 2006, compared to a rate of 4% overall for British
visits abroad.
The website was set up to allow both individuals and travel organisations to create
itineraries and travel packages to suit their own needs and interests. On the website,
visitors can search for activities not solely by geographical location, but also by the
particular nature of the activity. This is important as research shows that activities are the
key driver of visitor satisfaction, contributing 74% to visitor satisfaction, while transport
and accommodation account for the remaining 26%. The more activities that visitors
undertake, the more satisfied they will be. It has also been found that visitors enjoy
cultural activities most when they are interactive, such as visiting a marae (meeting
ground) to learn about traditional Maori life. Many long-haul travellers enjoy such
learning experiences, which provide them with stories to take home to their friends and
family. In addition, it appears that visitors to New Zealand don't want to be ‘one of the
crowd' and find activities that involve only a few people more special and meaningful.
It could be argued that New Zealand is not a typical destination. New Zealand is a small
country with a visitor economy composed mainly of small businesses. It is generally
perceived as a safe English-speaking country with a reliable transport infrastructure.
Because of the long-haul flight, most visitors stay for longer (average 20 days) and want
to see as much of the country as possible on what is often seen as a once-in-a-lifetime
visit. However, the underlying lessons apply anywhere - the effectiveness of a strong
brand, a strategy based on unique experiences and a comprehensive and user-friendly
website.
17
```

[Original question page](assets/4a8ba88c5ef27a0fbdebf31d232aad6883cf0f928cd4429b5bf311ca17d04f3c.jpg)

<!-- Source: /api/assets/c5be0baa16e78d73bf2439ab9ecd1c152b8af6da7aee01b23002b91b306badb5.jpg; PDF page 19; full -->

```text
Questions 1–7
Complete the table below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–7 on your answer sheet.
| Section of website | Comments |
| --- | --- |
| Database of tourism services | easy for tourism-related businesses to get on the list; allowed businesses to (1) __________ information regularly; provided a country-wide evaluation of businesses, including their impact on the (2) __________ |
| Special features on local topics | e.g. an interview with a former sports (3) __________, and an interactive tour of various locations used in (4) __________ |
| Information on driving routes | varied depending on the (5) __________ |
| Travel Planner | included a map showing selected places, details of public transport and local (6) __________ |
| ‘Your Words’ | travellers could send a link to their (7) __________ |
```

[Original question page](assets/c5be0baa16e78d73bf2439ab9ecd1c152b8af6da7aee01b23002b91b306badb5.jpg)

<!-- Source: /api/assets/d9bceb959f8dbd22e08ccdf0d2a984a6fc0324fe16c5a51f6e18fd010b3c78f7.jpg; PDF page 20; full -->

```text
Questions 8–13
Reading
Do the following statements agree with the information given in Reading Passage 1?
In boxes 8-13 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
8 The website www.newzealand.com aimed to provide ready-made itineraries and
packages for travel companies and individual tourists.
9 It was found that most visitors started searching on the website by
geographical location.
10 According to research, 26% of visitor satisfaction is related to their accommodation.
11 Visitors to New Zealand like to become involved in the local culture.
12 Visitors like staying in small hotels in New Zealand rather than in larger ones.
13 Many visitors feel it is unlikely that they will return to New Zealand after their visit.

19
```

[Original question page](assets/d9bceb959f8dbd22e08ccdf0d2a984a6fc0324fe16c5a51f6e18fd010b3c78f7.jpg)

<!-- Source: /api/assets/e8f9dd1ea2b264f27d7638e0de794e5a585db3ffc8f955ee8a355ae3a52a233d.jpg; PDF page 21; full -->

```text
Test 1
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 on pages 21 and 22.
Questions 14-19
Reading Passage 2 has six paragraphs, A-F.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i- viii, in boxes 14-19 on your answer sheet.
List of Headings
i The productive outcomes that may result from boredom
ii What teachers can do to prevent boredom
iii A new explanation and a new cure for boredom
iv Problems with a scientific approach to boredom
v A potential danger arising from boredom
vi Creating a system of classification for feelings of boredom
vii Age groups most affected by boredom
viii Identifying those most affected by boredom
14 Paragraph A
15 Paragraph B
16 Paragraph C
17 Paragraph D
18 Paragraph E
19 Paragraph F
20
```

[Original question page](assets/e8f9dd1ea2b264f27d7638e0de794e5a585db3ffc8f955ee8a355ae3a52a233d.jpg)

<!-- Source: /api/assets/2526ee06f8685b77803e48f962c3bd9b5b814b3aec11f61ec728d8579fc899ca.jpg; PDF page 22; full -->

```text
Reading
Why being bored is stimulating —  and useful, too
This most common of emotions is turning out to be more interesting than
we thought
A We all know how it feels — it's impossible to keep your mind on anything, time
stretches out, and all the things you could do seem equally unlikely to make you
feel better. But defining boredom so that it can be studied in the lab has proved
difficult. For a start, it can include a lot of other mental states, such as frustration,
apathy, depression and indifference. There isn't even agreement over whether
boredom is always a low-energy, flat kind of emotion or whether feeling agitated
and restless counts as boredom, too. In his book, Boredom: A Lively History, Peter
Toohey at the University of Calgary, Canada, compares it to disgust - an emotion
that motivates us to stay away from certain situations. ‘If disgust protects humans
from infection, boredom may protect them from “infectious” social situations, ’
he suggests.
B By asking people about their experiences of boredom, Thomas Goetz and his team
at the University of Konstanz in Germany have recently identified five distinct types:
indifferent, calibrating, searching, reactant and apathetic. These can be plotted on
two axes - one running left to right, which measures low to high arousal, and the
other from top to bottom, which measures how positive or negative the feeling is.
Intriguingly, Goetz has found that while people experience all kinds of boredom,
they tend to specialise in one. Of the five types, the most damaging is 'reactant,
boredom with its explosive combination of high arousal and negative emotion. The
most useful is what Goetz calls ‘indifferent’ boredom: someone isn’t engaged in
anything satisfying but still feels relaxed and calm. However, it remains to be seen
whether there are any character traits that predict the kind of boredom each of us
might be prone to.
C Psychologist Sandi Mann at the University of Central Lancashire,UK, goes further.
‘All emotions are there for a reason, including boredom,’ she says. Mann has found
that being bored makes us more creative. ‘We’re all afraid of being bored but in
actual fact it can lead to all kinds of amazing things,, she says. In experiments
published last year, Mann found that people who had been made to feel bored by
copying numbers out of the phone book for 15 minutes came up with more creative
ideas about how to use a polystyrene cup than a control group. Mann concluded
that a passive, boring activity is best for creativity because it allows the mind
to wander. In fact, she goes so far as to suggest that we should seek out more
boredom in our lives.
D Psychologist John Eastwood at York University in Toronto, Canada, isn’t convinced.
‘If you are in a state of mind-wandering you are not bored, ’ he says. ‘In my view,
by definition boredom is an undesirable state.’ That doesn’t necessarily mean
that it isn’t adaptive, he adds. ‘Pain is adaptive — if we didn’t have physical pain,
bad things would happen to us. Does that mean that we should actively cause
pain? No. But even if boredom has evolved to help us survive, it can still be toxic
21
```

[Original question page](assets/2526ee06f8685b77803e48f962c3bd9b5b814b3aec11f61ec728d8579fc899ca.jpg)

<!-- Source: /api/assets/3dcecba811fa81b726fcbca6081802952e8c6e497744b577f0bc3e71d6aa1806.jpg; PDF page 23; full -->

```text
Test 1
if allowed to fester.’ For Eastwood, the central feature of boredom is a failure to
put our ‘attention system’ into gear. This causes an inability to focus on anything,
which makes time seem to go painfully slowly. What’s more, your efforts to improve
the situation can end up making you feel worse. ‘People try to connect with the
world and if they are not successful there’s that frustration and irritability,' he says.
Perhaps most worryingly, says Eastwood, repeatedly failing to engage attention
can lead to a state where we don’t know what to do any more, and no longer care.
E Eastwood's team is now trying to explore why the attention system fails. It’s early
days but they think that at least some of it comes down to personality. Boredom
proneness has been linked with a variety of traits. People who are motivated by
pleasure seem to suffer particularly badly. Other personality traits, such as curiosity,
are associated with a high boredom threshold. More evidence that boredom has
detrimental effects comes from studies of people who are more or less prone to
boredom. It seems those who bore easily face poorer prospects in education,
their career and even life in general. But of course, boredom itself cannot kill -
it’s the things we do to deal with it that may put us in danger. What can we do to
alleviate it before it comes to that? Goetz’s group has one suggestion. Working with
teenagers, they found that those who ‘approach’ a boring situation - in other words,
see that it’s boring and get stuck in anyway - report less boredom than those who
try to avoid it by using snacks, TV or social media for distraction.
F Psychologist Francoise Wemelsfelder speculates that our over-connected lifestyles
might even be a new source of boredom. ‘In modern human society there is a lot of
overstimulation but still a lot of problems finding meaning,, she says. So instead of
seeking yet more mental stimulation, perhaps we should leave our phones alone,
and use boredom to motivate us to engage with the world in a more
meaningful way.
22
```

[Original question page](assets/3dcecba811fa81b726fcbca6081802952e8c6e497744b577f0bc3e71d6aa1806.jpg)

<!-- Source: /api/assets/224b278d47aae1994801cee7aa9136231bda3106ed29ebf1c22724259e0adcef.jpg; PDF page 24; full -->

```text
Questions 20–23
Reading
Look at the following people () and the list of ideas below.
Match each person with the correct idea, A-E.
Write the correct letter, A-E, in boxes 20-23 on your answer sheet.
20 Peter Toohey
21 Thomas Goetz
22 John Eastwood
23 Francoise Wemelsfelder

List of Ideas
A The way we live today may encourage boredom.
B One sort of boredom is worse than all the others.
C Levels of boredom may fall in the future.
D Trying to cope with boredom can increase its negative effects.
E Boredom may encourage us to avoid an unpleasant experience.
Questions 24-26
Complete the summary below.
Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 24-26 on your answer sheet
Responses to boredom
For John Eastwood, the central feature of boredom is that people cannot (24) __________, due to a failure in what he calls the ‘attention system’, and as a result they become frustrated and irritable. His team suggests that those for whom (25) __________ is an important aim in life may have problems in coping with boredom, whereas those who have the characteristic of (26) __________ can generally cope with it.
```

[Original question page](assets/224b278d47aae1994801cee7aa9136231bda3106ed29ebf1c22724259e0adcef.jpg)

<!-- Source: /api/assets/0b9534b7926020fd43bfe329bd84dc06226938058e722239d4d0093a5f0a0cc7.jpg; PDF page 25; full -->

```text
Test 1
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
Artificial artists
Can computers really create works of art?
The Painting Fool is one of a growing number of computer programs which, so their
makers claim, possess creative talents. Classical music by an artificial composer has
had audiences enraptured, and even tricked them into believing a human was behind
the score. Artworks painted by a robot have sold for thousands of dollars and been hung
in prestigious galleries. And software has been built which creates art that could not
have been imagined by the programmer.
Human beings are the only species to perform sophisticated creative acts regularly.
If we can break this process down into computer code, where does that leave human
creativity? ‘This is a question at the very core of humanity,, says Geraint Wiggins, a
computational creativity researcher at Goldsmiths, University of London. ‘It scares a lot
of people. They are worried that it is taking something special away from what it means
to be human.'
To some extent, we are all familiar with computerised art. The question is: where does
the work of the artist stop and the creativity of the computer begin? Consider one of the
oldest machine artists, Aaron, a robot that has had paintings exhibited in London’s Tate
Modern and the San Francisco Museum of Modern Art. Aaron can pick up a paintbrush
and paint on canvas on its own. Impressive perhaps, but it is still little more than a tool to
realise the programmer’s own creative ideas.
Simon Colton, the designer of the Painting Fool, is keen to make sure his creation
doesn’t attract the same criticism. Unlike earlier ‘artists’ such as Aaron, the Painting Fool
only needs minimal direction and can come up with its own concepts by going online for
material. The software runs its own web searches and trawls through social media sites.
It is now beginning to display a kind of imagination too, creating pictures from scratch.
One of its original works is a series of fuzzy landscapes, depicting trees and sky. While
some might say they have a mechanical look, Colton argues that such reactions arise
from people's double standards towards software-produced and human-produced
art. After all, he says, consider that the Painting Fool painted the landscapes without
referring to a photo. 'If a child painted a new scene from its head, you'd say it has a
certain level of imagination,’ he points out. ‘The same should be true of a machine.’
Software bugs can also lead to unexpected results. Some of the Painting Fool's
paintings of a chair came out in black and white, thanks to a technical glitch. This gives
the work an eerie, ghostlike quality. Human artists like the renowned Ellsworth Kelly are
lauded for limiting their colour palette - so why should computers be any different?
24
```

[Original question page](assets/0b9534b7926020fd43bfe329bd84dc06226938058e722239d4d0093a5f0a0cc7.jpg)

<!-- Source: /api/assets/99ec65736080060901548b341e7891ff401390511f500cece29aab002c92cce2.jpg; PDF page 26; full -->

```text
Reading
Researchers like Colton don't believe it is right to measure machine creativity directly
to that of humans who ‘have had millennia to develop our skills’. Others, though, are
fascinated by the prospect that a computer might create something as original and
subtle as our best artists. So far, only one has come close. Composer David Cope
invented a program called Experiments in Musical Intelligence, or EMI. Not only did
EMI create compositions in Cope’s style, but also that of the most revered classical
composers, including Bach, Chopin and Mozart. Audiences were moved to tears, and
EMI even fooled classical music experts into thinking they were hearing genuine Bach.
Not everyone was impressed however. Some, such as Wiggins, have blasted Cope's
work as pseudoscience, and condemned him for his deliberately vague explanation of
how the software worked. Meanwhile, Douglas Hofstadter of Indiana University said
EMI created replicas which still rely completely on the original artist’s creative impulses.
When audiences found out the truth they were often outraged with Cope, and one music
lover even tried to punch him. Amid such controversy, Cope destroyed EMI's
vital databases.
But why did so many people love the music, yet recoil when they discovered how it
was composed? A study by computer scientist David Moffat of Glasgow Caledonian
University provides a clue. He asked both expert musicians and non-experts to assess
six compositions. The participants weren’t told beforehand whether the tunes were
composed by humans or computers, but were asked to guess, and then rate how much
they liked each one. People who thought the composer was a computer tended to dislike
the piece more than those who believed it was human. This was true even among the
experts, who might have been expected to be more objective in their analyses.
Where does this prejudice come from? Paul Bloom of Yale University has a suggestion:
he reckons part of the pleasure we get from art stems from the creative process behind
the work. This can give it an ‘irresistible essence', says Bloom. Meanwhile, experiments
by Justin Kruger of New York University have shown that people's enjoyment of an
artwork increases if they think more time and effort was needed to create it. Similarly,
Colton thinks that when people experience art, they wonder what the artist might have
been thinking or what the artist is trying to tell them. It seems obvious, therefore, that
with computers producing art, this speculation is cut short - there's nothing to explore.
But as technology becomes increasingly complex, finding those greater depths in
computer art could become possible. This is precisely why Colton asks the Painting
Fool to tap into online social networks for its inspiration: hopefully this way it will choose
themes that will already be meaningful to us.
```

[Original question page](assets/99ec65736080060901548b341e7891ff401390511f500cece29aab002c92cce2.jpg)

<!-- Source: /api/assets/96f72ca044b85f1bd35cbe08d03404cf658ddacac86c73b0704be60be761f9a3.jpg; PDF page 27; full -->

```text
Questions 27–31
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27–31 on your answer sheet.
27 What is the writer suggesting about computer-produced works in the first paragraph?
A People’s acceptance of them can vary considerably.
B A great deal of progress has already been attained in this field.
C They have had more success in some artistic genres than in others.
D The advances are not as significant as the public believes them to be.
28 According to Geraint Wiggins, why are many people worried by computer art?
A It is aesthetically inferior to human art.
B It may ultimately supersede human art.
C It undermines a fundamental human quality.
D It will lead to a deterioration in human ability.
29 What is a key difference between Aaron and the Painting Fool?
A its programmer’s background
B public response to its work
C the source of its subject matter
D the technical standard of its output
30 What point does Simon Colton make in the fourth paragraph?
A Software-produced art is often dismissed as childish and simplistic.
B The same concepts of creativity should not be applied to all forms of art.
C It is unreasonable to expect a machine to be as imaginative as a human being.
D People tend to judge computer art and human art according to different criteria.
31 The writer refers to the paintings of a chair as an example of computer art which
A achieves a particularly striking effect.
B exhibits a certain level of genuine artistic skill.
C closely resembles that of a well-known artist.
D highlights the technical limitations of the software.
```

[Original question page](assets/96f72ca044b85f1bd35cbe08d03404cf658ddacac86c73b0704be60be761f9a3.jpg)

<!-- Source: /api/assets/8d942246bfcf8ce83921a71cc57d8222c8e0fa500383389797972c13fc02d7bc.jpg; PDF page 28; full -->

```text
Questions 32–37
Reading
Complete each sentence with the correct ending, A-G below.
Write the correct letter, A-G, in boxes 32-37 on your answer sheet
32 Simon Colton says it is important to consider the long-term view when
33 David Cope's EMI software surprised people by
34 Geraint Wiggins criticised Cope for not
35 Douglas Hofstadter claimed that EMI was
36 Audiences who had listened to EMI's music became angry after
37 The participants in David Moffat's study had to assess music without
List of Ideas
A generating work that was virtually indistinguishable from that of humans.
B knowing whether it was the work of humans or software.
C producing work entirely dependent on the imagination of its creator.
D comparing the artistic achievements of humans and computers.
E revealing the technical details of his program.
F persuading the public to appreciate computer art.
G discovering that it was the product of a computer program.

27
```

[Original question page](assets/8d942246bfcf8ce83921a71cc57d8222c8e0fa500383389797972c13fc02d7bc.jpg)

<!-- Source: /api/assets/e30b3f223c74e7fd249d5d890924416c29be336108d6f95223bacc8cc22e23e4.jpg; PDF page 29; full -->

```text
Test 1
Questions 38-40
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 38-40 on your answer sheet, write
YES if the statement agrees with the claims of the writer
NO if the statement contradicts the claims of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
38 Moffat's research may help explain people’s reactions to EMI.
39 The non-experts in Moffat's study all responded in a predictable way.
40 Justin Kruger's findings cast doubt on Paul Bloom’s theory about people's prejudice
towards computer art.
28
```

[Original question page](assets/e30b3f223c74e7fd249d5d890924416c29be336108d6f95223bacc8cc22e23e4.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/c31e18588873ae97ace5526ba09938e0ad59e3a1ac9825ec41f74e8309c0b20e.jpg; PDF page 30; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The two maps below show road access to a city hospital in 2007 and in 2010.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/c31e18588873ae97ace5526ba09938e0ad59e3a1ac9825ec41f74e8309c0b20e.jpg)

![Original figure](assets/c31e18588873ae97ace5526ba09938e0ad59e3a1ac9825ec41f74e8309c0b20e.jpg)

### Task 2

<!-- Source: /api/assets/e4df2cf343752aebd4ae8c1bec0e3dc838e42937efca6875ee1446cd5e49e812.jpg; PDF page 31; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Living in a country where you have to speak a foreign language can cause serious social problems, as well as practical problems.

To what extent do you agree or disagree with this statement?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/e4df2cf343752aebd4ae8c1bec0e3dc838e42937efca6875ee1446cd5e49e812.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/5fbe398965b289b42d82c5a85934c839b8830b8b02eb5f392baddbb930a7f952.jpg; PDF page 32; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Television programmes
• Where do you usually watch TV programmes/shows? [Why?/Why not?]
• What’s your favourite TV programme/show? [Why?]
• Are there any programmes/shows you don't like watching? [Why?/Why not?]
• Do you think you will watch more TV or fewer TV programmes/shows in the future?
[Why?/Why not?]
PART 2
Describe someone you know who has started a
business.
You should say:
who this person is
what work this person does
why this person decided to start a business
and explain whether you would like to do the
same kind of work as this person.
You will have to talk
about the topic for one
to two minutes. You
have one minute to
think about what you
are going to say. You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Choosing work
Example questions:
What kinds of jobs do young people not want to do in your country?
Who is best at advising young people about choosing a job: teachers or parents?
Is money always the most important thing when choosing a job?
Work-Life balance
Example questions:
Do you agree that many people nowadays are under pressure to work longer hours and
take less holiday?
What is the impact on society of people having a poor work-life balance?
Could you recommend some effective strategies for governments and employers to
ensure people have a good work-life balance?
```

[Original question page](assets/5fbe398965b289b42d82c5a85934c839b8830b8b02eb5f392baddbb930a7f952.jpg)

### Part 2

<!-- Source: /api/assets/5fbe398965b289b42d82c5a85934c839b8830b8b02eb5f392baddbb930a7f952.jpg; PDF page 32; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Television programmes
• Where do you usually watch TV programmes/shows? [Why?/Why not?]
• What’s your favourite TV programme/show? [Why?]
• Are there any programmes/shows you don't like watching? [Why?/Why not?]
• Do you think you will watch more TV or fewer TV programmes/shows in the future?
[Why?/Why not?]
PART 2
Describe someone you know who has started a
business.
You should say:
who this person is
what work this person does
why this person decided to start a business
and explain whether you would like to do the
same kind of work as this person.
You will have to talk
about the topic for one
to two minutes. You
have one minute to
think about what you
are going to say. You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Choosing work
Example questions:
What kinds of jobs do young people not want to do in your country?
Who is best at advising young people about choosing a job: teachers or parents?
Is money always the most important thing when choosing a job?
Work-Life balance
Example questions:
Do you agree that many people nowadays are under pressure to work longer hours and
take less holiday?
What is the impact on society of people having a poor work-life balance?
Could you recommend some effective strategies for governments and employers to
ensure people have a good work-life balance?
```

[Original question page](assets/5fbe398965b289b42d82c5a85934c839b8830b8b02eb5f392baddbb930a7f952.jpg)

### Part 3

<!-- Source: /api/assets/5fbe398965b289b42d82c5a85934c839b8830b8b02eb5f392baddbb930a7f952.jpg; PDF page 32; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Television programmes
• Where do you usually watch TV programmes/shows? [Why?/Why not?]
• What’s your favourite TV programme/show? [Why?]
• Are there any programmes/shows you don't like watching? [Why?/Why not?]
• Do you think you will watch more TV or fewer TV programmes/shows in the future?
[Why?/Why not?]
PART 2
Describe someone you know who has started a
business.
You should say:
who this person is
what work this person does
why this person decided to start a business
and explain whether you would like to do the
same kind of work as this person.
You will have to talk
about the topic for one
to two minutes. You
have one minute to
think about what you
are going to say. You
can make some notes
to help you if you wish.
PART 3
Discussion topics:
Choosing work
Example questions:
What kinds of jobs do young people not want to do in your country?
Who is best at advising young people about choosing a job: teachers or parents?
Is money always the most important thing when choosing a job?
Work-Life balance
Example questions:
Do you agree that many people nowadays are under pressure to work longer hours and
take less holiday?
What is the impact on society of people having a poor work-life balance?
Could you recommend some effective strategies for governments and employers to
ensure people have a good work-life balance?
```

[Original question page](assets/5fbe398965b289b42d82c5a85934c839b8830b8b02eb5f392baddbb930a7f952.jpg)
