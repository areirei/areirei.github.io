# 剑雅 7 · Test 2

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/dabae73cf41b041414fa2db013e2342f6ad83416e5be3fb761143bfb5020d94e.jpg; PDF page 38; full -->

```text
LISTENING SECTION 1 Questions 1–10
Complete the form below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
CAR INSURANCE
Example: Name — Patrick Jones
Address: (1) __________, Greendale
Contact number: 730453
Occupation: (2) __________
Size of car engine: 1200cc
Type of car: Manufacturer: Hewton; Model: (3) __________; Year: 1997
Previous insurance company: (4) __________
Any insurance claims in the last five years? Yes [checked]; No [unchecked]
If yes, give brief details: Car was (5) __________ in 1999
Name(s) of other driver(s): Simon (6) __________
Relationship to main driver: (7) __________
Uses of car: social; (8) __________
Start date: 31 January
Recommended Insurance arrangement
Name of company: (9) __________
Annual cost: (10) $__________
```

[Original question page](assets/dabae73cf41b041414fa2db013e2342f6ad83416e5be3fb761143bfb5020d94e.jpg)

### Part 2

<!-- Source: /api/assets/c97204dde421a4b4081f8b8281128c82c4148ca22e186620cb2af074412b9471.jpg; PDF page 39; full -->

```text
SECTION 2 Questions 11–20
Questions 11 and 12
Label the map below. Write NO MORE THAN TWO WORDS for each answer.
Boat Trip
[Original river map retained. Compass: north up, east right. STOP A: Green Banks, on upper bank at left; STOP B: (11) __________, on lower bank near left-centre; STOP C: Roman Landing, on upper bank farther right; STOP D: (12) __________, on upper bank at far right.]
```

[Original question page](assets/c97204dde421a4b4081f8b8281128c82c4148ca22e186620cb2af074412b9471.jpg)

![Original figure](assets/c97204dde421a4b4081f8b8281128c82c4148ca22e186620cb2af074412b9471.jpg)

<!-- Source: /api/assets/bf6684a25bd67e94e4bfe560950133d54da1ca4015561787649e48761c255130.jpg; PDF page 40; full -->

```text
Questions 13–18
Complete the table below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
| Stop | Attraction | Further Information |
| --- | --- | --- |
| STOP A: Main Booking Office; First boat: 8 a.m.; Last boat: (13) __________ p.m. | Palace | has lovely (14) __________ |
| STOP B | (15) __________ | has good (16) __________ of city centre |
| STOP C | Museum | bookshop specialising in the (17) __________ of the local area |
| STOP D | Entertainment Complex | (18) __________ cinema; bowling alley; video games arcade |
Questions 19 and 20
Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
19 How often do the Top Bus Company tours run? __________
20 Where can you catch a Number One Sightseeing Tour from? __________
```

[Original question page](assets/bf6684a25bd67e94e4bfe560950133d54da1ca4015561787649e48761c255130.jpg)

### Part 3

<!-- Source: /api/assets/0e21801ae77abb55fde74127e4b5eee8630b990e2d284921ba2e263f4782feb2.jpg; PDF page 41; full -->

```text
Test 2
SECTION 3 Questions 21-30
Questions 21-26
Choose the correct letter, A, B or C
21 The Antarctic Centre was established in Christchurch because
A New Zealand is a member of the Antarctic Treaty.
B Christchurch is geographically well positioned .
C the climate of Christchurch is suitable.
22 One role of the Antarctic Centre is to
A provide expeditions with suitable equipment.
B provide researchers with financial assistance.
C ensure that research is internationally relevant.
23 The purpose of the Visitors' Centre is to
A provide accommodation.
B run training sessions.
C show people what Antarctica is like.
24 Dr Merrywhether says that Antarctica is
A unlike any other country.
B extremely beautiful.
C too cold for tourists.
25 According to Dr Merrywhether, Antarctica is very cold because
A of the shape of the continent.
B it is surrounded by a frozen sea.
C it is an extremely dry continent.
26 Dr Merrywhether thinks Antarctica was part of another continent because
A he has done his own research in the area.
B there is geological evidence of this.
C it is very close to South America.
36
```

[Original question page](assets/0e21801ae77abb55fde74127e4b5eee8630b990e2d284921ba2e263f4782feb2.jpg)

<!-- Source: /api/assets/5667f0bc189ed47fec38ed26a033cd3a3edc761ad0b3efab03fad7ad2ff0aa2e.jpg; PDF page 42; full -->

```text
Listening
Questions 27 and 28
Complete the table below.
Write ONE WORD AND/OR TWO NUMBERS for each answer.
ANTARCTIC TREATY
Date Event
1870 Polar Research meeting
27 ........................ to ........ ................ 1st International Polar Year
1957 Antarctic Treaty was proposed
1959 Antarctic Treaty was 28 ........................
Questions 29 and 30
Choose TWO letters, A- E.
Which TWO achievements of the Antarctic Treaty are mentioned by the speakers?
A no military use
B animals protected
C historic sites preserved
D no nuclear testing
E fishing rights protected
37
```

[Original question page](assets/5667f0bc189ed47fec38ed26a033cd3a3edc761ad0b3efab03fad7ad2ff0aa2e.jpg)

### Part 4

<!-- Source: /api/assets/80919d44067c573c3b34aedd1653b78f1e9f2e3f2bbf2d652f6c99b9bf514550.jpg; PDF page 43; full -->

```text
Test 2
SECTION 4 Questions 31-40
Questions 31-35
Choose the correct letter, A, B or C
Left and Right Handedness in Sport
31 Anita first felt the Matthews article was of value when she realised
A how it would help her difficulties with left-handedness.
B the relevance of connections he made with music.
C the impressive size of his research project.
32 Anita feels that the findings on handedness will be of value in
A helping sportspeople identify their weaknesses.
B aiding sportspeople as they plan tactics for each game.
C developing suitable training programmes for sportspeople.
33 Anita feels that most sports coaches
A know nothing about the influence of handedness.
B focus on the wrong aspects of performance.
C underestimate what science has to offer sport.
34 A German study showed there was greater 'mixed handedness ' in musicians who
A started playing instruments in early youth.
B play a string instrument such as the violin.
C practise a great deal on their instrument.
35 Studies on ape behaviour show that
38
A apes which always use the same hand to get food are most successful.
B apes have the same proportion of left- and right-handers as humans.
C more apes are left-handed than right-handed .
```

[Original question page](assets/80919d44067c573c3b34aedd1653b78f1e9f2e3f2bbf2d652f6c99b9bf514550.jpg)

<!-- Source: /api/assets/4d0e9a35666a85217d1885f4d2fe4183c623f8a71c1da09b232b25cbd210bb29.jpg; PDF page 44; full -->

```text
Questions 36–40
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
| Sport | Best laterality | Comments |
| --- | --- | --- |
| Hockey | mixed laterality | hockey stick has to be used in (36) __________; mixed-handed players found to be much more (37) __________ than others |
| Tennis | single laterality | gives a larger relevant field of (38) __________; cross-lateral players make (39) __________ too late |
| Gymnastics | cross laterality | gymnasts’ (40) __________ is important for performances |
```

[Original question page](assets/4d0e9a35666a85217d1885f4d2fe4183c623f8a71c1da09b232b25cbd210bb29.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/74d8a5651778032c75552337dc561ec09c393da8f9b0119ae9a1560bbf566faf.jpg; PDF page 45; full -->

```text
Test2
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading Passage 1
below.
Why pagodas
don't
fall down
In a land swept by typhoons and shaken by earthquakes, how have Japan's tallest and seemingly
flimsiest old buildings- 500 or so wooden pagodas- remained standing for centuries? Records
show that only two have collapsed during the past 1400 years. Those that have disappeared
were destroyed by fire as a result of lightning or civil war. The disastrous Hanshin earthquake in
1995 killed 6,400 people, toppled elevated highways, flattened office blocks and devastated the
port area of Kobe. Yet it left the magnificent five-storey pagoda at the Toji temple in nearby
Kyoto unscathed, though it levelled a number of buildings in the neighbourhood.
Japanese scholars have been mystified for ages about why these tall, slender buildings are so
stable. It was only thirty years ago that the building industry felt confident enough to erect
office blocks of steel and reinforced concrete that had more than a dozen floors . With its special
shock absorbers to dampen the effect of sudden sideways movements from an earthquake, the
thirty-six-storey Kasumigaseki building in central Tokyo- Japan's first skyscraper- was
considered a masterpiece of modern engineering when it was built in 1968.
Yet in 826, with only pegs and wedges to keep his wooden structure upright, the master builder
Kobodaishi had no hesitation in sending his majestic Toji pagoda soaring fifty -five metres into
the sky- nearly half as high as the Kasumigaseki skyscraper built some eleven centuries later.
Clearly, Japanese carpenters of the day knew a few tricks about allowing a building to sway and
settle itself rather than fight nature's forces. But what sort of tricks?
The multi-storey pagoda came to Japan from China in the sixth century. As in China, they were
first introduced with Buddhism and were attached to important temples . The Chinese built their
pagodas in brick or stone, with inner staircases, and used them in later centuries mainly as
watchtowers . When the pagoda reached Japan, however, its architecture was freely adapted to
local conditions- they were built less high, typically five rather than nine storeys, made mainly
of wood and the staircase was dispensed with because the Japanese pagoda did not have any
practical use but became more of an art object. Because of the typhoons that batter Japan in
the summer, Japanese builders learned to extend the eaves of buildings further beyond the
walls. This prevents rainwater gushing down the walls. Pagodas in China and Korea have
nothing like the overhang that is found on pagodas in Japan.
40
```

[Original question page](assets/74d8a5651778032c75552337dc561ec09c393da8f9b0119ae9a1560bbf566faf.jpg)

<!-- Source: /api/assets/e9f19d6eaa438e7b5d52f1bbe2f1a498fc40b6acbb1de00611ba1ca23e2bd949.jpg; PDF page 46; full -->

```text
Reading
The roof of a Japanese temple building can be made to overhang the sides of the structure by
fifty per cent or more of the building's overall width. For the same reason, the builders of
Japanese pagodas seem to have further increased their weight by choosing to cover these
extended eaves not with the porcelain tiles of many Chinese pagodas but with much heavier
earthenware tiles.
But this does not totally explain the great resilience of Japanese pagodas. Is the answer that, like
a tall pine tree, the Japanese pagoda- with its massive trunk-like central pillar known as
shinbashira- simply flexes and sways during a typhoon or earthquake? For centuries, many
thought so. But the answer is not so simple because the startling thing is that the shinbashira
actually carries no load at all. In fact, in some pagoda designs, it does not even rest on the
ground, but is suspended from the top of the pagoda- hanging loosely down through the
middle of the building. The weight of the building is supported entirely by twelve outer and four
inner columns.
And what is the role of the shinbashira, the central pillar? The best way to understand the
shinbashira's role is to watch a video made by Shuzo Ishida, a structural engineer at Kyoto
Institute of Technology. Mr Ishida, known to his students as 'Professor Pagoda' because of his
passion to understand the pagoda, has built a series of models and tested them on a 'shake­
table' in his laboratory . In short, the shinbashira was acting like an enormous stationary
pendulum . The ancient craftsmen, apparently without the assistance of very advanced
mathematics, seemed to grasp the principles that were, more than a thousand years later,
applied in the construction of Japan's first skyscraper. What those early craftsmen had found by
trial and error was that under pressure a pagoda's loose stack of floors could be made to slither
to and fro independent of one another. Viewed from the side, the pagoda seemed to be doing a
snake dance- with each consecutive floor moving in the opposite direction to its neighbours
above and below . The shinbashira, running up through a hole in the centre of the building,
constrained individual storeys from moving too far because, after moving a certain distance,
they banged into it, transmitting energy away along the column.
Another strange feature of the Japanese pagoda is that, because the building tapers, with each
successive floor plan being smaller than the one below, none of the vertical pillars that carry the
weight of the building is connected to its corresponding pillar above. In other words, a five­
storey pagoda contains not even one pillar that travels right up through the building to carry the
structural loads from the top to the bottom . More surprising is the fact that the individual
storeys of a Japanese pagoda, unlike their counterparts elsewhere, are not actually connected to
each other. They are simply stacked one on top of another like a pile of hats. Interestingly, such
a design would not be permitted under current Japanese building regulations.
And the extra-wide eaves? Think of them as a tightrope walker's balancing pole. The bigger the
mass at each end of the pole, the easier it is for the tightrope walker to maintain his or her
balance. The same holds true for a pagoda . 'With the eaves extending out on all sides like
balancing poles,' says Mr Ishida, 'the building responds to even the most powerful jolt of an
earthquake with a graceful swaying, never an abrupt shaking.' Here again, Japanese master
builders of a thousand years ago anticipated concepts of modern structural engineering.
41
```

[Original question page](assets/e9f19d6eaa438e7b5d52f1bbe2f1a498fc40b6acbb1de00611ba1ca23e2bd949.jpg)

<!-- Source: /api/assets/47b99d89ad05f5c4f5b338f387adf772b88264120066309115f4feb647055d23.jpg; PDF page 47; full -->

```text
Test 2
Questions 1-4
Do the following statements agree with the claims of the writer in Reading Passage 1?
In boxes 1-4 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
1 Only two Japanese pagodas have collapsed in 1400 years.
2 The Hanshin earthquake of 1995 destroyed the pagoda at the Toji temple.
3 The other buildings near the Toji pagoda had been built in the last 30 years.
4 The builders of pagodas knew how to absorb some of the power produced by severe
weather conditions.
Questions 5-10
Classify the following as typical of
A both Chinese and Japanese pagodas
B only Chinese pagodas
C only Japanese pagodas
Write the correct letter, A, B or C, in boxes 5-10 on your answer sheet.
5 easy interior access to top
6 tiles on eaves
7 use as observation post
8 size of eaves up to half the width of the building
9 original religious purpose
10 floors fitting loosely over each other
42
```

[Original question page](assets/47b99d89ad05f5c4f5b338f387adf772b88264120066309115f4feb647055d23.jpg)

<!-- Source: /api/assets/db9769a61179948b68192ed2869d5220ca14ac91b5fbff42a2fbbe699e9fd8cd.jpg; PDF page 48; full -->

```text
Reading
Questions 11-13
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 11- 13 on your answer sheet.
11 In a Japanese pagoda, the shinbashira
A bears the full weight of the building .
B bends under pressure like a tree.
C connects the floors with the foundations.
D stops the floors moving too far.
12 Shuzo Ishida performs experiments in order to
A improve skyscraper design.
B be able to build new pagodas.
C learn about the dynamics of pagodas.
D understand ancient mathematics.
13 The storeys of a Japanese pagoda are
A linked only by wood.
B fastened only to the central pillar.
C fitted loosely on top of each other.
D joined by special weights.
43
```

[Original question page](assets/db9769a61179948b68192ed2869d5220ca14ac91b5fbff42a2fbbe699e9fd8cd.jpg)

<!-- Source: /api/assets/957666e3e20a003b6cdc846cd327d290b237e90dcf1e704df9c99354a594448e.jpg; PDF page 49; full -->

```text
Test 2
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading Passage 2
below.
The True Cost of Food
A For more than forty years the cost of food has been
rising. It has now reached a point where a growing
number of people believe that it is far too high, and that
bringing it down will be one of the great challenges of
the twenty first century. That cost, however, is not in
immediate cash. In the West at least, most food is now
far cheaper to buy in relative terms than it was in 1960.
The cost is in the collateral damage of the very
methods of food production that have made the food
cheaper: in the pollution of water, the enervation of soil,
the destruction of wildlife, the harm to animal welfare
and the threat to human health caused by modern
industrial agriculture.
B First mechanisation, then mass use of chemical fertilisers and pesticides, then
monocultures, then battery rearing of livestock, and now genetic engineering - the
onward march of intensive farming has seemed unstoppable in the last half-century, as
the yields of produce have soared . But the damage it has caused has been colossal.
In Britain, for example, many of our best-loved farmland birds, such as the skylark, the
grey partridge, the lapwing and the corn bunting, have vanished from huge stretches
of countryside, as have even more wild flowers and insects. This is a direct result of the
way we have produced our food in the last four decades . Thousands of miles of
hedgerows , thousands of ponds, have disappeared from the landscape. The faecal filth
of salmon farming has driven wild salmon from many of the sea lochs and rivers of
Scotland . Natural soil fertility is dropping in many areas because of continuous
industrial fertiliser and pesticide use, while the growth of algae is increasing in lakes
because of the fertiliser run-off.
C Put it all together and it looks like a battlefield , but consumers rarely make the
connection at the dinner table. That is mainly because the costs of all this damage are
what economists refer to as externalities: they are outside the main transaction, which
is for example producing and selling a field of wheat, and are borne directly by neither
producers nor consumers. To many, the costs may not even appear to be financial at
all, but merely aesthetic- a terrible shame, but nothing to do with money. And anyway
they, as consumers of food, certainly aren't paying for it, are they?
44
```

[Original question page](assets/957666e3e20a003b6cdc846cd327d290b237e90dcf1e704df9c99354a594448e.jpg)

<!-- Source: /api/assets/eeb447be9b18f1f92b9098db3f14d9ab17a03cb56a1e357bdc2d8b6f27d001bd.jpg; PDF page 50; full -->

```text
Reading
D But the costs to society can actually be quantified and, when added up, can amount to
staggering sums. A remarkable exercise in doing this has been carried out by one of
the world's leading thinkers on the future of agriculture, Professor Jules Pretty, Director
of the Centre for Environment and Society at the University of Essex. Professor Pretty
and his colleagues calculated the externalities of British agriculture for one particular
year. They added up the costs of repairing the damage it caused, and came up with a
total figure of £2,343m. This is equivalent to £208 for every hectare of arable land and
permanent pasture, almost as much again as the total government and EU spend on
British farming in that year. And according to Professor Pretty, it was a conservative
estimate.
E The costs included: £120m for removal of pesticides; £16m for removal of nitrates;
£55m for removal of phosphates and soil; £23m for the removal of the bug
cryptosporidium from drinking water by water companies; £125m for damage to wildlife
habitats, hedgerows and dry stone walls; £1,113m from emissions of gases likely to
contribute to climate change; £106m from soil erosion and organic carbon losses;
£169m from food poisoning; and £607m from cattle disease. Professor Pretty draws a
simple but memorable conclusion from all this: our food bills are actually threefold. We
are paying for our supposedly cheaper food in three separate ways: once over the
counter, secondly through our taxes, which provide the enormous subsidies propping
up modern intensive farming, and thirdly to clean up the mess that modern farming
leaves behind.
F So can the true cost of food be brought down? Breaking away from industrial agriculture
as the solution to hunger may be very hard for some countries, but in Britain, where the
immediate need to supply food is less urgent, and the costs and the damage of
intensive farming have been clearly seen, it may be more feasible. The government
needs to create sustainable, competitive and diverse farming and food sectors, which
will contribute to a thriving and sustainable rural economy, and advance environmental,
economic, health, and animal welfare goals.
G But if industrial agriculture is to be replaced, what is a viable alternative? Professor
Pretty feels that organic farming would be too big a jump in thinking and in practices for
many farmers. Furthermore, the price premium would put the produce out of reach of
many poorer consumers. He is recommending the immediate introduction of a 'Greener
Food Standard', which would push the market towards more sustainable environmental
practices than the current norm, while not requiring the full commitment to organic
production. Such a standard would comprise agreed practices for different kinds of
farming, covering agrochemical use, soil health, land management, water and energy
use, food safety and animal health. It could go a long way, he says, to shifting
consumers as well as farmers towards a more sustainable system of agriculture. · ·
45
```

[Original question page](assets/eeb447be9b18f1f92b9098db3f14d9ab17a03cb56a1e357bdc2d8b6f27d001bd.jpg)

<!-- Source: /api/assets/e4011fe28cf875fc2b8bc60b41fa40ebf451a3439bc1580471355cabc2e8801a.jpg; PDF page 51; full -->

```text
Test 2
Questions 14-17
Reading Passage 2 has seven paragraphs, A-G.
Which paragraph contains the following information?
Write the correct letter, A-G, in boxes 14-17 on your answer sheet.
NB You may use any letter more than once.
14 a cost involved in purifying domestic water
15 the stages in the development of the farming industry
16 the term used to describe hidden costs
17 one effect of chemicals on water sources
Questions 18-21
Do the following statements agree with the claims of the writer in Reading Passage 2?
In boxes 18- 21 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
18 Several species of wildlife in the British countryside are declining.
19 The taste of food has deteriorated in recent years.
20 The financial costs of environmental damage are widely recognised.
21 One of the costs calculated by Professor Pretty was illness caused by food.
46
```

[Original question page](assets/e4011fe28cf875fc2b8bc60b41fa40ebf451a3439bc1580471355cabc2e8801a.jpg)

<!-- Source: /api/assets/164da930a8ce0ceeb0b8573a1484d6d67d6a3ee30b38f283503562c0d3e8af83.jpg; PDF page 52; full -->

```text
Reading
Questions 22-26
Complete the summary below.
Choose NO MORE THAN THREE WORDS from the passage for each answer.
Write your answers in boxes 22-26 on your answer sheet.
Professor Pretty concludes that our 22 ........................ are higher than most people
realise, because we make three different types of payment. He feels it is realistic
to suggest that Britain should reduce its reliance on 23 ........................ .
Although most farmers would be unable to adapt to 24 ........................ , Professor
Pretty wants the government to initiate change by establishing what he refers to as
a 25 .......................... He feels this would help to change the attitudes of both
26 ........................ and ......................... .
47
```

[Original question page](assets/164da930a8ce0ceeb0b8573a1484d6d67d6a3ee30b38f283503562c0d3e8af83.jpg)

<!-- Source: /api/assets/584b39be3878969642f2759eb1a90876ce9a71543c3981475af8ace88a40a2d8.jpg; PDF page 53; full -->

```text
Test 2
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading Passage 3
on the following pages.
Questions 27-30
Reading Passage 3 has six sections, A-F.
Choose the correct heading for sections B, C, E and F from the list of headings below.
Write the correct number, i-xi, in boxes 27-30 on your answer sheet.
List of Headings
i MIRTP as a future model
ii Identifying the main transport problems
iii Preference for motorised vehicles
iv Government authorities' instructions
v Initial improvements in mobility and transport modes
vi Request for improved transport in Makete
vii Transport improvements in the northern part of the district
viii Improvements in the rail network
ix Effects of initial MIRTP measures
x Co-operation of district officials
xi Role of wheelbarrows and donkeys
Example: Section A — vi
27 Section B __________
28 Section C __________
Example: Section D — ix
29 Section E __________
30 Section F __________
```

[Original question page](assets/584b39be3878969642f2759eb1a90876ce9a71543c3981475af8ace88a40a2d8.jpg)

<!-- Source: /api/assets/302d848861eee6c15bc0f1b922f81866540495c44061f0cb46ac78e5d370c746.jpg; PDF page 54; full -->

```text
Reading
Makete Integrated Rural Transport Project
Section A
The disappointing results of many conventional road transport projects in Africa led some experts to
rethink the strategy by which rural transport problems were to be tackled at the beginning of the 1980s.
A request for help in improving the availability of transport within the remote Makete District of south­
western Tanzania presented the opportunity to try a new approach.
The concept of'integrated rural transport' was adopted in the task of examining the transport needs of
the rural households in the district. The objective was to reduce the time and effort needed to obtain
access to essential goods and services through an improved rural transport system. The underlying
assumption was that the time saved would be used instead for activities that would improve the social and
economic development of the communities. The Makete Integrated Rural Transport Project (MIRTP)
started in 1985 with financial support from the Swiss Development Corporation and was co-ordinated
with the help of the Tanzanian government.
Section B
When the project began, Makete District was virtually totally isolated during the rainy season .The regional
road was in such bad shape that access to the main towns was impossible for about three months of the
year. Road traffic was extremely rare within the district, and alternative means of transport were restricted
to donkeys in the north of the district. People relied primarily on the paths, which were slippery and
dangerous during the rains.
Before solutions could be proposed , the problems had to be understood. Little was known about the
transport demands of the rural households, so Phase I, between December 1985 and December 1987,
focused on research .The socio-economic survey of more than 400 households in the district indicated that
a household in Makete spent, on average, seven hours a day on transporting themselves and their goods,
a figure which seemed extreme but which has also been obtained in surveys in other rural areas in Africa.
Interesting facts regarding transport were found: 95% was on foot; 80% was within the locality; and 70%
was related to the collection of water and firewood and travelling to grinding mills.
Section C
Having determined the main transport needs, possible solutions were identified which might reduce the
time and burden. During Phase II, from January to February 1991, a number of approaches were
implemented in an effort to improve mobility and access to transport.
An improvement of the road network was considered necessary to ensure the import and export of
goods to the district. These improvements were carried out using methods that were heavily dependent
on labour. In addition to the improvement of roads, these methods provided training in the operation of
a mechanical workshop and bus and truck services . However; the difference from the conventional
approach was that this time consideration was given to local transport needs outside the road network.
Most goods were transported along the paths that provide short-cuts up and down the hillsides, but the
paths were a real safety risk and made the journey on foot even more arduous. it made sense to improve
the paths by building steps, handrails and footbridges .
it was uncommon to find means of transport that were more efficient than walking but less technologically
advanced than motor vehicles. The use of bicycles was constrained by their high cost and the lack of
available spare parts. Oxen were not used at all but donkeys were used by a few households in the
northern part of the district. MIRTP focused on what would be most appropriate for the inhabitants of
Makete in terms of what was available, how much they could afford and what they were willing to accept.
49
```

[Original question page](assets/302d848861eee6c15bc0f1b922f81866540495c44061f0cb46ac78e5d370c746.jpg)

<!-- Source: /api/assets/88472b9ee69ac1ec52a262f2382ffb1c5ee97422245a1ee88fbeef603cca8202.jpg; PDF page 55; full -->

```text
Test 2
50
After careful consideration, the project chose the promotion of donkeys- a donkey costs less than a bicycle
- and the introduction of a locally manufacturable wheelbarrow.
Section D
At the end of Phase II, it was clear that the selected approaches to Makete's transport problems had had
different degrees of success. Phase III, from March 1991 to March 1993. focused on the refinement and
institutionalisation of these activities.
The road improvements and accompanying maintenance system had helped make the district centre
accessible throughout the year. Essential goods from outside the district had become more readily available
at the market, and prices did not fluctuate as much as they had done before .
Paths and secondary roads were improved only at the request of communities who were willing to
participate in construction and maintenance. However, the improved paths impressed the inhabitants, and
requests for assistance greatly increased soon after only a few improvements had been completed .
The efforts to improve the efficiency of the existing transport services were not very successful because
most of the motorised vehicles in the district broke down and there were no resources to repair them .
Even the introduction of low-cost means of transport was difficult because of the general poverty of the
district.The locally manufactured wheelbarrows were still too expensive for all but a few of the households.
Modifications to the original design by local carpenters cut production time and costs. Other local
carpenters have been trained in the new design so that they can respond to requests. Nevertheless, a
locally produced wooden wheelbarrow which costs around 5000 Tanzanian shillings (less than US$20) in
Makete, and is about one quarter the cost of a metal wheelbarrow, is still too expensive for most people .
Donkeys, which were imported to the district, have become more common and contribute , in particular,
to the transportation of crops and goods to market. Those who have bought donkeys are mainly from
richer households but. with an increased supply through local breeding, donkeys should become more
affordable. Meanwhile, local initiatives are promoting the renting out of the existing donkeys.
it should be noted , however, that a donkey, which at 20,000 Tanzanian shillings costs less than a bicycle, is
still an investment equal to an average household's income over half a year. This clearly illustrates the need
for supplementary measures if one wants to assist the rural poor.
Section E
It would have been easy to criticise the MIRTP for using in the early phases a 'top-down' approach, in which
decisions were made by experts and officials before being handed down to communities, but it was
necessary to start the process from the level of the governmental authorities of the district. It would have
been difficult to respond to the requests of villagers and other rural inhabitants without the support and
understanding of district authorities .
Section F
Today, nobody in the district argues about the importance of improved paths and inexpensive means of
transport . But this is the result of dedicated work over a long period , particularly from the officers in charge
of community development. They played an essential role in raising awareness and interest among the rural
communities.
The concept of integrated rural transport is now well established in Tanzania, where a major program of
rural transport is just about to start. The experiences from Makete will help in this initiative, and Makete
District will act as a reference for future work.
```

[Original question page](assets/88472b9ee69ac1ec52a262f2382ffb1c5ee97422245a1ee88fbeef603cca8202.jpg)

<!-- Source: /api/assets/bf1bca0c779f6306b238463e9e2a8d64c50ba453383d5f6a0e7b516a80745445.jpg; PDF page 56; full -->

```text
Reading
Questions 31-35
Do the following statements agree with the claims of the writer in Reading Passage 3?
In boxes 31-35 on your answer sheet, write
YES
NO
NOT GIVEN
if the statement agrees with the claims of the writer
if the statement contradicts the claims of the writer
if it is impossible to say what the writer thinks about this
31 MIRTP was divided into five phases.
32 Prior to the start of MIRTP the Makete district was almost inaccessible during the
rainy season.
33 Phase I of MIRTP consisted of a survey of household expenditure on transport.
34 The survey concluded that one-fifth or 20% of the household transport requirement as
outside the local area .
35 MIRTP hoped to improve the movement of goods from Makete district to the
country's capital.
51
```

[Original question page](assets/bf1bca0c779f6306b238463e9e2a8d64c50ba453383d5f6a0e7b516a80745445.jpg)

<!-- Source: /api/assets/f23dcd117ad352fa185281f0f8041fe09afdec5b3b9cf4d2fdb3d8ffa7f5f2a8.jpg; PDF page 57; full -->

```text
Test 2
Questions 36-39
Complete each sentence with the correct ending, A-J, below.
Write the correct letter, A-J, in boxes 36-39 on your answer sheet.
36 Construction of footbridges, steps and handrails
37 Frequent breakdown of buses and trucks in Makete
38 The improvement of secondary roads and paths
39 The isolation of Makete for part of the year
A provided the people of Makete with experience in running bus and
truck services.
B was especially successful in the northern part of the district.
C differed from earlier phases in that the community became less
actively involved.
D improved paths used for transport up and down hillsides.
E was no longer a problem once the roads had been improved .
F cost less than locally made wheelbarrows.
G was done only at the request of local people who were willing to
lend a hand.
H was at first considered by MIRTP to be affordable for the people
of the district.
I hindered attempts to make the existing transport services more
efficient.
J was thought to be the most important objective of Phase III.
Question 40
Choose the correct letter, A, B, C or D.
Write the correct letter in box 40 on your answer sheet.
Which of the following phrases best describes the main aim of Reading Passage 3?
52
A to suggest that projects such as MIRTP are needed in other
countries
B to describe how MIRTP was implemented and how successful it
was
C to examine how MIRTP promoted the use of donkeys
D to warn that projects such as MIRTP are likely to have serious
problems
```

[Original question page](assets/f23dcd117ad352fa185281f0f8041fe09afdec5b3b9cf4d2fdb3d8ffa7f5f2a8.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/edf2415cf47a2f2960cfce804cebf6ebfe1036cd168d36020231b838a89f09fd.jpg; PDF page 58; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The graph below shows the consumption of fish and some different kinds of meat in a European country between 1979 and 2004.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the original figure is retained for the complete plotted data or diagram.]
```

[Original question page](assets/edf2415cf47a2f2960cfce804cebf6ebfe1036cd168d36020231b838a89f09fd.jpg)

![Original figure](assets/edf2415cf47a2f2960cfce804cebf6ebfe1036cd168d36020231b838a89f09fd.jpg)

### Task 2

<!-- Source: /api/assets/5835d70b100d66a673a5214f1add266cf7372687eac2079695b1040c9a368f93.jpg; PDF page 59; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

Some people believe that there should be fixed punishments for each type of crime. Others, however, argue that the circumstances of an individual crime, and the motivation for committing it, should always be taken into account when deciding on the punishment.

Discuss both these views and give your own opinion.

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/5835d70b100d66a673a5214f1add266cf7372687eac2079695b1040c9a368f93.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/a9bf627f00cbfae0978b1becb842d7ad33fe3d9ef7da1a93ce5802a736b5b4a9.jpg; PDF page 60; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself , his/her home , work or studies and other
familiar topics .
EXAMPLE
Laughing
• What kinds of thing make you laugh?
• Do you like making other people laugh? [Why/Why not?]
• Do you think it's important for people to laugh? [Why/Why not ?]
• Is laughing the same as feeling happy , do you think? [Why/Why not?]
PART 2
Describe an idea you had for improving something at work or college.
You should say: when and where you had your idea; what your idea was; who you told about your idea; and explain why you thought your idea would make an improvement.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Ideas and education
Example questions:
Some people think that education should be about memorising the important ideas of the
past. Do you agree or disagree? Why?
Should education encourage students to have their own new ideas? Why?
How do you think teachers could help students to develop and share their own ideas?
Ideas in the workplace
Example questions:
Should employers encourage their workers to have new ideas about improving the company?
Why?
Do you think people sometimes dislike ideas just because they are new? Why?
What is more difficult: having new ideas or putting them into practice? Which is more
important for a successful company?
55
```

[Original question page](assets/a9bf627f00cbfae0978b1becb842d7ad33fe3d9ef7da1a93ce5802a736b5b4a9.jpg)

### Part 2

<!-- Source: /api/assets/a9bf627f00cbfae0978b1becb842d7ad33fe3d9ef7da1a93ce5802a736b5b4a9.jpg; PDF page 60; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself , his/her home , work or studies and other
familiar topics .
EXAMPLE
Laughing
• What kinds of thing make you laugh?
• Do you like making other people laugh? [Why/Why not?]
• Do you think it's important for people to laugh? [Why/Why not ?]
• Is laughing the same as feeling happy , do you think? [Why/Why not?]
PART 2
Describe an idea you had for improving something at work or college.
You should say: when and where you had your idea; what your idea was; who you told about your idea; and explain why you thought your idea would make an improvement.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Ideas and education
Example questions:
Some people think that education should be about memorising the important ideas of the
past. Do you agree or disagree? Why?
Should education encourage students to have their own new ideas? Why?
How do you think teachers could help students to develop and share their own ideas?
Ideas in the workplace
Example questions:
Should employers encourage their workers to have new ideas about improving the company?
Why?
Do you think people sometimes dislike ideas just because they are new? Why?
What is more difficult: having new ideas or putting them into practice? Which is more
important for a successful company?
55
```

[Original question page](assets/a9bf627f00cbfae0978b1becb842d7ad33fe3d9ef7da1a93ce5802a736b5b4a9.jpg)

### Part 3

<!-- Source: /api/assets/a9bf627f00cbfae0978b1becb842d7ad33fe3d9ef7da1a93ce5802a736b5b4a9.jpg; PDF page 60; full -->

```text
Speaking
SPEAKING
PART 1
The examiner asks the candidate about him/herself , his/her home , work or studies and other
familiar topics .
EXAMPLE
Laughing
• What kinds of thing make you laugh?
• Do you like making other people laugh? [Why/Why not?]
• Do you think it's important for people to laugh? [Why/Why not ?]
• Is laughing the same as feeling happy , do you think? [Why/Why not?]
PART 2
Describe an idea you had for improving something at work or college.
You should say: when and where you had your idea; what your idea was; who you told about your idea; and explain why you thought your idea would make an improvement.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.

PART 3
Discussion topics:
Ideas and education
Example questions:
Some people think that education should be about memorising the important ideas of the
past. Do you agree or disagree? Why?
Should education encourage students to have their own new ideas? Why?
How do you think teachers could help students to develop and share their own ideas?
Ideas in the workplace
Example questions:
Should employers encourage their workers to have new ideas about improving the company?
Why?
Do you think people sometimes dislike ideas just because they are new? Why?
What is more difficult: having new ideas or putting them into practice? Which is more
important for a successful company?
55
```

[Original question page](assets/a9bf627f00cbfae0978b1becb842d7ad33fe3d9ef7da1a93ce5802a736b5b4a9.jpg)
