# 剑雅 7 · Test 2 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 159

TEST 2 LISTENING
Section 1, Questions 1–10
1 27 Bank Road
2 (a) dentist
3 Sable
4 Northern Star
5 stolen
6 Paynter
7 brother-in-law
8 (travel(ling/ing)) (to) work
9 Red Flag
10 450
Section 2, Questions 11–20
11 City Bridge
12 Newtown
13 6.30
14 (formal) garden
15 (Tower) Restaurant
16 view(s)
17 history
18 7 screen
19 every 20 minutes
20 (from/the) Central Station
Section 3, Questions 21–30
21 B
22 A
23 C
24 B
25 A
26 B
27 1882 (to/–) (18)83
28 signed
29–30 IN EITHER ORDER: A; D
Section 4, Questions 31–40
31 C
32 B
33 C
34 A
35 A
36 2 directions
37 confident
38 vision
39 corrections
40 balance
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. 27 Bank Road

2. dentist / a dentist

3. Sable

4. Northern Star

5. stolen

6. Paynter

7. brother-in-law

8. work / to work / travelling work / travelling to work / traveling work / traveling to work

9. Red Flag

10. 450

### Part 2 · source page 159

TEST 2 LISTENING
Section 1, Questions 1–10
1 27 Bank Road
2 (a) dentist
3 Sable
4 Northern Star
5 stolen
6 Paynter
7 brother-in-law
8 (travel(ling/ing)) (to) work
9 Red Flag
10 450
Section 2, Questions 11–20
11 City Bridge
12 Newtown
13 6.30
14 (formal) garden
15 (Tower) Restaurant
16 view(s)
17 history
18 7 screen
19 every 20 minutes
20 (from/the) Central Station
Section 3, Questions 21–30
21 B
22 A
23 C
24 B
25 A
26 B
27 1882 (to/–) (18)83
28 signed
29–30 IN EITHER ORDER: A; D
Section 4, Questions 31–40
31 C
32 B
33 C
34 A
35 A
36 2 directions
37 confident
38 vision
39 corrections
40 balance
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. City Bridge

12. Newtown

13. 6.30 / 6:30

14. garden / formal garden

15. Restaurant / Tower Restaurant

16. view / views

17. history

18. 7 screen

19. every 20 minutes

20. Central Station / from Central Station / the Central Station

### Part 3 · source page 159

TEST 2 LISTENING
Section 1, Questions 1–10
1 27 Bank Road
2 (a) dentist
3 Sable
4 Northern Star
5 stolen
6 Paynter
7 brother-in-law
8 (travel(ling/ing)) (to) work
9 Red Flag
10 450
Section 2, Questions 11–20
11 City Bridge
12 Newtown
13 6.30
14 (formal) garden
15 (Tower) Restaurant
16 view(s)
17 history
18 7 screen
19 every 20 minutes
20 (from/the) Central Station
Section 3, Questions 21–30
21 B
22 A
23 C
24 B
25 A
26 B
27 1882 (to/–) (18)83
28 signed
29–30 IN EITHER ORDER: A; D
Section 4, Questions 31–40
31 C
32 B
33 C
34 A
35 A
36 2 directions
37 confident
38 vision
39 corrections
40 balance
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. B

22. A

23. C

24. B

25. A

26. B

27. 1882 to 1883 / 1882-1883 / 1882 to 83 / 1882-83

28. signed

29. A / D

30. A / D

### Part 4 · source page 159

TEST 2 LISTENING
Section 1, Questions 1–10
1 27 Bank Road
2 (a) dentist
3 Sable
4 Northern Star
5 stolen
6 Paynter
7 brother-in-law
8 (travel(ling/ing)) (to) work
9 Red Flag
10 450
Section 2, Questions 11–20
11 City Bridge
12 Newtown
13 6.30
14 (formal) garden
15 (Tower) Restaurant
16 view(s)
17 history
18 7 screen
19 every 20 minutes
20 (from/the) Central Station
Section 3, Questions 21–30
21 B
22 A
23 C
24 B
25 A
26 B
27 1882 (to/–) (18)83
28 signed
29–30 IN EITHER ORDER: A; D
Section 4, Questions 31–40
31 C
32 B
33 C
34 A
35 A
36 2 directions
37 confident
38 vision
39 corrections
40 balance
If you score… (original source guidance, not a new scoring rule)
0–11: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
12–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. C

32. B

33. C

34. A

35. A

36. 2 directions

37. confident

38. vision

39. corrections

40. balance

## A 类阅读

### Academic Reading · source page 160

ACADEMIC READING
Reading Passage 1, Questions 1–13
1 YES
2 NO
3 NOT GIVEN
4 YES
5 B
6 A
7 B
8 C
9 A
10 C
11 D
12 C
13 C
Reading Passage 2, Questions 14–26
14 E
15 B
16 C
17 B
18 YES
19 NOT GIVEN
20 NO
21 YES
22 food bills / costs
23 (modern) intensive farming
24 organic farming
25 Greener Food Standard
26 IN EITHER ORDER: farmers (and); consumers
Reading Passage 3, Questions 27–40
27 ii
28 v
29 x
30 i
31 NO
32 YES
33 NO
34 YES
35 NOT GIVEN
36 D
37 I
38 G
39 E
40 B
If you score… (original source guidance, not a new scoring rule)
0–13: you are unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
14–29: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
30–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. YES

2. NO

3. NOT GIVEN

4. YES

5. B

6. A

7. B

8. C

9. A

10. C

11. D

12. C

13. C

14. E

15. B

16. C

17. B

18. YES

19. NOT GIVEN

20. NO

21. YES

22. food bills / costs

23. intensive farming / modern intensive farming

24. organic farming

25. Greener Food Standard

26. farmers consumers / farmers, consumers / farmers and consumers / farmers & consumers / farmers; consumers / farmers/consumers / farmers,consumers / consumers farmers / consumers, farmers / consumers and farmers / consumers & farmers / consumers; farmers / consumers/farmers / consumers,farmers

27. ii

28. v

29. x

30. i

31. NO

32. YES

33. NO

34. YES

35. NOT GIVEN

36. D

37. I

38. G

39. E

40. B

## A 类写作

### Writing material: c7-t2-w-1

Units grams per person per week, unnamed European country, 1979–2004. Approximate readings: chicken increases with fluctuations from around 150 to around 250 grams; beef starts around 220, fluctuates near a peak around 240 in the early 1980s, then declines to around 110; lamb falls overall from about 150 to around 60; fish declines gently from about 60 to around 40 and is lowest throughout. Chicken overtakes beef around 1989 and finishes highest. Only chicken increases overall; the other three decline. No country name, population size, causes or future projections are supplied. All unlabelled curve values are approximate.



### Writing material: c7-t2-w-2

Both fixed punishment by offence type and consideration of circumstances and motivation must be discussed, with an opinion. The prompt is a policy debate, not a statement of any particular jurisdiction's current law.



## 口语
