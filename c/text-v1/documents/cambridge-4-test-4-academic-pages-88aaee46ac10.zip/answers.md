# 剑雅 4 · Test 4 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 159

TEST4 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 College Dining Room
2–3 IN EITHER ORDER: office staff;students
4 10th December
5 coffee break / coffee breaks
6 6
7 set of dictionaries / dictionaries / a good dictionary
8–9 IN EITHER ORDER: (some) music / (some) music tapes / (some) tapes; photos / photographs
10 speech
Section2, Questions11–20
11 B
12 A
13 A
14 A
15 B
16 180
17 nearest station
18 local history
19 690
20 walking club / local walking club
Section3, Questions21–30
21 20balloons
22 units of measurement / measurements / measurement units
23 rock salt / salt
24 crystals
25 string / piece of string
26 (ordinary) (white) light
27 H
28 B
29 E
30 C
Section4, Questions31–40
31 795
32 tail
33 floor / bed / bottom
34 sense of smell
35 A
36 A
37 B
38 B
39–40 IN EITHER ORDER: B;E
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. College Dining Room

2. office staff / students

3. office staff / students

4. 10 December / 10th December

5. coffee break / coffee breaks

6. 6

7. set of dictionaries / dictionaries / a good dictionary

8. music / some music / music tapes / some music tapes / tapes / some tapes / photos / photographs

9. music / some music / music tapes / some music tapes / tapes / some tapes / photos / photographs

10. speech

### Part 2 · source page 159

TEST4 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 College Dining Room
2–3 IN EITHER ORDER: office staff;students
4 10th December
5 coffee break / coffee breaks
6 6
7 set of dictionaries / dictionaries / a good dictionary
8–9 IN EITHER ORDER: (some) music / (some) music tapes / (some) tapes; photos / photographs
10 speech
Section2, Questions11–20
11 B
12 A
13 A
14 A
15 B
16 180
17 nearest station
18 local history
19 690
20 walking club / local walking club
Section3, Questions21–30
21 20balloons
22 units of measurement / measurements / measurement units
23 rock salt / salt
24 crystals
25 string / piece of string
26 (ordinary) (white) light
27 H
28 B
29 E
30 C
Section4, Questions31–40
31 795
32 tail
33 floor / bed / bottom
34 sense of smell
35 A
36 A
37 B
38 B
39–40 IN EITHER ORDER: B;E
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

11. B

12. A

13. A

14. A

15. B

16. 180

17. nearest station

18. local history

19. 690

20. walking club / local walking club

### Part 3 · source page 159

TEST4 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 College Dining Room
2–3 IN EITHER ORDER: office staff;students
4 10th December
5 coffee break / coffee breaks
6 6
7 set of dictionaries / dictionaries / a good dictionary
8–9 IN EITHER ORDER: (some) music / (some) music tapes / (some) tapes; photos / photographs
10 speech
Section2, Questions11–20
11 B
12 A
13 A
14 A
15 B
16 180
17 nearest station
18 local history
19 690
20 walking club / local walking club
Section3, Questions21–30
21 20balloons
22 units of measurement / measurements / measurement units
23 rock salt / salt
24 crystals
25 string / piece of string
26 (ordinary) (white) light
27 H
28 B
29 E
30 C
Section4, Questions31–40
31 795
32 tail
33 floor / bed / bottom
34 sense of smell
35 A
36 A
37 B
38 B
39–40 IN EITHER ORDER: B;E
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

21. 20 balloons

22. units of measurement / measurements / measurement units

23. rock salt / salt

24. crystals

25. string / piece of string

26. light / white light / ordinary light / ordinary white light

27. H

28. B

29. E

30. C

### Part 4 · source page 159

TEST4 LISTENING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Section1, Questions1–10
1 College Dining Room
2–3 IN EITHER ORDER: office staff;students
4 10th December
5 coffee break / coffee breaks
6 6
7 set of dictionaries / dictionaries / a good dictionary
8–9 IN EITHER ORDER: (some) music / (some) music tapes / (some) tapes; photos / photographs
10 speech
Section2, Questions11–20
11 B
12 A
13 A
14 A
15 B
16 180
17 nearest station
18 local history
19 690
20 walking club / local walking club
Section3, Questions21–30
21 20balloons
22 units of measurement / measurements / measurement units
23 rock salt / salt
24 crystals
25 string / piece of string
26 (ordinary) (white) light
27 H
28 B
29 E
30 C
Section4, Questions31–40
31 795
32 tail
33 floor / bed / bottom
34 sense of smell
35 A
36 A
37 B
38 B
39–40 IN EITHER ORDER: B;E
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–27: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
28–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

31. 795

32. tail

33. floor / bed / bottom

34. sense of smell

35. A

36. A

37. B

38. B

39. B / E

40. B / E

## A 类阅读

### Academic Reading · source page 160

ACADEMIC READING
Each question correctly answered scores1mark. CORRECT SPELLING IS NEEDED IN ALL ANSWERS.
Reading Passage1, Questions1–13
1 TRUE
2 NOT GIVEN
3 FALSE
4 FALSE
5 NOT GIVEN
6 TRUE
7 genetics
8 power
9 injuries
10 training
11 A
12 D
13 B
Reading Passage2, Questions14–27
14 YES
15 NOT GIVEN
16 NO
17 YES
18 NOT GIVEN
19 NO
20–21 IN EITHER ORDER: D;E
22–23 IN EITHER ORDER: C;D
24 oral histories
25–26 IN EITHER ORDER: humanistic study;historical discipline
27 scientist
Reading Passage3, Questions28–40
28 iv
29 i
30 iii
31 v
32 B
33 B
34 A
35 B
36 NO
37 YES
38 YES
39 NOT GIVEN
40 NOT GIVEN
If you score… (original source guidance, not a new scoring rule)
0–12: you are highly unlikely to get an acceptable score under examination conditions and we recommend that you spend a lot of time improving your English before you take IELTS.
13–28: you may get an acceptable score under examination conditions but we recommend that you think about having more practice or lessons before you take IELTS.
29–40: you are likely to get an acceptable score under examination conditions but remember that different institutions will find different scores acceptable.

1. TRUE

2. NOT GIVEN

3. FALSE

4. FALSE

5. NOT GIVEN

6. TRUE

7. genetics

8. power

9. injuries

10. training

11. A

12. D

13. B

14. YES

15. NOT GIVEN

16. NO

17. YES

18. NOT GIVEN

19. NO

20. D / E

21. D / E

22. C / D

23. C / D

24. oral histories

25. humanistic study / historical discipline

26. humanistic study / historical discipline

27. scientist

28. iv

29. i

30. iii

31. v

32. B

33. B

34. A

35. B

36. NO

37. YES

38. YES

39. NOT GIVEN

40. NOT GIVEN

## A 类写作

### Writing material: c4-t4-w-1

Original line chart and destination bars inspected at full resolution. Line title: Visits to and from the UK; unit millions; years 1979–1999. Two series only: thick single line visits abroad by UK residents; striped/multiple-stroke symbol visits to the UK by overseas residents. Multiple strokes are the rendering of ONE inbound series, not three countries or three different datasets. Approximate outbound values rise from about 12 million in 1979 to around 20 in the mid-1980s, 30 around the late 1980s, about 40 in the early-to-mid 1990s, and roughly 53 in 1999. Inbound visits rise from around 10 million to roughly 26–28 million. Both increase, but outbound grows faster and exceeds inbound throughout, widening the gap. Destination chart applies only to UK residents in 1999; horizontal units millions of UK visitors. Approximate destinations: France 11 million, Spain 9–10 million, USA 3.5–4 million, Greece about 3 million, Turkey about 2 million. France and Spain are far ahead of the other three, with France highest and Turkey lowest. No purposes of travel, spending or causes are supplied. Treat all unlabelled graph readings as approximate.



### Writing material: c4-t4-w-2

The task asks for causes of school student-behaviour problems and proposed solutions. Address both and explain the proposed mechanisms; do not require invented research or statistics.



## 口语
