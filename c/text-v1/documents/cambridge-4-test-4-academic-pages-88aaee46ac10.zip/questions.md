# 剑雅 4 · Test 4

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/39e94faa0332c9823f7655d2a595689c774b60f0d6fd59d577f7599d0b48e2d6.jpg; PDF page 82; full -->

```text
LISTENING SECTION1 Questions1–10
Complete the notes below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
GOODBYE PARTY FOR JOHN
Example: Date—22nd December
Venue:(1) __________
Invitations(Tony)
Who to invite: John and his wife; Director; the (2) __________; all the teachers; all the (3) __________.
Date for sending invitations:(4) __________
Present(Lisa)
Collect money during the (5) __________
Suggested amount per person:(6) $__________
Check prices for: CD players; (7) __________; coffee maker.
Ask guests to bring: snacks; (8) __________; (9) __________.
Ask student representative to prepare a (10) __________.
```

[Original question page](assets/39e94faa0332c9823f7655d2a595689c774b60f0d6fd59d577f7599d0b48e2d6.jpg)

### Part 2

<!-- Source: /api/assets/81a4b3343c48806a67a602bcfffabe7ef9d572aaa093a92a6b018e26185690b9.jpg; PDF page 83; full -->

```text
SECTION 2 Questions 11-20 
Questions 11-15 
Choose the correct letter, A, B or C 
11 To find out how much holidays cost, you should press button 
A one. 
B two. 
C three. 
12 Travelite currently offer walking holidays 
A only in Western Europe. 
B all over Europe. 
C outside Europe. 
13 The walks offered by Travelite 
A cater for a range of walking abilities. 
B are planned by guides from the local area. 
C are for people with good fitness levels. 
14 On Travelite holidays, people holidaying alone pay 
A the same as other clients. 
B only a little more than other clients. 
C extra only if they stay in a large room. 
15 Entertainment is provided 
A when guests request it. 
B most nights. 
C every night. 
82
```

[Original question page](assets/81a4b3343c48806a67a602bcfffabe7ef9d572aaa093a92a6b018e26185690b9.jpg)

<!-- Source: /api/assets/865ab25df7052bdc83fb47fa9967b1cd8b63640346cf0b21a0027d0162392fd8.jpg; PDF page 84; full -->

```text
Questions16–20: Complete the table below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Length of holiday | Cost per person(including all accommodation costs) | Special offers included in price
3days |(16) $__________|Pick up from the (17) __________
7days |$350|As above plus: book of (18) __________;maps
14days |(19) $__________|As above plus membership of a (20) __________
```

[Original question page](assets/865ab25df7052bdc83fb47fa9967b1cd8b63640346cf0b21a0027d0162392fd8.jpg)

### Part 3

<!-- Source: /api/assets/a9eaad1c72f43e0a00de3a0cd8d41f8f411fb277ff58f1d3e3508266d1d6b0f7.jpg; PDF page 85; full -->

```text
SECTION3 Questions21–30
Questions21–26: Complete the table below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Experiment number | Equipment | Purpose
Experiment1 |(21) __________ and a table|To show how things move on a cushion of air
Experiment2 |Lots of paperclips|To show why we need standard (22) __________
Experiment3 |(23) __________ and a jar of water|To show how (24) __________ grow
Experiment4 |Cardboard,coloured pens and a (25) __________|To teach children about how (26) __________ is made up
Experiment5 |A drill,an old record,a pin/needle,paper,a bolt|To make a record player in order to learn about recording sound
```

[Original question page](assets/a9eaad1c72f43e0a00de3a0cd8d41f8f411fb277ff58f1d3e3508266d1d6b0f7.jpg)

<!-- Source: /api/assets/dd7d24a76866d79ab2a0ea27c5289836707101037c4ae6b7afd2b917a1e224cf.jpg; PDF page 86; full -->

```text
Questions 27-30 
What problems do the speakers identify for each experiment? 
Choose your answers from the box and write the letters A-H next to questions 27-30. 
Problems 
A too messy 
B too boring 
C too difficult 
D too much equipment 
E too long 
F too easy [example] 
G too noisy 
H too dangerous 
Experiment 1: 27 .............. . 
Experiment 2: 28 ..... ......... . 
Experiment 3: 29 ....... ....... . 
Experiment 4: Example F 
Experiment 5: 30 .............. . 
85
```

[Original question page](assets/dd7d24a76866d79ab2a0ea27c5289836707101037c4ae6b7afd2b917a1e224cf.jpg)

### Part 4

<!-- Source: /api/assets/2f4373b6c0035f5371dc921e51df89331c89677fdb086d79cbdcdc51dda80ae1.jpg; PDF page 87; full -->

```text
SECTION4 Questions31–40
Questions31–34: Complete the notes below. Write NO MORE THAN THREE WORDS AND/OR A NUMBER for each answer.
Sharks in Australia
Length—largest caught:16metres
Weight—heaviest:(31) __________kg
Skeleton—cartilage
Skin texture—rough barbs
Swimming aids—fins and (32) __________
Food—gathered from the ocean (33) __________;sharks locate food by using their (34) __________
```

[Original question page](assets/2f4373b6c0035f5371dc921e51df89331c89677fdb086d79cbdcdc51dda80ae1.jpg)

<!-- Source: /api/assets/83b50c9c981493231efbb155b84b4c13936cb9d380e92e38a34e8f122e53243d.jpg; PDF page 88; full -->

```text
Questions 35-38 
Choose the correct letter, A, B or C 
35 Shark meshing uses nets laid 
A along the coastline. 
B at an angle to the beach. 
C from the beach to the sea. 
36 Other places that have taken up shark meshing include 
A South Africa. 
B New Zealand. 
C Tahiti. 
37 The average number of sharks caught in nets each year is 
A 15. 
B 150. 
C 1,500. 
38 Most sharks are caught in 
A spring. 
B summer. 
C winter. 
Questions 39 and 40 
Choose TWO letters A-G 
Which TWO factors reduce the benefits of shark nets? 
A nets wrongly positioned 
B strong waves and currents 
C too many fish 
D sharks eat holes in nets 
E moving sands 
F nets too short 
G holes in nets scare sharks 
87
```

[Original question page](assets/83b50c9c981493231efbb155b84b4c13936cb9d380e92e38a34e8f122e53243d.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/37e9d5783926b85895c32f50dfb6f6ee77fe4e819731250b372a7d326ea3b7c3.jpg; PDF page 89; full -->

```text
READING 
READING PASSAGE 1 
You should spend about 20 minutes on Questions 1-13 which are based on Reading Passage 1 
below. · 
88 
How much higher? How much faster?
- Limits to human sporting performance are not yet in sight -
Since the early years of the 
twentieth century. when 
the International Athletic 
Federation began keeping 
records, there has been a 
steady improvement in 
how fast athletes run, how 
high they jump and how 
far they are able to hurl 
massive objects, them­
selves included, through 
space. For the so-called 
power events - that 
require a relatively brief, explosive release of 
energy, like the 100-metre sprint and the long 
jump - times and distances have improved ten 
to twenty per cent In the endurance events 
the results have been more dramatic. At the 
1908 Olympics, John Hayes of the U.S. team 
ran a marathon in a time of 2:55:18. In 1999, 
Morocco's Khalid Khannouchi set a new world 
record of 2:05:42, almost thirty per cent faster: 
No one theory can explain improvements in 
performance, but the most important factor 
has been genetics. 'The athlete must choose his 
parents carefully.' says Jesus Dapena, a sports 
scientist at Indiana University, invoking an oft-
cited adage. Over the past century. the com­
position of the human gene pool has not 
changed appreciably. but with increasing global 
participation in athletics - and greater rewards 
to tempt athletes - it is more likely that indi­
viduals possessing the unique complement of 
genes for athletic performance can be identi­
fied early. 'Was there someone like [sprinter] 
Michael Johnson in the 1920s?' Dapena asks. 
'I'm sure there was, but his talent was probably 
never realised.' 
Identifying genetically talented individuals is 
only the first step. Michael Yessis, an emeritus 
professor of Sports Science at California State 
University at Fullerton, maintains that 'genetics 
only determines about one third of what an 
athlete can do. But with the right training we 
can go much further with that one third than 
we've been going.' Yessis believes that U.S. 
runners, despite their impressive achieve­
ments, are 'running on their genetics'. By apply­
ing more scientific methods, 'they're going to 
go much faster'. These methods include 
strength training that duplicates what they are 
doing in their running events as well as plyo­
metrics, a technique pioneered in the former 
Soviet Union.
```

[Original question page](assets/37e9d5783926b85895c32f50dfb6f6ee77fe4e819731250b372a7d326ea3b7c3.jpg)

<!-- Source: /api/assets/794e66a5abaa9d111c74f6cd4cddd6db35c0c25ef3c9c8211a148c0d0568f712.jpg; PDF page 90; full -->

```text
Whereas most exercises are designed to build 
up strength or endurance, plyometrics focuses 
on increasing power - the rate at which an 
athlete can expend energy. When a sprinter 
runs, Yessis explains, her foot stays in contact 
with the ground for just under a tenth of a 
second, half of which is devoted to landing and 
the other half to pushing off. Plyometric exer­
cises help athletes make the best use of this 
brief interval. 
Nutrition is another area that sports trainers 
have failed to address adequately. 'Many ath­
letes are not getting the best nutrition, even 
through supplements;' Yessis insists. Each activ­
ity has its own nutritional needs. Few coaches, 
for instance, understand how deficiencies in 
trace minerals can lead to injuries. 
Focused training will also play a role in enabling 
records to be broken. 'If we applied the Russian 
training model to some of the outstanding 
runners we have in this country.' Yessis asserts, 
'they would be breaking records left and right.' 
He will not predict by how much, however: 
'Exactly what the limits are it's hard to say. but 
there will be increases even if only by hun­
dredths of a second, as long as our training 
continues to improve.' 
One of the most important new methodolo­
gies is biomechanics, the study of the body in 
motion. A biomechanic films an athlete in 
action and then digitizes her performance, 
recording the motion of every joint and limb in 
three dimensions. By applying Newton 's laws 
to these motions, 'we can say that this athlete's 
run is not fast enough; that this one is not using 
his arms strongly enough during take-off,' says 
Dapena, who uses these methods to help high 
jumpers: To date, however; biomechanics has 
made only a small difference to athletic per­
formance. 
Revolutionary ideas still come from the ath­
letes themselves. For example, during the 1968 
Olympics in Mexico City. a relatively unknown 
high jumper named Dick Fosbury won the gold 
by going over the bar backwards, in complete 
contradiction of all the received high-jumping 
wisdom, a move instantly dubbed the Fosbury 
flop. Fosbury himself did not know what he 
was doing. That understanding took the later 
analysis of biomechanics specialists, who put 
their minds to comprehending something that 
was too complex and unorthodox ever to 
have been invented through their own mathe­
matical simulations. Fosbury also required 
another element that lies behind many 
improvements in athletic performance: an 
innovation in athletic equipment In Fosbury's 
case, it was the cushions that jumpers land on. 
Traditionally. high jumpers would land in pits 
filled with sawdust. But by Fosbury's time, 
sawdust pits had been replaced by soft foam 
cushions, ideal for flopping. 
In the end, most people who examine human 
performance are humbled by the resourceful­
ness of athletes and the powers of the human 
body. 'Once you study athletics, you learn that 
it's a vexingly complex issue,' says John S. Raglin, 
a sports psychologist at Indiana University. 
'Core performance is not a simple or mundane 
thing of higher; faster; longer. So many variables 
enter into the equation, and our understanding 
in many cases is fundamental. We've got a long 
way to go.' For the foreseeable future, records 
will be made to be broken. 
89
```

[Original question page](assets/794e66a5abaa9d111c74f6cd4cddd6db35c0c25ef3c9c8211a148c0d0568f712.jpg)

<!-- Source: /api/assets/736906adbec61e48c3d200858b2a29433d9de5f215b29bbb4f67629b4e4d34f0.jpg; PDF page 91; full -->

```text
Questions 1-6 
Do the following statements agree with the information given in Reading Passage 1? 
In boxes 1-6 on your answer sheet write 
TRUE if the statement agrees with the information 
FALSE if the statement contradicts the information 
NOT GIVEN if there is no information on this 
1 Modern official athletic records date from about 1900. 
2 There was little improvement in athletic performance before the twentieth century. 
3 Performance has improved most greatly in events requiring an intensive burst of energy. 
4 Improvements in athletic performance can be fully explained by genetics. 
5 The parents of top athletes have often been successful athletes themselves. 
6 The growing international importance of athletics means that gifted athletes can be 
recognised at a younger age. 
Questions7–10
Complete the sentences below with words taken from Reading Passage1. Use ONE WORD for each answer. Write your answers in boxes7–10 on your answer sheet.
7 According to Professor Yessis,American runners are relying for their current success on __________.
8 Yessis describes a training approach from the former Soviet Union that aims to develop an athlete’s __________.
9 Yessis links an inadequate diet to __________.
10 Yessis claims that the key to setting new records is better __________.
```

[Original question page](assets/736906adbec61e48c3d200858b2a29433d9de5f215b29bbb4f67629b4e4d34f0.jpg)

<!-- Source: /api/assets/9da9356ce3ad7fa5d56b1f19f57c83d41778307a3db60f41245ba87484736bfe.jpg; PDF page 92; full -->

```text
Questions 11-13 
Choose the correct letter, A, B, C or D. 
Write your answers in boxes 11-13 on your answer sheet. 
11 Biomechanics films are proving particularly useful because they enable trainers to 
A highlight areas for improvement in athletes. 
B assess the fitness levels of athletes. 
C select top athletes. 
D predict the success of athletes. 
12 Biomechanics specialists used theoretical models to 
A soften the Fosbury flop. 
B create the Fosbury flop. 
C correct the Fosbury flop. 
D explain the Fosbury flop. 
13 John S. Raglin believes our current knowledge of athletics is 
A mistaken. 
B basic. 
C diverse. 
D theoretical. 
91
```

[Original question page](assets/9da9356ce3ad7fa5d56b1f19f57c83d41778307a3db60f41245ba87484736bfe.jpg)

<!-- Source: /api/assets/08da426d9974af1b6eb37296d74d0dd339c14f68f638d2d856c2dea76cf5c3ad.jpg; PDF page 93; full -->

```text
READING PASSAGE 2



You should spend about 20 minutes on Questions 14-27 which are based on Reading Passage 2

below.



THE NATURE AND AIMS OF ARCHAEOLOGY

Archaeology is partly the discovery of the treasures of the past, partly the careful work of the scientific analyst, partly the exercise of the creative imagination. It is toiling in the sun on an excavation in the Middle East, it is working with living Inuit in the snows of Alaska, and it is investigating

the sewers of Roman Britain. But it is also the painstaking task of interpretation, so that we come

to understand what these things mean for the human story. And it is the conservation of the

world’s cultural heritage against looting and careless harm.



Archaeology, then, is both a physical activity out in the field, and an intellectual pursuit in the study

or laboratory. That is part of its great attraction. The rich mixture of danger and detective work has

also made it the perfect vehicle for fiction writers and film-makers, from Agatha Christie with

Murder in Mesopotamia to Stephen Spielberg with Indiana Jones. However far from reality such

portrayals are, they capture the essential truth that archaeology is an exciting quest — the quest for

knowledge about ourselves and our past.



But how does archaeology relate to disciplines such as anthropology and history, that are also

concerned with the human story? Is archaeology itself a science? And what are the responsibilities of the archaeologist in today’s world?



Anthropology, at its broadest, is the study of humanity — our physical characteristics as animals

and our unique non-biological characteristics that we call culture. Culture in this sense includes

what the anthropologist, Edward Tylor, summarised in 1871 as ‘knowledge, belief, art, morals,

custom and any other capabilities and habits acquired by man as a member of society’.

Anthropologists also use the term ‘culture’ in a more restricted sense when they refer to the

‘culture’ of a particular society, meaning the non-biological characteristics unique to that society,

which distinguish it from other societies. Anthropology is thus a broad discipline — so broad that

it is generally broken down into three smaller disciplines: physical anthropology, cultural anthropology and archaeology.



92
```

[Original question page](assets/08da426d9974af1b6eb37296d74d0dd339c14f68f638d2d856c2dea76cf5c3ad.jpg)

<!-- Source: /api/assets/0af9eb57bb20f7cf460ebb06fc6992cf65ffdb7dd4ffc7a96b1d5135d510c9fc.jpg; PDF page 94; full -->

```text
Physical anthropology, or biological anthropology as it is also called, concerns the study of human

biological or physical characteristics and how they evolved. Cultural anthropology — or social

anthropology — analyses human culture and society. Two of its branches are ethnography (the

study at first hand of individual living cultures) and ethnology (which sets out to compare cultures

using ethnographic evidence to derive general principles about human society).



Archaeology is the ‘past tense of cultural anthropology’. Whereas cultural anthropologists will

often base their conclusions on the experience of living within contemporary communities,

archaeologists study past societies primarily through their material remains — the buildings, tools,

and other artefacts that constitute what is known as the material culture left over from former societies.



Nevertheless, one of the most important tasks for the archaeologist today is to know how to interpret material culture in human terms. How were those pots used? Why are some dwellings round

and others square? Here the methods of archaeology and ethnography overlap. Archaeologists

in recent decades have developed ‘ethnoarchaeology’, where, like ethnographers, they live

among contemporary communities, but with the specific purpose of learning how such societies

use material culture — how they make their tools and weapons, why they build their settlements

where they do, and so on. Moreover, archaeology has an active role to play in the field of conservation. Heritage studies constitutes a developing field, where it is realised that the world’s cultural heritage is a diminishing resource which holds different meanings for different people.



If, then, archaeology deals with the past, in what way does it differ from history? In the broadest

sense, just as archaeology is an aspect of anthropology, so too is it a part of history — where we

mean the whole history of humankind from its beginnings over three million years ago. Indeed,

for more than ninety-nine per cent of that huge span of time, archaeology — the study of past material culture — is the only significant source of information. Conventional historical sources begin

only with the introduction of written records around 3000 BC in western Asia, and much later in

most other parts of the world.



A commonly drawn distinction is between pre-history, i.e. the period before written records —

and history in the narrow sense, meaning the study of the past using written evidence. To archaeology, which studies all cultures and periods, whether with or without writing, the distinction

between history and pre-history is a convenient dividing line that recognises the importance of

the written word, but in no way lessens the importance of the useful information contained in oral

histories.



Since the aim of archaeology is the understanding of humankind, it is a humanistic study, and since

it deals with the human past, it is a historical discipline. But it differs from the study of written

history in a fundamental way. The material the archaeologist finds does not tell us directly what to

think. Historical records make statements, offer opinions and pass judgements. The objects the

archaeologists discover, on the other hand, tell us nothing directly in themselves. In this respect,

the practice of the archaeologist is rather like that of the scientist, who collects data, conducts

experiments, formulates a hypothesis, tests the hypothesis against more data, and then, in conclusion, devises a model that seems best to summarise the pattern observed in the data. The

archaeologist has to develop a picture of the past, just as the scientist has to develop a coherent

view of the natural world,



93
```

[Original question page](assets/0af9eb57bb20f7cf460ebb06fc6992cf65ffdb7dd4ffc7a96b1d5135d510c9fc.jpg)

<!-- Source: /api/assets/ff753727fc8ad6583626df9513b38522445195206c15cb81bcb11eef4e503368.jpg; PDF page 95; full -->

```text
Questions 14-19 
Do the following statements agree with the claims of the writer in Reading Passage 2? 
In boxes 14- 19 on your answer sheet write 
YES if the statement agrees with the claims of the writer 
NO if the statement contradicts the claims of the writer 
NOT GIVEN if it is impossible to say what the writer thinks about this 
14 Archaeology involves creativity as well as careful investigative work. 
15 Archaeologists must be able to translate texts from ancient languages. 
16 Movies give a realistic picture of the work of archaeologists. 
17 Anthropologists define culture in more than one way. 
18 Archaeology is a more demanding field of study than anthropology. 
19 The history of Europe has been documented since 3000 BC. 
Questions 20 and 21 
Choose TWO letters A-E. 
Write your answers in boxes 20 and 21 on your answer sheet. 
The list below gives some statements about anthropology. 
Which TWO statements are mentioned by the writer of the text? 
94 
A It is important for government planners. 
B It is a continually growing field of study. 
C It often involves long periods of fieldwork. 
D It is subdivided for study purposes. 
E It studies human evolutionary patterns .
```

[Original question page](assets/ff753727fc8ad6583626df9513b38522445195206c15cb81bcb11eef4e503368.jpg)

<!-- Source: /api/assets/08462ae9888402e82c630f75f0dd37ff390b7f7af2bca5ccf65ab94c552a6d8d.jpg; PDF page 96; full -->

```text
Questions 22 and 23 
Choose TWO letters A-E. 
Write your answers in boxes 22 and 23 on your answer sheet. 
The list below gives some of the tasks of an archaeologist. 
Which TWO of these tasks are mentioned by the writer of the text? 
A examining ancient waste sites to investigate diet 
B studying cave art to determine its significance 
C deducing reasons for the shape of domestic buildings 
D investigating the way different cultures make and use objects 
E examining evidence for past climate changes 
Questions 24-27 
Complete the summary of the last two paragraphs of Reading Passage 2. 
Choose NO MORE THAN TWO WORDS from the passage for each answer. 
Write your answers in boxes 24-27 on your answer sheet. 
Much of the work of archaeologists can be done using written records but they find 24 ... .. . 
equally valuable. The writer describes archaeology as both a 25 ... ... and a 26 ...... . However, 
as archaeologists do not try to influence human behaviour, the writer compares their style of 
working to that of a 27 ...... . 
95
```

[Original question page](assets/08462ae9888402e82c630f75f0dd37ff390b7f7af2bca5ccf65ab94c552a6d8d.jpg)

<!-- Source: /api/assets/647f4ee27c2d761bce8fee71818f5f676d2eb706b1e4d017f40cb346373c237a.jpg; PDF page 97; full -->

```text
READING PASSAGE3
You should spend about20minutes on Questions28–40 which are based on Reading Passage3 on the following pages.
Questions28–31: Reading Passage3 has five sections A–E.
Choose the correct heading for sections A and C–E from the list of headings below. Write the correct number i–viii in boxes28–31 on your answer sheet.
List of Headings
i The connection between health-care and other human rights
ii The development of market-based health systems
iii The role of the state in health-care
iv A problem shared by every economically developed country
v The impact of recent change
vi The views of the medical establishment
vii The end of an illusion
viii Sustainable economic development
28 SectionA
Example: SectionB—viii [as printed in supplied original]
29 SectionC
30 SectionD
31 SectionE
```

[Original question page](assets/647f4ee27c2d761bce8fee71818f5f676d2eb706b1e4d017f40cb346373c237a.jpg)

<!-- Source: /api/assets/5d7faeab3ebda369fbe8fb722abc9335cb160ea9dd21f94ae6247fb5259ae0c2.jpg; PDF page 98; full -->

```text
The Problem of 
Scarce Resources 
Section A 
The problem of how health-care resources should be allocated or apportioned, so that 
they are distributed in both the most just and most efficient way, is not a new one. 
Every health system in an economically developed society is faced with the need to 
decide (either formally or informally) what proportion of the community' s total 
resources should be spent on health-care; how resources are to be apportioned; what 
diseases and disabilities and which forms of treatment are to be given priority; which 
members of the community are to be given special consideration in respect of their 
health needs; and which forms of treatment are the most cost-effective. 
Section B 
What is new is that, from the 1950s onwards, there have been certain general changes 
in outlook about the finitude of resources as a whole and of health-care resources in 
particular, as well as more specific changes regarding the clientele of health-care 
resources and the cost to the community of those resources. Thus, in the 1950s and 
1960s , there emerged an awareness in Western societies that resources for the provi­
sion of fossil fuel energy were finite and exhaustible and that the capacity of nature 
or the environment to sustain economic development and population was also finite. 
In other words, we became aware of the obvious fact that there were 'limits to 
growth'. The new consciousness that there were also severe limits to health -care 
resources was part of this general revelation of the obvious . Looking back, it now 
seems quite incredible that in the national health systems that emerged in many coun­
tries in the years immediately after the 1939-45 World War, it was assumed without 
question that all the basic health needs of any community could be satisfied, at least 
in principle; the 'invisible hand' of economic progress would provide. 
Section C 
However, at exactly the same time as this new realisation of the finite character of 
health -care resources was sinking in, an awareness of a contrary kind was developing 
in Western societies: that people have a basic right to health-care as a necessary con­
dition of a proper human life. Like education, political and legal processes and insti­
tutions, public order, communication, transport and money supply, health-care came 
to be seen · as one of the fundamental social facilities necessary for people to exercise 
97
```

[Original question page](assets/5d7faeab3ebda369fbe8fb722abc9335cb160ea9dd21f94ae6247fb5259ae0c2.jpg)

<!-- Source: /api/assets/43c47624bbaea9591a2c335e0dd0f029fbb09e2b0b97ea38d11d0694f083110b.jpg; PDF page 99; full -->

```text
their other rights as autonomous human beings. People are not in a position to exer­
cise personal liberty and to be self-determining if they are poverty-stricken, or 
deprived of basic education, or do not live within a context of law and order. In the 
same way, basic health-care is a condition of the exercise of autonomy. 
Section D 
Although the language of'rights' sometimes leads to confusion, by the late 1970s it 
was recognised in most societies that people have a right to health-care (though there 
has been considerable resistance in the United States to the idea that there is a formal 
right to health-care). It is also accepted that this right generates an obligation or duty 
for the state to ensure that adequate health-care resources are provided out of the 
public purse. The state has no obligation to provide a health-care system itself, but to 
ensure that such a system is provided. Put another way, basic health-care is now recog­
nised as a 'public good', rather than a 'private good' that one is expected to buy for 
oneself. As the 1976 declaration of the World Health Organisation put it: 'The enjoy­
ment of the highest attainable standard of health is one of the fundamental rights of 
every human being without distinction of race, religion, political belief, economic or 
social condition.' As has just been remarked, in a liberal society basic health is seen as 
one of the indispensable conditions for the exercise of personal autonomy . 
Section E 
Just at the time when it became obvious that health-care resources could not possi­
bly meet the demands being made upon them, people were demanding that their fun­
damental right to health-care be satisfied by the state. The second set of more specific 
changes that have led to the present concern about the distribution of health-care 
resources stems from the dramatic rise in health costs in most OECD1 countries, 
accompanied by large-scale demographic and social changes which have meant, to 
take one example, that elderly people are now major (and relatively very expensive) 
consumers of health-care resources. Thus in OECD countries as a whole, health costs 
increased from 3.8% of GDP2 in 1960 to 7% of GDP in 1980, and it has been pre­
dicted that the proportion of health costs to GDP will continue to increase. (In the US 
the current figure is about 12% of GDP, and in Australia about 7.8% of GDP.) 
As a consequence, during the 1980s a kind of doomsday scenario (analogous to 
similar doomsday extrapolations about energy needs and fossil fuels or about popu­
lation increases) was projected by health administrators, economists and politicians . 
In this scenario, ever-rising health costs were matched against static or declining 
resources . 
1 Organisation for Economic Cooperation and Development 
2 Gross Domestic Product 
98
```

[Original question page](assets/43c47624bbaea9591a2c335e0dd0f029fbb09e2b0b97ea38d11d0694f083110b.jpg)

<!-- Source: /api/assets/376414a7b1b5df5e29ae42bcd08cd047858e0d7b7ab8b79f9d30a312c72181c0.jpg; PDF page 100; full -->

```text
Questions 32-35 
Classify the following as first occurring 
A between 1945 and 1950 
B between 1950 and 1980 
C after 1980 
Write the correct letter A, B or C in boxes 32- 35 on your answer sheet. 
32 the realisation that the resources of the national health systems were limited 
33 a sharp rise in the cost of health-care 
34 a belief that all the health-care resources the community needed would be produced by 
economic growth · 
35 an acceptance of the role of the state in guaranteeing the provision of health-care 
Questions 36-40 
Do the following statements agree with the views of the writer in Reading Passage 3? 
In boxes 36--40 on your answer sheet write 
YES if the statement agrees with the views of the writer 
NO if the statement contradicts the views of the writer 
NOT GIVEN if it is impossible to say what the writer thinks about this 
36 Personal liberty and independence have never been regarded as directly linked to 
health-care. 
37 Health-care came to be seen as a right at about the same time that the limits of health­
care resources became evident. 
38 In OECD countries population changes have had an impact on health-care costs in 
recent years. 
39 OECD governments have consistently underestimated the level of health-care provision 
needed. 
40 In most economically developed countries the elderly will have to make special 
provision for their health-care in the future. 
99
```

[Original question page](assets/376414a7b1b5df5e29ae42bcd08cd047858e0d7b7ab8b79f9d30a312c72181c0.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/012bc5bc103f00787a36d447bdead423d247becbf6e250410ea29d4855d396d4.jpg; PDF page 101; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The charts below give information about travel to and from the UK, and about the most popular countries for UK residents to visit.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original table or chart is retained below.]
```

[Original question page](assets/012bc5bc103f00787a36d447bdead423d247becbf6e250410ea29d4855d396d4.jpg)

![Original figure](assets/012bc5bc103f00787a36d447bdead423d247becbf6e250410ea29d4855d396d4.jpg)

### Task 2

<!-- Source: /api/assets/96a82b1d7c9cbd05e9371ee4797f7fe76a10fafc73020c8735f32efd73e215dd.jpg; PDF page 102; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In many countries schools have severe problems with student behaviour.

What do you think are the causes of this?

What solutions can you suggest?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/96a82b1d7c9cbd05e9371ee4797f7fe76a10fafc73020c8735f32efd73e215dd.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/a4ff5023041e04fbd5592a4197d7237cb3c909d32fdf39fdbe11268effd5c464.jpg; PDF page 103; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself. his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Your favourite place 
• What place do you most like to visit? 
• How often do you visit this place? 
• Why do you like it so much? · 
• Is it popular with many other people? 
• Has it changed very much since you first went there? [In what way?] 
PART 2 
Describe a useful website you have visited. 
You should say: 
what the website was 
how you found the address for this website 
what the website contained 
and explain why it was useful to you. 
You will have to talk about 
the topic for one to two 
minutes. 
You have one minute to 
think about what you're 
going to say. 
You can make some notes 
to help you if you wish. 

PART 3 
Discussion topics: 
The Internet and communication 
Example questions: 
What effect has the Internet had on the way people generally communicate with each other? 
Why do you think the Internet is being used more and more for communication? 
How reliable do you think information from the Internet is? Why? What about the news on 
the Internet? 
The Internet and shopping 
Example questions: 
Why do you think some people use the Internet for shopping? Why doesn't everyone use it in 
this way? 
What kinds of things are easy to buy and sell online? Can you give me some examples? 
Do you think shopping on the Internet will be more or less popular in the future? Why? 
102
```

[Original question page](assets/a4ff5023041e04fbd5592a4197d7237cb3c909d32fdf39fdbe11268effd5c464.jpg)

### Part 2

<!-- Source: /api/assets/a4ff5023041e04fbd5592a4197d7237cb3c909d32fdf39fdbe11268effd5c464.jpg; PDF page 103; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself. his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Your favourite place 
• What place do you most like to visit? 
• How often do you visit this place? 
• Why do you like it so much? · 
• Is it popular with many other people? 
• Has it changed very much since you first went there? [In what way?] 
PART 2 
Describe a useful website you have visited. 
You should say: 
what the website was 
how you found the address for this website 
what the website contained 
and explain why it was useful to you. 
You will have to talk about 
the topic for one to two 
minutes. 
You have one minute to 
think about what you're 
going to say. 
You can make some notes 
to help you if you wish. 

PART 3 
Discussion topics: 
The Internet and communication 
Example questions: 
What effect has the Internet had on the way people generally communicate with each other? 
Why do you think the Internet is being used more and more for communication? 
How reliable do you think information from the Internet is? Why? What about the news on 
the Internet? 
The Internet and shopping 
Example questions: 
Why do you think some people use the Internet for shopping? Why doesn't everyone use it in 
this way? 
What kinds of things are easy to buy and sell online? Can you give me some examples? 
Do you think shopping on the Internet will be more or less popular in the future? Why? 
102
```

[Original question page](assets/a4ff5023041e04fbd5592a4197d7237cb3c909d32fdf39fdbe11268effd5c464.jpg)

### Part 3

<!-- Source: /api/assets/a4ff5023041e04fbd5592a4197d7237cb3c909d32fdf39fdbe11268effd5c464.jpg; PDF page 103; full -->

```text
SPEAKING 
PART 1 
The examiner asks the candidate about him/herself. his/her home, work or studies and other 
familiar topics. 
EXAMPLE 
Your favourite place 
• What place do you most like to visit? 
• How often do you visit this place? 
• Why do you like it so much? · 
• Is it popular with many other people? 
• Has it changed very much since you first went there? [In what way?] 
PART 2 
Describe a useful website you have visited. 
You should say: 
what the website was 
how you found the address for this website 
what the website contained 
and explain why it was useful to you. 
You will have to talk about 
the topic for one to two 
minutes. 
You have one minute to 
think about what you're 
going to say. 
You can make some notes 
to help you if you wish. 

PART 3 
Discussion topics: 
The Internet and communication 
Example questions: 
What effect has the Internet had on the way people generally communicate with each other? 
Why do you think the Internet is being used more and more for communication? 
How reliable do you think information from the Internet is? Why? What about the news on 
the Internet? 
The Internet and shopping 
Example questions: 
Why do you think some people use the Internet for shopping? Why doesn't everyone use it in 
this way? 
What kinds of things are easy to buy and sell online? Can you give me some examples? 
Do you think shopping on the Internet will be more or less popular in the future? Why? 
102
```

[Original question page](assets/a4ff5023041e04fbd5592a4197d7237cb3c909d32fdf39fdbe11268effd5c464.jpg)
