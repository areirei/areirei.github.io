# 剑雅 18 · Test 3 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 125

TEST 3 LISTENING
1 Marrowfield
2 relative
3 socialise / socialize
4 full
5 Domestic Life
6 clouds
7 timing
8 Animal Magic
9 (animal) movement
10 dark
11 B
12 C
13 B
14 D
15 C
16 B
17 B
18 C
19 A
20 A
21 A
22 E
23 B
24 D
25 G
26 E
27 B
28 C
29 F
30 A
31 technical
32 cheap
33 thousands
34 identification
35 tracking
36 military
37 location
38 prediction
39 database
40 trust
11&12 IN EITHER ORDER: B,C
13&14 IN EITHER ORDER: B,D
21&22 IN EITHER ORDER: A,E
23&24 IN EITHER ORDER: B,D
If you score: 0–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. Marrowfield

2. relative

3. socialise / socialize

4. full

5. Domestic Life

6. clouds

7. timing

8. Animal Magic

9. movement / animal movement

10. dark

### Part 2 · source page 125

TEST 3 LISTENING
1 Marrowfield
2 relative
3 socialise / socialize
4 full
5 Domestic Life
6 clouds
7 timing
8 Animal Magic
9 (animal) movement
10 dark
11 B
12 C
13 B
14 D
15 C
16 B
17 B
18 C
19 A
20 A
21 A
22 E
23 B
24 D
25 G
26 E
27 B
28 C
29 F
30 A
31 technical
32 cheap
33 thousands
34 identification
35 tracking
36 military
37 location
38 prediction
39 database
40 trust
11&12 IN EITHER ORDER: B,C
13&14 IN EITHER ORDER: B,D
21&22 IN EITHER ORDER: A,E
23&24 IN EITHER ORDER: B,D
If you score: 0–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. B / C

12. B / C

13. B / D

14. B / D

15. C

16. B

17. B

18. C

19. A

20. A

### Part 3 · source page 125

TEST 3 LISTENING
1 Marrowfield
2 relative
3 socialise / socialize
4 full
5 Domestic Life
6 clouds
7 timing
8 Animal Magic
9 (animal) movement
10 dark
11 B
12 C
13 B
14 D
15 C
16 B
17 B
18 C
19 A
20 A
21 A
22 E
23 B
24 D
25 G
26 E
27 B
28 C
29 F
30 A
31 technical
32 cheap
33 thousands
34 identification
35 tracking
36 military
37 location
38 prediction
39 database
40 trust
11&12 IN EITHER ORDER: B,C
13&14 IN EITHER ORDER: B,D
21&22 IN EITHER ORDER: A,E
23&24 IN EITHER ORDER: B,D
If you score: 0–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. A / E

22. A / E

23. B / D

24. B / D

25. G

26. E

27. B

28. C

29. F

30. A

### Part 4 · source page 125

TEST 3 LISTENING
1 Marrowfield
2 relative
3 socialise / socialize
4 full
5 Domestic Life
6 clouds
7 timing
8 Animal Magic
9 (animal) movement
10 dark
11 B
12 C
13 B
14 D
15 C
16 B
17 B
18 C
19 A
20 A
21 A
22 E
23 B
24 D
25 G
26 E
27 B
28 C
29 F
30 A
31 technical
32 cheap
33 thousands
34 identification
35 tracking
36 military
37 location
38 prediction
39 database
40 trust
11&12 IN EITHER ORDER: B,C
13&14 IN EITHER ORDER: B,D
21&22 IN EITHER ORDER: A,E
23&24 IN EITHER ORDER: B,D
If you score: 0–18 unlikely;19–28 may;29–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. technical

32. cheap

33. thousands

34. identification

35. tracking

36. military

37. location

38. prediction

39. database

40. trust

## A 类阅读

### Academic Reading · source page 126

TEST 3 READING
1 G
2 D
3 C
4 F
5 architects
6 moisture
7 layers
8 speed
9 C
10 A
11 B
12 D
13 A
14 iii
15 viii
16 vi
17 v
18 vii
19 i
20 iv
21 A
22 C
23 B
24 speed
25 fifty / 50
26 strict
27 B
28 A
29 C
30 C
31 H
32 D
33 F
34 E
35 B
36 NO
37 NOT GIVEN
38 YES
39 NO
40 NOT GIVEN
If you score: 0–17 unlikely;18–26 may;27–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. G

2. D

3. C

4. F

5. architects

6. moisture

7. layers

8. speed

9. C

10. A

11. B

12. D

13. A

14. iii

15. viii

16. vi

17. v

18. vii

19. i

20. iv

21. A

22. C

23. B

24. speed

25. fifty / 50

26. strict

27. B

28. A

29. C

30. C

31. H

32. D

33. F

34. E

35. B

36. NO

37. NOT GIVEN

38. YES

39. NO

40. NOT GIVEN

## A 类写作

### Writing material: c18-t3-w-1

Central Library entrance bottom centre in both plans.20years ago: northwest CDs/videos/computer games room; northeast children’s books room; adult fiction west; adult nonfiction east; southwest reading room(newspapers/magazines); southeast enquiry desk(tickets,book returns,etc); tables/chairs middle. Today: northwest children’s fiction/storytelling events with two sofas; northeast lecture room; west all reference books; east adult fiction,information desk,self-service machines; southwest computer room; southeast cafe. Central tables/chairs removed; entrance retained. No compass or dates supplied beyond20years ago/today; do not invent book collection totals or relocate entrance.



### Writing material: c18-t3-w-2

Evaluate rural-to-urban migration and declining countryside population. Causes may support analysis but the explicit task is positive/negative evaluation, not merely reasons for urban growth.



## 口语
