# 剑雅 18 · Test 3

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/e781e3ec48b0384e4ed2d7b33536bde64211e7cfc89077cc909fe09c3e1fad80.jpg; PDF page 57; full -->

```text
PART 1 Questions 1–10
Questions 1–4
Complete the form below. Write ONE WORD AND/OR A NUMBER for each answer.
Wayside Camera Club membership form
Name: Dan Green
Email address: dan1068@market.com
Home address: 52 (1) __________ Street, Peacetown
Heard about us: from a (2) __________
Reasons for joining: to enter competitions; to (3) __________
Type of membership: (4) __________ membership (£30)
Questions 5–10
Complete the table below. Write NO MORE THAN TWO WORDS for each answer.
Photography competitions
| Title of competition | Instructions | Feedback to Dan |
| --- | --- | --- |
| (5) ‘__________’ | A scene in the home | The picture’s composition was not good. |
| ‘Beautiful Sunsets’ | Scene must show some (6) __________ | The (7) __________ was wrong. |
| (8) ‘__________’ | Scene must show (9) __________ | The photograph was too (10) __________. |
```

[Original question page](assets/e781e3ec48b0384e4ed2d7b33536bde64211e7cfc89077cc909fe09c3e1fad80.jpg)

### Part 2

<!-- Source: /api/assets/45421792c1822a4e33567f0592c7d5a6f77f303c18752ccaf726a7b272ed6d7d.jpg; PDF page 58; full -->

```text
PART 2 Questions 11–20
Questions 11 and 12
Choose TWO letters, A–E.
Which TWO warnings does Dan give about picking mushrooms?
A Don’t pick more than one variety of mushroom at a time.
B Don’t pick mushrooms near busy roads.
C Don’t eat mushrooms given to you.
D Don’t eat mushrooms while picking them.
E Don’t pick old mushrooms.
Questions 13 and 14
Choose TWO letters, A–E.
Which TWO ideas about wild mushrooms does Dan say are correct?
A Mushrooms should always be peeled before eating.
B Mushrooms eaten by animals may be unsafe.
C Cooking destroys toxins in mushrooms.
D Brightly coloured mushrooms can be edible.
E All poisonous mushrooms have a bad smell.
```

[Original question page](assets/45421792c1822a4e33567f0592c7d5a6f77f303c18752ccaf726a7b272ed6d7d.jpg)

<!-- Source: /api/assets/65377eeb6b2e9abe85189f3ad4c854b2500df396e3180bf3e07f0973d7aebe81.jpg; PDF page 59; full -->

```text
Questions 15-20
Choose the correct letter, A, B or C.






15 What advice does Dan give about picking mushrooms in parks?
A Choose wooded areas.
B Don’t disturb wildlife.
C Get there early.
16 Dan says it is a good idea for beginners to
A use a mushroom app.
B join a group.
C take a reference book.
17 What does Dan say is important for conservation?
A selecting only fully grown mushrooms
B picking a limited amount of mushrooms
C avoiding areas where rare mushroom species grow
18 According to Dan, some varieties of wild mushrooms are in decline because there is
A a huge demand for them from restaurants.
B a lack of rain in this part of the country.
C a rise in building developments locally.
19 Dan says that when storing mushrooms, people should
A keep them in the fridge for no more than two days.
B keep them in a brown bag in a dark room.
C leave them for a period after washing them.
20 What does Dan say about trying new varieties of mushrooms?
A Experiment with different recipes.
B Expect some to have a strong taste.
C Cook them for a long time.
```

[Original question page](assets/65377eeb6b2e9abe85189f3ad4c854b2500df396e3180bf3e07f0973d7aebe81.jpg)

### Part 3

<!-- Source: /api/assets/1b0d118219f170d979c0536b374dff812260db029bc1dd8932083ce90c8b41c9.jpg; PDF page 60; full -->

```text
PART 3 Questions 21–30
Questions 21 and 22
Choose TWO letters, A–E.
Which TWO opinions about the Luddites do the students express?
A Their actions were ineffective.
B They are still influential today.
C They have received unfair criticism.
D They were proved right.
E Their attitude is understandable.
Questions 23 and 24
Choose TWO letters, A–E.
Which TWO predictions about the future of work are the students doubtful about?
A Work will be more rewarding.
B Unemployment will fall.
C People will want to delay retiring.
D Working hours will be shorter.
E People will change jobs more frequently.
```

[Original question page](assets/1b0d118219f170d979c0536b374dff812260db029bc1dd8932083ce90c8b41c9.jpg)

<!-- Source: /api/assets/bba8ee84e74d75bacfb3d9bc47df3a3791677b8939aa3160cafdf16eb8f838ae.jpg; PDF page 61; full -->

```text
Questions 25–30
What comment do the students make about each of the following jobs?
Choose SIX answers from the box and write the correct letter, A–G, next to Questions 25–30.
Comments
A These jobs are likely to be at risk.
B Their role has become more interesting in recent years.
C The number of people working in this sector has fallen dramatically.
D This job will require more qualifications.
E Higher disposable income has led to a huge increase in jobs.
F There is likely to be a significant rise in demand for this service.
G Both employment and productivity have risen.
Jobs
25 Accountants __________
26 Hairdressers __________
27 Administrative staff __________
28 Agricultural workers __________
29 Care workers __________
30 Bank clerks __________
```

[Original question page](assets/bba8ee84e74d75bacfb3d9bc47df3a3791677b8939aa3160cafdf16eb8f838ae.jpg)

### Part 4

<!-- Source: /api/assets/d4d258bd294921e613b3a693b025a15ee91cdb9adb7b05872fc65ae7e2f837c7.jpg; PDF page 62; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
Space Traffic Management
A Space Traffic Management system
• is a concept similar to Air Traffic Control, but for satellites rather than planes.
• would aim to set up legal and (31) __________ ways of improving safety.
• does not actually exist at present.
Problems in developing effective Space Traffic Management
• Satellites are now quite (32) __________ and therefore more widespread (e.g. there are constellations made up of (33) __________ of satellites).
• At present, satellites are not required to transmit information to help with their (34) __________.
• There are few systems for (35) __________ satellites.
• Small pieces of debris may be difficult to identify.
• Operators may be unwilling to share details of satellites used for (36) __________ or commercial reasons.
• It may be hard to collect details of the object’s (37) __________ at a given time.
• Scientists can only make a (38) __________ about where the satellite will go.
Solutions
• Common standards should be agreed on for the presentation of information.
• The information should be combined in one (39) __________.
• A coordinated system must be designed to create (40) __________ in its users.
```

[Original question page](assets/d4d258bd294921e613b3a693b025a15ee91cdb9adb7b05872fc65ae7e2f837c7.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/caec68a1543ff70e459a57aedba354db5e407f92349c5c66032e5386de4afaef.jpg; PDF page 63; full -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Materials to take us beyond concrete
Concrete is everywhere, but it’s bad for the planet, generating large amounts of carbon
dioxide — alternatives are being developed
A Concrete is the second most used substance in the global economy, after water — and one
of the world’s biggest single sources of greenhouse gas emissions. The chemical process
by which cement, the key ingredient of concrete, is created results in large quantities of
carbon dioxide. The UN estimates that there will be 9.8 billion people living on the planet
by mid-century. They will need somewhere to live. If concrete is the only answer to the
construction of new cities, then carbon emissions will soar, aggravating global warming.
And so scientists have started innovating with other materials, in a scramble for alternatives
to a universal commodity that has underpinned our modern life for many years.
B The problem with replacing concrete is that it is so very good at what it does.
Chris Cheeseman, an engineering professor at Imperial College London, says the key
thing to consider is the extent to which concrete is used around the world, and is likely to
continue to be used. ‘Concrete is not a high-carbon product. Cement is high carbon, but
concrete is not. But it is the scale on which it is used that makes it high carbon. The sheer
scale of manufacture is so huge, that is the issue.’
C Not only are the ingredients of concrete relatively cheap and found in abundance in most
places around the globe, the stuff itself has marvellous properties: Portland cement, the
vital component of concrete, is mouldable and pourable, but quickly sets hard. Cheeseman
also notes another advantage: concrete and steel have similar thermal expansion properties,
so steel can be used to reinforce concrete, making it far stronger and more flexible as a
building material than it could be on its own. According to Cheeseman, all these factors
together make concrete hard to beat. ‘Concrete is amazing stuff. Making anything with
similar properties is going to be very difficult.’
D A possible alternative to concrete is wood. Making buildings from wood may seem like a
rather medieval idea, but climate change is driving architects to turn to treated timber as
a possible resource. Recent years have seen the emergence of tall buildings constructed
almost entirely from timber. Vancouver, Vienna and Brumunddal in Norway are all home to
constructed tall, wooden buildings.
```

[Original question page](assets/caec68a1543ff70e459a57aedba354db5e407f92349c5c66032e5386de4afaef.jpg)

<!-- Source: /api/assets/1891407601b14fc8848f50680768e8f784836a93f29f84e408f05dc2278eca25.jpg; PDF page 64; full -->

```text
Test 3
E Using wood to construct buildings, however, is not straightforward. Wood expands as it
absorbs moisture from the air and is susceptible to pests, not to mention fire. But treating
wood and combining it with other materials can improve its properties. Cross-laminated
timber is engineered wood. An adhesive is used to stick layers of solid-sawn timber
together, crosswise, to form building blocks. This material is light but has the strength of
concrete and steel. Construction experts say that wooden buildings can be constructed at a
greater speed than ones of concrete and steel and the process, it seems, is quieter.
F Stora Enso is Europe’s biggest supplier of cross-laminated timber, and its vice-president
Markus Mannström reports that the company is seeing increasing demand globally for
building in wood, with climate change concerns the key driver. Finland, with its large
forests, where Stora Enso is based, has been leading the way, but the company is seeing
a rise in demand for its timber products across the world, including in Asia. Of course,
using timber in a building also locks away the carbon that it absorbed as it grew. But even
treated wood has its limitations and only when a wider range of construction projects has
been proven in practice will it be possible to see wood as a real alternative to concrete in
constructing tall buildings.
G Fly ash and slag from iron ore are possible alternatives to cement in a concrete mix. Fly ash,
a byproduct of coal-burning power plants, can be incorporated into concrete mixes to make
up as much as 15 to 30% of the cement, without harming the strength or durability of the
resulting mix. Iron-ore slag, a byproduct of the iron-ore smelting process, can be used in a
similar way. Their incorporation into concrete mixes has the potential to reduce greenhouse
gas emissions.
But Anna Surgenor, of the UK’s Green Building Council, notes that although these waste
products can save carbon in the concrete mix, their use is not always straightforward.
‘It’s possible to replace the cement content in concrete with waste products to lower the
overall carbon impact. But there are several calculations that need to be considered across
the entire life cycle of the building — these include factoring in where these materials are
being shipped from. If they are transported over long distances, using fossil fuels, the use of
alternative materials might not make sense from an overall carbon reduction perspective.’
H While these technologies are all promising ideas, they are either unproven or based on
materials that are not abundant. In their overview of innovation in the concrete industry,
Felix Preston and Johanna Lehne of the UK’s Royal Institute of International Affairs
reached the conclusion that, ‘Some novel cements have been discussed for more than
a decade within the research community, without breaking through. At present, these
alternatives are rarely as cost-effective as conventional cement, and they face raw-material
shortages and resistance from customers.’
```

[Original question page](assets/1891407601b14fc8848f50680768e8f784836a93f29f84e408f05dc2278eca25.jpg)

<!-- Source: /api/assets/a7fea54a8c10cade3f719d77ece7043860534f5c584285a68b94fe743ceabd0a.jpg; PDF page 65; full -->

```text
Questions 1–4
Reading Passage 1 has eight sections, A–H.
Which section contains the following information?
Write the correct letter, A–H, in boxes 1–4 on your answer sheet.
1 an explanation of the industrial processes that create potential raw materials for concrete
2 a reference to the various locations where high-rise wooden buildings can be found
3 an indication of how widely available the raw materials of concrete are
4 the belief that more high-rise wooden buildings are needed before wood can be regarded as a viable construction material
Questions 5–8
Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 5–8 on your answer sheet.
Making buildings with wood
Wood is a traditional building material, but current environmental concerns are encouraging (5) __________ to use wood in modern construction projects. Using wood, however, has its challenges. For example, as (6) __________ in the atmosphere enters wood, it increases in size. In addition, wood is prone to pests and the risk of fire is greater. However, wood can be turned into a better construction material if it is treated and combined with other materials. In one process, (7) __________ of solid wood are glued together to create building blocks. These blocks are lighter than concrete and steel but equal them in strength. Experts say that wooden buildings are an improvement on those made of concrete and steel in terms of the (8) __________ with which they can be constructed and how much noise is generated by the process.
```

[Original question page](assets/a7fea54a8c10cade3f719d77ece7043860534f5c584285a68b94fe743ceabd0a.jpg)

<!-- Source: /api/assets/ffb4df5c23aa1fd4ade3238a5816dc815144a7f6a1e992753ea468db213d3944.jpg; PDF page 66; full -->

```text
Test 3
Questions 9-13
Look at the following statements (Questions 9-13) and the list of people below.
Match each statement with the correct person, A, B, C or D.
Write the correct letter, A, B, C or D, in boxes 9-13 on your answer sheet.
NB You may use any letter more than once.





9 The environmental advantage of cement alternatives may not be as great as
initially assumed.
10 It would be hard to create a construction alternative to concrete that offers so many
comparable benefits.
11 Worries about the environment have led to increased interest in wood as a
construction material.
12 Expense has been a factor in the negative response to the development of
new cements.
13 The environmental damage caused by concrete is due to it being produced in
large quantities.
List of People
A Chris Cheeseman
B Markus Mannström
C Anna Surgenor
D Felix Preston and Johanna Lehne
```

[Original question page](assets/ffb4df5c23aa1fd4ade3238a5816dc815144a7f6a1e992753ea468db213d3944.jpg)

<!-- Source: /api/assets/7e220f3df344be5fb6d41c96092ab649cd0a989e85422a8fe0f1777b5d535850.jpg; PDF page 67; full -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 on pages 66 and 67.
Questions 14-20
Reading Passage 2 has seven paragraphs, A-G.
Choose the correct heading for each paragraph from the list of headings below.
Write the correct number, i-viii, in boxes 14-20 on your answer sheet.
List of Headings
i A period in cold conditions before the technology
is assessed
ii Marketing issues lead to failure
iii Good and bad aspects of steam technology are
passed on
iv A possible solution to the issues of today
v Further improvements lead to commercial orders
vi Positive publicity at last for this quiet, clean, fast
vehicle
vii A disappointing outcome for customers
viii A better option than the steam car arises
14 Paragraph A
15 Paragraph B
16 Paragraph C
17 Paragraph D
18 Paragraph E
19 Paragraph F
20 Paragraph G
```

[Original question page](assets/7e220f3df344be5fb6d41c96092ab649cd0a989e85422a8fe0f1777b5d535850.jpg)

<!-- Source: /api/assets/14b4dd7f82a5a4777b77c734bbd8589cb919a49b859d5f792c9faf6d2226aaab.jpg; PDF page 68; full -->

```text
The steam car
The successes and failures of the Doble brothers and their steam cars
A When primitive automobiles first began to appear in the 1800s, their engines were based
on steam power. Steam had already enjoyed a long and successful career in the railways,
so it was only natural that the technology evolved into a miniaturized version which was
separate from the trains. But these early cars inherited steam’s weaknesses along with its
strengths. The boilers had to be lit by hand, and they required about twenty minutes to build
up pressure before they could be driven. Furthermore, their water reservoirs only lasted for
about thirty miles before needing replenishment. Despite such shortcomings, these newly
designed self-propelled carriages offered quick transportation, and by the early 1900s it was
not uncommon to see such machines shuttling wealthy citizens around town.
B But the glory days of steam cars were few. A new technology called the Internal
Combustion Engine soon appeared, which offered the ability to drive down the road just
moments after starting up. At first, these noisy gasoline cars were unpopular because they
were more complicated to operate and they had difficult hand-crank starters, which were
known to break arms when the engines backfired. But in 1912 General Motors introduced
the electric starter, and over the following few years steam power was gradually phased out.
C Even as the market was declining, four brothers made one last effort to rekindle the
technology. Between 1906 and 1909, while still attending high school, Abner Doble and his
three brothers built their first steam car in their parents’ basement. It comprised parts taken
from a wrecked early steam car but reconfigured to drive an engine of their own design.
Though it did not run well, the Doble brothers went on to build a second and third prototype
in the following years. Though the Doble boys’ third prototype, nicknamed the Model B,
still lacked the convenience of an internal combustion engine, it drew the attention of
automobile trade magazines due to its numerous improvements over previous steam cars.
The Model B proved to be superior to gasoline automobiles in many ways. Its high-pressure
steam drove the engine pistons in virtual silence, in contrast to clattering gas engines which
emitted the aroma of burned hydrocarbons. Perhaps most impressively, the Model B was
amazingly swift. It could accelerate from zero to sixty miles per hour in just fifteen seconds,
a feat described as ‘remarkable acceleration’ by Automobile magazine in 1914.
D The following year Abner Doble drove the Model B from Massachusetts to Detroit in order
to seek investment in his automobile design, which he used to open the General Engineering
Company. He and his brothers immediately began working on the Model C, which was
intended to expand upon the innovations of the Model B. The brothers added features such
as a key-based ignition in the cabin, eliminating the need for the operator to manually
ignite the boiler. With these enhancements, the Dobles’ new car company promised a steam
vehicle which would provide all of the convenience of a gasoline car, but with much greater
speed, much simpler driving controls, and a virtually silent powerplant. By the following
April, the General Engineering Company had received 5,390 deposits for Doble Detroits,
which were scheduled for delivery in early 1918.
```

[Original question page](assets/14b4dd7f82a5a4777b77c734bbd8589cb919a49b859d5f792c9faf6d2226aaab.jpg)

<!-- Source: /api/assets/41a4a682d342119894d09adf40b406155dea499fe80e576962a8ffee7b0c3ef0.jpg; PDF page 69; full -->

```text
E Later that year Abner Doble delivered unhappy news to those eagerly awaiting the delivery
of their modern new cars. Those buyers who received the handful of completed cars
complained that the vehicles were sluggish and erratic, sometimes going in reverse when
they should go forward. The new engine design, though innovative, was still plagued with
serious glitches.
F The brothers made one final attempt to produce a viable steam automobile. In early
1924, the Doble brothers shipped a Model E to New York City to be road-tested by the
Automobile Club of America. After sitting overnight in freezing temperatures, the car was
pushed out into the road and left to sit for over an hour in the frosty morning air. At the
turn of the key, the boiler lit and reached its operating pressure inside of forty seconds.
As they drove the test vehicle further, they found that its evenly distributed weight lent it
surprisingly good handling, even though it was so heavy. As the new Doble steamer was
further developed and tested, its maximum speed was pushed to over a hundred miles per
hour, and it achieved about fifteen miles per gallon of kerosene with negligible emissions.
G Sadly, the Dobles’ brilliant steam car never was a financial success. Priced at around
$18,000 in 1924, it was popular only among the very wealthy. Plus, it is said that no two
Model Es were quite the same, because Abner Doble tinkered endlessly with the design. By
the time the company folded in 1931, fewer than fifty of the amazing Model E steam cars
had been produced. For his whole career, until his death in 1961, Abner Doble remained
adamant that steam-powered automobiles were at least equal to gasoline cars, if not
superior. Given the evidence, he may have been right. Many of the Model E Dobles which
have survived are still in good working condition, some having been driven over half a
million miles with only normal maintenance. Astonishingly, an unmodified Doble Model E
runs clean enough to pass the emissions laws in California today, and they are pretty strict.
It is true that the technology poses some difficult problems, but you cannot help but wonder
how efficient a steam car might be with the benefit of modern materials and computers.
Under the current pressure to improve automotive performance and reduce emissions, it is
not unthinkable that the steam car may rise again.
```

[Original question page](assets/41a4a682d342119894d09adf40b406155dea499fe80e576962a8ffee7b0c3ef0.jpg)

<!-- Source: /api/assets/24caa400d444af9949ecbe54b21c42735b3f3a2997a57f8c37eda07db3e405b2.jpg; PDF page 70; full -->

```text
Test 3
Questions 21-23
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 21-23 on your answer sheet.




21 What point does the writer make about the steam car in Paragraph B?
A Its success was short-lived.
B Not enough cars were made.
C Car companies found them hard to sell.
D People found them hard to drive.
22 When building their first steam car, the Doble brothers
A constructed all the parts themselves.
B made written notes at each stage of the construction.
C needed several attempts to achieve a competitive model.
D sought the advice of experienced people in the car industry.
23 In order to produce the Model C, the Doble brothers
A moved production to a different city.
B raised financial capital.
C employed an additional worker.
D abandoned their earlier designs.
```

[Original question page](assets/24caa400d444af9949ecbe54b21c42735b3f3a2997a57f8c37eda07db3e405b2.jpg)

<!-- Source: /api/assets/5288c7719bccc2ec8b91987a3b2bbdf3393a3d1e16a3941eb704da614b4359c3.jpg; PDF page 71; full -->

```text
Questions 24–26
Complete the summary below. Choose ONE WORD AND/OR A NUMBER from the passage for each answer.
Write your answers in boxes 24–26 on your answer sheet.
The Model E
The Model E was road-tested in 1924 by the Automobile Club of America. They found it easy to drive, despite its weight, and it impressed the spectators. A later version of the Model E raised its (24) __________, while keeping its emissions extremely low.
The steam car was too expensive for many people and its design was constantly being altered. Under (25) __________ cars were produced before the company went out of business. However, even today, there are Model Es on the road in the US. They are straightforward to maintain, and they satisfy California’s (26) __________ emissions laws. Perhaps today’s technology and materials would help us revive the steam car.
```

[Original question page](assets/5288c7719bccc2ec8b91987a3b2bbdf3393a3d1e16a3941eb704da614b4359c3.jpg)

<!-- Source: /api/assets/e664c2494438ab0ccca9ac158528f3d26bb31d2379f58a9833b1654990731df6.jpg; PDF page 72; full -->

```text
Test 3
READING PASSAGE 3

You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
The case for mixed-ability classes
Picture this scene. It’s an English literature
lesson in a UK school, and the teacher has just
read an extract from Shakespeare’s Romeo
and Juliet with a class of 15-year-olds. He’s
given some of the students copies of No Fear
Shakespeare, a kid-friendly translation of the
original. For three students, even these literacy
demands are beyond them. Another girl
simply can’t focus and he gives her pens and
paper to draw with. The teacher can ask the
No Fear group to identify the key characters
and maybe provide a tentative plot summary.
He can ask most of the class about character
development, and five of them might be able to
support their statements with textual evidence.
Now two curious students are wondering
whether Shakespeare advocates living a life of
moderation or one of passionate engagement.
As a teacher myself, I’d think my lesson would
be going rather well if the discussion went as
described above. But wouldn’t this kind of
class work better if there weren’t such a huge
gap between the top and the bottom? If we put
all the kids who needed literacy support into
one class, and all the students who want to
discuss the virtue of moderation into another?
The practice of ‘streaming’, or ‘tracking’,
involves separating students into classes
depending on their diagnosed levels of
attainment. At a macro level, it requires the
establishment of academically selective
schools for the brightest students, and
comprehensive schools for the rest. Within
schools, it means selecting students into a
‘stream’ of general ability, or ‘sets’ of subject-
specific ability. The practice is intuitively
appealing to almost every stakeholder.
I have heard the mixed-ability model attacked
by way of analogy: a group hike. The fittest
in the group take the lead and set a brisk pace,
only to have to stop and wait every 20 minutes.
This is frustrating, and their enthusiasm wanes.
Meanwhile, the slowest ones are not only
embarrassed but physically struggling to keep
up. What’s worse, they never get a long enough
break. They honestly just want to quit. Hiking,
they feel, is not for them.
Mixed-ability classes bore students, frustrate
parents and burn out teachers. The brightest
ones will never summit Mount Qomolangma, and
the stragglers won’t enjoy the lovely stroll in the
park they are perhaps more suited to. Individuals
suffer at the demands of the collective, mediocrity
prevails. So: is learning like hiking?
The current pedagogical paradigm is arguably
that of constructivism, which emerged out of
the work of psychologist Lev Vygotsky. In the
1930s, Vygotsky emphasised the importance of
targeting a student’s specific ‘zone of proximal
development’ (ZPD). This is the gap between
what they can achieve only with support
— teachers, textbooks, worked examples,
parents and so on — and what they can achieve
independently. The purpose of teaching is
to provide and then gradually remove this
‘scaffolding’ until they are autonomous. If we
accept this model, it follows that streaming
students with similar ZPDs would be an
efficient and effective solution. And that
forcing everyone on the same hike — regardless
of aptitude — would be madness.
Despite all this, there is limited empirical
evidence to suggest that streaming results in
```

[Original question page](assets/e664c2494438ab0ccca9ac158528f3d26bb31d2379f58a9833b1654990731df6.jpg)

<!-- Source: /api/assets/3efd3979134f526e38293e4d30fcae42e0014ea624f5971b52b4fb374a77d5bd.jpg; PDF page 73; full -->

```text
better outcomes for students. Professor John
Hattie, director of the Melbourne Education
Research Institute, notes that ‘tracking has
minimal effects on learning outcomes’. What
is more, streaming appears to significantly
—and negatively — affect those students
assigned to the lowest sets. These students
tend to have much higher representation of low
socioeconomic class. Less significant is the
small benefit for those lucky clever students
in the higher sets. The overall result is that the
smart stay smart and the dumb get dumber,
further entrenching the social divide.
In the latest update of Hattie’s influential
meta-analysis of factors influencing
student achievement, one of the most
significant factors is the teachers’ estimate
of achievement. Streaming students by
diagnosed achievement automatically limits
what the teacher feels the student is capable of.
Meanwhile, in a mixed environment, teachers’
estimates need to be more diverse and flexible.
While streaming might seem to help teachers
effectively target a student’s ZPD, it can
underestimate the importance of peer-to-peer
learning. A crucial aspect of constructivist
theory is the role of the MKO — ‘more-
knowledgeable other’ — in knowledge
construction. While teachers are traditionally

the MKOs in classrooms, the value of
knowledgeable student peers must not go
unrecognised either.
I find it amazing to watch students get over an
idea to their peers in ways that I would never
think of. They operate with different language
tools and different social tools from teachers
and, having just learnt it themselves, they
possess similar cognitive structures to their
struggling classmates. There is also something
exciting about passing on skills and knowledge
that you yourself have just mastered — a certain
pride and zeal, a certain freshness to the
interaction between ‘teacher’ and ‘learner’ that
is often lost by the expert for whom the steps
are obvious and the joy of discovery forgotten.
Having a variety of different abilities in a
collaborative learning environment provides
valuable resources for helping students meet
their learning needs, not to mention improving
their communication and social skills. And
today, more than ever, we need the many to
flourish — not suffer at the expense of a few
bright stars. Once a year, I go on a hike with
my class, a mixed bunch of students. It is
challenging. The fittest students realise they
need to encourage the reluctant. There are
lookouts who report back, and extra items to
carry for others. We make it — together.
```

[Original question page](assets/3efd3979134f526e38293e4d30fcae42e0014ea624f5971b52b4fb374a77d5bd.jpg)

<!-- Source: /api/assets/18a7f833739fbb6329cf4725ad54592098936ae38787030aba9e573c24049714.jpg; PDF page 74; full -->

```text
Test 3
Questions 27-30
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-30 on your answer sheet.
27 The writer describes the Romeo and Juliet lesson in order to demonstrate
A how few students are interested in literature.
B how a teacher handles a range of learning needs.
C how unsuitable Shakespeare is for most teenagers.
D how weaker students can disrupt their classmates’ learning.
28 What does the writer say about streaming in the third paragraph?
A It has a very broad appeal.
B It favours cleverer students.
C It is relatively simple to implement.
D It works better in some schools than others.
29 What idea is suggested by the reference to Mount Qomolangma in the fifth paragraph?
A students following unsuitable paths
B students attempting interesting tasks
C students not achieving their full potential
D students not being aware of their limitations
30 What does the word ‘scaffolding’ in the sixth paragraph refer to?
A the factors which prevent a student from learning effectively
B the environment where most of a student’s learning takes place
C the assistance given to a student in their initial stages of learning
D the setting of appropriate learning targets for a student’s aptitude
```

[Original question page](assets/18a7f833739fbb6329cf4725ad54592098936ae38787030aba9e573c24049714.jpg)

<!-- Source: /api/assets/f29c8ddf767701f16563553f3ff0cf29583140b56497a227763b4e69471ffa1d.jpg; PDF page 75; full -->

```text
Questions 31–35
Complete the summary using the list of phrases, A–I, below.
Write the correct letter, A–I, in boxes 31–35 on your answer sheet.
Is streaming effective?
According to Professor John Hattie of the Melbourne Education Research Institute, there is very little indication that streaming leads to (31) __________. He points out that, in schools which use streaming, the most significant impact is on those students placed in the (32) __________, especially where a large proportion of them have (33) __________. Meanwhile, for the (34) __________, there appears to be only minimal advantage. A further issue is that teachers tend to have (35) __________ of students in streamed groups.
A wrong classes
B lower expectations
C average learners
D bottom sets
E brightest pupils
F disadvantaged backgrounds
G weaker students
H higher achievements
I positive impressions
```

[Original question page](assets/f29c8ddf767701f16563553f3ff0cf29583140b56497a227763b4e69471ffa1d.jpg)

<!-- Source: /api/assets/a2e7c201f8aef7b9e95b3eecef9ff737d5f246e148ab0d526a43cd6024533113.jpg; PDF page 76; full -->

```text
Test 3
Questions 36-40
Do the following statements agree with the views of the writer in Reading Passage 3?
In boxes 36-40 on your answer sheet, write
YES if the statement agrees with the views of the writer
NO if the statement contradicts the views of the writer
NOT GIVEN if it is impossible to say what the writer thinks about this
36 The Vygotsky model of education supports the concept of a mixed-ability class.
37 Some teachers are uncertain about allowing students to take on MKO roles in the
classroom.
38 It can be rewarding to teach knowledge which you have only recently acquired.
39 The priority should be to ensure that the highest-achieving students attain their
goals.
40 Taking part in collaborative outdoor activities with teachers and classmates can
improve student outcomes in the classroom.
```

[Original question page](assets/a2e7c201f8aef7b9e95b3eecef9ff737d5f246e148ab0d526a43cd6024533113.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/b16ae9e4ef117c98e191ea6d1303de39d675802489f5de326ea5f91f1ba14ba6.jpg; PDF page 77; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The diagram below shows the floor plan of a public library 20 years ago and how it looks now.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/b16ae9e4ef117c98e191ea6d1303de39d675802489f5de326ea5f91f1ba14ba6.jpg)

![Original figure](assets/b16ae9e4ef117c98e191ea6d1303de39d675802489f5de326ea5f91f1ba14ba6.jpg)

### Task 2

<!-- Source: /api/assets/3e312248e61176cec1bdb38e143035a03fac20abc3731eb516a0d1f9f969d11e.jpg; PDF page 78; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In many countries around the world, rural people are moving to cities, so the population in the countryside is decreasing.

Do you think this is a positive or a negative development?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/3e312248e61176cec1bdb38e143035a03fac20abc3731eb516a0d1f9f969d11e.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/e1e4ea206a5a61a85e14f278b70bc0893d4ba8a63758e91b7a48b4ff2d4af36c.jpg; PDF page 79; full -->

```text
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Online shopping
e How often do you buy things online? [Why?]
e What was the last thing you bought online?
e Do you ever see things in shops and then buy them online? [Why/Why not?]
e Do you think the popularity of online shopping is changing your town or city centre?
[Why/Why not?]
PART 2
Describe a time when you enjoyed visiting a member of your family in their home.
You should say:
who you visited and where they lived
why you made this visit
what happened during this visit
and explain what you enjoyed about this visit.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Family occasions
Example questions:
When do families celebrate together in your country?
How often do all the generations in a family come together in your country?
Why is it that some people might not enjoy attending family occasions?
Everyday life in families
Example questions:
Do you think it is a good thing for parents to help their children with schoolwork?
How important do you think it is for families to eat together at least once a day?
Do you believe that everyone in a family should share household tasks?
```

[Original question page](assets/e1e4ea206a5a61a85e14f278b70bc0893d4ba8a63758e91b7a48b4ff2d4af36c.jpg)

### Part 2

<!-- Source: /api/assets/e1e4ea206a5a61a85e14f278b70bc0893d4ba8a63758e91b7a48b4ff2d4af36c.jpg; PDF page 79; full -->

```text
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Online shopping
e How often do you buy things online? [Why?]
e What was the last thing you bought online?
e Do you ever see things in shops and then buy them online? [Why/Why not?]
e Do you think the popularity of online shopping is changing your town or city centre?
[Why/Why not?]
PART 2
Describe a time when you enjoyed visiting a member of your family in their home.
You should say:
who you visited and where they lived
why you made this visit
what happened during this visit
and explain what you enjoyed about this visit.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Family occasions
Example questions:
When do families celebrate together in your country?
How often do all the generations in a family come together in your country?
Why is it that some people might not enjoy attending family occasions?
Everyday life in families
Example questions:
Do you think it is a good thing for parents to help their children with schoolwork?
How important do you think it is for families to eat together at least once a day?
Do you believe that everyone in a family should share household tasks?
```

[Original question page](assets/e1e4ea206a5a61a85e14f278b70bc0893d4ba8a63758e91b7a48b4ff2d4af36c.jpg)

### Part 3

<!-- Source: /api/assets/e1e4ea206a5a61a85e14f278b70bc0893d4ba8a63758e91b7a48b4ff2d4af36c.jpg; PDF page 79; full -->

```text
PART 1
The examiner asks you about yourself, your home, work or studies and other familiar
topics.
EXAMPLE
Online shopping
e How often do you buy things online? [Why?]
e What was the last thing you bought online?
e Do you ever see things in shops and then buy them online? [Why/Why not?]
e Do you think the popularity of online shopping is changing your town or city centre?
[Why/Why not?]
PART 2
Describe a time when you enjoyed visiting a member of your family in their home.
You should say:
who you visited and where they lived
why you made this visit
what happened during this visit
and explain what you enjoyed about this visit.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Family occasions
Example questions:
When do families celebrate together in your country?
How often do all the generations in a family come together in your country?
Why is it that some people might not enjoy attending family occasions?
Everyday life in families
Example questions:
Do you think it is a good thing for parents to help their children with schoolwork?
How important do you think it is for families to eat together at least once a day?
Do you believe that everyone in a family should share household tasks?
```

[Original question page](assets/e1e4ea206a5a61a85e14f278b70bc0893d4ba8a63758e91b7a48b4ff2d4af36c.jpg)
