# 剑雅 2 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 71

Answer key
LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are stated in the Key.)
0-18
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
19-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 Black
2 2085
3 9456 1309
4 2020BD
5 July
6–8 B, D, F (in any order)
9 $25/twenty-five dollars (refundable)
10 next week // in a week // in one week // the
following week
Section 2, Questions 11-20
11 route book
12 900/nine hundred miles NOT 900
13 North/N Africa NOT Africa
14 A
15 C
16–18 B, C, E (in any order)
19–20 B, D (in either order)
If you score...
Section 3, Questions 21-30
21 (on) Friday
22 Biology
23 57/fifty-seven (books)
24 43/forty-three (books)
25 Wed/Wednesday NOT the day after
26 (she) record(s) them/lectures // she use(s) a
(tape/cassette) recorder/recording
27 skimming // (he) skims (books)/(a book) //.
skim (the) book first // skim reading
28 (The) French Revolution
29 Why study history(?)
30 animal language // (the) language of
animals NOT language
Section 4, Questions 31-40
31 4/four-month certificate/cert (course)
32 (current) employment // job
33 1/one-year diploma //ACCEPT dyploma
34 none // no (prior) qualifications/quals
35 6/six-month certificate/cert (course)
36 C
37 F
38 B
39 G
40 D

1. Black

2. 2085

3. 9456 1309 / 94561309

4. 2020BD

5. July

6. B / D / F

7. B / D / F

8. B / D / F

9. $ 25 / $25 / twenty-five dollars / twenty-five dollars refundable

10. next week / in a week / in one week / the following week

### Part 2 · source page 71

Answer key
LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are stated in the Key.)
0-18
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
19-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 Black
2 2085
3 9456 1309
4 2020BD
5 July
6–8 B, D, F (in any order)
9 $25/twenty-five dollars (refundable)
10 next week // in a week // in one week // the
following week
Section 2, Questions 11-20
11 route book
12 900/nine hundred miles NOT 900
13 North/N Africa NOT Africa
14 A
15 C
16–18 B, C, E (in any order)
19–20 B, D (in either order)
If you score...
Section 3, Questions 21-30
21 (on) Friday
22 Biology
23 57/fifty-seven (books)
24 43/forty-three (books)
25 Wed/Wednesday NOT the day after
26 (she) record(s) them/lectures // she use(s) a
(tape/cassette) recorder/recording
27 skimming // (he) skims (books)/(a book) //.
skim (the) book first // skim reading
28 (The) French Revolution
29 Why study history(?)
30 animal language // (the) language of
animals NOT language
Section 4, Questions 31-40
31 4/four-month certificate/cert (course)
32 (current) employment // job
33 1/one-year diploma //ACCEPT dyploma
34 none // no (prior) qualifications/quals
35 6/six-month certificate/cert (course)
36 C
37 F
38 B
39 G
40 D

11. route book

12. 900 miles / nine hundred miles

13. North Africa / N Africa

14. A

15. C

16. B / C / E

17. B / C / E

18. B / C / E

19. B / D

20. B / D

### Part 3 · source page 71

Answer key
LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are stated in the Key.)
0-18
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
19-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 Black
2 2085
3 9456 1309
4 2020BD
5 July
6–8 B, D, F (in any order)
9 $25/twenty-five dollars (refundable)
10 next week // in a week // in one week // the
following week
Section 2, Questions 11-20
11 route book
12 900/nine hundred miles NOT 900
13 North/N Africa NOT Africa
14 A
15 C
16–18 B, C, E (in any order)
19–20 B, D (in either order)
If you score...
Section 3, Questions 21-30
21 (on) Friday
22 Biology
23 57/fifty-seven (books)
24 43/forty-three (books)
25 Wed/Wednesday NOT the day after
26 (she) record(s) them/lectures // she use(s) a
(tape/cassette) recorder/recording
27 skimming // (he) skims (books)/(a book) //.
skim (the) book first // skim reading
28 (The) French Revolution
29 Why study history(?)
30 animal language // (the) language of
animals NOT language
Section 4, Questions 31-40
31 4/four-month certificate/cert (course)
32 (current) employment // job
33 1/one-year diploma //ACCEPT dyploma
34 none // no (prior) qualifications/quals
35 6/six-month certificate/cert (course)
36 C
37 F
38 B
39 G
40 D

21. Friday / on Friday

22. Biology

23. 57 / 57 books / fifty-seven / fifty-seven books

24. 43 / 43 books / forty-three / forty-three books

25. Wed / Wednesday

26. record them / records them / she record them / she records them / record lectures / records lectures / she record lectures / she records lectures / she use a recorder / she use a tape recorder / she use a cassette recorder / she uses a recorder / she uses a tape recorder / she uses a cassette recorder / recording

27. skimming / skims / skims books / he skims / he skims books / skims a book / he skims a book / skim book first / skim the book first / skim reading

28. French Revolution / The French Revolution

29. Why study history / Why study history?

30. animal language / language of animals / the language of animals

### Part 4 · source page 71

Answer key
LISTENING
Each question correctly answered scores 1 mark. CORRECT SPELLING NEEDED IN ALL
ANSWERS. ( Where alternative spellings are accepted, these are stated in the Key.)
0-18
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
19-25
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
26-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Section 1, Questions 1-10
1 Black
2 2085
3 9456 1309
4 2020BD
5 July
6–8 B, D, F (in any order)
9 $25/twenty-five dollars (refundable)
10 next week // in a week // in one week // the
following week
Section 2, Questions 11-20
11 route book
12 900/nine hundred miles NOT 900
13 North/N Africa NOT Africa
14 A
15 C
16–18 B, C, E (in any order)
19–20 B, D (in either order)
If you score...
Section 3, Questions 21-30
21 (on) Friday
22 Biology
23 57/fifty-seven (books)
24 43/forty-three (books)
25 Wed/Wednesday NOT the day after
26 (she) record(s) them/lectures // she use(s) a
(tape/cassette) recorder/recording
27 skimming // (he) skims (books)/(a book) //.
skim (the) book first // skim reading
28 (The) French Revolution
29 Why study history(?)
30 animal language // (the) language of
animals NOT language
Section 4, Questions 31-40
31 4/four-month certificate/cert (course)
32 (current) employment // job
33 1/one-year diploma //ACCEPT dyploma
34 none // no (prior) qualifications/quals
35 6/six-month certificate/cert (course)
36 C
37 F
38 B
39 G
40 D

31. 4-month certificate / 4-month certificate course / four-month certificate / four-month certificate course / 4-month cert / 4-month cert course / four-month cert / four-month cert course

32. employment / current employment / job

33. 1-year diploma / one-year diploma / 1-year dyploma / one-year dyploma

34. none / no qualifications / no prior qualifications / no quals / no prior quals

35. 6-month certificate / 6-month certificate course / six-month certificate / six-month certificate course / 6-month cert / 6-month cert course / six-month cert / six-month cert course

36. C

37. F

38. B

39. G

40. D

## A 类阅读

### Academic Reading · source page 71

ACADEMIC READING
Each question correctly answered scores 1 mark.
0-13
you are highly unlikely to get
an acceptable score under
examination conditions and we
recommend that you spend a
lot of time improving your
English before you take IELTS
14-22
you may get an acceptable
score under examination
conditions but we recommend
that you think about having
more practice or lessons before
you take IELTS
23-40
you are likely to get an
acceptable score under
examination conditions but
remember that different
institutions will find different
scores acceptable
Reading Passage 1, Questions 1-13
1 A
2 A
3 B
4 C
5 B
6 runways and taxiways
7 terminal building site
8 sand
9 stiff clay
10–11 Lantau Island; sea walls (in either order)
12 rainfall
13 geotextile
Reading Passage 2, Questions 14-27
14 viii
15 ii
16 iv
17 ix
18 vii
19 1946
If you score...
20 (the) wealthy (members) (of) (society)
21 social, economic, environmental
22 (the) 1970s
23 NOT GIVEN
24 YES
25 NO
26 NO
27 NOT GIVEN
Reading Passage 3, Questions 28-40
28 CH
29 MC
30 MC
31 SH
32 SH
33 MC
34 HTK
35 SH
36 NOT GIVEN
37 YES
38 YES
39 YES
40 NO

1. A

2. A

3. B

4. C

5. B

6. runways taxiways / runways, taxiways / runways and taxiways / runways & taxiways / runways; taxiways / runways/taxiways / runways,taxiways / taxiways runways / taxiways, runways / taxiways and runways / taxiways & runways / taxiways; runways / taxiways/runways / taxiways,runways

7. terminal building site

8. sand

9. stiff clay

10. Lantau Island / sea walls

11. Lantau Island / sea walls

12. rainfall

13. geotextile

14. viii

15. ii

16. iv

17. ix

18. vii

19. 1946

20. wealthy / wealthy society / wealthy of / wealthy of society / wealthy members / wealthy members society / wealthy members of / wealthy members of society / the wealthy / the wealthy society / the wealthy of / the wealthy of society / the wealthy members / the wealthy members society / the wealthy members of / the wealthy members of society

21. social economic environmental / social, economic, environmental / social and economic and environmental / social & economic & environmental / social; economic; environmental / social/economic/environmental / social,economic,environmental / social, economic and environmental / social environmental economic / social, environmental, economic / social and environmental and economic / social & environmental & economic / social; environmental; economic / social/environmental/economic / social,environmental,economic / social, environmental and economic / economic social environmental / economic, social, environmental / economic and social and environmental / economic & social & environmental / economic; social; environmental / economic/social/environmental / economic,social,environmental / economic, social and environmental / economic environmental social / economic, environmental, social / economic and environmental and social / economic & environmental & social / economic; environmental; social / economic/environmental/social / economic,environmental,social / economic, environmental and social / environmental social economic / environmental, social, economic / environmental and social and economic / environmental & social & economic / environmental; social; economic / environmental/social/economic / environmental,social,economic / environmental, social and economic / environmental economic social / environmental, economic, social / environmental and economic and social / environmental & economic & social / environmental; economic; social / environmental/economic/social / environmental,economic,social / environmental, economic and social

22. 1970s / the 1970s

23. NOT GIVEN

24. YES

25. NO

26. NO

27. NOT GIVEN

28. CH

29. MC

30. MC

31. SH

32. SH

33. MC

34. HTK

35. SH

36. NOT GIVEN

37. YES

38. YES

39. YES

40. NO

## A 类写作

### Writing material: c2-t1-w-1

Original table inspected at full resolution, including blanks. Units: percentage of households owning each consumer durable in Britain. Columns: 1972, 1974, 1976, 1978, 1979, 1981, 1982, 1983. Rows in that order: central heating [unreadable: source literally prints 3?],43,48,52,55,59,60,64; television 93,95,96,96,97,97,97,98; video blank,blank,blank,blank,blank,blank,blank,18; vacuum cleaner 87,89,92,92,93,94,95,blank; refrigerator 73,81,88,91,92,93,93,94; washing machine 66,68,71,75,74,78,79,80; dishwasher blank,blank,blank,3,3,4,4,5; telephone 42,50,54,60,67,75,76,77. Blanks are missing entries, not zero ownership. Television is most widespread throughout; telephone and central heating increase strongly; dishwasher ownership remains low; washing machine ownership briefly dips in 1979. Do not reconstruct the damaged 1972 central-heating value from memory or infer the missing vacuum-cleaner value in 1983.



### Writing material: c2-t1-w-2

Opinion task: respond to the stated claim and justify the chosen position; no particular stance is required.



## 口语

### 原书口语任务 · reference on source page 13

Information for the Examiner:
what e-mail is means by which to send messages from one
computer to another over the telephone lines
cost free for students at this language school
how to obtain an e-mail address complete an application form and return to
Student Services
location of e-mail at school in the independent learning centre or
computer laboratory
equipment needed at home a modem and a telephone line
courses on e-mail Friday afternoon classes throughout the year

[Complete original page](assets/d5767efd7d6add6e3f5b80b376abf052c71146da0d5a479a2cb43c5657b7c658.jpg)
