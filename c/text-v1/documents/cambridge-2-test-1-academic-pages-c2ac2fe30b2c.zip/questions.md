# 剑雅 2 · Test 1

Text edition · verified

> Part 1: source audio not supplied.

> Part 2: source audio not supplied.

> Part 3: source audio not supplied.

> Part 4: source audio not supplied.

> c2-t1-w-1: source writing information incomplete — The supplied original prints the 1972 central-heating value as 3?; its final digit cannot be verified. A cleaner source or explicit user correction is required before complete task scoring.

## 听力

### Part 1

<!-- Source: /api/assets/e749cb320b64b3981fbca2e3fa3c3080a3533738fb25cfef33e7b3976f7bbb9f.jpg; PDF page 2; R -->

```text
Test 1 — SECTION 1 Questions 1–10
Questions 1–5
Complete the form below.
Write NO MORE THAN ONE WORD OR A NUMBER for each answer.
VIDEO LIBRARY APPLICATION FORM
EXAMPLE ANSWER: Surname — Jones
First names: Louise Cynthia
Address: Apartment 1,72 (1) __________ Street, Highbridge
Post code: (2) __________
Telephone: 9835 6712 (home); (3) __________ (work)
Driver’s licence number: (4) __________
Date of birth: Day: 25th; Month: (5) __________; Year: 1977
```

[Original question page](assets/e749cb320b64b3981fbca2e3fa3c3080a3533738fb25cfef33e7b3976f7bbb9f.jpg)

<!-- Source: /api/assets/d0663dc49f7b7f37d5df7bc435bc9d82795d4b75e6fc612b55cfe5bfca7c013f.jpg; PDF page 3; L -->

```text
Questions 6—8
Circle THREE letters A-F.
What types of films does Louise like?
A Action
B Comedies
C Musicals
D Romance
E Westerns
F Wildlife
Questions 9 and 10
Write NO MORE THAN THREE WORDS for each answer.
9 How much does it cost to join the library?
10 When will Louise's card be ready?
```

[Original question page](assets/d0663dc49f7b7f37d5df7bc435bc9d82795d4b75e6fc612b55cfe5bfca7c013f.jpg)

### Part 2

<!-- Source: /api/assets/5bb280ee77def9d1f445e307452b9214b03b40df848474d63f71a977060c3c64.jpg; PDF page 3; R -->

```text
SECTION 2 Questions 11–20
Questions 11–13
Complete the notes below. Write NO MORE THAN THREE WORDS for each answer.
Expedition Across Attora Mountains
Leader: Charles Owen
Prepared a (11) __________ for the trip
Total length of trip (12) __________
Climbed highest peak in (13) __________
Questions 14 and 15: Circle the correct letters A–C.
14 What took the group by surprise?
A the amount of rain
B the number of possible routes
C the length of the journey
15 How did Charles feel about having to change routes?
A He reluctantly accepted it.
B He was irritated by the diversion.
C It made no difference to his enjoyment.
Questions 16–18: Circle THREE letters A–F.
What does Charles say about his friends?
A He met them at one stage on the trip.
B They kept all their meeting arrangements.
C One of them helped arrange the transport.
D One of them owned the hotel they stayed in.
E Some of them travelled with him.
F Only one group lasted the 96 days.
```

[Original question page](assets/5bb280ee77def9d1f445e307452b9214b03b40df848474d63f71a977060c3c64.jpg)

<!-- Source: /api/assets/246e3bf7f1c3132c407ad702cd6e6f561dade0aaba3df0b289825ada8452c941.jpg; PDF page 4; L -->

```text
Questions 19 and 20
Circle TWO letters A-E.
What does Charles say about the donkeys?
A He rode them when he was tired.
B He named them after places.
C One of them died.
D They behaved unpredictably.
E They were very small.
```

[Original question page](assets/246e3bf7f1c3132c407ad702cd6e6f561dade0aaba3df0b289825ada8452c941.jpg)

### Part 3

<!-- Source: /api/assets/f4704a4e88734fca6f05435a5dfe28f374c3db401d54613e5e506e3f313cf476.jpg; PDF page 4; R -->

```text
SECTION 3 Questions 21–30
Questions 21–25
Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
Item | TIM | JANE
Day of arrival | Sunday | (21) __________
Subject | History | (22) __________
Number of books to read | (23) __________ | (24) __________
Day of first lecture | Tuesday | (25) __________
Questions 26-30
Write NO MORE THAN THREE WORDS for each answer.
26 What is Jane's study strategy in lectures?
27 What is Tim's study strategy for reading?
28 What is the subject of Tim's first lecture?
29 What is the title of Tim's first essay?
30 What is the subject of Jane's first essay?
```

[Original question page](assets/f4704a4e88734fca6f05435a5dfe28f374c3db401d54613e5e506e3f313cf476.jpg)

### Part 4

<!-- Source: /api/assets/e6f5c3fb6dbdfe53c5403757469f84e8167da04e6b4aef706f791d7304712d2c.jpg; PDF page 5; L -->

```text
SECTION 4 Questions 31–40
Questions 31–35
Complete the table below. Write NO MORE THAN THREE WORDS for each answer.
Course | Type of course: duration and level | Entry requirements
Physical Fitness Instructor | Example: Six-month certificate | None
Sports Administrator | (31) __________ | (32) __________ in sports administration
Sports Psychologist | (33) __________ | Degree in psychology
Physical Education Teacher | Four-year degree in education | (34) __________
Recreation Officer | (35) __________ | None
```

[Original question page](assets/e6f5c3fb6dbdfe53c5403757469f84e8167da04e6b4aef706f791d7304712d2c.jpg)

<!-- Source: /api/assets/85dcfacac72e43f2727de7999bc0faac009570db6037cc45af794050d0ebcfff.jpg; PDF page 5; R -->

```text
Questions 36-40
Complete the table below.
Write the appropriate letters A-G against Questions 36-40.
Job
Physical Fitness Instructor
Sports Administrator
Sports Psychologist
Physical Education Teacher
Recreation Officer
Main role
(36)
(37)
(38)
(39)
(40)
MAIN ROLES
A the coaching of teams
B the support of elite athletes
C guidance of ordinary individuals
D community health
E the treatment of injuries
F arranging matches and venues
G the rounded development of children
```

[Original question page](assets/85dcfacac72e43f2727de7999bc0faac009570db6037cc45af794050d0ebcfff.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/d3939c893e4bc3692a2ff38772f59407ca07265859baf08f37cfeeab5b965643.jpg; PDF page 6; L -->

```text
READING PASSAGE 1
You should spend about 20 minutes on Questions 1–13 which are based on Reading Passage 1 below.
AIRPORTS ON WATER
River deltas are difficult places 
for map makers. The river 
builds them up, the sea wears 
them down; their outlines are 
always changing. The changes 
in China's Pearl River delta, 
however, are more dramatic 
than these natural fluctuations. 
An island six kilometres long 
and with a total area of 1248 
hectares is being created there. 
And the civil engineers are as 
interested in performance as in 
speed and size. This is a bit of 
the delta that they want to 
endure. 
The new island of Chek Lap 
Kok, the site of Hong Kong's 
new airport, is 83% complete. 
The giant dumper trucks 
rumbling across it will have 
finished their job by the middle 
of this year and the airport 
itself will be built at a similarly 
breakneck pace. 
As Chek Lap Kok rises, 
however, another new Asian 
island is sinking back into the 
sea. This is a 520-hectare island 
built in Osaka Bay, Japan, that 
serves as the platform for the 
new Kansai airport. Chek Lap 
Kok was built in a different 
way, and thus hopes to avoid 
the same sinking fate.

The usual way to reclaim 
land is to pile sand rock on to 
the seabed. When the seabed 
oozes with mud, this is rather 
like placing a textbook on a wet 
sponge: the weight squeezes the 
water out, causing both water 
and sponge to settle lower. The 
settlement is rarely even: 
different parts sink at different 
rates. So buildings, pipes, roads 
and so on tend to buckle and 
crack. You can engineer around 
these problems, or you can 
engineer them out. Kansai took 
the first approach; Chek 
Lap Kok is taking the second. 
The differences are both 
political and geological. Kansai 
was supposed to be built just 
one kilometre offshore, where 
the seabed is quite solid. 
Fishermen protested, and the 
site was shifted a further five 
kilometres. That put it in 
deeper water (around 20 
metres) and above a seabed that 
consisted of 20 metres of soft 
alluvial silt and mud deposits. 
Worse, below it was a not-very- 
firm glacial deposit hundreds of 
metres thick. 
The Kansai builders 
recognised that settlement was 
inevitable. Sand was driven into

the seabed to strengthen it
before the landfill was piled on
top, in an attempt to slow the
process; but this has not been as
effective as had been hoped. To
cope with settlement, Kansai's
giant terminal is supported on
900 pillars. Each of them can
be individually jacked up,
allowing wedges to be added
underneath. That is meant to
keep the building level. But it
could be a tricky task.
Conditions are different at
Chek Lap Kok. There was
some land there to begin with,
the original little island of
Chek Lap Kok and a smaller
outcrop called Lam Chau.
Between them, these two
outcrops of hard, weathered
granite make up a quarter of
the new island's surface area.
Unfortunately, between the
islands there was a layer of soft
mud, 27 metres thick in places.
According to Frans
Uiterwijk, a Dutchman who is
the project's reclamation
director, it would have been
possible to leave this mud
below the reclaimed land, and
to deal with the resulting
settlement by the Kansai
method. But the consortium
```

[Original question page](assets/d3939c893e4bc3692a2ff38772f59407ca07265859baf08f37cfeeab5b965643.jpg)

<!-- Source: /api/assets/867dfc1604824432b5e823423cbe71eb32912c1f3a051ae79c020b20c6598f5f.jpg; PDF page 6; R -->

```text
that won the contract for the
island opted for a more
aggressive approach. It
assembled the worlds largest
fleet of dredgers, which sucked
up 150m cubic metres of clay
and mud and dumped it in
deeper waters. At the same
time, sand was dredged from
the waters and piled on top of
the layer of stiff clay that the
massive dredging had laid bare.
Nor was the sand the only
thing used. The original granite
island which had hills up to 120
metres high was drilled and
blasted into boulders no bigger
than two metres in diameter.
This provided 70m cubic
metres of granite to add to the
island's foundations. Because
the heap of boulders does not
fill the space perfectly, this
represents the equivalent of
105m cubic metres of landfill.
Most of the rock will become
the foundations for the
airport's runways and its
taxiways. The sand dredged
from the waters will also be
used to provide a two-metre
capping layer over the granite
platform. This makes it easier
for utilities to dig trenches -
granite is unyielding stuff. Most
of the terminal buildings will
be placed above the site of the
existing island. Only a limited
amount of pile-driving is
needed to support building
foundations above softer areas.
The completed island will be
six to seven metres above sea
level. In all, 350m cubic metres
of material will have been
moved. And much of it, like the
overloads, has to be moved
several times before reaching its
final resting place. For example,
there has to be a motorway
capable of carrying 150-tonne
dump-trucks; and there has to
be a raised area for the 15,000
construction workers. These
are temporary; they will be
removed when the airport is
finished.
The airport, though, is here
to stay. To protect it, the new
coastline is being bolstered
with a formidable twelve
kilometres of sea defences. The
brunt of a typhoon will be
deflected by the neighbouring
island of Lantau; the sea walls
should guard against the rest.
Gentler but more persistent
bad weather - the downpours
of the summer monsoon - is
also being taken into account.
A mat-like material called
geotextile is being laid across
the island to separate the rock
and sand layers. That will stop
sand particles from being
washed into the rock voids, and
so causing further settlement
This island is being built never
to be sunk.
```

[Original question page](assets/867dfc1604824432b5e823423cbe71eb32912c1f3a051ae79c020b20c6598f5f.jpg)

<!-- Source: /api/assets/84063621c3816cb713ae157990a97ac6deab848710e64bda4f0b9632a959441e.jpg; PDF page 7; L -->

```text
Questions 1—5
Classify the following statements as applying to
A Chek Lap Kok airport only
B Kansai airport only
C Both airports
Write the appropriate letters A-C in boxes 1-5 on your answer sheet.
Example Answer
built on a man-made island C
1 having an area of over 1000 hectares
2 built in a river delta
3 built in the open sea
4 built by reclaiming land
5 built using conventional methods of reclamation
```

[Original question page](assets/84063621c3816cb713ae157990a97ac6deab848710e64bda4f0b9632a959441e.jpg)

<!-- Source: /api/assets/b3675cd2645177f899b650ee1b8a798c90ce5a51752eca33c990c2317d2ddc1c.jpg; PDF page 7; R -->

```text
Questions 6-9
Complete the labels on Diagram B below.
Choose your answers from the box below the diagram and write them in boxes 6-9 on your
answer sheet.
NB There are more words/phrases than spaces, so you will not use them all.
DIAGRAM A
Cross-section of the original area around Chek Lap Kok before work began
DIAGRAM B
Cross-section of the same area at the time the article was written
granite runways and taxiways
mud water
terminal building site stiff clay
sand
Diagram B positions (original diagram retained): (6) long upper horizontal span to the left; (7) shorter upper span on the right; (8) thin horizontal upper layer; (9) lower layer beneath the large stones.
Word/phrase box: granite; mud; terminal building site; sand; runways and taxiways; water; stiff clay.
```

[Original question page](assets/b3675cd2645177f899b650ee1b8a798c90ce5a51752eca33c990c2317d2ddc1c.jpg)

![Original figure](assets/b3675cd2645177f899b650ee1b8a798c90ce5a51752eca33c990c2317d2ddc1c.jpg)

<!-- Source: /api/assets/d56d157167d9b622ab93938f2a9341b631a81af0912dc34146355703cb48de17.jpg; PDF page 8; L -->

```text
Questions 10-13
Complete the summary below.
Choose your answers from the box below the summary and write them in boxes 10-13 on your
answer sheet.
NB There are more words than spaces, so you will not use them all.
Answer
When the new Chek Lap Kok airport has been completed,
the raised area and the ... (Example) ... will be removed.'. motorway
The island will be partially protected from storms by ... (10)... and
also by ... (11) ... . Further settlement caused by ... (12) ... will be
prevented by the use of ... (13)....
construction workers coastline dump-trucks
geotextile Lantau Island motorway
rainfall rock and sand rock voids
sea walls typhoons
```

[Original question page](assets/d56d157167d9b622ab93938f2a9341b631a81af0912dc34146355703cb48de17.jpg)

<!-- Source: /api/assets/7851fe5de35003a2f68130a959e8da3b29a99cecd1cfc28e73cd97ba0040137d.jpg; PDF page 8; R -->

```text
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-27 which are based on Reading Passage 2
on the following pages.
Questions 14-18
Reading passage 2 has six paragraphs B-F from the list of headings below
Choose the most suitable headings for paragraphs B-F from the list of headings below.
Write the appropriate numbers (i-ix) in boxes 14-18 on your answer sheet.
NB There are more headings than paragraphs, so you will not use them all.
List of Headings
i Ottawa International Conference on
Health Promotion
ii Holistic approach to health
iii The primary importance of environmental
factors
iv Healthy lifestyles approach to health
v Changes in concepts of health in Western
society
vi Prevention of diseases and illness
vii Ottawa Charter for Health Promotion
viii Definition of health in medical terms
ix Socio-ecological view of health
Example Answer
Paragraph A *
14 Paragraph B
15 Paragraph C
16 Paragraph D
17 Paragraph E
18 Paragraph F
[Source note: the introduction prints “six paragraphs B–F”; the passage has six paragraphs A–F, and Questions14–18 ask for headings for B–F. The printed example answer is an asterisk; no missing numeral is invented.]
```

[Original question page](assets/7851fe5de35003a2f68130a959e8da3b29a99cecd1cfc28e73cd97ba0040137d.jpg)

<!-- Source: /api/assets/c65b7a86ce5484d04434baf08167bea1ba45c2ecf7adf30a908a406f9f4d99a9.jpg; PDF page 9; L -->

```text
Changing our
Understanding of Health
A
The concept of health holds different meanings for different people and
groups. These meanings of health have also changed over time. This change
is no more evident than in Western society today, when notions of health and
health promotion are being challenged and expanded in new ways.
B
For much of recent Western history, health has been viewed in the physical
sense only. That is, good health has been connected to the smooth
mechanical operation of the body, while ill health has been attributed to a
breakdown in this machine. Health in this sense has been defined as the
absence of disease or illness and is seen in medical terms. According to this
view, creating health for people means providing medical care to treat or
prevent disease and illness. During this period, there was an emphasis on
providing clean water, improved sanitation and housing.
C
In the late 1940s the World Health Organisation challenged this physically and
medically oriented view of health. They stated that 'health is a complete state
of physical, mental and social well-being and is not merely the absence of
disease' (WHO, 1946). Health and the person were seen more holistically
(mind/body/spirit) and not just in physical terms.
D
The 1970s was a time of focusing on the prevention of disease and illness by
emphasising the importance of the lifestyle and behaviour of the individual.
Specific behaviours which were seen to increase risk of disease, such as
smoking, lack of fitness and unhealthy eating habits, were targeted. Creating
health meant providing not only medical health care, but health promotion
programs and policies which would help people maintain healthy behaviours
and lifestyles. While this individualistic healthy lifestyles approach to health
worked for some (the wealthy members of society), people experiencing
poverty, unemployment, underemployment or little control over the
conditions of their daily lives benefited little from this approach. This was
largely because both the healthy lifestyles approach and the medical
approach to health largely ignored the social and environmental conditions
affecting the health of people.
```

[Original question page](assets/c65b7a86ce5484d04434baf08167bea1ba45c2ecf7adf30a908a406f9f4d99a9.jpg)

<!-- Source: /api/assets/c723ac0ab705c4b5965a9f2d72dcb2a6f8bc422a829ec0319f2be0e928dad3df.jpg; PDF page 9; R -->

```text
E
During 1980s and 1990s there has been a growing swing away from
seeing lifestyle risks as the root cause of poor health. While lifestyle factors
still remain important, health is being viewed also in terms of the social,
economic and environmental contexts in which people live. This broad
approach to health is called the socio-ecological view of health. The broad
socio-ecological view of health was endorsed at the first International
Conference of Health Promotion held in 1986, Ottawa, Canada, where people
from 38 countries agreed and declared that:
The fundamental conditions and resources for health are
peace, shelter, education, food, a viable income, a stable
eco-system, sustainable resources, social justice and equity.
Improvement in health requires a secure foundation in
these basic requirements. (WHO, 1986)
It is clear from this statement that the creation of health is about much more
than encouraging healthy individual behaviours and lifestyles and providing
appropriate medical care. Therefore, the creation of health must include
addressing issues such as poverty, pollution, urbanisation, natural resource
depletion, social alienation and poor working conditions. The social, economic
and environmental contexts which contribute to the creation of health do not
operate separately or independently of each other. Rather, they are interacting
and interdependent, and it is the complex interrelationships between them
which determine the conditions that promote health. A broad socio-ecological
view of health suggests that the promotion of health must include a strong
social, economic and environmental focus.
F
At the Ottawa Conference in 1986, a charter was developed which outlined
new directions for health promotion based on the socio-ecological view of
health. This charter, known as the Ottawa Charter for Health Promotion,
remains as the backbone of health action today. In exploring the scope of
health promotion it states that:
Good health is a major resource for social, economic and
personal development and an important dimension of
quality of life. Political, economic, social, cultural,
environmental, behavioural and biological factors can all
favour health or be harmful to it. (WHO, 1986)
The Ottawa Charter brings practical meaning and action to this broad notion
of health promotion. It presents fundamental strategies and approaches in
achieving health for all. The overall philosophy of health promotion which
guides these fundamental strategies and approaches is one of 'enabling
people to increase control over and to improve their health' (WHO, 1986).
```

[Original question page](assets/c723ac0ab705c4b5965a9f2d72dcb2a6f8bc422a829ec0319f2be0e928dad3df.jpg)

<!-- Source: /api/assets/9f16dfe22de624c82787b6bec70fd817a56f21c96a031d0127ee1ce0508bfedb.jpg; PDF page 10; L -->

```text
Questions 19-22
Using NO MORE THAN THREE WORDS from the passage, answer the following questions
Write your answers in boxes 19-22 on your answer sheet.
19 In which year did the World Health Organisation define health in terms of mental,
physical and social well-being?
20 Which members of society benefited most from the healthy lifestyles approach to
health?
21 Name the three broad areas which relate to people's health, according to the socioecological view of health.
22 During which decade were lifestyle risks seen as the major contributors to poor health?
Questions 23-27
Do the following statements agree with the information in Reading Passage 2?
In boxes 23-27 on your answer sheet write
YES if the statement agrees with the information
NO if the statement contradicts the information
NOT GIVEN if there is no information on this in the passsage
23 Doctors have been instrumental in improving living standards in Western society.
24 The approach to health during the 1970s included the introduction of health awareness
programs.
25 The socio-ecological view of health recognises that lifestyle habits and the provision of
adequate health care are critical factors governing health.
26 The principles of the Ottawa Charter are considered to be out of date in the 1990s.
27 In recent years a number of additional countries have subscribed to the Ottawa
Charter.
```

[Original question page](assets/9f16dfe22de624c82787b6bec70fd817a56f21c96a031d0127ee1ce0508bfedb.jpg)

<!-- Source: /api/assets/9b63ac32014aaab2987b2691b7b01723980fcb167db652ec00df82df5cae1a7a.jpg; PDF page 10; R -->

```text
READING PASSAGE 3
You should spend about 20 minutes on Questions 28–40 which are based on Reading Passage 3 below.
CHILDREN’S THINKING
One of the most eminent of 
psychologists, Clark Hull, claimed that 
the essence of reasoning lies in the 
putting together of two 'behaviour 
segments' in some novel way, never 
actually performed before, so as to 
reach a goal. 
Two followers of Clark Hull, Howard 
and Tracey Kendler, devised a test for 
children that was explicitly based on 
Clark Hull's principles. The children 
were given the task of learning to 
operate a machine so as to get a toy. In 
order to succeed they had to go through 
a two-stage sequence. The children 
were trained on each stage separately.
The stages consisted merely of pressing 
the correct one of two buttons to get a 
marble; and of inserting the marble into 
a small hole to release the toy. 
The Kendlers found that the children 
could learn the separate bits readily 
enough. Given the task of getting a 
marble by pressing the button they 
could get the marble; given the task of 
getting a toy when a marble was handed 
to them, they could use the marble. (All 
they had to do was put it in a hole.) But 
they did not for the most part 
'integrate', to use the Kendlers' 
terminology. They did not press the 
button to get the marble and then 
proceed without further help to use the 
marble to get the toy. So the Kendlers 
concluded that they were incapable of 
deductive reasoning.

The mystery at first appears to
deepen when we learn, from another
psychologist, Michael Cole, and his
colleagues, that adults in an African
culture apparently cannot do the
Kendlers' task either. But it lessens, on
the other hand, when we learn that a
task was devised which was strictly
analogous to the Kendlers' one but
much easier for the African males to
handle.
Instead of the button-pressing
machine, Cole used a locked box and
two differently coloured match-boxes,
one of which contained a key that
would open the box. Notice that there
are still two behaviour segments —
'open the right match-box to get the key'
and 'use the key to open the box' - so
the task seems formally to be the same.
But psychologically it is quite different,
Now the subject is dealing not with a
strange machine but with familiar
meaningful objects; and it is clear to
him what he is meant to do. It then
turns out that the difficulty of
'integration' is greatly reduced,
Recent work by Simon Hewson is of
great interest here for it shows that, for
young children, too, the difficulty lies
not in the inferential processes which
the task demands, but in certain
perplexing features of the apparatus
and the procedure. When these are
changed in ways which do not at all
affect the inferential nature of the
```

[Original question page](assets/9b63ac32014aaab2987b2691b7b01723980fcb167db652ec00df82df5cae1a7a.jpg)

<!-- Source: /api/assets/8d554192494db7723ec787fa2a8618f7b43ca1e37361e1c53a37d8df683ecd37.jpg; PDF page 11; L -->

```text
problem, then five-year-old children 
solve the problem as well as college 
students did in the Kendlers' own 
experiments. 
Hewson made two crucial changes. 
First, he replaced the button-pressing 
mechanism in the side panels by 
drawers in these panels which the child 
could open and shut. This took away 
the mystery from the first stage of 
training. Then he helped the child to 
understand that there was no 'magic' 
about the specific marble which, during 
the second stage of training, the 
experimenter handed to him so that he 
could pop it in the hole and get the 
reward. 
A child understands nothing, after 
all, about how a marble put into a hole 
can open a little door. How is he to 
know that any other marble of similar

size will do just as well? Yet he must
assume that if he is to solve the
problem. Hewson made the functional
equivalence of different marbles clear
by playing a 'swapping game' with the
children.
The two modifications together
produced a jump in success rates from
30 per cent to 90 per cent for five-year-
olds and from 35 per cent to 72.5 per
cent for four-year-olds. For three-year-
olds, for reasons that are still in need of
clarification, no improvement — rather a
slight drop in performance - resulted
from the change.
We may conclude, then, that
children experience very real difficulty
when faced with the Kendler
apparatus; but this difficulty cannot be
taken as proof that they are incapable of
deductive reasoning.
```

[Original question page](assets/8d554192494db7723ec787fa2a8618f7b43ca1e37361e1c53a37d8df683ecd37.jpg)

<!-- Source: /api/assets/967cc9011ac4aa01b9a2f9d5abcc7b0217dfcbeb110702cd8d0075474c7a4b1b.jpg; PDF page 11; R -->

```text
Questions 28-35
Classify the following descriptions as a referring
Clark Hull CH
Howard and Tracy Kendler HTK
Micheal Cole and colleagues MC
Simon Hewson SH [source correction: this option is omitted on the printed question page but is used in the source key; Simon Hewson is named in the passage.]
Write the appropriate letters in boxes 28-35 on your answer sheet.
NB You may use any answer more than once.
28 is cited as famous in the field of psychology.
29 demonstrated that the two-stage experiment involving button-pressing and
inserting a marble into a hole poses problems for certain adults as well as children.
30 devised an experiment that investigated deductive reasoning without the use of
any marbles.
31 appears to have proved that a change in the apparatus dramatically improves the
performance of children of certain ages.
32 used a machine to measure inductive reasoning that replaced button-pressing with
drawer-opening.
33 experimented with things that the subjects might have been expected to encounter
in everyday life, rather than with a machine.
34 compared the performance of five-year-olds with college students, using the same
apparatus with both sets of subjects.
35 is cited as having demonstrated that earlier experiments into children's ability to
reason deductively may have led to the wrong conclusions.
```

[Original question page](assets/967cc9011ac4aa01b9a2f9d5abcc7b0217dfcbeb110702cd8d0075474c7a4b1b.jpg)

<!-- Source: /api/assets/979f899dca4a7987690c2a8ba25c282d5f3e0002d298924306c84d197a8470dc.jpg; PDF page 12; L -->

```text
Questions 36-40
Do the following statements agree with the information given in Reading Passage 3?
In boxes 36-40 on your answer sheet write
YES if the statement agrees with the information
NO if the statement contradicts the information
NOT GIVEN if there is no information on this in the passage
36 Howard and Tracey Kendler studied under Clark Hull.
37 The Kendlers trained their subjects separately in the two stages of their experiment, but
not in how to integrate the two actions.
38 Michael Cole and his colleagues demonstrated that adult performance on inductive
reasoning tasks depends on features of the apparatus and procedure.
39 All Hewson's experiments used marbles of the same size.
40 Hewson's modifications resulted in a higher success rate for children of all ages.
```

[Original question page](assets/979f899dca4a7987690c2a8ba25c282d5f3e0002d298924306c84d197a8470dc.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/a748216c8ec73e746ceaea55c008857b9f88208d4c427ee07149509dce6d3aca.jpg; PDF page 12; R -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The table below shows the consumer durables (telephone, refrigerator, etc.) owned in Britain from 1972 to 1983.

Write a report for a university lecturer describing the information shown below.

You should write at least 150 words.

See the retained original figure for the full table or chart.
Source defect: the 1972 central-heating cell reads "3?"; its final digit is not recoverable from this supplied source.
```

[Original question page](assets/a748216c8ec73e746ceaea55c008857b9f88208d4c427ee07149509dce6d3aca.jpg)

![Original figure](assets/a748216c8ec73e746ceaea55c008857b9f88208d4c427ee07149509dce6d3aca.jpg)

### Task 2

<!-- Source: /api/assets/011a88d2bffc4477fdc9b9f7e27cb38c1a52202a110fe5abb4ff46c9742d3af2.jpg; PDF page 13; L -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Present a written argument or case to an educated reader with no specialist knowledge of the following topic:

"Fatherhood ought to be emphasised as much as motherhood. The idea that women are solely responsible for deciding whether or not to have babies leads on to the idea that they are also responsible for bringing the children up."

To what extent do you agree or disagree?

You should write at least 250 words.

You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.
```

[Original question page](assets/011a88d2bffc4477fdc9b9f7e27cb38c1a52202a110fe5abb4ff46c9742d3af2.jpg)

## 口语

### 原书口语任务

<!-- Source: /api/assets/4531243c215d40f77316b38b2677eb1d2a61059607a45f77fde1b74ca4a2041a.png; PDF page 13; R -->

```text
SPEAKING
The candidate is to find out as much information as possible about electronic mail.
Candidate's cue card:
ELECTRONIC MAIL
You are studying at a language school and have heard that students may obtain an
electronic mail (e-mail) address so that they can send and receive messages by
computer. The Examiner is the Student Services advisor.
Ask the Examiner about: what e-mail is
cost
how to obtain an e-mail address
location of e-mail at school
equipment needed at home
courses on e-mail
```

[Original question page](assets/4531243c215d40f77316b38b2677eb1d2a61059607a45f77fde1b74ca4a2041a.png)
