# 剑雅 15 · Test 1

Text edition · verified

## 听力

### Part 1

<!-- Source: /api/assets/2345f71b6e7446cefc3051d0fa6feb629390d3b4614e11756020a3a2440936b4.jpg; PDF page 8; full -->

```text
PART 1 Questions 1–10
Complete the notes below. Write ONE WORD AND/OR A NUMBER for each answer.
Bankside Recruitment Agency
Address of agency: 497 Eastside, Docklands
Name of agent: Becky (1) __________
Phone number: 07866 510333
Best to call her in the (2) __________
Typical jobs
Clerical and admin roles, mainly in the finance industry
Must have good (3) __________ skills
Jobs are usually for at least one (4) __________
Pay is usually (5) £ __________ per hour
Registration process
Wear a (6) __________ to the interview
Must bring your (7) __________ to the interview
They will ask questions about each applicant’s (8) __________
Advantages of using an agency
The (9) __________ you receive at interview will benefit you
Will get access to vacancies which are not advertised
Less (10) __________ is involved in applying for jobs
```

[Original question page](assets/2345f71b6e7446cefc3051d0fa6feb629390d3b4614e11756020a3a2440936b4.jpg)

### Part 2

<!-- Source: /api/assets/469e5f1ca78a0264bf99415acebe92784d9f8cea676251a2ea84115c086eba87.jpg; PDF page 9; full -->

```text
PART 2 Questions 11–20
Questions 11–14
Choose the correct letter, A, B or C.
Matthews Island Holidays
11 According to the speaker, the company
A has been in business for longer than most of its competitors.
B arranges holidays to more destinations than its competitors.
C has more customers than its competitors.
12 Where can customers meet the tour manager before travelling to the Isle of Man?
A Liverpool
B Heysham
C Luton
13 How many lunches are included in the price of the holiday?
A three
B four
C five
14 Customers have to pay extra for
A guaranteeing themselves a larger room.
B booking at short notice.
C transferring to another date.
```

[Original question page](assets/469e5f1ca78a0264bf99415acebe92784d9f8cea676251a2ea84115c086eba87.jpg)

<!-- Source: /api/assets/683d3d7225a6b9612d69cd8b2e3656f99aa15b1961b8f6c1591499e43e171daa.jpg; PDF page 10; full -->

```text
Questions 15–20
Complete the table below. Write ONE WORD AND/OR A NUMBER for each answer.
Timetable for Isle of Man holiday
| Day | Activity | Notes |
| --- | --- | --- |
| 1 | Arrive | Introduction by manager. Hotel dining room has view of the (15) __________ |
| 2 | Tynwald Exhibition and Peel | Tynwald may have been founded in (16) __________, not 979. |
| 3 | Trip to Snaefell | Travel along promenade in a tram; train to Laxey; train to the (17) __________ of Snaefell |
| 4 | Free day | Company provides a (18) __________ for local transport and heritage sites. |
| 5 | Take the (19) __________ railway train from Douglas to Port Erin | Free time, then coach to Castletown – former (20) __________ has old castle. |
| 6 | Leave | Leave the island by ferry or plane |
```

[Original question page](assets/683d3d7225a6b9612d69cd8b2e3656f99aa15b1961b8f6c1591499e43e171daa.jpg)

### Part 3

<!-- Source: /api/assets/4f0842b37fd37c9ae3c4dd88025013de09d6a5a2f6258cbd65b0df1fb871c198.jpg; PDF page 11; full -->

```text
PART 3 Questions 21–30
Questions 21–26
What did findings of previous research claim about the personality traits a child is likely to have because of their position in the family?
Choose SIX answers from the box and write the correct letter, A–H, next to Questions 21–26.
Personality Traits
A outgoing
B selfish
C independent
D attention-seeking
E introverted
F co-operative
G caring
H competitive
Position in family
21 the eldest child __________
22 a middle child __________
23 the youngest child __________
24 a twin __________
25 an only child __________
26 a child with much older siblings __________
```

[Original question page](assets/4f0842b37fd37c9ae3c4dd88025013de09d6a5a2f6258cbd65b0df1fb871c198.jpg)

<!-- Source: /api/assets/27a13fbcb0ff13e7907d0e55906066d76cc5ad6bf19faeec723c8c115deffe4e.jpg; PDF page 12; full -->

```text
Questions 27 and 28
Choose the correct letter, A, B or C.
27 What do the speakers say about the evidence relating to birth order and academic success?
A There is conflicting evidence about whether oldest children perform best in intelligence tests.
B There is little doubt that birth order has less influence on academic achievement than socio-economic status.
C Some studies have neglected to include important factors such as family size.
28 What does Ruth think is surprising about the difference in oldest children’s academic performance?
A It is mainly thanks to their roles as teachers for their younger siblings.
B The advantages they have only lead to a slightly higher level of achievement.
C The extra parental attention they receive at a young age makes little difference.
Questions 29 and 30
Choose TWO letters, A–E.
Which TWO experiences of sibling rivalry do the speakers agree has been valuable for them?
A learning to share
B learning to stand up for oneself
C learning to be a good loser
D learning to be tolerant
E learning to say sorry
```

[Original question page](assets/27a13fbcb0ff13e7907d0e55906066d76cc5ad6bf19faeec723c8c115deffe4e.jpg)

### Part 4

<!-- Source: /api/assets/d5cf184e2de57c150f1051e9dd7c22176d46f57a08c774011b158e20815dac6a.jpg; PDF page 13; full -->

```text
PART 4 Questions 31–40
Complete the notes below. Write ONE WORD ONLY for each answer.
The Eucalyptus Tree in Australia
Importance
• it provides (31) __________ and food for a wide range of species
• its leaves provide (32) __________ which is used as a disinfectant
Reasons for present decline in number
A Diseases
i ‘Mundulla Yellows’
Cause
– lime used for making (33) __________ was absorbed
– trees were unable to take in necessary iron through their roots
ii ‘Bell-miner Associated Die-back’
Cause
– (34) __________ feed on eucalyptus leaves
– they secrete a substance containing sugar
– bell-miner birds are attracted by this and keep away other species
B Bushfires
William Jackson’s theory:
• high-frequency bushfires have impact on vegetation, resulting in the growth of (35) __________
• mid-frequency bushfires result in the growth of eucalyptus forests, because they:
– make more (36) __________ available to the trees
– maintain the (37) __________ of the soil
• low-frequency bushfires result in the growth of (38) ‘__________ rainforest’, which is:
– a (39) __________ ecosystem
– an ideal environment for the (40) __________ of the bell-miner
```

[Original question page](assets/d5cf184e2de57c150f1051e9dd7c22176d46f57a08c774011b158e20815dac6a.jpg)

## A 类阅读

### Academic Reading

<!-- Source: /api/assets/6762857e118892a8d20da04014a192c18698e58f7c8f24972ad47ae53f480692.jpg; PDF page 14; full -->

```text
Test 1
READING
READING PASSAGE 1
You should spend about 20 minutes on Questions 1-13, which are based on Reading
Passage 1 below.
Nutmeg — a valuable spice
The nutmeg tree, Myristica fragrans, is a large evergreen tree native to Southeast Asia. Until the late
18th century, it only grew in one place in the world: a small group of islands in the Banda Sea, part
of the Moluccas — or Spice Islands — in northeastern Indonesia. The tree is thickly branched with
dense foliage of tough, dark green oval leaves, and produces small, yellow, bell-shaped flowers and
pale yellow pear-shaped fruits. The fruit is encased in a fleshy husk. When the fruit is ripe, this husk
splits into two halves along a ridge running the length of the fruit. Inside is a purple-brown shiny seed,
2–3 cm long by about 2cm across, surrounded by a lacy red or crimson covering called an ‘aril’. These
are the sources of the two spices nutmeg and mace, the former being produced from the dried seed
and the latter from the aril.
Nutmeg was a highly prized and costly ingredient in European cuisine in the Middle Ages, and was
used as a flavouring, medicinal, and preservative agent. Throughout this period, the Arabs were the
exclusive importers of the spice to Europe. They sold nutmeg for high prices to merchants based in
Venice, but they never revealed the exact location of the source of this extremely valuable commodity.
The Arab-Venetian dominance of the trade finally ended in 1512, when the Portuguese reached the
Banda Islands and began exploiting its precious resources.
Always in danger of competition from neighbouring Spain, the Portuguese began subcontracting
their spice distribution to Dutch traders. Profits began to flow into the Netherlands, and the Dutch
commercial fleet swiftly grew into one of the largest in the world. The Dutch quietly gained control
of most of the shipping and trading of spices in Northern Europe. Then, in 1580, Portugal fell under
Spanish rule, and by the end of the 16th century the Dutch found themselves locked out of the market.
As prices for pepper, nutmeg, and other spices soared across Europe, they decided to fight back.
In 1602, Dutch merchants founded the VOC, a trading corporation better known as the Dutch East
India Company. By 1617, the VOC was the richest commercial operation in the world. The company
had 50,000 employees worldwide, with a private army of 30,000 men and a fleet of 200 ships. At
the same time, thousands of people across Europe were dying of the plague, a highly contagious and
deadly disease. Doctors were desperate for a way to stop the spread of this disease, and they decided
nutmeg held the cure. Everybody wanted nutmeg, and many were willing to spare no expense to
have it. Nutmeg bought for a few pennies in Indonesia could be sold for 68,000 times its original cost
on the streets of London. The only problem was the short supply. And that’s where the Dutch found
their opportunity.
16
```

[Original question page](assets/6762857e118892a8d20da04014a192c18698e58f7c8f24972ad47ae53f480692.jpg)

<!-- Source: /api/assets/f296269687d1ad1e472af9b11424a63e2a1b5d9ce3d965a7222ce5f959c4eca9.jpg; PDF page 15; full -->

```text
Reading
The Banda Islands were ruled by local sultans who insisted on maintaining a neutral trading
policy towards foreign powers. This allowed them to avoid the presence of Portuguese or Spanish
troops on their soil, but it also left them unprotected from other invaders. In 1621, the Dutch
arrived and took over. Once securely in control of the Bandas, the Dutch went to work protecting
their new investment. They concentrated all nutmeg production into a few easily guarded areas,
uprooting and destroying any trees outside the plantation zones. Anyone caught growing a nutmeg
seedling or carrying seeds without the proper authority was severely punished. In addition,
all exported nutmeg was covered with lime to make sure there was no chance a fertile seed
which could be grown elsewhere would leave the islands. There was only one obstacle to Dutch
domination. One of the Banda Islands, a sliver of land called Run, only 3km long by less than
1km wide, was under the control of the British. After decades of fighting for control of this tiny
island, the Dutch and British arrived at a compromise settlement, the Treaty of Breda, in 1667.
Intent on securing their hold over every nutmeg-producing island, the Dutch offered a trade: if the
British would give them the island of Run, they would in turn give Britain a distant and much less
valuable island in North America. The British agreed. That other island was Manhattan, which is
how New Amsterdam became New York. The Dutch now had a monopoly over the nutmeg trade
which would last for another century.
Then, in 1770, a Frenchman named Pierre Poivre successfully smuggled nutmeg plants to safety
in Mauritius, an island off the coast of Africa. Some of these were later exported to the Caribbean
where they thrived, especially on the island of Grenada. Next, in 1778, a volcanic eruption in the
Banda region caused a tsunami that wiped out half the nutmeg groves. Finally, in 1809, the British
returned to Indonesia and seized the Banda Islands by force. They returned the islands to the
Dutch in 1817, but not before transplanting hundreds of nutmeg seedlings to plantations in several
locations across southern Asia. The Dutch nutmeg monopoly was over.
Today, nutmeg is grown in Indonesia, the Caribbean, India, Malaysia, Papua New Guinea and
Sri Lanka, and world nutmeg production is estimated to average between 10,000 and 12,000 tonnes
per year.
17
```

[Original question page](assets/f296269687d1ad1e472af9b11424a63e2a1b5d9ce3d965a7222ce5f959c4eca9.jpg)

<!-- Source: /api/assets/2bc72aad5cee7182f4cf2ebac0df9bfb474e50143db90467dc8d13c0b83078dd.jpg; PDF page 16; full -->

```text
Questions 1–4
Complete the notes below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 1–4 on your answer sheet.
The nutmeg tree and fruit
• the leaves of the tree are (1) __________ in shape
• the (2) __________ surrounds the fruit and breaks open when the fruit is ripe
• the (3) __________ is used to produce the spice nutmeg
• the covering known as the aril is used to produce (4) __________
• the tree has yellow flowers and fruit
Questions 5–7
Do the following statements agree with the information given in Reading Passage 1?
In boxes 5–7 on your answer sheet, write
TRUE if the statement agrees with the information
FALSE if the statement contradicts the information
NOT GIVEN if there is no information on this
5 In the Middle Ages, most Europeans knew where nutmeg was grown.
6 The VOC was the world’s first major trading company.
7 Following the Treaty of Breda, the Dutch had control of all the islands where nutmeg grew.
```

[Original question page](assets/2bc72aad5cee7182f4cf2ebac0df9bfb474e50143db90467dc8d13c0b83078dd.jpg)

<!-- Source: /api/assets/b7471546e7d4a844f57a05915c24ce62817af7c4bc73e27763670f2cc7205b78.jpg; PDF page 17; full -->

```text
Questions 8–13
Complete the table below. Choose ONE WORD ONLY from the passage for each answer.
Write your answers in boxes 8–13 on your answer sheet.
| Period | Details |
| --- | --- |
| Middle Ages | Nutmeg was brought to Europe by the (8) __________ |
| 16th century | European nations took control of the nutmeg trade |
| 17th century | Demand for nutmeg grew, as it was believed to be effective against the disease known as the (9) __________ |
| 17th century | The Dutch took control of the Banda Islands; restricted nutmeg production to a few areas; put (10) __________ on nutmeg to avoid it being cultivated outside the islands; finally obtained the island of (11) __________ from the British |
| Late 18th century | 1770 – nutmeg plants were secretly taken to (12) __________; 1778 – half the Banda Islands’ nutmeg plantations were destroyed by a (13) __________ |
```

[Original question page](assets/b7471546e7d4a844f57a05915c24ce62817af7c4bc73e27763670f2cc7205b78.jpg)

<!-- Source: /api/assets/211d822d80443184108febcd3094fd5b9b99ba1e3bee5aa1d992a0ce90ad4b88.jpg; PDF page 18; full -->

```text
Test 1
READING PASSAGE 2
You should spend about 20 minutes on Questions 14-26, which are based on Reading
Passage 2 below.
Driverless cars
A The automotive sector is well used to adapting to automation in manufacturing.
The implementation of robotic car manufacture from the 1970s onwards led to
significant cost savings and improvements in the reliability and flexibility of vehicle
mass production. A new challenge to vehicle production is now on the horizon
and, again, it comes from automation. However, this time it is not to do with the
manufacturing process, but with the vehicles themselves.
Research projects on vehicle automation are not new. Vehicles with limited self-
driving capabilities have been around for more than 50 years, resulting in significant
contributions towards driver assistance systems. But since Google announced in
2010 that it had been trialling self-driving cars on the streets of California, progress
in this field has quickly gathered pace.
B There are many reasons why technology is advancing so fast. One frequently cited
motive is safety; indeed, research at the UK’s Transport Research Laboratory has
demonstrated that more than 90 percent of road collisions involve human error as a
contributory factor, and it is the primary cause in the vast majority. Automation may
help to reduce the incidence of this.
Another aim is to free the time people spend driving for other purposes. If the
vehicle can do some or all of the driving, it may be possible to be productive, to
socialise or simply to relax while automation systems have responsibility for safe
control of the vehicle. If the vehicle can do the driving, those who are challenged
by existing mobility models — such as older or disabled travellers — may be able to
enjoy significantly greater travel autonomy.
C Beyond these direct benefits, we can consider the wider implications for transport
and society, and how manufacturing processes might need to respond as a
result. At present, the average car spends more than 90 percent of its life parked.
Automation means that initiatives for car-sharing become much more viable,
particularly in urban areas with significant travel demand. If a significant proportion
of the population choose to use shared automated vehicles, mobility demand can
be met by far fewer vehicles.
D The Massachusetts Institute of Technology investigated automated mobility in
Singapore, finding that fewer than 30 percent of the vehicles currently used would
be required if fully automated car sharing could be implemented. If this is the case,
it might mean that we need to manufacture far fewer vehicles to meet demand.
```

[Original question page](assets/211d822d80443184108febcd3094fd5b9b99ba1e3bee5aa1d992a0ce90ad4b88.jpg)

<!-- Source: /api/assets/3dcc6691a7bedf0526503de625ba9df1895e694f5a1975f0fba7673b6fabd73c.jpg; PDF page 19; full -->

```text
Reading
However, the number of trips being taken would probably increase, partly because
empty vehicles would have to be moved from one customer to the next.
Modelling work by the University of Michigan Transportation Research Institute
suggests automated vehicles might reduce vehicle ownership by 43 percent, but
that vehicles’ average annual mileage would double as a result. As a consequence,
each vehicle would be used more intensively, and might need replacing
sooner. This faster rate of turnover may mean that vehicle production will not
necessarily decrease.
E Automation may prompt other changes in vehicle manufacture. If we move to a
model where consumers are tending not to own a single vehicle but to purchase
access to a range of vehicles through a mobility provider, drivers will have the
freedom to select one that best suits their needs for a particular journey, rather than
making a compromise across all their requirements.
Since, for most of the time, most of the seats in most cars are unoccupied, this may
boost production of a smaller, more efficient range of vehicles that suit the needs
of individuals. Specialised vehicles may then be available for exceptional journeys,
such as going on a family camping trip or helping a son or daughter move to
university.
F There are a number of hurdles to overcome in delivering automated vehicles
to our roads. These include the technical difficulties in ensuring that the vehicle
works reliably in the infinite range of traffic, weather and road situations it might
encounter; the regulatory challenges in understanding how liability and enforcement
might change when drivers are no longer essential for vehicle operation; and
the societal changes that may be required for communities to trust and accept
automated vehicles as being a valuable part of the mobility landscape.
G It's clear that there are many challenges that need to be addressed but, through
robust and targeted research, these can most probably be conquered within the
next 10 years. Mobility will change in such potentially significant ways and in
association with so many other technological developments, such as telepresence
and virtual reality, that it is hard to make concrete predictions about the future.
However, one thing is certain: change is coming, and the need to be flexible in
response to this will be vital for those involved in manufacturing the vehicles that
will deliver future mobility.
21
```

[Original question page](assets/3dcc6691a7bedf0526503de625ba9df1895e694f5a1975f0fba7673b6fabd73c.jpg)

<!-- Source: /api/assets/65a6aac9dfa30eb23882dafcf1ffdbf7b3eba17d61984b975651712c457de868.jpg; PDF page 20; full -->

```text
Test 1
Questions 14-18
Reading Passage 2 has seven sections, A-G.
Which section contains the following information?
Write the correct letter, A-G, in boxes 14—18 on your answer sheet.
14 reference to the amount of time when a car is not in use
15 mention of several advantages of driverless vehicles for individual road-users
16 reference to the opportunity of choosing the most appropriate vehicle for each trip
17 an estimate of how long it will take to overcome a number of problems
18 a suggestion that the use of driverless cars may have no effect on the number of
vehicles manufactured
Questions 19-22
Complete the summary below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 19-22 on your answer sheet.
The impact of driverless cars
Figures from the Transport Research Laboratory indicate that most motor accidents
are partly due to 19 __________ , so the introduction of driverless vehicles
will result in greater safety. In addition to the direct benefits of automation, it may bring
other advantages. For example, schemes for 20 __________ will be more
workable, especially in towns and cities, resulting in fewer cars on the road.
According to the University of Michigan Transportation Research Institute, there could
be a 43 percent drop in 21 __________ of cars. However, this would mean
that the yearly 22 __________ of each car would, on average, be twice as
high as it currently is. This would lead to a higher turnover of vehicles, and therefore no
reduction in automotive manufacturing.
22
```

[Original question page](assets/65a6aac9dfa30eb23882dafcf1ffdbf7b3eba17d61984b975651712c457de868.jpg)

<!-- Source: /api/assets/71d799439e20b82755be7ca778f3d86b3c261fe45365552e2e9952aeff6c2d5d.jpg; PDF page 21; full -->

```text
Questions 23 and 24
Choose TWO letters, A–E. Write the correct letters in boxes 23 and 24 on your answer sheet.
Which TWO benefits of automated vehicles does the writer mention?
A Car travellers could enjoy considerable cost savings.
B It would be easier to find parking spaces in urban areas.
C Travellers could spend journeys doing something other than driving.
D People who find driving physically difficult could travel independently.
E A reduction in the number of cars would mean a reduction in pollution.
Questions 25 and 26
Choose TWO letters, A–E. Write the correct letters in boxes 25 and 26 on your answer sheet.
Which TWO challenges to automated vehicle development does the writer mention?
A making sure the general public has confidence in automated vehicles
B managing the pace of transition from conventional to automated vehicles
C deciding how to compensate professional drivers who become redundant
D setting up the infrastructure to make roads suitable for automated vehicles
E getting automated vehicles to adapt to various different driving conditions
```

[Original question page](assets/71d799439e20b82755be7ca778f3d86b3c261fe45365552e2e9952aeff6c2d5d.jpg)

<!-- Source: /api/assets/2084f846e87273ffdb3cc90d040d0987e0a09bcf4ff05ed42eff3c00aba61b2b.jpg; PDF page 22; full -->

```text
Test 1
READING PASSAGE 3
You should spend about 20 minutes on Questions 27-40, which are based on Reading
Passage 3 below.
What is exploration?
We are all explorers. Our desire to discover, and then share that new-found knowledge, is part
of what makes us human — indeed, this has played an important part in our success as a species.
Long before the first caveman slumped down beside the fire and grunted news that there were
plenty of wildebeest over yonder, our ancestors had learnt the value of sending out scouts to
investigate the unknown. This questing nature of ours undoubtedly helped our species spread
around the globe, just as it nowadays no doubt helps the last nomadic Penan maintain their
existence in the depleted forests of Borneo, and a visitor negotiate the subways of New York.
Over the years, we’ve come to think of explorers as a peculiar breed — different from the rest of
us, different from those of us who are merely ‘well travelled’, even; and perhaps there is a type of
person more suited to seeking out the new, a type of caveman more inclined to risk venturing out.
That, however, doesn’t take away from the fact that we all have this enquiring instinct, even today;
and that in all sorts of professions — whether artist, marine biologist or astronomer — borders of
the unknown are being tested each day.
Thomas Hardy set some of his novels in Egdon Heath, a fictional area of uncultivated land, and
used the landscape to suggest the desires and fears of his characters. He is delving into matters
we all recognise because they are common to humanity. This is surely an act of exploration, and
into a world as remote as the author chooses. Explorer and travel writer Peter Fleming talks of
the moment when the explorer returns to the existence he has left behind with his loved ones. The
traveller ‘who has for weeks or months seen himself only as a puny and irrelevant alien crawling
laboriously over a country in which he has no roots and no background, suddenly encounters his
other self, a relatively solid figure, with a place in the minds of certain people’.
In this book about the exploration of the earth’s surface, I have confined myself to those whose
travels were real and who also aimed at more than personal discovery. But that still left me with
another problem: the word ‘explorer’ has become associated with a past era. We think back to a
golden age, as if exploration peaked somehow in the 19th century — as if the process of discovery
is now on the decline, though the truth is that we have named only one and a half million of this
planet's species, and there may be more than 10 million — and that’s not including bacteria. We
have studied only 5 per cent of the species we know. We have scarcely mapped the ocean floors,
and know even less about ourselves; we fully understand the workings of only 10 per cent of our
brains.
24
```

[Original question page](assets/2084f846e87273ffdb3cc90d040d0987e0a09bcf4ff05ed42eff3c00aba61b2b.jpg)

<!-- Source: /api/assets/bbeb26915daa5c5ee9cc7874ecf923cd329346926bbdaf9f971826b28210f2b4.jpg; PDF page 23; full -->

```text
Reading
Here is how some of today’s ‘explorers’ define the word. Ran Fiennes, dubbed the ‘greatest
living explorer’, said, ‘An explorer is someone who has done something that no human has done
before — and also done something scientifically useful.’ Chris Bonington, a leading mountaineer,
felt exploration was to be found in the act of physically touching the unknown: ‘You have to
have gone somewhere new.’ Then Robin Hanbury-Tenison, a campaigner on behalf of remote
so-called ‘tribal’ peoples, said, ‘A traveller simply records information about some far-off world,
and reports back; but an explorer changes the world.’ Wilfred Thesiger, who crossed Arabia’s
Empty Quarter in 1946, and belongs to an era of unmechanised travel now lost to the rest of us,
told me, ‘If I’d gone across by camel when I could have gone by car, it would have been a stunt.’
To him, exploration meant bringing back information from a remote place regardless of any great
self-discovery.
Each definition is slightly different — and tends to reflect the field of endeavour of each pioneer. It
was the same whoever I asked: the prominent historian would say exploration was a thing of the
past, the cutting-edge scientist would say it was of the present. And so on. They each set their own
particular criteria; the common factor in their approach being that they all had, unlike many of us
who simply enjoy travel or discovering new things, both a very definite objective from the outset
and also a desire to record their findings.
I'd best declare my own bias. As a writer, I’m interested in the exploration of ideas. I’ve done
a great many expeditions and each one was unique. I’ve lived for months alone with isolated
groups of people all around the world, even two ‘uncontacted tribes’. But none of these things
is of the slightest interest to anyone unless, through my books, I’ve found a new slant, explored
a new idea. Why? Because the world has moved on. The time has long passed for the great
continental voyages — another walk to the poles, another crossing of the Empty Quarter. We
know how the land surface of our planet lies; exploration of it is now down to the details — the
habits of microbes, say, or the grazing behaviour of buffalo. Aside from the deep sea and deep
underground, it’s the era of specialists. However, this is to disregard the role the human mind has
in conveying remote places; and this is what interests me: how a fresh interpretation, even of a
well-travelled route, can give its readers new insights.
25
```

[Original question page](assets/bbeb26915daa5c5ee9cc7874ecf923cd329346926bbdaf9f971826b28210f2b4.jpg)

<!-- Source: /api/assets/0f4b70560c23d2b61d797f8d0635187d6ddd894083e18c39168329fbb72dc3eb.jpg; PDF page 24; full -->

```text
Test 1
Questions 27-32
Choose the correct letter, A, B, C or D.
Write the correct letter in boxes 27-32 on your answer sheet.
27 The writer refers to visitors to New York to illustrate the point that
A exploration is an intrinsic element of being human.
B most people are enthusiastic about exploring.
C exploration can lead to surprising results.
D most people find exploration daunting.
28 According to the second paragraph, what is the writer’s view of explorers?
A Their discoveries have brought both benefits and disadvantages.
B Their main value is in teaching others.
C They act on an urge that is common to everyone.
D They tend to be more attracted to certain professions than to others.
29 The writer refers to a description of Egdon Heath to suggest that
A Hardy was writing about his own experience of exploration.
B Hardy was mistaken about the nature of exploration.
C Hardy's aim was to investigate people’s emotional states.
D Hardy's aim was to show the attraction of isolation.
30 In the fourth paragraph, the writer refers to ‘a golden age’ to suggest that
A the amount of useful information produced by exploration has decreased.
B fewer people are interested in exploring than in the 19th century.
C recent developments have made exploration less exciting.
D we are wrong to think that exploration is no longer necessary.
31 In the sixth paragraph, when discussing the definition of exploration, the writer
argues that
A people tend to relate exploration to their own professional interests.
B certain people are likely to misunderstand the nature of exploration.
C the generally accepted definition has changed over time.
D historians and scientists have more valid definitions than the general public.
32 In the last paragraph, the writer explains that he is interested in
A how someone's personality is reflected in their choice of places to visit.
B the human ability to cast new light on places that may be familiar.
C how travel writing has evolved to meet changing demands.
D the feelings that writers develop about the places that they explore.
26
```

[Original question page](assets/0f4b70560c23d2b61d797f8d0635187d6ddd894083e18c39168329fbb72dc3eb.jpg)

<!-- Source: /api/assets/d7158ec8db7e822382c84adf7f581ad9411db974521551a4d54dc698eae078e3.jpg; PDF page 25; full -->

```text
Reading
Questions 33-37
Look at the following statements (Questions 33-37) and the list of explorers below.
Match each statement with the correct explorer, A-E.
Write the correct letter, A-E, in boxes 33-37 on your answer sheet.
NB You may use any letter more than once.
33 He referred to the relevance of the form of transport used.
34 He described feelings on coming back home after a long journey.
35 He worked for the benefit of specific groups of people.
36 He did not consider learning about oneself an essential part of exploration.
37 He defined exploration as being both unique and of value to others.
List of Explorers
A Peter Fleming
B Ran Fiennes
C Chris Bonington
D Robin Hanbury-Tenison
E Wilfred Thesiger
Questions 38–40
Complete the summary below.
Choose NO MORE THAN TWO WORDS from the passage for each answer.
Write your answers in boxes 38–40 on your answer sheet.
The writer’s own bias
The writer has experience of a large number of (38) __________, and was the first stranger that certain previously (39) __________ people had encountered. He believes there is no need for further exploration of Earth’s (40) __________, except to answer specific questions such as how buffalo eat.
```

[Original question page](assets/d7158ec8db7e822382c84adf7f581ad9411db974521551a4d54dc698eae078e3.jpg)

## A 类写作

### Task 1

<!-- Source: /api/assets/512719376e6d9df23420419287cffff28dded79f19b40a4b708ee4ae12e5ffe5.jpg; PDF page 26; full -->

```text
WRITING TASK 1
You should spend about 20 minutes on this task.

The chart below shows the results of a survey about people’s coffee and tea buying and drinking habits in five Australian cities.

Summarise the information by selecting and reporting the main features, and make comparisons where relevant.

Write at least 150 words.

[Text edition note: the complete original figure is retained below.]
```

[Original question page](assets/512719376e6d9df23420419287cffff28dded79f19b40a4b708ee4ae12e5ffe5.jpg)

![Original figure](assets/512719376e6d9df23420419287cffff28dded79f19b40a4b708ee4ae12e5ffe5.jpg)

### Task 2

<!-- Source: /api/assets/6866de5148eb4ab73e0e658a6547e9ebf3569dcd9a0962383ca7377a7f187665.jpg; PDF page 27; full -->

```text
WRITING TASK 2
You should spend about 40 minutes on this task.

Write about the following topic:

In some countries, owning a home rather than renting one is very important for people.

Why might this be the case?

Do you think this is a positive or negative situation?

Give reasons for your answer and include any relevant examples from your own knowledge or experience.

Write at least 250 words.
```

[Original question page](assets/6866de5148eb4ab73e0e658a6547e9ebf3569dcd9a0962383ca7377a7f187665.jpg)

## 口语

### Part 1

<!-- Source: /api/assets/92969f5ac814d69a6daa7d880fd4f6399d8d2ff407f4f1a571eb56dda09e971f.jpg; PDF page 28; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Email
What kinds of emails do you receive about your work or studies?
Do you prefer to email, phone or text your friends? [Why?]
Do you reply to emails and messages as soon as you receive them? [Why/Why not?]
Are you happy to receive emails that are advertising things? [Why/Why not?]
PART 2
Describe a hotel that you know.
You should say:
where this hotel is
what this hotel looks like
what facilities this hotel has
and explain whether you think this is a nice hotel to stay in.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Staying in hotels
Example questions:
What things are important when people are choosing a hotel?
Why do some people not like staying in hotels?
Do you think staying in a luxury hotel is a waste of money?
Working in a hotel
Example questions:
Do you think hotel work is a good career for life?
How does working in a big hotel compare with working in a small hotel?
What skills are needed to be a successful hotel manager?
30
```

[Original question page](assets/92969f5ac814d69a6daa7d880fd4f6399d8d2ff407f4f1a571eb56dda09e971f.jpg)

### Part 2

<!-- Source: /api/assets/92969f5ac814d69a6daa7d880fd4f6399d8d2ff407f4f1a571eb56dda09e971f.jpg; PDF page 28; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Email
What kinds of emails do you receive about your work or studies?
Do you prefer to email, phone or text your friends? [Why?]
Do you reply to emails and messages as soon as you receive them? [Why/Why not?]
Are you happy to receive emails that are advertising things? [Why/Why not?]
PART 2
Describe a hotel that you know.
You should say:
where this hotel is
what this hotel looks like
what facilities this hotel has
and explain whether you think this is a nice hotel to stay in.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Staying in hotels
Example questions:
What things are important when people are choosing a hotel?
Why do some people not like staying in hotels?
Do you think staying in a luxury hotel is a waste of money?
Working in a hotel
Example questions:
Do you think hotel work is a good career for life?
How does working in a big hotel compare with working in a small hotel?
What skills are needed to be a successful hotel manager?
30
```

[Original question page](assets/92969f5ac814d69a6daa7d880fd4f6399d8d2ff407f4f1a571eb56dda09e971f.jpg)

### Part 3

<!-- Source: /api/assets/92969f5ac814d69a6daa7d880fd4f6399d8d2ff407f4f1a571eb56dda09e971f.jpg; PDF page 28; full -->

```text
Test 1
SPEAKING
PART 1
The examiner asks the candidate about him/herself, his/her home, work or studies and
other familiar topics.
EXAMPLE
Email
What kinds of emails do you receive about your work or studies?
Do you prefer to email, phone or text your friends? [Why?]
Do you reply to emails and messages as soon as you receive them? [Why/Why not?]
Are you happy to receive emails that are advertising things? [Why/Why not?]
PART 2
Describe a hotel that you know.
You should say:
where this hotel is
what this hotel looks like
what facilities this hotel has
and explain whether you think this is a nice hotel to stay in.
You will have to talk about the topic for one to two minutes. You have one minute to think about what you are going to say. You can make some notes to help you if you wish.
PART 3
Discussion topics:
Staying in hotels
Example questions:
What things are important when people are choosing a hotel?
Why do some people not like staying in hotels?
Do you think staying in a luxury hotel is a waste of money?
Working in a hotel
Example questions:
Do you think hotel work is a good career for life?
How does working in a big hotel compare with working in a small hotel?
What skills are needed to be a successful hotel manager?
30
```

[Original question page](assets/92969f5ac814d69a6daa7d880fd4f6399d8d2ff407f4f1a571eb56dda09e971f.jpg)
