# 剑雅 15 · Test 1 — Answers and review

For use after submission.

## 听力

### Part 1 · source page 117

TEST 1 LISTENING
1 Jamieson
2 afternoon
3 communication
4 week
5 10/ten
6 suit
7 passport
8 personality
9 feedback
10 time
11 A
12 B
13 A
14 C
15 river
16 1422
17 top
18 pass
19 steam
20 capital
21 G
22 F
23 A
24 E
25 B
26 C
27 C
28 A
29 B
30 D
31 shelter
32 oil
33 roads
34 insects
35 grass(es)
36 water
37 soil
38 dry
39 simple
40 nest(s)
29&30 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. Jamieson

2. afternoon

3. communication

4. week

5. 10 / ten

6. suit

7. passport

8. personality

9. feedback

10. time

### Part 2 · source page 117

TEST 1 LISTENING
1 Jamieson
2 afternoon
3 communication
4 week
5 10/ten
6 suit
7 passport
8 personality
9 feedback
10 time
11 A
12 B
13 A
14 C
15 river
16 1422
17 top
18 pass
19 steam
20 capital
21 G
22 F
23 A
24 E
25 B
26 C
27 C
28 A
29 B
30 D
31 shelter
32 oil
33 roads
34 insects
35 grass(es)
36 water
37 soil
38 dry
39 simple
40 nest(s)
29&30 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

11. A

12. B

13. A

14. C

15. river

16. 1422

17. top

18. pass

19. steam

20. capital

### Part 3 · source page 117

TEST 1 LISTENING
1 Jamieson
2 afternoon
3 communication
4 week
5 10/ten
6 suit
7 passport
8 personality
9 feedback
10 time
11 A
12 B
13 A
14 C
15 river
16 1422
17 top
18 pass
19 steam
20 capital
21 G
22 F
23 A
24 E
25 B
26 C
27 C
28 A
29 B
30 D
31 shelter
32 oil
33 roads
34 insects
35 grass(es)
36 water
37 soil
38 dry
39 simple
40 nest(s)
29&30 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

21. G

22. F

23. A

24. E

25. B

26. C

27. C

28. A

29. B / D

30. B / D

### Part 4 · source page 117

TEST 1 LISTENING
1 Jamieson
2 afternoon
3 communication
4 week
5 10/ten
6 suit
7 passport
8 personality
9 feedback
10 time
11 A
12 B
13 A
14 C
15 river
16 1422
17 top
18 pass
19 steam
20 capital
21 G
22 F
23 A
24 E
25 B
26 C
27 C
28 A
29 B
30 D
31 shelter
32 oil
33 roads
34 insects
35 grass(es)
36 water
37 soil
38 dry
39 simple
40 nest(s)
29&30 IN EITHER ORDER: B,D
If you score: 0–17 unlikely;18–27 may;28–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

31. shelter

32. oil

33. roads

34. insects

35. grass / grasses

36. water

37. soil

38. dry

39. simple

40. nest / nests

## A 类阅读

### Academic Reading · source page 118

TEST 1 READING
1 oval
2 husk
3 seed
4 mace
5 FALSE
6 NOT GIVEN
7 TRUE
8 Arabs
9 plague
10 lime
11 Run
12 Mauritius
13 tsunami
14 C
15 B
16 E
17 G
18 D
19 human error
20 car (-) sharing
21 ownership
22 mileage
23 C
24 D
25 A
26 E
27 A
28 C
29 C
30 D
31 A
32 B
33 E
34 A
35 D
36 E
37 B
38 (unique) expeditions
39 uncontacted / isolated
40 (land) surface
23&24 IN EITHER ORDER: C,D
25&26 IN EITHER ORDER: A,E
If you score: 0–15 unlikely;16–24 may;25–40 likely to get an acceptable score under examination conditions. Improve English or consider practice/lessons; institutions accept different scores.

1. oval

2. husk

3. seed

4. mace

5. FALSE

6. NOT GIVEN

7. TRUE

8. Arabs

9. plague

10. lime

11. Run

12. Mauritius

13. tsunami

14. C

15. B

16. E

17. G

18. D

19. human error

20. car-sharing / car sharing

21. ownership

22. mileage

23. C / D

24. C / D

25. A / E

26. A / E

27. A

28. C

29. C

30. D

31. A

32. B

33. E

34. A

35. D

36. E

37. B

38. expeditions / unique expeditions

39. uncontacted / isolated

40. surface / land surface

## A 类写作

### Writing material: c15-t1-w-1

Percentage of city residents in LAST FOUR WEEKS; fresh coffee/instant coffee/went to cafe for coffee or tea, approximate unlabelled bars: Sydney44/46/61%; Melbourne43/48/64%; Brisbane34/53/56%; Adelaide35/50/just under50%; Hobart39/54/63%. Cafe visits lead in four cities; Adelaide instant coffee marginally exceeds cafe. Fresh coffee lowest in all five; instant always above fresh. Cafe visits not exclusively coffee purchases and categories may overlap, so sums need not100. No calendar year or total residents supplied.



### Writing material: c15-t1-w-2

Explain why home ownership matters more than renting in some countries and evaluate that situation. Both causal explanation and positive/negative judgement are required.



## 口语
